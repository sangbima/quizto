<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-13 10:09:48 --> Config Class Initialized
INFO - 2017-02-13 10:09:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:09:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:09:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:09:48 --> URI Class Initialized
DEBUG - 2017-02-13 10:09:48 --> No URI present. Default controller set.
INFO - 2017-02-13 10:09:48 --> Router Class Initialized
INFO - 2017-02-13 10:09:48 --> Output Class Initialized
INFO - 2017-02-13 10:09:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:09:48 --> Input Class Initialized
INFO - 2017-02-13 10:09:48 --> Language Class Initialized
INFO - 2017-02-13 10:09:48 --> Loader Class Initialized
INFO - 2017-02-13 10:09:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:09:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:09:48 --> Controller Class Initialized
INFO - 2017-02-13 10:09:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:09:48 --> Model Class Initialized
INFO - 2017-02-13 10:09:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:09:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-13 10:09:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-13 10:09:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-13 10:09:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:09:48 --> Total execution time: 0.1940
INFO - 2017-02-13 10:09:49 --> Config Class Initialized
INFO - 2017-02-13 10:09:49 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:09:49 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:09:49 --> Utf8 Class Initialized
INFO - 2017-02-13 10:09:49 --> URI Class Initialized
INFO - 2017-02-13 10:09:49 --> Router Class Initialized
INFO - 2017-02-13 10:09:49 --> Output Class Initialized
INFO - 2017-02-13 10:09:49 --> Security Class Initialized
DEBUG - 2017-02-13 10:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:09:49 --> Input Class Initialized
INFO - 2017-02-13 10:09:49 --> Language Class Initialized
ERROR - 2017-02-13 10:09:49 --> 404 Page Not Found: Faviconico/index
INFO - 2017-02-13 10:09:55 --> Config Class Initialized
INFO - 2017-02-13 10:09:55 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:09:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:09:55 --> Utf8 Class Initialized
INFO - 2017-02-13 10:09:55 --> URI Class Initialized
INFO - 2017-02-13 10:09:55 --> Router Class Initialized
INFO - 2017-02-13 10:09:55 --> Output Class Initialized
INFO - 2017-02-13 10:09:56 --> Security Class Initialized
DEBUG - 2017-02-13 10:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:09:56 --> Input Class Initialized
INFO - 2017-02-13 10:09:56 --> Language Class Initialized
INFO - 2017-02-13 10:09:56 --> Loader Class Initialized
INFO - 2017-02-13 10:09:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:09:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:09:56 --> Controller Class Initialized
INFO - 2017-02-13 10:09:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:09:56 --> Model Class Initialized
INFO - 2017-02-13 10:09:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:09:56 --> Config Class Initialized
INFO - 2017-02-13 10:09:56 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:09:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:09:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:09:56 --> URI Class Initialized
INFO - 2017-02-13 10:09:56 --> Router Class Initialized
INFO - 2017-02-13 10:09:56 --> Output Class Initialized
INFO - 2017-02-13 10:09:56 --> Security Class Initialized
DEBUG - 2017-02-13 10:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:09:56 --> Input Class Initialized
INFO - 2017-02-13 10:09:56 --> Language Class Initialized
INFO - 2017-02-13 10:09:56 --> Loader Class Initialized
INFO - 2017-02-13 10:09:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:09:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:09:56 --> Controller Class Initialized
INFO - 2017-02-13 10:09:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:09:56 --> Model Class Initialized
INFO - 2017-02-13 10:09:56 --> Model Class Initialized
INFO - 2017-02-13 10:09:56 --> Model Class Initialized
INFO - 2017-02-13 10:09:56 --> Model Class Initialized
INFO - 2017-02-13 10:09:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:09:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:09:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-13 10:09:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:09:56 --> Final output sent to browser
DEBUG - 2017-02-13 10:09:56 --> Total execution time: 0.1713
INFO - 2017-02-13 10:14:38 --> Config Class Initialized
INFO - 2017-02-13 10:14:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:14:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:14:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:14:38 --> URI Class Initialized
INFO - 2017-02-13 10:14:38 --> Router Class Initialized
INFO - 2017-02-13 10:14:38 --> Output Class Initialized
INFO - 2017-02-13 10:14:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:14:38 --> Input Class Initialized
INFO - 2017-02-13 10:14:38 --> Language Class Initialized
INFO - 2017-02-13 10:14:38 --> Loader Class Initialized
INFO - 2017-02-13 10:14:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:14:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:14:38 --> Controller Class Initialized
INFO - 2017-02-13 10:14:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:14:38 --> Model Class Initialized
INFO - 2017-02-13 10:14:38 --> Model Class Initialized
INFO - 2017-02-13 10:14:38 --> Model Class Initialized
INFO - 2017-02-13 10:14:38 --> Model Class Initialized
INFO - 2017-02-13 10:14:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-13 10:14:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:14:38 --> Final output sent to browser
DEBUG - 2017-02-13 10:14:38 --> Total execution time: 0.1613
INFO - 2017-02-13 10:14:48 --> Config Class Initialized
INFO - 2017-02-13 10:14:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:14:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:14:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:14:48 --> URI Class Initialized
INFO - 2017-02-13 10:14:48 --> Router Class Initialized
INFO - 2017-02-13 10:14:48 --> Output Class Initialized
INFO - 2017-02-13 10:14:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:14:48 --> Input Class Initialized
INFO - 2017-02-13 10:14:48 --> Language Class Initialized
INFO - 2017-02-13 10:14:48 --> Loader Class Initialized
INFO - 2017-02-13 10:14:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:14:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:14:48 --> Controller Class Initialized
INFO - 2017-02-13 10:14:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:14:48 --> Model Class Initialized
INFO - 2017-02-13 10:14:48 --> Model Class Initialized
INFO - 2017-02-13 10:14:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-13 10:14:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:14:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:14:48 --> Total execution time: 0.1112
INFO - 2017-02-13 10:15:03 --> Config Class Initialized
INFO - 2017-02-13 10:15:03 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:15:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:15:03 --> Utf8 Class Initialized
INFO - 2017-02-13 10:15:03 --> URI Class Initialized
INFO - 2017-02-13 10:15:03 --> Router Class Initialized
INFO - 2017-02-13 10:15:03 --> Output Class Initialized
INFO - 2017-02-13 10:15:03 --> Security Class Initialized
DEBUG - 2017-02-13 10:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:15:03 --> Input Class Initialized
INFO - 2017-02-13 10:15:03 --> Language Class Initialized
INFO - 2017-02-13 10:15:03 --> Loader Class Initialized
INFO - 2017-02-13 10:15:03 --> Helper loaded: url_helper
INFO - 2017-02-13 10:15:03 --> Helper loaded: language_helper
INFO - 2017-02-13 10:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:15:03 --> Controller Class Initialized
INFO - 2017-02-13 10:15:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:15:03 --> Model Class Initialized
INFO - 2017-02-13 10:15:03 --> Model Class Initialized
INFO - 2017-02-13 10:15:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-13 10:15:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:15:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:15:03 --> Total execution time: 0.0893
INFO - 2017-02-13 10:15:03 --> Config Class Initialized
INFO - 2017-02-13 10:15:03 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:15:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:15:03 --> Utf8 Class Initialized
INFO - 2017-02-13 10:15:03 --> URI Class Initialized
INFO - 2017-02-13 10:15:03 --> Router Class Initialized
INFO - 2017-02-13 10:15:03 --> Output Class Initialized
INFO - 2017-02-13 10:15:03 --> Security Class Initialized
DEBUG - 2017-02-13 10:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:15:03 --> Input Class Initialized
INFO - 2017-02-13 10:15:03 --> Language Class Initialized
INFO - 2017-02-13 10:15:03 --> Loader Class Initialized
INFO - 2017-02-13 10:15:03 --> Helper loaded: url_helper
INFO - 2017-02-13 10:15:03 --> Helper loaded: language_helper
INFO - 2017-02-13 10:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:15:03 --> Controller Class Initialized
INFO - 2017-02-13 10:15:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:15:03 --> Model Class Initialized
INFO - 2017-02-13 10:15:03 --> Model Class Initialized
INFO - 2017-02-13 10:15:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:15:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:15:03 --> Total execution time: 0.1516
INFO - 2017-02-13 10:15:21 --> Config Class Initialized
INFO - 2017-02-13 10:15:21 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:15:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:15:21 --> Utf8 Class Initialized
INFO - 2017-02-13 10:15:21 --> URI Class Initialized
INFO - 2017-02-13 10:15:21 --> Router Class Initialized
INFO - 2017-02-13 10:15:21 --> Output Class Initialized
INFO - 2017-02-13 10:15:21 --> Security Class Initialized
DEBUG - 2017-02-13 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:15:21 --> Input Class Initialized
INFO - 2017-02-13 10:15:21 --> Language Class Initialized
INFO - 2017-02-13 10:15:21 --> Loader Class Initialized
INFO - 2017-02-13 10:15:21 --> Helper loaded: url_helper
INFO - 2017-02-13 10:15:21 --> Helper loaded: language_helper
INFO - 2017-02-13 10:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:15:21 --> Controller Class Initialized
INFO - 2017-02-13 10:15:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:15:21 --> Model Class Initialized
INFO - 2017-02-13 10:15:21 --> Model Class Initialized
INFO - 2017-02-13 10:15:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:15:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:15:21 --> Total execution time: 0.1080
INFO - 2017-02-13 10:15:29 --> Config Class Initialized
INFO - 2017-02-13 10:15:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:15:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:15:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:15:29 --> URI Class Initialized
INFO - 2017-02-13 10:15:29 --> Router Class Initialized
INFO - 2017-02-13 10:15:29 --> Output Class Initialized
INFO - 2017-02-13 10:15:29 --> Security Class Initialized
DEBUG - 2017-02-13 10:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:15:29 --> Input Class Initialized
INFO - 2017-02-13 10:15:29 --> Language Class Initialized
INFO - 2017-02-13 10:15:29 --> Loader Class Initialized
INFO - 2017-02-13 10:15:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:15:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:15:29 --> Controller Class Initialized
INFO - 2017-02-13 10:15:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:15:29 --> Model Class Initialized
INFO - 2017-02-13 10:15:29 --> Model Class Initialized
INFO - 2017-02-13 10:15:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:15:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:15:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-13 10:15:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:15:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:15:29 --> Total execution time: 0.1154
INFO - 2017-02-13 10:15:31 --> Config Class Initialized
INFO - 2017-02-13 10:15:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:15:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:15:31 --> Utf8 Class Initialized
INFO - 2017-02-13 10:15:31 --> URI Class Initialized
INFO - 2017-02-13 10:15:31 --> Router Class Initialized
INFO - 2017-02-13 10:15:31 --> Output Class Initialized
INFO - 2017-02-13 10:15:31 --> Security Class Initialized
DEBUG - 2017-02-13 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:15:31 --> Input Class Initialized
INFO - 2017-02-13 10:15:31 --> Language Class Initialized
INFO - 2017-02-13 10:15:31 --> Loader Class Initialized
INFO - 2017-02-13 10:15:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:15:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:15:31 --> Controller Class Initialized
INFO - 2017-02-13 10:15:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:15:31 --> Model Class Initialized
INFO - 2017-02-13 10:15:31 --> Model Class Initialized
INFO - 2017-02-13 10:15:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:15:31 --> Model Class Initialized
INFO - 2017-02-13 10:15:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:15:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-13 10:15:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:15:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:15:31 --> Total execution time: 0.2151
INFO - 2017-02-13 10:15:53 --> Config Class Initialized
INFO - 2017-02-13 10:15:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:15:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:15:53 --> Utf8 Class Initialized
INFO - 2017-02-13 10:15:53 --> URI Class Initialized
INFO - 2017-02-13 10:15:53 --> Router Class Initialized
INFO - 2017-02-13 10:15:53 --> Output Class Initialized
INFO - 2017-02-13 10:15:53 --> Security Class Initialized
DEBUG - 2017-02-13 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:15:53 --> Input Class Initialized
INFO - 2017-02-13 10:15:53 --> Language Class Initialized
INFO - 2017-02-13 10:15:53 --> Loader Class Initialized
INFO - 2017-02-13 10:15:53 --> Helper loaded: url_helper
INFO - 2017-02-13 10:15:53 --> Helper loaded: language_helper
INFO - 2017-02-13 10:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:15:53 --> Controller Class Initialized
INFO - 2017-02-13 10:15:53 --> Database Driver Class Initialized
INFO - 2017-02-13 10:15:53 --> Model Class Initialized
INFO - 2017-02-13 10:15:53 --> Model Class Initialized
INFO - 2017-02-13 10:15:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-13 10:15:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:15:53 --> Final output sent to browser
DEBUG - 2017-02-13 10:15:53 --> Total execution time: 0.1105
INFO - 2017-02-13 10:15:53 --> Config Class Initialized
INFO - 2017-02-13 10:15:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:15:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:15:53 --> Utf8 Class Initialized
INFO - 2017-02-13 10:15:53 --> URI Class Initialized
INFO - 2017-02-13 10:15:53 --> Router Class Initialized
INFO - 2017-02-13 10:15:53 --> Output Class Initialized
INFO - 2017-02-13 10:15:53 --> Security Class Initialized
DEBUG - 2017-02-13 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:15:53 --> Input Class Initialized
INFO - 2017-02-13 10:15:53 --> Language Class Initialized
INFO - 2017-02-13 10:15:53 --> Loader Class Initialized
INFO - 2017-02-13 10:15:53 --> Helper loaded: url_helper
INFO - 2017-02-13 10:15:53 --> Helper loaded: language_helper
INFO - 2017-02-13 10:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:15:53 --> Controller Class Initialized
INFO - 2017-02-13 10:15:53 --> Database Driver Class Initialized
INFO - 2017-02-13 10:15:53 --> Model Class Initialized
INFO - 2017-02-13 10:15:53 --> Model Class Initialized
INFO - 2017-02-13 10:15:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:15:53 --> Final output sent to browser
DEBUG - 2017-02-13 10:15:53 --> Total execution time: 0.2026
INFO - 2017-02-13 10:16:20 --> Config Class Initialized
INFO - 2017-02-13 10:16:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:20 --> URI Class Initialized
INFO - 2017-02-13 10:16:20 --> Router Class Initialized
INFO - 2017-02-13 10:16:20 --> Output Class Initialized
INFO - 2017-02-13 10:16:20 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:20 --> Input Class Initialized
INFO - 2017-02-13 10:16:20 --> Language Class Initialized
INFO - 2017-02-13 10:16:20 --> Loader Class Initialized
INFO - 2017-02-13 10:16:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:20 --> Controller Class Initialized
INFO - 2017-02-13 10:16:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:20 --> Model Class Initialized
INFO - 2017-02-13 10:16:20 --> Model Class Initialized
INFO - 2017-02-13 10:16:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:16:20 --> Total execution time: 0.1482
INFO - 2017-02-13 10:16:24 --> Config Class Initialized
INFO - 2017-02-13 10:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:24 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:24 --> URI Class Initialized
INFO - 2017-02-13 10:16:24 --> Router Class Initialized
INFO - 2017-02-13 10:16:24 --> Output Class Initialized
INFO - 2017-02-13 10:16:24 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:24 --> Input Class Initialized
INFO - 2017-02-13 10:16:24 --> Language Class Initialized
INFO - 2017-02-13 10:16:24 --> Loader Class Initialized
INFO - 2017-02-13 10:16:24 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:24 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:24 --> Controller Class Initialized
INFO - 2017-02-13 10:16:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:25 --> Model Class Initialized
INFO - 2017-02-13 10:16:25 --> Model Class Initialized
INFO - 2017-02-13 10:16:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:25 --> Helper loaded: form_helper
INFO - 2017-02-13 10:16:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-13 10:16:25 --> Could not find the language line "import_user"
INFO - 2017-02-13 10:16:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-13 10:16:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:16:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:16:25 --> Total execution time: 0.1598
INFO - 2017-02-13 10:16:31 --> Config Class Initialized
INFO - 2017-02-13 10:16:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:31 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:31 --> URI Class Initialized
INFO - 2017-02-13 10:16:31 --> Router Class Initialized
INFO - 2017-02-13 10:16:31 --> Output Class Initialized
INFO - 2017-02-13 10:16:31 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:31 --> Input Class Initialized
INFO - 2017-02-13 10:16:31 --> Language Class Initialized
INFO - 2017-02-13 10:16:31 --> Loader Class Initialized
INFO - 2017-02-13 10:16:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:31 --> Controller Class Initialized
INFO - 2017-02-13 10:16:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:31 --> Model Class Initialized
INFO - 2017-02-13 10:16:31 --> Model Class Initialized
INFO - 2017-02-13 10:16:31 --> Model Class Initialized
INFO - 2017-02-13 10:16:31 --> Model Class Initialized
INFO - 2017-02-13 10:16:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:16:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-13 10:16:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:16:32 --> Final output sent to browser
DEBUG - 2017-02-13 10:16:32 --> Total execution time: 0.1691
INFO - 2017-02-13 10:16:38 --> Config Class Initialized
INFO - 2017-02-13 10:16:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:38 --> URI Class Initialized
INFO - 2017-02-13 10:16:38 --> Router Class Initialized
INFO - 2017-02-13 10:16:38 --> Output Class Initialized
INFO - 2017-02-13 10:16:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:38 --> Input Class Initialized
INFO - 2017-02-13 10:16:38 --> Language Class Initialized
INFO - 2017-02-13 10:16:38 --> Loader Class Initialized
INFO - 2017-02-13 10:16:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:38 --> Controller Class Initialized
INFO - 2017-02-13 10:16:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:38 --> Model Class Initialized
INFO - 2017-02-13 10:16:38 --> Model Class Initialized
INFO - 2017-02-13 10:16:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:38 --> Helper loaded: form_helper
INFO - 2017-02-13 10:16:38 --> Form Validation Class Initialized
INFO - 2017-02-13 10:16:38 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-13 10:16:38 --> Config Class Initialized
INFO - 2017-02-13 10:16:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:38 --> URI Class Initialized
INFO - 2017-02-13 10:16:38 --> Router Class Initialized
INFO - 2017-02-13 10:16:38 --> Output Class Initialized
INFO - 2017-02-13 10:16:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:38 --> Input Class Initialized
INFO - 2017-02-13 10:16:38 --> Language Class Initialized
INFO - 2017-02-13 10:16:38 --> Loader Class Initialized
INFO - 2017-02-13 10:16:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:39 --> Controller Class Initialized
INFO - 2017-02-13 10:16:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:39 --> Model Class Initialized
INFO - 2017-02-13 10:16:39 --> Model Class Initialized
INFO - 2017-02-13 10:16:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-13 10:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:16:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:16:39 --> Total execution time: 0.1092
INFO - 2017-02-13 10:16:39 --> Config Class Initialized
INFO - 2017-02-13 10:16:39 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:39 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:39 --> URI Class Initialized
INFO - 2017-02-13 10:16:39 --> Router Class Initialized
INFO - 2017-02-13 10:16:39 --> Output Class Initialized
INFO - 2017-02-13 10:16:39 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:39 --> Input Class Initialized
INFO - 2017-02-13 10:16:39 --> Language Class Initialized
INFO - 2017-02-13 10:16:39 --> Loader Class Initialized
INFO - 2017-02-13 10:16:39 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:39 --> Controller Class Initialized
INFO - 2017-02-13 10:16:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:39 --> Model Class Initialized
INFO - 2017-02-13 10:16:39 --> Model Class Initialized
INFO - 2017-02-13 10:16:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:16:39 --> Total execution time: 0.1206
INFO - 2017-02-13 10:16:41 --> Config Class Initialized
INFO - 2017-02-13 10:16:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:41 --> URI Class Initialized
INFO - 2017-02-13 10:16:41 --> Router Class Initialized
INFO - 2017-02-13 10:16:41 --> Output Class Initialized
INFO - 2017-02-13 10:16:41 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:41 --> Input Class Initialized
INFO - 2017-02-13 10:16:41 --> Language Class Initialized
INFO - 2017-02-13 10:16:41 --> Loader Class Initialized
INFO - 2017-02-13 10:16:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:41 --> Controller Class Initialized
INFO - 2017-02-13 10:16:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:41 --> Model Class Initialized
INFO - 2017-02-13 10:16:41 --> Model Class Initialized
INFO - 2017-02-13 10:16:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:41 --> Config Class Initialized
INFO - 2017-02-13 10:16:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:41 --> URI Class Initialized
INFO - 2017-02-13 10:16:41 --> Router Class Initialized
INFO - 2017-02-13 10:16:41 --> Output Class Initialized
INFO - 2017-02-13 10:16:41 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:41 --> Input Class Initialized
INFO - 2017-02-13 10:16:41 --> Language Class Initialized
INFO - 2017-02-13 10:16:41 --> Loader Class Initialized
INFO - 2017-02-13 10:16:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:41 --> Controller Class Initialized
INFO - 2017-02-13 10:16:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:41 --> Model Class Initialized
INFO - 2017-02-13 10:16:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-13 10:16:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-13 10:16:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-13 10:16:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:16:41 --> Total execution time: 0.1004
INFO - 2017-02-13 10:16:48 --> Config Class Initialized
INFO - 2017-02-13 10:16:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:48 --> URI Class Initialized
INFO - 2017-02-13 10:16:48 --> Router Class Initialized
INFO - 2017-02-13 10:16:48 --> Output Class Initialized
INFO - 2017-02-13 10:16:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:48 --> Input Class Initialized
INFO - 2017-02-13 10:16:48 --> Language Class Initialized
INFO - 2017-02-13 10:16:48 --> Loader Class Initialized
INFO - 2017-02-13 10:16:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:48 --> Controller Class Initialized
INFO - 2017-02-13 10:16:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:48 --> Model Class Initialized
INFO - 2017-02-13 10:16:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:48 --> Config Class Initialized
INFO - 2017-02-13 10:16:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:48 --> URI Class Initialized
INFO - 2017-02-13 10:16:48 --> Router Class Initialized
INFO - 2017-02-13 10:16:48 --> Output Class Initialized
INFO - 2017-02-13 10:16:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:48 --> Input Class Initialized
INFO - 2017-02-13 10:16:48 --> Language Class Initialized
INFO - 2017-02-13 10:16:48 --> Loader Class Initialized
INFO - 2017-02-13 10:16:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:48 --> Controller Class Initialized
INFO - 2017-02-13 10:16:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:48 --> Model Class Initialized
INFO - 2017-02-13 10:16:48 --> Model Class Initialized
INFO - 2017-02-13 10:16:48 --> Model Class Initialized
INFO - 2017-02-13 10:16:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:16:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-02-13 10:16:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:16:49 --> Final output sent to browser
DEBUG - 2017-02-13 10:16:49 --> Total execution time: 0.1736
INFO - 2017-02-13 10:16:58 --> Config Class Initialized
INFO - 2017-02-13 10:16:58 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:58 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:58 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:58 --> URI Class Initialized
INFO - 2017-02-13 10:16:58 --> Router Class Initialized
INFO - 2017-02-13 10:16:58 --> Output Class Initialized
INFO - 2017-02-13 10:16:58 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:58 --> Input Class Initialized
INFO - 2017-02-13 10:16:58 --> Language Class Initialized
INFO - 2017-02-13 10:16:58 --> Loader Class Initialized
INFO - 2017-02-13 10:16:58 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:58 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:58 --> Controller Class Initialized
INFO - 2017-02-13 10:16:58 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:58 --> Config Class Initialized
INFO - 2017-02-13 10:16:58 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:58 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:58 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:58 --> URI Class Initialized
INFO - 2017-02-13 10:16:58 --> Router Class Initialized
INFO - 2017-02-13 10:16:58 --> Output Class Initialized
INFO - 2017-02-13 10:16:58 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:58 --> Input Class Initialized
INFO - 2017-02-13 10:16:58 --> Language Class Initialized
INFO - 2017-02-13 10:16:58 --> Loader Class Initialized
INFO - 2017-02-13 10:16:58 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:58 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:58 --> Controller Class Initialized
INFO - 2017-02-13 10:16:58 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:58 --> Config Class Initialized
INFO - 2017-02-13 10:16:58 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:16:58 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:16:58 --> Utf8 Class Initialized
INFO - 2017-02-13 10:16:58 --> URI Class Initialized
INFO - 2017-02-13 10:16:58 --> Router Class Initialized
INFO - 2017-02-13 10:16:58 --> Output Class Initialized
INFO - 2017-02-13 10:16:58 --> Security Class Initialized
DEBUG - 2017-02-13 10:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:16:58 --> Input Class Initialized
INFO - 2017-02-13 10:16:58 --> Language Class Initialized
INFO - 2017-02-13 10:16:58 --> Loader Class Initialized
INFO - 2017-02-13 10:16:58 --> Helper loaded: url_helper
INFO - 2017-02-13 10:16:58 --> Helper loaded: language_helper
INFO - 2017-02-13 10:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:16:58 --> Controller Class Initialized
INFO - 2017-02-13 10:16:58 --> Database Driver Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Model Class Initialized
INFO - 2017-02-13 10:16:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:16:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:16:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01.php
INFO - 2017-02-13 10:16:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:16:58 --> Final output sent to browser
DEBUG - 2017-02-13 10:16:58 --> Total execution time: 0.1398
INFO - 2017-02-13 10:17:01 --> Config Class Initialized
INFO - 2017-02-13 10:17:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:01 --> URI Class Initialized
INFO - 2017-02-13 10:17:01 --> Router Class Initialized
INFO - 2017-02-13 10:17:01 --> Output Class Initialized
INFO - 2017-02-13 10:17:01 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:01 --> Input Class Initialized
INFO - 2017-02-13 10:17:01 --> Language Class Initialized
INFO - 2017-02-13 10:17:01 --> Loader Class Initialized
INFO - 2017-02-13 10:17:01 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:01 --> Controller Class Initialized
INFO - 2017-02-13 10:17:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:01 --> Model Class Initialized
INFO - 2017-02-13 10:17:01 --> Model Class Initialized
INFO - 2017-02-13 10:17:01 --> Model Class Initialized
INFO - 2017-02-13 10:17:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:01 --> Config Class Initialized
INFO - 2017-02-13 10:17:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:01 --> URI Class Initialized
INFO - 2017-02-13 10:17:01 --> Router Class Initialized
INFO - 2017-02-13 10:17:01 --> Output Class Initialized
INFO - 2017-02-13 10:17:01 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:01 --> Input Class Initialized
INFO - 2017-02-13 10:17:01 --> Language Class Initialized
INFO - 2017-02-13 10:17:01 --> Loader Class Initialized
INFO - 2017-02-13 10:17:01 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:01 --> Controller Class Initialized
INFO - 2017-02-13 10:17:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:01 --> Model Class Initialized
INFO - 2017-02-13 10:17:01 --> Model Class Initialized
INFO - 2017-02-13 10:17:01 --> Model Class Initialized
INFO - 2017-02-13 10:17:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_01_attempt.php
INFO - 2017-02-13 10:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:17:01 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:01 --> Total execution time: 0.2277
INFO - 2017-02-13 10:17:01 --> Config Class Initialized
INFO - 2017-02-13 10:17:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:01 --> Config Class Initialized
INFO - 2017-02-13 10:17:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:01 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:01 --> URI Class Initialized
INFO - 2017-02-13 10:17:01 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:01 --> Output Class Initialized
INFO - 2017-02-13 10:17:01 --> URI Class Initialized
INFO - 2017-02-13 10:17:01 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:01 --> Input Class Initialized
INFO - 2017-02-13 10:17:01 --> Language Class Initialized
INFO - 2017-02-13 10:17:01 --> Router Class Initialized
INFO - 2017-02-13 10:17:01 --> Output Class Initialized
INFO - 2017-02-13 10:17:01 --> Loader Class Initialized
INFO - 2017-02-13 10:17:01 --> Security Class Initialized
INFO - 2017-02-13 10:17:01 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:01 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:01 --> Input Class Initialized
INFO - 2017-02-13 10:17:01 --> Language Class Initialized
INFO - 2017-02-13 10:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:01 --> Controller Class Initialized
INFO - 2017-02-13 10:17:01 --> Loader Class Initialized
INFO - 2017-02-13 10:17:01 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:01 --> Model Class Initialized
INFO - 2017-02-13 10:17:01 --> Model Class Initialized
INFO - 2017-02-13 10:17:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:02 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:02 --> Total execution time: 0.1344
INFO - 2017-02-13 10:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:02 --> Controller Class Initialized
INFO - 2017-02-13 10:17:02 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:02 --> Model Class Initialized
INFO - 2017-02-13 10:17:02 --> Model Class Initialized
INFO - 2017-02-13 10:17:02 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:17:02 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:17:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:17:02 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:02 --> Total execution time: 0.3223
INFO - 2017-02-13 10:17:06 --> Config Class Initialized
INFO - 2017-02-13 10:17:06 --> Config Class Initialized
INFO - 2017-02-13 10:17:06 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:06 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:06 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:06 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:06 --> URI Class Initialized
INFO - 2017-02-13 10:17:06 --> Router Class Initialized
INFO - 2017-02-13 10:17:06 --> Output Class Initialized
INFO - 2017-02-13 10:17:06 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:06 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:06 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:06 --> Input Class Initialized
INFO - 2017-02-13 10:17:06 --> URI Class Initialized
INFO - 2017-02-13 10:17:06 --> Language Class Initialized
INFO - 2017-02-13 10:17:06 --> Router Class Initialized
INFO - 2017-02-13 10:17:06 --> Output Class Initialized
INFO - 2017-02-13 10:17:06 --> Loader Class Initialized
INFO - 2017-02-13 10:17:06 --> Security Class Initialized
INFO - 2017-02-13 10:17:06 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:06 --> Input Class Initialized
INFO - 2017-02-13 10:17:06 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:06 --> Language Class Initialized
INFO - 2017-02-13 10:17:06 --> Loader Class Initialized
INFO - 2017-02-13 10:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:06 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:06 --> Controller Class Initialized
INFO - 2017-02-13 10:17:06 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:06 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:06 --> Model Class Initialized
INFO - 2017-02-13 10:17:06 --> Model Class Initialized
INFO - 2017-02-13 10:17:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:06 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:06 --> Total execution time: 0.1133
INFO - 2017-02-13 10:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:06 --> Controller Class Initialized
INFO - 2017-02-13 10:17:06 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:06 --> Model Class Initialized
INFO - 2017-02-13 10:17:06 --> Model Class Initialized
INFO - 2017-02-13 10:17:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:06 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:06 --> Total execution time: 0.2097
INFO - 2017-02-13 10:17:07 --> Config Class Initialized
INFO - 2017-02-13 10:17:07 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:07 --> Config Class Initialized
INFO - 2017-02-13 10:17:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:07 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:07 --> URI Class Initialized
INFO - 2017-02-13 10:17:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:07 --> Router Class Initialized
INFO - 2017-02-13 10:17:07 --> URI Class Initialized
INFO - 2017-02-13 10:17:07 --> Output Class Initialized
INFO - 2017-02-13 10:17:07 --> Router Class Initialized
INFO - 2017-02-13 10:17:07 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:07 --> Input Class Initialized
INFO - 2017-02-13 10:17:07 --> Output Class Initialized
INFO - 2017-02-13 10:17:07 --> Language Class Initialized
INFO - 2017-02-13 10:17:07 --> Security Class Initialized
INFO - 2017-02-13 10:17:07 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:07 --> Input Class Initialized
INFO - 2017-02-13 10:17:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:07 --> Language Class Initialized
INFO - 2017-02-13 10:17:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:07 --> Loader Class Initialized
INFO - 2017-02-13 10:17:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:07 --> Controller Class Initialized
INFO - 2017-02-13 10:17:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:07 --> Model Class Initialized
INFO - 2017-02-13 10:17:07 --> Model Class Initialized
INFO - 2017-02-13 10:17:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:07 --> Total execution time: 0.1334
INFO - 2017-02-13 10:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:07 --> Controller Class Initialized
INFO - 2017-02-13 10:17:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:07 --> Model Class Initialized
INFO - 2017-02-13 10:17:07 --> Model Class Initialized
INFO - 2017-02-13 10:17:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:08 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:08 --> Total execution time: 0.2885
INFO - 2017-02-13 10:17:09 --> Config Class Initialized
INFO - 2017-02-13 10:17:09 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:09 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:09 --> Config Class Initialized
INFO - 2017-02-13 10:17:09 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:09 --> URI Class Initialized
INFO - 2017-02-13 10:17:09 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:09 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:09 --> Output Class Initialized
INFO - 2017-02-13 10:17:09 --> URI Class Initialized
INFO - 2017-02-13 10:17:09 --> Security Class Initialized
INFO - 2017-02-13 10:17:09 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:09 --> Output Class Initialized
INFO - 2017-02-13 10:17:09 --> Input Class Initialized
INFO - 2017-02-13 10:17:09 --> Language Class Initialized
INFO - 2017-02-13 10:17:09 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:09 --> Input Class Initialized
INFO - 2017-02-13 10:17:09 --> Loader Class Initialized
INFO - 2017-02-13 10:17:09 --> Language Class Initialized
INFO - 2017-02-13 10:17:09 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:09 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:09 --> Loader Class Initialized
INFO - 2017-02-13 10:17:09 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:09 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:09 --> Controller Class Initialized
INFO - 2017-02-13 10:17:09 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:09 --> Model Class Initialized
INFO - 2017-02-13 10:17:09 --> Model Class Initialized
INFO - 2017-02-13 10:17:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:09 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:09 --> Total execution time: 0.1166
INFO - 2017-02-13 10:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:09 --> Controller Class Initialized
INFO - 2017-02-13 10:17:09 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:09 --> Model Class Initialized
INFO - 2017-02-13 10:17:09 --> Model Class Initialized
INFO - 2017-02-13 10:17:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:09 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:09 --> Total execution time: 0.2920
INFO - 2017-02-13 10:17:11 --> Config Class Initialized
INFO - 2017-02-13 10:17:11 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:11 --> Config Class Initialized
INFO - 2017-02-13 10:17:11 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:11 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:11 --> URI Class Initialized
INFO - 2017-02-13 10:17:11 --> Router Class Initialized
INFO - 2017-02-13 10:17:11 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:11 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:11 --> Security Class Initialized
INFO - 2017-02-13 10:17:11 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:11 --> Router Class Initialized
INFO - 2017-02-13 10:17:11 --> Input Class Initialized
INFO - 2017-02-13 10:17:11 --> Language Class Initialized
INFO - 2017-02-13 10:17:11 --> Output Class Initialized
INFO - 2017-02-13 10:17:11 --> Security Class Initialized
INFO - 2017-02-13 10:17:11 --> Loader Class Initialized
INFO - 2017-02-13 10:17:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:11 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:11 --> Input Class Initialized
INFO - 2017-02-13 10:17:11 --> Language Class Initialized
INFO - 2017-02-13 10:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:11 --> Controller Class Initialized
INFO - 2017-02-13 10:17:11 --> Loader Class Initialized
INFO - 2017-02-13 10:17:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:11 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:11 --> Model Class Initialized
INFO - 2017-02-13 10:17:11 --> Model Class Initialized
INFO - 2017-02-13 10:17:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:11 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:11 --> Total execution time: 0.1359
INFO - 2017-02-13 10:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:11 --> Controller Class Initialized
INFO - 2017-02-13 10:17:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:11 --> Model Class Initialized
INFO - 2017-02-13 10:17:11 --> Model Class Initialized
INFO - 2017-02-13 10:17:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:11 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:11 --> Total execution time: 0.3556
INFO - 2017-02-13 10:17:12 --> Config Class Initialized
INFO - 2017-02-13 10:17:12 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:12 --> Config Class Initialized
INFO - 2017-02-13 10:17:12 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:12 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:12 --> URI Class Initialized
INFO - 2017-02-13 10:17:12 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:12 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:12 --> URI Class Initialized
INFO - 2017-02-13 10:17:12 --> Output Class Initialized
INFO - 2017-02-13 10:17:12 --> Router Class Initialized
INFO - 2017-02-13 10:17:12 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:12 --> Input Class Initialized
INFO - 2017-02-13 10:17:12 --> Output Class Initialized
INFO - 2017-02-13 10:17:12 --> Language Class Initialized
INFO - 2017-02-13 10:17:12 --> Security Class Initialized
INFO - 2017-02-13 10:17:12 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:12 --> Input Class Initialized
INFO - 2017-02-13 10:17:12 --> Language Class Initialized
INFO - 2017-02-13 10:17:12 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:12 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:12 --> Loader Class Initialized
INFO - 2017-02-13 10:17:12 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:12 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:12 --> Controller Class Initialized
INFO - 2017-02-13 10:17:12 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:12 --> Model Class Initialized
INFO - 2017-02-13 10:17:12 --> Model Class Initialized
INFO - 2017-02-13 10:17:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:12 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:12 --> Total execution time: 0.1241
INFO - 2017-02-13 10:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:12 --> Controller Class Initialized
INFO - 2017-02-13 10:17:12 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:12 --> Model Class Initialized
INFO - 2017-02-13 10:17:12 --> Model Class Initialized
INFO - 2017-02-13 10:17:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:13 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:13 --> Total execution time: 0.3000
INFO - 2017-02-13 10:17:14 --> Config Class Initialized
INFO - 2017-02-13 10:17:14 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:14 --> Config Class Initialized
INFO - 2017-02-13 10:17:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:14 --> URI Class Initialized
INFO - 2017-02-13 10:17:14 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:14 --> Output Class Initialized
INFO - 2017-02-13 10:17:14 --> URI Class Initialized
INFO - 2017-02-13 10:17:14 --> Security Class Initialized
INFO - 2017-02-13 10:17:14 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:14 --> Input Class Initialized
INFO - 2017-02-13 10:17:14 --> Language Class Initialized
INFO - 2017-02-13 10:17:14 --> Output Class Initialized
INFO - 2017-02-13 10:17:14 --> Security Class Initialized
INFO - 2017-02-13 10:17:14 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:14 --> Input Class Initialized
INFO - 2017-02-13 10:17:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:14 --> Language Class Initialized
INFO - 2017-02-13 10:17:14 --> Loader Class Initialized
INFO - 2017-02-13 10:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:14 --> Controller Class Initialized
INFO - 2017-02-13 10:17:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:14 --> Model Class Initialized
INFO - 2017-02-13 10:17:14 --> Model Class Initialized
INFO - 2017-02-13 10:17:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:14 --> Total execution time: 0.1015
INFO - 2017-02-13 10:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:14 --> Controller Class Initialized
INFO - 2017-02-13 10:17:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:14 --> Model Class Initialized
INFO - 2017-02-13 10:17:14 --> Model Class Initialized
INFO - 2017-02-13 10:17:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:14 --> Total execution time: 0.3188
INFO - 2017-02-13 10:17:15 --> Config Class Initialized
INFO - 2017-02-13 10:17:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:15 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:15 --> URI Class Initialized
INFO - 2017-02-13 10:17:15 --> Config Class Initialized
INFO - 2017-02-13 10:17:15 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:15 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:15 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:15 --> Output Class Initialized
INFO - 2017-02-13 10:17:15 --> URI Class Initialized
INFO - 2017-02-13 10:17:15 --> Security Class Initialized
INFO - 2017-02-13 10:17:15 --> Router Class Initialized
INFO - 2017-02-13 10:17:15 --> Output Class Initialized
INFO - 2017-02-13 10:17:15 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:15 --> Input Class Initialized
INFO - 2017-02-13 10:17:15 --> Language Class Initialized
DEBUG - 2017-02-13 10:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:15 --> Input Class Initialized
INFO - 2017-02-13 10:17:15 --> Loader Class Initialized
INFO - 2017-02-13 10:17:15 --> Language Class Initialized
INFO - 2017-02-13 10:17:15 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:15 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:15 --> Loader Class Initialized
INFO - 2017-02-13 10:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:15 --> Controller Class Initialized
INFO - 2017-02-13 10:17:15 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:15 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:15 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:15 --> Model Class Initialized
INFO - 2017-02-13 10:17:15 --> Model Class Initialized
INFO - 2017-02-13 10:17:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:15 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:15 --> Total execution time: 0.1265
INFO - 2017-02-13 10:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:15 --> Controller Class Initialized
INFO - 2017-02-13 10:17:15 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:15 --> Model Class Initialized
INFO - 2017-02-13 10:17:15 --> Model Class Initialized
INFO - 2017-02-13 10:17:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:16 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:16 --> Total execution time: 0.3786
INFO - 2017-02-13 10:17:17 --> Config Class Initialized
INFO - 2017-02-13 10:17:17 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:17 --> Config Class Initialized
INFO - 2017-02-13 10:17:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:17 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:17 --> URI Class Initialized
INFO - 2017-02-13 10:17:17 --> Router Class Initialized
INFO - 2017-02-13 10:17:17 --> URI Class Initialized
INFO - 2017-02-13 10:17:17 --> Output Class Initialized
INFO - 2017-02-13 10:17:17 --> Router Class Initialized
INFO - 2017-02-13 10:17:17 --> Security Class Initialized
INFO - 2017-02-13 10:17:17 --> Output Class Initialized
INFO - 2017-02-13 10:17:17 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:17 --> Input Class Initialized
INFO - 2017-02-13 10:17:17 --> Language Class Initialized
INFO - 2017-02-13 10:17:17 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:17 --> Input Class Initialized
INFO - 2017-02-13 10:17:17 --> Language Class Initialized
INFO - 2017-02-13 10:17:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:17 --> Loader Class Initialized
INFO - 2017-02-13 10:17:17 --> Controller Class Initialized
INFO - 2017-02-13 10:17:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:17 --> Model Class Initialized
INFO - 2017-02-13 10:17:17 --> Model Class Initialized
INFO - 2017-02-13 10:17:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:17 --> Total execution time: 0.1193
INFO - 2017-02-13 10:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:17 --> Controller Class Initialized
INFO - 2017-02-13 10:17:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:17 --> Model Class Initialized
INFO - 2017-02-13 10:17:17 --> Model Class Initialized
INFO - 2017-02-13 10:17:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:17 --> Total execution time: 0.3418
INFO - 2017-02-13 10:17:18 --> Config Class Initialized
INFO - 2017-02-13 10:17:18 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:18 --> Config Class Initialized
INFO - 2017-02-13 10:17:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:18 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:18 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:18 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:18 --> Router Class Initialized
INFO - 2017-02-13 10:17:18 --> URI Class Initialized
INFO - 2017-02-13 10:17:18 --> Router Class Initialized
INFO - 2017-02-13 10:17:18 --> Output Class Initialized
INFO - 2017-02-13 10:17:18 --> Security Class Initialized
INFO - 2017-02-13 10:17:18 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:18 --> Input Class Initialized
INFO - 2017-02-13 10:17:18 --> Language Class Initialized
INFO - 2017-02-13 10:17:18 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:18 --> Input Class Initialized
INFO - 2017-02-13 10:17:18 --> Loader Class Initialized
INFO - 2017-02-13 10:17:18 --> Language Class Initialized
INFO - 2017-02-13 10:17:18 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:18 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:18 --> Loader Class Initialized
INFO - 2017-02-13 10:17:18 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:18 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:18 --> Controller Class Initialized
INFO - 2017-02-13 10:17:18 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:18 --> Model Class Initialized
INFO - 2017-02-13 10:17:18 --> Model Class Initialized
INFO - 2017-02-13 10:17:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:18 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:18 --> Total execution time: 0.1198
INFO - 2017-02-13 10:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:18 --> Controller Class Initialized
INFO - 2017-02-13 10:17:18 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:18 --> Model Class Initialized
INFO - 2017-02-13 10:17:18 --> Model Class Initialized
INFO - 2017-02-13 10:17:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:19 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:19 --> Total execution time: 0.3568
INFO - 2017-02-13 10:17:20 --> Config Class Initialized
INFO - 2017-02-13 10:17:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:20 --> Config Class Initialized
INFO - 2017-02-13 10:17:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:20 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:20 --> URI Class Initialized
INFO - 2017-02-13 10:17:20 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:20 --> Output Class Initialized
INFO - 2017-02-13 10:17:20 --> URI Class Initialized
INFO - 2017-02-13 10:17:20 --> Security Class Initialized
INFO - 2017-02-13 10:17:20 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:20 --> Input Class Initialized
INFO - 2017-02-13 10:17:20 --> Output Class Initialized
INFO - 2017-02-13 10:17:20 --> Language Class Initialized
INFO - 2017-02-13 10:17:20 --> Security Class Initialized
INFO - 2017-02-13 10:17:20 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:20 --> Input Class Initialized
INFO - 2017-02-13 10:17:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:20 --> Language Class Initialized
INFO - 2017-02-13 10:17:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:20 --> Loader Class Initialized
INFO - 2017-02-13 10:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:20 --> Controller Class Initialized
INFO - 2017-02-13 10:17:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:20 --> Model Class Initialized
INFO - 2017-02-13 10:17:20 --> Model Class Initialized
INFO - 2017-02-13 10:17:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:20 --> Total execution time: 0.1045
INFO - 2017-02-13 10:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:20 --> Controller Class Initialized
INFO - 2017-02-13 10:17:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:20 --> Model Class Initialized
INFO - 2017-02-13 10:17:20 --> Model Class Initialized
INFO - 2017-02-13 10:17:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:20 --> Total execution time: 0.2487
INFO - 2017-02-13 10:17:21 --> Config Class Initialized
INFO - 2017-02-13 10:17:21 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:21 --> Config Class Initialized
INFO - 2017-02-13 10:17:21 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:21 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:21 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:21 --> Router Class Initialized
INFO - 2017-02-13 10:17:21 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:21 --> URI Class Initialized
INFO - 2017-02-13 10:17:21 --> Output Class Initialized
INFO - 2017-02-13 10:17:21 --> Security Class Initialized
INFO - 2017-02-13 10:17:21 --> Router Class Initialized
INFO - 2017-02-13 10:17:21 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:21 --> Input Class Initialized
INFO - 2017-02-13 10:17:21 --> Security Class Initialized
INFO - 2017-02-13 10:17:21 --> Language Class Initialized
DEBUG - 2017-02-13 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:21 --> Input Class Initialized
INFO - 2017-02-13 10:17:21 --> Language Class Initialized
INFO - 2017-02-13 10:17:21 --> Loader Class Initialized
INFO - 2017-02-13 10:17:21 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:21 --> Loader Class Initialized
INFO - 2017-02-13 10:17:21 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:21 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:21 --> Controller Class Initialized
INFO - 2017-02-13 10:17:21 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:21 --> Model Class Initialized
INFO - 2017-02-13 10:17:21 --> Model Class Initialized
INFO - 2017-02-13 10:17:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:21 --> Total execution time: 0.4175
INFO - 2017-02-13 10:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:21 --> Controller Class Initialized
INFO - 2017-02-13 10:17:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:21 --> Model Class Initialized
INFO - 2017-02-13 10:17:21 --> Model Class Initialized
INFO - 2017-02-13 10:17:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:21 --> Total execution time: 0.4684
INFO - 2017-02-13 10:17:23 --> Config Class Initialized
INFO - 2017-02-13 10:17:23 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:23 --> Config Class Initialized
INFO - 2017-02-13 10:17:23 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:23 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:23 --> Router Class Initialized
INFO - 2017-02-13 10:17:23 --> URI Class Initialized
INFO - 2017-02-13 10:17:23 --> Router Class Initialized
INFO - 2017-02-13 10:17:23 --> Output Class Initialized
INFO - 2017-02-13 10:17:23 --> Output Class Initialized
INFO - 2017-02-13 10:17:23 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:23 --> Input Class Initialized
INFO - 2017-02-13 10:17:23 --> Security Class Initialized
INFO - 2017-02-13 10:17:23 --> Language Class Initialized
DEBUG - 2017-02-13 10:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:23 --> Input Class Initialized
INFO - 2017-02-13 10:17:23 --> Loader Class Initialized
INFO - 2017-02-13 10:17:23 --> Language Class Initialized
INFO - 2017-02-13 10:17:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:23 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:23 --> Loader Class Initialized
INFO - 2017-02-13 10:17:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:23 --> Controller Class Initialized
INFO - 2017-02-13 10:17:23 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:23 --> Model Class Initialized
INFO - 2017-02-13 10:17:23 --> Model Class Initialized
INFO - 2017-02-13 10:17:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:23 --> Total execution time: 0.1137
INFO - 2017-02-13 10:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:23 --> Controller Class Initialized
INFO - 2017-02-13 10:17:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:23 --> Model Class Initialized
INFO - 2017-02-13 10:17:23 --> Model Class Initialized
INFO - 2017-02-13 10:17:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:23 --> Total execution time: 0.3549
INFO - 2017-02-13 10:17:24 --> Config Class Initialized
INFO - 2017-02-13 10:17:24 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:24 --> Config Class Initialized
INFO - 2017-02-13 10:17:24 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:24 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:24 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:24 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:24 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:24 --> URI Class Initialized
INFO - 2017-02-13 10:17:24 --> Router Class Initialized
INFO - 2017-02-13 10:17:24 --> URI Class Initialized
INFO - 2017-02-13 10:17:24 --> Output Class Initialized
INFO - 2017-02-13 10:17:24 --> Router Class Initialized
INFO - 2017-02-13 10:17:24 --> Security Class Initialized
INFO - 2017-02-13 10:17:24 --> Output Class Initialized
INFO - 2017-02-13 10:17:24 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:24 --> Input Class Initialized
DEBUG - 2017-02-13 10:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:24 --> Input Class Initialized
INFO - 2017-02-13 10:17:24 --> Language Class Initialized
INFO - 2017-02-13 10:17:24 --> Language Class Initialized
INFO - 2017-02-13 10:17:24 --> Loader Class Initialized
INFO - 2017-02-13 10:17:24 --> Loader Class Initialized
INFO - 2017-02-13 10:17:24 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:24 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:24 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:24 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:24 --> Controller Class Initialized
INFO - 2017-02-13 10:17:24 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:24 --> Model Class Initialized
INFO - 2017-02-13 10:17:24 --> Model Class Initialized
INFO - 2017-02-13 10:17:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:25 --> Total execution time: 0.4158
INFO - 2017-02-13 10:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:25 --> Controller Class Initialized
INFO - 2017-02-13 10:17:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:25 --> Model Class Initialized
INFO - 2017-02-13 10:17:25 --> Model Class Initialized
INFO - 2017-02-13 10:17:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:25 --> Total execution time: 0.4661
INFO - 2017-02-13 10:17:26 --> Config Class Initialized
INFO - 2017-02-13 10:17:26 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:26 --> URI Class Initialized
INFO - 2017-02-13 10:17:26 --> Config Class Initialized
INFO - 2017-02-13 10:17:26 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:26 --> Router Class Initialized
INFO - 2017-02-13 10:17:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:26 --> URI Class Initialized
INFO - 2017-02-13 10:17:26 --> Output Class Initialized
INFO - 2017-02-13 10:17:26 --> Router Class Initialized
INFO - 2017-02-13 10:17:26 --> Security Class Initialized
INFO - 2017-02-13 10:17:26 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:26 --> Input Class Initialized
INFO - 2017-02-13 10:17:26 --> Security Class Initialized
INFO - 2017-02-13 10:17:26 --> Language Class Initialized
INFO - 2017-02-13 10:17:26 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:26 --> Input Class Initialized
INFO - 2017-02-13 10:17:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:26 --> Language Class Initialized
INFO - 2017-02-13 10:17:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:26 --> Controller Class Initialized
INFO - 2017-02-13 10:17:26 --> Loader Class Initialized
INFO - 2017-02-13 10:17:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:26 --> Model Class Initialized
INFO - 2017-02-13 10:17:26 --> Model Class Initialized
INFO - 2017-02-13 10:17:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:26 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:26 --> Total execution time: 0.1276
INFO - 2017-02-13 10:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:26 --> Controller Class Initialized
INFO - 2017-02-13 10:17:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:26 --> Model Class Initialized
INFO - 2017-02-13 10:17:26 --> Model Class Initialized
INFO - 2017-02-13 10:17:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:26 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:26 --> Total execution time: 0.4078
INFO - 2017-02-13 10:17:27 --> Config Class Initialized
INFO - 2017-02-13 10:17:27 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:27 --> Config Class Initialized
INFO - 2017-02-13 10:17:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:27 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:27 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:27 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:27 --> Router Class Initialized
INFO - 2017-02-13 10:17:27 --> URI Class Initialized
INFO - 2017-02-13 10:17:27 --> Output Class Initialized
INFO - 2017-02-13 10:17:27 --> Router Class Initialized
INFO - 2017-02-13 10:17:27 --> Security Class Initialized
INFO - 2017-02-13 10:17:27 --> Output Class Initialized
INFO - 2017-02-13 10:17:27 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:27 --> Input Class Initialized
DEBUG - 2017-02-13 10:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:27 --> Language Class Initialized
INFO - 2017-02-13 10:17:27 --> Input Class Initialized
INFO - 2017-02-13 10:17:27 --> Language Class Initialized
INFO - 2017-02-13 10:17:27 --> Loader Class Initialized
INFO - 2017-02-13 10:17:27 --> Loader Class Initialized
INFO - 2017-02-13 10:17:27 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:27 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:27 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:27 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:27 --> Controller Class Initialized
INFO - 2017-02-13 10:17:27 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:27 --> Model Class Initialized
INFO - 2017-02-13 10:17:27 --> Model Class Initialized
INFO - 2017-02-13 10:17:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:28 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:28 --> Total execution time: 0.4027
INFO - 2017-02-13 10:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:28 --> Controller Class Initialized
INFO - 2017-02-13 10:17:28 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:28 --> Model Class Initialized
INFO - 2017-02-13 10:17:28 --> Model Class Initialized
INFO - 2017-02-13 10:17:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:28 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:28 --> Total execution time: 0.4477
INFO - 2017-02-13 10:17:29 --> Config Class Initialized
INFO - 2017-02-13 10:17:29 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:29 --> Config Class Initialized
DEBUG - 2017-02-13 10:17:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:29 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:29 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:29 --> Router Class Initialized
INFO - 2017-02-13 10:17:29 --> URI Class Initialized
INFO - 2017-02-13 10:17:29 --> Output Class Initialized
INFO - 2017-02-13 10:17:29 --> Security Class Initialized
INFO - 2017-02-13 10:17:29 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:29 --> Input Class Initialized
INFO - 2017-02-13 10:17:29 --> Language Class Initialized
INFO - 2017-02-13 10:17:29 --> Output Class Initialized
INFO - 2017-02-13 10:17:29 --> Security Class Initialized
INFO - 2017-02-13 10:17:29 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:29 --> Input Class Initialized
INFO - 2017-02-13 10:17:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:29 --> Language Class Initialized
INFO - 2017-02-13 10:17:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:29 --> Controller Class Initialized
INFO - 2017-02-13 10:17:29 --> Loader Class Initialized
INFO - 2017-02-13 10:17:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:29 --> Model Class Initialized
INFO - 2017-02-13 10:17:29 --> Model Class Initialized
INFO - 2017-02-13 10:17:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:29 --> Total execution time: 0.1215
INFO - 2017-02-13 10:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:29 --> Controller Class Initialized
INFO - 2017-02-13 10:17:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:29 --> Model Class Initialized
INFO - 2017-02-13 10:17:29 --> Model Class Initialized
INFO - 2017-02-13 10:17:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:29 --> Total execution time: 0.4536
INFO - 2017-02-13 10:17:30 --> Config Class Initialized
INFO - 2017-02-13 10:17:30 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:30 --> Config Class Initialized
INFO - 2017-02-13 10:17:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:30 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:30 --> Router Class Initialized
INFO - 2017-02-13 10:17:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:30 --> URI Class Initialized
INFO - 2017-02-13 10:17:30 --> Output Class Initialized
INFO - 2017-02-13 10:17:30 --> Router Class Initialized
INFO - 2017-02-13 10:17:30 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:30 --> Input Class Initialized
INFO - 2017-02-13 10:17:30 --> Output Class Initialized
INFO - 2017-02-13 10:17:30 --> Language Class Initialized
INFO - 2017-02-13 10:17:30 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:30 --> Loader Class Initialized
INFO - 2017-02-13 10:17:30 --> Input Class Initialized
INFO - 2017-02-13 10:17:30 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:30 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:30 --> Language Class Initialized
INFO - 2017-02-13 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:30 --> Controller Class Initialized
INFO - 2017-02-13 10:17:30 --> Loader Class Initialized
INFO - 2017-02-13 10:17:30 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:30 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:30 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:30 --> Model Class Initialized
INFO - 2017-02-13 10:17:30 --> Model Class Initialized
INFO - 2017-02-13 10:17:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:30 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:30 --> Total execution time: 0.1239
INFO - 2017-02-13 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:30 --> Controller Class Initialized
INFO - 2017-02-13 10:17:30 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:30 --> Model Class Initialized
INFO - 2017-02-13 10:17:30 --> Model Class Initialized
INFO - 2017-02-13 10:17:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:31 --> Total execution time: 0.3740
INFO - 2017-02-13 10:17:31 --> Config Class Initialized
INFO - 2017-02-13 10:17:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:31 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:31 --> URI Class Initialized
INFO - 2017-02-13 10:17:31 --> Router Class Initialized
INFO - 2017-02-13 10:17:31 --> Output Class Initialized
INFO - 2017-02-13 10:17:31 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:31 --> Input Class Initialized
INFO - 2017-02-13 10:17:31 --> Language Class Initialized
INFO - 2017-02-13 10:17:31 --> Loader Class Initialized
INFO - 2017-02-13 10:17:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:31 --> Controller Class Initialized
INFO - 2017-02-13 10:17:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:31 --> Model Class Initialized
INFO - 2017-02-13 10:17:31 --> Model Class Initialized
INFO - 2017-02-13 10:17:31 --> Model Class Initialized
INFO - 2017-02-13 10:17:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:31 --> Total execution time: 0.0918
INFO - 2017-02-13 10:17:32 --> Config Class Initialized
INFO - 2017-02-13 10:17:32 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:32 --> Config Class Initialized
INFO - 2017-02-13 10:17:32 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:32 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:32 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:32 --> URI Class Initialized
INFO - 2017-02-13 10:17:32 --> URI Class Initialized
INFO - 2017-02-13 10:17:32 --> Router Class Initialized
INFO - 2017-02-13 10:17:32 --> Router Class Initialized
INFO - 2017-02-13 10:17:32 --> Output Class Initialized
INFO - 2017-02-13 10:17:32 --> Output Class Initialized
INFO - 2017-02-13 10:17:32 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:32 --> Input Class Initialized
INFO - 2017-02-13 10:17:32 --> Security Class Initialized
INFO - 2017-02-13 10:17:32 --> Language Class Initialized
DEBUG - 2017-02-13 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:32 --> Input Class Initialized
INFO - 2017-02-13 10:17:32 --> Language Class Initialized
INFO - 2017-02-13 10:17:32 --> Loader Class Initialized
INFO - 2017-02-13 10:17:32 --> Loader Class Initialized
INFO - 2017-02-13 10:17:32 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:32 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:32 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:32 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:32 --> Controller Class Initialized
INFO - 2017-02-13 10:17:32 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:32 --> Model Class Initialized
INFO - 2017-02-13 10:17:32 --> Model Class Initialized
INFO - 2017-02-13 10:17:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:32 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:32 --> Total execution time: 0.1107
INFO - 2017-02-13 10:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:32 --> Controller Class Initialized
INFO - 2017-02-13 10:17:32 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:32 --> Model Class Initialized
INFO - 2017-02-13 10:17:32 --> Model Class Initialized
INFO - 2017-02-13 10:17:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:32 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:32 --> Total execution time: 0.3232
INFO - 2017-02-13 10:17:33 --> Config Class Initialized
INFO - 2017-02-13 10:17:33 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:33 --> Config Class Initialized
INFO - 2017-02-13 10:17:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:33 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:33 --> URI Class Initialized
INFO - 2017-02-13 10:17:33 --> URI Class Initialized
INFO - 2017-02-13 10:17:33 --> Router Class Initialized
INFO - 2017-02-13 10:17:33 --> Router Class Initialized
INFO - 2017-02-13 10:17:33 --> Output Class Initialized
INFO - 2017-02-13 10:17:33 --> Output Class Initialized
INFO - 2017-02-13 10:17:33 --> Security Class Initialized
INFO - 2017-02-13 10:17:33 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:33 --> Input Class Initialized
DEBUG - 2017-02-13 10:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:33 --> Input Class Initialized
INFO - 2017-02-13 10:17:33 --> Language Class Initialized
INFO - 2017-02-13 10:17:33 --> Language Class Initialized
INFO - 2017-02-13 10:17:33 --> Loader Class Initialized
INFO - 2017-02-13 10:17:33 --> Loader Class Initialized
INFO - 2017-02-13 10:17:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:33 --> Controller Class Initialized
INFO - 2017-02-13 10:17:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:33 --> Model Class Initialized
INFO - 2017-02-13 10:17:33 --> Model Class Initialized
INFO - 2017-02-13 10:17:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:33 --> Total execution time: 0.1178
INFO - 2017-02-13 10:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:33 --> Controller Class Initialized
INFO - 2017-02-13 10:17:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:33 --> Model Class Initialized
INFO - 2017-02-13 10:17:33 --> Model Class Initialized
INFO - 2017-02-13 10:17:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:34 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:34 --> Total execution time: 0.5546
INFO - 2017-02-13 10:17:35 --> Config Class Initialized
INFO - 2017-02-13 10:17:35 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:35 --> Config Class Initialized
INFO - 2017-02-13 10:17:35 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:35 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:17:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:35 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:35 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:35 --> URI Class Initialized
INFO - 2017-02-13 10:17:35 --> URI Class Initialized
INFO - 2017-02-13 10:17:35 --> Config Class Initialized
INFO - 2017-02-13 10:17:35 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:35 --> Router Class Initialized
INFO - 2017-02-13 10:17:35 --> Router Class Initialized
INFO - 2017-02-13 10:17:35 --> Output Class Initialized
INFO - 2017-02-13 10:17:35 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:35 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:35 --> Security Class Initialized
INFO - 2017-02-13 10:17:35 --> Security Class Initialized
INFO - 2017-02-13 10:17:35 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:35 --> Input Class Initialized
INFO - 2017-02-13 10:17:35 --> Language Class Initialized
INFO - 2017-02-13 10:17:35 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:35 --> Input Class Initialized
INFO - 2017-02-13 10:17:35 --> Language Class Initialized
INFO - 2017-02-13 10:17:35 --> Output Class Initialized
INFO - 2017-02-13 10:17:35 --> Security Class Initialized
INFO - 2017-02-13 10:17:35 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:35 --> Input Class Initialized
INFO - 2017-02-13 10:17:35 --> Language Class Initialized
INFO - 2017-02-13 10:17:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:35 --> Loader Class Initialized
INFO - 2017-02-13 10:17:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:35 --> Loader Class Initialized
INFO - 2017-02-13 10:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:35 --> Controller Class Initialized
INFO - 2017-02-13 10:17:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:35 --> Total execution time: 0.1244
INFO - 2017-02-13 10:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:35 --> Controller Class Initialized
INFO - 2017-02-13 10:17:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:35 --> Total execution time: 0.4521
INFO - 2017-02-13 10:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:35 --> Controller Class Initialized
INFO - 2017-02-13 10:17:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:35 --> Config Class Initialized
INFO - 2017-02-13 10:17:35 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:35 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:35 --> URI Class Initialized
INFO - 2017-02-13 10:17:35 --> Router Class Initialized
INFO - 2017-02-13 10:17:35 --> Output Class Initialized
INFO - 2017-02-13 10:17:35 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:35 --> Input Class Initialized
INFO - 2017-02-13 10:17:35 --> Language Class Initialized
INFO - 2017-02-13 10:17:35 --> Loader Class Initialized
INFO - 2017-02-13 10:17:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:35 --> Controller Class Initialized
INFO - 2017-02-13 10:17:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Model Class Initialized
INFO - 2017-02-13 10:17:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:17:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02.php
INFO - 2017-02-13 10:17:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:17:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:35 --> Total execution time: 0.1362
INFO - 2017-02-13 10:17:38 --> Config Class Initialized
INFO - 2017-02-13 10:17:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:38 --> URI Class Initialized
INFO - 2017-02-13 10:17:38 --> Router Class Initialized
INFO - 2017-02-13 10:17:38 --> Output Class Initialized
INFO - 2017-02-13 10:17:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:38 --> Input Class Initialized
INFO - 2017-02-13 10:17:38 --> Language Class Initialized
INFO - 2017-02-13 10:17:38 --> Loader Class Initialized
INFO - 2017-02-13 10:17:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:38 --> Controller Class Initialized
INFO - 2017-02-13 10:17:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:38 --> Config Class Initialized
INFO - 2017-02-13 10:17:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:38 --> URI Class Initialized
INFO - 2017-02-13 10:17:38 --> Router Class Initialized
INFO - 2017-02-13 10:17:38 --> Output Class Initialized
INFO - 2017-02-13 10:17:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:38 --> Input Class Initialized
INFO - 2017-02-13 10:17:38 --> Language Class Initialized
INFO - 2017-02-13 10:17:38 --> Loader Class Initialized
INFO - 2017-02-13 10:17:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:38 --> Controller Class Initialized
INFO - 2017-02-13 10:17:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:17:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_02_attempt.php
INFO - 2017-02-13 10:17:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:17:38 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:38 --> Total execution time: 0.2310
INFO - 2017-02-13 10:17:38 --> Config Class Initialized
INFO - 2017-02-13 10:17:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:38 --> URI Class Initialized
INFO - 2017-02-13 10:17:38 --> Router Class Initialized
INFO - 2017-02-13 10:17:38 --> Config Class Initialized
INFO - 2017-02-13 10:17:38 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:38 --> Output Class Initialized
INFO - 2017-02-13 10:17:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:38 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:38 --> Input Class Initialized
INFO - 2017-02-13 10:17:38 --> URI Class Initialized
INFO - 2017-02-13 10:17:38 --> Language Class Initialized
INFO - 2017-02-13 10:17:38 --> Router Class Initialized
INFO - 2017-02-13 10:17:38 --> Loader Class Initialized
INFO - 2017-02-13 10:17:38 --> Output Class Initialized
INFO - 2017-02-13 10:17:38 --> Security Class Initialized
INFO - 2017-02-13 10:17:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:38 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:38 --> Input Class Initialized
INFO - 2017-02-13 10:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:38 --> Controller Class Initialized
INFO - 2017-02-13 10:17:38 --> Language Class Initialized
INFO - 2017-02-13 10:17:38 --> Loader Class Initialized
INFO - 2017-02-13 10:17:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:38 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:38 --> Total execution time: 0.1225
INFO - 2017-02-13 10:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:38 --> Controller Class Initialized
INFO - 2017-02-13 10:17:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Model Class Initialized
INFO - 2017-02-13 10:17:38 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:17:38 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:17:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:17:38 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:38 --> Total execution time: 0.3048
INFO - 2017-02-13 10:17:41 --> Config Class Initialized
INFO - 2017-02-13 10:17:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:41 --> Config Class Initialized
INFO - 2017-02-13 10:17:41 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:41 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:41 --> URI Class Initialized
INFO - 2017-02-13 10:17:41 --> Router Class Initialized
INFO - 2017-02-13 10:17:41 --> Router Class Initialized
INFO - 2017-02-13 10:17:41 --> Output Class Initialized
INFO - 2017-02-13 10:17:41 --> Output Class Initialized
INFO - 2017-02-13 10:17:41 --> Security Class Initialized
INFO - 2017-02-13 10:17:41 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:41 --> Input Class Initialized
DEBUG - 2017-02-13 10:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:41 --> Language Class Initialized
INFO - 2017-02-13 10:17:41 --> Input Class Initialized
INFO - 2017-02-13 10:17:41 --> Loader Class Initialized
INFO - 2017-02-13 10:17:41 --> Language Class Initialized
INFO - 2017-02-13 10:17:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:41 --> Loader Class Initialized
INFO - 2017-02-13 10:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:41 --> Controller Class Initialized
INFO - 2017-02-13 10:17:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:41 --> Model Class Initialized
INFO - 2017-02-13 10:17:41 --> Model Class Initialized
INFO - 2017-02-13 10:17:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:41 --> Total execution time: 0.1236
INFO - 2017-02-13 10:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:41 --> Controller Class Initialized
INFO - 2017-02-13 10:17:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:41 --> Model Class Initialized
INFO - 2017-02-13 10:17:41 --> Model Class Initialized
INFO - 2017-02-13 10:17:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:41 --> Total execution time: 0.2685
INFO - 2017-02-13 10:17:42 --> Config Class Initialized
INFO - 2017-02-13 10:17:42 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:42 --> Config Class Initialized
INFO - 2017-02-13 10:17:42 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:42 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:42 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:42 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:42 --> Router Class Initialized
INFO - 2017-02-13 10:17:42 --> URI Class Initialized
INFO - 2017-02-13 10:17:42 --> Output Class Initialized
INFO - 2017-02-13 10:17:42 --> Router Class Initialized
INFO - 2017-02-13 10:17:42 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:42 --> Input Class Initialized
INFO - 2017-02-13 10:17:42 --> Output Class Initialized
INFO - 2017-02-13 10:17:42 --> Language Class Initialized
INFO - 2017-02-13 10:17:42 --> Security Class Initialized
INFO - 2017-02-13 10:17:42 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:42 --> Input Class Initialized
INFO - 2017-02-13 10:17:42 --> Language Class Initialized
INFO - 2017-02-13 10:17:42 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:42 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:42 --> Loader Class Initialized
INFO - 2017-02-13 10:17:42 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:42 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:42 --> Controller Class Initialized
INFO - 2017-02-13 10:17:42 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:42 --> Model Class Initialized
INFO - 2017-02-13 10:17:42 --> Model Class Initialized
INFO - 2017-02-13 10:17:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:42 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:42 --> Total execution time: 0.1489
INFO - 2017-02-13 10:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:42 --> Controller Class Initialized
INFO - 2017-02-13 10:17:42 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:42 --> Model Class Initialized
INFO - 2017-02-13 10:17:42 --> Model Class Initialized
INFO - 2017-02-13 10:17:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:43 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:43 --> Total execution time: 0.3148
INFO - 2017-02-13 10:17:44 --> Config Class Initialized
INFO - 2017-02-13 10:17:44 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:44 --> Config Class Initialized
INFO - 2017-02-13 10:17:44 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:44 --> URI Class Initialized
INFO - 2017-02-13 10:17:44 --> Router Class Initialized
INFO - 2017-02-13 10:17:44 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:44 --> Security Class Initialized
INFO - 2017-02-13 10:17:44 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:44 --> Input Class Initialized
INFO - 2017-02-13 10:17:44 --> Language Class Initialized
INFO - 2017-02-13 10:17:44 --> Router Class Initialized
INFO - 2017-02-13 10:17:44 --> Loader Class Initialized
INFO - 2017-02-13 10:17:44 --> Output Class Initialized
INFO - 2017-02-13 10:17:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:44 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:44 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:44 --> Input Class Initialized
INFO - 2017-02-13 10:17:44 --> Language Class Initialized
INFO - 2017-02-13 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:44 --> Controller Class Initialized
INFO - 2017-02-13 10:17:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:44 --> Loader Class Initialized
INFO - 2017-02-13 10:17:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:44 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:44 --> Model Class Initialized
INFO - 2017-02-13 10:17:44 --> Model Class Initialized
INFO - 2017-02-13 10:17:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:44 --> Total execution time: 0.1093
INFO - 2017-02-13 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:44 --> Controller Class Initialized
INFO - 2017-02-13 10:17:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:44 --> Model Class Initialized
INFO - 2017-02-13 10:17:44 --> Model Class Initialized
INFO - 2017-02-13 10:17:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:44 --> Total execution time: 0.2115
INFO - 2017-02-13 10:17:45 --> Config Class Initialized
INFO - 2017-02-13 10:17:45 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:45 --> Config Class Initialized
INFO - 2017-02-13 10:17:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:45 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:45 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:45 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:45 --> Router Class Initialized
INFO - 2017-02-13 10:17:45 --> URI Class Initialized
INFO - 2017-02-13 10:17:45 --> Output Class Initialized
INFO - 2017-02-13 10:17:45 --> Router Class Initialized
INFO - 2017-02-13 10:17:45 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:45 --> Input Class Initialized
INFO - 2017-02-13 10:17:45 --> Output Class Initialized
INFO - 2017-02-13 10:17:45 --> Language Class Initialized
INFO - 2017-02-13 10:17:45 --> Security Class Initialized
INFO - 2017-02-13 10:17:45 --> Loader Class Initialized
INFO - 2017-02-13 10:17:45 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:45 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:45 --> Input Class Initialized
INFO - 2017-02-13 10:17:45 --> Language Class Initialized
INFO - 2017-02-13 10:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:45 --> Loader Class Initialized
INFO - 2017-02-13 10:17:45 --> Controller Class Initialized
INFO - 2017-02-13 10:17:45 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:45 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:45 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:45 --> Model Class Initialized
INFO - 2017-02-13 10:17:45 --> Model Class Initialized
INFO - 2017-02-13 10:17:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:45 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:45 --> Total execution time: 0.1476
INFO - 2017-02-13 10:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:45 --> Controller Class Initialized
INFO - 2017-02-13 10:17:45 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:45 --> Model Class Initialized
INFO - 2017-02-13 10:17:45 --> Model Class Initialized
INFO - 2017-02-13 10:17:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:45 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:45 --> Total execution time: 0.3568
INFO - 2017-02-13 10:17:46 --> Config Class Initialized
INFO - 2017-02-13 10:17:46 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:46 --> Config Class Initialized
INFO - 2017-02-13 10:17:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:46 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:46 --> Router Class Initialized
INFO - 2017-02-13 10:17:46 --> URI Class Initialized
INFO - 2017-02-13 10:17:46 --> Output Class Initialized
INFO - 2017-02-13 10:17:46 --> Router Class Initialized
INFO - 2017-02-13 10:17:46 --> Security Class Initialized
INFO - 2017-02-13 10:17:46 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:46 --> Input Class Initialized
INFO - 2017-02-13 10:17:46 --> Security Class Initialized
INFO - 2017-02-13 10:17:46 --> Language Class Initialized
DEBUG - 2017-02-13 10:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:46 --> Input Class Initialized
INFO - 2017-02-13 10:17:46 --> Loader Class Initialized
INFO - 2017-02-13 10:17:46 --> Language Class Initialized
INFO - 2017-02-13 10:17:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:46 --> Loader Class Initialized
INFO - 2017-02-13 10:17:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:46 --> Controller Class Initialized
INFO - 2017-02-13 10:17:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:46 --> Model Class Initialized
INFO - 2017-02-13 10:17:46 --> Model Class Initialized
INFO - 2017-02-13 10:17:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:46 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:46 --> Total execution time: 0.1139
INFO - 2017-02-13 10:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:46 --> Controller Class Initialized
INFO - 2017-02-13 10:17:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:46 --> Model Class Initialized
INFO - 2017-02-13 10:17:46 --> Model Class Initialized
INFO - 2017-02-13 10:17:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:47 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:47 --> Total execution time: 0.3050
INFO - 2017-02-13 10:17:48 --> Config Class Initialized
INFO - 2017-02-13 10:17:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:48 --> Config Class Initialized
INFO - 2017-02-13 10:17:48 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:48 --> URI Class Initialized
INFO - 2017-02-13 10:17:48 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:48 --> URI Class Initialized
INFO - 2017-02-13 10:17:48 --> Output Class Initialized
INFO - 2017-02-13 10:17:48 --> Router Class Initialized
INFO - 2017-02-13 10:17:48 --> Output Class Initialized
INFO - 2017-02-13 10:17:48 --> Security Class Initialized
INFO - 2017-02-13 10:17:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:48 --> Input Class Initialized
INFO - 2017-02-13 10:17:48 --> Language Class Initialized
DEBUG - 2017-02-13 10:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:48 --> Input Class Initialized
INFO - 2017-02-13 10:17:48 --> Language Class Initialized
INFO - 2017-02-13 10:17:48 --> Loader Class Initialized
INFO - 2017-02-13 10:17:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:48 --> Loader Class Initialized
INFO - 2017-02-13 10:17:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:48 --> Controller Class Initialized
INFO - 2017-02-13 10:17:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:48 --> Model Class Initialized
INFO - 2017-02-13 10:17:48 --> Model Class Initialized
INFO - 2017-02-13 10:17:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:48 --> Total execution time: 0.1345
INFO - 2017-02-13 10:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:48 --> Controller Class Initialized
INFO - 2017-02-13 10:17:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:48 --> Model Class Initialized
INFO - 2017-02-13 10:17:48 --> Model Class Initialized
INFO - 2017-02-13 10:17:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:48 --> Total execution time: 0.2829
INFO - 2017-02-13 10:17:50 --> Config Class Initialized
INFO - 2017-02-13 10:17:50 --> Config Class Initialized
INFO - 2017-02-13 10:17:50 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:50 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:50 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:17:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:50 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:50 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:50 --> URI Class Initialized
INFO - 2017-02-13 10:17:50 --> Router Class Initialized
INFO - 2017-02-13 10:17:50 --> Output Class Initialized
INFO - 2017-02-13 10:17:50 --> URI Class Initialized
INFO - 2017-02-13 10:17:50 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:50 --> Input Class Initialized
INFO - 2017-02-13 10:17:50 --> Router Class Initialized
INFO - 2017-02-13 10:17:50 --> Language Class Initialized
INFO - 2017-02-13 10:17:50 --> Output Class Initialized
INFO - 2017-02-13 10:17:50 --> Security Class Initialized
INFO - 2017-02-13 10:17:50 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:50 --> Input Class Initialized
INFO - 2017-02-13 10:17:50 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:50 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:50 --> Language Class Initialized
INFO - 2017-02-13 10:17:50 --> Loader Class Initialized
INFO - 2017-02-13 10:17:50 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:50 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:50 --> Controller Class Initialized
INFO - 2017-02-13 10:17:50 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:50 --> Model Class Initialized
INFO - 2017-02-13 10:17:50 --> Model Class Initialized
INFO - 2017-02-13 10:17:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:50 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:50 --> Total execution time: 0.1236
INFO - 2017-02-13 10:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:50 --> Controller Class Initialized
INFO - 2017-02-13 10:17:50 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:50 --> Model Class Initialized
INFO - 2017-02-13 10:17:50 --> Model Class Initialized
INFO - 2017-02-13 10:17:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:51 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:51 --> Total execution time: 0.2489
INFO - 2017-02-13 10:17:52 --> Config Class Initialized
INFO - 2017-02-13 10:17:52 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:52 --> Config Class Initialized
INFO - 2017-02-13 10:17:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:52 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:52 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:52 --> URI Class Initialized
INFO - 2017-02-13 10:17:52 --> URI Class Initialized
INFO - 2017-02-13 10:17:52 --> Router Class Initialized
INFO - 2017-02-13 10:17:52 --> Router Class Initialized
INFO - 2017-02-13 10:17:52 --> Output Class Initialized
INFO - 2017-02-13 10:17:52 --> Output Class Initialized
INFO - 2017-02-13 10:17:52 --> Security Class Initialized
INFO - 2017-02-13 10:17:52 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:52 --> Input Class Initialized
INFO - 2017-02-13 10:17:52 --> Language Class Initialized
INFO - 2017-02-13 10:17:52 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:52 --> Input Class Initialized
INFO - 2017-02-13 10:17:52 --> Language Class Initialized
INFO - 2017-02-13 10:17:52 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:52 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:52 --> Loader Class Initialized
INFO - 2017-02-13 10:17:52 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:52 --> Controller Class Initialized
INFO - 2017-02-13 10:17:52 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:52 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:52 --> Model Class Initialized
INFO - 2017-02-13 10:17:52 --> Model Class Initialized
INFO - 2017-02-13 10:17:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:52 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:52 --> Total execution time: 0.1158
INFO - 2017-02-13 10:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:52 --> Controller Class Initialized
INFO - 2017-02-13 10:17:52 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:52 --> Model Class Initialized
INFO - 2017-02-13 10:17:52 --> Model Class Initialized
INFO - 2017-02-13 10:17:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:52 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:52 --> Total execution time: 0.4538
INFO - 2017-02-13 10:17:53 --> Config Class Initialized
INFO - 2017-02-13 10:17:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:53 --> Config Class Initialized
INFO - 2017-02-13 10:17:53 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:53 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:53 --> URI Class Initialized
INFO - 2017-02-13 10:17:53 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:53 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:53 --> Output Class Initialized
INFO - 2017-02-13 10:17:53 --> URI Class Initialized
INFO - 2017-02-13 10:17:53 --> Security Class Initialized
INFO - 2017-02-13 10:17:53 --> Router Class Initialized
DEBUG - 2017-02-13 10:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:53 --> Input Class Initialized
INFO - 2017-02-13 10:17:53 --> Language Class Initialized
INFO - 2017-02-13 10:17:53 --> Output Class Initialized
INFO - 2017-02-13 10:17:53 --> Security Class Initialized
INFO - 2017-02-13 10:17:53 --> Loader Class Initialized
DEBUG - 2017-02-13 10:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:53 --> Input Class Initialized
INFO - 2017-02-13 10:17:53 --> Language Class Initialized
INFO - 2017-02-13 10:17:53 --> Loader Class Initialized
INFO - 2017-02-13 10:17:53 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:53 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:53 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:53 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:53 --> Controller Class Initialized
INFO - 2017-02-13 10:17:53 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:53 --> Model Class Initialized
INFO - 2017-02-13 10:17:53 --> Model Class Initialized
INFO - 2017-02-13 10:17:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:53 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:53 --> Total execution time: 0.1224
INFO - 2017-02-13 10:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:53 --> Controller Class Initialized
INFO - 2017-02-13 10:17:53 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:53 --> Model Class Initialized
INFO - 2017-02-13 10:17:53 --> Model Class Initialized
INFO - 2017-02-13 10:17:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:53 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:53 --> Total execution time: 0.2726
INFO - 2017-02-13 10:17:55 --> Config Class Initialized
INFO - 2017-02-13 10:17:55 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:55 --> Config Class Initialized
INFO - 2017-02-13 10:17:55 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:55 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:55 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:55 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:55 --> Router Class Initialized
INFO - 2017-02-13 10:17:55 --> URI Class Initialized
INFO - 2017-02-13 10:17:55 --> Output Class Initialized
INFO - 2017-02-13 10:17:55 --> Router Class Initialized
INFO - 2017-02-13 10:17:55 --> Security Class Initialized
INFO - 2017-02-13 10:17:55 --> Output Class Initialized
INFO - 2017-02-13 10:17:55 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 10:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:55 --> Input Class Initialized
INFO - 2017-02-13 10:17:55 --> Input Class Initialized
INFO - 2017-02-13 10:17:55 --> Language Class Initialized
INFO - 2017-02-13 10:17:55 --> Language Class Initialized
INFO - 2017-02-13 10:17:55 --> Loader Class Initialized
INFO - 2017-02-13 10:17:55 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:55 --> Loader Class Initialized
INFO - 2017-02-13 10:17:55 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:55 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:55 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:55 --> Controller Class Initialized
INFO - 2017-02-13 10:17:55 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:55 --> Model Class Initialized
INFO - 2017-02-13 10:17:55 --> Model Class Initialized
INFO - 2017-02-13 10:17:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:55 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:55 --> Total execution time: 0.1324
INFO - 2017-02-13 10:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:55 --> Controller Class Initialized
INFO - 2017-02-13 10:17:55 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:55 --> Model Class Initialized
INFO - 2017-02-13 10:17:55 --> Model Class Initialized
INFO - 2017-02-13 10:17:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:55 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:55 --> Total execution time: 0.3525
INFO - 2017-02-13 10:17:56 --> Config Class Initialized
INFO - 2017-02-13 10:17:56 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:56 --> Config Class Initialized
INFO - 2017-02-13 10:17:56 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:56 --> URI Class Initialized
INFO - 2017-02-13 10:17:56 --> Router Class Initialized
INFO - 2017-02-13 10:17:56 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:56 --> Security Class Initialized
INFO - 2017-02-13 10:17:56 --> URI Class Initialized
INFO - 2017-02-13 10:17:56 --> Router Class Initialized
INFO - 2017-02-13 10:17:56 --> Output Class Initialized
INFO - 2017-02-13 10:17:56 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 10:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:56 --> Input Class Initialized
INFO - 2017-02-13 10:17:56 --> Input Class Initialized
INFO - 2017-02-13 10:17:56 --> Language Class Initialized
INFO - 2017-02-13 10:17:56 --> Loader Class Initialized
INFO - 2017-02-13 10:17:56 --> Language Class Initialized
INFO - 2017-02-13 10:17:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:56 --> Loader Class Initialized
INFO - 2017-02-13 10:17:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:56 --> Controller Class Initialized
INFO - 2017-02-13 10:17:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:56 --> Model Class Initialized
INFO - 2017-02-13 10:17:56 --> Model Class Initialized
INFO - 2017-02-13 10:17:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:57 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:57 --> Total execution time: 0.3843
INFO - 2017-02-13 10:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:57 --> Controller Class Initialized
INFO - 2017-02-13 10:17:57 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:57 --> Model Class Initialized
INFO - 2017-02-13 10:17:57 --> Model Class Initialized
INFO - 2017-02-13 10:17:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:57 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:57 --> Total execution time: 0.4616
INFO - 2017-02-13 10:17:58 --> Config Class Initialized
INFO - 2017-02-13 10:17:58 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:58 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:58 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:58 --> URI Class Initialized
INFO - 2017-02-13 10:17:58 --> Config Class Initialized
INFO - 2017-02-13 10:17:58 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:58 --> Router Class Initialized
INFO - 2017-02-13 10:17:58 --> Output Class Initialized
DEBUG - 2017-02-13 10:17:58 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:58 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:58 --> Security Class Initialized
INFO - 2017-02-13 10:17:58 --> URI Class Initialized
DEBUG - 2017-02-13 10:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:58 --> Input Class Initialized
INFO - 2017-02-13 10:17:58 --> Router Class Initialized
INFO - 2017-02-13 10:17:58 --> Language Class Initialized
INFO - 2017-02-13 10:17:58 --> Output Class Initialized
INFO - 2017-02-13 10:17:58 --> Loader Class Initialized
INFO - 2017-02-13 10:17:58 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:58 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:58 --> Security Class Initialized
INFO - 2017-02-13 10:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:58 --> Controller Class Initialized
DEBUG - 2017-02-13 10:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:58 --> Input Class Initialized
INFO - 2017-02-13 10:17:58 --> Language Class Initialized
INFO - 2017-02-13 10:17:58 --> Loader Class Initialized
INFO - 2017-02-13 10:17:58 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:58 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:58 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:58 --> Model Class Initialized
INFO - 2017-02-13 10:17:58 --> Model Class Initialized
INFO - 2017-02-13 10:17:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:58 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:58 --> Total execution time: 0.1276
INFO - 2017-02-13 10:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:58 --> Controller Class Initialized
INFO - 2017-02-13 10:17:58 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:58 --> Model Class Initialized
INFO - 2017-02-13 10:17:58 --> Model Class Initialized
INFO - 2017-02-13 10:17:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:58 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:58 --> Total execution time: 0.4610
INFO - 2017-02-13 10:17:59 --> Config Class Initialized
INFO - 2017-02-13 10:17:59 --> Hooks Class Initialized
INFO - 2017-02-13 10:17:59 --> Config Class Initialized
INFO - 2017-02-13 10:17:59 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:17:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:59 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:17:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:17:59 --> Utf8 Class Initialized
INFO - 2017-02-13 10:17:59 --> URI Class Initialized
INFO - 2017-02-13 10:17:59 --> URI Class Initialized
INFO - 2017-02-13 10:17:59 --> Router Class Initialized
INFO - 2017-02-13 10:17:59 --> Router Class Initialized
INFO - 2017-02-13 10:17:59 --> Output Class Initialized
INFO - 2017-02-13 10:17:59 --> Output Class Initialized
INFO - 2017-02-13 10:17:59 --> Security Class Initialized
INFO - 2017-02-13 10:17:59 --> Security Class Initialized
DEBUG - 2017-02-13 10:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:59 --> Input Class Initialized
INFO - 2017-02-13 10:17:59 --> Language Class Initialized
DEBUG - 2017-02-13 10:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:17:59 --> Input Class Initialized
INFO - 2017-02-13 10:17:59 --> Language Class Initialized
INFO - 2017-02-13 10:17:59 --> Loader Class Initialized
INFO - 2017-02-13 10:17:59 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:59 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:59 --> Loader Class Initialized
INFO - 2017-02-13 10:17:59 --> Helper loaded: url_helper
INFO - 2017-02-13 10:17:59 --> Helper loaded: language_helper
INFO - 2017-02-13 10:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:59 --> Controller Class Initialized
INFO - 2017-02-13 10:17:59 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:59 --> Model Class Initialized
INFO - 2017-02-13 10:17:59 --> Model Class Initialized
INFO - 2017-02-13 10:17:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:17:59 --> Final output sent to browser
DEBUG - 2017-02-13 10:17:59 --> Total execution time: 0.1147
INFO - 2017-02-13 10:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:17:59 --> Controller Class Initialized
INFO - 2017-02-13 10:17:59 --> Database Driver Class Initialized
INFO - 2017-02-13 10:17:59 --> Model Class Initialized
INFO - 2017-02-13 10:17:59 --> Model Class Initialized
INFO - 2017-02-13 10:17:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:00 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:00 --> Total execution time: 0.5736
INFO - 2017-02-13 10:18:01 --> Config Class Initialized
INFO - 2017-02-13 10:18:01 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:01 --> Config Class Initialized
INFO - 2017-02-13 10:18:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:01 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:01 --> URI Class Initialized
INFO - 2017-02-13 10:18:01 --> Router Class Initialized
INFO - 2017-02-13 10:18:01 --> Output Class Initialized
INFO - 2017-02-13 10:18:01 --> Router Class Initialized
INFO - 2017-02-13 10:18:01 --> Security Class Initialized
INFO - 2017-02-13 10:18:01 --> Output Class Initialized
INFO - 2017-02-13 10:18:01 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:01 --> Input Class Initialized
INFO - 2017-02-13 10:18:01 --> Language Class Initialized
INFO - 2017-02-13 10:18:01 --> Loader Class Initialized
INFO - 2017-02-13 10:18:01 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:01 --> Input Class Initialized
INFO - 2017-02-13 10:18:01 --> Language Class Initialized
INFO - 2017-02-13 10:18:01 --> Loader Class Initialized
INFO - 2017-02-13 10:18:01 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:01 --> Controller Class Initialized
INFO - 2017-02-13 10:18:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:01 --> Model Class Initialized
INFO - 2017-02-13 10:18:01 --> Model Class Initialized
INFO - 2017-02-13 10:18:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:01 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:01 --> Total execution time: 0.2020
INFO - 2017-02-13 10:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:01 --> Controller Class Initialized
INFO - 2017-02-13 10:18:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:01 --> Model Class Initialized
INFO - 2017-02-13 10:18:01 --> Model Class Initialized
INFO - 2017-02-13 10:18:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:01 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:01 --> Total execution time: 0.3657
INFO - 2017-02-13 10:18:02 --> Config Class Initialized
INFO - 2017-02-13 10:18:02 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:02 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:02 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:02 --> URI Class Initialized
INFO - 2017-02-13 10:18:02 --> Config Class Initialized
INFO - 2017-02-13 10:18:02 --> Router Class Initialized
INFO - 2017-02-13 10:18:02 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:02 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:02 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:02 --> Security Class Initialized
INFO - 2017-02-13 10:18:02 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:02 --> URI Class Initialized
INFO - 2017-02-13 10:18:02 --> Input Class Initialized
INFO - 2017-02-13 10:18:02 --> Language Class Initialized
INFO - 2017-02-13 10:18:02 --> Router Class Initialized
INFO - 2017-02-13 10:18:02 --> Output Class Initialized
INFO - 2017-02-13 10:18:02 --> Loader Class Initialized
INFO - 2017-02-13 10:18:02 --> Security Class Initialized
INFO - 2017-02-13 10:18:02 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:02 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:02 --> Input Class Initialized
INFO - 2017-02-13 10:18:02 --> Language Class Initialized
INFO - 2017-02-13 10:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:02 --> Controller Class Initialized
INFO - 2017-02-13 10:18:02 --> Loader Class Initialized
INFO - 2017-02-13 10:18:02 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:02 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:02 --> Model Class Initialized
INFO - 2017-02-13 10:18:02 --> Model Class Initialized
INFO - 2017-02-13 10:18:02 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:02 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:02 --> Total execution time: 0.1174
INFO - 2017-02-13 10:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:02 --> Controller Class Initialized
INFO - 2017-02-13 10:18:02 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:02 --> Model Class Initialized
INFO - 2017-02-13 10:18:02 --> Model Class Initialized
INFO - 2017-02-13 10:18:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:03 --> Total execution time: 0.3962
INFO - 2017-02-13 10:18:04 --> Config Class Initialized
INFO - 2017-02-13 10:18:04 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:04 --> Config Class Initialized
INFO - 2017-02-13 10:18:04 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:04 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:04 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:04 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:04 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:04 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:04 --> URI Class Initialized
INFO - 2017-02-13 10:18:04 --> Router Class Initialized
INFO - 2017-02-13 10:18:04 --> Router Class Initialized
INFO - 2017-02-13 10:18:04 --> Output Class Initialized
INFO - 2017-02-13 10:18:04 --> Security Class Initialized
INFO - 2017-02-13 10:18:04 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:04 --> Input Class Initialized
INFO - 2017-02-13 10:18:04 --> Security Class Initialized
INFO - 2017-02-13 10:18:04 --> Language Class Initialized
INFO - 2017-02-13 10:18:04 --> Loader Class Initialized
DEBUG - 2017-02-13 10:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:04 --> Input Class Initialized
INFO - 2017-02-13 10:18:04 --> Language Class Initialized
INFO - 2017-02-13 10:18:04 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:04 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:04 --> Loader Class Initialized
INFO - 2017-02-13 10:18:04 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:04 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:04 --> Controller Class Initialized
INFO - 2017-02-13 10:18:04 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:04 --> Model Class Initialized
INFO - 2017-02-13 10:18:04 --> Model Class Initialized
INFO - 2017-02-13 10:18:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:04 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:04 --> Total execution time: 0.1961
INFO - 2017-02-13 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:04 --> Controller Class Initialized
INFO - 2017-02-13 10:18:05 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:05 --> Model Class Initialized
INFO - 2017-02-13 10:18:05 --> Model Class Initialized
INFO - 2017-02-13 10:18:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:05 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:05 --> Total execution time: 0.5332
INFO - 2017-02-13 10:18:06 --> Config Class Initialized
INFO - 2017-02-13 10:18:06 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:06 --> Config Class Initialized
INFO - 2017-02-13 10:18:06 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:06 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:06 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:06 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:06 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:06 --> Router Class Initialized
INFO - 2017-02-13 10:18:06 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:06 --> URI Class Initialized
INFO - 2017-02-13 10:18:06 --> Output Class Initialized
INFO - 2017-02-13 10:18:06 --> Security Class Initialized
INFO - 2017-02-13 10:18:06 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:06 --> Input Class Initialized
INFO - 2017-02-13 10:18:06 --> Output Class Initialized
INFO - 2017-02-13 10:18:06 --> Language Class Initialized
INFO - 2017-02-13 10:18:06 --> Security Class Initialized
INFO - 2017-02-13 10:18:06 --> Loader Class Initialized
INFO - 2017-02-13 10:18:06 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:06 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:06 --> Input Class Initialized
INFO - 2017-02-13 10:18:06 --> Language Class Initialized
INFO - 2017-02-13 10:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:06 --> Controller Class Initialized
INFO - 2017-02-13 10:18:06 --> Loader Class Initialized
INFO - 2017-02-13 10:18:06 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:06 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:06 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:06 --> Model Class Initialized
INFO - 2017-02-13 10:18:06 --> Model Class Initialized
INFO - 2017-02-13 10:18:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:06 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:06 --> Total execution time: 0.1316
INFO - 2017-02-13 10:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:06 --> Controller Class Initialized
INFO - 2017-02-13 10:18:06 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:06 --> Model Class Initialized
INFO - 2017-02-13 10:18:06 --> Model Class Initialized
INFO - 2017-02-13 10:18:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:06 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:06 --> Total execution time: 0.3407
INFO - 2017-02-13 10:18:07 --> Config Class Initialized
INFO - 2017-02-13 10:18:07 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:07 --> Config Class Initialized
DEBUG - 2017-02-13 10:18:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:07 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:07 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:07 --> Router Class Initialized
INFO - 2017-02-13 10:18:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:07 --> URI Class Initialized
INFO - 2017-02-13 10:18:07 --> Router Class Initialized
INFO - 2017-02-13 10:18:07 --> Output Class Initialized
INFO - 2017-02-13 10:18:07 --> Output Class Initialized
INFO - 2017-02-13 10:18:07 --> Security Class Initialized
INFO - 2017-02-13 10:18:07 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:07 --> Input Class Initialized
INFO - 2017-02-13 10:18:07 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:07 --> Input Class Initialized
INFO - 2017-02-13 10:18:07 --> Loader Class Initialized
INFO - 2017-02-13 10:18:07 --> Language Class Initialized
INFO - 2017-02-13 10:18:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:07 --> Loader Class Initialized
INFO - 2017-02-13 10:18:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:07 --> Controller Class Initialized
INFO - 2017-02-13 10:18:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:07 --> Model Class Initialized
INFO - 2017-02-13 10:18:07 --> Model Class Initialized
INFO - 2017-02-13 10:18:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:07 --> Total execution time: 0.1141
INFO - 2017-02-13 10:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:07 --> Controller Class Initialized
INFO - 2017-02-13 10:18:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:07 --> Model Class Initialized
INFO - 2017-02-13 10:18:07 --> Model Class Initialized
INFO - 2017-02-13 10:18:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:08 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:08 --> Total execution time: 0.4444
INFO - 2017-02-13 10:18:08 --> Config Class Initialized
INFO - 2017-02-13 10:18:08 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:08 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:08 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:08 --> URI Class Initialized
INFO - 2017-02-13 10:18:08 --> Router Class Initialized
INFO - 2017-02-13 10:18:08 --> Output Class Initialized
INFO - 2017-02-13 10:18:08 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:08 --> Input Class Initialized
INFO - 2017-02-13 10:18:08 --> Language Class Initialized
INFO - 2017-02-13 10:18:08 --> Loader Class Initialized
INFO - 2017-02-13 10:18:08 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:08 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:08 --> Controller Class Initialized
INFO - 2017-02-13 10:18:08 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:08 --> Model Class Initialized
INFO - 2017-02-13 10:18:08 --> Model Class Initialized
INFO - 2017-02-13 10:18:08 --> Model Class Initialized
INFO - 2017-02-13 10:18:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:08 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:08 --> Total execution time: 0.0938
INFO - 2017-02-13 10:18:09 --> Config Class Initialized
INFO - 2017-02-13 10:18:09 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:09 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:09 --> URI Class Initialized
INFO - 2017-02-13 10:18:09 --> Config Class Initialized
INFO - 2017-02-13 10:18:09 --> Router Class Initialized
INFO - 2017-02-13 10:18:09 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:09 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:09 --> Security Class Initialized
INFO - 2017-02-13 10:18:09 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:09 --> URI Class Initialized
INFO - 2017-02-13 10:18:09 --> Input Class Initialized
INFO - 2017-02-13 10:18:09 --> Language Class Initialized
INFO - 2017-02-13 10:18:09 --> Router Class Initialized
INFO - 2017-02-13 10:18:09 --> Output Class Initialized
INFO - 2017-02-13 10:18:09 --> Loader Class Initialized
INFO - 2017-02-13 10:18:09 --> Security Class Initialized
INFO - 2017-02-13 10:18:09 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:09 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:09 --> Controller Class Initialized
DEBUG - 2017-02-13 10:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:09 --> Input Class Initialized
INFO - 2017-02-13 10:18:09 --> Language Class Initialized
INFO - 2017-02-13 10:18:09 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:09 --> Loader Class Initialized
INFO - 2017-02-13 10:18:09 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:09 --> Model Class Initialized
INFO - 2017-02-13 10:18:09 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:09 --> Model Class Initialized
INFO - 2017-02-13 10:18:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:09 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:09 --> Total execution time: 0.1172
INFO - 2017-02-13 10:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:09 --> Controller Class Initialized
INFO - 2017-02-13 10:18:09 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:09 --> Model Class Initialized
INFO - 2017-02-13 10:18:09 --> Model Class Initialized
INFO - 2017-02-13 10:18:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:09 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:09 --> Total execution time: 0.3745
INFO - 2017-02-13 10:18:11 --> Config Class Initialized
INFO - 2017-02-13 10:18:11 --> Config Class Initialized
INFO - 2017-02-13 10:18:11 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:11 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:11 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:11 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:11 --> URI Class Initialized
INFO - 2017-02-13 10:18:11 --> Config Class Initialized
INFO - 2017-02-13 10:18:11 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:11 --> URI Class Initialized
INFO - 2017-02-13 10:18:11 --> Router Class Initialized
INFO - 2017-02-13 10:18:11 --> Router Class Initialized
INFO - 2017-02-13 10:18:11 --> Output Class Initialized
INFO - 2017-02-13 10:18:11 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:11 --> Security Class Initialized
INFO - 2017-02-13 10:18:11 --> Security Class Initialized
INFO - 2017-02-13 10:18:11 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:11 --> Input Class Initialized
INFO - 2017-02-13 10:18:11 --> URI Class Initialized
INFO - 2017-02-13 10:18:11 --> Language Class Initialized
INFO - 2017-02-13 10:18:11 --> Router Class Initialized
INFO - 2017-02-13 10:18:11 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:11 --> Input Class Initialized
INFO - 2017-02-13 10:18:11 --> Security Class Initialized
INFO - 2017-02-13 10:18:11 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:11 --> Loader Class Initialized
INFO - 2017-02-13 10:18:11 --> Input Class Initialized
INFO - 2017-02-13 10:18:11 --> Language Class Initialized
INFO - 2017-02-13 10:18:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:11 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:11 --> Loader Class Initialized
INFO - 2017-02-13 10:18:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:11 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:11 --> Controller Class Initialized
INFO - 2017-02-13 10:18:11 --> Loader Class Initialized
INFO - 2017-02-13 10:18:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:11 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:11 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:11 --> Total execution time: 0.1446
INFO - 2017-02-13 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:11 --> Controller Class Initialized
INFO - 2017-02-13 10:18:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:11 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:11 --> Total execution time: 0.4882
INFO - 2017-02-13 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:11 --> Controller Class Initialized
INFO - 2017-02-13 10:18:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:11 --> Config Class Initialized
INFO - 2017-02-13 10:18:11 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:11 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:11 --> URI Class Initialized
INFO - 2017-02-13 10:18:11 --> Router Class Initialized
INFO - 2017-02-13 10:18:11 --> Output Class Initialized
INFO - 2017-02-13 10:18:11 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:11 --> Input Class Initialized
INFO - 2017-02-13 10:18:11 --> Language Class Initialized
INFO - 2017-02-13 10:18:11 --> Loader Class Initialized
INFO - 2017-02-13 10:18:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:11 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:11 --> Controller Class Initialized
INFO - 2017-02-13 10:18:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Model Class Initialized
INFO - 2017-02-13 10:18:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03.php
INFO - 2017-02-13 10:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:18:11 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:11 --> Total execution time: 0.1329
INFO - 2017-02-13 10:18:13 --> Config Class Initialized
INFO - 2017-02-13 10:18:13 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:13 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:13 --> URI Class Initialized
INFO - 2017-02-13 10:18:13 --> Router Class Initialized
INFO - 2017-02-13 10:18:13 --> Output Class Initialized
INFO - 2017-02-13 10:18:14 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:14 --> Input Class Initialized
INFO - 2017-02-13 10:18:14 --> Language Class Initialized
INFO - 2017-02-13 10:18:14 --> Loader Class Initialized
INFO - 2017-02-13 10:18:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:14 --> Controller Class Initialized
INFO - 2017-02-13 10:18:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:14 --> Config Class Initialized
INFO - 2017-02-13 10:18:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:14 --> URI Class Initialized
INFO - 2017-02-13 10:18:14 --> Router Class Initialized
INFO - 2017-02-13 10:18:14 --> Output Class Initialized
INFO - 2017-02-13 10:18:14 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:14 --> Input Class Initialized
INFO - 2017-02-13 10:18:14 --> Language Class Initialized
INFO - 2017-02-13 10:18:14 --> Loader Class Initialized
INFO - 2017-02-13 10:18:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:14 --> Controller Class Initialized
INFO - 2017-02-13 10:18:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_03_attempt.php
INFO - 2017-02-13 10:18:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:18:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:14 --> Total execution time: 0.2285
INFO - 2017-02-13 10:18:14 --> Config Class Initialized
INFO - 2017-02-13 10:18:14 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:14 --> Config Class Initialized
INFO - 2017-02-13 10:18:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:14 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:14 --> Router Class Initialized
INFO - 2017-02-13 10:18:14 --> URI Class Initialized
INFO - 2017-02-13 10:18:14 --> Output Class Initialized
INFO - 2017-02-13 10:18:14 --> Security Class Initialized
INFO - 2017-02-13 10:18:14 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:14 --> Input Class Initialized
INFO - 2017-02-13 10:18:14 --> Output Class Initialized
INFO - 2017-02-13 10:18:14 --> Security Class Initialized
INFO - 2017-02-13 10:18:14 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:14 --> Input Class Initialized
INFO - 2017-02-13 10:18:14 --> Loader Class Initialized
INFO - 2017-02-13 10:18:14 --> Language Class Initialized
INFO - 2017-02-13 10:18:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:14 --> Loader Class Initialized
INFO - 2017-02-13 10:18:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:14 --> Controller Class Initialized
INFO - 2017-02-13 10:18:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:18:14 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:18:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:18:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:14 --> Total execution time: 0.2257
INFO - 2017-02-13 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:14 --> Controller Class Initialized
INFO - 2017-02-13 10:18:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Model Class Initialized
INFO - 2017-02-13 10:18:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:14 --> Total execution time: 0.2806
INFO - 2017-02-13 10:18:17 --> Config Class Initialized
INFO - 2017-02-13 10:18:17 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:17 --> Config Class Initialized
DEBUG - 2017-02-13 10:18:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:17 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:17 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:17 --> Router Class Initialized
INFO - 2017-02-13 10:18:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:17 --> Output Class Initialized
INFO - 2017-02-13 10:18:17 --> URI Class Initialized
INFO - 2017-02-13 10:18:17 --> Security Class Initialized
INFO - 2017-02-13 10:18:17 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:17 --> Input Class Initialized
INFO - 2017-02-13 10:18:17 --> Language Class Initialized
INFO - 2017-02-13 10:18:17 --> Output Class Initialized
INFO - 2017-02-13 10:18:17 --> Loader Class Initialized
INFO - 2017-02-13 10:18:17 --> Security Class Initialized
INFO - 2017-02-13 10:18:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:17 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:17 --> Input Class Initialized
INFO - 2017-02-13 10:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:17 --> Language Class Initialized
INFO - 2017-02-13 10:18:17 --> Controller Class Initialized
INFO - 2017-02-13 10:18:17 --> Loader Class Initialized
INFO - 2017-02-13 10:18:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:17 --> Model Class Initialized
INFO - 2017-02-13 10:18:17 --> Model Class Initialized
INFO - 2017-02-13 10:18:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:17 --> Total execution time: 0.1056
INFO - 2017-02-13 10:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:17 --> Controller Class Initialized
INFO - 2017-02-13 10:18:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:17 --> Model Class Initialized
INFO - 2017-02-13 10:18:17 --> Model Class Initialized
INFO - 2017-02-13 10:18:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:17 --> Total execution time: 0.2109
INFO - 2017-02-13 10:18:18 --> Config Class Initialized
INFO - 2017-02-13 10:18:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:18 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:18 --> Config Class Initialized
INFO - 2017-02-13 10:18:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:18 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:18 --> URI Class Initialized
INFO - 2017-02-13 10:18:18 --> URI Class Initialized
INFO - 2017-02-13 10:18:18 --> Router Class Initialized
INFO - 2017-02-13 10:18:18 --> Router Class Initialized
INFO - 2017-02-13 10:18:18 --> Output Class Initialized
INFO - 2017-02-13 10:18:19 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:19 --> Output Class Initialized
INFO - 2017-02-13 10:18:19 --> Input Class Initialized
INFO - 2017-02-13 10:18:19 --> Language Class Initialized
INFO - 2017-02-13 10:18:19 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:19 --> Input Class Initialized
INFO - 2017-02-13 10:18:19 --> Language Class Initialized
INFO - 2017-02-13 10:18:19 --> Loader Class Initialized
INFO - 2017-02-13 10:18:19 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:19 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:19 --> Loader Class Initialized
INFO - 2017-02-13 10:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:19 --> Controller Class Initialized
INFO - 2017-02-13 10:18:19 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:19 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:19 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:19 --> Model Class Initialized
INFO - 2017-02-13 10:18:19 --> Model Class Initialized
INFO - 2017-02-13 10:18:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:19 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:19 --> Total execution time: 0.1251
INFO - 2017-02-13 10:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:19 --> Controller Class Initialized
INFO - 2017-02-13 10:18:19 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:19 --> Model Class Initialized
INFO - 2017-02-13 10:18:19 --> Model Class Initialized
INFO - 2017-02-13 10:18:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:19 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:19 --> Total execution time: 0.3211
INFO - 2017-02-13 10:18:20 --> Config Class Initialized
INFO - 2017-02-13 10:18:20 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:20 --> Config Class Initialized
INFO - 2017-02-13 10:18:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:20 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:20 --> URI Class Initialized
INFO - 2017-02-13 10:18:20 --> Router Class Initialized
INFO - 2017-02-13 10:18:20 --> URI Class Initialized
INFO - 2017-02-13 10:18:20 --> Output Class Initialized
INFO - 2017-02-13 10:18:20 --> Router Class Initialized
INFO - 2017-02-13 10:18:20 --> Security Class Initialized
INFO - 2017-02-13 10:18:20 --> Output Class Initialized
INFO - 2017-02-13 10:18:20 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:20 --> Input Class Initialized
DEBUG - 2017-02-13 10:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:20 --> Input Class Initialized
INFO - 2017-02-13 10:18:20 --> Language Class Initialized
INFO - 2017-02-13 10:18:20 --> Language Class Initialized
INFO - 2017-02-13 10:18:20 --> Loader Class Initialized
INFO - 2017-02-13 10:18:20 --> Loader Class Initialized
INFO - 2017-02-13 10:18:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:20 --> Controller Class Initialized
INFO - 2017-02-13 10:18:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:20 --> Model Class Initialized
INFO - 2017-02-13 10:18:20 --> Model Class Initialized
INFO - 2017-02-13 10:18:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:21 --> Total execution time: 0.2455
INFO - 2017-02-13 10:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:21 --> Controller Class Initialized
INFO - 2017-02-13 10:18:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:21 --> Model Class Initialized
INFO - 2017-02-13 10:18:21 --> Model Class Initialized
INFO - 2017-02-13 10:18:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:21 --> Total execution time: 0.2982
INFO - 2017-02-13 10:18:22 --> Config Class Initialized
INFO - 2017-02-13 10:18:22 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:22 --> Config Class Initialized
DEBUG - 2017-02-13 10:18:22 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:22 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:22 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:22 --> URI Class Initialized
INFO - 2017-02-13 10:18:22 --> Router Class Initialized
INFO - 2017-02-13 10:18:22 --> Output Class Initialized
INFO - 2017-02-13 10:18:22 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:22 --> Input Class Initialized
DEBUG - 2017-02-13 10:18:22 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:22 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:22 --> URI Class Initialized
INFO - 2017-02-13 10:18:22 --> Language Class Initialized
INFO - 2017-02-13 10:18:22 --> Router Class Initialized
INFO - 2017-02-13 10:18:22 --> Loader Class Initialized
INFO - 2017-02-13 10:18:22 --> Output Class Initialized
INFO - 2017-02-13 10:18:22 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:22 --> Security Class Initialized
INFO - 2017-02-13 10:18:22 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:22 --> Input Class Initialized
INFO - 2017-02-13 10:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:22 --> Controller Class Initialized
INFO - 2017-02-13 10:18:22 --> Language Class Initialized
INFO - 2017-02-13 10:18:22 --> Loader Class Initialized
INFO - 2017-02-13 10:18:22 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:22 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:22 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:22 --> Model Class Initialized
INFO - 2017-02-13 10:18:22 --> Model Class Initialized
INFO - 2017-02-13 10:18:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:22 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:22 --> Total execution time: 0.1107
INFO - 2017-02-13 10:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:22 --> Controller Class Initialized
INFO - 2017-02-13 10:18:22 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:22 --> Model Class Initialized
INFO - 2017-02-13 10:18:22 --> Model Class Initialized
INFO - 2017-02-13 10:18:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:22 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:22 --> Total execution time: 0.2964
INFO - 2017-02-13 10:18:23 --> Config Class Initialized
INFO - 2017-02-13 10:18:23 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:23 --> Config Class Initialized
INFO - 2017-02-13 10:18:23 --> URI Class Initialized
INFO - 2017-02-13 10:18:23 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:23 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:23 --> Output Class Initialized
INFO - 2017-02-13 10:18:23 --> URI Class Initialized
INFO - 2017-02-13 10:18:23 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:23 --> Input Class Initialized
INFO - 2017-02-13 10:18:23 --> Router Class Initialized
INFO - 2017-02-13 10:18:23 --> Language Class Initialized
INFO - 2017-02-13 10:18:23 --> Output Class Initialized
INFO - 2017-02-13 10:18:23 --> Loader Class Initialized
INFO - 2017-02-13 10:18:23 --> Security Class Initialized
INFO - 2017-02-13 10:18:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:23 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:23 --> Input Class Initialized
INFO - 2017-02-13 10:18:23 --> Language Class Initialized
INFO - 2017-02-13 10:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:23 --> Controller Class Initialized
INFO - 2017-02-13 10:18:23 --> Loader Class Initialized
INFO - 2017-02-13 10:18:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:23 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:23 --> Model Class Initialized
INFO - 2017-02-13 10:18:23 --> Model Class Initialized
INFO - 2017-02-13 10:18:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:23 --> Total execution time: 0.1180
INFO - 2017-02-13 10:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:23 --> Controller Class Initialized
INFO - 2017-02-13 10:18:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:23 --> Model Class Initialized
INFO - 2017-02-13 10:18:23 --> Model Class Initialized
INFO - 2017-02-13 10:18:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:24 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:24 --> Total execution time: 0.2835
INFO - 2017-02-13 10:18:25 --> Config Class Initialized
INFO - 2017-02-13 10:18:25 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:25 --> Config Class Initialized
INFO - 2017-02-13 10:18:25 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:25 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:25 --> URI Class Initialized
INFO - 2017-02-13 10:18:25 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:25 --> Router Class Initialized
INFO - 2017-02-13 10:18:25 --> URI Class Initialized
INFO - 2017-02-13 10:18:25 --> Output Class Initialized
INFO - 2017-02-13 10:18:25 --> Router Class Initialized
INFO - 2017-02-13 10:18:25 --> Security Class Initialized
INFO - 2017-02-13 10:18:25 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:25 --> Security Class Initialized
INFO - 2017-02-13 10:18:25 --> Input Class Initialized
INFO - 2017-02-13 10:18:25 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:25 --> Input Class Initialized
INFO - 2017-02-13 10:18:25 --> Language Class Initialized
INFO - 2017-02-13 10:18:25 --> Loader Class Initialized
INFO - 2017-02-13 10:18:25 --> Loader Class Initialized
INFO - 2017-02-13 10:18:25 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:25 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:25 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:25 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:25 --> Controller Class Initialized
INFO - 2017-02-13 10:18:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:25 --> Model Class Initialized
INFO - 2017-02-13 10:18:25 --> Model Class Initialized
INFO - 2017-02-13 10:18:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:25 --> Total execution time: 0.2907
INFO - 2017-02-13 10:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:25 --> Controller Class Initialized
INFO - 2017-02-13 10:18:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:25 --> Model Class Initialized
INFO - 2017-02-13 10:18:25 --> Model Class Initialized
INFO - 2017-02-13 10:18:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:25 --> Total execution time: 0.3417
INFO - 2017-02-13 10:18:26 --> Config Class Initialized
INFO - 2017-02-13 10:18:26 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:26 --> Config Class Initialized
DEBUG - 2017-02-13 10:18:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:26 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:26 --> URI Class Initialized
INFO - 2017-02-13 10:18:26 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:26 --> Output Class Initialized
INFO - 2017-02-13 10:18:26 --> URI Class Initialized
INFO - 2017-02-13 10:18:26 --> Security Class Initialized
INFO - 2017-02-13 10:18:26 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:26 --> Output Class Initialized
INFO - 2017-02-13 10:18:26 --> Input Class Initialized
INFO - 2017-02-13 10:18:26 --> Language Class Initialized
INFO - 2017-02-13 10:18:26 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:26 --> Input Class Initialized
INFO - 2017-02-13 10:18:26 --> Language Class Initialized
INFO - 2017-02-13 10:18:26 --> Loader Class Initialized
INFO - 2017-02-13 10:18:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:26 --> Loader Class Initialized
INFO - 2017-02-13 10:18:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:26 --> Controller Class Initialized
INFO - 2017-02-13 10:18:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:26 --> Model Class Initialized
INFO - 2017-02-13 10:18:26 --> Model Class Initialized
INFO - 2017-02-13 10:18:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:26 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:26 --> Total execution time: 0.4125
INFO - 2017-02-13 10:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:26 --> Controller Class Initialized
INFO - 2017-02-13 10:18:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:26 --> Model Class Initialized
INFO - 2017-02-13 10:18:27 --> Model Class Initialized
INFO - 2017-02-13 10:18:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:27 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:27 --> Total execution time: 0.4448
INFO - 2017-02-13 10:18:27 --> Config Class Initialized
INFO - 2017-02-13 10:18:27 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:27 --> Config Class Initialized
INFO - 2017-02-13 10:18:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:27 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:27 --> URI Class Initialized
INFO - 2017-02-13 10:18:27 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:27 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:27 --> Output Class Initialized
INFO - 2017-02-13 10:18:27 --> URI Class Initialized
INFO - 2017-02-13 10:18:27 --> Security Class Initialized
INFO - 2017-02-13 10:18:27 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:27 --> Input Class Initialized
INFO - 2017-02-13 10:18:27 --> Output Class Initialized
INFO - 2017-02-13 10:18:27 --> Language Class Initialized
INFO - 2017-02-13 10:18:27 --> Security Class Initialized
INFO - 2017-02-13 10:18:27 --> Loader Class Initialized
DEBUG - 2017-02-13 10:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:27 --> Input Class Initialized
INFO - 2017-02-13 10:18:27 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:27 --> Language Class Initialized
INFO - 2017-02-13 10:18:27 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:27 --> Loader Class Initialized
INFO - 2017-02-13 10:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:27 --> Controller Class Initialized
INFO - 2017-02-13 10:18:27 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:27 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:27 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:27 --> Model Class Initialized
INFO - 2017-02-13 10:18:27 --> Model Class Initialized
INFO - 2017-02-13 10:18:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:27 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:27 --> Total execution time: 0.1283
INFO - 2017-02-13 10:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:27 --> Controller Class Initialized
INFO - 2017-02-13 10:18:27 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:27 --> Model Class Initialized
INFO - 2017-02-13 10:18:27 --> Model Class Initialized
INFO - 2017-02-13 10:18:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:28 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:28 --> Total execution time: 0.4900
INFO - 2017-02-13 10:18:29 --> Config Class Initialized
INFO - 2017-02-13 10:18:29 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:29 --> Config Class Initialized
DEBUG - 2017-02-13 10:18:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:29 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:29 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:29 --> Router Class Initialized
INFO - 2017-02-13 10:18:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:29 --> URI Class Initialized
INFO - 2017-02-13 10:18:29 --> Router Class Initialized
INFO - 2017-02-13 10:18:29 --> Output Class Initialized
INFO - 2017-02-13 10:18:29 --> Security Class Initialized
INFO - 2017-02-13 10:18:29 --> Output Class Initialized
INFO - 2017-02-13 10:18:29 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:29 --> Input Class Initialized
INFO - 2017-02-13 10:18:29 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:29 --> Input Class Initialized
INFO - 2017-02-13 10:18:29 --> Language Class Initialized
INFO - 2017-02-13 10:18:29 --> Loader Class Initialized
INFO - 2017-02-13 10:18:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:29 --> Loader Class Initialized
INFO - 2017-02-13 10:18:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:29 --> Controller Class Initialized
INFO - 2017-02-13 10:18:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:29 --> Model Class Initialized
INFO - 2017-02-13 10:18:29 --> Model Class Initialized
INFO - 2017-02-13 10:18:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:29 --> Total execution time: 0.1167
INFO - 2017-02-13 10:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:29 --> Controller Class Initialized
INFO - 2017-02-13 10:18:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:29 --> Model Class Initialized
INFO - 2017-02-13 10:18:29 --> Model Class Initialized
INFO - 2017-02-13 10:18:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:29 --> Total execution time: 0.3043
INFO - 2017-02-13 10:18:31 --> Config Class Initialized
INFO - 2017-02-13 10:18:31 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:31 --> Config Class Initialized
INFO - 2017-02-13 10:18:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:31 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:18:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:31 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:31 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:31 --> URI Class Initialized
INFO - 2017-02-13 10:18:31 --> Router Class Initialized
INFO - 2017-02-13 10:18:31 --> URI Class Initialized
INFO - 2017-02-13 10:18:31 --> Output Class Initialized
INFO - 2017-02-13 10:18:31 --> Router Class Initialized
INFO - 2017-02-13 10:18:31 --> Security Class Initialized
INFO - 2017-02-13 10:18:31 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:31 --> Input Class Initialized
INFO - 2017-02-13 10:18:31 --> Security Class Initialized
INFO - 2017-02-13 10:18:31 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:31 --> Input Class Initialized
INFO - 2017-02-13 10:18:31 --> Language Class Initialized
INFO - 2017-02-13 10:18:31 --> Loader Class Initialized
INFO - 2017-02-13 10:18:31 --> Loader Class Initialized
INFO - 2017-02-13 10:18:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:31 --> Controller Class Initialized
INFO - 2017-02-13 10:18:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:31 --> Model Class Initialized
INFO - 2017-02-13 10:18:31 --> Model Class Initialized
INFO - 2017-02-13 10:18:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:31 --> Total execution time: 0.3096
INFO - 2017-02-13 10:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:31 --> Controller Class Initialized
INFO - 2017-02-13 10:18:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:31 --> Model Class Initialized
INFO - 2017-02-13 10:18:31 --> Model Class Initialized
INFO - 2017-02-13 10:18:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:31 --> Total execution time: 0.3425
INFO - 2017-02-13 10:18:32 --> Config Class Initialized
INFO - 2017-02-13 10:18:32 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:32 --> Config Class Initialized
INFO - 2017-02-13 10:18:32 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:32 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:32 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:32 --> URI Class Initialized
INFO - 2017-02-13 10:18:32 --> URI Class Initialized
INFO - 2017-02-13 10:18:32 --> Router Class Initialized
INFO - 2017-02-13 10:18:32 --> Output Class Initialized
INFO - 2017-02-13 10:18:32 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:32 --> Input Class Initialized
INFO - 2017-02-13 10:18:32 --> Router Class Initialized
INFO - 2017-02-13 10:18:32 --> Language Class Initialized
INFO - 2017-02-13 10:18:32 --> Output Class Initialized
INFO - 2017-02-13 10:18:32 --> Loader Class Initialized
INFO - 2017-02-13 10:18:32 --> Security Class Initialized
INFO - 2017-02-13 10:18:32 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:32 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:32 --> Input Class Initialized
INFO - 2017-02-13 10:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:32 --> Controller Class Initialized
INFO - 2017-02-13 10:18:32 --> Language Class Initialized
INFO - 2017-02-13 10:18:32 --> Loader Class Initialized
INFO - 2017-02-13 10:18:32 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:32 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:32 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:32 --> Model Class Initialized
INFO - 2017-02-13 10:18:32 --> Model Class Initialized
INFO - 2017-02-13 10:18:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:32 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:32 --> Total execution time: 0.1138
INFO - 2017-02-13 10:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:32 --> Controller Class Initialized
INFO - 2017-02-13 10:18:32 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:32 --> Model Class Initialized
INFO - 2017-02-13 10:18:32 --> Model Class Initialized
INFO - 2017-02-13 10:18:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:32 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:32 --> Total execution time: 0.2677
INFO - 2017-02-13 10:18:33 --> Config Class Initialized
INFO - 2017-02-13 10:18:33 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:33 --> Config Class Initialized
INFO - 2017-02-13 10:18:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:33 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:33 --> Router Class Initialized
INFO - 2017-02-13 10:18:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:33 --> URI Class Initialized
INFO - 2017-02-13 10:18:33 --> Router Class Initialized
INFO - 2017-02-13 10:18:33 --> Output Class Initialized
INFO - 2017-02-13 10:18:33 --> Security Class Initialized
INFO - 2017-02-13 10:18:33 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:33 --> Input Class Initialized
INFO - 2017-02-13 10:18:33 --> Security Class Initialized
INFO - 2017-02-13 10:18:33 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:33 --> Loader Class Initialized
INFO - 2017-02-13 10:18:33 --> Input Class Initialized
INFO - 2017-02-13 10:18:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:33 --> Language Class Initialized
INFO - 2017-02-13 10:18:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:33 --> Loader Class Initialized
INFO - 2017-02-13 10:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:33 --> Controller Class Initialized
INFO - 2017-02-13 10:18:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:33 --> Model Class Initialized
INFO - 2017-02-13 10:18:33 --> Model Class Initialized
INFO - 2017-02-13 10:18:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:33 --> Total execution time: 0.1265
INFO - 2017-02-13 10:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:33 --> Controller Class Initialized
INFO - 2017-02-13 10:18:34 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:34 --> Model Class Initialized
INFO - 2017-02-13 10:18:34 --> Model Class Initialized
INFO - 2017-02-13 10:18:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:34 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:34 --> Total execution time: 0.3968
INFO - 2017-02-13 10:18:35 --> Config Class Initialized
INFO - 2017-02-13 10:18:35 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:35 --> Config Class Initialized
INFO - 2017-02-13 10:18:35 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:35 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:35 --> URI Class Initialized
INFO - 2017-02-13 10:18:35 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:35 --> Router Class Initialized
INFO - 2017-02-13 10:18:35 --> URI Class Initialized
INFO - 2017-02-13 10:18:35 --> Output Class Initialized
INFO - 2017-02-13 10:18:35 --> Security Class Initialized
INFO - 2017-02-13 10:18:35 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:35 --> Input Class Initialized
INFO - 2017-02-13 10:18:35 --> Language Class Initialized
INFO - 2017-02-13 10:18:35 --> Output Class Initialized
INFO - 2017-02-13 10:18:35 --> Security Class Initialized
INFO - 2017-02-13 10:18:35 --> Loader Class Initialized
DEBUG - 2017-02-13 10:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:35 --> Input Class Initialized
INFO - 2017-02-13 10:18:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:35 --> Language Class Initialized
INFO - 2017-02-13 10:18:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:35 --> Loader Class Initialized
INFO - 2017-02-13 10:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:35 --> Controller Class Initialized
INFO - 2017-02-13 10:18:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:35 --> Model Class Initialized
INFO - 2017-02-13 10:18:35 --> Model Class Initialized
INFO - 2017-02-13 10:18:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:35 --> Total execution time: 0.3403
INFO - 2017-02-13 10:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:35 --> Controller Class Initialized
INFO - 2017-02-13 10:18:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:35 --> Model Class Initialized
INFO - 2017-02-13 10:18:35 --> Model Class Initialized
INFO - 2017-02-13 10:18:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:35 --> Total execution time: 0.3923
INFO - 2017-02-13 10:18:37 --> Config Class Initialized
INFO - 2017-02-13 10:18:37 --> Config Class Initialized
INFO - 2017-02-13 10:18:37 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:37 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:18:37 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:37 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:37 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:37 --> URI Class Initialized
INFO - 2017-02-13 10:18:37 --> URI Class Initialized
INFO - 2017-02-13 10:18:37 --> Router Class Initialized
INFO - 2017-02-13 10:18:37 --> Router Class Initialized
INFO - 2017-02-13 10:18:37 --> Output Class Initialized
INFO - 2017-02-13 10:18:37 --> Output Class Initialized
INFO - 2017-02-13 10:18:37 --> Security Class Initialized
INFO - 2017-02-13 10:18:37 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:37 --> Input Class Initialized
INFO - 2017-02-13 10:18:37 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:37 --> Input Class Initialized
INFO - 2017-02-13 10:18:37 --> Loader Class Initialized
INFO - 2017-02-13 10:18:37 --> Language Class Initialized
INFO - 2017-02-13 10:18:37 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:37 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:37 --> Loader Class Initialized
INFO - 2017-02-13 10:18:37 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:37 --> Controller Class Initialized
INFO - 2017-02-13 10:18:37 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:37 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:37 --> Model Class Initialized
INFO - 2017-02-13 10:18:37 --> Model Class Initialized
INFO - 2017-02-13 10:18:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:37 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:37 --> Total execution time: 0.1280
INFO - 2017-02-13 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:37 --> Controller Class Initialized
INFO - 2017-02-13 10:18:37 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:37 --> Model Class Initialized
INFO - 2017-02-13 10:18:37 --> Model Class Initialized
INFO - 2017-02-13 10:18:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:37 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:37 --> Total execution time: 0.3935
INFO - 2017-02-13 10:18:38 --> Config Class Initialized
INFO - 2017-02-13 10:18:38 --> Config Class Initialized
INFO - 2017-02-13 10:18:38 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:38 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:38 --> URI Class Initialized
INFO - 2017-02-13 10:18:38 --> URI Class Initialized
INFO - 2017-02-13 10:18:38 --> Router Class Initialized
INFO - 2017-02-13 10:18:38 --> Router Class Initialized
INFO - 2017-02-13 10:18:38 --> Output Class Initialized
INFO - 2017-02-13 10:18:38 --> Output Class Initialized
INFO - 2017-02-13 10:18:38 --> Security Class Initialized
INFO - 2017-02-13 10:18:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:38 --> Input Class Initialized
INFO - 2017-02-13 10:18:38 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:38 --> Input Class Initialized
INFO - 2017-02-13 10:18:38 --> Language Class Initialized
INFO - 2017-02-13 10:18:38 --> Loader Class Initialized
INFO - 2017-02-13 10:18:38 --> Loader Class Initialized
INFO - 2017-02-13 10:18:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:38 --> Controller Class Initialized
INFO - 2017-02-13 10:18:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:38 --> Model Class Initialized
INFO - 2017-02-13 10:18:38 --> Model Class Initialized
INFO - 2017-02-13 10:18:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:38 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:38 --> Total execution time: 0.1341
INFO - 2017-02-13 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:38 --> Controller Class Initialized
INFO - 2017-02-13 10:18:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:38 --> Model Class Initialized
INFO - 2017-02-13 10:18:38 --> Model Class Initialized
INFO - 2017-02-13 10:18:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:39 --> Total execution time: 0.4246
INFO - 2017-02-13 10:18:40 --> Config Class Initialized
INFO - 2017-02-13 10:18:40 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:40 --> Config Class Initialized
INFO - 2017-02-13 10:18:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:40 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:40 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:40 --> URI Class Initialized
INFO - 2017-02-13 10:18:40 --> URI Class Initialized
INFO - 2017-02-13 10:18:40 --> Router Class Initialized
INFO - 2017-02-13 10:18:40 --> Router Class Initialized
INFO - 2017-02-13 10:18:40 --> Output Class Initialized
INFO - 2017-02-13 10:18:40 --> Output Class Initialized
INFO - 2017-02-13 10:18:40 --> Security Class Initialized
INFO - 2017-02-13 10:18:40 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:40 --> Input Class Initialized
DEBUG - 2017-02-13 10:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:40 --> Language Class Initialized
INFO - 2017-02-13 10:18:40 --> Input Class Initialized
INFO - 2017-02-13 10:18:40 --> Language Class Initialized
INFO - 2017-02-13 10:18:40 --> Loader Class Initialized
INFO - 2017-02-13 10:18:40 --> Loader Class Initialized
INFO - 2017-02-13 10:18:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:40 --> Controller Class Initialized
INFO - 2017-02-13 10:18:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:40 --> Model Class Initialized
INFO - 2017-02-13 10:18:40 --> Model Class Initialized
INFO - 2017-02-13 10:18:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:40 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:40 --> Total execution time: 0.1144
INFO - 2017-02-13 10:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:40 --> Controller Class Initialized
INFO - 2017-02-13 10:18:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:40 --> Model Class Initialized
INFO - 2017-02-13 10:18:40 --> Model Class Initialized
INFO - 2017-02-13 10:18:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:40 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:40 --> Total execution time: 0.4548
INFO - 2017-02-13 10:18:41 --> Config Class Initialized
INFO - 2017-02-13 10:18:41 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:41 --> Config Class Initialized
INFO - 2017-02-13 10:18:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:41 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:41 --> URI Class Initialized
INFO - 2017-02-13 10:18:41 --> URI Class Initialized
INFO - 2017-02-13 10:18:41 --> Router Class Initialized
INFO - 2017-02-13 10:18:41 --> Router Class Initialized
INFO - 2017-02-13 10:18:41 --> Output Class Initialized
INFO - 2017-02-13 10:18:41 --> Output Class Initialized
INFO - 2017-02-13 10:18:41 --> Security Class Initialized
INFO - 2017-02-13 10:18:41 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:41 --> Input Class Initialized
INFO - 2017-02-13 10:18:41 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:41 --> Input Class Initialized
INFO - 2017-02-13 10:18:41 --> Loader Class Initialized
INFO - 2017-02-13 10:18:41 --> Language Class Initialized
INFO - 2017-02-13 10:18:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:41 --> Loader Class Initialized
INFO - 2017-02-13 10:18:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:41 --> Controller Class Initialized
INFO - 2017-02-13 10:18:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:41 --> Model Class Initialized
INFO - 2017-02-13 10:18:41 --> Model Class Initialized
INFO - 2017-02-13 10:18:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:41 --> Total execution time: 0.1132
INFO - 2017-02-13 10:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:41 --> Controller Class Initialized
INFO - 2017-02-13 10:18:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:41 --> Model Class Initialized
INFO - 2017-02-13 10:18:41 --> Model Class Initialized
INFO - 2017-02-13 10:18:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:41 --> Total execution time: 0.3153
INFO - 2017-02-13 10:18:43 --> Config Class Initialized
INFO - 2017-02-13 10:18:43 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:43 --> Config Class Initialized
INFO - 2017-02-13 10:18:43 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:43 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:18:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:43 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:43 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:43 --> URI Class Initialized
INFO - 2017-02-13 10:18:43 --> URI Class Initialized
INFO - 2017-02-13 10:18:43 --> Router Class Initialized
INFO - 2017-02-13 10:18:43 --> Router Class Initialized
INFO - 2017-02-13 10:18:43 --> Output Class Initialized
INFO - 2017-02-13 10:18:43 --> Output Class Initialized
INFO - 2017-02-13 10:18:43 --> Security Class Initialized
INFO - 2017-02-13 10:18:43 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 10:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:43 --> Input Class Initialized
INFO - 2017-02-13 10:18:43 --> Input Class Initialized
INFO - 2017-02-13 10:18:43 --> Language Class Initialized
INFO - 2017-02-13 10:18:43 --> Language Class Initialized
INFO - 2017-02-13 10:18:43 --> Loader Class Initialized
INFO - 2017-02-13 10:18:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:43 --> Loader Class Initialized
INFO - 2017-02-13 10:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:43 --> Controller Class Initialized
INFO - 2017-02-13 10:18:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:43 --> Model Class Initialized
INFO - 2017-02-13 10:18:43 --> Model Class Initialized
INFO - 2017-02-13 10:18:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:43 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:43 --> Total execution time: 0.3648
INFO - 2017-02-13 10:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:43 --> Controller Class Initialized
INFO - 2017-02-13 10:18:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:43 --> Model Class Initialized
INFO - 2017-02-13 10:18:43 --> Model Class Initialized
INFO - 2017-02-13 10:18:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:43 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:43 --> Total execution time: 0.4086
INFO - 2017-02-13 10:18:44 --> Config Class Initialized
INFO - 2017-02-13 10:18:44 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:44 --> URI Class Initialized
INFO - 2017-02-13 10:18:44 --> Router Class Initialized
INFO - 2017-02-13 10:18:44 --> Output Class Initialized
INFO - 2017-02-13 10:18:44 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:44 --> Input Class Initialized
INFO - 2017-02-13 10:18:44 --> Language Class Initialized
INFO - 2017-02-13 10:18:44 --> Loader Class Initialized
INFO - 2017-02-13 10:18:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:44 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:44 --> Controller Class Initialized
INFO - 2017-02-13 10:18:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:44 --> Model Class Initialized
INFO - 2017-02-13 10:18:44 --> Model Class Initialized
INFO - 2017-02-13 10:18:44 --> Model Class Initialized
INFO - 2017-02-13 10:18:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:44 --> Total execution time: 0.0952
INFO - 2017-02-13 10:18:45 --> Config Class Initialized
INFO - 2017-02-13 10:18:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:45 --> Config Class Initialized
INFO - 2017-02-13 10:18:45 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:45 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:45 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:45 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:45 --> Router Class Initialized
INFO - 2017-02-13 10:18:45 --> URI Class Initialized
INFO - 2017-02-13 10:18:45 --> Output Class Initialized
INFO - 2017-02-13 10:18:45 --> Router Class Initialized
INFO - 2017-02-13 10:18:45 --> Security Class Initialized
INFO - 2017-02-13 10:18:45 --> Output Class Initialized
INFO - 2017-02-13 10:18:45 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:45 --> Input Class Initialized
INFO - 2017-02-13 10:18:45 --> Language Class Initialized
DEBUG - 2017-02-13 10:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:45 --> Input Class Initialized
INFO - 2017-02-13 10:18:45 --> Language Class Initialized
INFO - 2017-02-13 10:18:45 --> Loader Class Initialized
INFO - 2017-02-13 10:18:45 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:45 --> Loader Class Initialized
INFO - 2017-02-13 10:18:45 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:45 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:45 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:45 --> Controller Class Initialized
INFO - 2017-02-13 10:18:45 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:45 --> Model Class Initialized
INFO - 2017-02-13 10:18:45 --> Model Class Initialized
INFO - 2017-02-13 10:18:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:45 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:45 --> Total execution time: 0.0983
INFO - 2017-02-13 10:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:45 --> Controller Class Initialized
INFO - 2017-02-13 10:18:45 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:45 --> Model Class Initialized
INFO - 2017-02-13 10:18:45 --> Model Class Initialized
INFO - 2017-02-13 10:18:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:45 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:45 --> Total execution time: 0.3623
INFO - 2017-02-13 10:18:47 --> Config Class Initialized
INFO - 2017-02-13 10:18:47 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:47 --> Config Class Initialized
DEBUG - 2017-02-13 10:18:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:47 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:47 --> URI Class Initialized
INFO - 2017-02-13 10:18:47 --> Router Class Initialized
INFO - 2017-02-13 10:18:47 --> Config Class Initialized
INFO - 2017-02-13 10:18:47 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:47 --> Output Class Initialized
DEBUG - 2017-02-13 10:18:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:47 --> Security Class Initialized
INFO - 2017-02-13 10:18:47 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:47 --> URI Class Initialized
INFO - 2017-02-13 10:18:47 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:47 --> Router Class Initialized
INFO - 2017-02-13 10:18:47 --> Input Class Initialized
INFO - 2017-02-13 10:18:47 --> Language Class Initialized
INFO - 2017-02-13 10:18:47 --> Output Class Initialized
INFO - 2017-02-13 10:18:47 --> Output Class Initialized
INFO - 2017-02-13 10:18:47 --> Security Class Initialized
INFO - 2017-02-13 10:18:47 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:47 --> Input Class Initialized
DEBUG - 2017-02-13 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:47 --> Language Class Initialized
INFO - 2017-02-13 10:18:47 --> Input Class Initialized
INFO - 2017-02-13 10:18:47 --> Language Class Initialized
INFO - 2017-02-13 10:18:47 --> Loader Class Initialized
INFO - 2017-02-13 10:18:47 --> Loader Class Initialized
INFO - 2017-02-13 10:18:47 --> Config Class Initialized
INFO - 2017-02-13 10:18:47 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:47 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:47 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:47 --> Config Class Initialized
INFO - 2017-02-13 10:18:47 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:47 --> URI Class Initialized
INFO - 2017-02-13 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:47 --> Router Class Initialized
INFO - 2017-02-13 10:18:47 --> Controller Class Initialized
DEBUG - 2017-02-13 10:18:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:47 --> URI Class Initialized
INFO - 2017-02-13 10:18:47 --> Output Class Initialized
INFO - 2017-02-13 10:18:47 --> Security Class Initialized
INFO - 2017-02-13 10:18:47 --> Router Class Initialized
INFO - 2017-02-13 10:18:47 --> Output Class Initialized
INFO - 2017-02-13 10:18:47 --> Loader Class Initialized
INFO - 2017-02-13 10:18:47 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:47 --> Input Class Initialized
INFO - 2017-02-13 10:18:47 --> Config Class Initialized
INFO - 2017-02-13 10:18:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:47 --> Language Class Initialized
INFO - 2017-02-13 10:18:47 --> Input Class Initialized
INFO - 2017-02-13 10:18:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:47 --> Language Class Initialized
INFO - 2017-02-13 10:18:47 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:47 --> Loader Class Initialized
INFO - 2017-02-13 10:18:47 --> URI Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Router Class Initialized
INFO - 2017-02-13 10:18:47 --> Loader Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Output Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:47 --> Security Class Initialized
INFO - 2017-02-13 10:18:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:47 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:47 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:47 --> Input Class Initialized
INFO - 2017-02-13 10:18:47 --> Language Class Initialized
INFO - 2017-02-13 10:18:47 --> Loader Class Initialized
INFO - 2017-02-13 10:18:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:47 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:47 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:47 --> Total execution time: 0.4298
INFO - 2017-02-13 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:47 --> Controller Class Initialized
INFO - 2017-02-13 10:18:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:47 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:47 --> Total execution time: 0.4606
INFO - 2017-02-13 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:47 --> Controller Class Initialized
INFO - 2017-02-13 10:18:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:47 --> Controller Class Initialized
INFO - 2017-02-13 10:18:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:47 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:47 --> Total execution time: 0.5190
INFO - 2017-02-13 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:47 --> Controller Class Initialized
INFO - 2017-02-13 10:18:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:47 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:47 --> Total execution time: 0.5622
INFO - 2017-02-13 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:47 --> Controller Class Initialized
INFO - 2017-02-13 10:18:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:18:47 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 324
INFO - 2017-02-13 10:18:47 --> Config Class Initialized
INFO - 2017-02-13 10:18:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:47 --> URI Class Initialized
INFO - 2017-02-13 10:18:47 --> Router Class Initialized
INFO - 2017-02-13 10:18:47 --> Output Class Initialized
INFO - 2017-02-13 10:18:47 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:47 --> Input Class Initialized
INFO - 2017-02-13 10:18:47 --> Language Class Initialized
INFO - 2017-02-13 10:18:47 --> Loader Class Initialized
INFO - 2017-02-13 10:18:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:47 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:47 --> Controller Class Initialized
INFO - 2017-02-13 10:18:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Model Class Initialized
INFO - 2017-02-13 10:18:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:18:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04.php
INFO - 2017-02-13 10:18:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:18:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:48 --> Total execution time: 0.1498
INFO - 2017-02-13 10:18:50 --> Config Class Initialized
INFO - 2017-02-13 10:18:50 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:50 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:50 --> URI Class Initialized
INFO - 2017-02-13 10:18:50 --> Router Class Initialized
INFO - 2017-02-13 10:18:50 --> Output Class Initialized
INFO - 2017-02-13 10:18:50 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:50 --> Input Class Initialized
INFO - 2017-02-13 10:18:50 --> Language Class Initialized
INFO - 2017-02-13 10:18:50 --> Loader Class Initialized
INFO - 2017-02-13 10:18:50 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:50 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:50 --> Controller Class Initialized
INFO - 2017-02-13 10:18:50 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:50 --> Model Class Initialized
INFO - 2017-02-13 10:18:50 --> Model Class Initialized
INFO - 2017-02-13 10:18:50 --> Model Class Initialized
INFO - 2017-02-13 10:18:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:50 --> Config Class Initialized
INFO - 2017-02-13 10:18:50 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:50 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:50 --> URI Class Initialized
INFO - 2017-02-13 10:18:50 --> Router Class Initialized
INFO - 2017-02-13 10:18:50 --> Output Class Initialized
INFO - 2017-02-13 10:18:50 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:50 --> Input Class Initialized
INFO - 2017-02-13 10:18:50 --> Language Class Initialized
INFO - 2017-02-13 10:18:50 --> Loader Class Initialized
INFO - 2017-02-13 10:18:50 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:50 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:50 --> Controller Class Initialized
INFO - 2017-02-13 10:18:50 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:50 --> Model Class Initialized
INFO - 2017-02-13 10:18:50 --> Model Class Initialized
INFO - 2017-02-13 10:18:50 --> Model Class Initialized
INFO - 2017-02-13 10:18:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_04_attempt.php
INFO - 2017-02-13 10:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:18:51 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:51 --> Total execution time: 0.1681
INFO - 2017-02-13 10:18:51 --> Config Class Initialized
INFO - 2017-02-13 10:18:51 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:51 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:51 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:51 --> URI Class Initialized
INFO - 2017-02-13 10:18:51 --> Config Class Initialized
INFO - 2017-02-13 10:18:51 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:51 --> Router Class Initialized
DEBUG - 2017-02-13 10:18:51 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:51 --> Output Class Initialized
INFO - 2017-02-13 10:18:51 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:51 --> Security Class Initialized
INFO - 2017-02-13 10:18:51 --> URI Class Initialized
DEBUG - 2017-02-13 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:51 --> Input Class Initialized
INFO - 2017-02-13 10:18:51 --> Language Class Initialized
INFO - 2017-02-13 10:18:51 --> Router Class Initialized
INFO - 2017-02-13 10:18:51 --> Output Class Initialized
INFO - 2017-02-13 10:18:51 --> Loader Class Initialized
INFO - 2017-02-13 10:18:51 --> Security Class Initialized
INFO - 2017-02-13 10:18:51 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:51 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:51 --> Input Class Initialized
INFO - 2017-02-13 10:18:51 --> Language Class Initialized
INFO - 2017-02-13 10:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:51 --> Controller Class Initialized
INFO - 2017-02-13 10:18:51 --> Loader Class Initialized
INFO - 2017-02-13 10:18:51 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:51 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:51 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:51 --> Model Class Initialized
INFO - 2017-02-13 10:18:51 --> Model Class Initialized
INFO - 2017-02-13 10:18:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:51 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:51 --> Total execution time: 0.1547
INFO - 2017-02-13 10:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:51 --> Controller Class Initialized
INFO - 2017-02-13 10:18:51 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:51 --> Model Class Initialized
INFO - 2017-02-13 10:18:51 --> Model Class Initialized
INFO - 2017-02-13 10:18:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:51 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:51 --> Total execution time: 0.3261
INFO - 2017-02-13 10:18:56 --> Config Class Initialized
INFO - 2017-02-13 10:18:56 --> Hooks Class Initialized
INFO - 2017-02-13 10:18:56 --> Config Class Initialized
INFO - 2017-02-13 10:18:56 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:18:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:18:56 --> URI Class Initialized
INFO - 2017-02-13 10:18:56 --> Router Class Initialized
INFO - 2017-02-13 10:18:56 --> Output Class Initialized
INFO - 2017-02-13 10:18:56 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:18:56 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:56 --> Input Class Initialized
INFO - 2017-02-13 10:18:56 --> URI Class Initialized
INFO - 2017-02-13 10:18:56 --> Language Class Initialized
INFO - 2017-02-13 10:18:56 --> Router Class Initialized
INFO - 2017-02-13 10:18:56 --> Output Class Initialized
INFO - 2017-02-13 10:18:56 --> Security Class Initialized
DEBUG - 2017-02-13 10:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:18:56 --> Loader Class Initialized
INFO - 2017-02-13 10:18:56 --> Input Class Initialized
INFO - 2017-02-13 10:18:56 --> Language Class Initialized
INFO - 2017-02-13 10:18:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:56 --> Loader Class Initialized
INFO - 2017-02-13 10:18:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:18:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:56 --> Controller Class Initialized
INFO - 2017-02-13 10:18:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:56 --> Model Class Initialized
INFO - 2017-02-13 10:18:56 --> Model Class Initialized
INFO - 2017-02-13 10:18:56 --> Model Class Initialized
INFO - 2017-02-13 10:18:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:56 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:56 --> Total execution time: 0.2740
INFO - 2017-02-13 10:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:18:56 --> Controller Class Initialized
INFO - 2017-02-13 10:18:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:18:56 --> Model Class Initialized
INFO - 2017-02-13 10:18:56 --> Model Class Initialized
INFO - 2017-02-13 10:18:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:18:56 --> Final output sent to browser
DEBUG - 2017-02-13 10:18:56 --> Total execution time: 0.3244
INFO - 2017-02-13 10:19:00 --> Config Class Initialized
INFO - 2017-02-13 10:19:00 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:00 --> Config Class Initialized
INFO - 2017-02-13 10:19:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:00 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:19:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:00 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:00 --> URI Class Initialized
INFO - 2017-02-13 10:19:00 --> URI Class Initialized
INFO - 2017-02-13 10:19:00 --> Router Class Initialized
INFO - 2017-02-13 10:19:00 --> Router Class Initialized
INFO - 2017-02-13 10:19:00 --> Output Class Initialized
INFO - 2017-02-13 10:19:00 --> Output Class Initialized
INFO - 2017-02-13 10:19:00 --> Security Class Initialized
INFO - 2017-02-13 10:19:00 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:00 --> Input Class Initialized
INFO - 2017-02-13 10:19:00 --> Language Class Initialized
INFO - 2017-02-13 10:19:00 --> Loader Class Initialized
DEBUG - 2017-02-13 10:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:00 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:00 --> Input Class Initialized
INFO - 2017-02-13 10:19:00 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:00 --> Language Class Initialized
INFO - 2017-02-13 10:19:00 --> Controller Class Initialized
INFO - 2017-02-13 10:19:00 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:00 --> Loader Class Initialized
INFO - 2017-02-13 10:19:00 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:00 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:00 --> Model Class Initialized
INFO - 2017-02-13 10:19:00 --> Model Class Initialized
INFO - 2017-02-13 10:19:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:00 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:00 --> Total execution time: 0.1167
INFO - 2017-02-13 10:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:00 --> Controller Class Initialized
INFO - 2017-02-13 10:19:00 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:00 --> Model Class Initialized
INFO - 2017-02-13 10:19:00 --> Model Class Initialized
INFO - 2017-02-13 10:19:00 --> Model Class Initialized
INFO - 2017-02-13 10:19:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:00 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:00 --> Total execution time: 0.3987
INFO - 2017-02-13 10:19:03 --> Config Class Initialized
INFO - 2017-02-13 10:19:03 --> Config Class Initialized
INFO - 2017-02-13 10:19:03 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:03 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:03 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:19:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:03 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:03 --> URI Class Initialized
INFO - 2017-02-13 10:19:03 --> URI Class Initialized
INFO - 2017-02-13 10:19:03 --> Router Class Initialized
INFO - 2017-02-13 10:19:03 --> Output Class Initialized
INFO - 2017-02-13 10:19:03 --> Security Class Initialized
INFO - 2017-02-13 10:19:03 --> Router Class Initialized
INFO - 2017-02-13 10:19:03 --> Output Class Initialized
DEBUG - 2017-02-13 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:03 --> Input Class Initialized
INFO - 2017-02-13 10:19:03 --> Security Class Initialized
INFO - 2017-02-13 10:19:03 --> Language Class Initialized
DEBUG - 2017-02-13 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:03 --> Input Class Initialized
INFO - 2017-02-13 10:19:03 --> Language Class Initialized
INFO - 2017-02-13 10:19:03 --> Loader Class Initialized
INFO - 2017-02-13 10:19:03 --> Loader Class Initialized
INFO - 2017-02-13 10:19:03 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:03 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:03 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:03 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:03 --> Controller Class Initialized
INFO - 2017-02-13 10:19:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:03 --> Model Class Initialized
INFO - 2017-02-13 10:19:03 --> Model Class Initialized
INFO - 2017-02-13 10:19:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:03 --> Total execution time: 0.1137
INFO - 2017-02-13 10:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:03 --> Controller Class Initialized
INFO - 2017-02-13 10:19:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:03 --> Model Class Initialized
INFO - 2017-02-13 10:19:03 --> Model Class Initialized
INFO - 2017-02-13 10:19:03 --> Model Class Initialized
INFO - 2017-02-13 10:19:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:04 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:04 --> Total execution time: 0.3766
INFO - 2017-02-13 10:19:06 --> Config Class Initialized
INFO - 2017-02-13 10:19:06 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:06 --> Config Class Initialized
INFO - 2017-02-13 10:19:06 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:06 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:06 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:06 --> URI Class Initialized
INFO - 2017-02-13 10:19:06 --> Router Class Initialized
INFO - 2017-02-13 10:19:06 --> Output Class Initialized
INFO - 2017-02-13 10:19:06 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:06 --> Input Class Initialized
INFO - 2017-02-13 10:19:06 --> Language Class Initialized
DEBUG - 2017-02-13 10:19:06 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:06 --> Loader Class Initialized
INFO - 2017-02-13 10:19:06 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:06 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:06 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:06 --> URI Class Initialized
INFO - 2017-02-13 10:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:06 --> Controller Class Initialized
INFO - 2017-02-13 10:19:06 --> Router Class Initialized
INFO - 2017-02-13 10:19:06 --> Output Class Initialized
INFO - 2017-02-13 10:19:06 --> Security Class Initialized
INFO - 2017-02-13 10:19:06 --> Database Driver Class Initialized
DEBUG - 2017-02-13 10:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:06 --> Input Class Initialized
INFO - 2017-02-13 10:19:06 --> Language Class Initialized
INFO - 2017-02-13 10:19:07 --> Model Class Initialized
INFO - 2017-02-13 10:19:07 --> Model Class Initialized
INFO - 2017-02-13 10:19:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:07 --> Loader Class Initialized
INFO - 2017-02-13 10:19:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:07 --> Total execution time: 0.1067
INFO - 2017-02-13 10:19:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:07 --> Controller Class Initialized
INFO - 2017-02-13 10:19:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:07 --> Model Class Initialized
INFO - 2017-02-13 10:19:07 --> Model Class Initialized
INFO - 2017-02-13 10:19:07 --> Model Class Initialized
INFO - 2017-02-13 10:19:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:07 --> Total execution time: 0.4192
INFO - 2017-02-13 10:19:10 --> Config Class Initialized
INFO - 2017-02-13 10:19:10 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:10 --> Config Class Initialized
INFO - 2017-02-13 10:19:10 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:10 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:10 --> URI Class Initialized
DEBUG - 2017-02-13 10:19:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:10 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:10 --> Router Class Initialized
INFO - 2017-02-13 10:19:10 --> Output Class Initialized
INFO - 2017-02-13 10:19:10 --> URI Class Initialized
INFO - 2017-02-13 10:19:10 --> Router Class Initialized
INFO - 2017-02-13 10:19:10 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:10 --> Output Class Initialized
INFO - 2017-02-13 10:19:10 --> Input Class Initialized
INFO - 2017-02-13 10:19:10 --> Language Class Initialized
INFO - 2017-02-13 10:19:10 --> Security Class Initialized
INFO - 2017-02-13 10:19:10 --> Loader Class Initialized
INFO - 2017-02-13 10:19:10 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:10 --> Input Class Initialized
INFO - 2017-02-13 10:19:10 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:10 --> Language Class Initialized
INFO - 2017-02-13 10:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:10 --> Controller Class Initialized
INFO - 2017-02-13 10:19:10 --> Loader Class Initialized
INFO - 2017-02-13 10:19:10 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:10 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:10 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:10 --> Model Class Initialized
INFO - 2017-02-13 10:19:10 --> Model Class Initialized
INFO - 2017-02-13 10:19:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:10 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:10 --> Total execution time: 0.1328
INFO - 2017-02-13 10:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:10 --> Controller Class Initialized
INFO - 2017-02-13 10:19:10 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:10 --> Model Class Initialized
INFO - 2017-02-13 10:19:10 --> Model Class Initialized
INFO - 2017-02-13 10:19:10 --> Model Class Initialized
INFO - 2017-02-13 10:19:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:10 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:10 --> Total execution time: 0.3967
INFO - 2017-02-13 10:19:13 --> Config Class Initialized
INFO - 2017-02-13 10:19:13 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:13 --> Config Class Initialized
INFO - 2017-02-13 10:19:13 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:13 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:19:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:13 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:13 --> URI Class Initialized
INFO - 2017-02-13 10:19:13 --> URI Class Initialized
INFO - 2017-02-13 10:19:13 --> Router Class Initialized
INFO - 2017-02-13 10:19:13 --> Router Class Initialized
INFO - 2017-02-13 10:19:13 --> Output Class Initialized
INFO - 2017-02-13 10:19:13 --> Security Class Initialized
INFO - 2017-02-13 10:19:13 --> Output Class Initialized
DEBUG - 2017-02-13 10:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:13 --> Security Class Initialized
INFO - 2017-02-13 10:19:13 --> Input Class Initialized
INFO - 2017-02-13 10:19:13 --> Language Class Initialized
DEBUG - 2017-02-13 10:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:13 --> Input Class Initialized
INFO - 2017-02-13 10:19:13 --> Loader Class Initialized
INFO - 2017-02-13 10:19:13 --> Language Class Initialized
INFO - 2017-02-13 10:19:13 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:13 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:13 --> Loader Class Initialized
INFO - 2017-02-13 10:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:13 --> Controller Class Initialized
INFO - 2017-02-13 10:19:13 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:13 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:13 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:13 --> Model Class Initialized
INFO - 2017-02-13 10:19:13 --> Model Class Initialized
INFO - 2017-02-13 10:19:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:13 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:13 --> Total execution time: 0.1321
INFO - 2017-02-13 10:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:13 --> Controller Class Initialized
INFO - 2017-02-13 10:19:13 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:13 --> Model Class Initialized
INFO - 2017-02-13 10:19:13 --> Model Class Initialized
INFO - 2017-02-13 10:19:13 --> Model Class Initialized
INFO - 2017-02-13 10:19:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:13 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:13 --> Total execution time: 0.3476
INFO - 2017-02-13 10:19:17 --> Config Class Initialized
INFO - 2017-02-13 10:19:17 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:17 --> Config Class Initialized
INFO - 2017-02-13 10:19:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:17 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:19:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:17 --> URI Class Initialized
INFO - 2017-02-13 10:19:17 --> URI Class Initialized
INFO - 2017-02-13 10:19:17 --> Router Class Initialized
INFO - 2017-02-13 10:19:17 --> Router Class Initialized
INFO - 2017-02-13 10:19:17 --> Output Class Initialized
INFO - 2017-02-13 10:19:17 --> Security Class Initialized
INFO - 2017-02-13 10:19:17 --> Output Class Initialized
INFO - 2017-02-13 10:19:17 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 10:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:17 --> Input Class Initialized
INFO - 2017-02-13 10:19:17 --> Input Class Initialized
INFO - 2017-02-13 10:19:17 --> Language Class Initialized
INFO - 2017-02-13 10:19:17 --> Language Class Initialized
INFO - 2017-02-13 10:19:17 --> Loader Class Initialized
INFO - 2017-02-13 10:19:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:17 --> Loader Class Initialized
INFO - 2017-02-13 10:19:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:17 --> Controller Class Initialized
INFO - 2017-02-13 10:19:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:17 --> Model Class Initialized
INFO - 2017-02-13 10:19:17 --> Model Class Initialized
INFO - 2017-02-13 10:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:17 --> Total execution time: 0.1435
INFO - 2017-02-13 10:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:17 --> Controller Class Initialized
INFO - 2017-02-13 10:19:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:17 --> Model Class Initialized
INFO - 2017-02-13 10:19:17 --> Model Class Initialized
INFO - 2017-02-13 10:19:17 --> Model Class Initialized
INFO - 2017-02-13 10:19:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:18 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:18 --> Total execution time: 0.4164
INFO - 2017-02-13 10:19:20 --> Config Class Initialized
INFO - 2017-02-13 10:19:20 --> Config Class Initialized
INFO - 2017-02-13 10:19:20 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:20 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:19:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:20 --> URI Class Initialized
INFO - 2017-02-13 10:19:20 --> URI Class Initialized
INFO - 2017-02-13 10:19:20 --> Router Class Initialized
INFO - 2017-02-13 10:19:20 --> Router Class Initialized
INFO - 2017-02-13 10:19:20 --> Output Class Initialized
INFO - 2017-02-13 10:19:20 --> Output Class Initialized
INFO - 2017-02-13 10:19:20 --> Security Class Initialized
INFO - 2017-02-13 10:19:20 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:20 --> Input Class Initialized
DEBUG - 2017-02-13 10:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:20 --> Input Class Initialized
INFO - 2017-02-13 10:19:20 --> Language Class Initialized
INFO - 2017-02-13 10:19:20 --> Language Class Initialized
INFO - 2017-02-13 10:19:20 --> Loader Class Initialized
INFO - 2017-02-13 10:19:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:20 --> Loader Class Initialized
INFO - 2017-02-13 10:19:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:20 --> Controller Class Initialized
INFO - 2017-02-13 10:19:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:21 --> Model Class Initialized
INFO - 2017-02-13 10:19:21 --> Model Class Initialized
INFO - 2017-02-13 10:19:21 --> Model Class Initialized
INFO - 2017-02-13 10:19:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:21 --> Config Class Initialized
INFO - 2017-02-13 10:19:21 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:21 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:21 --> URI Class Initialized
INFO - 2017-02-13 10:19:21 --> Router Class Initialized
INFO - 2017-02-13 10:19:21 --> Output Class Initialized
INFO - 2017-02-13 10:19:21 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:21 --> Input Class Initialized
INFO - 2017-02-13 10:19:21 --> Language Class Initialized
INFO - 2017-02-13 10:19:21 --> Loader Class Initialized
INFO - 2017-02-13 10:19:21 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:21 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:21 --> Total execution time: 0.3822
INFO - 2017-02-13 10:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:21 --> Controller Class Initialized
INFO - 2017-02-13 10:19:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:21 --> Model Class Initialized
INFO - 2017-02-13 10:19:21 --> Model Class Initialized
INFO - 2017-02-13 10:19:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:21 --> Total execution time: 0.4186
INFO - 2017-02-13 10:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:21 --> Controller Class Initialized
INFO - 2017-02-13 10:19:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:21 --> Model Class Initialized
INFO - 2017-02-13 10:19:21 --> Model Class Initialized
INFO - 2017-02-13 10:19:21 --> Model Class Initialized
INFO - 2017-02-13 10:19:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:21 --> Total execution time: 0.2351
INFO - 2017-02-13 10:19:25 --> Config Class Initialized
INFO - 2017-02-13 10:19:25 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:25 --> Config Class Initialized
INFO - 2017-02-13 10:19:25 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:25 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:25 --> URI Class Initialized
INFO - 2017-02-13 10:19:25 --> Router Class Initialized
DEBUG - 2017-02-13 10:19:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:25 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:25 --> Output Class Initialized
INFO - 2017-02-13 10:19:25 --> URI Class Initialized
INFO - 2017-02-13 10:19:25 --> Security Class Initialized
INFO - 2017-02-13 10:19:25 --> Router Class Initialized
INFO - 2017-02-13 10:19:25 --> Output Class Initialized
DEBUG - 2017-02-13 10:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:25 --> Input Class Initialized
INFO - 2017-02-13 10:19:25 --> Language Class Initialized
INFO - 2017-02-13 10:19:25 --> Security Class Initialized
INFO - 2017-02-13 10:19:25 --> Loader Class Initialized
INFO - 2017-02-13 10:19:25 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:25 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:25 --> Input Class Initialized
INFO - 2017-02-13 10:19:25 --> Language Class Initialized
INFO - 2017-02-13 10:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:25 --> Controller Class Initialized
INFO - 2017-02-13 10:19:25 --> Loader Class Initialized
INFO - 2017-02-13 10:19:25 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:25 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:25 --> Model Class Initialized
INFO - 2017-02-13 10:19:25 --> Model Class Initialized
INFO - 2017-02-13 10:19:25 --> Model Class Initialized
INFO - 2017-02-13 10:19:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:25 --> Total execution time: 0.2972
INFO - 2017-02-13 10:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:25 --> Controller Class Initialized
INFO - 2017-02-13 10:19:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:25 --> Model Class Initialized
INFO - 2017-02-13 10:19:25 --> Model Class Initialized
INFO - 2017-02-13 10:19:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:25 --> Total execution time: 0.3344
INFO - 2017-02-13 10:19:33 --> Config Class Initialized
INFO - 2017-02-13 10:19:33 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:33 --> Config Class Initialized
INFO - 2017-02-13 10:19:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:33 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:19:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:33 --> URI Class Initialized
INFO - 2017-02-13 10:19:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:33 --> Router Class Initialized
INFO - 2017-02-13 10:19:33 --> URI Class Initialized
INFO - 2017-02-13 10:19:33 --> Output Class Initialized
INFO - 2017-02-13 10:19:33 --> Router Class Initialized
INFO - 2017-02-13 10:19:33 --> Security Class Initialized
INFO - 2017-02-13 10:19:33 --> Output Class Initialized
DEBUG - 2017-02-13 10:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:33 --> Security Class Initialized
INFO - 2017-02-13 10:19:33 --> Input Class Initialized
INFO - 2017-02-13 10:19:33 --> Language Class Initialized
INFO - 2017-02-13 10:19:33 --> Loader Class Initialized
INFO - 2017-02-13 10:19:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:33 --> Controller Class Initialized
DEBUG - 2017-02-13 10:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:33 --> Input Class Initialized
INFO - 2017-02-13 10:19:33 --> Language Class Initialized
INFO - 2017-02-13 10:19:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:33 --> Loader Class Initialized
INFO - 2017-02-13 10:19:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:33 --> Model Class Initialized
INFO - 2017-02-13 10:19:33 --> Model Class Initialized
INFO - 2017-02-13 10:19:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:33 --> Total execution time: 0.1156
INFO - 2017-02-13 10:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:33 --> Controller Class Initialized
INFO - 2017-02-13 10:19:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:33 --> Model Class Initialized
INFO - 2017-02-13 10:19:33 --> Model Class Initialized
INFO - 2017-02-13 10:19:33 --> Model Class Initialized
INFO - 2017-02-13 10:19:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:33 --> Total execution time: 0.3131
INFO - 2017-02-13 10:19:37 --> Config Class Initialized
INFO - 2017-02-13 10:19:37 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:37 --> Config Class Initialized
INFO - 2017-02-13 10:19:37 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:37 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:37 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:37 --> URI Class Initialized
DEBUG - 2017-02-13 10:19:37 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:37 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:37 --> Router Class Initialized
INFO - 2017-02-13 10:19:37 --> URI Class Initialized
INFO - 2017-02-13 10:19:37 --> Router Class Initialized
INFO - 2017-02-13 10:19:37 --> Output Class Initialized
INFO - 2017-02-13 10:19:37 --> Output Class Initialized
INFO - 2017-02-13 10:19:37 --> Security Class Initialized
INFO - 2017-02-13 10:19:37 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:37 --> Input Class Initialized
INFO - 2017-02-13 10:19:37 --> Language Class Initialized
DEBUG - 2017-02-13 10:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:37 --> Input Class Initialized
INFO - 2017-02-13 10:19:37 --> Language Class Initialized
INFO - 2017-02-13 10:19:37 --> Loader Class Initialized
INFO - 2017-02-13 10:19:37 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:37 --> Loader Class Initialized
INFO - 2017-02-13 10:19:37 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:37 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:37 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:37 --> Controller Class Initialized
INFO - 2017-02-13 10:19:37 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:37 --> Model Class Initialized
INFO - 2017-02-13 10:19:37 --> Model Class Initialized
INFO - 2017-02-13 10:19:37 --> Model Class Initialized
INFO - 2017-02-13 10:19:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:37 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:37 --> Total execution time: 0.2861
INFO - 2017-02-13 10:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:37 --> Controller Class Initialized
INFO - 2017-02-13 10:19:37 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:37 --> Model Class Initialized
INFO - 2017-02-13 10:19:37 --> Model Class Initialized
INFO - 2017-02-13 10:19:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:37 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:37 --> Total execution time: 0.3251
INFO - 2017-02-13 10:19:41 --> Config Class Initialized
INFO - 2017-02-13 10:19:41 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:41 --> Config Class Initialized
INFO - 2017-02-13 10:19:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:41 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:19:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:41 --> URI Class Initialized
INFO - 2017-02-13 10:19:41 --> URI Class Initialized
INFO - 2017-02-13 10:19:41 --> Router Class Initialized
INFO - 2017-02-13 10:19:41 --> Router Class Initialized
INFO - 2017-02-13 10:19:41 --> Output Class Initialized
INFO - 2017-02-13 10:19:41 --> Security Class Initialized
INFO - 2017-02-13 10:19:41 --> Output Class Initialized
DEBUG - 2017-02-13 10:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:41 --> Input Class Initialized
INFO - 2017-02-13 10:19:41 --> Security Class Initialized
INFO - 2017-02-13 10:19:41 --> Language Class Initialized
INFO - 2017-02-13 10:19:41 --> Loader Class Initialized
INFO - 2017-02-13 10:19:41 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:41 --> Input Class Initialized
INFO - 2017-02-13 10:19:41 --> Language Class Initialized
INFO - 2017-02-13 10:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:41 --> Controller Class Initialized
INFO - 2017-02-13 10:19:41 --> Loader Class Initialized
INFO - 2017-02-13 10:19:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:41 --> Model Class Initialized
INFO - 2017-02-13 10:19:41 --> Model Class Initialized
INFO - 2017-02-13 10:19:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:41 --> Total execution time: 0.1825
INFO - 2017-02-13 10:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:41 --> Controller Class Initialized
INFO - 2017-02-13 10:19:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:41 --> Model Class Initialized
INFO - 2017-02-13 10:19:41 --> Model Class Initialized
INFO - 2017-02-13 10:19:41 --> Model Class Initialized
INFO - 2017-02-13 10:19:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:41 --> Total execution time: 0.6264
INFO - 2017-02-13 10:19:44 --> Config Class Initialized
INFO - 2017-02-13 10:19:44 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:44 --> Config Class Initialized
INFO - 2017-02-13 10:19:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:44 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:44 --> URI Class Initialized
INFO - 2017-02-13 10:19:44 --> Router Class Initialized
INFO - 2017-02-13 10:19:44 --> Output Class Initialized
INFO - 2017-02-13 10:19:44 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:44 --> Input Class Initialized
INFO - 2017-02-13 10:19:44 --> Language Class Initialized
INFO - 2017-02-13 10:19:44 --> Loader Class Initialized
DEBUG - 2017-02-13 10:19:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:44 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:44 --> URI Class Initialized
INFO - 2017-02-13 10:19:44 --> Router Class Initialized
INFO - 2017-02-13 10:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:44 --> Controller Class Initialized
INFO - 2017-02-13 10:19:44 --> Output Class Initialized
INFO - 2017-02-13 10:19:44 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:44 --> Input Class Initialized
INFO - 2017-02-13 10:19:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:44 --> Language Class Initialized
INFO - 2017-02-13 10:19:44 --> Model Class Initialized
INFO - 2017-02-13 10:19:44 --> Model Class Initialized
INFO - 2017-02-13 10:19:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:44 --> Loader Class Initialized
INFO - 2017-02-13 10:19:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:44 --> Final output sent to browser
INFO - 2017-02-13 10:19:44 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:19:44 --> Total execution time: 0.1036
INFO - 2017-02-13 10:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:44 --> Controller Class Initialized
INFO - 2017-02-13 10:19:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:44 --> Model Class Initialized
INFO - 2017-02-13 10:19:44 --> Model Class Initialized
INFO - 2017-02-13 10:19:44 --> Model Class Initialized
INFO - 2017-02-13 10:19:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:45 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:45 --> Total execution time: 0.3110
INFO - 2017-02-13 10:19:47 --> Config Class Initialized
INFO - 2017-02-13 10:19:47 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:47 --> Config Class Initialized
INFO - 2017-02-13 10:19:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:47 --> URI Class Initialized
DEBUG - 2017-02-13 10:19:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:47 --> Router Class Initialized
INFO - 2017-02-13 10:19:47 --> URI Class Initialized
INFO - 2017-02-13 10:19:47 --> Output Class Initialized
INFO - 2017-02-13 10:19:47 --> Security Class Initialized
INFO - 2017-02-13 10:19:47 --> Router Class Initialized
INFO - 2017-02-13 10:19:47 --> Output Class Initialized
DEBUG - 2017-02-13 10:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:47 --> Input Class Initialized
INFO - 2017-02-13 10:19:47 --> Security Class Initialized
INFO - 2017-02-13 10:19:47 --> Language Class Initialized
DEBUG - 2017-02-13 10:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:47 --> Input Class Initialized
INFO - 2017-02-13 10:19:47 --> Language Class Initialized
INFO - 2017-02-13 10:19:47 --> Loader Class Initialized
INFO - 2017-02-13 10:19:47 --> Loader Class Initialized
INFO - 2017-02-13 10:19:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:47 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:47 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:47 --> Controller Class Initialized
INFO - 2017-02-13 10:19:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:47 --> Model Class Initialized
INFO - 2017-02-13 10:19:47 --> Model Class Initialized
INFO - 2017-02-13 10:19:47 --> Model Class Initialized
INFO - 2017-02-13 10:19:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:48 --> Total execution time: 0.3958
INFO - 2017-02-13 10:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:48 --> Controller Class Initialized
INFO - 2017-02-13 10:19:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:48 --> Model Class Initialized
INFO - 2017-02-13 10:19:48 --> Model Class Initialized
INFO - 2017-02-13 10:19:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:48 --> Total execution time: 0.4339
INFO - 2017-02-13 10:19:51 --> Config Class Initialized
INFO - 2017-02-13 10:19:51 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:51 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:51 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:51 --> URI Class Initialized
INFO - 2017-02-13 10:19:51 --> Router Class Initialized
INFO - 2017-02-13 10:19:51 --> Output Class Initialized
INFO - 2017-02-13 10:19:51 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:51 --> Input Class Initialized
INFO - 2017-02-13 10:19:51 --> Language Class Initialized
INFO - 2017-02-13 10:19:51 --> Loader Class Initialized
INFO - 2017-02-13 10:19:51 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:51 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:51 --> Controller Class Initialized
INFO - 2017-02-13 10:19:51 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:51 --> Model Class Initialized
INFO - 2017-02-13 10:19:51 --> Model Class Initialized
INFO - 2017-02-13 10:19:51 --> Model Class Initialized
INFO - 2017-02-13 10:19:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:51 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:51 --> Total execution time: 0.0896
INFO - 2017-02-13 10:19:53 --> Config Class Initialized
INFO - 2017-02-13 10:19:53 --> Config Class Initialized
INFO - 2017-02-13 10:19:53 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:19:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:53 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:53 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:53 --> URI Class Initialized
INFO - 2017-02-13 10:19:53 --> URI Class Initialized
INFO - 2017-02-13 10:19:53 --> Router Class Initialized
INFO - 2017-02-13 10:19:53 --> Router Class Initialized
INFO - 2017-02-13 10:19:53 --> Output Class Initialized
INFO - 2017-02-13 10:19:53 --> Output Class Initialized
INFO - 2017-02-13 10:19:53 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:53 --> Input Class Initialized
INFO - 2017-02-13 10:19:53 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:53 --> Input Class Initialized
INFO - 2017-02-13 10:19:53 --> Language Class Initialized
INFO - 2017-02-13 10:19:53 --> Language Class Initialized
INFO - 2017-02-13 10:19:53 --> Loader Class Initialized
INFO - 2017-02-13 10:19:53 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:53 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:53 --> Controller Class Initialized
INFO - 2017-02-13 10:19:53 --> Loader Class Initialized
INFO - 2017-02-13 10:19:53 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:53 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:53 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:53 --> Model Class Initialized
INFO - 2017-02-13 10:19:53 --> Model Class Initialized
INFO - 2017-02-13 10:19:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:53 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:53 --> Total execution time: 0.1276
INFO - 2017-02-13 10:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:53 --> Controller Class Initialized
INFO - 2017-02-13 10:19:53 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:53 --> Model Class Initialized
INFO - 2017-02-13 10:19:53 --> Model Class Initialized
INFO - 2017-02-13 10:19:53 --> Model Class Initialized
INFO - 2017-02-13 10:19:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:53 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:53 --> Total execution time: 0.5452
INFO - 2017-02-13 10:19:56 --> Config Class Initialized
INFO - 2017-02-13 10:19:56 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:56 --> Config Class Initialized
INFO - 2017-02-13 10:19:56 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:56 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:19:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:56 --> URI Class Initialized
INFO - 2017-02-13 10:19:56 --> URI Class Initialized
INFO - 2017-02-13 10:19:56 --> Router Class Initialized
INFO - 2017-02-13 10:19:56 --> Router Class Initialized
INFO - 2017-02-13 10:19:56 --> Output Class Initialized
INFO - 2017-02-13 10:19:56 --> Config Class Initialized
INFO - 2017-02-13 10:19:56 --> Hooks Class Initialized
INFO - 2017-02-13 10:19:56 --> Output Class Initialized
INFO - 2017-02-13 10:19:56 --> Security Class Initialized
INFO - 2017-02-13 10:19:56 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:56 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:56 --> Input Class Initialized
INFO - 2017-02-13 10:19:56 --> URI Class Initialized
INFO - 2017-02-13 10:19:56 --> Language Class Initialized
DEBUG - 2017-02-13 10:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:56 --> Input Class Initialized
INFO - 2017-02-13 10:19:56 --> Router Class Initialized
INFO - 2017-02-13 10:19:56 --> Language Class Initialized
INFO - 2017-02-13 10:19:56 --> Output Class Initialized
INFO - 2017-02-13 10:19:56 --> Loader Class Initialized
INFO - 2017-02-13 10:19:56 --> Security Class Initialized
INFO - 2017-02-13 10:19:56 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:56 --> Input Class Initialized
INFO - 2017-02-13 10:19:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:56 --> Language Class Initialized
INFO - 2017-02-13 10:19:57 --> Loader Class Initialized
INFO - 2017-02-13 10:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:57 --> Controller Class Initialized
INFO - 2017-02-13 10:19:57 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:57 --> Loader Class Initialized
INFO - 2017-02-13 10:19:57 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:57 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:57 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:57 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:57 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:57 --> Total execution time: 0.1302
INFO - 2017-02-13 10:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:57 --> Controller Class Initialized
INFO - 2017-02-13 10:19:57 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:57 --> Controller Class Initialized
INFO - 2017-02-13 10:19:57 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:57 --> Config Class Initialized
INFO - 2017-02-13 10:19:57 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:57 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:57 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> URI Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Router Class Initialized
INFO - 2017-02-13 10:19:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:57 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:57 --> Total execution time: 0.2846
INFO - 2017-02-13 10:19:57 --> Output Class Initialized
INFO - 2017-02-13 10:19:57 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:57 --> Input Class Initialized
INFO - 2017-02-13 10:19:57 --> Language Class Initialized
INFO - 2017-02-13 10:19:57 --> Loader Class Initialized
INFO - 2017-02-13 10:19:57 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:57 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:57 --> Controller Class Initialized
INFO - 2017-02-13 10:19:57 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Model Class Initialized
INFO - 2017-02-13 10:19:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:19:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05.php
INFO - 2017-02-13 10:19:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:19:57 --> Final output sent to browser
DEBUG - 2017-02-13 10:19:57 --> Total execution time: 0.1582
INFO - 2017-02-13 10:19:59 --> Config Class Initialized
INFO - 2017-02-13 10:19:59 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:59 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:59 --> URI Class Initialized
INFO - 2017-02-13 10:19:59 --> Router Class Initialized
INFO - 2017-02-13 10:19:59 --> Output Class Initialized
INFO - 2017-02-13 10:19:59 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:59 --> Input Class Initialized
INFO - 2017-02-13 10:19:59 --> Language Class Initialized
INFO - 2017-02-13 10:19:59 --> Loader Class Initialized
INFO - 2017-02-13 10:19:59 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:59 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:59 --> Controller Class Initialized
INFO - 2017-02-13 10:19:59 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:59 --> Model Class Initialized
INFO - 2017-02-13 10:19:59 --> Model Class Initialized
INFO - 2017-02-13 10:19:59 --> Model Class Initialized
INFO - 2017-02-13 10:19:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:19:59 --> Config Class Initialized
INFO - 2017-02-13 10:19:59 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:19:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:19:59 --> Utf8 Class Initialized
INFO - 2017-02-13 10:19:59 --> URI Class Initialized
INFO - 2017-02-13 10:19:59 --> Router Class Initialized
INFO - 2017-02-13 10:19:59 --> Output Class Initialized
INFO - 2017-02-13 10:19:59 --> Security Class Initialized
DEBUG - 2017-02-13 10:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:19:59 --> Input Class Initialized
INFO - 2017-02-13 10:19:59 --> Language Class Initialized
INFO - 2017-02-13 10:19:59 --> Loader Class Initialized
INFO - 2017-02-13 10:19:59 --> Helper loaded: url_helper
INFO - 2017-02-13 10:19:59 --> Helper loaded: language_helper
INFO - 2017-02-13 10:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:19:59 --> Controller Class Initialized
INFO - 2017-02-13 10:19:59 --> Database Driver Class Initialized
INFO - 2017-02-13 10:19:59 --> Model Class Initialized
INFO - 2017-02-13 10:19:59 --> Model Class Initialized
INFO - 2017-02-13 10:19:59 --> Model Class Initialized
INFO - 2017-02-13 10:19:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:20:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_05_attempt.php
INFO - 2017-02-13 10:20:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:20:00 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:00 --> Total execution time: 0.2079
INFO - 2017-02-13 10:20:00 --> Config Class Initialized
INFO - 2017-02-13 10:20:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:00 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:00 --> URI Class Initialized
INFO - 2017-02-13 10:20:00 --> Router Class Initialized
INFO - 2017-02-13 10:20:00 --> Output Class Initialized
INFO - 2017-02-13 10:20:00 --> Config Class Initialized
INFO - 2017-02-13 10:20:00 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:00 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:00 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:00 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:00 --> Input Class Initialized
INFO - 2017-02-13 10:20:00 --> Language Class Initialized
INFO - 2017-02-13 10:20:00 --> Router Class Initialized
INFO - 2017-02-13 10:20:00 --> Output Class Initialized
INFO - 2017-02-13 10:20:00 --> Loader Class Initialized
INFO - 2017-02-13 10:20:00 --> Security Class Initialized
INFO - 2017-02-13 10:20:00 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:00 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:00 --> Input Class Initialized
INFO - 2017-02-13 10:20:00 --> Language Class Initialized
INFO - 2017-02-13 10:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:00 --> Controller Class Initialized
INFO - 2017-02-13 10:20:00 --> Loader Class Initialized
INFO - 2017-02-13 10:20:00 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:00 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:00 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:00 --> Model Class Initialized
INFO - 2017-02-13 10:20:00 --> Model Class Initialized
INFO - 2017-02-13 10:20:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:00 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:00 --> Total execution time: 0.1333
INFO - 2017-02-13 10:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:00 --> Controller Class Initialized
INFO - 2017-02-13 10:20:00 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:00 --> Model Class Initialized
INFO - 2017-02-13 10:20:00 --> Model Class Initialized
INFO - 2017-02-13 10:20:00 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:20:00 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:20:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:20:00 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:00 --> Total execution time: 0.2498
INFO - 2017-02-13 10:20:03 --> Config Class Initialized
INFO - 2017-02-13 10:20:03 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:03 --> Config Class Initialized
INFO - 2017-02-13 10:20:03 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:03 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:03 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:03 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:03 --> URI Class Initialized
INFO - 2017-02-13 10:20:03 --> Router Class Initialized
INFO - 2017-02-13 10:20:03 --> Output Class Initialized
INFO - 2017-02-13 10:20:03 --> Router Class Initialized
INFO - 2017-02-13 10:20:03 --> Security Class Initialized
INFO - 2017-02-13 10:20:03 --> Output Class Initialized
DEBUG - 2017-02-13 10:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:03 --> Input Class Initialized
INFO - 2017-02-13 10:20:03 --> Security Class Initialized
INFO - 2017-02-13 10:20:03 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:03 --> Loader Class Initialized
INFO - 2017-02-13 10:20:03 --> Input Class Initialized
INFO - 2017-02-13 10:20:03 --> Language Class Initialized
INFO - 2017-02-13 10:20:03 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:03 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:03 --> Controller Class Initialized
INFO - 2017-02-13 10:20:03 --> Loader Class Initialized
INFO - 2017-02-13 10:20:03 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:03 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:03 --> Model Class Initialized
INFO - 2017-02-13 10:20:03 --> Model Class Initialized
INFO - 2017-02-13 10:20:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:03 --> Total execution time: 0.1076
INFO - 2017-02-13 10:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:03 --> Controller Class Initialized
INFO - 2017-02-13 10:20:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:03 --> Model Class Initialized
INFO - 2017-02-13 10:20:03 --> Model Class Initialized
INFO - 2017-02-13 10:20:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:03 --> Total execution time: 0.2304
INFO - 2017-02-13 10:20:05 --> Config Class Initialized
INFO - 2017-02-13 10:20:05 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:05 --> Config Class Initialized
INFO - 2017-02-13 10:20:05 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:05 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:05 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:05 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:05 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:05 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:05 --> Router Class Initialized
INFO - 2017-02-13 10:20:05 --> URI Class Initialized
INFO - 2017-02-13 10:20:05 --> Output Class Initialized
INFO - 2017-02-13 10:20:05 --> Router Class Initialized
INFO - 2017-02-13 10:20:05 --> Security Class Initialized
INFO - 2017-02-13 10:20:05 --> Output Class Initialized
INFO - 2017-02-13 10:20:05 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:05 --> Input Class Initialized
DEBUG - 2017-02-13 10:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:05 --> Input Class Initialized
INFO - 2017-02-13 10:20:05 --> Language Class Initialized
INFO - 2017-02-13 10:20:05 --> Language Class Initialized
INFO - 2017-02-13 10:20:05 --> Loader Class Initialized
INFO - 2017-02-13 10:20:05 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:05 --> Loader Class Initialized
INFO - 2017-02-13 10:20:05 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:05 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:05 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:05 --> Controller Class Initialized
INFO - 2017-02-13 10:20:05 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:05 --> Model Class Initialized
INFO - 2017-02-13 10:20:05 --> Model Class Initialized
INFO - 2017-02-13 10:20:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:05 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:05 --> Total execution time: 0.2338
INFO - 2017-02-13 10:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:05 --> Controller Class Initialized
INFO - 2017-02-13 10:20:05 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:05 --> Model Class Initialized
INFO - 2017-02-13 10:20:05 --> Model Class Initialized
INFO - 2017-02-13 10:20:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:05 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:05 --> Total execution time: 0.2950
INFO - 2017-02-13 10:20:07 --> Config Class Initialized
INFO - 2017-02-13 10:20:07 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:07 --> Config Class Initialized
INFO - 2017-02-13 10:20:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:07 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:07 --> Router Class Initialized
INFO - 2017-02-13 10:20:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:07 --> Output Class Initialized
INFO - 2017-02-13 10:20:07 --> URI Class Initialized
INFO - 2017-02-13 10:20:07 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:07 --> Router Class Initialized
INFO - 2017-02-13 10:20:07 --> Input Class Initialized
INFO - 2017-02-13 10:20:07 --> Language Class Initialized
INFO - 2017-02-13 10:20:07 --> Output Class Initialized
INFO - 2017-02-13 10:20:07 --> Security Class Initialized
INFO - 2017-02-13 10:20:07 --> Loader Class Initialized
INFO - 2017-02-13 10:20:07 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:07 --> Input Class Initialized
INFO - 2017-02-13 10:20:07 --> Language Class Initialized
INFO - 2017-02-13 10:20:07 --> Loader Class Initialized
INFO - 2017-02-13 10:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:07 --> Controller Class Initialized
INFO - 2017-02-13 10:20:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:07 --> Model Class Initialized
INFO - 2017-02-13 10:20:07 --> Model Class Initialized
INFO - 2017-02-13 10:20:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:07 --> Total execution time: 0.1182
INFO - 2017-02-13 10:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:07 --> Controller Class Initialized
INFO - 2017-02-13 10:20:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:07 --> Model Class Initialized
INFO - 2017-02-13 10:20:07 --> Model Class Initialized
INFO - 2017-02-13 10:20:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:07 --> Total execution time: 0.3287
INFO - 2017-02-13 10:20:09 --> Config Class Initialized
INFO - 2017-02-13 10:20:09 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:09 --> Config Class Initialized
INFO - 2017-02-13 10:20:09 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:09 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:09 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:09 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:09 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:09 --> Router Class Initialized
INFO - 2017-02-13 10:20:09 --> URI Class Initialized
INFO - 2017-02-13 10:20:09 --> Output Class Initialized
INFO - 2017-02-13 10:20:09 --> Router Class Initialized
INFO - 2017-02-13 10:20:09 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:09 --> Input Class Initialized
INFO - 2017-02-13 10:20:09 --> Language Class Initialized
INFO - 2017-02-13 10:20:09 --> Output Class Initialized
INFO - 2017-02-13 10:20:09 --> Security Class Initialized
INFO - 2017-02-13 10:20:09 --> Loader Class Initialized
DEBUG - 2017-02-13 10:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:09 --> Input Class Initialized
INFO - 2017-02-13 10:20:09 --> Language Class Initialized
INFO - 2017-02-13 10:20:09 --> Loader Class Initialized
INFO - 2017-02-13 10:20:09 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:09 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:09 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:09 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:09 --> Controller Class Initialized
INFO - 2017-02-13 10:20:09 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:09 --> Model Class Initialized
INFO - 2017-02-13 10:20:09 --> Model Class Initialized
INFO - 2017-02-13 10:20:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:09 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:09 --> Total execution time: 0.2373
INFO - 2017-02-13 10:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:09 --> Controller Class Initialized
INFO - 2017-02-13 10:20:09 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:09 --> Model Class Initialized
INFO - 2017-02-13 10:20:09 --> Model Class Initialized
INFO - 2017-02-13 10:20:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:09 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:09 --> Total execution time: 0.2825
INFO - 2017-02-13 10:20:11 --> Config Class Initialized
INFO - 2017-02-13 10:20:11 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:11 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:11 --> Config Class Initialized
INFO - 2017-02-13 10:20:11 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:11 --> URI Class Initialized
INFO - 2017-02-13 10:20:11 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:11 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:11 --> Output Class Initialized
INFO - 2017-02-13 10:20:11 --> Security Class Initialized
INFO - 2017-02-13 10:20:11 --> URI Class Initialized
INFO - 2017-02-13 10:20:11 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:11 --> Input Class Initialized
INFO - 2017-02-13 10:20:11 --> Language Class Initialized
INFO - 2017-02-13 10:20:11 --> Output Class Initialized
INFO - 2017-02-13 10:20:11 --> Security Class Initialized
INFO - 2017-02-13 10:20:11 --> Loader Class Initialized
INFO - 2017-02-13 10:20:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:11 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:11 --> Input Class Initialized
INFO - 2017-02-13 10:20:11 --> Language Class Initialized
INFO - 2017-02-13 10:20:11 --> Loader Class Initialized
INFO - 2017-02-13 10:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:11 --> Controller Class Initialized
INFO - 2017-02-13 10:20:11 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:11 --> Model Class Initialized
INFO - 2017-02-13 10:20:11 --> Model Class Initialized
INFO - 2017-02-13 10:20:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:11 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:11 --> Total execution time: 0.1610
INFO - 2017-02-13 10:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:11 --> Controller Class Initialized
INFO - 2017-02-13 10:20:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:11 --> Model Class Initialized
INFO - 2017-02-13 10:20:11 --> Model Class Initialized
INFO - 2017-02-13 10:20:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:12 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:12 --> Total execution time: 0.4251
INFO - 2017-02-13 10:20:13 --> Config Class Initialized
INFO - 2017-02-13 10:20:13 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:13 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:13 --> Config Class Initialized
INFO - 2017-02-13 10:20:13 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:13 --> URI Class Initialized
INFO - 2017-02-13 10:20:13 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:13 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:13 --> Output Class Initialized
INFO - 2017-02-13 10:20:13 --> URI Class Initialized
INFO - 2017-02-13 10:20:13 --> Security Class Initialized
INFO - 2017-02-13 10:20:13 --> Router Class Initialized
INFO - 2017-02-13 10:20:13 --> Output Class Initialized
DEBUG - 2017-02-13 10:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:13 --> Input Class Initialized
INFO - 2017-02-13 10:20:13 --> Security Class Initialized
INFO - 2017-02-13 10:20:13 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:13 --> Input Class Initialized
INFO - 2017-02-13 10:20:13 --> Language Class Initialized
INFO - 2017-02-13 10:20:13 --> Loader Class Initialized
INFO - 2017-02-13 10:20:13 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:13 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:13 --> Loader Class Initialized
INFO - 2017-02-13 10:20:13 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:13 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:13 --> Controller Class Initialized
INFO - 2017-02-13 10:20:13 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:13 --> Model Class Initialized
INFO - 2017-02-13 10:20:13 --> Model Class Initialized
INFO - 2017-02-13 10:20:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:14 --> Total execution time: 0.4150
INFO - 2017-02-13 10:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:14 --> Controller Class Initialized
INFO - 2017-02-13 10:20:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:14 --> Model Class Initialized
INFO - 2017-02-13 10:20:14 --> Model Class Initialized
INFO - 2017-02-13 10:20:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:14 --> Total execution time: 0.4609
INFO - 2017-02-13 10:20:16 --> Config Class Initialized
INFO - 2017-02-13 10:20:16 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:16 --> Config Class Initialized
INFO - 2017-02-13 10:20:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:16 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:16 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:16 --> URI Class Initialized
INFO - 2017-02-13 10:20:16 --> Router Class Initialized
INFO - 2017-02-13 10:20:16 --> URI Class Initialized
INFO - 2017-02-13 10:20:16 --> Output Class Initialized
INFO - 2017-02-13 10:20:16 --> Router Class Initialized
INFO - 2017-02-13 10:20:16 --> Security Class Initialized
INFO - 2017-02-13 10:20:16 --> Output Class Initialized
INFO - 2017-02-13 10:20:16 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:16 --> Input Class Initialized
DEBUG - 2017-02-13 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:16 --> Input Class Initialized
INFO - 2017-02-13 10:20:16 --> Language Class Initialized
INFO - 2017-02-13 10:20:16 --> Language Class Initialized
INFO - 2017-02-13 10:20:16 --> Loader Class Initialized
INFO - 2017-02-13 10:20:16 --> Loader Class Initialized
INFO - 2017-02-13 10:20:16 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:16 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:16 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:16 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:16 --> Controller Class Initialized
INFO - 2017-02-13 10:20:16 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:16 --> Model Class Initialized
INFO - 2017-02-13 10:20:16 --> Model Class Initialized
INFO - 2017-02-13 10:20:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:16 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:16 --> Total execution time: 0.3301
INFO - 2017-02-13 10:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:16 --> Controller Class Initialized
INFO - 2017-02-13 10:20:16 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:16 --> Model Class Initialized
INFO - 2017-02-13 10:20:16 --> Model Class Initialized
INFO - 2017-02-13 10:20:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:16 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:16 --> Total execution time: 0.3823
INFO - 2017-02-13 10:20:18 --> Config Class Initialized
INFO - 2017-02-13 10:20:18 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:18 --> Config Class Initialized
INFO - 2017-02-13 10:20:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:18 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:18 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:18 --> URI Class Initialized
INFO - 2017-02-13 10:20:18 --> URI Class Initialized
INFO - 2017-02-13 10:20:18 --> Router Class Initialized
INFO - 2017-02-13 10:20:18 --> Router Class Initialized
INFO - 2017-02-13 10:20:18 --> Output Class Initialized
INFO - 2017-02-13 10:20:18 --> Output Class Initialized
INFO - 2017-02-13 10:20:18 --> Security Class Initialized
INFO - 2017-02-13 10:20:18 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:18 --> Input Class Initialized
INFO - 2017-02-13 10:20:18 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:18 --> Input Class Initialized
INFO - 2017-02-13 10:20:18 --> Language Class Initialized
INFO - 2017-02-13 10:20:18 --> Loader Class Initialized
INFO - 2017-02-13 10:20:18 --> Loader Class Initialized
INFO - 2017-02-13 10:20:18 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:18 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:18 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:18 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:18 --> Controller Class Initialized
INFO - 2017-02-13 10:20:18 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:18 --> Model Class Initialized
INFO - 2017-02-13 10:20:18 --> Model Class Initialized
INFO - 2017-02-13 10:20:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:18 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:18 --> Total execution time: 0.1359
INFO - 2017-02-13 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:18 --> Controller Class Initialized
INFO - 2017-02-13 10:20:18 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:18 --> Model Class Initialized
INFO - 2017-02-13 10:20:18 --> Model Class Initialized
INFO - 2017-02-13 10:20:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:18 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:18 --> Total execution time: 0.4057
INFO - 2017-02-13 10:20:20 --> Config Class Initialized
INFO - 2017-02-13 10:20:20 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:20 --> Config Class Initialized
INFO - 2017-02-13 10:20:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:20 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:20 --> URI Class Initialized
INFO - 2017-02-13 10:20:20 --> URI Class Initialized
INFO - 2017-02-13 10:20:20 --> Router Class Initialized
INFO - 2017-02-13 10:20:20 --> Router Class Initialized
INFO - 2017-02-13 10:20:20 --> Output Class Initialized
INFO - 2017-02-13 10:20:20 --> Output Class Initialized
INFO - 2017-02-13 10:20:20 --> Security Class Initialized
INFO - 2017-02-13 10:20:20 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:20 --> Input Class Initialized
INFO - 2017-02-13 10:20:20 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:20 --> Input Class Initialized
INFO - 2017-02-13 10:20:20 --> Language Class Initialized
INFO - 2017-02-13 10:20:20 --> Loader Class Initialized
INFO - 2017-02-13 10:20:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:20 --> Loader Class Initialized
INFO - 2017-02-13 10:20:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:20 --> Controller Class Initialized
INFO - 2017-02-13 10:20:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:20 --> Model Class Initialized
INFO - 2017-02-13 10:20:20 --> Model Class Initialized
INFO - 2017-02-13 10:20:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:20 --> Total execution time: 0.1118
INFO - 2017-02-13 10:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:20 --> Controller Class Initialized
INFO - 2017-02-13 10:20:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:20 --> Model Class Initialized
INFO - 2017-02-13 10:20:20 --> Model Class Initialized
INFO - 2017-02-13 10:20:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:21 --> Total execution time: 0.3535
INFO - 2017-02-13 10:20:22 --> Config Class Initialized
INFO - 2017-02-13 10:20:22 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:22 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:22 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:22 --> Config Class Initialized
INFO - 2017-02-13 10:20:22 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:22 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:22 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:22 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:22 --> Router Class Initialized
INFO - 2017-02-13 10:20:22 --> Output Class Initialized
INFO - 2017-02-13 10:20:22 --> Security Class Initialized
INFO - 2017-02-13 10:20:22 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:22 --> Input Class Initialized
INFO - 2017-02-13 10:20:22 --> Language Class Initialized
INFO - 2017-02-13 10:20:22 --> Router Class Initialized
INFO - 2017-02-13 10:20:22 --> Output Class Initialized
INFO - 2017-02-13 10:20:22 --> Loader Class Initialized
INFO - 2017-02-13 10:20:22 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:22 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:22 --> Security Class Initialized
INFO - 2017-02-13 10:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:22 --> Controller Class Initialized
DEBUG - 2017-02-13 10:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:22 --> Input Class Initialized
INFO - 2017-02-13 10:20:22 --> Language Class Initialized
INFO - 2017-02-13 10:20:22 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:22 --> Loader Class Initialized
INFO - 2017-02-13 10:20:22 --> Model Class Initialized
INFO - 2017-02-13 10:20:22 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:22 --> Model Class Initialized
INFO - 2017-02-13 10:20:22 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:22 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:22 --> Total execution time: 0.1269
INFO - 2017-02-13 10:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:22 --> Controller Class Initialized
INFO - 2017-02-13 10:20:22 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:22 --> Model Class Initialized
INFO - 2017-02-13 10:20:23 --> Model Class Initialized
INFO - 2017-02-13 10:20:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:23 --> Total execution time: 0.4353
INFO - 2017-02-13 10:20:24 --> Config Class Initialized
INFO - 2017-02-13 10:20:24 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:24 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:24 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:24 --> Config Class Initialized
INFO - 2017-02-13 10:20:24 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:24 --> URI Class Initialized
INFO - 2017-02-13 10:20:24 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:24 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:24 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:24 --> Output Class Initialized
INFO - 2017-02-13 10:20:24 --> URI Class Initialized
INFO - 2017-02-13 10:20:24 --> Security Class Initialized
INFO - 2017-02-13 10:20:24 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:24 --> Input Class Initialized
INFO - 2017-02-13 10:20:24 --> Language Class Initialized
INFO - 2017-02-13 10:20:24 --> Output Class Initialized
INFO - 2017-02-13 10:20:24 --> Loader Class Initialized
INFO - 2017-02-13 10:20:24 --> Security Class Initialized
INFO - 2017-02-13 10:20:24 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:24 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:24 --> Input Class Initialized
INFO - 2017-02-13 10:20:24 --> Language Class Initialized
INFO - 2017-02-13 10:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:24 --> Controller Class Initialized
INFO - 2017-02-13 10:20:24 --> Loader Class Initialized
INFO - 2017-02-13 10:20:24 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:24 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:24 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:24 --> Model Class Initialized
INFO - 2017-02-13 10:20:24 --> Model Class Initialized
INFO - 2017-02-13 10:20:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:24 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:24 --> Total execution time: 0.1208
INFO - 2017-02-13 10:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:24 --> Controller Class Initialized
INFO - 2017-02-13 10:20:24 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:24 --> Model Class Initialized
INFO - 2017-02-13 10:20:24 --> Model Class Initialized
INFO - 2017-02-13 10:20:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:25 --> Total execution time: 0.3116
INFO - 2017-02-13 10:20:27 --> Config Class Initialized
INFO - 2017-02-13 10:20:27 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:27 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:27 --> Config Class Initialized
INFO - 2017-02-13 10:20:27 --> URI Class Initialized
INFO - 2017-02-13 10:20:27 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:27 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:27 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:27 --> Output Class Initialized
INFO - 2017-02-13 10:20:27 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:27 --> Security Class Initialized
INFO - 2017-02-13 10:20:27 --> URI Class Initialized
INFO - 2017-02-13 10:20:27 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:27 --> Input Class Initialized
INFO - 2017-02-13 10:20:27 --> Output Class Initialized
INFO - 2017-02-13 10:20:27 --> Language Class Initialized
INFO - 2017-02-13 10:20:27 --> Security Class Initialized
INFO - 2017-02-13 10:20:27 --> Loader Class Initialized
DEBUG - 2017-02-13 10:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:27 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:27 --> Input Class Initialized
INFO - 2017-02-13 10:20:27 --> Language Class Initialized
INFO - 2017-02-13 10:20:27 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:27 --> Loader Class Initialized
INFO - 2017-02-13 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:27 --> Controller Class Initialized
INFO - 2017-02-13 10:20:27 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:27 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:27 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:27 --> Model Class Initialized
INFO - 2017-02-13 10:20:27 --> Model Class Initialized
INFO - 2017-02-13 10:20:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:27 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:27 --> Total execution time: 0.1321
INFO - 2017-02-13 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:27 --> Controller Class Initialized
INFO - 2017-02-13 10:20:27 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:27 --> Model Class Initialized
INFO - 2017-02-13 10:20:27 --> Model Class Initialized
INFO - 2017-02-13 10:20:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:27 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:27 --> Total execution time: 0.5390
INFO - 2017-02-13 10:20:29 --> Config Class Initialized
INFO - 2017-02-13 10:20:29 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:29 --> Config Class Initialized
INFO - 2017-02-13 10:20:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:29 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:29 --> URI Class Initialized
INFO - 2017-02-13 10:20:29 --> URI Class Initialized
INFO - 2017-02-13 10:20:29 --> Router Class Initialized
INFO - 2017-02-13 10:20:29 --> Router Class Initialized
INFO - 2017-02-13 10:20:29 --> Output Class Initialized
INFO - 2017-02-13 10:20:29 --> Output Class Initialized
INFO - 2017-02-13 10:20:29 --> Security Class Initialized
INFO - 2017-02-13 10:20:29 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:29 --> Input Class Initialized
INFO - 2017-02-13 10:20:29 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:29 --> Input Class Initialized
INFO - 2017-02-13 10:20:29 --> Language Class Initialized
INFO - 2017-02-13 10:20:29 --> Loader Class Initialized
INFO - 2017-02-13 10:20:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:29 --> Loader Class Initialized
INFO - 2017-02-13 10:20:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:29 --> Controller Class Initialized
INFO - 2017-02-13 10:20:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:29 --> Model Class Initialized
INFO - 2017-02-13 10:20:29 --> Model Class Initialized
INFO - 2017-02-13 10:20:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:29 --> Total execution time: 0.1186
INFO - 2017-02-13 10:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:29 --> Controller Class Initialized
INFO - 2017-02-13 10:20:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:29 --> Model Class Initialized
INFO - 2017-02-13 10:20:29 --> Model Class Initialized
INFO - 2017-02-13 10:20:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:29 --> Total execution time: 0.3963
INFO - 2017-02-13 10:20:30 --> Config Class Initialized
INFO - 2017-02-13 10:20:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:30 --> URI Class Initialized
INFO - 2017-02-13 10:20:30 --> Router Class Initialized
INFO - 2017-02-13 10:20:30 --> Output Class Initialized
INFO - 2017-02-13 10:20:30 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:30 --> Input Class Initialized
INFO - 2017-02-13 10:20:30 --> Language Class Initialized
INFO - 2017-02-13 10:20:30 --> Loader Class Initialized
INFO - 2017-02-13 10:20:30 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:30 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:30 --> Controller Class Initialized
INFO - 2017-02-13 10:20:30 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:30 --> Model Class Initialized
INFO - 2017-02-13 10:20:30 --> Model Class Initialized
INFO - 2017-02-13 10:20:30 --> Model Class Initialized
INFO - 2017-02-13 10:20:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:30 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:30 --> Total execution time: 0.1130
INFO - 2017-02-13 10:20:31 --> Config Class Initialized
INFO - 2017-02-13 10:20:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:31 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:31 --> URI Class Initialized
INFO - 2017-02-13 10:20:31 --> Router Class Initialized
INFO - 2017-02-13 10:20:31 --> Config Class Initialized
INFO - 2017-02-13 10:20:31 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:31 --> Output Class Initialized
INFO - 2017-02-13 10:20:31 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:31 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:31 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:31 --> Input Class Initialized
INFO - 2017-02-13 10:20:31 --> Language Class Initialized
INFO - 2017-02-13 10:20:31 --> Router Class Initialized
INFO - 2017-02-13 10:20:31 --> Loader Class Initialized
INFO - 2017-02-13 10:20:31 --> Output Class Initialized
INFO - 2017-02-13 10:20:31 --> Security Class Initialized
INFO - 2017-02-13 10:20:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:31 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:31 --> Input Class Initialized
INFO - 2017-02-13 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:31 --> Language Class Initialized
INFO - 2017-02-13 10:20:31 --> Controller Class Initialized
INFO - 2017-02-13 10:20:31 --> Loader Class Initialized
INFO - 2017-02-13 10:20:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:31 --> Model Class Initialized
INFO - 2017-02-13 10:20:31 --> Model Class Initialized
INFO - 2017-02-13 10:20:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:31 --> Total execution time: 0.1334
INFO - 2017-02-13 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:31 --> Controller Class Initialized
INFO - 2017-02-13 10:20:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:31 --> Model Class Initialized
INFO - 2017-02-13 10:20:31 --> Model Class Initialized
INFO - 2017-02-13 10:20:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:32 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:32 --> Total execution time: 0.4932
INFO - 2017-02-13 10:20:33 --> Config Class Initialized
INFO - 2017-02-13 10:20:33 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:33 --> Config Class Initialized
INFO - 2017-02-13 10:20:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:33 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:33 --> URI Class Initialized
INFO - 2017-02-13 10:20:33 --> Router Class Initialized
INFO - 2017-02-13 10:20:33 --> Router Class Initialized
INFO - 2017-02-13 10:20:33 --> Output Class Initialized
INFO - 2017-02-13 10:20:33 --> Output Class Initialized
INFO - 2017-02-13 10:20:33 --> Security Class Initialized
INFO - 2017-02-13 10:20:33 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:33 --> Input Class Initialized
INFO - 2017-02-13 10:20:33 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:33 --> Input Class Initialized
INFO - 2017-02-13 10:20:33 --> Language Class Initialized
INFO - 2017-02-13 10:20:33 --> Loader Class Initialized
INFO - 2017-02-13 10:20:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:33 --> Loader Class Initialized
INFO - 2017-02-13 10:20:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:33 --> Controller Class Initialized
INFO - 2017-02-13 10:20:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:33 --> Model Class Initialized
INFO - 2017-02-13 10:20:33 --> Model Class Initialized
INFO - 2017-02-13 10:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:33 --> Total execution time: 0.1183
INFO - 2017-02-13 10:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:33 --> Controller Class Initialized
INFO - 2017-02-13 10:20:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:33 --> Model Class Initialized
INFO - 2017-02-13 10:20:33 --> Model Class Initialized
INFO - 2017-02-13 10:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:34 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:34 --> Total execution time: 0.4580
INFO - 2017-02-13 10:20:36 --> Config Class Initialized
INFO - 2017-02-13 10:20:36 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:36 --> Config Class Initialized
INFO - 2017-02-13 10:20:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:36 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:36 --> URI Class Initialized
INFO - 2017-02-13 10:20:36 --> URI Class Initialized
INFO - 2017-02-13 10:20:36 --> Router Class Initialized
INFO - 2017-02-13 10:20:36 --> Router Class Initialized
INFO - 2017-02-13 10:20:36 --> Output Class Initialized
INFO - 2017-02-13 10:20:36 --> Output Class Initialized
INFO - 2017-02-13 10:20:36 --> Security Class Initialized
INFO - 2017-02-13 10:20:36 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:36 --> Input Class Initialized
INFO - 2017-02-13 10:20:36 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:36 --> Input Class Initialized
INFO - 2017-02-13 10:20:36 --> Loader Class Initialized
INFO - 2017-02-13 10:20:36 --> Language Class Initialized
INFO - 2017-02-13 10:20:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:36 --> Loader Class Initialized
INFO - 2017-02-13 10:20:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:36 --> Controller Class Initialized
INFO - 2017-02-13 10:20:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:36 --> Model Class Initialized
INFO - 2017-02-13 10:20:36 --> Model Class Initialized
INFO - 2017-02-13 10:20:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:36 --> Total execution time: 0.1154
INFO - 2017-02-13 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:36 --> Controller Class Initialized
INFO - 2017-02-13 10:20:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:36 --> Model Class Initialized
INFO - 2017-02-13 10:20:36 --> Model Class Initialized
INFO - 2017-02-13 10:20:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:36 --> Total execution time: 0.4405
INFO - 2017-02-13 10:20:38 --> Config Class Initialized
INFO - 2017-02-13 10:20:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:38 --> URI Class Initialized
INFO - 2017-02-13 10:20:38 --> Config Class Initialized
INFO - 2017-02-13 10:20:38 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:38 --> Router Class Initialized
INFO - 2017-02-13 10:20:38 --> Output Class Initialized
INFO - 2017-02-13 10:20:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:38 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:38 --> Input Class Initialized
INFO - 2017-02-13 10:20:38 --> Language Class Initialized
INFO - 2017-02-13 10:20:38 --> URI Class Initialized
INFO - 2017-02-13 10:20:38 --> Router Class Initialized
INFO - 2017-02-13 10:20:38 --> Loader Class Initialized
INFO - 2017-02-13 10:20:38 --> Output Class Initialized
INFO - 2017-02-13 10:20:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:39 --> Security Class Initialized
INFO - 2017-02-13 10:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:39 --> Controller Class Initialized
DEBUG - 2017-02-13 10:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:39 --> Input Class Initialized
INFO - 2017-02-13 10:20:39 --> Language Class Initialized
INFO - 2017-02-13 10:20:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:39 --> Loader Class Initialized
INFO - 2017-02-13 10:20:39 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:39 --> Model Class Initialized
INFO - 2017-02-13 10:20:39 --> Model Class Initialized
INFO - 2017-02-13 10:20:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:39 --> Total execution time: 0.1225
INFO - 2017-02-13 10:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:39 --> Controller Class Initialized
INFO - 2017-02-13 10:20:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:39 --> Model Class Initialized
INFO - 2017-02-13 10:20:39 --> Model Class Initialized
INFO - 2017-02-13 10:20:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:39 --> Total execution time: 0.5469
INFO - 2017-02-13 10:20:41 --> Config Class Initialized
INFO - 2017-02-13 10:20:41 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:41 --> Config Class Initialized
INFO - 2017-02-13 10:20:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:20:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:41 --> URI Class Initialized
INFO - 2017-02-13 10:20:41 --> Router Class Initialized
INFO - 2017-02-13 10:20:41 --> URI Class Initialized
INFO - 2017-02-13 10:20:41 --> Output Class Initialized
INFO - 2017-02-13 10:20:41 --> Router Class Initialized
INFO - 2017-02-13 10:20:41 --> Security Class Initialized
INFO - 2017-02-13 10:20:41 --> Output Class Initialized
INFO - 2017-02-13 10:20:41 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:41 --> Input Class Initialized
DEBUG - 2017-02-13 10:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:41 --> Input Class Initialized
INFO - 2017-02-13 10:20:41 --> Language Class Initialized
INFO - 2017-02-13 10:20:41 --> Language Class Initialized
INFO - 2017-02-13 10:20:41 --> Loader Class Initialized
INFO - 2017-02-13 10:20:41 --> Loader Class Initialized
INFO - 2017-02-13 10:20:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:41 --> Controller Class Initialized
INFO - 2017-02-13 10:20:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:41 --> Model Class Initialized
INFO - 2017-02-13 10:20:41 --> Model Class Initialized
INFO - 2017-02-13 10:20:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:41 --> Total execution time: 0.5862
INFO - 2017-02-13 10:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:41 --> Controller Class Initialized
INFO - 2017-02-13 10:20:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:41 --> Model Class Initialized
INFO - 2017-02-13 10:20:41 --> Model Class Initialized
INFO - 2017-02-13 10:20:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:41 --> Total execution time: 0.6531
INFO - 2017-02-13 10:20:43 --> Config Class Initialized
INFO - 2017-02-13 10:20:43 --> Config Class Initialized
INFO - 2017-02-13 10:20:43 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:43 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:43 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:43 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:43 --> URI Class Initialized
INFO - 2017-02-13 10:20:43 --> URI Class Initialized
INFO - 2017-02-13 10:20:43 --> Router Class Initialized
INFO - 2017-02-13 10:20:43 --> Router Class Initialized
INFO - 2017-02-13 10:20:43 --> Output Class Initialized
INFO - 2017-02-13 10:20:43 --> Output Class Initialized
INFO - 2017-02-13 10:20:43 --> Security Class Initialized
INFO - 2017-02-13 10:20:43 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:43 --> Input Class Initialized
INFO - 2017-02-13 10:20:43 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:43 --> Input Class Initialized
INFO - 2017-02-13 10:20:43 --> Language Class Initialized
INFO - 2017-02-13 10:20:43 --> Loader Class Initialized
INFO - 2017-02-13 10:20:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:43 --> Loader Class Initialized
INFO - 2017-02-13 10:20:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:43 --> Controller Class Initialized
INFO - 2017-02-13 10:20:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:43 --> Model Class Initialized
INFO - 2017-02-13 10:20:43 --> Model Class Initialized
INFO - 2017-02-13 10:20:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:43 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:43 --> Total execution time: 0.1214
INFO - 2017-02-13 10:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:43 --> Controller Class Initialized
INFO - 2017-02-13 10:20:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:43 --> Model Class Initialized
INFO - 2017-02-13 10:20:43 --> Model Class Initialized
INFO - 2017-02-13 10:20:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:44 --> Total execution time: 0.5013
INFO - 2017-02-13 10:20:46 --> Config Class Initialized
INFO - 2017-02-13 10:20:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:46 --> Config Class Initialized
INFO - 2017-02-13 10:20:46 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:46 --> URI Class Initialized
INFO - 2017-02-13 10:20:46 --> Config Class Initialized
INFO - 2017-02-13 10:20:46 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:46 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:46 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:46 --> Output Class Initialized
INFO - 2017-02-13 10:20:46 --> URI Class Initialized
INFO - 2017-02-13 10:20:46 --> URI Class Initialized
INFO - 2017-02-13 10:20:46 --> Router Class Initialized
INFO - 2017-02-13 10:20:46 --> Router Class Initialized
INFO - 2017-02-13 10:20:46 --> Output Class Initialized
INFO - 2017-02-13 10:20:46 --> Security Class Initialized
INFO - 2017-02-13 10:20:46 --> Output Class Initialized
INFO - 2017-02-13 10:20:46 --> Security Class Initialized
INFO - 2017-02-13 10:20:46 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:46 --> Input Class Initialized
INFO - 2017-02-13 10:20:46 --> Input Class Initialized
INFO - 2017-02-13 10:20:46 --> Language Class Initialized
INFO - 2017-02-13 10:20:46 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:46 --> Input Class Initialized
INFO - 2017-02-13 10:20:46 --> Language Class Initialized
INFO - 2017-02-13 10:20:46 --> Loader Class Initialized
INFO - 2017-02-13 10:20:46 --> Loader Class Initialized
INFO - 2017-02-13 10:20:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:46 --> Loader Class Initialized
INFO - 2017-02-13 10:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:46 --> Controller Class Initialized
INFO - 2017-02-13 10:20:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:46 --> Controller Class Initialized
INFO - 2017-02-13 10:20:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:46 --> Config Class Initialized
INFO - 2017-02-13 10:20:46 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:46 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:46 --> Total execution time: 0.2419
INFO - 2017-02-13 10:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:46 --> Controller Class Initialized
DEBUG - 2017-02-13 10:20:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:46 --> URI Class Initialized
INFO - 2017-02-13 10:20:46 --> Router Class Initialized
INFO - 2017-02-13 10:20:46 --> Output Class Initialized
INFO - 2017-02-13 10:20:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:46 --> Security Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
DEBUG - 2017-02-13 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:46 --> Input Class Initialized
INFO - 2017-02-13 10:20:46 --> Language Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:46 --> Loader Class Initialized
INFO - 2017-02-13 10:20:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:46 --> Controller Class Initialized
INFO - 2017-02-13 10:20:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Model Class Initialized
INFO - 2017-02-13 10:20:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:20:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06.php
INFO - 2017-02-13 10:20:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:20:46 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:46 --> Total execution time: 0.1534
INFO - 2017-02-13 10:20:47 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:47 --> Total execution time: 0.7028
INFO - 2017-02-13 10:20:48 --> Config Class Initialized
INFO - 2017-02-13 10:20:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:48 --> URI Class Initialized
INFO - 2017-02-13 10:20:48 --> Router Class Initialized
INFO - 2017-02-13 10:20:48 --> Output Class Initialized
INFO - 2017-02-13 10:20:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:48 --> Input Class Initialized
INFO - 2017-02-13 10:20:48 --> Language Class Initialized
INFO - 2017-02-13 10:20:48 --> Loader Class Initialized
INFO - 2017-02-13 10:20:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:48 --> Controller Class Initialized
INFO - 2017-02-13 10:20:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:48 --> Model Class Initialized
INFO - 2017-02-13 10:20:48 --> Model Class Initialized
INFO - 2017-02-13 10:20:48 --> Model Class Initialized
INFO - 2017-02-13 10:20:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:49 --> Config Class Initialized
INFO - 2017-02-13 10:20:49 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:49 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:49 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:49 --> URI Class Initialized
INFO - 2017-02-13 10:20:49 --> Router Class Initialized
INFO - 2017-02-13 10:20:49 --> Output Class Initialized
INFO - 2017-02-13 10:20:49 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:49 --> Input Class Initialized
INFO - 2017-02-13 10:20:49 --> Language Class Initialized
INFO - 2017-02-13 10:20:49 --> Loader Class Initialized
INFO - 2017-02-13 10:20:49 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:49 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:49 --> Controller Class Initialized
INFO - 2017-02-13 10:20:49 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:49 --> Model Class Initialized
INFO - 2017-02-13 10:20:49 --> Model Class Initialized
INFO - 2017-02-13 10:20:49 --> Model Class Initialized
INFO - 2017-02-13 10:20:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_06_attempt.php
INFO - 2017-02-13 10:20:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:20:49 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:49 --> Total execution time: 0.1932
INFO - 2017-02-13 10:20:49 --> Config Class Initialized
INFO - 2017-02-13 10:20:49 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:49 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:49 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:49 --> URI Class Initialized
INFO - 2017-02-13 10:20:49 --> Config Class Initialized
INFO - 2017-02-13 10:20:49 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:49 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:49 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:49 --> Output Class Initialized
INFO - 2017-02-13 10:20:49 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:49 --> URI Class Initialized
INFO - 2017-02-13 10:20:49 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:49 --> Input Class Initialized
INFO - 2017-02-13 10:20:49 --> Router Class Initialized
INFO - 2017-02-13 10:20:49 --> Language Class Initialized
INFO - 2017-02-13 10:20:49 --> Output Class Initialized
INFO - 2017-02-13 10:20:49 --> Security Class Initialized
INFO - 2017-02-13 10:20:49 --> Loader Class Initialized
INFO - 2017-02-13 10:20:49 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:49 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:49 --> Input Class Initialized
INFO - 2017-02-13 10:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:49 --> Language Class Initialized
INFO - 2017-02-13 10:20:49 --> Controller Class Initialized
INFO - 2017-02-13 10:20:49 --> Loader Class Initialized
INFO - 2017-02-13 10:20:49 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:49 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:49 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:49 --> Model Class Initialized
INFO - 2017-02-13 10:20:49 --> Model Class Initialized
INFO - 2017-02-13 10:20:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:49 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:49 --> Total execution time: 0.1531
INFO - 2017-02-13 10:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:49 --> Controller Class Initialized
INFO - 2017-02-13 10:20:49 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:49 --> Model Class Initialized
INFO - 2017-02-13 10:20:49 --> Model Class Initialized
INFO - 2017-02-13 10:20:49 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:20:49 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:20:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:20:49 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:49 --> Total execution time: 0.3153
INFO - 2017-02-13 10:20:52 --> Config Class Initialized
INFO - 2017-02-13 10:20:52 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:52 --> Config Class Initialized
INFO - 2017-02-13 10:20:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:52 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:52 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:52 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:52 --> Router Class Initialized
INFO - 2017-02-13 10:20:52 --> URI Class Initialized
INFO - 2017-02-13 10:20:52 --> Output Class Initialized
INFO - 2017-02-13 10:20:52 --> Security Class Initialized
INFO - 2017-02-13 10:20:52 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:52 --> Input Class Initialized
INFO - 2017-02-13 10:20:52 --> Output Class Initialized
INFO - 2017-02-13 10:20:52 --> Language Class Initialized
INFO - 2017-02-13 10:20:52 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:52 --> Input Class Initialized
INFO - 2017-02-13 10:20:52 --> Loader Class Initialized
INFO - 2017-02-13 10:20:52 --> Language Class Initialized
INFO - 2017-02-13 10:20:52 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:52 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:52 --> Loader Class Initialized
INFO - 2017-02-13 10:20:52 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:52 --> Controller Class Initialized
INFO - 2017-02-13 10:20:52 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:52 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:52 --> Model Class Initialized
INFO - 2017-02-13 10:20:52 --> Model Class Initialized
INFO - 2017-02-13 10:20:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:52 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:52 --> Total execution time: 0.2116
INFO - 2017-02-13 10:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:52 --> Controller Class Initialized
INFO - 2017-02-13 10:20:52 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:52 --> Model Class Initialized
INFO - 2017-02-13 10:20:52 --> Model Class Initialized
INFO - 2017-02-13 10:20:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:52 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:52 --> Total execution time: 0.3230
INFO - 2017-02-13 10:20:54 --> Config Class Initialized
INFO - 2017-02-13 10:20:54 --> Config Class Initialized
INFO - 2017-02-13 10:20:54 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:54 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:54 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:54 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:20:54 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:54 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:54 --> URI Class Initialized
INFO - 2017-02-13 10:20:54 --> URI Class Initialized
INFO - 2017-02-13 10:20:54 --> Router Class Initialized
INFO - 2017-02-13 10:20:54 --> Router Class Initialized
INFO - 2017-02-13 10:20:54 --> Output Class Initialized
INFO - 2017-02-13 10:20:54 --> Output Class Initialized
INFO - 2017-02-13 10:20:54 --> Security Class Initialized
INFO - 2017-02-13 10:20:54 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:54 --> Input Class Initialized
INFO - 2017-02-13 10:20:54 --> Language Class Initialized
DEBUG - 2017-02-13 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:54 --> Input Class Initialized
INFO - 2017-02-13 10:20:54 --> Language Class Initialized
INFO - 2017-02-13 10:20:54 --> Loader Class Initialized
INFO - 2017-02-13 10:20:54 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:54 --> Loader Class Initialized
INFO - 2017-02-13 10:20:54 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:54 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:54 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:54 --> Controller Class Initialized
INFO - 2017-02-13 10:20:54 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:54 --> Model Class Initialized
INFO - 2017-02-13 10:20:54 --> Model Class Initialized
INFO - 2017-02-13 10:20:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:54 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:54 --> Total execution time: 0.1313
INFO - 2017-02-13 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:54 --> Controller Class Initialized
INFO - 2017-02-13 10:20:54 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:54 --> Model Class Initialized
INFO - 2017-02-13 10:20:54 --> Model Class Initialized
INFO - 2017-02-13 10:20:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:54 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:54 --> Total execution time: 0.3095
INFO - 2017-02-13 10:20:56 --> Config Class Initialized
INFO - 2017-02-13 10:20:56 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:56 --> Config Class Initialized
DEBUG - 2017-02-13 10:20:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:56 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:56 --> URI Class Initialized
INFO - 2017-02-13 10:20:56 --> Router Class Initialized
DEBUG - 2017-02-13 10:20:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:56 --> Output Class Initialized
INFO - 2017-02-13 10:20:56 --> URI Class Initialized
INFO - 2017-02-13 10:20:56 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:56 --> Input Class Initialized
INFO - 2017-02-13 10:20:56 --> Language Class Initialized
INFO - 2017-02-13 10:20:56 --> Router Class Initialized
INFO - 2017-02-13 10:20:56 --> Loader Class Initialized
INFO - 2017-02-13 10:20:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:56 --> Output Class Initialized
INFO - 2017-02-13 10:20:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:56 --> Security Class Initialized
INFO - 2017-02-13 10:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:56 --> Controller Class Initialized
DEBUG - 2017-02-13 10:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:56 --> Input Class Initialized
INFO - 2017-02-13 10:20:56 --> Language Class Initialized
INFO - 2017-02-13 10:20:56 --> Loader Class Initialized
INFO - 2017-02-13 10:20:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:56 --> Model Class Initialized
INFO - 2017-02-13 10:20:56 --> Model Class Initialized
INFO - 2017-02-13 10:20:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:56 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:56 --> Total execution time: 0.1132
INFO - 2017-02-13 10:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:56 --> Controller Class Initialized
INFO - 2017-02-13 10:20:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:56 --> Model Class Initialized
INFO - 2017-02-13 10:20:56 --> Model Class Initialized
INFO - 2017-02-13 10:20:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:56 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:56 --> Total execution time: 0.3218
INFO - 2017-02-13 10:20:59 --> Config Class Initialized
INFO - 2017-02-13 10:20:59 --> Hooks Class Initialized
INFO - 2017-02-13 10:20:59 --> Config Class Initialized
INFO - 2017-02-13 10:20:59 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:20:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:59 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:59 --> URI Class Initialized
DEBUG - 2017-02-13 10:20:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:20:59 --> Utf8 Class Initialized
INFO - 2017-02-13 10:20:59 --> Router Class Initialized
INFO - 2017-02-13 10:20:59 --> URI Class Initialized
INFO - 2017-02-13 10:20:59 --> Output Class Initialized
INFO - 2017-02-13 10:20:59 --> Router Class Initialized
INFO - 2017-02-13 10:20:59 --> Security Class Initialized
INFO - 2017-02-13 10:20:59 --> Output Class Initialized
DEBUG - 2017-02-13 10:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:59 --> Input Class Initialized
INFO - 2017-02-13 10:20:59 --> Language Class Initialized
INFO - 2017-02-13 10:20:59 --> Security Class Initialized
DEBUG - 2017-02-13 10:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:20:59 --> Input Class Initialized
INFO - 2017-02-13 10:20:59 --> Loader Class Initialized
INFO - 2017-02-13 10:20:59 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:59 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:59 --> Language Class Initialized
INFO - 2017-02-13 10:20:59 --> Loader Class Initialized
INFO - 2017-02-13 10:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:59 --> Controller Class Initialized
INFO - 2017-02-13 10:20:59 --> Helper loaded: url_helper
INFO - 2017-02-13 10:20:59 --> Helper loaded: language_helper
INFO - 2017-02-13 10:20:59 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:59 --> Model Class Initialized
INFO - 2017-02-13 10:20:59 --> Model Class Initialized
INFO - 2017-02-13 10:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:59 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:59 --> Total execution time: 0.1214
INFO - 2017-02-13 10:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:20:59 --> Controller Class Initialized
INFO - 2017-02-13 10:20:59 --> Database Driver Class Initialized
INFO - 2017-02-13 10:20:59 --> Model Class Initialized
INFO - 2017-02-13 10:20:59 --> Model Class Initialized
INFO - 2017-02-13 10:20:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:20:59 --> Final output sent to browser
DEBUG - 2017-02-13 10:20:59 --> Total execution time: 0.3886
INFO - 2017-02-13 10:21:01 --> Config Class Initialized
INFO - 2017-02-13 10:21:01 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:01 --> Config Class Initialized
INFO - 2017-02-13 10:21:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:01 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:01 --> URI Class Initialized
INFO - 2017-02-13 10:21:01 --> Router Class Initialized
INFO - 2017-02-13 10:21:01 --> Router Class Initialized
INFO - 2017-02-13 10:21:01 --> Output Class Initialized
INFO - 2017-02-13 10:21:01 --> Security Class Initialized
INFO - 2017-02-13 10:21:01 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:01 --> Input Class Initialized
INFO - 2017-02-13 10:21:01 --> Language Class Initialized
INFO - 2017-02-13 10:21:01 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:01 --> Input Class Initialized
INFO - 2017-02-13 10:21:01 --> Loader Class Initialized
INFO - 2017-02-13 10:21:01 --> Language Class Initialized
INFO - 2017-02-13 10:21:01 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:01 --> Loader Class Initialized
INFO - 2017-02-13 10:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:01 --> Controller Class Initialized
INFO - 2017-02-13 10:21:01 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:01 --> Model Class Initialized
INFO - 2017-02-13 10:21:01 --> Model Class Initialized
INFO - 2017-02-13 10:21:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:01 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:01 --> Total execution time: 0.1471
INFO - 2017-02-13 10:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:01 --> Controller Class Initialized
INFO - 2017-02-13 10:21:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:01 --> Model Class Initialized
INFO - 2017-02-13 10:21:01 --> Model Class Initialized
INFO - 2017-02-13 10:21:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:01 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:01 --> Total execution time: 0.3464
INFO - 2017-02-13 10:21:03 --> Config Class Initialized
INFO - 2017-02-13 10:21:03 --> Config Class Initialized
INFO - 2017-02-13 10:21:03 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:03 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:03 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:21:03 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:03 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:03 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:03 --> URI Class Initialized
INFO - 2017-02-13 10:21:03 --> URI Class Initialized
INFO - 2017-02-13 10:21:03 --> Router Class Initialized
INFO - 2017-02-13 10:21:03 --> Router Class Initialized
INFO - 2017-02-13 10:21:03 --> Output Class Initialized
INFO - 2017-02-13 10:21:03 --> Output Class Initialized
INFO - 2017-02-13 10:21:03 --> Security Class Initialized
INFO - 2017-02-13 10:21:03 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:03 --> Input Class Initialized
INFO - 2017-02-13 10:21:03 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:03 --> Input Class Initialized
INFO - 2017-02-13 10:21:03 --> Language Class Initialized
INFO - 2017-02-13 10:21:03 --> Loader Class Initialized
INFO - 2017-02-13 10:21:03 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:03 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:03 --> Loader Class Initialized
INFO - 2017-02-13 10:21:03 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:03 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:03 --> Controller Class Initialized
INFO - 2017-02-13 10:21:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:03 --> Model Class Initialized
INFO - 2017-02-13 10:21:03 --> Model Class Initialized
INFO - 2017-02-13 10:21:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:03 --> Total execution time: 0.1217
INFO - 2017-02-13 10:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:03 --> Controller Class Initialized
INFO - 2017-02-13 10:21:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:03 --> Model Class Initialized
INFO - 2017-02-13 10:21:03 --> Model Class Initialized
INFO - 2017-02-13 10:21:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:03 --> Total execution time: 0.3613
INFO - 2017-02-13 10:21:05 --> Config Class Initialized
INFO - 2017-02-13 10:21:05 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:05 --> Config Class Initialized
INFO - 2017-02-13 10:21:05 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:05 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:05 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:05 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:05 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:05 --> URI Class Initialized
INFO - 2017-02-13 10:21:05 --> URI Class Initialized
INFO - 2017-02-13 10:21:05 --> Router Class Initialized
INFO - 2017-02-13 10:21:05 --> Router Class Initialized
INFO - 2017-02-13 10:21:05 --> Output Class Initialized
INFO - 2017-02-13 10:21:05 --> Security Class Initialized
INFO - 2017-02-13 10:21:05 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:05 --> Input Class Initialized
INFO - 2017-02-13 10:21:05 --> Language Class Initialized
INFO - 2017-02-13 10:21:05 --> Security Class Initialized
INFO - 2017-02-13 10:21:05 --> Loader Class Initialized
INFO - 2017-02-13 10:21:05 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:05 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:05 --> Input Class Initialized
INFO - 2017-02-13 10:21:05 --> Language Class Initialized
INFO - 2017-02-13 10:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:05 --> Controller Class Initialized
INFO - 2017-02-13 10:21:05 --> Loader Class Initialized
INFO - 2017-02-13 10:21:05 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:05 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:05 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:05 --> Model Class Initialized
INFO - 2017-02-13 10:21:05 --> Model Class Initialized
INFO - 2017-02-13 10:21:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:05 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:05 --> Total execution time: 0.1331
INFO - 2017-02-13 10:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:05 --> Controller Class Initialized
INFO - 2017-02-13 10:21:05 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:05 --> Model Class Initialized
INFO - 2017-02-13 10:21:05 --> Model Class Initialized
INFO - 2017-02-13 10:21:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:06 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:06 --> Total execution time: 0.4163
INFO - 2017-02-13 10:21:07 --> Config Class Initialized
INFO - 2017-02-13 10:21:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:07 --> Config Class Initialized
INFO - 2017-02-13 10:21:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:07 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:07 --> URI Class Initialized
INFO - 2017-02-13 10:21:07 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:07 --> Output Class Initialized
INFO - 2017-02-13 10:21:07 --> URI Class Initialized
INFO - 2017-02-13 10:21:07 --> Security Class Initialized
INFO - 2017-02-13 10:21:07 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:07 --> Input Class Initialized
INFO - 2017-02-13 10:21:07 --> Output Class Initialized
INFO - 2017-02-13 10:21:07 --> Language Class Initialized
INFO - 2017-02-13 10:21:07 --> Security Class Initialized
INFO - 2017-02-13 10:21:07 --> Loader Class Initialized
DEBUG - 2017-02-13 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:07 --> Input Class Initialized
INFO - 2017-02-13 10:21:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:07 --> Language Class Initialized
INFO - 2017-02-13 10:21:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:07 --> Loader Class Initialized
INFO - 2017-02-13 10:21:07 --> Controller Class Initialized
INFO - 2017-02-13 10:21:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:07 --> Model Class Initialized
INFO - 2017-02-13 10:21:07 --> Model Class Initialized
INFO - 2017-02-13 10:21:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:07 --> Total execution time: 0.1127
INFO - 2017-02-13 10:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:07 --> Controller Class Initialized
INFO - 2017-02-13 10:21:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:07 --> Model Class Initialized
INFO - 2017-02-13 10:21:07 --> Model Class Initialized
INFO - 2017-02-13 10:21:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:08 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:08 --> Total execution time: 0.3199
INFO - 2017-02-13 10:21:10 --> Config Class Initialized
INFO - 2017-02-13 10:21:10 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:10 --> Config Class Initialized
INFO - 2017-02-13 10:21:10 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:10 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:10 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:10 --> URI Class Initialized
INFO - 2017-02-13 10:21:10 --> URI Class Initialized
INFO - 2017-02-13 10:21:10 --> Router Class Initialized
INFO - 2017-02-13 10:21:10 --> Router Class Initialized
INFO - 2017-02-13 10:21:10 --> Output Class Initialized
INFO - 2017-02-13 10:21:10 --> Security Class Initialized
INFO - 2017-02-13 10:21:10 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:10 --> Input Class Initialized
INFO - 2017-02-13 10:21:10 --> Security Class Initialized
INFO - 2017-02-13 10:21:10 --> Language Class Initialized
INFO - 2017-02-13 10:21:10 --> Loader Class Initialized
DEBUG - 2017-02-13 10:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:10 --> Input Class Initialized
INFO - 2017-02-13 10:21:10 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:10 --> Language Class Initialized
INFO - 2017-02-13 10:21:10 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:10 --> Loader Class Initialized
INFO - 2017-02-13 10:21:10 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:10 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:10 --> Controller Class Initialized
INFO - 2017-02-13 10:21:10 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:10 --> Model Class Initialized
INFO - 2017-02-13 10:21:10 --> Model Class Initialized
INFO - 2017-02-13 10:21:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:10 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:10 --> Total execution time: 0.1361
INFO - 2017-02-13 10:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:10 --> Controller Class Initialized
INFO - 2017-02-13 10:21:10 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:10 --> Model Class Initialized
INFO - 2017-02-13 10:21:10 --> Model Class Initialized
INFO - 2017-02-13 10:21:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:10 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:10 --> Total execution time: 0.3931
INFO - 2017-02-13 10:21:12 --> Config Class Initialized
INFO - 2017-02-13 10:21:12 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:12 --> Config Class Initialized
INFO - 2017-02-13 10:21:12 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:12 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:12 --> URI Class Initialized
INFO - 2017-02-13 10:21:12 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:12 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:12 --> Output Class Initialized
INFO - 2017-02-13 10:21:12 --> URI Class Initialized
INFO - 2017-02-13 10:21:12 --> Security Class Initialized
INFO - 2017-02-13 10:21:12 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:12 --> Input Class Initialized
INFO - 2017-02-13 10:21:12 --> Language Class Initialized
INFO - 2017-02-13 10:21:12 --> Output Class Initialized
INFO - 2017-02-13 10:21:12 --> Security Class Initialized
INFO - 2017-02-13 10:21:12 --> Loader Class Initialized
INFO - 2017-02-13 10:21:12 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:12 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:12 --> Input Class Initialized
INFO - 2017-02-13 10:21:12 --> Language Class Initialized
INFO - 2017-02-13 10:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:12 --> Controller Class Initialized
INFO - 2017-02-13 10:21:12 --> Loader Class Initialized
INFO - 2017-02-13 10:21:12 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:12 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:12 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:12 --> Model Class Initialized
INFO - 2017-02-13 10:21:12 --> Model Class Initialized
INFO - 2017-02-13 10:21:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:12 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:12 --> Total execution time: 0.1190
INFO - 2017-02-13 10:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:12 --> Controller Class Initialized
INFO - 2017-02-13 10:21:12 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:12 --> Model Class Initialized
INFO - 2017-02-13 10:21:12 --> Model Class Initialized
INFO - 2017-02-13 10:21:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:12 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:12 --> Total execution time: 0.3570
INFO - 2017-02-13 10:21:14 --> Config Class Initialized
INFO - 2017-02-13 10:21:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:14 --> URI Class Initialized
INFO - 2017-02-13 10:21:14 --> Router Class Initialized
INFO - 2017-02-13 10:21:14 --> Config Class Initialized
INFO - 2017-02-13 10:21:14 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:14 --> Output Class Initialized
INFO - 2017-02-13 10:21:14 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:14 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:14 --> Input Class Initialized
INFO - 2017-02-13 10:21:14 --> Language Class Initialized
INFO - 2017-02-13 10:21:14 --> Router Class Initialized
INFO - 2017-02-13 10:21:14 --> Output Class Initialized
INFO - 2017-02-13 10:21:14 --> Loader Class Initialized
INFO - 2017-02-13 10:21:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:14 --> Security Class Initialized
INFO - 2017-02-13 10:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:14 --> Controller Class Initialized
DEBUG - 2017-02-13 10:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:14 --> Input Class Initialized
INFO - 2017-02-13 10:21:14 --> Language Class Initialized
INFO - 2017-02-13 10:21:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:14 --> Loader Class Initialized
INFO - 2017-02-13 10:21:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:14 --> Model Class Initialized
INFO - 2017-02-13 10:21:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:14 --> Model Class Initialized
INFO - 2017-02-13 10:21:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:14 --> Total execution time: 0.1165
INFO - 2017-02-13 10:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:14 --> Controller Class Initialized
INFO - 2017-02-13 10:21:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:14 --> Model Class Initialized
INFO - 2017-02-13 10:21:14 --> Model Class Initialized
INFO - 2017-02-13 10:21:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:14 --> Total execution time: 0.4186
INFO - 2017-02-13 10:21:17 --> Config Class Initialized
INFO - 2017-02-13 10:21:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:17 --> Config Class Initialized
INFO - 2017-02-13 10:21:17 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:17 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:17 --> Router Class Initialized
INFO - 2017-02-13 10:21:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:17 --> URI Class Initialized
INFO - 2017-02-13 10:21:17 --> Output Class Initialized
INFO - 2017-02-13 10:21:17 --> Router Class Initialized
INFO - 2017-02-13 10:21:17 --> Output Class Initialized
INFO - 2017-02-13 10:21:17 --> Security Class Initialized
INFO - 2017-02-13 10:21:17 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:17 --> Input Class Initialized
DEBUG - 2017-02-13 10:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:17 --> Language Class Initialized
INFO - 2017-02-13 10:21:17 --> Input Class Initialized
INFO - 2017-02-13 10:21:17 --> Language Class Initialized
INFO - 2017-02-13 10:21:17 --> Loader Class Initialized
INFO - 2017-02-13 10:21:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:17 --> Loader Class Initialized
INFO - 2017-02-13 10:21:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:17 --> Controller Class Initialized
INFO - 2017-02-13 10:21:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:17 --> Model Class Initialized
INFO - 2017-02-13 10:21:17 --> Model Class Initialized
INFO - 2017-02-13 10:21:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:17 --> Total execution time: 0.1575
INFO - 2017-02-13 10:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:17 --> Controller Class Initialized
INFO - 2017-02-13 10:21:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:17 --> Model Class Initialized
INFO - 2017-02-13 10:21:17 --> Model Class Initialized
INFO - 2017-02-13 10:21:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:17 --> Total execution time: 0.5416
INFO - 2017-02-13 10:21:19 --> Config Class Initialized
INFO - 2017-02-13 10:21:19 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:19 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:19 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:19 --> URI Class Initialized
INFO - 2017-02-13 10:21:19 --> Router Class Initialized
INFO - 2017-02-13 10:21:19 --> Output Class Initialized
INFO - 2017-02-13 10:21:19 --> Config Class Initialized
INFO - 2017-02-13 10:21:19 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:19 --> Security Class Initialized
INFO - 2017-02-13 10:21:19 --> Config Class Initialized
DEBUG - 2017-02-13 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:19 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:19 --> Input Class Initialized
DEBUG - 2017-02-13 10:21:19 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:19 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:19 --> Language Class Initialized
INFO - 2017-02-13 10:21:19 --> URI Class Initialized
INFO - 2017-02-13 10:21:19 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:19 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:19 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:19 --> URI Class Initialized
INFO - 2017-02-13 10:21:19 --> Loader Class Initialized
INFO - 2017-02-13 10:21:19 --> Output Class Initialized
INFO - 2017-02-13 10:21:19 --> Router Class Initialized
INFO - 2017-02-13 10:21:19 --> Security Class Initialized
INFO - 2017-02-13 10:21:19 --> Output Class Initialized
INFO - 2017-02-13 10:21:19 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:19 --> Input Class Initialized
INFO - 2017-02-13 10:21:19 --> Security Class Initialized
INFO - 2017-02-13 10:21:19 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:19 --> Language Class Initialized
INFO - 2017-02-13 10:21:19 --> Loader Class Initialized
INFO - 2017-02-13 10:21:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-02-13 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:19 --> Controller Class Initialized
INFO - 2017-02-13 10:21:19 --> Input Class Initialized
INFO - 2017-02-13 10:21:19 --> Language Class Initialized
INFO - 2017-02-13 10:21:19 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:19 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:19 --> Loader Class Initialized
INFO - 2017-02-13 10:21:19 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:19 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:19 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:19 --> Model Class Initialized
INFO - 2017-02-13 10:21:19 --> Model Class Initialized
INFO - 2017-02-13 10:21:19 --> Model Class Initialized
INFO - 2017-02-13 10:21:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:19 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:19 --> Total execution time: 0.2537
INFO - 2017-02-13 10:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:19 --> Controller Class Initialized
INFO - 2017-02-13 10:21:19 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:19 --> Model Class Initialized
INFO - 2017-02-13 10:21:19 --> Model Class Initialized
INFO - 2017-02-13 10:21:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:19 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:19 --> Total execution time: 0.2380
INFO - 2017-02-13 10:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:19 --> Controller Class Initialized
INFO - 2017-02-13 10:21:19 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:19 --> Model Class Initialized
INFO - 2017-02-13 10:21:19 --> Model Class Initialized
INFO - 2017-02-13 10:21:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:20 --> Total execution time: 0.6301
INFO - 2017-02-13 10:21:21 --> Config Class Initialized
INFO - 2017-02-13 10:21:21 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:21 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:21 --> URI Class Initialized
INFO - 2017-02-13 10:21:21 --> Config Class Initialized
INFO - 2017-02-13 10:21:21 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:21 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:21 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:21 --> Output Class Initialized
INFO - 2017-02-13 10:21:21 --> URI Class Initialized
INFO - 2017-02-13 10:21:21 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:21 --> Input Class Initialized
INFO - 2017-02-13 10:21:21 --> Router Class Initialized
INFO - 2017-02-13 10:21:21 --> Language Class Initialized
INFO - 2017-02-13 10:21:21 --> Output Class Initialized
INFO - 2017-02-13 10:21:21 --> Security Class Initialized
INFO - 2017-02-13 10:21:21 --> Loader Class Initialized
INFO - 2017-02-13 10:21:21 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:21 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:21 --> Input Class Initialized
INFO - 2017-02-13 10:21:21 --> Language Class Initialized
INFO - 2017-02-13 10:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:21 --> Controller Class Initialized
INFO - 2017-02-13 10:21:21 --> Loader Class Initialized
INFO - 2017-02-13 10:21:21 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:21 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:21 --> Model Class Initialized
INFO - 2017-02-13 10:21:21 --> Model Class Initialized
INFO - 2017-02-13 10:21:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:21 --> Total execution time: 0.1220
INFO - 2017-02-13 10:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:21 --> Controller Class Initialized
INFO - 2017-02-13 10:21:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:21 --> Model Class Initialized
INFO - 2017-02-13 10:21:21 --> Model Class Initialized
INFO - 2017-02-13 10:21:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:21 --> Total execution time: 0.3418
INFO - 2017-02-13 10:21:23 --> Config Class Initialized
INFO - 2017-02-13 10:21:23 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:23 --> Config Class Initialized
INFO - 2017-02-13 10:21:23 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:23 --> URI Class Initialized
INFO - 2017-02-13 10:21:23 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:23 --> URI Class Initialized
INFO - 2017-02-13 10:21:23 --> Output Class Initialized
INFO - 2017-02-13 10:21:23 --> Router Class Initialized
INFO - 2017-02-13 10:21:23 --> Security Class Initialized
INFO - 2017-02-13 10:21:23 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:23 --> Input Class Initialized
INFO - 2017-02-13 10:21:23 --> Language Class Initialized
INFO - 2017-02-13 10:21:23 --> Security Class Initialized
INFO - 2017-02-13 10:21:23 --> Loader Class Initialized
DEBUG - 2017-02-13 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:23 --> Input Class Initialized
INFO - 2017-02-13 10:21:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:23 --> Language Class Initialized
INFO - 2017-02-13 10:21:23 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:23 --> Loader Class Initialized
INFO - 2017-02-13 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:23 --> Controller Class Initialized
INFO - 2017-02-13 10:21:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:23 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:23 --> Model Class Initialized
INFO - 2017-02-13 10:21:23 --> Model Class Initialized
INFO - 2017-02-13 10:21:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:23 --> Total execution time: 0.1239
INFO - 2017-02-13 10:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:23 --> Controller Class Initialized
INFO - 2017-02-13 10:21:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:23 --> Model Class Initialized
INFO - 2017-02-13 10:21:24 --> Model Class Initialized
INFO - 2017-02-13 10:21:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:24 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:24 --> Total execution time: 0.4400
INFO - 2017-02-13 10:21:26 --> Config Class Initialized
INFO - 2017-02-13 10:21:26 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:26 --> Config Class Initialized
INFO - 2017-02-13 10:21:26 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:26 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:26 --> URI Class Initialized
INFO - 2017-02-13 10:21:26 --> URI Class Initialized
INFO - 2017-02-13 10:21:26 --> Router Class Initialized
INFO - 2017-02-13 10:21:26 --> Router Class Initialized
INFO - 2017-02-13 10:21:26 --> Output Class Initialized
INFO - 2017-02-13 10:21:26 --> Output Class Initialized
INFO - 2017-02-13 10:21:26 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:26 --> Security Class Initialized
INFO - 2017-02-13 10:21:26 --> Input Class Initialized
INFO - 2017-02-13 10:21:26 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:26 --> Input Class Initialized
INFO - 2017-02-13 10:21:26 --> Language Class Initialized
INFO - 2017-02-13 10:21:26 --> Loader Class Initialized
INFO - 2017-02-13 10:21:26 --> Loader Class Initialized
INFO - 2017-02-13 10:21:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:26 --> Controller Class Initialized
INFO - 2017-02-13 10:21:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:26 --> Model Class Initialized
INFO - 2017-02-13 10:21:26 --> Model Class Initialized
INFO - 2017-02-13 10:21:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:26 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:26 --> Total execution time: 0.3731
INFO - 2017-02-13 10:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:26 --> Controller Class Initialized
INFO - 2017-02-13 10:21:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:26 --> Model Class Initialized
INFO - 2017-02-13 10:21:26 --> Model Class Initialized
INFO - 2017-02-13 10:21:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:26 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:26 --> Total execution time: 0.4121
INFO - 2017-02-13 10:21:28 --> Config Class Initialized
INFO - 2017-02-13 10:21:28 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:28 --> Config Class Initialized
INFO - 2017-02-13 10:21:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:29 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:29 --> URI Class Initialized
INFO - 2017-02-13 10:21:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:29 --> Router Class Initialized
INFO - 2017-02-13 10:21:29 --> URI Class Initialized
INFO - 2017-02-13 10:21:29 --> Output Class Initialized
INFO - 2017-02-13 10:21:29 --> Router Class Initialized
INFO - 2017-02-13 10:21:29 --> Security Class Initialized
INFO - 2017-02-13 10:21:29 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:29 --> Input Class Initialized
INFO - 2017-02-13 10:21:29 --> Security Class Initialized
INFO - 2017-02-13 10:21:29 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:29 --> Input Class Initialized
INFO - 2017-02-13 10:21:29 --> Language Class Initialized
INFO - 2017-02-13 10:21:29 --> Loader Class Initialized
INFO - 2017-02-13 10:21:29 --> Loader Class Initialized
INFO - 2017-02-13 10:21:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:29 --> Controller Class Initialized
INFO - 2017-02-13 10:21:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:29 --> Model Class Initialized
INFO - 2017-02-13 10:21:29 --> Model Class Initialized
INFO - 2017-02-13 10:21:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:29 --> Total execution time: 0.1303
INFO - 2017-02-13 10:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:29 --> Controller Class Initialized
INFO - 2017-02-13 10:21:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:29 --> Model Class Initialized
INFO - 2017-02-13 10:21:29 --> Model Class Initialized
INFO - 2017-02-13 10:21:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:29 --> Total execution time: 0.4980
INFO - 2017-02-13 10:21:30 --> Config Class Initialized
INFO - 2017-02-13 10:21:30 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:30 --> Config Class Initialized
INFO - 2017-02-13 10:21:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:30 --> URI Class Initialized
INFO - 2017-02-13 10:21:30 --> Router Class Initialized
INFO - 2017-02-13 10:21:30 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:30 --> Security Class Initialized
INFO - 2017-02-13 10:21:30 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:30 --> Input Class Initialized
INFO - 2017-02-13 10:21:30 --> Language Class Initialized
INFO - 2017-02-13 10:21:30 --> Router Class Initialized
INFO - 2017-02-13 10:21:30 --> Output Class Initialized
INFO - 2017-02-13 10:21:30 --> Security Class Initialized
INFO - 2017-02-13 10:21:30 --> Loader Class Initialized
INFO - 2017-02-13 10:21:30 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:30 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:30 --> Input Class Initialized
INFO - 2017-02-13 10:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:30 --> Controller Class Initialized
INFO - 2017-02-13 10:21:30 --> Language Class Initialized
INFO - 2017-02-13 10:21:31 --> Loader Class Initialized
INFO - 2017-02-13 10:21:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:31 --> Model Class Initialized
INFO - 2017-02-13 10:21:31 --> Model Class Initialized
INFO - 2017-02-13 10:21:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:31 --> Total execution time: 0.1207
INFO - 2017-02-13 10:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:31 --> Controller Class Initialized
INFO - 2017-02-13 10:21:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:31 --> Model Class Initialized
INFO - 2017-02-13 10:21:31 --> Model Class Initialized
INFO - 2017-02-13 10:21:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:31 --> Total execution time: 0.3797
INFO - 2017-02-13 10:21:33 --> Config Class Initialized
INFO - 2017-02-13 10:21:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:33 --> Config Class Initialized
INFO - 2017-02-13 10:21:33 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:33 --> URI Class Initialized
INFO - 2017-02-13 10:21:33 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:33 --> Output Class Initialized
INFO - 2017-02-13 10:21:33 --> URI Class Initialized
INFO - 2017-02-13 10:21:33 --> Security Class Initialized
INFO - 2017-02-13 10:21:33 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:33 --> Input Class Initialized
INFO - 2017-02-13 10:21:33 --> Language Class Initialized
INFO - 2017-02-13 10:21:33 --> Output Class Initialized
INFO - 2017-02-13 10:21:33 --> Loader Class Initialized
INFO - 2017-02-13 10:21:33 --> Security Class Initialized
INFO - 2017-02-13 10:21:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:33 --> Controller Class Initialized
DEBUG - 2017-02-13 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:33 --> Input Class Initialized
INFO - 2017-02-13 10:21:33 --> Language Class Initialized
INFO - 2017-02-13 10:21:33 --> Loader Class Initialized
INFO - 2017-02-13 10:21:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:33 --> Model Class Initialized
INFO - 2017-02-13 10:21:33 --> Model Class Initialized
INFO - 2017-02-13 10:21:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:33 --> Total execution time: 0.1152
INFO - 2017-02-13 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:33 --> Controller Class Initialized
INFO - 2017-02-13 10:21:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:33 --> Model Class Initialized
INFO - 2017-02-13 10:21:33 --> Model Class Initialized
INFO - 2017-02-13 10:21:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:33 --> Total execution time: 0.5743
INFO - 2017-02-13 10:21:35 --> Config Class Initialized
INFO - 2017-02-13 10:21:35 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:35 --> Config Class Initialized
INFO - 2017-02-13 10:21:35 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:35 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:35 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:35 --> URI Class Initialized
INFO - 2017-02-13 10:21:35 --> URI Class Initialized
INFO - 2017-02-13 10:21:35 --> Config Class Initialized
INFO - 2017-02-13 10:21:35 --> Router Class Initialized
INFO - 2017-02-13 10:21:35 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:35 --> Router Class Initialized
INFO - 2017-02-13 10:21:35 --> Output Class Initialized
INFO - 2017-02-13 10:21:35 --> Output Class Initialized
INFO - 2017-02-13 10:21:35 --> Security Class Initialized
INFO - 2017-02-13 10:21:35 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:35 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:35 --> Input Class Initialized
INFO - 2017-02-13 10:21:35 --> Language Class Initialized
INFO - 2017-02-13 10:21:35 --> URI Class Initialized
INFO - 2017-02-13 10:21:35 --> Router Class Initialized
INFO - 2017-02-13 10:21:35 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:35 --> Input Class Initialized
INFO - 2017-02-13 10:21:35 --> Loader Class Initialized
INFO - 2017-02-13 10:21:35 --> Security Class Initialized
INFO - 2017-02-13 10:21:35 --> Language Class Initialized
INFO - 2017-02-13 10:21:35 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:35 --> Input Class Initialized
INFO - 2017-02-13 10:21:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:35 --> Language Class Initialized
INFO - 2017-02-13 10:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:35 --> Controller Class Initialized
INFO - 2017-02-13 10:21:35 --> Loader Class Initialized
INFO - 2017-02-13 10:21:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:35 --> Loader Class Initialized
INFO - 2017-02-13 10:21:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:35 --> Model Class Initialized
INFO - 2017-02-13 10:21:35 --> Model Class Initialized
INFO - 2017-02-13 10:21:35 --> Model Class Initialized
INFO - 2017-02-13 10:21:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:35 --> Total execution time: 0.1296
INFO - 2017-02-13 10:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:35 --> Controller Class Initialized
INFO - 2017-02-13 10:21:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:35 --> Model Class Initialized
INFO - 2017-02-13 10:21:35 --> Model Class Initialized
INFO - 2017-02-13 10:21:35 --> Model Class Initialized
INFO - 2017-02-13 10:21:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:36 --> Total execution time: 0.6821
INFO - 2017-02-13 10:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:36 --> Controller Class Initialized
INFO - 2017-02-13 10:21:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:36 --> Config Class Initialized
INFO - 2017-02-13 10:21:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:36 --> URI Class Initialized
INFO - 2017-02-13 10:21:36 --> Router Class Initialized
INFO - 2017-02-13 10:21:36 --> Output Class Initialized
INFO - 2017-02-13 10:21:36 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:36 --> Input Class Initialized
INFO - 2017-02-13 10:21:36 --> Language Class Initialized
INFO - 2017-02-13 10:21:36 --> Loader Class Initialized
INFO - 2017-02-13 10:21:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:36 --> Controller Class Initialized
INFO - 2017-02-13 10:21:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07.php
INFO - 2017-02-13 10:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:21:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:36 --> Total execution time: 0.1462
INFO - 2017-02-13 10:21:36 --> Config Class Initialized
INFO - 2017-02-13 10:21:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:36 --> URI Class Initialized
INFO - 2017-02-13 10:21:36 --> Router Class Initialized
INFO - 2017-02-13 10:21:36 --> Output Class Initialized
INFO - 2017-02-13 10:21:36 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:36 --> Input Class Initialized
INFO - 2017-02-13 10:21:36 --> Language Class Initialized
INFO - 2017-02-13 10:21:36 --> Loader Class Initialized
INFO - 2017-02-13 10:21:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:36 --> Controller Class Initialized
INFO - 2017-02-13 10:21:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:21:36 --> Severity: Warning --> Division by zero C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 324
INFO - 2017-02-13 10:21:36 --> Config Class Initialized
INFO - 2017-02-13 10:21:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:36 --> URI Class Initialized
INFO - 2017-02-13 10:21:36 --> Router Class Initialized
INFO - 2017-02-13 10:21:36 --> Output Class Initialized
INFO - 2017-02-13 10:21:36 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:36 --> Input Class Initialized
INFO - 2017-02-13 10:21:36 --> Language Class Initialized
INFO - 2017-02-13 10:21:36 --> Loader Class Initialized
INFO - 2017-02-13 10:21:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:36 --> Controller Class Initialized
INFO - 2017-02-13 10:21:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Model Class Initialized
INFO - 2017-02-13 10:21:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07.php
INFO - 2017-02-13 10:21:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:21:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:36 --> Total execution time: 0.1505
INFO - 2017-02-13 10:21:38 --> Config Class Initialized
INFO - 2017-02-13 10:21:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:38 --> URI Class Initialized
INFO - 2017-02-13 10:21:38 --> Router Class Initialized
INFO - 2017-02-13 10:21:38 --> Output Class Initialized
INFO - 2017-02-13 10:21:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:38 --> Input Class Initialized
INFO - 2017-02-13 10:21:38 --> Language Class Initialized
INFO - 2017-02-13 10:21:38 --> Loader Class Initialized
INFO - 2017-02-13 10:21:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:38 --> Controller Class Initialized
INFO - 2017-02-13 10:21:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:38 --> Model Class Initialized
INFO - 2017-02-13 10:21:38 --> Model Class Initialized
INFO - 2017-02-13 10:21:38 --> Model Class Initialized
INFO - 2017-02-13 10:21:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:39 --> Config Class Initialized
INFO - 2017-02-13 10:21:39 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:39 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:39 --> URI Class Initialized
INFO - 2017-02-13 10:21:39 --> Router Class Initialized
INFO - 2017-02-13 10:21:39 --> Output Class Initialized
INFO - 2017-02-13 10:21:39 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:39 --> Input Class Initialized
INFO - 2017-02-13 10:21:39 --> Language Class Initialized
INFO - 2017-02-13 10:21:39 --> Loader Class Initialized
INFO - 2017-02-13 10:21:39 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:39 --> Controller Class Initialized
INFO - 2017-02-13 10:21:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:39 --> Model Class Initialized
INFO - 2017-02-13 10:21:39 --> Model Class Initialized
INFO - 2017-02-13 10:21:39 --> Model Class Initialized
INFO - 2017-02-13 10:21:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:21:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_07_attempt.php
INFO - 2017-02-13 10:21:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:21:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:39 --> Total execution time: 0.2490
INFO - 2017-02-13 10:21:39 --> Config Class Initialized
INFO - 2017-02-13 10:21:39 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:39 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:39 --> URI Class Initialized
INFO - 2017-02-13 10:21:39 --> Router Class Initialized
INFO - 2017-02-13 10:21:39 --> Output Class Initialized
INFO - 2017-02-13 10:21:39 --> Security Class Initialized
INFO - 2017-02-13 10:21:39 --> Config Class Initialized
INFO - 2017-02-13 10:21:39 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:39 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:39 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:39 --> Input Class Initialized
INFO - 2017-02-13 10:21:39 --> Language Class Initialized
INFO - 2017-02-13 10:21:39 --> Router Class Initialized
INFO - 2017-02-13 10:21:39 --> Output Class Initialized
INFO - 2017-02-13 10:21:39 --> Loader Class Initialized
INFO - 2017-02-13 10:21:39 --> Security Class Initialized
INFO - 2017-02-13 10:21:39 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:39 --> Input Class Initialized
INFO - 2017-02-13 10:21:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:39 --> Language Class Initialized
INFO - 2017-02-13 10:21:39 --> Loader Class Initialized
INFO - 2017-02-13 10:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:39 --> Controller Class Initialized
INFO - 2017-02-13 10:21:39 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:39 --> Model Class Initialized
INFO - 2017-02-13 10:21:39 --> Model Class Initialized
INFO - 2017-02-13 10:21:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:39 --> Total execution time: 0.1799
INFO - 2017-02-13 10:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:39 --> Controller Class Initialized
INFO - 2017-02-13 10:21:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:39 --> Model Class Initialized
INFO - 2017-02-13 10:21:39 --> Model Class Initialized
INFO - 2017-02-13 10:21:39 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:21:39 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:21:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:21:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:39 --> Total execution time: 0.3193
INFO - 2017-02-13 10:21:41 --> Config Class Initialized
INFO - 2017-02-13 10:21:41 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:41 --> Config Class Initialized
INFO - 2017-02-13 10:21:41 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:41 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:41 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:41 --> Router Class Initialized
INFO - 2017-02-13 10:21:41 --> URI Class Initialized
INFO - 2017-02-13 10:21:41 --> Output Class Initialized
INFO - 2017-02-13 10:21:41 --> Router Class Initialized
INFO - 2017-02-13 10:21:41 --> Security Class Initialized
INFO - 2017-02-13 10:21:41 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:41 --> Input Class Initialized
INFO - 2017-02-13 10:21:41 --> Security Class Initialized
INFO - 2017-02-13 10:21:41 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:41 --> Input Class Initialized
INFO - 2017-02-13 10:21:41 --> Language Class Initialized
INFO - 2017-02-13 10:21:41 --> Loader Class Initialized
INFO - 2017-02-13 10:21:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:41 --> Loader Class Initialized
INFO - 2017-02-13 10:21:41 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:41 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:41 --> Controller Class Initialized
INFO - 2017-02-13 10:21:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:41 --> Model Class Initialized
INFO - 2017-02-13 10:21:41 --> Model Class Initialized
INFO - 2017-02-13 10:21:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:41 --> Total execution time: 0.1978
INFO - 2017-02-13 10:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:41 --> Controller Class Initialized
INFO - 2017-02-13 10:21:41 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:41 --> Model Class Initialized
INFO - 2017-02-13 10:21:41 --> Model Class Initialized
INFO - 2017-02-13 10:21:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:42 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:42 --> Total execution time: 0.2638
INFO - 2017-02-13 10:21:43 --> Config Class Initialized
INFO - 2017-02-13 10:21:43 --> Config Class Initialized
INFO - 2017-02-13 10:21:43 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:43 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:43 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:43 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:43 --> URI Class Initialized
INFO - 2017-02-13 10:21:43 --> URI Class Initialized
INFO - 2017-02-13 10:21:43 --> Router Class Initialized
INFO - 2017-02-13 10:21:43 --> Router Class Initialized
INFO - 2017-02-13 10:21:43 --> Output Class Initialized
INFO - 2017-02-13 10:21:43 --> Output Class Initialized
INFO - 2017-02-13 10:21:43 --> Security Class Initialized
INFO - 2017-02-13 10:21:43 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:43 --> Input Class Initialized
DEBUG - 2017-02-13 10:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:43 --> Input Class Initialized
INFO - 2017-02-13 10:21:43 --> Language Class Initialized
INFO - 2017-02-13 10:21:43 --> Language Class Initialized
INFO - 2017-02-13 10:21:43 --> Loader Class Initialized
INFO - 2017-02-13 10:21:43 --> Loader Class Initialized
INFO - 2017-02-13 10:21:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:43 --> Controller Class Initialized
INFO - 2017-02-13 10:21:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:43 --> Model Class Initialized
INFO - 2017-02-13 10:21:43 --> Model Class Initialized
INFO - 2017-02-13 10:21:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:43 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:43 --> Total execution time: 0.1480
INFO - 2017-02-13 10:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:43 --> Controller Class Initialized
INFO - 2017-02-13 10:21:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:43 --> Model Class Initialized
INFO - 2017-02-13 10:21:43 --> Model Class Initialized
INFO - 2017-02-13 10:21:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:43 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:43 --> Total execution time: 0.2913
INFO - 2017-02-13 10:21:44 --> Config Class Initialized
INFO - 2017-02-13 10:21:44 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:44 --> URI Class Initialized
INFO - 2017-02-13 10:21:44 --> Router Class Initialized
INFO - 2017-02-13 10:21:44 --> Config Class Initialized
INFO - 2017-02-13 10:21:44 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:44 --> Output Class Initialized
INFO - 2017-02-13 10:21:44 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:44 --> Input Class Initialized
DEBUG - 2017-02-13 10:21:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:44 --> Language Class Initialized
INFO - 2017-02-13 10:21:44 --> URI Class Initialized
INFO - 2017-02-13 10:21:44 --> Router Class Initialized
INFO - 2017-02-13 10:21:44 --> Loader Class Initialized
INFO - 2017-02-13 10:21:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:44 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:44 --> Output Class Initialized
INFO - 2017-02-13 10:21:44 --> Security Class Initialized
INFO - 2017-02-13 10:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:44 --> Controller Class Initialized
DEBUG - 2017-02-13 10:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:44 --> Input Class Initialized
INFO - 2017-02-13 10:21:44 --> Language Class Initialized
INFO - 2017-02-13 10:21:44 --> Loader Class Initialized
INFO - 2017-02-13 10:21:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:44 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:44 --> Model Class Initialized
INFO - 2017-02-13 10:21:44 --> Model Class Initialized
INFO - 2017-02-13 10:21:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:44 --> Total execution time: 0.1161
INFO - 2017-02-13 10:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:44 --> Controller Class Initialized
INFO - 2017-02-13 10:21:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:44 --> Model Class Initialized
INFO - 2017-02-13 10:21:44 --> Model Class Initialized
INFO - 2017-02-13 10:21:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:44 --> Total execution time: 0.2743
INFO - 2017-02-13 10:21:46 --> Config Class Initialized
INFO - 2017-02-13 10:21:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:46 --> Config Class Initialized
INFO - 2017-02-13 10:21:46 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:46 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:46 --> Router Class Initialized
INFO - 2017-02-13 10:21:46 --> URI Class Initialized
INFO - 2017-02-13 10:21:46 --> Output Class Initialized
INFO - 2017-02-13 10:21:46 --> Router Class Initialized
INFO - 2017-02-13 10:21:46 --> Security Class Initialized
INFO - 2017-02-13 10:21:46 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:46 --> Input Class Initialized
INFO - 2017-02-13 10:21:46 --> Security Class Initialized
INFO - 2017-02-13 10:21:46 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:46 --> Input Class Initialized
INFO - 2017-02-13 10:21:46 --> Language Class Initialized
INFO - 2017-02-13 10:21:46 --> Loader Class Initialized
INFO - 2017-02-13 10:21:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:46 --> Loader Class Initialized
INFO - 2017-02-13 10:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:46 --> Controller Class Initialized
INFO - 2017-02-13 10:21:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:46 --> Model Class Initialized
INFO - 2017-02-13 10:21:46 --> Model Class Initialized
INFO - 2017-02-13 10:21:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:46 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:46 --> Total execution time: 0.1333
INFO - 2017-02-13 10:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:46 --> Controller Class Initialized
INFO - 2017-02-13 10:21:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:46 --> Model Class Initialized
INFO - 2017-02-13 10:21:46 --> Model Class Initialized
INFO - 2017-02-13 10:21:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:46 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:46 --> Total execution time: 0.3020
INFO - 2017-02-13 10:21:47 --> Config Class Initialized
INFO - 2017-02-13 10:21:47 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:47 --> Config Class Initialized
INFO - 2017-02-13 10:21:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:47 --> URI Class Initialized
INFO - 2017-02-13 10:21:47 --> Router Class Initialized
INFO - 2017-02-13 10:21:47 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:47 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:47 --> Input Class Initialized
INFO - 2017-02-13 10:21:47 --> URI Class Initialized
INFO - 2017-02-13 10:21:47 --> Language Class Initialized
INFO - 2017-02-13 10:21:47 --> Router Class Initialized
INFO - 2017-02-13 10:21:47 --> Loader Class Initialized
INFO - 2017-02-13 10:21:47 --> Output Class Initialized
INFO - 2017-02-13 10:21:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:47 --> Security Class Initialized
INFO - 2017-02-13 10:21:47 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:47 --> Input Class Initialized
INFO - 2017-02-13 10:21:47 --> Language Class Initialized
INFO - 2017-02-13 10:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:47 --> Controller Class Initialized
INFO - 2017-02-13 10:21:47 --> Loader Class Initialized
INFO - 2017-02-13 10:21:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:47 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:47 --> Model Class Initialized
INFO - 2017-02-13 10:21:47 --> Model Class Initialized
INFO - 2017-02-13 10:21:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:47 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:47 --> Total execution time: 0.1225
INFO - 2017-02-13 10:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:47 --> Controller Class Initialized
INFO - 2017-02-13 10:21:47 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:47 --> Model Class Initialized
INFO - 2017-02-13 10:21:47 --> Model Class Initialized
INFO - 2017-02-13 10:21:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:47 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:47 --> Total execution time: 0.2907
INFO - 2017-02-13 10:21:48 --> Config Class Initialized
INFO - 2017-02-13 10:21:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:48 --> Config Class Initialized
INFO - 2017-02-13 10:21:48 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:48 --> URI Class Initialized
INFO - 2017-02-13 10:21:48 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:48 --> Output Class Initialized
INFO - 2017-02-13 10:21:48 --> URI Class Initialized
INFO - 2017-02-13 10:21:48 --> Security Class Initialized
INFO - 2017-02-13 10:21:48 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:48 --> Input Class Initialized
INFO - 2017-02-13 10:21:48 --> Output Class Initialized
INFO - 2017-02-13 10:21:48 --> Language Class Initialized
INFO - 2017-02-13 10:21:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:48 --> Input Class Initialized
INFO - 2017-02-13 10:21:48 --> Loader Class Initialized
INFO - 2017-02-13 10:21:48 --> Language Class Initialized
INFO - 2017-02-13 10:21:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:48 --> Loader Class Initialized
INFO - 2017-02-13 10:21:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:48 --> Controller Class Initialized
INFO - 2017-02-13 10:21:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:48 --> Model Class Initialized
INFO - 2017-02-13 10:21:48 --> Model Class Initialized
INFO - 2017-02-13 10:21:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:48 --> Total execution time: 0.1346
INFO - 2017-02-13 10:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:48 --> Controller Class Initialized
INFO - 2017-02-13 10:21:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:48 --> Model Class Initialized
INFO - 2017-02-13 10:21:48 --> Model Class Initialized
INFO - 2017-02-13 10:21:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:48 --> Total execution time: 0.2514
INFO - 2017-02-13 10:21:49 --> Config Class Initialized
INFO - 2017-02-13 10:21:49 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:49 --> Config Class Initialized
INFO - 2017-02-13 10:21:49 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:49 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:49 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:49 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:49 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:49 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:49 --> Router Class Initialized
INFO - 2017-02-13 10:21:49 --> URI Class Initialized
INFO - 2017-02-13 10:21:49 --> Output Class Initialized
INFO - 2017-02-13 10:21:49 --> Router Class Initialized
INFO - 2017-02-13 10:21:49 --> Security Class Initialized
INFO - 2017-02-13 10:21:49 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:49 --> Input Class Initialized
INFO - 2017-02-13 10:21:49 --> Security Class Initialized
INFO - 2017-02-13 10:21:49 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:49 --> Input Class Initialized
INFO - 2017-02-13 10:21:49 --> Loader Class Initialized
INFO - 2017-02-13 10:21:49 --> Language Class Initialized
INFO - 2017-02-13 10:21:49 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:49 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:49 --> Controller Class Initialized
INFO - 2017-02-13 10:21:49 --> Loader Class Initialized
INFO - 2017-02-13 10:21:49 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:49 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:49 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:49 --> Model Class Initialized
INFO - 2017-02-13 10:21:49 --> Model Class Initialized
INFO - 2017-02-13 10:21:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:49 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:49 --> Total execution time: 0.1093
INFO - 2017-02-13 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:49 --> Controller Class Initialized
INFO - 2017-02-13 10:21:49 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:49 --> Model Class Initialized
INFO - 2017-02-13 10:21:49 --> Model Class Initialized
INFO - 2017-02-13 10:21:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:49 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:49 --> Total execution time: 0.2733
INFO - 2017-02-13 10:21:50 --> Config Class Initialized
INFO - 2017-02-13 10:21:50 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:50 --> Config Class Initialized
INFO - 2017-02-13 10:21:50 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:50 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:50 --> URI Class Initialized
DEBUG - 2017-02-13 10:21:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:50 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:50 --> Router Class Initialized
INFO - 2017-02-13 10:21:50 --> URI Class Initialized
INFO - 2017-02-13 10:21:50 --> Output Class Initialized
INFO - 2017-02-13 10:21:50 --> Security Class Initialized
INFO - 2017-02-13 10:21:50 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:50 --> Input Class Initialized
INFO - 2017-02-13 10:21:50 --> Language Class Initialized
INFO - 2017-02-13 10:21:50 --> Output Class Initialized
INFO - 2017-02-13 10:21:50 --> Security Class Initialized
INFO - 2017-02-13 10:21:50 --> Loader Class Initialized
DEBUG - 2017-02-13 10:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:50 --> Input Class Initialized
INFO - 2017-02-13 10:21:50 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:50 --> Language Class Initialized
INFO - 2017-02-13 10:21:50 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:50 --> Loader Class Initialized
INFO - 2017-02-13 10:21:50 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:50 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:50 --> Controller Class Initialized
INFO - 2017-02-13 10:21:50 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:50 --> Model Class Initialized
INFO - 2017-02-13 10:21:50 --> Model Class Initialized
INFO - 2017-02-13 10:21:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:50 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:50 --> Total execution time: 0.1432
INFO - 2017-02-13 10:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:50 --> Controller Class Initialized
INFO - 2017-02-13 10:21:50 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:50 --> Model Class Initialized
INFO - 2017-02-13 10:21:50 --> Model Class Initialized
INFO - 2017-02-13 10:21:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:51 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:51 --> Total execution time: 0.2836
INFO - 2017-02-13 10:21:52 --> Config Class Initialized
INFO - 2017-02-13 10:21:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:52 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:52 --> URI Class Initialized
INFO - 2017-02-13 10:21:52 --> Config Class Initialized
INFO - 2017-02-13 10:21:52 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:52 --> Router Class Initialized
INFO - 2017-02-13 10:21:52 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:52 --> Security Class Initialized
INFO - 2017-02-13 10:21:52 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:52 --> Input Class Initialized
INFO - 2017-02-13 10:21:52 --> Language Class Initialized
INFO - 2017-02-13 10:21:52 --> URI Class Initialized
INFO - 2017-02-13 10:21:52 --> Loader Class Initialized
INFO - 2017-02-13 10:21:52 --> Router Class Initialized
INFO - 2017-02-13 10:21:52 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:52 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:52 --> Output Class Initialized
INFO - 2017-02-13 10:21:52 --> Security Class Initialized
INFO - 2017-02-13 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:52 --> Controller Class Initialized
DEBUG - 2017-02-13 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:52 --> Input Class Initialized
INFO - 2017-02-13 10:21:52 --> Language Class Initialized
INFO - 2017-02-13 10:21:52 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:52 --> Loader Class Initialized
INFO - 2017-02-13 10:21:52 --> Model Class Initialized
INFO - 2017-02-13 10:21:52 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:52 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:52 --> Model Class Initialized
INFO - 2017-02-13 10:21:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:52 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:52 --> Total execution time: 0.1184
INFO - 2017-02-13 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:52 --> Controller Class Initialized
INFO - 2017-02-13 10:21:52 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:52 --> Model Class Initialized
INFO - 2017-02-13 10:21:52 --> Model Class Initialized
INFO - 2017-02-13 10:21:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:52 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:52 --> Total execution time: 0.3597
INFO - 2017-02-13 10:21:53 --> Config Class Initialized
INFO - 2017-02-13 10:21:53 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:53 --> Config Class Initialized
INFO - 2017-02-13 10:21:53 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:53 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:53 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:53 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:53 --> URI Class Initialized
INFO - 2017-02-13 10:21:53 --> Router Class Initialized
INFO - 2017-02-13 10:21:53 --> URI Class Initialized
INFO - 2017-02-13 10:21:53 --> Router Class Initialized
INFO - 2017-02-13 10:21:53 --> Output Class Initialized
INFO - 2017-02-13 10:21:53 --> Security Class Initialized
INFO - 2017-02-13 10:21:53 --> Output Class Initialized
INFO - 2017-02-13 10:21:53 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:53 --> Input Class Initialized
INFO - 2017-02-13 10:21:53 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:53 --> Input Class Initialized
INFO - 2017-02-13 10:21:53 --> Language Class Initialized
INFO - 2017-02-13 10:21:53 --> Loader Class Initialized
INFO - 2017-02-13 10:21:53 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:53 --> Loader Class Initialized
INFO - 2017-02-13 10:21:53 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:53 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:53 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:53 --> Controller Class Initialized
INFO - 2017-02-13 10:21:53 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:53 --> Model Class Initialized
INFO - 2017-02-13 10:21:53 --> Model Class Initialized
INFO - 2017-02-13 10:21:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:53 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:53 --> Total execution time: 0.2214
INFO - 2017-02-13 10:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:53 --> Controller Class Initialized
INFO - 2017-02-13 10:21:53 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:53 --> Model Class Initialized
INFO - 2017-02-13 10:21:53 --> Model Class Initialized
INFO - 2017-02-13 10:21:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:53 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:53 --> Total execution time: 0.2623
INFO - 2017-02-13 10:21:54 --> Config Class Initialized
INFO - 2017-02-13 10:21:54 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:54 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:54 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:54 --> Config Class Initialized
INFO - 2017-02-13 10:21:54 --> URI Class Initialized
INFO - 2017-02-13 10:21:54 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:54 --> Router Class Initialized
DEBUG - 2017-02-13 10:21:54 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:54 --> Output Class Initialized
INFO - 2017-02-13 10:21:54 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:54 --> URI Class Initialized
INFO - 2017-02-13 10:21:54 --> Router Class Initialized
INFO - 2017-02-13 10:21:54 --> Security Class Initialized
INFO - 2017-02-13 10:21:54 --> Output Class Initialized
INFO - 2017-02-13 10:21:54 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:54 --> Input Class Initialized
INFO - 2017-02-13 10:21:54 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:54 --> Input Class Initialized
INFO - 2017-02-13 10:21:54 --> Loader Class Initialized
INFO - 2017-02-13 10:21:54 --> Language Class Initialized
INFO - 2017-02-13 10:21:54 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:54 --> Loader Class Initialized
INFO - 2017-02-13 10:21:54 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:54 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:54 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:54 --> Controller Class Initialized
INFO - 2017-02-13 10:21:54 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:54 --> Model Class Initialized
INFO - 2017-02-13 10:21:54 --> Model Class Initialized
INFO - 2017-02-13 10:21:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:54 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:54 --> Total execution time: 0.1317
INFO - 2017-02-13 10:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:54 --> Controller Class Initialized
INFO - 2017-02-13 10:21:54 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:54 --> Model Class Initialized
INFO - 2017-02-13 10:21:54 --> Model Class Initialized
INFO - 2017-02-13 10:21:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:54 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:54 --> Total execution time: 0.3234
INFO - 2017-02-13 10:21:56 --> Config Class Initialized
INFO - 2017-02-13 10:21:56 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:56 --> Config Class Initialized
INFO - 2017-02-13 10:21:56 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:56 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:21:56 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:56 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:56 --> URI Class Initialized
INFO - 2017-02-13 10:21:56 --> URI Class Initialized
INFO - 2017-02-13 10:21:56 --> Router Class Initialized
INFO - 2017-02-13 10:21:56 --> Router Class Initialized
INFO - 2017-02-13 10:21:56 --> Output Class Initialized
INFO - 2017-02-13 10:21:56 --> Output Class Initialized
INFO - 2017-02-13 10:21:56 --> Security Class Initialized
INFO - 2017-02-13 10:21:56 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:56 --> Input Class Initialized
INFO - 2017-02-13 10:21:56 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:56 --> Input Class Initialized
INFO - 2017-02-13 10:21:56 --> Language Class Initialized
INFO - 2017-02-13 10:21:56 --> Loader Class Initialized
INFO - 2017-02-13 10:21:56 --> Loader Class Initialized
INFO - 2017-02-13 10:21:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:56 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:56 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:56 --> Controller Class Initialized
INFO - 2017-02-13 10:21:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:56 --> Model Class Initialized
INFO - 2017-02-13 10:21:56 --> Model Class Initialized
INFO - 2017-02-13 10:21:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:56 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:56 --> Total execution time: 0.4553
INFO - 2017-02-13 10:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:56 --> Controller Class Initialized
INFO - 2017-02-13 10:21:56 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:56 --> Model Class Initialized
INFO - 2017-02-13 10:21:56 --> Model Class Initialized
INFO - 2017-02-13 10:21:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:56 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:56 --> Total execution time: 0.5524
INFO - 2017-02-13 10:21:57 --> Config Class Initialized
INFO - 2017-02-13 10:21:57 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:57 --> Config Class Initialized
INFO - 2017-02-13 10:21:57 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:57 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:57 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:57 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:57 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:57 --> URI Class Initialized
INFO - 2017-02-13 10:21:57 --> URI Class Initialized
INFO - 2017-02-13 10:21:57 --> Router Class Initialized
INFO - 2017-02-13 10:21:57 --> Router Class Initialized
INFO - 2017-02-13 10:21:57 --> Output Class Initialized
INFO - 2017-02-13 10:21:57 --> Security Class Initialized
INFO - 2017-02-13 10:21:57 --> Output Class Initialized
DEBUG - 2017-02-13 10:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:57 --> Input Class Initialized
INFO - 2017-02-13 10:21:57 --> Security Class Initialized
INFO - 2017-02-13 10:21:57 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:57 --> Input Class Initialized
INFO - 2017-02-13 10:21:57 --> Language Class Initialized
INFO - 2017-02-13 10:21:57 --> Loader Class Initialized
INFO - 2017-02-13 10:21:57 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:57 --> Loader Class Initialized
INFO - 2017-02-13 10:21:57 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:57 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:57 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:57 --> Controller Class Initialized
INFO - 2017-02-13 10:21:57 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:57 --> Model Class Initialized
INFO - 2017-02-13 10:21:57 --> Model Class Initialized
INFO - 2017-02-13 10:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:57 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:57 --> Total execution time: 0.1291
INFO - 2017-02-13 10:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:57 --> Controller Class Initialized
INFO - 2017-02-13 10:21:57 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:57 --> Model Class Initialized
INFO - 2017-02-13 10:21:57 --> Model Class Initialized
INFO - 2017-02-13 10:21:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:57 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:57 --> Total execution time: 0.3105
INFO - 2017-02-13 10:21:58 --> Config Class Initialized
INFO - 2017-02-13 10:21:58 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:58 --> Config Class Initialized
INFO - 2017-02-13 10:21:58 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:21:58 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:58 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:21:58 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:58 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:58 --> URI Class Initialized
INFO - 2017-02-13 10:21:58 --> URI Class Initialized
INFO - 2017-02-13 10:21:58 --> Router Class Initialized
INFO - 2017-02-13 10:21:58 --> Router Class Initialized
INFO - 2017-02-13 10:21:58 --> Output Class Initialized
INFO - 2017-02-13 10:21:58 --> Output Class Initialized
INFO - 2017-02-13 10:21:58 --> Security Class Initialized
INFO - 2017-02-13 10:21:58 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:58 --> Input Class Initialized
INFO - 2017-02-13 10:21:58 --> Language Class Initialized
DEBUG - 2017-02-13 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:58 --> Input Class Initialized
INFO - 2017-02-13 10:21:58 --> Language Class Initialized
INFO - 2017-02-13 10:21:58 --> Loader Class Initialized
INFO - 2017-02-13 10:21:58 --> Loader Class Initialized
INFO - 2017-02-13 10:21:58 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:58 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:58 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:58 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:58 --> Controller Class Initialized
INFO - 2017-02-13 10:21:58 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:58 --> Model Class Initialized
INFO - 2017-02-13 10:21:58 --> Model Class Initialized
INFO - 2017-02-13 10:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:58 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:58 --> Total execution time: 0.1400
INFO - 2017-02-13 10:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:58 --> Controller Class Initialized
INFO - 2017-02-13 10:21:59 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:59 --> Model Class Initialized
INFO - 2017-02-13 10:21:59 --> Model Class Initialized
INFO - 2017-02-13 10:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:59 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:59 --> Total execution time: 0.4197
INFO - 2017-02-13 10:21:59 --> Config Class Initialized
INFO - 2017-02-13 10:21:59 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:59 --> Config Class Initialized
DEBUG - 2017-02-13 10:21:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:59 --> Hooks Class Initialized
INFO - 2017-02-13 10:21:59 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:59 --> URI Class Initialized
INFO - 2017-02-13 10:21:59 --> Router Class Initialized
INFO - 2017-02-13 10:21:59 --> Output Class Initialized
INFO - 2017-02-13 10:21:59 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:59 --> Input Class Initialized
DEBUG - 2017-02-13 10:21:59 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:21:59 --> Utf8 Class Initialized
INFO - 2017-02-13 10:21:59 --> Language Class Initialized
INFO - 2017-02-13 10:21:59 --> URI Class Initialized
INFO - 2017-02-13 10:21:59 --> Router Class Initialized
INFO - 2017-02-13 10:21:59 --> Loader Class Initialized
INFO - 2017-02-13 10:21:59 --> Output Class Initialized
INFO - 2017-02-13 10:21:59 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:59 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:59 --> Security Class Initialized
DEBUG - 2017-02-13 10:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:21:59 --> Input Class Initialized
INFO - 2017-02-13 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:59 --> Language Class Initialized
INFO - 2017-02-13 10:21:59 --> Controller Class Initialized
INFO - 2017-02-13 10:21:59 --> Loader Class Initialized
INFO - 2017-02-13 10:21:59 --> Helper loaded: url_helper
INFO - 2017-02-13 10:21:59 --> Helper loaded: language_helper
INFO - 2017-02-13 10:21:59 --> Database Driver Class Initialized
INFO - 2017-02-13 10:21:59 --> Model Class Initialized
INFO - 2017-02-13 10:21:59 --> Model Class Initialized
INFO - 2017-02-13 10:21:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:21:59 --> Final output sent to browser
DEBUG - 2017-02-13 10:21:59 --> Total execution time: 0.1154
INFO - 2017-02-13 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:21:59 --> Controller Class Initialized
INFO - 2017-02-13 10:22:00 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:00 --> Model Class Initialized
INFO - 2017-02-13 10:22:00 --> Model Class Initialized
INFO - 2017-02-13 10:22:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:00 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:00 --> Total execution time: 0.3465
INFO - 2017-02-13 10:22:01 --> Config Class Initialized
INFO - 2017-02-13 10:22:01 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:01 --> Config Class Initialized
INFO - 2017-02-13 10:22:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:01 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:01 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:01 --> Router Class Initialized
INFO - 2017-02-13 10:22:01 --> URI Class Initialized
INFO - 2017-02-13 10:22:01 --> Output Class Initialized
INFO - 2017-02-13 10:22:01 --> Router Class Initialized
INFO - 2017-02-13 10:22:01 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:01 --> Output Class Initialized
INFO - 2017-02-13 10:22:01 --> Input Class Initialized
INFO - 2017-02-13 10:22:01 --> Language Class Initialized
INFO - 2017-02-13 10:22:01 --> Security Class Initialized
INFO - 2017-02-13 10:22:01 --> Loader Class Initialized
INFO - 2017-02-13 10:22:01 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:01 --> Input Class Initialized
INFO - 2017-02-13 10:22:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:01 --> Language Class Initialized
INFO - 2017-02-13 10:22:01 --> Loader Class Initialized
INFO - 2017-02-13 10:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:01 --> Controller Class Initialized
INFO - 2017-02-13 10:22:01 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:01 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:01 --> Model Class Initialized
INFO - 2017-02-13 10:22:01 --> Model Class Initialized
INFO - 2017-02-13 10:22:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:01 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:01 --> Total execution time: 0.1040
INFO - 2017-02-13 10:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:01 --> Controller Class Initialized
INFO - 2017-02-13 10:22:01 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:01 --> Model Class Initialized
INFO - 2017-02-13 10:22:01 --> Model Class Initialized
INFO - 2017-02-13 10:22:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:01 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:01 --> Total execution time: 0.3324
INFO - 2017-02-13 10:22:02 --> Config Class Initialized
INFO - 2017-02-13 10:22:02 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:02 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:02 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:02 --> URI Class Initialized
INFO - 2017-02-13 10:22:02 --> Router Class Initialized
INFO - 2017-02-13 10:22:02 --> Config Class Initialized
INFO - 2017-02-13 10:22:02 --> Output Class Initialized
INFO - 2017-02-13 10:22:02 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:02 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:02 --> Input Class Initialized
DEBUG - 2017-02-13 10:22:02 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:02 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:02 --> Language Class Initialized
INFO - 2017-02-13 10:22:02 --> URI Class Initialized
INFO - 2017-02-13 10:22:02 --> Router Class Initialized
INFO - 2017-02-13 10:22:02 --> Loader Class Initialized
INFO - 2017-02-13 10:22:02 --> Output Class Initialized
INFO - 2017-02-13 10:22:02 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:02 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:02 --> Security Class Initialized
INFO - 2017-02-13 10:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:02 --> Controller Class Initialized
DEBUG - 2017-02-13 10:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:02 --> Input Class Initialized
INFO - 2017-02-13 10:22:02 --> Language Class Initialized
INFO - 2017-02-13 10:22:02 --> Loader Class Initialized
INFO - 2017-02-13 10:22:02 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:02 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:02 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:02 --> Model Class Initialized
INFO - 2017-02-13 10:22:02 --> Model Class Initialized
INFO - 2017-02-13 10:22:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:02 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:02 --> Total execution time: 0.1833
INFO - 2017-02-13 10:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:02 --> Controller Class Initialized
INFO - 2017-02-13 10:22:03 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:03 --> Model Class Initialized
INFO - 2017-02-13 10:22:03 --> Model Class Initialized
INFO - 2017-02-13 10:22:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:03 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:03 --> Total execution time: 0.4461
INFO - 2017-02-13 10:22:04 --> Config Class Initialized
INFO - 2017-02-13 10:22:04 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:04 --> Config Class Initialized
INFO - 2017-02-13 10:22:04 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:04 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:04 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:04 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:04 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:04 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:04 --> Router Class Initialized
INFO - 2017-02-13 10:22:04 --> URI Class Initialized
INFO - 2017-02-13 10:22:04 --> Output Class Initialized
INFO - 2017-02-13 10:22:04 --> Router Class Initialized
INFO - 2017-02-13 10:22:04 --> Output Class Initialized
INFO - 2017-02-13 10:22:04 --> Security Class Initialized
INFO - 2017-02-13 10:22:04 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:04 --> Input Class Initialized
INFO - 2017-02-13 10:22:04 --> Language Class Initialized
INFO - 2017-02-13 10:22:04 --> Loader Class Initialized
DEBUG - 2017-02-13 10:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:04 --> Input Class Initialized
INFO - 2017-02-13 10:22:04 --> Language Class Initialized
INFO - 2017-02-13 10:22:04 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:04 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:04 --> Loader Class Initialized
INFO - 2017-02-13 10:22:04 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:04 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:04 --> Controller Class Initialized
INFO - 2017-02-13 10:22:04 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:04 --> Model Class Initialized
INFO - 2017-02-13 10:22:04 --> Model Class Initialized
INFO - 2017-02-13 10:22:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:04 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:04 --> Total execution time: 0.1281
INFO - 2017-02-13 10:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:04 --> Controller Class Initialized
INFO - 2017-02-13 10:22:04 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:04 --> Model Class Initialized
INFO - 2017-02-13 10:22:04 --> Model Class Initialized
INFO - 2017-02-13 10:22:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:05 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:05 --> Total execution time: 0.5164
INFO - 2017-02-13 10:22:07 --> Config Class Initialized
INFO - 2017-02-13 10:22:07 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:07 --> Config Class Initialized
INFO - 2017-02-13 10:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:07 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:07 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:07 --> Router Class Initialized
INFO - 2017-02-13 10:22:07 --> URI Class Initialized
INFO - 2017-02-13 10:22:07 --> Output Class Initialized
INFO - 2017-02-13 10:22:07 --> Router Class Initialized
INFO - 2017-02-13 10:22:07 --> Security Class Initialized
INFO - 2017-02-13 10:22:07 --> Output Class Initialized
INFO - 2017-02-13 10:22:07 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 10:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:07 --> Input Class Initialized
INFO - 2017-02-13 10:22:07 --> Input Class Initialized
INFO - 2017-02-13 10:22:07 --> Language Class Initialized
INFO - 2017-02-13 10:22:07 --> Language Class Initialized
INFO - 2017-02-13 10:22:07 --> Loader Class Initialized
INFO - 2017-02-13 10:22:07 --> Loader Class Initialized
INFO - 2017-02-13 10:22:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:07 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:07 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:07 --> Controller Class Initialized
INFO - 2017-02-13 10:22:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:07 --> Model Class Initialized
INFO - 2017-02-13 10:22:07 --> Model Class Initialized
INFO - 2017-02-13 10:22:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:07 --> Total execution time: 0.1231
INFO - 2017-02-13 10:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:07 --> Controller Class Initialized
INFO - 2017-02-13 10:22:07 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:07 --> Model Class Initialized
INFO - 2017-02-13 10:22:07 --> Model Class Initialized
INFO - 2017-02-13 10:22:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:07 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:07 --> Total execution time: 0.5100
INFO - 2017-02-13 10:22:08 --> Config Class Initialized
INFO - 2017-02-13 10:22:08 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:08 --> Config Class Initialized
INFO - 2017-02-13 10:22:08 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:08 --> Config Class Initialized
INFO - 2017-02-13 10:22:08 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:08 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:08 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:22:08 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:08 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:08 --> URI Class Initialized
INFO - 2017-02-13 10:22:08 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:08 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:08 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:08 --> Router Class Initialized
INFO - 2017-02-13 10:22:08 --> Router Class Initialized
INFO - 2017-02-13 10:22:08 --> URI Class Initialized
INFO - 2017-02-13 10:22:08 --> Output Class Initialized
INFO - 2017-02-13 10:22:08 --> Output Class Initialized
INFO - 2017-02-13 10:22:08 --> Router Class Initialized
INFO - 2017-02-13 10:22:08 --> Security Class Initialized
INFO - 2017-02-13 10:22:08 --> Security Class Initialized
INFO - 2017-02-13 10:22:08 --> Output Class Initialized
INFO - 2017-02-13 10:22:08 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:08 --> Input Class Initialized
DEBUG - 2017-02-13 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:08 --> Input Class Initialized
INFO - 2017-02-13 10:22:08 --> Language Class Initialized
DEBUG - 2017-02-13 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:08 --> Input Class Initialized
INFO - 2017-02-13 10:22:08 --> Language Class Initialized
INFO - 2017-02-13 10:22:08 --> Language Class Initialized
INFO - 2017-02-13 10:22:08 --> Loader Class Initialized
INFO - 2017-02-13 10:22:08 --> Loader Class Initialized
INFO - 2017-02-13 10:22:08 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:08 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:08 --> Loader Class Initialized
INFO - 2017-02-13 10:22:08 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:08 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:08 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:08 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:08 --> Controller Class Initialized
INFO - 2017-02-13 10:22:08 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:08 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:08 --> Total execution time: 0.1380
INFO - 2017-02-13 10:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:08 --> Controller Class Initialized
INFO - 2017-02-13 10:22:08 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:08 --> Controller Class Initialized
INFO - 2017-02-13 10:22:08 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:08 --> Config Class Initialized
INFO - 2017-02-13 10:22:08 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:08 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> URI Class Initialized
INFO - 2017-02-13 10:22:08 --> Router Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Output Class Initialized
INFO - 2017-02-13 10:22:08 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:08 --> Input Class Initialized
INFO - 2017-02-13 10:22:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:08 --> Language Class Initialized
INFO - 2017-02-13 10:22:08 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:08 --> Total execution time: 0.3115
INFO - 2017-02-13 10:22:08 --> Loader Class Initialized
INFO - 2017-02-13 10:22:08 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:08 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:08 --> Controller Class Initialized
INFO - 2017-02-13 10:22:08 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:08 --> Model Class Initialized
INFO - 2017-02-13 10:22:09 --> Model Class Initialized
INFO - 2017-02-13 10:22:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:22:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08.php
INFO - 2017-02-13 10:22:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:22:09 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:09 --> Total execution time: 0.2239
INFO - 2017-02-13 10:22:11 --> Config Class Initialized
INFO - 2017-02-13 10:22:11 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:11 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:11 --> URI Class Initialized
INFO - 2017-02-13 10:22:11 --> Router Class Initialized
INFO - 2017-02-13 10:22:11 --> Output Class Initialized
INFO - 2017-02-13 10:22:11 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:11 --> Input Class Initialized
INFO - 2017-02-13 10:22:11 --> Language Class Initialized
INFO - 2017-02-13 10:22:11 --> Loader Class Initialized
INFO - 2017-02-13 10:22:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:11 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:11 --> Controller Class Initialized
INFO - 2017-02-13 10:22:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:11 --> Model Class Initialized
INFO - 2017-02-13 10:22:11 --> Model Class Initialized
INFO - 2017-02-13 10:22:11 --> Model Class Initialized
INFO - 2017-02-13 10:22:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:11 --> Config Class Initialized
INFO - 2017-02-13 10:22:11 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:11 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:11 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:11 --> URI Class Initialized
INFO - 2017-02-13 10:22:11 --> Router Class Initialized
INFO - 2017-02-13 10:22:11 --> Output Class Initialized
INFO - 2017-02-13 10:22:11 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:11 --> Input Class Initialized
INFO - 2017-02-13 10:22:11 --> Language Class Initialized
INFO - 2017-02-13 10:22:11 --> Loader Class Initialized
INFO - 2017-02-13 10:22:11 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:11 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:11 --> Controller Class Initialized
INFO - 2017-02-13 10:22:11 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:11 --> Model Class Initialized
INFO - 2017-02-13 10:22:11 --> Model Class Initialized
INFO - 2017-02-13 10:22:11 --> Model Class Initialized
INFO - 2017-02-13 10:22:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:22:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_08_attempt.php
INFO - 2017-02-13 10:22:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:22:11 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:11 --> Total execution time: 0.1938
INFO - 2017-02-13 10:22:12 --> Config Class Initialized
INFO - 2017-02-13 10:22:12 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:12 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:12 --> URI Class Initialized
INFO - 2017-02-13 10:22:12 --> Router Class Initialized
INFO - 2017-02-13 10:22:12 --> Output Class Initialized
INFO - 2017-02-13 10:22:12 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:12 --> Input Class Initialized
INFO - 2017-02-13 10:22:12 --> Language Class Initialized
INFO - 2017-02-13 10:22:12 --> Loader Class Initialized
INFO - 2017-02-13 10:22:12 --> Config Class Initialized
INFO - 2017-02-13 10:22:12 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:12 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:22:12 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:12 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:12 --> URI Class Initialized
INFO - 2017-02-13 10:22:12 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:12 --> Router Class Initialized
INFO - 2017-02-13 10:22:12 --> Output Class Initialized
INFO - 2017-02-13 10:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:12 --> Controller Class Initialized
INFO - 2017-02-13 10:22:12 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:12 --> Input Class Initialized
INFO - 2017-02-13 10:22:12 --> Language Class Initialized
INFO - 2017-02-13 10:22:12 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:12 --> Model Class Initialized
INFO - 2017-02-13 10:22:12 --> Loader Class Initialized
INFO - 2017-02-13 10:22:12 --> Model Class Initialized
INFO - 2017-02-13 10:22:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:12 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:12 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:12 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:12 --> Total execution time: 0.1906
INFO - 2017-02-13 10:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:12 --> Controller Class Initialized
INFO - 2017-02-13 10:22:12 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:12 --> Model Class Initialized
INFO - 2017-02-13 10:22:12 --> Model Class Initialized
INFO - 2017-02-13 10:22:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:22:12 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:22:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:22:12 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:12 --> Total execution time: 0.3724
INFO - 2017-02-13 10:22:14 --> Config Class Initialized
INFO - 2017-02-13 10:22:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:14 --> URI Class Initialized
INFO - 2017-02-13 10:22:14 --> Config Class Initialized
INFO - 2017-02-13 10:22:14 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:14 --> Router Class Initialized
DEBUG - 2017-02-13 10:22:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:14 --> Output Class Initialized
INFO - 2017-02-13 10:22:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:14 --> URI Class Initialized
INFO - 2017-02-13 10:22:14 --> Security Class Initialized
INFO - 2017-02-13 10:22:14 --> Router Class Initialized
DEBUG - 2017-02-13 10:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:14 --> Input Class Initialized
INFO - 2017-02-13 10:22:14 --> Output Class Initialized
INFO - 2017-02-13 10:22:14 --> Language Class Initialized
INFO - 2017-02-13 10:22:14 --> Security Class Initialized
INFO - 2017-02-13 10:22:14 --> Loader Class Initialized
DEBUG - 2017-02-13 10:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:14 --> Input Class Initialized
INFO - 2017-02-13 10:22:14 --> Language Class Initialized
INFO - 2017-02-13 10:22:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:14 --> Loader Class Initialized
INFO - 2017-02-13 10:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:14 --> Controller Class Initialized
INFO - 2017-02-13 10:22:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:14 --> Model Class Initialized
INFO - 2017-02-13 10:22:14 --> Model Class Initialized
INFO - 2017-02-13 10:22:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:14 --> Total execution time: 0.1165
INFO - 2017-02-13 10:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:14 --> Controller Class Initialized
INFO - 2017-02-13 10:22:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:14 --> Model Class Initialized
INFO - 2017-02-13 10:22:14 --> Model Class Initialized
INFO - 2017-02-13 10:22:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:14 --> Total execution time: 0.2476
INFO - 2017-02-13 10:22:15 --> Config Class Initialized
INFO - 2017-02-13 10:22:15 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:15 --> Config Class Initialized
INFO - 2017-02-13 10:22:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:15 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:15 --> URI Class Initialized
INFO - 2017-02-13 10:22:15 --> Router Class Initialized
INFO - 2017-02-13 10:22:15 --> Output Class Initialized
DEBUG - 2017-02-13 10:22:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:15 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:15 --> Security Class Initialized
INFO - 2017-02-13 10:22:15 --> URI Class Initialized
INFO - 2017-02-13 10:22:15 --> Router Class Initialized
DEBUG - 2017-02-13 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:15 --> Input Class Initialized
INFO - 2017-02-13 10:22:15 --> Language Class Initialized
INFO - 2017-02-13 10:22:15 --> Output Class Initialized
INFO - 2017-02-13 10:22:15 --> Loader Class Initialized
INFO - 2017-02-13 10:22:15 --> Security Class Initialized
INFO - 2017-02-13 10:22:15 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:15 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:15 --> Input Class Initialized
INFO - 2017-02-13 10:22:15 --> Language Class Initialized
INFO - 2017-02-13 10:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:15 --> Controller Class Initialized
INFO - 2017-02-13 10:22:15 --> Loader Class Initialized
INFO - 2017-02-13 10:22:15 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:15 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:15 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:15 --> Model Class Initialized
INFO - 2017-02-13 10:22:15 --> Model Class Initialized
INFO - 2017-02-13 10:22:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:16 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:16 --> Total execution time: 0.2455
INFO - 2017-02-13 10:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:16 --> Controller Class Initialized
INFO - 2017-02-13 10:22:16 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:16 --> Model Class Initialized
INFO - 2017-02-13 10:22:16 --> Model Class Initialized
INFO - 2017-02-13 10:22:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:16 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:16 --> Total execution time: 0.2930
INFO - 2017-02-13 10:22:17 --> Config Class Initialized
INFO - 2017-02-13 10:22:17 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:17 --> Config Class Initialized
INFO - 2017-02-13 10:22:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:17 --> URI Class Initialized
INFO - 2017-02-13 10:22:17 --> Router Class Initialized
INFO - 2017-02-13 10:22:17 --> Output Class Initialized
DEBUG - 2017-02-13 10:22:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:17 --> URI Class Initialized
INFO - 2017-02-13 10:22:17 --> Security Class Initialized
INFO - 2017-02-13 10:22:17 --> Router Class Initialized
DEBUG - 2017-02-13 10:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:17 --> Output Class Initialized
INFO - 2017-02-13 10:22:17 --> Input Class Initialized
INFO - 2017-02-13 10:22:17 --> Language Class Initialized
INFO - 2017-02-13 10:22:17 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:17 --> Loader Class Initialized
INFO - 2017-02-13 10:22:17 --> Input Class Initialized
INFO - 2017-02-13 10:22:17 --> Language Class Initialized
INFO - 2017-02-13 10:22:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:17 --> Loader Class Initialized
INFO - 2017-02-13 10:22:17 --> Controller Class Initialized
INFO - 2017-02-13 10:22:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:17 --> Model Class Initialized
INFO - 2017-02-13 10:22:17 --> Model Class Initialized
INFO - 2017-02-13 10:22:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:17 --> Total execution time: 0.1230
INFO - 2017-02-13 10:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:17 --> Controller Class Initialized
INFO - 2017-02-13 10:22:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:17 --> Model Class Initialized
INFO - 2017-02-13 10:22:17 --> Model Class Initialized
INFO - 2017-02-13 10:22:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:17 --> Total execution time: 0.2262
INFO - 2017-02-13 10:22:20 --> Config Class Initialized
INFO - 2017-02-13 10:22:20 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:20 --> Config Class Initialized
INFO - 2017-02-13 10:22:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:20 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:22:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:20 --> URI Class Initialized
INFO - 2017-02-13 10:22:20 --> URI Class Initialized
INFO - 2017-02-13 10:22:20 --> Router Class Initialized
INFO - 2017-02-13 10:22:20 --> Router Class Initialized
INFO - 2017-02-13 10:22:20 --> Output Class Initialized
INFO - 2017-02-13 10:22:20 --> Output Class Initialized
INFO - 2017-02-13 10:22:20 --> Security Class Initialized
INFO - 2017-02-13 10:22:20 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:20 --> Input Class Initialized
DEBUG - 2017-02-13 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:20 --> Language Class Initialized
INFO - 2017-02-13 10:22:20 --> Input Class Initialized
INFO - 2017-02-13 10:22:20 --> Loader Class Initialized
INFO - 2017-02-13 10:22:20 --> Language Class Initialized
INFO - 2017-02-13 10:22:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:20 --> Loader Class Initialized
INFO - 2017-02-13 10:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:20 --> Controller Class Initialized
INFO - 2017-02-13 10:22:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:20 --> Model Class Initialized
INFO - 2017-02-13 10:22:20 --> Model Class Initialized
INFO - 2017-02-13 10:22:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:20 --> Total execution time: 0.1097
INFO - 2017-02-13 10:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:20 --> Controller Class Initialized
INFO - 2017-02-13 10:22:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:20 --> Model Class Initialized
INFO - 2017-02-13 10:22:20 --> Model Class Initialized
INFO - 2017-02-13 10:22:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:20 --> Total execution time: 0.2754
INFO - 2017-02-13 10:22:21 --> Config Class Initialized
INFO - 2017-02-13 10:22:21 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:21 --> Config Class Initialized
INFO - 2017-02-13 10:22:21 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:21 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:21 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:21 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:21 --> URI Class Initialized
INFO - 2017-02-13 10:22:21 --> Router Class Initialized
INFO - 2017-02-13 10:22:21 --> Router Class Initialized
INFO - 2017-02-13 10:22:21 --> Output Class Initialized
INFO - 2017-02-13 10:22:21 --> Output Class Initialized
INFO - 2017-02-13 10:22:21 --> Security Class Initialized
INFO - 2017-02-13 10:22:21 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:21 --> Input Class Initialized
INFO - 2017-02-13 10:22:21 --> Language Class Initialized
DEBUG - 2017-02-13 10:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:21 --> Input Class Initialized
INFO - 2017-02-13 10:22:21 --> Language Class Initialized
INFO - 2017-02-13 10:22:21 --> Loader Class Initialized
INFO - 2017-02-13 10:22:21 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:21 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:21 --> Loader Class Initialized
INFO - 2017-02-13 10:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:21 --> Controller Class Initialized
INFO - 2017-02-13 10:22:21 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:21 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:21 --> Model Class Initialized
INFO - 2017-02-13 10:22:21 --> Model Class Initialized
INFO - 2017-02-13 10:22:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:21 --> Total execution time: 0.1338
INFO - 2017-02-13 10:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:21 --> Controller Class Initialized
INFO - 2017-02-13 10:22:21 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:21 --> Model Class Initialized
INFO - 2017-02-13 10:22:21 --> Model Class Initialized
INFO - 2017-02-13 10:22:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:21 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:21 --> Total execution time: 0.2669
INFO - 2017-02-13 10:22:23 --> Config Class Initialized
INFO - 2017-02-13 10:22:23 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:23 --> URI Class Initialized
INFO - 2017-02-13 10:22:23 --> Config Class Initialized
INFO - 2017-02-13 10:22:23 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:23 --> Router Class Initialized
INFO - 2017-02-13 10:22:23 --> Output Class Initialized
DEBUG - 2017-02-13 10:22:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:23 --> Security Class Initialized
INFO - 2017-02-13 10:22:23 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:23 --> Input Class Initialized
INFO - 2017-02-13 10:22:23 --> Language Class Initialized
INFO - 2017-02-13 10:22:23 --> Router Class Initialized
INFO - 2017-02-13 10:22:23 --> Loader Class Initialized
INFO - 2017-02-13 10:22:23 --> Output Class Initialized
INFO - 2017-02-13 10:22:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:23 --> Security Class Initialized
INFO - 2017-02-13 10:22:23 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:23 --> Input Class Initialized
INFO - 2017-02-13 10:22:23 --> Language Class Initialized
INFO - 2017-02-13 10:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:23 --> Controller Class Initialized
INFO - 2017-02-13 10:22:23 --> Loader Class Initialized
INFO - 2017-02-13 10:22:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:23 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:23 --> Model Class Initialized
INFO - 2017-02-13 10:22:23 --> Model Class Initialized
INFO - 2017-02-13 10:22:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:23 --> Total execution time: 0.1292
INFO - 2017-02-13 10:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:23 --> Controller Class Initialized
INFO - 2017-02-13 10:22:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:23 --> Model Class Initialized
INFO - 2017-02-13 10:22:23 --> Model Class Initialized
INFO - 2017-02-13 10:22:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:23 --> Total execution time: 0.3589
INFO - 2017-02-13 10:22:24 --> Config Class Initialized
INFO - 2017-02-13 10:22:24 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:24 --> Config Class Initialized
INFO - 2017-02-13 10:22:24 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:24 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:24 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:22:24 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:24 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:24 --> URI Class Initialized
INFO - 2017-02-13 10:22:24 --> URI Class Initialized
INFO - 2017-02-13 10:22:24 --> Router Class Initialized
INFO - 2017-02-13 10:22:24 --> Router Class Initialized
INFO - 2017-02-13 10:22:24 --> Output Class Initialized
INFO - 2017-02-13 10:22:24 --> Output Class Initialized
INFO - 2017-02-13 10:22:24 --> Security Class Initialized
INFO - 2017-02-13 10:22:24 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:24 --> Input Class Initialized
DEBUG - 2017-02-13 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:24 --> Language Class Initialized
INFO - 2017-02-13 10:22:24 --> Input Class Initialized
INFO - 2017-02-13 10:22:24 --> Language Class Initialized
INFO - 2017-02-13 10:22:24 --> Loader Class Initialized
INFO - 2017-02-13 10:22:24 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:24 --> Loader Class Initialized
INFO - 2017-02-13 10:22:24 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:24 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:24 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:24 --> Controller Class Initialized
INFO - 2017-02-13 10:22:24 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:24 --> Model Class Initialized
INFO - 2017-02-13 10:22:24 --> Model Class Initialized
INFO - 2017-02-13 10:22:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:24 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:24 --> Total execution time: 0.2712
INFO - 2017-02-13 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:24 --> Controller Class Initialized
INFO - 2017-02-13 10:22:24 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:24 --> Model Class Initialized
INFO - 2017-02-13 10:22:24 --> Model Class Initialized
INFO - 2017-02-13 10:22:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:24 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:24 --> Total execution time: 0.3314
INFO - 2017-02-13 10:22:25 --> Config Class Initialized
INFO - 2017-02-13 10:22:25 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:25 --> Config Class Initialized
INFO - 2017-02-13 10:22:25 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:25 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:22:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:25 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:25 --> URI Class Initialized
INFO - 2017-02-13 10:22:25 --> URI Class Initialized
INFO - 2017-02-13 10:22:25 --> Router Class Initialized
INFO - 2017-02-13 10:22:25 --> Router Class Initialized
INFO - 2017-02-13 10:22:25 --> Output Class Initialized
INFO - 2017-02-13 10:22:25 --> Output Class Initialized
INFO - 2017-02-13 10:22:25 --> Security Class Initialized
INFO - 2017-02-13 10:22:25 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:25 --> Input Class Initialized
INFO - 2017-02-13 10:22:25 --> Language Class Initialized
DEBUG - 2017-02-13 10:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:25 --> Input Class Initialized
INFO - 2017-02-13 10:22:25 --> Language Class Initialized
INFO - 2017-02-13 10:22:25 --> Loader Class Initialized
INFO - 2017-02-13 10:22:25 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:25 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:25 --> Loader Class Initialized
INFO - 2017-02-13 10:22:25 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:25 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:25 --> Controller Class Initialized
INFO - 2017-02-13 10:22:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:25 --> Model Class Initialized
INFO - 2017-02-13 10:22:25 --> Model Class Initialized
INFO - 2017-02-13 10:22:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:25 --> Total execution time: 0.1245
INFO - 2017-02-13 10:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:25 --> Controller Class Initialized
INFO - 2017-02-13 10:22:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:25 --> Model Class Initialized
INFO - 2017-02-13 10:22:25 --> Model Class Initialized
INFO - 2017-02-13 10:22:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:25 --> Total execution time: 0.2800
INFO - 2017-02-13 10:22:26 --> Config Class Initialized
INFO - 2017-02-13 10:22:26 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:26 --> Config Class Initialized
INFO - 2017-02-13 10:22:26 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:26 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:26 --> URI Class Initialized
INFO - 2017-02-13 10:22:26 --> Router Class Initialized
INFO - 2017-02-13 10:22:26 --> Router Class Initialized
INFO - 2017-02-13 10:22:26 --> Output Class Initialized
INFO - 2017-02-13 10:22:26 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:26 --> Output Class Initialized
INFO - 2017-02-13 10:22:26 --> Input Class Initialized
INFO - 2017-02-13 10:22:26 --> Security Class Initialized
INFO - 2017-02-13 10:22:26 --> Language Class Initialized
DEBUG - 2017-02-13 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:26 --> Input Class Initialized
INFO - 2017-02-13 10:22:26 --> Language Class Initialized
INFO - 2017-02-13 10:22:26 --> Loader Class Initialized
INFO - 2017-02-13 10:22:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:26 --> Loader Class Initialized
INFO - 2017-02-13 10:22:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:26 --> Controller Class Initialized
INFO - 2017-02-13 10:22:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:26 --> Model Class Initialized
INFO - 2017-02-13 10:22:26 --> Model Class Initialized
INFO - 2017-02-13 10:22:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:27 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:27 --> Total execution time: 0.1195
INFO - 2017-02-13 10:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:27 --> Controller Class Initialized
INFO - 2017-02-13 10:22:27 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:27 --> Model Class Initialized
INFO - 2017-02-13 10:22:27 --> Model Class Initialized
INFO - 2017-02-13 10:22:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:27 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:27 --> Total execution time: 0.2751
INFO - 2017-02-13 10:22:28 --> Config Class Initialized
INFO - 2017-02-13 10:22:28 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:28 --> Config Class Initialized
INFO - 2017-02-13 10:22:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:28 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:22:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:28 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:28 --> URI Class Initialized
INFO - 2017-02-13 10:22:28 --> URI Class Initialized
INFO - 2017-02-13 10:22:28 --> Router Class Initialized
INFO - 2017-02-13 10:22:28 --> Router Class Initialized
INFO - 2017-02-13 10:22:28 --> Output Class Initialized
INFO - 2017-02-13 10:22:28 --> Output Class Initialized
INFO - 2017-02-13 10:22:28 --> Security Class Initialized
INFO - 2017-02-13 10:22:28 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:28 --> Input Class Initialized
INFO - 2017-02-13 10:22:28 --> Language Class Initialized
DEBUG - 2017-02-13 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:28 --> Input Class Initialized
INFO - 2017-02-13 10:22:28 --> Language Class Initialized
INFO - 2017-02-13 10:22:28 --> Loader Class Initialized
INFO - 2017-02-13 10:22:28 --> Loader Class Initialized
INFO - 2017-02-13 10:22:28 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:28 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:28 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:28 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:28 --> Controller Class Initialized
INFO - 2017-02-13 10:22:28 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:28 --> Model Class Initialized
INFO - 2017-02-13 10:22:28 --> Model Class Initialized
INFO - 2017-02-13 10:22:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:28 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:28 --> Total execution time: 0.1454
INFO - 2017-02-13 10:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:28 --> Controller Class Initialized
INFO - 2017-02-13 10:22:28 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:28 --> Model Class Initialized
INFO - 2017-02-13 10:22:28 --> Model Class Initialized
INFO - 2017-02-13 10:22:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:28 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:28 --> Total execution time: 0.3987
INFO - 2017-02-13 10:22:29 --> Config Class Initialized
INFO - 2017-02-13 10:22:29 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:29 --> Config Class Initialized
INFO - 2017-02-13 10:22:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:29 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:29 --> Router Class Initialized
INFO - 2017-02-13 10:22:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:29 --> URI Class Initialized
INFO - 2017-02-13 10:22:29 --> Output Class Initialized
INFO - 2017-02-13 10:22:29 --> Security Class Initialized
INFO - 2017-02-13 10:22:29 --> Router Class Initialized
DEBUG - 2017-02-13 10:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:29 --> Input Class Initialized
INFO - 2017-02-13 10:22:29 --> Language Class Initialized
INFO - 2017-02-13 10:22:29 --> Loader Class Initialized
INFO - 2017-02-13 10:22:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:29 --> Output Class Initialized
INFO - 2017-02-13 10:22:29 --> Security Class Initialized
INFO - 2017-02-13 10:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:29 --> Controller Class Initialized
DEBUG - 2017-02-13 10:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:29 --> Input Class Initialized
INFO - 2017-02-13 10:22:29 --> Language Class Initialized
INFO - 2017-02-13 10:22:29 --> Loader Class Initialized
INFO - 2017-02-13 10:22:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:29 --> Model Class Initialized
INFO - 2017-02-13 10:22:29 --> Model Class Initialized
INFO - 2017-02-13 10:22:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:29 --> Total execution time: 0.1229
INFO - 2017-02-13 10:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:29 --> Controller Class Initialized
INFO - 2017-02-13 10:22:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:29 --> Model Class Initialized
INFO - 2017-02-13 10:22:29 --> Model Class Initialized
INFO - 2017-02-13 10:22:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:30 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:30 --> Total execution time: 0.2952
INFO - 2017-02-13 10:22:30 --> Config Class Initialized
INFO - 2017-02-13 10:22:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:30 --> URI Class Initialized
INFO - 2017-02-13 10:22:30 --> Router Class Initialized
INFO - 2017-02-13 10:22:30 --> Output Class Initialized
INFO - 2017-02-13 10:22:30 --> Security Class Initialized
INFO - 2017-02-13 10:22:30 --> Config Class Initialized
INFO - 2017-02-13 10:22:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:30 --> Input Class Initialized
INFO - 2017-02-13 10:22:30 --> Language Class Initialized
DEBUG - 2017-02-13 10:22:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:30 --> URI Class Initialized
INFO - 2017-02-13 10:22:30 --> Loader Class Initialized
INFO - 2017-02-13 10:22:30 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:30 --> Router Class Initialized
INFO - 2017-02-13 10:22:30 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:30 --> Output Class Initialized
INFO - 2017-02-13 10:22:31 --> Security Class Initialized
INFO - 2017-02-13 10:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:31 --> Controller Class Initialized
DEBUG - 2017-02-13 10:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:31 --> Input Class Initialized
INFO - 2017-02-13 10:22:31 --> Language Class Initialized
INFO - 2017-02-13 10:22:31 --> Loader Class Initialized
INFO - 2017-02-13 10:22:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:31 --> Model Class Initialized
INFO - 2017-02-13 10:22:31 --> Model Class Initialized
INFO - 2017-02-13 10:22:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:31 --> Total execution time: 0.2405
INFO - 2017-02-13 10:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:31 --> Controller Class Initialized
INFO - 2017-02-13 10:22:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:31 --> Model Class Initialized
INFO - 2017-02-13 10:22:31 --> Model Class Initialized
INFO - 2017-02-13 10:22:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:31 --> Total execution time: 0.2783
INFO - 2017-02-13 10:22:32 --> Config Class Initialized
INFO - 2017-02-13 10:22:32 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:32 --> Config Class Initialized
INFO - 2017-02-13 10:22:32 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:32 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:32 --> URI Class Initialized
INFO - 2017-02-13 10:22:32 --> Router Class Initialized
DEBUG - 2017-02-13 10:22:32 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:32 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:32 --> Output Class Initialized
INFO - 2017-02-13 10:22:32 --> URI Class Initialized
INFO - 2017-02-13 10:22:32 --> Security Class Initialized
INFO - 2017-02-13 10:22:32 --> Router Class Initialized
DEBUG - 2017-02-13 10:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:32 --> Input Class Initialized
INFO - 2017-02-13 10:22:32 --> Output Class Initialized
INFO - 2017-02-13 10:22:32 --> Language Class Initialized
INFO - 2017-02-13 10:22:32 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:32 --> Input Class Initialized
INFO - 2017-02-13 10:22:32 --> Loader Class Initialized
INFO - 2017-02-13 10:22:32 --> Language Class Initialized
INFO - 2017-02-13 10:22:32 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:32 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:32 --> Loader Class Initialized
INFO - 2017-02-13 10:22:32 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:32 --> Controller Class Initialized
INFO - 2017-02-13 10:22:32 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:32 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:32 --> Model Class Initialized
INFO - 2017-02-13 10:22:32 --> Model Class Initialized
INFO - 2017-02-13 10:22:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:32 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:32 --> Total execution time: 0.1206
INFO - 2017-02-13 10:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:32 --> Controller Class Initialized
INFO - 2017-02-13 10:22:32 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:32 --> Model Class Initialized
INFO - 2017-02-13 10:22:32 --> Model Class Initialized
INFO - 2017-02-13 10:22:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:32 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:32 --> Total execution time: 0.3556
INFO - 2017-02-13 10:22:33 --> Config Class Initialized
INFO - 2017-02-13 10:22:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:33 --> URI Class Initialized
INFO - 2017-02-13 10:22:33 --> Router Class Initialized
INFO - 2017-02-13 10:22:33 --> Output Class Initialized
INFO - 2017-02-13 10:22:33 --> Config Class Initialized
INFO - 2017-02-13 10:22:33 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:33 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:33 --> Input Class Initialized
INFO - 2017-02-13 10:22:33 --> Language Class Initialized
INFO - 2017-02-13 10:22:33 --> Loader Class Initialized
DEBUG - 2017-02-13 10:22:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:33 --> URI Class Initialized
INFO - 2017-02-13 10:22:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:33 --> Router Class Initialized
INFO - 2017-02-13 10:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:33 --> Controller Class Initialized
INFO - 2017-02-13 10:22:33 --> Output Class Initialized
INFO - 2017-02-13 10:22:33 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:33 --> Input Class Initialized
INFO - 2017-02-13 10:22:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:33 --> Language Class Initialized
INFO - 2017-02-13 10:22:33 --> Model Class Initialized
INFO - 2017-02-13 10:22:33 --> Loader Class Initialized
INFO - 2017-02-13 10:22:33 --> Model Class Initialized
INFO - 2017-02-13 10:22:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:33 --> Total execution time: 0.1250
INFO - 2017-02-13 10:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:33 --> Controller Class Initialized
INFO - 2017-02-13 10:22:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:33 --> Model Class Initialized
INFO - 2017-02-13 10:22:33 --> Model Class Initialized
INFO - 2017-02-13 10:22:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:34 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:34 --> Total execution time: 0.4458
INFO - 2017-02-13 10:22:34 --> Config Class Initialized
INFO - 2017-02-13 10:22:34 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:34 --> Config Class Initialized
INFO - 2017-02-13 10:22:34 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:34 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:34 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:22:34 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:34 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:34 --> URI Class Initialized
INFO - 2017-02-13 10:22:34 --> URI Class Initialized
INFO - 2017-02-13 10:22:34 --> Router Class Initialized
INFO - 2017-02-13 10:22:34 --> Router Class Initialized
INFO - 2017-02-13 10:22:35 --> Output Class Initialized
INFO - 2017-02-13 10:22:35 --> Output Class Initialized
INFO - 2017-02-13 10:22:35 --> Security Class Initialized
INFO - 2017-02-13 10:22:35 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:35 --> Input Class Initialized
DEBUG - 2017-02-13 10:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:35 --> Language Class Initialized
INFO - 2017-02-13 10:22:35 --> Input Class Initialized
INFO - 2017-02-13 10:22:35 --> Language Class Initialized
INFO - 2017-02-13 10:22:35 --> Loader Class Initialized
INFO - 2017-02-13 10:22:35 --> Loader Class Initialized
INFO - 2017-02-13 10:22:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:35 --> Controller Class Initialized
INFO - 2017-02-13 10:22:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:35 --> Model Class Initialized
INFO - 2017-02-13 10:22:35 --> Model Class Initialized
INFO - 2017-02-13 10:22:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:35 --> Total execution time: 0.1254
INFO - 2017-02-13 10:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:35 --> Controller Class Initialized
INFO - 2017-02-13 10:22:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:35 --> Model Class Initialized
INFO - 2017-02-13 10:22:35 --> Model Class Initialized
INFO - 2017-02-13 10:22:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:35 --> Total execution time: 0.3953
INFO - 2017-02-13 10:22:36 --> Config Class Initialized
INFO - 2017-02-13 10:22:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:36 --> URI Class Initialized
INFO - 2017-02-13 10:22:36 --> Config Class Initialized
INFO - 2017-02-13 10:22:36 --> Router Class Initialized
INFO - 2017-02-13 10:22:36 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:36 --> Output Class Initialized
INFO - 2017-02-13 10:22:36 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:36 --> Input Class Initialized
INFO - 2017-02-13 10:22:36 --> Language Class Initialized
INFO - 2017-02-13 10:22:36 --> Config Class Initialized
INFO - 2017-02-13 10:22:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:36 --> URI Class Initialized
INFO - 2017-02-13 10:22:36 --> Loader Class Initialized
INFO - 2017-02-13 10:22:36 --> Config Class Initialized
INFO - 2017-02-13 10:22:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:36 --> Router Class Initialized
INFO - 2017-02-13 10:22:36 --> URI Class Initialized
DEBUG - 2017-02-13 10:22:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:36 --> Output Class Initialized
INFO - 2017-02-13 10:22:36 --> URI Class Initialized
INFO - 2017-02-13 10:22:36 --> Router Class Initialized
INFO - 2017-02-13 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:36 --> Controller Class Initialized
INFO - 2017-02-13 10:22:36 --> Output Class Initialized
INFO - 2017-02-13 10:22:36 --> Router Class Initialized
INFO - 2017-02-13 10:22:36 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:36 --> Security Class Initialized
INFO - 2017-02-13 10:22:36 --> Input Class Initialized
INFO - 2017-02-13 10:22:36 --> Language Class Initialized
INFO - 2017-02-13 10:22:36 --> Output Class Initialized
INFO - 2017-02-13 10:22:36 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:36 --> Loader Class Initialized
INFO - 2017-02-13 10:22:36 --> Input Class Initialized
INFO - 2017-02-13 10:22:36 --> Language Class Initialized
INFO - 2017-02-13 10:22:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:36 --> Loader Class Initialized
DEBUG - 2017-02-13 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:36 --> Input Class Initialized
INFO - 2017-02-13 10:22:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:36 --> Language Class Initialized
INFO - 2017-02-13 10:22:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:36 --> Model Class Initialized
INFO - 2017-02-13 10:22:36 --> Model Class Initialized
INFO - 2017-02-13 10:22:36 --> Loader Class Initialized
INFO - 2017-02-13 10:22:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:36 --> Total execution time: 0.1528
INFO - 2017-02-13 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:36 --> Controller Class Initialized
INFO - 2017-02-13 10:22:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:36 --> Model Class Initialized
INFO - 2017-02-13 10:22:36 --> Model Class Initialized
INFO - 2017-02-13 10:22:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:36 --> Total execution time: 0.1438
INFO - 2017-02-13 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:36 --> Controller Class Initialized
INFO - 2017-02-13 10:22:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:36 --> Model Class Initialized
INFO - 2017-02-13 10:22:36 --> Model Class Initialized
INFO - 2017-02-13 10:22:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:36 --> Total execution time: 0.4329
INFO - 2017-02-13 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:36 --> Controller Class Initialized
INFO - 2017-02-13 10:22:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:36 --> Model Class Initialized
INFO - 2017-02-13 10:22:36 --> Model Class Initialized
INFO - 2017-02-13 10:22:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:36 --> Total execution time: 0.6481
INFO - 2017-02-13 10:22:37 --> Config Class Initialized
INFO - 2017-02-13 10:22:37 --> Config Class Initialized
INFO - 2017-02-13 10:22:37 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:37 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:37 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:37 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:22:37 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:37 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:37 --> URI Class Initialized
INFO - 2017-02-13 10:22:37 --> URI Class Initialized
INFO - 2017-02-13 10:22:37 --> Router Class Initialized
INFO - 2017-02-13 10:22:37 --> Router Class Initialized
INFO - 2017-02-13 10:22:37 --> Output Class Initialized
INFO - 2017-02-13 10:22:37 --> Security Class Initialized
INFO - 2017-02-13 10:22:37 --> Output Class Initialized
INFO - 2017-02-13 10:22:37 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 10:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:37 --> Input Class Initialized
INFO - 2017-02-13 10:22:37 --> Input Class Initialized
INFO - 2017-02-13 10:22:37 --> Language Class Initialized
INFO - 2017-02-13 10:22:37 --> Language Class Initialized
INFO - 2017-02-13 10:22:37 --> Loader Class Initialized
INFO - 2017-02-13 10:22:37 --> Loader Class Initialized
INFO - 2017-02-13 10:22:37 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:37 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:37 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:37 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:37 --> Controller Class Initialized
INFO - 2017-02-13 10:22:37 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:37 --> Model Class Initialized
INFO - 2017-02-13 10:22:37 --> Model Class Initialized
INFO - 2017-02-13 10:22:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:37 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:37 --> Total execution time: 0.1429
INFO - 2017-02-13 10:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:37 --> Controller Class Initialized
INFO - 2017-02-13 10:22:37 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:37 --> Model Class Initialized
INFO - 2017-02-13 10:22:37 --> Model Class Initialized
INFO - 2017-02-13 10:22:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:37 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:37 --> Total execution time: 0.3732
INFO - 2017-02-13 10:22:38 --> Config Class Initialized
INFO - 2017-02-13 10:22:38 --> Config Class Initialized
INFO - 2017-02-13 10:22:38 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:38 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:38 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:22:38 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:38 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:38 --> URI Class Initialized
INFO - 2017-02-13 10:22:38 --> URI Class Initialized
INFO - 2017-02-13 10:22:38 --> Router Class Initialized
INFO - 2017-02-13 10:22:38 --> Router Class Initialized
INFO - 2017-02-13 10:22:38 --> Output Class Initialized
INFO - 2017-02-13 10:22:38 --> Security Class Initialized
INFO - 2017-02-13 10:22:38 --> Output Class Initialized
INFO - 2017-02-13 10:22:38 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:38 --> Input Class Initialized
DEBUG - 2017-02-13 10:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:38 --> Input Class Initialized
INFO - 2017-02-13 10:22:38 --> Language Class Initialized
INFO - 2017-02-13 10:22:38 --> Language Class Initialized
INFO - 2017-02-13 10:22:38 --> Loader Class Initialized
INFO - 2017-02-13 10:22:38 --> Loader Class Initialized
INFO - 2017-02-13 10:22:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:38 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:38 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:38 --> Controller Class Initialized
INFO - 2017-02-13 10:22:38 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:38 --> Model Class Initialized
INFO - 2017-02-13 10:22:38 --> Model Class Initialized
INFO - 2017-02-13 10:22:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:39 --> Total execution time: 0.3967
INFO - 2017-02-13 10:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:39 --> Controller Class Initialized
INFO - 2017-02-13 10:22:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:39 --> Model Class Initialized
INFO - 2017-02-13 10:22:39 --> Model Class Initialized
INFO - 2017-02-13 10:22:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:39 --> Total execution time: 0.4392
INFO - 2017-02-13 10:22:40 --> Config Class Initialized
INFO - 2017-02-13 10:22:40 --> Config Class Initialized
INFO - 2017-02-13 10:22:40 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:40 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:22:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:40 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:40 --> Config Class Initialized
INFO - 2017-02-13 10:22:40 --> URI Class Initialized
INFO - 2017-02-13 10:22:40 --> Hooks Class Initialized
INFO - 2017-02-13 10:22:40 --> URI Class Initialized
INFO - 2017-02-13 10:22:40 --> Router Class Initialized
INFO - 2017-02-13 10:22:40 --> Router Class Initialized
DEBUG - 2017-02-13 10:22:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:40 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:40 --> Output Class Initialized
INFO - 2017-02-13 10:22:40 --> URI Class Initialized
INFO - 2017-02-13 10:22:40 --> Output Class Initialized
INFO - 2017-02-13 10:22:40 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:40 --> Security Class Initialized
INFO - 2017-02-13 10:22:40 --> Input Class Initialized
INFO - 2017-02-13 10:22:40 --> Router Class Initialized
INFO - 2017-02-13 10:22:40 --> Language Class Initialized
INFO - 2017-02-13 10:22:40 --> Output Class Initialized
DEBUG - 2017-02-13 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:40 --> Input Class Initialized
INFO - 2017-02-13 10:22:40 --> Security Class Initialized
INFO - 2017-02-13 10:22:40 --> Language Class Initialized
DEBUG - 2017-02-13 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:40 --> Input Class Initialized
INFO - 2017-02-13 10:22:40 --> Language Class Initialized
INFO - 2017-02-13 10:22:40 --> Loader Class Initialized
INFO - 2017-02-13 10:22:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:40 --> Loader Class Initialized
INFO - 2017-02-13 10:22:40 --> Loader Class Initialized
INFO - 2017-02-13 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:40 --> Controller Class Initialized
INFO - 2017-02-13 10:22:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:40 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:40 --> Total execution time: 0.1374
INFO - 2017-02-13 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:40 --> Controller Class Initialized
INFO - 2017-02-13 10:22:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:40 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:40 --> Total execution time: 0.5384
INFO - 2017-02-13 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:40 --> Controller Class Initialized
INFO - 2017-02-13 10:22:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:40 --> Config Class Initialized
INFO - 2017-02-13 10:22:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:22:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:22:40 --> Utf8 Class Initialized
INFO - 2017-02-13 10:22:40 --> URI Class Initialized
INFO - 2017-02-13 10:22:40 --> Router Class Initialized
INFO - 2017-02-13 10:22:40 --> Output Class Initialized
INFO - 2017-02-13 10:22:40 --> Security Class Initialized
DEBUG - 2017-02-13 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:22:40 --> Input Class Initialized
INFO - 2017-02-13 10:22:40 --> Language Class Initialized
INFO - 2017-02-13 10:22:40 --> Loader Class Initialized
INFO - 2017-02-13 10:22:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:22:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:22:40 --> Controller Class Initialized
INFO - 2017-02-13 10:22:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Model Class Initialized
INFO - 2017-02-13 10:22:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09.php
INFO - 2017-02-13 10:22:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:22:40 --> Final output sent to browser
DEBUG - 2017-02-13 10:22:40 --> Total execution time: 0.1454
INFO - 2017-02-13 10:23:10 --> Config Class Initialized
INFO - 2017-02-13 10:23:10 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:10 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:10 --> URI Class Initialized
INFO - 2017-02-13 10:23:10 --> Router Class Initialized
INFO - 2017-02-13 10:23:10 --> Output Class Initialized
INFO - 2017-02-13 10:23:10 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:10 --> Input Class Initialized
INFO - 2017-02-13 10:23:10 --> Language Class Initialized
INFO - 2017-02-13 10:23:10 --> Loader Class Initialized
INFO - 2017-02-13 10:23:10 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:10 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:10 --> Controller Class Initialized
INFO - 2017-02-13 10:23:10 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:10 --> Config Class Initialized
INFO - 2017-02-13 10:23:10 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:10 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:10 --> URI Class Initialized
INFO - 2017-02-13 10:23:10 --> Router Class Initialized
INFO - 2017-02-13 10:23:10 --> Output Class Initialized
INFO - 2017-02-13 10:23:10 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:10 --> Input Class Initialized
INFO - 2017-02-13 10:23:10 --> Language Class Initialized
INFO - 2017-02-13 10:23:10 --> Loader Class Initialized
INFO - 2017-02-13 10:23:10 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:10 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:10 --> Controller Class Initialized
INFO - 2017-02-13 10:23:10 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:23:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_ist_09_attempt.php
INFO - 2017-02-13 10:23:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:23:10 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:10 --> Total execution time: 0.2294
INFO - 2017-02-13 10:23:10 --> Config Class Initialized
INFO - 2017-02-13 10:23:10 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:10 --> Config Class Initialized
INFO - 2017-02-13 10:23:10 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:10 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:10 --> URI Class Initialized
INFO - 2017-02-13 10:23:10 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:10 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:10 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:10 --> Output Class Initialized
INFO - 2017-02-13 10:23:10 --> URI Class Initialized
INFO - 2017-02-13 10:23:10 --> Security Class Initialized
INFO - 2017-02-13 10:23:10 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:10 --> Input Class Initialized
INFO - 2017-02-13 10:23:10 --> Language Class Initialized
INFO - 2017-02-13 10:23:10 --> Output Class Initialized
INFO - 2017-02-13 10:23:10 --> Loader Class Initialized
INFO - 2017-02-13 10:23:10 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:10 --> Input Class Initialized
INFO - 2017-02-13 10:23:10 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:10 --> Language Class Initialized
INFO - 2017-02-13 10:23:10 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:10 --> Loader Class Initialized
INFO - 2017-02-13 10:23:10 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:10 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:10 --> Controller Class Initialized
INFO - 2017-02-13 10:23:10 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:10 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:10 --> Total execution time: 0.1523
INFO - 2017-02-13 10:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:10 --> Controller Class Initialized
INFO - 2017-02-13 10:23:10 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Model Class Initialized
INFO - 2017-02-13 10:23:10 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:23:10 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:23:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:23:10 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:10 --> Total execution time: 0.2804
INFO - 2017-02-13 10:23:13 --> Config Class Initialized
INFO - 2017-02-13 10:23:13 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:13 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:13 --> Config Class Initialized
INFO - 2017-02-13 10:23:13 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:13 --> URI Class Initialized
INFO - 2017-02-13 10:23:13 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:13 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:13 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:13 --> Output Class Initialized
INFO - 2017-02-13 10:23:13 --> URI Class Initialized
INFO - 2017-02-13 10:23:13 --> Security Class Initialized
INFO - 2017-02-13 10:23:13 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:13 --> Input Class Initialized
INFO - 2017-02-13 10:23:13 --> Language Class Initialized
INFO - 2017-02-13 10:23:13 --> Output Class Initialized
INFO - 2017-02-13 10:23:13 --> Security Class Initialized
INFO - 2017-02-13 10:23:13 --> Loader Class Initialized
DEBUG - 2017-02-13 10:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:13 --> Input Class Initialized
INFO - 2017-02-13 10:23:13 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:13 --> Language Class Initialized
INFO - 2017-02-13 10:23:13 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:13 --> Loader Class Initialized
INFO - 2017-02-13 10:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:13 --> Controller Class Initialized
INFO - 2017-02-13 10:23:13 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:13 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:13 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:13 --> Model Class Initialized
INFO - 2017-02-13 10:23:13 --> Model Class Initialized
INFO - 2017-02-13 10:23:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:13 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:13 --> Total execution time: 0.1303
INFO - 2017-02-13 10:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:13 --> Controller Class Initialized
INFO - 2017-02-13 10:23:13 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:13 --> Model Class Initialized
INFO - 2017-02-13 10:23:13 --> Model Class Initialized
INFO - 2017-02-13 10:23:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:13 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:13 --> Total execution time: 0.2392
INFO - 2017-02-13 10:23:14 --> Config Class Initialized
INFO - 2017-02-13 10:23:14 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:14 --> Config Class Initialized
INFO - 2017-02-13 10:23:14 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:14 --> URI Class Initialized
DEBUG - 2017-02-13 10:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:14 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:14 --> Router Class Initialized
INFO - 2017-02-13 10:23:14 --> URI Class Initialized
INFO - 2017-02-13 10:23:14 --> Output Class Initialized
INFO - 2017-02-13 10:23:14 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:14 --> Input Class Initialized
INFO - 2017-02-13 10:23:14 --> Language Class Initialized
INFO - 2017-02-13 10:23:14 --> Router Class Initialized
INFO - 2017-02-13 10:23:14 --> Loader Class Initialized
INFO - 2017-02-13 10:23:14 --> Output Class Initialized
INFO - 2017-02-13 10:23:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:14 --> Security Class Initialized
INFO - 2017-02-13 10:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:14 --> Controller Class Initialized
DEBUG - 2017-02-13 10:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:14 --> Input Class Initialized
INFO - 2017-02-13 10:23:14 --> Language Class Initialized
INFO - 2017-02-13 10:23:14 --> Loader Class Initialized
INFO - 2017-02-13 10:23:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:14 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:14 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:14 --> Model Class Initialized
INFO - 2017-02-13 10:23:14 --> Model Class Initialized
INFO - 2017-02-13 10:23:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:14 --> Total execution time: 0.1216
INFO - 2017-02-13 10:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:14 --> Controller Class Initialized
INFO - 2017-02-13 10:23:14 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:14 --> Model Class Initialized
INFO - 2017-02-13 10:23:14 --> Model Class Initialized
INFO - 2017-02-13 10:23:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:14 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:14 --> Total execution time: 0.2946
INFO - 2017-02-13 10:23:17 --> Config Class Initialized
INFO - 2017-02-13 10:23:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:17 --> Config Class Initialized
INFO - 2017-02-13 10:23:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:17 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:17 --> URI Class Initialized
INFO - 2017-02-13 10:23:17 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:17 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:17 --> Output Class Initialized
INFO - 2017-02-13 10:23:17 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:17 --> URI Class Initialized
INFO - 2017-02-13 10:23:17 --> Input Class Initialized
INFO - 2017-02-13 10:23:17 --> Language Class Initialized
INFO - 2017-02-13 10:23:17 --> Router Class Initialized
INFO - 2017-02-13 10:23:17 --> Output Class Initialized
INFO - 2017-02-13 10:23:17 --> Loader Class Initialized
INFO - 2017-02-13 10:23:17 --> Security Class Initialized
INFO - 2017-02-13 10:23:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:17 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:17 --> Input Class Initialized
INFO - 2017-02-13 10:23:17 --> Language Class Initialized
INFO - 2017-02-13 10:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:17 --> Controller Class Initialized
INFO - 2017-02-13 10:23:17 --> Loader Class Initialized
INFO - 2017-02-13 10:23:17 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:17 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:17 --> Model Class Initialized
INFO - 2017-02-13 10:23:17 --> Model Class Initialized
INFO - 2017-02-13 10:23:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:17 --> Total execution time: 0.1970
INFO - 2017-02-13 10:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:17 --> Controller Class Initialized
INFO - 2017-02-13 10:23:17 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:17 --> Model Class Initialized
INFO - 2017-02-13 10:23:17 --> Model Class Initialized
INFO - 2017-02-13 10:23:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:17 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:17 --> Total execution time: 0.2445
INFO - 2017-02-13 10:23:18 --> Config Class Initialized
INFO - 2017-02-13 10:23:18 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:18 --> Config Class Initialized
INFO - 2017-02-13 10:23:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:18 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:23:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:18 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:18 --> URI Class Initialized
INFO - 2017-02-13 10:23:18 --> URI Class Initialized
INFO - 2017-02-13 10:23:18 --> Router Class Initialized
INFO - 2017-02-13 10:23:18 --> Router Class Initialized
INFO - 2017-02-13 10:23:18 --> Output Class Initialized
INFO - 2017-02-13 10:23:18 --> Output Class Initialized
INFO - 2017-02-13 10:23:18 --> Security Class Initialized
INFO - 2017-02-13 10:23:18 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 10:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:19 --> Input Class Initialized
INFO - 2017-02-13 10:23:19 --> Input Class Initialized
INFO - 2017-02-13 10:23:19 --> Language Class Initialized
INFO - 2017-02-13 10:23:19 --> Language Class Initialized
INFO - 2017-02-13 10:23:19 --> Loader Class Initialized
INFO - 2017-02-13 10:23:19 --> Loader Class Initialized
INFO - 2017-02-13 10:23:19 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:19 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:19 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:19 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:19 --> Controller Class Initialized
INFO - 2017-02-13 10:23:19 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:19 --> Model Class Initialized
INFO - 2017-02-13 10:23:19 --> Model Class Initialized
INFO - 2017-02-13 10:23:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:19 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:19 --> Total execution time: 0.3000
INFO - 2017-02-13 10:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:19 --> Controller Class Initialized
INFO - 2017-02-13 10:23:19 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:19 --> Model Class Initialized
INFO - 2017-02-13 10:23:19 --> Model Class Initialized
INFO - 2017-02-13 10:23:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:19 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:19 --> Total execution time: 0.3583
INFO - 2017-02-13 10:23:20 --> Config Class Initialized
INFO - 2017-02-13 10:23:20 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:20 --> Config Class Initialized
INFO - 2017-02-13 10:23:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:20 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:23:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:20 --> URI Class Initialized
INFO - 2017-02-13 10:23:20 --> URI Class Initialized
INFO - 2017-02-13 10:23:20 --> Router Class Initialized
INFO - 2017-02-13 10:23:20 --> Router Class Initialized
INFO - 2017-02-13 10:23:20 --> Output Class Initialized
INFO - 2017-02-13 10:23:20 --> Security Class Initialized
INFO - 2017-02-13 10:23:20 --> Output Class Initialized
DEBUG - 2017-02-13 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:20 --> Input Class Initialized
INFO - 2017-02-13 10:23:20 --> Security Class Initialized
INFO - 2017-02-13 10:23:20 --> Language Class Initialized
DEBUG - 2017-02-13 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:20 --> Input Class Initialized
INFO - 2017-02-13 10:23:20 --> Loader Class Initialized
INFO - 2017-02-13 10:23:20 --> Language Class Initialized
INFO - 2017-02-13 10:23:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:20 --> Loader Class Initialized
INFO - 2017-02-13 10:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:20 --> Controller Class Initialized
INFO - 2017-02-13 10:23:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:20 --> Model Class Initialized
INFO - 2017-02-13 10:23:20 --> Model Class Initialized
INFO - 2017-02-13 10:23:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:20 --> Total execution time: 0.1501
INFO - 2017-02-13 10:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:20 --> Controller Class Initialized
INFO - 2017-02-13 10:23:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:20 --> Model Class Initialized
INFO - 2017-02-13 10:23:20 --> Model Class Initialized
INFO - 2017-02-13 10:23:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:20 --> Total execution time: 0.3315
INFO - 2017-02-13 10:23:22 --> Config Class Initialized
INFO - 2017-02-13 10:23:22 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:22 --> Config Class Initialized
INFO - 2017-02-13 10:23:22 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:22 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:22 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:23:22 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:22 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:22 --> URI Class Initialized
INFO - 2017-02-13 10:23:22 --> URI Class Initialized
INFO - 2017-02-13 10:23:22 --> Router Class Initialized
INFO - 2017-02-13 10:23:22 --> Output Class Initialized
INFO - 2017-02-13 10:23:22 --> Router Class Initialized
INFO - 2017-02-13 10:23:22 --> Security Class Initialized
INFO - 2017-02-13 10:23:22 --> Output Class Initialized
DEBUG - 2017-02-13 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:22 --> Input Class Initialized
INFO - 2017-02-13 10:23:22 --> Security Class Initialized
INFO - 2017-02-13 10:23:22 --> Language Class Initialized
DEBUG - 2017-02-13 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:22 --> Input Class Initialized
INFO - 2017-02-13 10:23:22 --> Loader Class Initialized
INFO - 2017-02-13 10:23:22 --> Language Class Initialized
INFO - 2017-02-13 10:23:22 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:22 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:22 --> Loader Class Initialized
INFO - 2017-02-13 10:23:22 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:22 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:22 --> Controller Class Initialized
INFO - 2017-02-13 10:23:22 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:22 --> Model Class Initialized
INFO - 2017-02-13 10:23:22 --> Model Class Initialized
INFO - 2017-02-13 10:23:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:22 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:22 --> Total execution time: 0.1462
INFO - 2017-02-13 10:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:22 --> Controller Class Initialized
INFO - 2017-02-13 10:23:22 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:22 --> Model Class Initialized
INFO - 2017-02-13 10:23:22 --> Model Class Initialized
INFO - 2017-02-13 10:23:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:22 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:22 --> Total execution time: 0.4296
INFO - 2017-02-13 10:23:23 --> Config Class Initialized
INFO - 2017-02-13 10:23:23 --> Config Class Initialized
INFO - 2017-02-13 10:23:23 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:23 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:23 --> URI Class Initialized
DEBUG - 2017-02-13 10:23:23 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:23 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:23 --> URI Class Initialized
INFO - 2017-02-13 10:23:23 --> Router Class Initialized
INFO - 2017-02-13 10:23:23 --> Router Class Initialized
INFO - 2017-02-13 10:23:23 --> Output Class Initialized
INFO - 2017-02-13 10:23:23 --> Output Class Initialized
INFO - 2017-02-13 10:23:23 --> Security Class Initialized
INFO - 2017-02-13 10:23:23 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:23 --> Input Class Initialized
DEBUG - 2017-02-13 10:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:23 --> Input Class Initialized
INFO - 2017-02-13 10:23:23 --> Language Class Initialized
INFO - 2017-02-13 10:23:23 --> Language Class Initialized
INFO - 2017-02-13 10:23:23 --> Loader Class Initialized
INFO - 2017-02-13 10:23:23 --> Loader Class Initialized
INFO - 2017-02-13 10:23:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:23 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:23 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:23 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:23 --> Controller Class Initialized
INFO - 2017-02-13 10:23:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:23 --> Model Class Initialized
INFO - 2017-02-13 10:23:23 --> Model Class Initialized
INFO - 2017-02-13 10:23:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:23 --> Total execution time: 0.2785
INFO - 2017-02-13 10:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:23 --> Controller Class Initialized
INFO - 2017-02-13 10:23:23 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:23 --> Model Class Initialized
INFO - 2017-02-13 10:23:23 --> Model Class Initialized
INFO - 2017-02-13 10:23:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:23 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:23 --> Total execution time: 0.3163
INFO - 2017-02-13 10:23:25 --> Config Class Initialized
INFO - 2017-02-13 10:23:25 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:25 --> Config Class Initialized
INFO - 2017-02-13 10:23:25 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:25 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:25 --> URI Class Initialized
DEBUG - 2017-02-13 10:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:25 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:25 --> Router Class Initialized
INFO - 2017-02-13 10:23:25 --> URI Class Initialized
INFO - 2017-02-13 10:23:25 --> Output Class Initialized
INFO - 2017-02-13 10:23:25 --> Router Class Initialized
INFO - 2017-02-13 10:23:25 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:25 --> Input Class Initialized
INFO - 2017-02-13 10:23:25 --> Language Class Initialized
INFO - 2017-02-13 10:23:25 --> Output Class Initialized
INFO - 2017-02-13 10:23:25 --> Loader Class Initialized
INFO - 2017-02-13 10:23:25 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:25 --> Input Class Initialized
INFO - 2017-02-13 10:23:25 --> Language Class Initialized
INFO - 2017-02-13 10:23:25 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:25 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:25 --> Loader Class Initialized
INFO - 2017-02-13 10:23:25 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:25 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:25 --> Controller Class Initialized
INFO - 2017-02-13 10:23:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:25 --> Model Class Initialized
INFO - 2017-02-13 10:23:25 --> Model Class Initialized
INFO - 2017-02-13 10:23:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:25 --> Total execution time: 0.1798
INFO - 2017-02-13 10:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:25 --> Controller Class Initialized
INFO - 2017-02-13 10:23:25 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:25 --> Model Class Initialized
INFO - 2017-02-13 10:23:25 --> Model Class Initialized
INFO - 2017-02-13 10:23:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:25 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:25 --> Total execution time: 0.4832
INFO - 2017-02-13 10:23:26 --> Config Class Initialized
INFO - 2017-02-13 10:23:26 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:26 --> Config Class Initialized
INFO - 2017-02-13 10:23:26 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:26 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:23:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:26 --> URI Class Initialized
INFO - 2017-02-13 10:23:26 --> URI Class Initialized
INFO - 2017-02-13 10:23:26 --> Router Class Initialized
INFO - 2017-02-13 10:23:26 --> Router Class Initialized
INFO - 2017-02-13 10:23:26 --> Output Class Initialized
INFO - 2017-02-13 10:23:26 --> Security Class Initialized
INFO - 2017-02-13 10:23:26 --> Output Class Initialized
DEBUG - 2017-02-13 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:26 --> Input Class Initialized
INFO - 2017-02-13 10:23:26 --> Security Class Initialized
INFO - 2017-02-13 10:23:26 --> Language Class Initialized
DEBUG - 2017-02-13 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:26 --> Input Class Initialized
INFO - 2017-02-13 10:23:26 --> Loader Class Initialized
INFO - 2017-02-13 10:23:26 --> Language Class Initialized
INFO - 2017-02-13 10:23:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:26 --> Loader Class Initialized
INFO - 2017-02-13 10:23:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:26 --> Controller Class Initialized
INFO - 2017-02-13 10:23:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:26 --> Model Class Initialized
INFO - 2017-02-13 10:23:26 --> Model Class Initialized
INFO - 2017-02-13 10:23:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:26 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:26 --> Total execution time: 0.1307
INFO - 2017-02-13 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:26 --> Controller Class Initialized
INFO - 2017-02-13 10:23:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:26 --> Model Class Initialized
INFO - 2017-02-13 10:23:26 --> Model Class Initialized
INFO - 2017-02-13 10:23:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:26 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:26 --> Total execution time: 0.3879
INFO - 2017-02-13 10:23:29 --> Config Class Initialized
INFO - 2017-02-13 10:23:29 --> Config Class Initialized
INFO - 2017-02-13 10:23:29 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:29 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:23:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:29 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:29 --> URI Class Initialized
INFO - 2017-02-13 10:23:29 --> URI Class Initialized
INFO - 2017-02-13 10:23:29 --> Router Class Initialized
INFO - 2017-02-13 10:23:29 --> Router Class Initialized
INFO - 2017-02-13 10:23:29 --> Output Class Initialized
INFO - 2017-02-13 10:23:29 --> Output Class Initialized
INFO - 2017-02-13 10:23:29 --> Security Class Initialized
INFO - 2017-02-13 10:23:29 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:29 --> Input Class Initialized
DEBUG - 2017-02-13 10:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:29 --> Language Class Initialized
INFO - 2017-02-13 10:23:29 --> Input Class Initialized
INFO - 2017-02-13 10:23:29 --> Language Class Initialized
INFO - 2017-02-13 10:23:29 --> Loader Class Initialized
INFO - 2017-02-13 10:23:29 --> Loader Class Initialized
INFO - 2017-02-13 10:23:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:29 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:29 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:29 --> Controller Class Initialized
INFO - 2017-02-13 10:23:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:29 --> Model Class Initialized
INFO - 2017-02-13 10:23:29 --> Model Class Initialized
INFO - 2017-02-13 10:23:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:29 --> Total execution time: 0.1384
INFO - 2017-02-13 10:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:29 --> Controller Class Initialized
INFO - 2017-02-13 10:23:29 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:29 --> Model Class Initialized
INFO - 2017-02-13 10:23:29 --> Model Class Initialized
INFO - 2017-02-13 10:23:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:29 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:29 --> Total execution time: 0.3966
INFO - 2017-02-13 10:23:30 --> Config Class Initialized
INFO - 2017-02-13 10:23:30 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:30 --> Config Class Initialized
INFO - 2017-02-13 10:23:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:30 --> URI Class Initialized
INFO - 2017-02-13 10:23:30 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:30 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:30 --> Output Class Initialized
INFO - 2017-02-13 10:23:30 --> URI Class Initialized
INFO - 2017-02-13 10:23:30 --> Security Class Initialized
INFO - 2017-02-13 10:23:30 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:30 --> Input Class Initialized
INFO - 2017-02-13 10:23:30 --> Language Class Initialized
INFO - 2017-02-13 10:23:30 --> Output Class Initialized
INFO - 2017-02-13 10:23:30 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:30 --> Input Class Initialized
INFO - 2017-02-13 10:23:30 --> Loader Class Initialized
INFO - 2017-02-13 10:23:30 --> Language Class Initialized
INFO - 2017-02-13 10:23:30 --> Loader Class Initialized
INFO - 2017-02-13 10:23:30 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:30 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:30 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:30 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:30 --> Controller Class Initialized
INFO - 2017-02-13 10:23:30 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:30 --> Model Class Initialized
INFO - 2017-02-13 10:23:30 --> Model Class Initialized
INFO - 2017-02-13 10:23:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:30 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:30 --> Total execution time: 0.1360
INFO - 2017-02-13 10:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:30 --> Controller Class Initialized
INFO - 2017-02-13 10:23:30 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:30 --> Model Class Initialized
INFO - 2017-02-13 10:23:30 --> Model Class Initialized
INFO - 2017-02-13 10:23:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:30 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:30 --> Total execution time: 0.3103
INFO - 2017-02-13 10:23:31 --> Config Class Initialized
INFO - 2017-02-13 10:23:31 --> Config Class Initialized
INFO - 2017-02-13 10:23:31 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:31 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:23:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:31 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:31 --> URI Class Initialized
INFO - 2017-02-13 10:23:31 --> URI Class Initialized
INFO - 2017-02-13 10:23:31 --> Router Class Initialized
INFO - 2017-02-13 10:23:31 --> Router Class Initialized
INFO - 2017-02-13 10:23:31 --> Output Class Initialized
INFO - 2017-02-13 10:23:31 --> Output Class Initialized
INFO - 2017-02-13 10:23:31 --> Security Class Initialized
INFO - 2017-02-13 10:23:31 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:31 --> Input Class Initialized
INFO - 2017-02-13 10:23:31 --> Language Class Initialized
DEBUG - 2017-02-13 10:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:31 --> Input Class Initialized
INFO - 2017-02-13 10:23:31 --> Language Class Initialized
INFO - 2017-02-13 10:23:31 --> Loader Class Initialized
INFO - 2017-02-13 10:23:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:31 --> Loader Class Initialized
INFO - 2017-02-13 10:23:31 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:31 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:31 --> Controller Class Initialized
INFO - 2017-02-13 10:23:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:31 --> Model Class Initialized
INFO - 2017-02-13 10:23:31 --> Model Class Initialized
INFO - 2017-02-13 10:23:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:31 --> Total execution time: 0.1165
INFO - 2017-02-13 10:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:31 --> Controller Class Initialized
INFO - 2017-02-13 10:23:31 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:31 --> Model Class Initialized
INFO - 2017-02-13 10:23:31 --> Model Class Initialized
INFO - 2017-02-13 10:23:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:31 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:31 --> Total execution time: 0.2902
INFO - 2017-02-13 10:23:33 --> Config Class Initialized
INFO - 2017-02-13 10:23:33 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:33 --> Config Class Initialized
INFO - 2017-02-13 10:23:33 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:33 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:23:33 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:33 --> URI Class Initialized
INFO - 2017-02-13 10:23:33 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:33 --> URI Class Initialized
INFO - 2017-02-13 10:23:33 --> Router Class Initialized
INFO - 2017-02-13 10:23:33 --> Router Class Initialized
INFO - 2017-02-13 10:23:33 --> Output Class Initialized
INFO - 2017-02-13 10:23:33 --> Output Class Initialized
INFO - 2017-02-13 10:23:33 --> Security Class Initialized
INFO - 2017-02-13 10:23:33 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:33 --> Input Class Initialized
INFO - 2017-02-13 10:23:33 --> Language Class Initialized
DEBUG - 2017-02-13 10:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:33 --> Input Class Initialized
INFO - 2017-02-13 10:23:33 --> Language Class Initialized
INFO - 2017-02-13 10:23:33 --> Loader Class Initialized
INFO - 2017-02-13 10:23:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:33 --> Loader Class Initialized
INFO - 2017-02-13 10:23:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:33 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:33 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:33 --> Controller Class Initialized
INFO - 2017-02-13 10:23:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:33 --> Model Class Initialized
INFO - 2017-02-13 10:23:33 --> Model Class Initialized
INFO - 2017-02-13 10:23:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:33 --> Total execution time: 0.3802
INFO - 2017-02-13 10:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:33 --> Controller Class Initialized
INFO - 2017-02-13 10:23:33 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:33 --> Model Class Initialized
INFO - 2017-02-13 10:23:33 --> Model Class Initialized
INFO - 2017-02-13 10:23:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:33 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:33 --> Total execution time: 0.4218
INFO - 2017-02-13 10:23:35 --> Config Class Initialized
INFO - 2017-02-13 10:23:35 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:35 --> Config Class Initialized
INFO - 2017-02-13 10:23:35 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:35 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:35 --> URI Class Initialized
DEBUG - 2017-02-13 10:23:35 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:35 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:35 --> Router Class Initialized
INFO - 2017-02-13 10:23:35 --> URI Class Initialized
INFO - 2017-02-13 10:23:35 --> Output Class Initialized
INFO - 2017-02-13 10:23:35 --> Router Class Initialized
INFO - 2017-02-13 10:23:35 --> Security Class Initialized
INFO - 2017-02-13 10:23:35 --> Output Class Initialized
DEBUG - 2017-02-13 10:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:35 --> Input Class Initialized
INFO - 2017-02-13 10:23:35 --> Language Class Initialized
INFO - 2017-02-13 10:23:35 --> Security Class Initialized
INFO - 2017-02-13 10:23:35 --> Loader Class Initialized
DEBUG - 2017-02-13 10:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:35 --> Input Class Initialized
INFO - 2017-02-13 10:23:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:35 --> Language Class Initialized
INFO - 2017-02-13 10:23:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:35 --> Loader Class Initialized
INFO - 2017-02-13 10:23:35 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:35 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:35 --> Controller Class Initialized
INFO - 2017-02-13 10:23:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:35 --> Model Class Initialized
INFO - 2017-02-13 10:23:35 --> Model Class Initialized
INFO - 2017-02-13 10:23:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:35 --> Total execution time: 0.1299
INFO - 2017-02-13 10:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:35 --> Controller Class Initialized
INFO - 2017-02-13 10:23:35 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:35 --> Model Class Initialized
INFO - 2017-02-13 10:23:35 --> Model Class Initialized
INFO - 2017-02-13 10:23:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:35 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:35 --> Total execution time: 0.4637
INFO - 2017-02-13 10:23:36 --> Config Class Initialized
INFO - 2017-02-13 10:23:36 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:36 --> Config Class Initialized
INFO - 2017-02-13 10:23:36 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:36 --> URI Class Initialized
INFO - 2017-02-13 10:23:36 --> Router Class Initialized
INFO - 2017-02-13 10:23:36 --> Output Class Initialized
DEBUG - 2017-02-13 10:23:36 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:36 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:36 --> Security Class Initialized
INFO - 2017-02-13 10:23:36 --> URI Class Initialized
DEBUG - 2017-02-13 10:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:36 --> Input Class Initialized
INFO - 2017-02-13 10:23:36 --> Router Class Initialized
INFO - 2017-02-13 10:23:36 --> Language Class Initialized
INFO - 2017-02-13 10:23:36 --> Output Class Initialized
INFO - 2017-02-13 10:23:36 --> Security Class Initialized
INFO - 2017-02-13 10:23:36 --> Loader Class Initialized
INFO - 2017-02-13 10:23:36 --> Helper loaded: url_helper
DEBUG - 2017-02-13 10:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:36 --> Input Class Initialized
INFO - 2017-02-13 10:23:36 --> Language Class Initialized
INFO - 2017-02-13 10:23:36 --> Loader Class Initialized
INFO - 2017-02-13 10:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:36 --> Controller Class Initialized
INFO - 2017-02-13 10:23:36 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:36 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:36 --> Model Class Initialized
INFO - 2017-02-13 10:23:36 --> Model Class Initialized
INFO - 2017-02-13 10:23:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:36 --> Total execution time: 0.1292
INFO - 2017-02-13 10:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:36 --> Controller Class Initialized
INFO - 2017-02-13 10:23:36 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:36 --> Model Class Initialized
INFO - 2017-02-13 10:23:36 --> Model Class Initialized
INFO - 2017-02-13 10:23:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:36 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:36 --> Total execution time: 0.3358
INFO - 2017-02-13 10:23:37 --> Config Class Initialized
INFO - 2017-02-13 10:23:37 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:37 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:37 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:37 --> Config Class Initialized
INFO - 2017-02-13 10:23:37 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:37 --> URI Class Initialized
INFO - 2017-02-13 10:23:37 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:37 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:37 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:37 --> URI Class Initialized
INFO - 2017-02-13 10:23:37 --> Output Class Initialized
INFO - 2017-02-13 10:23:37 --> Security Class Initialized
INFO - 2017-02-13 10:23:37 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:37 --> Input Class Initialized
INFO - 2017-02-13 10:23:37 --> Output Class Initialized
INFO - 2017-02-13 10:23:37 --> Language Class Initialized
INFO - 2017-02-13 10:23:37 --> Security Class Initialized
INFO - 2017-02-13 10:23:37 --> Loader Class Initialized
DEBUG - 2017-02-13 10:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:37 --> Input Class Initialized
INFO - 2017-02-13 10:23:37 --> Language Class Initialized
INFO - 2017-02-13 10:23:37 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:37 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:37 --> Loader Class Initialized
INFO - 2017-02-13 10:23:37 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:37 --> Controller Class Initialized
INFO - 2017-02-13 10:23:37 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:37 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:37 --> Model Class Initialized
INFO - 2017-02-13 10:23:37 --> Model Class Initialized
INFO - 2017-02-13 10:23:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:37 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:37 --> Total execution time: 0.1274
INFO - 2017-02-13 10:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:37 --> Controller Class Initialized
INFO - 2017-02-13 10:23:37 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:37 --> Model Class Initialized
INFO - 2017-02-13 10:23:37 --> Model Class Initialized
INFO - 2017-02-13 10:23:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:37 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:37 --> Total execution time: 0.3226
INFO - 2017-02-13 10:23:39 --> Config Class Initialized
INFO - 2017-02-13 10:23:39 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:39 --> Config Class Initialized
INFO - 2017-02-13 10:23:39 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:39 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:39 --> URI Class Initialized
DEBUG - 2017-02-13 10:23:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:39 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:39 --> URI Class Initialized
INFO - 2017-02-13 10:23:39 --> Router Class Initialized
INFO - 2017-02-13 10:23:39 --> Router Class Initialized
INFO - 2017-02-13 10:23:39 --> Output Class Initialized
INFO - 2017-02-13 10:23:39 --> Security Class Initialized
INFO - 2017-02-13 10:23:39 --> Output Class Initialized
DEBUG - 2017-02-13 10:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:39 --> Security Class Initialized
INFO - 2017-02-13 10:23:39 --> Input Class Initialized
INFO - 2017-02-13 10:23:39 --> Language Class Initialized
INFO - 2017-02-13 10:23:39 --> Loader Class Initialized
DEBUG - 2017-02-13 10:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:39 --> Input Class Initialized
INFO - 2017-02-13 10:23:39 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:39 --> Language Class Initialized
INFO - 2017-02-13 10:23:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:39 --> Loader Class Initialized
INFO - 2017-02-13 10:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:39 --> Controller Class Initialized
INFO - 2017-02-13 10:23:39 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:39 --> Model Class Initialized
INFO - 2017-02-13 10:23:39 --> Model Class Initialized
INFO - 2017-02-13 10:23:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:39 --> Total execution time: 0.1443
INFO - 2017-02-13 10:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:39 --> Controller Class Initialized
INFO - 2017-02-13 10:23:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:39 --> Model Class Initialized
INFO - 2017-02-13 10:23:39 --> Model Class Initialized
INFO - 2017-02-13 10:23:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:39 --> Total execution time: 0.4706
INFO - 2017-02-13 10:23:40 --> Config Class Initialized
INFO - 2017-02-13 10:23:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:40 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:40 --> Config Class Initialized
INFO - 2017-02-13 10:23:40 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:40 --> URI Class Initialized
INFO - 2017-02-13 10:23:40 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:40 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:40 --> Output Class Initialized
INFO - 2017-02-13 10:23:40 --> URI Class Initialized
INFO - 2017-02-13 10:23:40 --> Security Class Initialized
INFO - 2017-02-13 10:23:40 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:40 --> Input Class Initialized
INFO - 2017-02-13 10:23:40 --> Language Class Initialized
INFO - 2017-02-13 10:23:40 --> Loader Class Initialized
INFO - 2017-02-13 10:23:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:40 --> Output Class Initialized
INFO - 2017-02-13 10:23:40 --> Security Class Initialized
INFO - 2017-02-13 10:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:40 --> Controller Class Initialized
DEBUG - 2017-02-13 10:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:40 --> Input Class Initialized
INFO - 2017-02-13 10:23:40 --> Language Class Initialized
INFO - 2017-02-13 10:23:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:40 --> Loader Class Initialized
INFO - 2017-02-13 10:23:40 --> Model Class Initialized
INFO - 2017-02-13 10:23:40 --> Model Class Initialized
INFO - 2017-02-13 10:23:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:40 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:40 --> Total execution time: 0.1061
INFO - 2017-02-13 10:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:40 --> Controller Class Initialized
INFO - 2017-02-13 10:23:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:40 --> Config Class Initialized
INFO - 2017-02-13 10:23:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:40 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:40 --> Model Class Initialized
INFO - 2017-02-13 10:23:40 --> Model Class Initialized
INFO - 2017-02-13 10:23:40 --> URI Class Initialized
INFO - 2017-02-13 10:23:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:40 --> Router Class Initialized
INFO - 2017-02-13 10:23:40 --> Output Class Initialized
INFO - 2017-02-13 10:23:40 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:40 --> Input Class Initialized
INFO - 2017-02-13 10:23:40 --> Language Class Initialized
INFO - 2017-02-13 10:23:40 --> Loader Class Initialized
INFO - 2017-02-13 10:23:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:40 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:40 --> Total execution time: 0.3753
INFO - 2017-02-13 10:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:40 --> Controller Class Initialized
INFO - 2017-02-13 10:23:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:40 --> Model Class Initialized
INFO - 2017-02-13 10:23:41 --> Model Class Initialized
INFO - 2017-02-13 10:23:41 --> Model Class Initialized
INFO - 2017-02-13 10:23:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:41 --> Total execution time: 0.3804
INFO - 2017-02-13 10:23:42 --> Config Class Initialized
INFO - 2017-02-13 10:23:42 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:42 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:42 --> Config Class Initialized
INFO - 2017-02-13 10:23:42 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:42 --> URI Class Initialized
INFO - 2017-02-13 10:23:42 --> Router Class Initialized
DEBUG - 2017-02-13 10:23:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:42 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:42 --> Output Class Initialized
INFO - 2017-02-13 10:23:42 --> URI Class Initialized
INFO - 2017-02-13 10:23:42 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:42 --> Input Class Initialized
INFO - 2017-02-13 10:23:42 --> Language Class Initialized
INFO - 2017-02-13 10:23:42 --> Router Class Initialized
INFO - 2017-02-13 10:23:42 --> Output Class Initialized
INFO - 2017-02-13 10:23:42 --> Loader Class Initialized
INFO - 2017-02-13 10:23:42 --> Security Class Initialized
INFO - 2017-02-13 10:23:42 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:42 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:42 --> Input Class Initialized
INFO - 2017-02-13 10:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:42 --> Language Class Initialized
INFO - 2017-02-13 10:23:42 --> Controller Class Initialized
INFO - 2017-02-13 10:23:42 --> Loader Class Initialized
INFO - 2017-02-13 10:23:42 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:42 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:42 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:42 --> Model Class Initialized
INFO - 2017-02-13 10:23:42 --> Model Class Initialized
INFO - 2017-02-13 10:23:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:42 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:42 --> Total execution time: 0.1128
INFO - 2017-02-13 10:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:42 --> Controller Class Initialized
INFO - 2017-02-13 10:23:42 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:42 --> Model Class Initialized
INFO - 2017-02-13 10:23:42 --> Model Class Initialized
INFO - 2017-02-13 10:23:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:42 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:42 --> Total execution time: 0.4748
INFO - 2017-02-13 10:23:43 --> Config Class Initialized
INFO - 2017-02-13 10:23:43 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:43 --> Config Class Initialized
INFO - 2017-02-13 10:23:43 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:43 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 10:23:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:43 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:43 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:43 --> URI Class Initialized
INFO - 2017-02-13 10:23:43 --> URI Class Initialized
INFO - 2017-02-13 10:23:43 --> Router Class Initialized
INFO - 2017-02-13 10:23:43 --> Router Class Initialized
INFO - 2017-02-13 10:23:43 --> Output Class Initialized
INFO - 2017-02-13 10:23:43 --> Output Class Initialized
INFO - 2017-02-13 10:23:43 --> Security Class Initialized
INFO - 2017-02-13 10:23:43 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:43 --> Input Class Initialized
INFO - 2017-02-13 10:23:43 --> Language Class Initialized
INFO - 2017-02-13 10:23:43 --> Config Class Initialized
INFO - 2017-02-13 10:23:43 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:43 --> Input Class Initialized
DEBUG - 2017-02-13 10:23:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:43 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:43 --> Language Class Initialized
INFO - 2017-02-13 10:23:43 --> URI Class Initialized
INFO - 2017-02-13 10:23:43 --> Loader Class Initialized
INFO - 2017-02-13 10:23:43 --> Router Class Initialized
INFO - 2017-02-13 10:23:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:43 --> Output Class Initialized
INFO - 2017-02-13 10:23:43 --> Security Class Initialized
INFO - 2017-02-13 10:23:43 --> Loader Class Initialized
DEBUG - 2017-02-13 10:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:43 --> Input Class Initialized
INFO - 2017-02-13 10:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:43 --> Controller Class Initialized
INFO - 2017-02-13 10:23:43 --> Language Class Initialized
INFO - 2017-02-13 10:23:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:43 --> Loader Class Initialized
INFO - 2017-02-13 10:23:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:43 --> Model Class Initialized
INFO - 2017-02-13 10:23:43 --> Model Class Initialized
INFO - 2017-02-13 10:23:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:43 --> Model Class Initialized
INFO - 2017-02-13 10:23:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:43 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:43 --> Total execution time: 0.1359
INFO - 2017-02-13 10:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:43 --> Controller Class Initialized
INFO - 2017-02-13 10:23:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:43 --> Model Class Initialized
INFO - 2017-02-13 10:23:43 --> Model Class Initialized
INFO - 2017-02-13 10:23:43 --> Model Class Initialized
INFO - 2017-02-13 10:23:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:44 --> Total execution time: 0.5558
INFO - 2017-02-13 10:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:44 --> Controller Class Initialized
INFO - 2017-02-13 10:23:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:44 --> Model Class Initialized
INFO - 2017-02-13 10:23:44 --> Model Class Initialized
INFO - 2017-02-13 10:23:44 --> Model Class Initialized
INFO - 2017-02-13 10:23:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:44 --> Config Class Initialized
INFO - 2017-02-13 10:23:44 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:44 --> URI Class Initialized
INFO - 2017-02-13 10:23:44 --> Router Class Initialized
INFO - 2017-02-13 10:23:44 --> Output Class Initialized
INFO - 2017-02-13 10:23:44 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:44 --> Input Class Initialized
INFO - 2017-02-13 10:23:44 --> Language Class Initialized
INFO - 2017-02-13 10:23:44 --> Loader Class Initialized
INFO - 2017-02-13 10:23:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:44 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:44 --> Controller Class Initialized
INFO - 2017-02-13 10:23:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:44 --> Model Class Initialized
INFO - 2017-02-13 10:23:44 --> Model Class Initialized
INFO - 2017-02-13 10:23:44 --> Model Class Initialized
INFO - 2017-02-13 10:23:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:23:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc.php
INFO - 2017-02-13 10:23:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:23:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:44 --> Total execution time: 0.1183
INFO - 2017-02-13 10:23:47 --> Config Class Initialized
INFO - 2017-02-13 10:23:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:47 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:47 --> URI Class Initialized
INFO - 2017-02-13 10:23:47 --> Router Class Initialized
INFO - 2017-02-13 10:23:47 --> Output Class Initialized
INFO - 2017-02-13 10:23:47 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:47 --> Input Class Initialized
INFO - 2017-02-13 10:23:47 --> Language Class Initialized
INFO - 2017-02-13 10:23:47 --> Loader Class Initialized
INFO - 2017-02-13 10:23:47 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:47 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:48 --> Controller Class Initialized
INFO - 2017-02-13 10:23:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:48 --> Config Class Initialized
INFO - 2017-02-13 10:23:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:48 --> URI Class Initialized
INFO - 2017-02-13 10:23:48 --> Router Class Initialized
INFO - 2017-02-13 10:23:48 --> Output Class Initialized
INFO - 2017-02-13 10:23:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:48 --> Input Class Initialized
INFO - 2017-02-13 10:23:48 --> Language Class Initialized
INFO - 2017-02-13 10:23:48 --> Loader Class Initialized
INFO - 2017-02-13 10:23:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:48 --> Controller Class Initialized
INFO - 2017-02-13 10:23:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:23:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_disc_attempt.php
INFO - 2017-02-13 10:23:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:23:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:48 --> Total execution time: 0.2239
INFO - 2017-02-13 10:23:48 --> Config Class Initialized
INFO - 2017-02-13 10:23:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:23:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:48 --> Utf8 Class Initialized
INFO - 2017-02-13 10:23:48 --> URI Class Initialized
INFO - 2017-02-13 10:23:48 --> Router Class Initialized
INFO - 2017-02-13 10:23:48 --> Config Class Initialized
INFO - 2017-02-13 10:23:48 --> Hooks Class Initialized
INFO - 2017-02-13 10:23:48 --> Output Class Initialized
INFO - 2017-02-13 10:23:48 --> Security Class Initialized
DEBUG - 2017-02-13 10:23:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:23:48 --> Utf8 Class Initialized
DEBUG - 2017-02-13 10:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:48 --> Input Class Initialized
INFO - 2017-02-13 10:23:48 --> URI Class Initialized
INFO - 2017-02-13 10:23:48 --> Language Class Initialized
INFO - 2017-02-13 10:23:48 --> Router Class Initialized
INFO - 2017-02-13 10:23:48 --> Loader Class Initialized
INFO - 2017-02-13 10:23:48 --> Output Class Initialized
INFO - 2017-02-13 10:23:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:48 --> Security Class Initialized
INFO - 2017-02-13 10:23:48 --> Helper loaded: language_helper
DEBUG - 2017-02-13 10:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:23:48 --> Input Class Initialized
INFO - 2017-02-13 10:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:48 --> Language Class Initialized
INFO - 2017-02-13 10:23:48 --> Controller Class Initialized
INFO - 2017-02-13 10:23:48 --> Loader Class Initialized
INFO - 2017-02-13 10:23:48 --> Helper loaded: url_helper
INFO - 2017-02-13 10:23:48 --> Helper loaded: language_helper
INFO - 2017-02-13 10:23:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:23:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:48 --> Total execution time: 0.1598
INFO - 2017-02-13 10:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:23:48 --> Controller Class Initialized
INFO - 2017-02-13 10:23:48 --> Database Driver Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Model Class Initialized
INFO - 2017-02-13 10:23:48 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:23:48 --> Severity: Notice --> Undefined index: answer C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
ERROR - 2017-02-13 10:23:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\models\Quiz_model.php 605
INFO - 2017-02-13 10:23:48 --> Final output sent to browser
DEBUG - 2017-02-13 10:23:48 --> Total execution time: 0.3638
INFO - 2017-02-13 10:24:18 --> Config Class Initialized
INFO - 2017-02-13 10:24:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:24:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:24:18 --> Utf8 Class Initialized
INFO - 2017-02-13 10:24:18 --> URI Class Initialized
INFO - 2017-02-13 10:24:18 --> Router Class Initialized
INFO - 2017-02-13 10:24:18 --> Output Class Initialized
INFO - 2017-02-13 10:24:18 --> Security Class Initialized
DEBUG - 2017-02-13 10:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:24:18 --> Input Class Initialized
INFO - 2017-02-13 10:24:18 --> Language Class Initialized
INFO - 2017-02-13 10:24:18 --> Loader Class Initialized
INFO - 2017-02-13 10:24:18 --> Helper loaded: url_helper
INFO - 2017-02-13 10:24:18 --> Helper loaded: language_helper
INFO - 2017-02-13 10:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:24:18 --> Controller Class Initialized
INFO - 2017-02-13 10:24:18 --> Database Driver Class Initialized
INFO - 2017-02-13 10:24:18 --> Model Class Initialized
INFO - 2017-02-13 10:24:18 --> Model Class Initialized
INFO - 2017-02-13 10:24:18 --> Model Class Initialized
INFO - 2017-02-13 10:24:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:24:18 --> Final output sent to browser
DEBUG - 2017-02-13 10:24:18 --> Total execution time: 0.0905
INFO - 2017-02-13 10:24:43 --> Config Class Initialized
INFO - 2017-02-13 10:24:43 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:24:43 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:24:43 --> Utf8 Class Initialized
INFO - 2017-02-13 10:24:43 --> URI Class Initialized
INFO - 2017-02-13 10:24:43 --> Router Class Initialized
INFO - 2017-02-13 10:24:43 --> Output Class Initialized
INFO - 2017-02-13 10:24:43 --> Security Class Initialized
DEBUG - 2017-02-13 10:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:24:43 --> Input Class Initialized
INFO - 2017-02-13 10:24:43 --> Language Class Initialized
INFO - 2017-02-13 10:24:43 --> Loader Class Initialized
INFO - 2017-02-13 10:24:43 --> Helper loaded: url_helper
INFO - 2017-02-13 10:24:43 --> Helper loaded: language_helper
INFO - 2017-02-13 10:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:24:43 --> Controller Class Initialized
INFO - 2017-02-13 10:24:43 --> Database Driver Class Initialized
INFO - 2017-02-13 10:24:43 --> Model Class Initialized
INFO - 2017-02-13 10:24:43 --> Model Class Initialized
INFO - 2017-02-13 10:24:43 --> Model Class Initialized
INFO - 2017-02-13 10:24:43 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-13 10:24:44 --> Severity: Notice --> Undefined index: correct_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 193
ERROR - 2017-02-13 10:24:44 --> Severity: Notice --> Undefined index: incorrect_score C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 194
ERROR - 2017-02-13 10:24:44 --> Severity: Notice --> Undefined index: pass_percentage C:\wamp64\www\savsoftquiz\application\models\Ujian_model.php 211
INFO - 2017-02-13 10:24:44 --> Config Class Initialized
INFO - 2017-02-13 10:24:44 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:24:44 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:24:44 --> Utf8 Class Initialized
INFO - 2017-02-13 10:24:44 --> URI Class Initialized
INFO - 2017-02-13 10:24:44 --> Router Class Initialized
INFO - 2017-02-13 10:24:44 --> Output Class Initialized
INFO - 2017-02-13 10:24:44 --> Security Class Initialized
DEBUG - 2017-02-13 10:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:24:44 --> Input Class Initialized
INFO - 2017-02-13 10:24:44 --> Language Class Initialized
INFO - 2017-02-13 10:24:44 --> Loader Class Initialized
INFO - 2017-02-13 10:24:44 --> Helper loaded: url_helper
INFO - 2017-02-13 10:24:44 --> Helper loaded: language_helper
INFO - 2017-02-13 10:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:24:44 --> Controller Class Initialized
INFO - 2017-02-13 10:24:44 --> Database Driver Class Initialized
INFO - 2017-02-13 10:24:44 --> Model Class Initialized
INFO - 2017-02-13 10:24:44 --> Model Class Initialized
INFO - 2017-02-13 10:24:44 --> Model Class Initialized
INFO - 2017-02-13 10:24:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:24:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:24:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\ujian_list.php
INFO - 2017-02-13 10:24:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:24:44 --> Final output sent to browser
DEBUG - 2017-02-13 10:24:44 --> Total execution time: 0.2562
INFO - 2017-02-13 10:24:46 --> Config Class Initialized
INFO - 2017-02-13 10:24:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:24:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:24:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:24:46 --> URI Class Initialized
INFO - 2017-02-13 10:24:46 --> Router Class Initialized
INFO - 2017-02-13 10:24:46 --> Output Class Initialized
INFO - 2017-02-13 10:24:46 --> Security Class Initialized
DEBUG - 2017-02-13 10:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:24:46 --> Input Class Initialized
INFO - 2017-02-13 10:24:46 --> Language Class Initialized
INFO - 2017-02-13 10:24:46 --> Loader Class Initialized
INFO - 2017-02-13 10:24:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:24:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:24:46 --> Controller Class Initialized
INFO - 2017-02-13 10:24:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:24:46 --> Model Class Initialized
INFO - 2017-02-13 10:24:46 --> Model Class Initialized
INFO - 2017-02-13 10:24:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:24:46 --> Config Class Initialized
INFO - 2017-02-13 10:24:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:24:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:24:46 --> Utf8 Class Initialized
INFO - 2017-02-13 10:24:46 --> URI Class Initialized
INFO - 2017-02-13 10:24:46 --> Router Class Initialized
INFO - 2017-02-13 10:24:46 --> Output Class Initialized
INFO - 2017-02-13 10:24:46 --> Security Class Initialized
DEBUG - 2017-02-13 10:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:24:46 --> Input Class Initialized
INFO - 2017-02-13 10:24:46 --> Language Class Initialized
INFO - 2017-02-13 10:24:46 --> Loader Class Initialized
INFO - 2017-02-13 10:24:46 --> Helper loaded: url_helper
INFO - 2017-02-13 10:24:46 --> Helper loaded: language_helper
INFO - 2017-02-13 10:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:24:46 --> Controller Class Initialized
INFO - 2017-02-13 10:24:46 --> Database Driver Class Initialized
INFO - 2017-02-13 10:24:46 --> Model Class Initialized
INFO - 2017-02-13 10:24:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:24:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-13 10:24:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-13 10:24:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-13 10:24:46 --> Final output sent to browser
DEBUG - 2017-02-13 10:24:46 --> Total execution time: 0.1509
INFO - 2017-02-13 10:24:51 --> Config Class Initialized
INFO - 2017-02-13 10:24:51 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:24:51 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:24:51 --> Utf8 Class Initialized
INFO - 2017-02-13 10:24:51 --> URI Class Initialized
INFO - 2017-02-13 10:24:51 --> Router Class Initialized
INFO - 2017-02-13 10:24:51 --> Output Class Initialized
INFO - 2017-02-13 10:24:51 --> Security Class Initialized
DEBUG - 2017-02-13 10:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:24:51 --> Input Class Initialized
INFO - 2017-02-13 10:24:51 --> Language Class Initialized
INFO - 2017-02-13 10:24:52 --> Loader Class Initialized
INFO - 2017-02-13 10:24:52 --> Helper loaded: url_helper
INFO - 2017-02-13 10:24:52 --> Helper loaded: language_helper
INFO - 2017-02-13 10:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:24:52 --> Controller Class Initialized
INFO - 2017-02-13 10:24:52 --> Database Driver Class Initialized
INFO - 2017-02-13 10:24:52 --> Model Class Initialized
INFO - 2017-02-13 10:24:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:24:52 --> Config Class Initialized
INFO - 2017-02-13 10:24:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:24:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:24:52 --> Utf8 Class Initialized
INFO - 2017-02-13 10:24:52 --> URI Class Initialized
INFO - 2017-02-13 10:24:52 --> Router Class Initialized
INFO - 2017-02-13 10:24:52 --> Output Class Initialized
INFO - 2017-02-13 10:24:52 --> Security Class Initialized
DEBUG - 2017-02-13 10:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:24:52 --> Input Class Initialized
INFO - 2017-02-13 10:24:52 --> Language Class Initialized
INFO - 2017-02-13 10:24:52 --> Loader Class Initialized
INFO - 2017-02-13 10:24:52 --> Helper loaded: url_helper
INFO - 2017-02-13 10:24:52 --> Helper loaded: language_helper
INFO - 2017-02-13 10:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:24:52 --> Controller Class Initialized
INFO - 2017-02-13 10:24:52 --> Database Driver Class Initialized
INFO - 2017-02-13 10:24:52 --> Model Class Initialized
INFO - 2017-02-13 10:24:52 --> Model Class Initialized
INFO - 2017-02-13 10:24:52 --> Model Class Initialized
INFO - 2017-02-13 10:24:52 --> Model Class Initialized
INFO - 2017-02-13 10:24:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-13 10:24:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:24:52 --> Final output sent to browser
DEBUG - 2017-02-13 10:24:52 --> Total execution time: 0.1538
INFO - 2017-02-13 10:24:55 --> Config Class Initialized
INFO - 2017-02-13 10:24:55 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:24:55 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:24:55 --> Utf8 Class Initialized
INFO - 2017-02-13 10:24:55 --> URI Class Initialized
INFO - 2017-02-13 10:24:55 --> Router Class Initialized
INFO - 2017-02-13 10:24:55 --> Output Class Initialized
INFO - 2017-02-13 10:24:55 --> Security Class Initialized
DEBUG - 2017-02-13 10:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:24:55 --> Input Class Initialized
INFO - 2017-02-13 10:24:55 --> Language Class Initialized
INFO - 2017-02-13 10:24:55 --> Loader Class Initialized
INFO - 2017-02-13 10:24:55 --> Helper loaded: url_helper
INFO - 2017-02-13 10:24:55 --> Helper loaded: language_helper
INFO - 2017-02-13 10:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:24:55 --> Controller Class Initialized
INFO - 2017-02-13 10:24:55 --> Database Driver Class Initialized
INFO - 2017-02-13 10:24:55 --> Model Class Initialized
INFO - 2017-02-13 10:24:55 --> Model Class Initialized
INFO - 2017-02-13 10:24:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:24:55 --> Helper loaded: form_helper
INFO - 2017-02-13 10:24:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:24:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-13 10:24:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:24:55 --> Final output sent to browser
DEBUG - 2017-02-13 10:24:55 --> Total execution time: 0.2721
INFO - 2017-02-13 10:28:51 --> Config Class Initialized
INFO - 2017-02-13 10:28:51 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:28:51 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:28:51 --> Utf8 Class Initialized
INFO - 2017-02-13 10:28:51 --> URI Class Initialized
INFO - 2017-02-13 10:28:51 --> Router Class Initialized
INFO - 2017-02-13 10:28:51 --> Output Class Initialized
INFO - 2017-02-13 10:28:51 --> Security Class Initialized
DEBUG - 2017-02-13 10:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:28:51 --> Input Class Initialized
INFO - 2017-02-13 10:28:51 --> Language Class Initialized
INFO - 2017-02-13 10:28:51 --> Loader Class Initialized
INFO - 2017-02-13 10:28:51 --> Helper loaded: url_helper
INFO - 2017-02-13 10:28:51 --> Helper loaded: language_helper
INFO - 2017-02-13 10:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:28:51 --> Controller Class Initialized
INFO - 2017-02-13 10:28:51 --> Database Driver Class Initialized
INFO - 2017-02-13 10:28:51 --> Model Class Initialized
INFO - 2017-02-13 10:28:51 --> Model Class Initialized
INFO - 2017-02-13 10:28:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:28:51 --> Helper loaded: form_helper
INFO - 2017-02-13 10:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-13 10:28:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:28:51 --> Final output sent to browser
DEBUG - 2017-02-13 10:28:51 --> Total execution time: 0.2967
INFO - 2017-02-13 10:36:05 --> Config Class Initialized
INFO - 2017-02-13 10:36:05 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:36:05 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:36:05 --> Utf8 Class Initialized
INFO - 2017-02-13 10:36:05 --> URI Class Initialized
INFO - 2017-02-13 10:36:05 --> Router Class Initialized
INFO - 2017-02-13 10:36:05 --> Output Class Initialized
INFO - 2017-02-13 10:36:05 --> Security Class Initialized
DEBUG - 2017-02-13 10:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:36:05 --> Input Class Initialized
INFO - 2017-02-13 10:36:05 --> Language Class Initialized
INFO - 2017-02-13 10:36:05 --> Loader Class Initialized
INFO - 2017-02-13 10:36:05 --> Helper loaded: url_helper
INFO - 2017-02-13 10:36:05 --> Helper loaded: language_helper
INFO - 2017-02-13 10:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:36:05 --> Controller Class Initialized
INFO - 2017-02-13 10:36:05 --> Database Driver Class Initialized
ERROR - 2017-02-13 10:36:05 --> Severity: Parsing Error --> syntax error, unexpected '' group by d.uid' (T_CONSTANT_ENCAPSED_STRING) C:\wamp64\www\savsoftquiz\application\models\Hasil_model.php 100
INFO - 2017-02-13 10:36:20 --> Config Class Initialized
INFO - 2017-02-13 10:36:20 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:36:20 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:36:20 --> Utf8 Class Initialized
INFO - 2017-02-13 10:36:20 --> URI Class Initialized
INFO - 2017-02-13 10:36:20 --> Router Class Initialized
INFO - 2017-02-13 10:36:20 --> Output Class Initialized
INFO - 2017-02-13 10:36:20 --> Security Class Initialized
DEBUG - 2017-02-13 10:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:36:20 --> Input Class Initialized
INFO - 2017-02-13 10:36:20 --> Language Class Initialized
INFO - 2017-02-13 10:36:20 --> Loader Class Initialized
INFO - 2017-02-13 10:36:20 --> Helper loaded: url_helper
INFO - 2017-02-13 10:36:20 --> Helper loaded: language_helper
INFO - 2017-02-13 10:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:36:20 --> Controller Class Initialized
INFO - 2017-02-13 10:36:20 --> Database Driver Class Initialized
INFO - 2017-02-13 10:36:20 --> Model Class Initialized
INFO - 2017-02-13 10:36:20 --> Model Class Initialized
INFO - 2017-02-13 10:36:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:36:20 --> Helper loaded: form_helper
INFO - 2017-02-13 10:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-13 10:36:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:36:20 --> Final output sent to browser
DEBUG - 2017-02-13 10:36:20 --> Total execution time: 0.3385
INFO - 2017-02-13 10:36:28 --> Config Class Initialized
INFO - 2017-02-13 10:36:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:36:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:36:28 --> Utf8 Class Initialized
INFO - 2017-02-13 10:36:28 --> URI Class Initialized
INFO - 2017-02-13 10:36:28 --> Router Class Initialized
INFO - 2017-02-13 10:36:28 --> Output Class Initialized
INFO - 2017-02-13 10:36:28 --> Security Class Initialized
DEBUG - 2017-02-13 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:36:28 --> Input Class Initialized
INFO - 2017-02-13 10:36:28 --> Language Class Initialized
INFO - 2017-02-13 10:36:28 --> Loader Class Initialized
INFO - 2017-02-13 10:36:28 --> Helper loaded: url_helper
INFO - 2017-02-13 10:36:28 --> Helper loaded: language_helper
INFO - 2017-02-13 10:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:36:28 --> Controller Class Initialized
INFO - 2017-02-13 10:36:28 --> Database Driver Class Initialized
INFO - 2017-02-13 10:36:28 --> Model Class Initialized
INFO - 2017-02-13 10:36:28 --> Model Class Initialized
INFO - 2017-02-13 10:36:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:36:28 --> Helper loaded: form_helper
INFO - 2017-02-13 10:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-13 10:36:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:36:28 --> Final output sent to browser
DEBUG - 2017-02-13 10:36:28 --> Total execution time: 0.2350
INFO - 2017-02-13 10:36:39 --> Config Class Initialized
INFO - 2017-02-13 10:36:39 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:36:39 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:36:39 --> Utf8 Class Initialized
INFO - 2017-02-13 10:36:39 --> URI Class Initialized
INFO - 2017-02-13 10:36:39 --> Router Class Initialized
INFO - 2017-02-13 10:36:39 --> Output Class Initialized
INFO - 2017-02-13 10:36:39 --> Security Class Initialized
DEBUG - 2017-02-13 10:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:36:39 --> Input Class Initialized
INFO - 2017-02-13 10:36:39 --> Language Class Initialized
INFO - 2017-02-13 10:36:39 --> Loader Class Initialized
INFO - 2017-02-13 10:36:39 --> Helper loaded: url_helper
INFO - 2017-02-13 10:36:39 --> Helper loaded: language_helper
INFO - 2017-02-13 10:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:36:39 --> Controller Class Initialized
INFO - 2017-02-13 10:36:39 --> Database Driver Class Initialized
INFO - 2017-02-13 10:36:39 --> Model Class Initialized
INFO - 2017-02-13 10:36:39 --> Model Class Initialized
INFO - 2017-02-13 10:36:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:36:39 --> Helper loaded: form_helper
INFO - 2017-02-13 10:36:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:36:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-13 10:36:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:36:39 --> Final output sent to browser
DEBUG - 2017-02-13 10:36:39 --> Total execution time: 0.2408
INFO - 2017-02-13 10:37:16 --> Config Class Initialized
INFO - 2017-02-13 10:37:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:37:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:37:16 --> Utf8 Class Initialized
INFO - 2017-02-13 10:37:16 --> URI Class Initialized
INFO - 2017-02-13 10:37:16 --> Router Class Initialized
INFO - 2017-02-13 10:37:16 --> Output Class Initialized
INFO - 2017-02-13 10:37:16 --> Security Class Initialized
DEBUG - 2017-02-13 10:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:37:16 --> Input Class Initialized
INFO - 2017-02-13 10:37:16 --> Language Class Initialized
INFO - 2017-02-13 10:37:16 --> Loader Class Initialized
INFO - 2017-02-13 10:37:16 --> Helper loaded: url_helper
INFO - 2017-02-13 10:37:16 --> Helper loaded: language_helper
INFO - 2017-02-13 10:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:37:16 --> Controller Class Initialized
INFO - 2017-02-13 10:37:16 --> Database Driver Class Initialized
INFO - 2017-02-13 10:37:16 --> Model Class Initialized
INFO - 2017-02-13 10:37:16 --> Model Class Initialized
INFO - 2017-02-13 10:37:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:37:16 --> Helper loaded: form_helper
INFO - 2017-02-13 10:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-13 10:37:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:37:16 --> Final output sent to browser
DEBUG - 2017-02-13 10:37:16 --> Total execution time: 0.2472
INFO - 2017-02-13 10:37:26 --> Config Class Initialized
INFO - 2017-02-13 10:37:26 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:37:26 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:37:26 --> Utf8 Class Initialized
INFO - 2017-02-13 10:37:26 --> URI Class Initialized
INFO - 2017-02-13 10:37:26 --> Router Class Initialized
INFO - 2017-02-13 10:37:26 --> Output Class Initialized
INFO - 2017-02-13 10:37:26 --> Security Class Initialized
DEBUG - 2017-02-13 10:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:37:26 --> Input Class Initialized
INFO - 2017-02-13 10:37:26 --> Language Class Initialized
INFO - 2017-02-13 10:37:26 --> Loader Class Initialized
INFO - 2017-02-13 10:37:26 --> Helper loaded: url_helper
INFO - 2017-02-13 10:37:26 --> Helper loaded: language_helper
INFO - 2017-02-13 10:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:37:26 --> Controller Class Initialized
INFO - 2017-02-13 10:37:26 --> Database Driver Class Initialized
INFO - 2017-02-13 10:37:26 --> Model Class Initialized
INFO - 2017-02-13 10:37:26 --> Model Class Initialized
INFO - 2017-02-13 10:37:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:37:26 --> Helper loaded: form_helper
INFO - 2017-02-13 10:37:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:37:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-13 10:37:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:37:27 --> Final output sent to browser
DEBUG - 2017-02-13 10:37:27 --> Total execution time: 0.2486
INFO - 2017-02-13 10:37:40 --> Config Class Initialized
INFO - 2017-02-13 10:37:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 10:37:40 --> UTF-8 Support Enabled
INFO - 2017-02-13 10:37:40 --> Utf8 Class Initialized
INFO - 2017-02-13 10:37:40 --> URI Class Initialized
INFO - 2017-02-13 10:37:40 --> Router Class Initialized
INFO - 2017-02-13 10:37:40 --> Output Class Initialized
INFO - 2017-02-13 10:37:40 --> Security Class Initialized
DEBUG - 2017-02-13 10:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 10:37:40 --> Input Class Initialized
INFO - 2017-02-13 10:37:40 --> Language Class Initialized
INFO - 2017-02-13 10:37:40 --> Loader Class Initialized
INFO - 2017-02-13 10:37:40 --> Helper loaded: url_helper
INFO - 2017-02-13 10:37:40 --> Helper loaded: language_helper
INFO - 2017-02-13 10:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 10:37:40 --> Controller Class Initialized
INFO - 2017-02-13 10:37:40 --> Database Driver Class Initialized
INFO - 2017-02-13 10:37:40 --> Model Class Initialized
INFO - 2017-02-13 10:37:40 --> Model Class Initialized
INFO - 2017-02-13 10:37:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 10:37:40 --> Helper loaded: form_helper
INFO - 2017-02-13 10:37:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 10:37:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-13 10:37:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 10:37:41 --> Final output sent to browser
DEBUG - 2017-02-13 10:37:41 --> Total execution time: 0.2469
INFO - 2017-02-13 16:16:00 --> Config Class Initialized
INFO - 2017-02-13 16:16:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:16:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:16:00 --> Utf8 Class Initialized
INFO - 2017-02-13 16:16:00 --> URI Class Initialized
INFO - 2017-02-13 16:16:00 --> Router Class Initialized
INFO - 2017-02-13 16:16:00 --> Output Class Initialized
INFO - 2017-02-13 16:16:00 --> Security Class Initialized
DEBUG - 2017-02-13 16:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:16:00 --> Input Class Initialized
INFO - 2017-02-13 16:16:00 --> Language Class Initialized
INFO - 2017-02-13 16:16:00 --> Loader Class Initialized
INFO - 2017-02-13 16:16:00 --> Helper loaded: url_helper
INFO - 2017-02-13 16:16:00 --> Helper loaded: language_helper
INFO - 2017-02-13 16:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:16:00 --> Controller Class Initialized
INFO - 2017-02-13 16:16:00 --> Database Driver Class Initialized
INFO - 2017-02-13 16:16:00 --> Model Class Initialized
INFO - 2017-02-13 16:16:00 --> Model Class Initialized
INFO - 2017-02-13 16:16:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 16:16:00 --> Config Class Initialized
INFO - 2017-02-13 16:16:00 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:16:00 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:16:00 --> Utf8 Class Initialized
INFO - 2017-02-13 16:16:00 --> URI Class Initialized
INFO - 2017-02-13 16:16:00 --> Router Class Initialized
INFO - 2017-02-13 16:16:00 --> Output Class Initialized
INFO - 2017-02-13 16:16:00 --> Security Class Initialized
DEBUG - 2017-02-13 16:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:16:00 --> Input Class Initialized
INFO - 2017-02-13 16:16:00 --> Language Class Initialized
INFO - 2017-02-13 16:16:00 --> Loader Class Initialized
INFO - 2017-02-13 16:16:00 --> Helper loaded: url_helper
INFO - 2017-02-13 16:16:00 --> Helper loaded: language_helper
INFO - 2017-02-13 16:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:16:00 --> Controller Class Initialized
INFO - 2017-02-13 16:16:00 --> Database Driver Class Initialized
INFO - 2017-02-13 16:16:00 --> Model Class Initialized
INFO - 2017-02-13 16:16:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 16:16:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-13 16:16:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-13 16:16:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-13 16:16:00 --> Final output sent to browser
DEBUG - 2017-02-13 16:16:00 --> Total execution time: 0.1307
INFO - 2017-02-13 16:16:04 --> Config Class Initialized
INFO - 2017-02-13 16:16:04 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:16:04 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:16:04 --> Utf8 Class Initialized
INFO - 2017-02-13 16:16:04 --> URI Class Initialized
INFO - 2017-02-13 16:16:04 --> Router Class Initialized
INFO - 2017-02-13 16:16:04 --> Output Class Initialized
INFO - 2017-02-13 16:16:04 --> Security Class Initialized
DEBUG - 2017-02-13 16:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:16:04 --> Input Class Initialized
INFO - 2017-02-13 16:16:04 --> Language Class Initialized
INFO - 2017-02-13 16:16:04 --> Loader Class Initialized
INFO - 2017-02-13 16:16:04 --> Helper loaded: url_helper
INFO - 2017-02-13 16:16:04 --> Helper loaded: language_helper
INFO - 2017-02-13 16:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:16:04 --> Controller Class Initialized
INFO - 2017-02-13 16:16:04 --> Database Driver Class Initialized
INFO - 2017-02-13 16:16:04 --> Model Class Initialized
INFO - 2017-02-13 16:16:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 16:16:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-13 16:16:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-13 16:16:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 16:16:04 --> Final output sent to browser
DEBUG - 2017-02-13 16:16:04 --> Total execution time: 0.1105
INFO - 2017-02-13 16:17:01 --> Config Class Initialized
INFO - 2017-02-13 16:17:01 --> Hooks Class Initialized
DEBUG - 2017-02-13 16:17:01 --> UTF-8 Support Enabled
INFO - 2017-02-13 16:17:01 --> Utf8 Class Initialized
INFO - 2017-02-13 16:17:01 --> URI Class Initialized
INFO - 2017-02-13 16:17:01 --> Router Class Initialized
INFO - 2017-02-13 16:17:01 --> Output Class Initialized
INFO - 2017-02-13 16:17:01 --> Security Class Initialized
DEBUG - 2017-02-13 16:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 16:17:01 --> Input Class Initialized
INFO - 2017-02-13 16:17:01 --> Language Class Initialized
INFO - 2017-02-13 16:17:01 --> Loader Class Initialized
INFO - 2017-02-13 16:17:01 --> Helper loaded: url_helper
INFO - 2017-02-13 16:17:01 --> Helper loaded: language_helper
INFO - 2017-02-13 16:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-13 16:17:01 --> Controller Class Initialized
INFO - 2017-02-13 16:17:01 --> Database Driver Class Initialized
INFO - 2017-02-13 16:17:01 --> Model Class Initialized
INFO - 2017-02-13 16:17:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-13 16:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-13 16:17:01 --> Severity: Notice --> Undefined variable: group_list C:\wamp64\www\savsoftquiz\application\views\register_new.php 49
ERROR - 2017-02-13 16:17:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\register_new.php 49
INFO - 2017-02-13 16:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-13 16:17:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-13 16:17:01 --> Final output sent to browser
DEBUG - 2017-02-13 16:17:01 --> Total execution time: 0.1680
