<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-14 07:47:51 --> Config Class Initialized
INFO - 2017-02-14 07:47:51 --> Hooks Class Initialized
DEBUG - 2017-02-14 07:47:51 --> UTF-8 Support Enabled
INFO - 2017-02-14 07:47:51 --> Utf8 Class Initialized
INFO - 2017-02-14 07:47:51 --> URI Class Initialized
INFO - 2017-02-14 07:47:51 --> Router Class Initialized
INFO - 2017-02-14 07:47:51 --> Output Class Initialized
INFO - 2017-02-14 07:47:51 --> Security Class Initialized
DEBUG - 2017-02-14 07:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 07:47:51 --> Input Class Initialized
INFO - 2017-02-14 07:47:51 --> Language Class Initialized
INFO - 2017-02-14 07:47:51 --> Loader Class Initialized
INFO - 2017-02-14 07:47:51 --> Helper loaded: url_helper
INFO - 2017-02-14 07:47:51 --> Helper loaded: language_helper
INFO - 2017-02-14 07:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 07:47:51 --> Controller Class Initialized
INFO - 2017-02-14 07:47:51 --> Database Driver Class Initialized
INFO - 2017-02-14 07:47:51 --> Model Class Initialized
INFO - 2017-02-14 07:47:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 07:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 07:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 07:47:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 07:47:51 --> Final output sent to browser
DEBUG - 2017-02-14 07:47:51 --> Total execution time: 0.1035
INFO - 2017-02-14 08:00:38 --> Config Class Initialized
INFO - 2017-02-14 08:00:38 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:00:38 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:00:38 --> Utf8 Class Initialized
INFO - 2017-02-14 08:00:38 --> URI Class Initialized
INFO - 2017-02-14 08:00:38 --> Router Class Initialized
INFO - 2017-02-14 08:00:38 --> Output Class Initialized
INFO - 2017-02-14 08:00:38 --> Security Class Initialized
DEBUG - 2017-02-14 08:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:00:38 --> Input Class Initialized
INFO - 2017-02-14 08:00:38 --> Language Class Initialized
INFO - 2017-02-14 08:00:38 --> Loader Class Initialized
INFO - 2017-02-14 08:00:38 --> Helper loaded: url_helper
INFO - 2017-02-14 08:00:38 --> Helper loaded: language_helper
INFO - 2017-02-14 08:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:00:38 --> Controller Class Initialized
INFO - 2017-02-14 08:00:38 --> Database Driver Class Initialized
INFO - 2017-02-14 08:00:38 --> Model Class Initialized
INFO - 2017-02-14 08:00:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:00:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:00:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:00:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:00:38 --> Final output sent to browser
DEBUG - 2017-02-14 08:00:38 --> Total execution time: 0.0728
INFO - 2017-02-14 08:02:52 --> Config Class Initialized
INFO - 2017-02-14 08:02:52 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:02:52 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:02:52 --> Utf8 Class Initialized
INFO - 2017-02-14 08:02:52 --> URI Class Initialized
INFO - 2017-02-14 08:02:52 --> Router Class Initialized
INFO - 2017-02-14 08:02:52 --> Output Class Initialized
INFO - 2017-02-14 08:02:52 --> Security Class Initialized
DEBUG - 2017-02-14 08:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:02:52 --> Input Class Initialized
INFO - 2017-02-14 08:02:52 --> Language Class Initialized
INFO - 2017-02-14 08:02:52 --> Loader Class Initialized
INFO - 2017-02-14 08:02:52 --> Helper loaded: url_helper
INFO - 2017-02-14 08:02:52 --> Helper loaded: language_helper
INFO - 2017-02-14 08:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:02:52 --> Controller Class Initialized
INFO - 2017-02-14 08:02:52 --> Database Driver Class Initialized
INFO - 2017-02-14 08:02:52 --> Model Class Initialized
INFO - 2017-02-14 08:02:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:02:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:02:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:02:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:02:52 --> Final output sent to browser
DEBUG - 2017-02-14 08:02:52 --> Total execution time: 0.0798
INFO - 2017-02-14 08:04:49 --> Config Class Initialized
INFO - 2017-02-14 08:04:49 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:04:49 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:04:49 --> Utf8 Class Initialized
INFO - 2017-02-14 08:04:49 --> URI Class Initialized
INFO - 2017-02-14 08:04:49 --> Router Class Initialized
INFO - 2017-02-14 08:04:49 --> Output Class Initialized
INFO - 2017-02-14 08:04:49 --> Security Class Initialized
DEBUG - 2017-02-14 08:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:04:49 --> Input Class Initialized
INFO - 2017-02-14 08:04:49 --> Language Class Initialized
INFO - 2017-02-14 08:04:49 --> Loader Class Initialized
INFO - 2017-02-14 08:04:49 --> Helper loaded: url_helper
INFO - 2017-02-14 08:04:49 --> Helper loaded: language_helper
INFO - 2017-02-14 08:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:04:49 --> Controller Class Initialized
INFO - 2017-02-14 08:04:49 --> Database Driver Class Initialized
INFO - 2017-02-14 08:04:49 --> Model Class Initialized
INFO - 2017-02-14 08:04:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:04:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:04:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:04:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:04:49 --> Final output sent to browser
DEBUG - 2017-02-14 08:04:49 --> Total execution time: 0.0712
INFO - 2017-02-14 08:06:06 --> Config Class Initialized
INFO - 2017-02-14 08:06:06 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:06:06 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:06:06 --> Utf8 Class Initialized
INFO - 2017-02-14 08:06:06 --> URI Class Initialized
INFO - 2017-02-14 08:06:06 --> Router Class Initialized
INFO - 2017-02-14 08:06:06 --> Output Class Initialized
INFO - 2017-02-14 08:06:06 --> Security Class Initialized
DEBUG - 2017-02-14 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:06:06 --> Input Class Initialized
INFO - 2017-02-14 08:06:06 --> Language Class Initialized
INFO - 2017-02-14 08:06:06 --> Loader Class Initialized
INFO - 2017-02-14 08:06:06 --> Helper loaded: url_helper
INFO - 2017-02-14 08:06:06 --> Helper loaded: language_helper
INFO - 2017-02-14 08:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:06:06 --> Controller Class Initialized
INFO - 2017-02-14 08:06:06 --> Database Driver Class Initialized
INFO - 2017-02-14 08:06:06 --> Model Class Initialized
INFO - 2017-02-14 08:06:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:06:06 --> Final output sent to browser
DEBUG - 2017-02-14 08:06:06 --> Total execution time: 0.0632
INFO - 2017-02-14 08:07:26 --> Config Class Initialized
INFO - 2017-02-14 08:07:26 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:07:26 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:07:26 --> Utf8 Class Initialized
INFO - 2017-02-14 08:07:26 --> URI Class Initialized
INFO - 2017-02-14 08:07:26 --> Router Class Initialized
INFO - 2017-02-14 08:07:26 --> Output Class Initialized
INFO - 2017-02-14 08:07:26 --> Security Class Initialized
DEBUG - 2017-02-14 08:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:07:26 --> Input Class Initialized
INFO - 2017-02-14 08:07:26 --> Language Class Initialized
INFO - 2017-02-14 08:07:26 --> Loader Class Initialized
INFO - 2017-02-14 08:07:26 --> Helper loaded: url_helper
INFO - 2017-02-14 08:07:26 --> Helper loaded: language_helper
INFO - 2017-02-14 08:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:07:26 --> Controller Class Initialized
INFO - 2017-02-14 08:07:26 --> Database Driver Class Initialized
INFO - 2017-02-14 08:07:26 --> Model Class Initialized
INFO - 2017-02-14 08:07:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:07:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:07:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:07:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:07:26 --> Final output sent to browser
DEBUG - 2017-02-14 08:07:26 --> Total execution time: 0.0683
INFO - 2017-02-14 08:07:44 --> Config Class Initialized
INFO - 2017-02-14 08:07:44 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:07:44 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:07:44 --> Utf8 Class Initialized
INFO - 2017-02-14 08:07:44 --> URI Class Initialized
INFO - 2017-02-14 08:07:44 --> Router Class Initialized
INFO - 2017-02-14 08:07:44 --> Output Class Initialized
INFO - 2017-02-14 08:07:44 --> Security Class Initialized
DEBUG - 2017-02-14 08:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:07:44 --> Input Class Initialized
INFO - 2017-02-14 08:07:44 --> Language Class Initialized
INFO - 2017-02-14 08:07:44 --> Loader Class Initialized
INFO - 2017-02-14 08:07:44 --> Helper loaded: url_helper
INFO - 2017-02-14 08:07:44 --> Helper loaded: language_helper
INFO - 2017-02-14 08:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:07:44 --> Controller Class Initialized
INFO - 2017-02-14 08:07:44 --> Database Driver Class Initialized
INFO - 2017-02-14 08:07:44 --> Model Class Initialized
INFO - 2017-02-14 08:07:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:07:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:07:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:07:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:07:44 --> Final output sent to browser
DEBUG - 2017-02-14 08:07:44 --> Total execution time: 0.0710
INFO - 2017-02-14 08:10:05 --> Config Class Initialized
INFO - 2017-02-14 08:10:05 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:10:05 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:10:05 --> Utf8 Class Initialized
INFO - 2017-02-14 08:10:05 --> URI Class Initialized
INFO - 2017-02-14 08:10:05 --> Router Class Initialized
INFO - 2017-02-14 08:10:05 --> Output Class Initialized
INFO - 2017-02-14 08:10:05 --> Security Class Initialized
DEBUG - 2017-02-14 08:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:10:05 --> Input Class Initialized
INFO - 2017-02-14 08:10:05 --> Language Class Initialized
INFO - 2017-02-14 08:10:05 --> Loader Class Initialized
INFO - 2017-02-14 08:10:05 --> Helper loaded: url_helper
INFO - 2017-02-14 08:10:05 --> Helper loaded: language_helper
INFO - 2017-02-14 08:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:10:05 --> Controller Class Initialized
INFO - 2017-02-14 08:10:05 --> Database Driver Class Initialized
INFO - 2017-02-14 08:10:05 --> Model Class Initialized
INFO - 2017-02-14 08:10:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:10:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:10:05 --> Final output sent to browser
DEBUG - 2017-02-14 08:10:05 --> Total execution time: 0.0621
INFO - 2017-02-14 08:12:31 --> Config Class Initialized
INFO - 2017-02-14 08:12:31 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:12:31 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:12:31 --> Utf8 Class Initialized
INFO - 2017-02-14 08:12:31 --> URI Class Initialized
INFO - 2017-02-14 08:12:31 --> Router Class Initialized
INFO - 2017-02-14 08:12:31 --> Output Class Initialized
INFO - 2017-02-14 08:12:31 --> Security Class Initialized
DEBUG - 2017-02-14 08:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:12:31 --> Input Class Initialized
INFO - 2017-02-14 08:12:31 --> Language Class Initialized
INFO - 2017-02-14 08:12:31 --> Loader Class Initialized
INFO - 2017-02-14 08:12:31 --> Helper loaded: url_helper
INFO - 2017-02-14 08:12:31 --> Helper loaded: language_helper
INFO - 2017-02-14 08:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:12:31 --> Controller Class Initialized
INFO - 2017-02-14 08:12:31 --> Database Driver Class Initialized
INFO - 2017-02-14 08:12:31 --> Model Class Initialized
INFO - 2017-02-14 08:12:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:12:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-14 08:12:31 --> Could not find the language line "ttl"
ERROR - 2017-02-14 08:12:31 --> Could not find the language line "ttl"
INFO - 2017-02-14 08:12:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:12:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:12:31 --> Final output sent to browser
DEBUG - 2017-02-14 08:12:31 --> Total execution time: 0.0737
INFO - 2017-02-14 08:13:41 --> Config Class Initialized
INFO - 2017-02-14 08:13:41 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:13:41 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:13:41 --> Utf8 Class Initialized
INFO - 2017-02-14 08:13:41 --> URI Class Initialized
INFO - 2017-02-14 08:13:41 --> Router Class Initialized
INFO - 2017-02-14 08:13:41 --> Output Class Initialized
INFO - 2017-02-14 08:13:41 --> Security Class Initialized
DEBUG - 2017-02-14 08:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:13:41 --> Input Class Initialized
INFO - 2017-02-14 08:13:41 --> Language Class Initialized
INFO - 2017-02-14 08:13:41 --> Loader Class Initialized
INFO - 2017-02-14 08:13:41 --> Helper loaded: url_helper
INFO - 2017-02-14 08:13:41 --> Helper loaded: language_helper
INFO - 2017-02-14 08:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:13:41 --> Controller Class Initialized
INFO - 2017-02-14 08:13:41 --> Database Driver Class Initialized
INFO - 2017-02-14 08:13:41 --> Model Class Initialized
INFO - 2017-02-14 08:13:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:13:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:13:41 --> Final output sent to browser
DEBUG - 2017-02-14 08:13:41 --> Total execution time: 0.0613
INFO - 2017-02-14 08:16:01 --> Config Class Initialized
INFO - 2017-02-14 08:16:01 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:16:01 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:16:01 --> Utf8 Class Initialized
INFO - 2017-02-14 08:16:01 --> URI Class Initialized
INFO - 2017-02-14 08:16:01 --> Router Class Initialized
INFO - 2017-02-14 08:16:01 --> Output Class Initialized
INFO - 2017-02-14 08:16:01 --> Security Class Initialized
DEBUG - 2017-02-14 08:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:16:01 --> Input Class Initialized
INFO - 2017-02-14 08:16:01 --> Language Class Initialized
INFO - 2017-02-14 08:16:01 --> Loader Class Initialized
INFO - 2017-02-14 08:16:01 --> Helper loaded: url_helper
INFO - 2017-02-14 08:16:01 --> Helper loaded: language_helper
INFO - 2017-02-14 08:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:16:01 --> Controller Class Initialized
INFO - 2017-02-14 08:16:01 --> Database Driver Class Initialized
INFO - 2017-02-14 08:16:01 --> Model Class Initialized
INFO - 2017-02-14 08:16:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:16:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:16:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:16:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:16:01 --> Final output sent to browser
DEBUG - 2017-02-14 08:16:01 --> Total execution time: 0.0635
INFO - 2017-02-14 08:16:19 --> Config Class Initialized
INFO - 2017-02-14 08:16:19 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:16:19 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:16:19 --> Utf8 Class Initialized
INFO - 2017-02-14 08:16:19 --> URI Class Initialized
INFO - 2017-02-14 08:16:19 --> Router Class Initialized
INFO - 2017-02-14 08:16:19 --> Output Class Initialized
INFO - 2017-02-14 08:16:19 --> Security Class Initialized
DEBUG - 2017-02-14 08:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:16:19 --> Input Class Initialized
INFO - 2017-02-14 08:16:19 --> Language Class Initialized
INFO - 2017-02-14 08:16:19 --> Loader Class Initialized
INFO - 2017-02-14 08:16:19 --> Helper loaded: url_helper
INFO - 2017-02-14 08:16:19 --> Helper loaded: language_helper
INFO - 2017-02-14 08:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:16:19 --> Controller Class Initialized
INFO - 2017-02-14 08:16:19 --> Database Driver Class Initialized
INFO - 2017-02-14 08:16:19 --> Model Class Initialized
INFO - 2017-02-14 08:16:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:16:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:16:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:16:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:16:19 --> Final output sent to browser
DEBUG - 2017-02-14 08:16:19 --> Total execution time: 0.0870
INFO - 2017-02-14 08:26:47 --> Config Class Initialized
INFO - 2017-02-14 08:26:47 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:26:47 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:26:47 --> Utf8 Class Initialized
INFO - 2017-02-14 08:26:47 --> URI Class Initialized
INFO - 2017-02-14 08:26:47 --> Router Class Initialized
INFO - 2017-02-14 08:26:47 --> Output Class Initialized
INFO - 2017-02-14 08:26:47 --> Security Class Initialized
DEBUG - 2017-02-14 08:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:26:47 --> Input Class Initialized
INFO - 2017-02-14 08:26:47 --> Language Class Initialized
INFO - 2017-02-14 08:26:47 --> Loader Class Initialized
INFO - 2017-02-14 08:26:47 --> Helper loaded: url_helper
INFO - 2017-02-14 08:26:47 --> Helper loaded: language_helper
INFO - 2017-02-14 08:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:26:47 --> Controller Class Initialized
INFO - 2017-02-14 08:26:47 --> Database Driver Class Initialized
INFO - 2017-02-14 08:26:47 --> Model Class Initialized
INFO - 2017-02-14 08:26:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:26:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:26:47 --> Final output sent to browser
DEBUG - 2017-02-14 08:26:47 --> Total execution time: 0.0621
INFO - 2017-02-14 08:27:23 --> Config Class Initialized
INFO - 2017-02-14 08:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:27:23 --> Utf8 Class Initialized
INFO - 2017-02-14 08:27:23 --> URI Class Initialized
INFO - 2017-02-14 08:27:23 --> Router Class Initialized
INFO - 2017-02-14 08:27:23 --> Output Class Initialized
INFO - 2017-02-14 08:27:23 --> Security Class Initialized
DEBUG - 2017-02-14 08:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:27:23 --> Input Class Initialized
INFO - 2017-02-14 08:27:23 --> Language Class Initialized
INFO - 2017-02-14 08:27:24 --> Loader Class Initialized
INFO - 2017-02-14 08:27:24 --> Helper loaded: url_helper
INFO - 2017-02-14 08:27:24 --> Helper loaded: language_helper
INFO - 2017-02-14 08:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:27:24 --> Controller Class Initialized
INFO - 2017-02-14 08:27:24 --> Database Driver Class Initialized
INFO - 2017-02-14 08:27:24 --> Model Class Initialized
INFO - 2017-02-14 08:27:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:27:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:27:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:27:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:27:24 --> Final output sent to browser
DEBUG - 2017-02-14 08:27:24 --> Total execution time: 0.0631
INFO - 2017-02-14 08:29:38 --> Config Class Initialized
INFO - 2017-02-14 08:29:38 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:29:38 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:29:38 --> Utf8 Class Initialized
INFO - 2017-02-14 08:29:38 --> URI Class Initialized
INFO - 2017-02-14 08:29:38 --> Router Class Initialized
INFO - 2017-02-14 08:29:38 --> Output Class Initialized
INFO - 2017-02-14 08:29:38 --> Security Class Initialized
DEBUG - 2017-02-14 08:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:29:38 --> Input Class Initialized
INFO - 2017-02-14 08:29:38 --> Language Class Initialized
INFO - 2017-02-14 08:29:38 --> Loader Class Initialized
INFO - 2017-02-14 08:29:38 --> Helper loaded: url_helper
INFO - 2017-02-14 08:29:38 --> Helper loaded: language_helper
INFO - 2017-02-14 08:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:29:38 --> Controller Class Initialized
INFO - 2017-02-14 08:29:38 --> Database Driver Class Initialized
INFO - 2017-02-14 08:29:38 --> Model Class Initialized
INFO - 2017-02-14 08:29:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:29:38 --> Final output sent to browser
DEBUG - 2017-02-14 08:29:38 --> Total execution time: 0.0643
INFO - 2017-02-14 08:32:23 --> Config Class Initialized
INFO - 2017-02-14 08:32:23 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:32:23 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:32:23 --> Utf8 Class Initialized
INFO - 2017-02-14 08:32:23 --> URI Class Initialized
INFO - 2017-02-14 08:32:23 --> Router Class Initialized
INFO - 2017-02-14 08:32:23 --> Output Class Initialized
INFO - 2017-02-14 08:32:23 --> Security Class Initialized
DEBUG - 2017-02-14 08:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:32:23 --> Input Class Initialized
INFO - 2017-02-14 08:32:23 --> Language Class Initialized
INFO - 2017-02-14 08:32:23 --> Loader Class Initialized
INFO - 2017-02-14 08:32:23 --> Helper loaded: url_helper
INFO - 2017-02-14 08:32:23 --> Helper loaded: language_helper
INFO - 2017-02-14 08:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:32:23 --> Controller Class Initialized
INFO - 2017-02-14 08:32:23 --> Database Driver Class Initialized
INFO - 2017-02-14 08:32:23 --> Model Class Initialized
INFO - 2017-02-14 08:32:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:32:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:32:23 --> Final output sent to browser
DEBUG - 2017-02-14 08:32:23 --> Total execution time: 0.0755
INFO - 2017-02-14 08:34:35 --> Config Class Initialized
INFO - 2017-02-14 08:34:35 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:34:35 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:34:35 --> Utf8 Class Initialized
INFO - 2017-02-14 08:34:35 --> URI Class Initialized
INFO - 2017-02-14 08:34:35 --> Router Class Initialized
INFO - 2017-02-14 08:34:35 --> Output Class Initialized
INFO - 2017-02-14 08:34:35 --> Security Class Initialized
DEBUG - 2017-02-14 08:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:34:35 --> Input Class Initialized
INFO - 2017-02-14 08:34:35 --> Language Class Initialized
INFO - 2017-02-14 08:34:35 --> Loader Class Initialized
INFO - 2017-02-14 08:34:35 --> Helper loaded: url_helper
INFO - 2017-02-14 08:34:35 --> Helper loaded: language_helper
INFO - 2017-02-14 08:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:34:35 --> Controller Class Initialized
INFO - 2017-02-14 08:34:35 --> Database Driver Class Initialized
INFO - 2017-02-14 08:34:35 --> Model Class Initialized
INFO - 2017-02-14 08:34:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:34:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:34:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:34:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:34:35 --> Final output sent to browser
DEBUG - 2017-02-14 08:34:35 --> Total execution time: 0.0616
INFO - 2017-02-14 08:38:57 --> Config Class Initialized
INFO - 2017-02-14 08:38:57 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:38:57 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:38:57 --> Utf8 Class Initialized
INFO - 2017-02-14 08:38:57 --> URI Class Initialized
INFO - 2017-02-14 08:38:57 --> Router Class Initialized
INFO - 2017-02-14 08:38:57 --> Output Class Initialized
INFO - 2017-02-14 08:38:57 --> Security Class Initialized
DEBUG - 2017-02-14 08:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:38:57 --> Input Class Initialized
INFO - 2017-02-14 08:38:57 --> Language Class Initialized
INFO - 2017-02-14 08:38:57 --> Loader Class Initialized
INFO - 2017-02-14 08:38:57 --> Helper loaded: url_helper
INFO - 2017-02-14 08:38:57 --> Helper loaded: language_helper
INFO - 2017-02-14 08:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:38:57 --> Controller Class Initialized
INFO - 2017-02-14 08:38:57 --> Database Driver Class Initialized
INFO - 2017-02-14 08:38:57 --> Model Class Initialized
INFO - 2017-02-14 08:38:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:38:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:38:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:38:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:38:57 --> Final output sent to browser
DEBUG - 2017-02-14 08:38:57 --> Total execution time: 0.0742
INFO - 2017-02-14 08:40:26 --> Config Class Initialized
INFO - 2017-02-14 08:40:26 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:40:26 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:40:26 --> Utf8 Class Initialized
INFO - 2017-02-14 08:40:26 --> URI Class Initialized
INFO - 2017-02-14 08:40:26 --> Router Class Initialized
INFO - 2017-02-14 08:40:26 --> Output Class Initialized
INFO - 2017-02-14 08:40:26 --> Security Class Initialized
DEBUG - 2017-02-14 08:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:40:26 --> Input Class Initialized
INFO - 2017-02-14 08:40:26 --> Language Class Initialized
INFO - 2017-02-14 08:40:26 --> Loader Class Initialized
INFO - 2017-02-14 08:40:26 --> Helper loaded: url_helper
INFO - 2017-02-14 08:40:26 --> Helper loaded: language_helper
INFO - 2017-02-14 08:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:40:26 --> Controller Class Initialized
INFO - 2017-02-14 08:40:26 --> Database Driver Class Initialized
INFO - 2017-02-14 08:40:26 --> Model Class Initialized
INFO - 2017-02-14 08:40:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:40:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:40:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:40:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:40:26 --> Final output sent to browser
DEBUG - 2017-02-14 08:40:26 --> Total execution time: 0.1092
INFO - 2017-02-14 08:41:17 --> Config Class Initialized
INFO - 2017-02-14 08:41:17 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:17 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:17 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:17 --> URI Class Initialized
INFO - 2017-02-14 08:41:17 --> Router Class Initialized
INFO - 2017-02-14 08:41:17 --> Output Class Initialized
INFO - 2017-02-14 08:41:17 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:17 --> Input Class Initialized
INFO - 2017-02-14 08:41:17 --> Language Class Initialized
INFO - 2017-02-14 08:41:17 --> Loader Class Initialized
INFO - 2017-02-14 08:41:17 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:17 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:17 --> Controller Class Initialized
INFO - 2017-02-14 08:41:17 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:17 --> Model Class Initialized
INFO - 2017-02-14 08:41:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:41:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:41:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:41:17 --> Final output sent to browser
DEBUG - 2017-02-14 08:41:17 --> Total execution time: 0.1366
INFO - 2017-02-14 08:41:20 --> Config Class Initialized
INFO - 2017-02-14 08:41:20 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:20 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:20 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:20 --> URI Class Initialized
INFO - 2017-02-14 08:41:20 --> Router Class Initialized
INFO - 2017-02-14 08:41:20 --> Output Class Initialized
INFO - 2017-02-14 08:41:20 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:20 --> Input Class Initialized
INFO - 2017-02-14 08:41:20 --> Language Class Initialized
INFO - 2017-02-14 08:41:20 --> Loader Class Initialized
INFO - 2017-02-14 08:41:20 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:20 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:20 --> Controller Class Initialized
INFO - 2017-02-14 08:41:20 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:20 --> Model Class Initialized
INFO - 2017-02-14 08:41:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:41:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:41:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:41:20 --> Final output sent to browser
DEBUG - 2017-02-14 08:41:20 --> Total execution time: 0.0943
INFO - 2017-02-14 08:41:29 --> Config Class Initialized
INFO - 2017-02-14 08:41:29 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:29 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:29 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:29 --> URI Class Initialized
DEBUG - 2017-02-14 08:41:29 --> No URI present. Default controller set.
INFO - 2017-02-14 08:41:29 --> Router Class Initialized
INFO - 2017-02-14 08:41:29 --> Output Class Initialized
INFO - 2017-02-14 08:41:29 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:29 --> Input Class Initialized
INFO - 2017-02-14 08:41:29 --> Language Class Initialized
INFO - 2017-02-14 08:41:29 --> Loader Class Initialized
INFO - 2017-02-14 08:41:29 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:29 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:29 --> Controller Class Initialized
INFO - 2017-02-14 08:41:29 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:29 --> Model Class Initialized
INFO - 2017-02-14 08:41:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-14 08:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-14 08:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-14 08:41:29 --> Final output sent to browser
DEBUG - 2017-02-14 08:41:29 --> Total execution time: 0.0729
INFO - 2017-02-14 08:41:34 --> Config Class Initialized
INFO - 2017-02-14 08:41:34 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:34 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:34 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:34 --> URI Class Initialized
INFO - 2017-02-14 08:41:35 --> Router Class Initialized
INFO - 2017-02-14 08:41:35 --> Output Class Initialized
INFO - 2017-02-14 08:41:35 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:35 --> Input Class Initialized
INFO - 2017-02-14 08:41:35 --> Language Class Initialized
INFO - 2017-02-14 08:41:35 --> Loader Class Initialized
INFO - 2017-02-14 08:41:35 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:35 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:35 --> Controller Class Initialized
INFO - 2017-02-14 08:41:35 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:35 --> Model Class Initialized
INFO - 2017-02-14 08:41:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:35 --> Config Class Initialized
INFO - 2017-02-14 08:41:35 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:35 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:35 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:35 --> URI Class Initialized
INFO - 2017-02-14 08:41:35 --> Router Class Initialized
INFO - 2017-02-14 08:41:35 --> Output Class Initialized
INFO - 2017-02-14 08:41:35 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:35 --> Input Class Initialized
INFO - 2017-02-14 08:41:35 --> Language Class Initialized
INFO - 2017-02-14 08:41:35 --> Loader Class Initialized
INFO - 2017-02-14 08:41:35 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:35 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:35 --> Controller Class Initialized
INFO - 2017-02-14 08:41:35 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:35 --> Model Class Initialized
INFO - 2017-02-14 08:41:35 --> Model Class Initialized
INFO - 2017-02-14 08:41:35 --> Model Class Initialized
INFO - 2017-02-14 08:41:35 --> Model Class Initialized
INFO - 2017-02-14 08:41:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:41:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-14 08:41:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:41:35 --> Final output sent to browser
DEBUG - 2017-02-14 08:41:35 --> Total execution time: 0.1398
INFO - 2017-02-14 08:41:38 --> Config Class Initialized
INFO - 2017-02-14 08:41:38 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:38 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:38 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:38 --> URI Class Initialized
INFO - 2017-02-14 08:41:38 --> Router Class Initialized
INFO - 2017-02-14 08:41:38 --> Output Class Initialized
INFO - 2017-02-14 08:41:38 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:38 --> Input Class Initialized
INFO - 2017-02-14 08:41:38 --> Language Class Initialized
INFO - 2017-02-14 08:41:38 --> Loader Class Initialized
INFO - 2017-02-14 08:41:38 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:38 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:39 --> Controller Class Initialized
INFO - 2017-02-14 08:41:39 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:39 --> Model Class Initialized
INFO - 2017-02-14 08:41:39 --> Model Class Initialized
INFO - 2017-02-14 08:41:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:41:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-14 08:41:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:41:39 --> Final output sent to browser
DEBUG - 2017-02-14 08:41:39 --> Total execution time: 0.0765
INFO - 2017-02-14 08:41:45 --> Config Class Initialized
INFO - 2017-02-14 08:41:45 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:45 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:45 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:45 --> URI Class Initialized
INFO - 2017-02-14 08:41:45 --> Router Class Initialized
INFO - 2017-02-14 08:41:45 --> Output Class Initialized
INFO - 2017-02-14 08:41:45 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:45 --> Input Class Initialized
INFO - 2017-02-14 08:41:45 --> Language Class Initialized
ERROR - 2017-02-14 08:41:45 --> 404 Page Not Found: New-quiz/index
INFO - 2017-02-14 08:41:51 --> Config Class Initialized
INFO - 2017-02-14 08:41:51 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:51 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:51 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:51 --> URI Class Initialized
INFO - 2017-02-14 08:41:51 --> Router Class Initialized
INFO - 2017-02-14 08:41:51 --> Output Class Initialized
INFO - 2017-02-14 08:41:51 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:51 --> Input Class Initialized
INFO - 2017-02-14 08:41:51 --> Language Class Initialized
ERROR - 2017-02-14 08:41:51 --> 404 Page Not Found: Add-quiz/index
INFO - 2017-02-14 08:41:57 --> Config Class Initialized
INFO - 2017-02-14 08:41:57 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:57 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:57 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:57 --> URI Class Initialized
DEBUG - 2017-02-14 08:41:57 --> No URI present. Default controller set.
INFO - 2017-02-14 08:41:57 --> Router Class Initialized
INFO - 2017-02-14 08:41:57 --> Output Class Initialized
INFO - 2017-02-14 08:41:57 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:57 --> Input Class Initialized
INFO - 2017-02-14 08:41:57 --> Language Class Initialized
INFO - 2017-02-14 08:41:57 --> Loader Class Initialized
INFO - 2017-02-14 08:41:57 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:57 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:57 --> Controller Class Initialized
INFO - 2017-02-14 08:41:57 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:57 --> Model Class Initialized
INFO - 2017-02-14 08:41:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:57 --> Config Class Initialized
INFO - 2017-02-14 08:41:57 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:57 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:57 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:57 --> URI Class Initialized
INFO - 2017-02-14 08:41:57 --> Router Class Initialized
INFO - 2017-02-14 08:41:57 --> Output Class Initialized
INFO - 2017-02-14 08:41:57 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:57 --> Input Class Initialized
INFO - 2017-02-14 08:41:57 --> Language Class Initialized
INFO - 2017-02-14 08:41:57 --> Loader Class Initialized
INFO - 2017-02-14 08:41:57 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:57 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:57 --> Controller Class Initialized
INFO - 2017-02-14 08:41:57 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:57 --> Model Class Initialized
INFO - 2017-02-14 08:41:57 --> Model Class Initialized
INFO - 2017-02-14 08:41:57 --> Model Class Initialized
INFO - 2017-02-14 08:41:57 --> Model Class Initialized
INFO - 2017-02-14 08:41:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:41:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-14 08:41:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:41:57 --> Final output sent to browser
DEBUG - 2017-02-14 08:41:57 --> Total execution time: 0.1057
INFO - 2017-02-14 08:41:58 --> Config Class Initialized
INFO - 2017-02-14 08:41:58 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:41:58 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:41:58 --> Utf8 Class Initialized
INFO - 2017-02-14 08:41:58 --> URI Class Initialized
INFO - 2017-02-14 08:41:58 --> Router Class Initialized
INFO - 2017-02-14 08:41:58 --> Output Class Initialized
INFO - 2017-02-14 08:41:59 --> Security Class Initialized
DEBUG - 2017-02-14 08:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:41:59 --> Input Class Initialized
INFO - 2017-02-14 08:41:59 --> Language Class Initialized
INFO - 2017-02-14 08:41:59 --> Loader Class Initialized
INFO - 2017-02-14 08:41:59 --> Helper loaded: url_helper
INFO - 2017-02-14 08:41:59 --> Helper loaded: language_helper
INFO - 2017-02-14 08:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:41:59 --> Controller Class Initialized
INFO - 2017-02-14 08:41:59 --> Database Driver Class Initialized
INFO - 2017-02-14 08:41:59 --> Model Class Initialized
INFO - 2017-02-14 08:41:59 --> Model Class Initialized
INFO - 2017-02-14 08:41:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:41:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:41:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-14 08:41:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:41:59 --> Final output sent to browser
DEBUG - 2017-02-14 08:41:59 --> Total execution time: 0.0865
INFO - 2017-02-14 08:42:05 --> Config Class Initialized
INFO - 2017-02-14 08:42:05 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:42:05 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:42:05 --> Utf8 Class Initialized
INFO - 2017-02-14 08:42:05 --> URI Class Initialized
INFO - 2017-02-14 08:42:05 --> Router Class Initialized
INFO - 2017-02-14 08:42:05 --> Output Class Initialized
INFO - 2017-02-14 08:42:05 --> Security Class Initialized
DEBUG - 2017-02-14 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:42:05 --> Input Class Initialized
INFO - 2017-02-14 08:42:05 --> Language Class Initialized
ERROR - 2017-02-14 08:42:05 --> 404 Page Not Found: Quiz/add
INFO - 2017-02-14 08:42:10 --> Config Class Initialized
INFO - 2017-02-14 08:42:10 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:42:10 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:42:10 --> Utf8 Class Initialized
INFO - 2017-02-14 08:42:10 --> URI Class Initialized
INFO - 2017-02-14 08:42:10 --> Router Class Initialized
INFO - 2017-02-14 08:42:10 --> Output Class Initialized
INFO - 2017-02-14 08:42:10 --> Security Class Initialized
DEBUG - 2017-02-14 08:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:42:10 --> Input Class Initialized
INFO - 2017-02-14 08:42:10 --> Language Class Initialized
ERROR - 2017-02-14 08:42:10 --> 404 Page Not Found: Quiz/add-new
INFO - 2017-02-14 08:42:16 --> Config Class Initialized
INFO - 2017-02-14 08:42:16 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:42:16 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:42:16 --> Utf8 Class Initialized
INFO - 2017-02-14 08:42:16 --> URI Class Initialized
INFO - 2017-02-14 08:42:16 --> Router Class Initialized
INFO - 2017-02-14 08:42:16 --> Output Class Initialized
INFO - 2017-02-14 08:42:16 --> Security Class Initialized
DEBUG - 2017-02-14 08:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:42:16 --> Input Class Initialized
INFO - 2017-02-14 08:42:16 --> Language Class Initialized
ERROR - 2017-02-14 08:42:16 --> 404 Page Not Found: Quiz/new
INFO - 2017-02-14 08:42:19 --> Config Class Initialized
INFO - 2017-02-14 08:42:19 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:42:19 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:42:19 --> Utf8 Class Initialized
INFO - 2017-02-14 08:42:19 --> URI Class Initialized
INFO - 2017-02-14 08:42:19 --> Router Class Initialized
INFO - 2017-02-14 08:42:19 --> Output Class Initialized
INFO - 2017-02-14 08:42:19 --> Security Class Initialized
DEBUG - 2017-02-14 08:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:42:19 --> Input Class Initialized
INFO - 2017-02-14 08:42:19 --> Language Class Initialized
ERROR - 2017-02-14 08:42:19 --> 404 Page Not Found: Quiz/new-quiz
INFO - 2017-02-14 08:42:25 --> Config Class Initialized
INFO - 2017-02-14 08:42:25 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:42:25 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:42:25 --> Utf8 Class Initialized
INFO - 2017-02-14 08:42:25 --> URI Class Initialized
INFO - 2017-02-14 08:42:25 --> Router Class Initialized
INFO - 2017-02-14 08:42:25 --> Output Class Initialized
INFO - 2017-02-14 08:42:25 --> Security Class Initialized
DEBUG - 2017-02-14 08:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:42:25 --> Input Class Initialized
INFO - 2017-02-14 08:42:25 --> Language Class Initialized
INFO - 2017-02-14 08:42:25 --> Loader Class Initialized
INFO - 2017-02-14 08:42:25 --> Helper loaded: url_helper
INFO - 2017-02-14 08:42:25 --> Helper loaded: language_helper
INFO - 2017-02-14 08:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:42:25 --> Controller Class Initialized
INFO - 2017-02-14 08:42:25 --> Database Driver Class Initialized
INFO - 2017-02-14 08:42:25 --> Model Class Initialized
INFO - 2017-02-14 08:42:25 --> Model Class Initialized
INFO - 2017-02-14 08:42:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:42:25 --> Model Class Initialized
INFO - 2017-02-14 08:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-14 08:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:42:25 --> Final output sent to browser
DEBUG - 2017-02-14 08:42:25 --> Total execution time: 0.1385
INFO - 2017-02-14 08:45:11 --> Config Class Initialized
INFO - 2017-02-14 08:45:11 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:45:11 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:45:11 --> Utf8 Class Initialized
INFO - 2017-02-14 08:45:11 --> URI Class Initialized
INFO - 2017-02-14 08:45:11 --> Router Class Initialized
INFO - 2017-02-14 08:45:11 --> Output Class Initialized
INFO - 2017-02-14 08:45:11 --> Security Class Initialized
DEBUG - 2017-02-14 08:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:45:11 --> Input Class Initialized
INFO - 2017-02-14 08:45:11 --> Language Class Initialized
INFO - 2017-02-14 08:45:12 --> Loader Class Initialized
INFO - 2017-02-14 08:45:12 --> Helper loaded: url_helper
INFO - 2017-02-14 08:45:12 --> Helper loaded: language_helper
INFO - 2017-02-14 08:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:45:12 --> Controller Class Initialized
INFO - 2017-02-14 08:45:12 --> Database Driver Class Initialized
INFO - 2017-02-14 08:45:12 --> Model Class Initialized
INFO - 2017-02-14 08:45:12 --> Model Class Initialized
INFO - 2017-02-14 08:45:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:45:12 --> Model Class Initialized
INFO - 2017-02-14 08:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-14 08:45:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:45:12 --> Final output sent to browser
DEBUG - 2017-02-14 08:45:12 --> Total execution time: 0.1258
INFO - 2017-02-14 08:47:23 --> Config Class Initialized
INFO - 2017-02-14 08:47:23 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:47:23 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:47:23 --> Utf8 Class Initialized
INFO - 2017-02-14 08:47:23 --> URI Class Initialized
INFO - 2017-02-14 08:47:23 --> Router Class Initialized
INFO - 2017-02-14 08:47:23 --> Output Class Initialized
INFO - 2017-02-14 08:47:23 --> Security Class Initialized
DEBUG - 2017-02-14 08:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:47:23 --> Input Class Initialized
INFO - 2017-02-14 08:47:23 --> Language Class Initialized
INFO - 2017-02-14 08:47:23 --> Loader Class Initialized
INFO - 2017-02-14 08:47:23 --> Helper loaded: url_helper
INFO - 2017-02-14 08:47:23 --> Helper loaded: language_helper
INFO - 2017-02-14 08:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:47:23 --> Controller Class Initialized
INFO - 2017-02-14 08:47:23 --> Database Driver Class Initialized
INFO - 2017-02-14 08:47:23 --> Model Class Initialized
INFO - 2017-02-14 08:47:23 --> Model Class Initialized
INFO - 2017-02-14 08:47:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:47:23 --> Model Class Initialized
INFO - 2017-02-14 08:47:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:47:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-14 08:47:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:47:23 --> Final output sent to browser
DEBUG - 2017-02-14 08:47:23 --> Total execution time: 0.1243
INFO - 2017-02-14 08:47:44 --> Config Class Initialized
INFO - 2017-02-14 08:47:44 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:47:44 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:47:44 --> Utf8 Class Initialized
INFO - 2017-02-14 08:47:44 --> URI Class Initialized
INFO - 2017-02-14 08:47:44 --> Router Class Initialized
INFO - 2017-02-14 08:47:44 --> Output Class Initialized
INFO - 2017-02-14 08:47:44 --> Security Class Initialized
DEBUG - 2017-02-14 08:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:47:44 --> Input Class Initialized
INFO - 2017-02-14 08:47:44 --> Language Class Initialized
INFO - 2017-02-14 08:47:44 --> Loader Class Initialized
INFO - 2017-02-14 08:47:44 --> Helper loaded: url_helper
INFO - 2017-02-14 08:47:44 --> Helper loaded: language_helper
INFO - 2017-02-14 08:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:47:44 --> Controller Class Initialized
INFO - 2017-02-14 08:47:44 --> Database Driver Class Initialized
INFO - 2017-02-14 08:47:44 --> Model Class Initialized
INFO - 2017-02-14 08:47:44 --> Model Class Initialized
INFO - 2017-02-14 08:47:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:47:44 --> Model Class Initialized
INFO - 2017-02-14 08:47:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:47:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-14 08:47:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:47:44 --> Final output sent to browser
DEBUG - 2017-02-14 08:47:44 --> Total execution time: 0.0880
INFO - 2017-02-14 08:48:33 --> Config Class Initialized
INFO - 2017-02-14 08:48:33 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:48:33 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:48:33 --> Utf8 Class Initialized
INFO - 2017-02-14 08:48:33 --> URI Class Initialized
INFO - 2017-02-14 08:48:33 --> Router Class Initialized
INFO - 2017-02-14 08:48:33 --> Output Class Initialized
INFO - 2017-02-14 08:48:33 --> Security Class Initialized
DEBUG - 2017-02-14 08:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:48:33 --> Input Class Initialized
INFO - 2017-02-14 08:48:33 --> Language Class Initialized
INFO - 2017-02-14 08:48:33 --> Loader Class Initialized
INFO - 2017-02-14 08:48:33 --> Helper loaded: url_helper
INFO - 2017-02-14 08:48:33 --> Helper loaded: language_helper
INFO - 2017-02-14 08:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:48:33 --> Controller Class Initialized
INFO - 2017-02-14 08:48:33 --> Database Driver Class Initialized
INFO - 2017-02-14 08:48:33 --> Model Class Initialized
INFO - 2017-02-14 08:48:33 --> Model Class Initialized
INFO - 2017-02-14 08:48:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:48:33 --> Model Class Initialized
INFO - 2017-02-14 08:48:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:48:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-14 08:48:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:48:33 --> Final output sent to browser
DEBUG - 2017-02-14 08:48:33 --> Total execution time: 0.1198
INFO - 2017-02-14 08:51:51 --> Config Class Initialized
INFO - 2017-02-14 08:51:51 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:51:51 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:51:51 --> Utf8 Class Initialized
INFO - 2017-02-14 08:51:51 --> URI Class Initialized
INFO - 2017-02-14 08:51:51 --> Router Class Initialized
INFO - 2017-02-14 08:51:51 --> Output Class Initialized
INFO - 2017-02-14 08:51:51 --> Security Class Initialized
DEBUG - 2017-02-14 08:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:51:51 --> Input Class Initialized
INFO - 2017-02-14 08:51:51 --> Language Class Initialized
INFO - 2017-02-14 08:51:51 --> Loader Class Initialized
INFO - 2017-02-14 08:51:51 --> Helper loaded: url_helper
INFO - 2017-02-14 08:51:51 --> Helper loaded: language_helper
INFO - 2017-02-14 08:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:51:51 --> Controller Class Initialized
INFO - 2017-02-14 08:51:51 --> Database Driver Class Initialized
INFO - 2017-02-14 08:51:51 --> Model Class Initialized
INFO - 2017-02-14 08:51:51 --> Model Class Initialized
INFO - 2017-02-14 08:51:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:51:51 --> Model Class Initialized
INFO - 2017-02-14 08:51:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:51:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-14 08:51:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:51:51 --> Final output sent to browser
DEBUG - 2017-02-14 08:51:51 --> Total execution time: 0.0916
INFO - 2017-02-14 08:53:43 --> Config Class Initialized
INFO - 2017-02-14 08:53:43 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:53:43 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:53:43 --> Utf8 Class Initialized
INFO - 2017-02-14 08:53:43 --> URI Class Initialized
INFO - 2017-02-14 08:53:43 --> Router Class Initialized
INFO - 2017-02-14 08:53:43 --> Output Class Initialized
INFO - 2017-02-14 08:53:43 --> Security Class Initialized
DEBUG - 2017-02-14 08:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:53:43 --> Input Class Initialized
INFO - 2017-02-14 08:53:43 --> Language Class Initialized
INFO - 2017-02-14 08:53:43 --> Loader Class Initialized
INFO - 2017-02-14 08:53:43 --> Helper loaded: url_helper
INFO - 2017-02-14 08:53:43 --> Helper loaded: language_helper
INFO - 2017-02-14 08:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:53:43 --> Controller Class Initialized
INFO - 2017-02-14 08:53:43 --> Database Driver Class Initialized
INFO - 2017-02-14 08:53:43 --> Model Class Initialized
INFO - 2017-02-14 08:53:43 --> Model Class Initialized
INFO - 2017-02-14 08:53:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:53:43 --> Config Class Initialized
INFO - 2017-02-14 08:53:43 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:53:43 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:53:43 --> Utf8 Class Initialized
INFO - 2017-02-14 08:53:43 --> URI Class Initialized
INFO - 2017-02-14 08:53:43 --> Router Class Initialized
INFO - 2017-02-14 08:53:43 --> Output Class Initialized
INFO - 2017-02-14 08:53:43 --> Security Class Initialized
DEBUG - 2017-02-14 08:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:53:43 --> Input Class Initialized
INFO - 2017-02-14 08:53:43 --> Language Class Initialized
INFO - 2017-02-14 08:53:43 --> Loader Class Initialized
INFO - 2017-02-14 08:53:43 --> Helper loaded: url_helper
INFO - 2017-02-14 08:53:43 --> Helper loaded: language_helper
INFO - 2017-02-14 08:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:53:43 --> Controller Class Initialized
INFO - 2017-02-14 08:53:44 --> Database Driver Class Initialized
INFO - 2017-02-14 08:53:44 --> Model Class Initialized
INFO - 2017-02-14 08:53:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:53:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-14 08:53:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-14 08:53:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-14 08:53:44 --> Final output sent to browser
DEBUG - 2017-02-14 08:53:44 --> Total execution time: 0.0925
INFO - 2017-02-14 08:53:47 --> Config Class Initialized
INFO - 2017-02-14 08:53:47 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:53:47 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:53:47 --> Utf8 Class Initialized
INFO - 2017-02-14 08:53:47 --> URI Class Initialized
INFO - 2017-02-14 08:53:47 --> Router Class Initialized
INFO - 2017-02-14 08:53:47 --> Output Class Initialized
INFO - 2017-02-14 08:53:47 --> Security Class Initialized
DEBUG - 2017-02-14 08:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:53:47 --> Input Class Initialized
INFO - 2017-02-14 08:53:47 --> Language Class Initialized
INFO - 2017-02-14 08:53:47 --> Loader Class Initialized
INFO - 2017-02-14 08:53:47 --> Helper loaded: url_helper
INFO - 2017-02-14 08:53:47 --> Helper loaded: language_helper
INFO - 2017-02-14 08:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:53:47 --> Controller Class Initialized
INFO - 2017-02-14 08:53:47 --> Database Driver Class Initialized
INFO - 2017-02-14 08:53:47 --> Model Class Initialized
INFO - 2017-02-14 08:53:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:53:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:53:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:53:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:53:47 --> Final output sent to browser
DEBUG - 2017-02-14 08:53:47 --> Total execution time: 0.0762
INFO - 2017-02-14 08:54:41 --> Config Class Initialized
INFO - 2017-02-14 08:54:41 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:54:41 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:54:41 --> Utf8 Class Initialized
INFO - 2017-02-14 08:54:41 --> URI Class Initialized
INFO - 2017-02-14 08:54:41 --> Router Class Initialized
INFO - 2017-02-14 08:54:41 --> Output Class Initialized
INFO - 2017-02-14 08:54:41 --> Security Class Initialized
DEBUG - 2017-02-14 08:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:54:41 --> Input Class Initialized
INFO - 2017-02-14 08:54:41 --> Language Class Initialized
INFO - 2017-02-14 08:54:41 --> Loader Class Initialized
INFO - 2017-02-14 08:54:41 --> Helper loaded: url_helper
INFO - 2017-02-14 08:54:41 --> Helper loaded: language_helper
INFO - 2017-02-14 08:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:54:42 --> Controller Class Initialized
INFO - 2017-02-14 08:54:42 --> Database Driver Class Initialized
INFO - 2017-02-14 08:54:42 --> Model Class Initialized
INFO - 2017-02-14 08:54:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:54:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:54:42 --> Final output sent to browser
DEBUG - 2017-02-14 08:54:42 --> Total execution time: 0.0983
INFO - 2017-02-14 08:56:36 --> Config Class Initialized
INFO - 2017-02-14 08:56:36 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:56:36 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:56:36 --> Utf8 Class Initialized
INFO - 2017-02-14 08:56:36 --> URI Class Initialized
INFO - 2017-02-14 08:56:36 --> Router Class Initialized
INFO - 2017-02-14 08:56:36 --> Output Class Initialized
INFO - 2017-02-14 08:56:36 --> Security Class Initialized
DEBUG - 2017-02-14 08:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:56:36 --> Input Class Initialized
INFO - 2017-02-14 08:56:37 --> Language Class Initialized
INFO - 2017-02-14 08:56:37 --> Loader Class Initialized
INFO - 2017-02-14 08:56:37 --> Helper loaded: url_helper
INFO - 2017-02-14 08:56:37 --> Helper loaded: language_helper
INFO - 2017-02-14 08:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:56:37 --> Controller Class Initialized
INFO - 2017-02-14 08:56:37 --> Database Driver Class Initialized
INFO - 2017-02-14 08:56:37 --> Model Class Initialized
INFO - 2017-02-14 08:56:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:56:37 --> Final output sent to browser
DEBUG - 2017-02-14 08:56:37 --> Total execution time: 0.0986
INFO - 2017-02-14 08:57:28 --> Config Class Initialized
INFO - 2017-02-14 08:57:28 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:57:28 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:57:28 --> Utf8 Class Initialized
INFO - 2017-02-14 08:57:28 --> URI Class Initialized
INFO - 2017-02-14 08:57:28 --> Router Class Initialized
INFO - 2017-02-14 08:57:28 --> Output Class Initialized
INFO - 2017-02-14 08:57:28 --> Security Class Initialized
DEBUG - 2017-02-14 08:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:57:28 --> Input Class Initialized
INFO - 2017-02-14 08:57:28 --> Language Class Initialized
INFO - 2017-02-14 08:57:28 --> Loader Class Initialized
INFO - 2017-02-14 08:57:28 --> Helper loaded: url_helper
INFO - 2017-02-14 08:57:28 --> Helper loaded: language_helper
INFO - 2017-02-14 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:57:28 --> Controller Class Initialized
INFO - 2017-02-14 08:57:28 --> Database Driver Class Initialized
INFO - 2017-02-14 08:57:28 --> Model Class Initialized
INFO - 2017-02-14 08:57:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:57:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:57:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:57:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:57:28 --> Final output sent to browser
DEBUG - 2017-02-14 08:57:28 --> Total execution time: 0.0684
INFO - 2017-02-14 08:57:45 --> Config Class Initialized
INFO - 2017-02-14 08:57:45 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:57:45 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:57:45 --> Utf8 Class Initialized
INFO - 2017-02-14 08:57:45 --> URI Class Initialized
INFO - 2017-02-14 08:57:45 --> Router Class Initialized
INFO - 2017-02-14 08:57:45 --> Output Class Initialized
INFO - 2017-02-14 08:57:45 --> Security Class Initialized
DEBUG - 2017-02-14 08:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:57:45 --> Input Class Initialized
INFO - 2017-02-14 08:57:45 --> Language Class Initialized
INFO - 2017-02-14 08:57:45 --> Loader Class Initialized
INFO - 2017-02-14 08:57:45 --> Helper loaded: url_helper
INFO - 2017-02-14 08:57:45 --> Helper loaded: language_helper
INFO - 2017-02-14 08:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:57:45 --> Controller Class Initialized
INFO - 2017-02-14 08:57:45 --> Database Driver Class Initialized
INFO - 2017-02-14 08:57:45 --> Model Class Initialized
INFO - 2017-02-14 08:57:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:57:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:57:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:57:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:57:45 --> Final output sent to browser
DEBUG - 2017-02-14 08:57:45 --> Total execution time: 0.0639
INFO - 2017-02-14 08:58:52 --> Config Class Initialized
INFO - 2017-02-14 08:58:52 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:58:52 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:58:52 --> Utf8 Class Initialized
INFO - 2017-02-14 08:58:52 --> URI Class Initialized
INFO - 2017-02-14 08:58:52 --> Router Class Initialized
INFO - 2017-02-14 08:58:52 --> Output Class Initialized
INFO - 2017-02-14 08:58:52 --> Security Class Initialized
DEBUG - 2017-02-14 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:58:52 --> Input Class Initialized
INFO - 2017-02-14 08:58:52 --> Language Class Initialized
INFO - 2017-02-14 08:58:52 --> Loader Class Initialized
INFO - 2017-02-14 08:58:52 --> Helper loaded: url_helper
INFO - 2017-02-14 08:58:52 --> Helper loaded: language_helper
INFO - 2017-02-14 08:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:58:52 --> Controller Class Initialized
INFO - 2017-02-14 08:58:52 --> Database Driver Class Initialized
INFO - 2017-02-14 08:58:52 --> Model Class Initialized
INFO - 2017-02-14 08:58:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:58:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:58:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:58:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:58:52 --> Final output sent to browser
DEBUG - 2017-02-14 08:58:52 --> Total execution time: 0.0711
INFO - 2017-02-14 08:59:01 --> Config Class Initialized
INFO - 2017-02-14 08:59:01 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:59:01 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:59:01 --> Utf8 Class Initialized
INFO - 2017-02-14 08:59:01 --> URI Class Initialized
DEBUG - 2017-02-14 08:59:01 --> No URI present. Default controller set.
INFO - 2017-02-14 08:59:01 --> Router Class Initialized
INFO - 2017-02-14 08:59:01 --> Output Class Initialized
INFO - 2017-02-14 08:59:01 --> Security Class Initialized
DEBUG - 2017-02-14 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:59:01 --> Input Class Initialized
INFO - 2017-02-14 08:59:01 --> Language Class Initialized
INFO - 2017-02-14 08:59:01 --> Loader Class Initialized
INFO - 2017-02-14 08:59:01 --> Helper loaded: url_helper
INFO - 2017-02-14 08:59:01 --> Helper loaded: language_helper
INFO - 2017-02-14 08:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:59:01 --> Controller Class Initialized
INFO - 2017-02-14 08:59:01 --> Database Driver Class Initialized
INFO - 2017-02-14 08:59:01 --> Model Class Initialized
INFO - 2017-02-14 08:59:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:59:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-14 08:59:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-14 08:59:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-14 08:59:01 --> Final output sent to browser
DEBUG - 2017-02-14 08:59:01 --> Total execution time: 0.0629
INFO - 2017-02-14 08:59:06 --> Config Class Initialized
INFO - 2017-02-14 08:59:06 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:59:06 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:59:06 --> Utf8 Class Initialized
INFO - 2017-02-14 08:59:06 --> URI Class Initialized
INFO - 2017-02-14 08:59:06 --> Router Class Initialized
INFO - 2017-02-14 08:59:06 --> Output Class Initialized
INFO - 2017-02-14 08:59:06 --> Security Class Initialized
DEBUG - 2017-02-14 08:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:59:06 --> Input Class Initialized
INFO - 2017-02-14 08:59:06 --> Language Class Initialized
INFO - 2017-02-14 08:59:06 --> Loader Class Initialized
INFO - 2017-02-14 08:59:06 --> Helper loaded: url_helper
INFO - 2017-02-14 08:59:06 --> Helper loaded: language_helper
INFO - 2017-02-14 08:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:59:06 --> Controller Class Initialized
INFO - 2017-02-14 08:59:06 --> Database Driver Class Initialized
INFO - 2017-02-14 08:59:06 --> Model Class Initialized
INFO - 2017-02-14 08:59:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:59:06 --> Config Class Initialized
INFO - 2017-02-14 08:59:06 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:59:06 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:59:06 --> Utf8 Class Initialized
INFO - 2017-02-14 08:59:06 --> URI Class Initialized
INFO - 2017-02-14 08:59:06 --> Router Class Initialized
INFO - 2017-02-14 08:59:06 --> Output Class Initialized
INFO - 2017-02-14 08:59:06 --> Security Class Initialized
DEBUG - 2017-02-14 08:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:59:06 --> Input Class Initialized
INFO - 2017-02-14 08:59:06 --> Language Class Initialized
INFO - 2017-02-14 08:59:06 --> Loader Class Initialized
INFO - 2017-02-14 08:59:06 --> Helper loaded: url_helper
INFO - 2017-02-14 08:59:06 --> Helper loaded: language_helper
INFO - 2017-02-14 08:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:59:06 --> Controller Class Initialized
INFO - 2017-02-14 08:59:06 --> Database Driver Class Initialized
INFO - 2017-02-14 08:59:06 --> Model Class Initialized
INFO - 2017-02-14 08:59:06 --> Model Class Initialized
INFO - 2017-02-14 08:59:06 --> Model Class Initialized
INFO - 2017-02-14 08:59:06 --> Model Class Initialized
INFO - 2017-02-14 08:59:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-14 08:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:59:06 --> Final output sent to browser
DEBUG - 2017-02-14 08:59:06 --> Total execution time: 0.0998
INFO - 2017-02-14 08:59:19 --> Config Class Initialized
INFO - 2017-02-14 08:59:19 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:59:19 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:59:19 --> Utf8 Class Initialized
INFO - 2017-02-14 08:59:19 --> URI Class Initialized
INFO - 2017-02-14 08:59:19 --> Router Class Initialized
INFO - 2017-02-14 08:59:19 --> Output Class Initialized
INFO - 2017-02-14 08:59:19 --> Security Class Initialized
DEBUG - 2017-02-14 08:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:59:19 --> Input Class Initialized
INFO - 2017-02-14 08:59:19 --> Language Class Initialized
INFO - 2017-02-14 08:59:19 --> Loader Class Initialized
INFO - 2017-02-14 08:59:19 --> Helper loaded: url_helper
INFO - 2017-02-14 08:59:19 --> Helper loaded: language_helper
INFO - 2017-02-14 08:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:59:19 --> Controller Class Initialized
INFO - 2017-02-14 08:59:19 --> Database Driver Class Initialized
INFO - 2017-02-14 08:59:19 --> Model Class Initialized
INFO - 2017-02-14 08:59:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:59:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:59:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:59:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:59:19 --> Final output sent to browser
DEBUG - 2017-02-14 08:59:19 --> Total execution time: 0.0650
INFO - 2017-02-14 08:59:43 --> Config Class Initialized
INFO - 2017-02-14 08:59:43 --> Hooks Class Initialized
DEBUG - 2017-02-14 08:59:43 --> UTF-8 Support Enabled
INFO - 2017-02-14 08:59:43 --> Utf8 Class Initialized
INFO - 2017-02-14 08:59:43 --> URI Class Initialized
INFO - 2017-02-14 08:59:43 --> Router Class Initialized
INFO - 2017-02-14 08:59:43 --> Output Class Initialized
INFO - 2017-02-14 08:59:43 --> Security Class Initialized
DEBUG - 2017-02-14 08:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 08:59:43 --> Input Class Initialized
INFO - 2017-02-14 08:59:43 --> Language Class Initialized
INFO - 2017-02-14 08:59:43 --> Loader Class Initialized
INFO - 2017-02-14 08:59:43 --> Helper loaded: url_helper
INFO - 2017-02-14 08:59:43 --> Helper loaded: language_helper
INFO - 2017-02-14 08:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 08:59:43 --> Controller Class Initialized
INFO - 2017-02-14 08:59:43 --> Database Driver Class Initialized
INFO - 2017-02-14 08:59:43 --> Model Class Initialized
INFO - 2017-02-14 08:59:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 08:59:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 08:59:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 08:59:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 08:59:43 --> Final output sent to browser
DEBUG - 2017-02-14 08:59:43 --> Total execution time: 0.0924
INFO - 2017-02-14 09:00:07 --> Config Class Initialized
INFO - 2017-02-14 09:00:07 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:00:07 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:00:07 --> Utf8 Class Initialized
INFO - 2017-02-14 09:00:07 --> URI Class Initialized
INFO - 2017-02-14 09:00:07 --> Router Class Initialized
INFO - 2017-02-14 09:00:07 --> Output Class Initialized
INFO - 2017-02-14 09:00:07 --> Security Class Initialized
DEBUG - 2017-02-14 09:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:00:07 --> Input Class Initialized
INFO - 2017-02-14 09:00:07 --> Language Class Initialized
INFO - 2017-02-14 09:00:07 --> Loader Class Initialized
INFO - 2017-02-14 09:00:07 --> Helper loaded: url_helper
INFO - 2017-02-14 09:00:07 --> Helper loaded: language_helper
INFO - 2017-02-14 09:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:00:07 --> Controller Class Initialized
INFO - 2017-02-14 09:00:07 --> Database Driver Class Initialized
INFO - 2017-02-14 09:00:07 --> Model Class Initialized
INFO - 2017-02-14 09:00:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:00:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:00:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:00:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:00:07 --> Final output sent to browser
DEBUG - 2017-02-14 09:00:07 --> Total execution time: 0.0667
INFO - 2017-02-14 09:00:33 --> Config Class Initialized
INFO - 2017-02-14 09:00:33 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:00:33 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:00:33 --> Utf8 Class Initialized
INFO - 2017-02-14 09:00:33 --> URI Class Initialized
INFO - 2017-02-14 09:00:33 --> Router Class Initialized
INFO - 2017-02-14 09:00:33 --> Output Class Initialized
INFO - 2017-02-14 09:00:33 --> Security Class Initialized
DEBUG - 2017-02-14 09:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:00:33 --> Input Class Initialized
INFO - 2017-02-14 09:00:33 --> Language Class Initialized
INFO - 2017-02-14 09:00:33 --> Loader Class Initialized
INFO - 2017-02-14 09:00:33 --> Helper loaded: url_helper
INFO - 2017-02-14 09:00:33 --> Helper loaded: language_helper
INFO - 2017-02-14 09:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:00:33 --> Controller Class Initialized
INFO - 2017-02-14 09:00:33 --> Database Driver Class Initialized
INFO - 2017-02-14 09:00:33 --> Model Class Initialized
INFO - 2017-02-14 09:00:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:00:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:00:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:00:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:00:33 --> Final output sent to browser
DEBUG - 2017-02-14 09:00:33 --> Total execution time: 0.0754
INFO - 2017-02-14 09:02:37 --> Config Class Initialized
INFO - 2017-02-14 09:02:37 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:02:37 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:02:37 --> Utf8 Class Initialized
INFO - 2017-02-14 09:02:37 --> URI Class Initialized
INFO - 2017-02-14 09:02:37 --> Router Class Initialized
INFO - 2017-02-14 09:02:37 --> Output Class Initialized
INFO - 2017-02-14 09:02:37 --> Security Class Initialized
DEBUG - 2017-02-14 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:02:37 --> Input Class Initialized
INFO - 2017-02-14 09:02:37 --> Language Class Initialized
INFO - 2017-02-14 09:02:37 --> Loader Class Initialized
INFO - 2017-02-14 09:02:37 --> Helper loaded: url_helper
INFO - 2017-02-14 09:02:37 --> Helper loaded: language_helper
INFO - 2017-02-14 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:02:37 --> Controller Class Initialized
INFO - 2017-02-14 09:02:37 --> Database Driver Class Initialized
INFO - 2017-02-14 09:02:37 --> Model Class Initialized
INFO - 2017-02-14 09:02:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:02:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:02:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:02:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:02:37 --> Final output sent to browser
DEBUG - 2017-02-14 09:02:37 --> Total execution time: 0.1384
INFO - 2017-02-14 09:04:30 --> Config Class Initialized
INFO - 2017-02-14 09:04:30 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:04:30 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:04:30 --> Utf8 Class Initialized
INFO - 2017-02-14 09:04:30 --> URI Class Initialized
INFO - 2017-02-14 09:04:30 --> Router Class Initialized
INFO - 2017-02-14 09:04:30 --> Output Class Initialized
INFO - 2017-02-14 09:04:30 --> Security Class Initialized
DEBUG - 2017-02-14 09:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:04:30 --> Input Class Initialized
INFO - 2017-02-14 09:04:30 --> Language Class Initialized
INFO - 2017-02-14 09:04:30 --> Loader Class Initialized
INFO - 2017-02-14 09:04:30 --> Helper loaded: url_helper
INFO - 2017-02-14 09:04:30 --> Helper loaded: language_helper
INFO - 2017-02-14 09:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:04:30 --> Controller Class Initialized
INFO - 2017-02-14 09:04:30 --> Database Driver Class Initialized
INFO - 2017-02-14 09:04:30 --> Model Class Initialized
INFO - 2017-02-14 09:04:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:04:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:04:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:04:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:04:30 --> Final output sent to browser
DEBUG - 2017-02-14 09:04:30 --> Total execution time: 0.0967
INFO - 2017-02-14 09:05:07 --> Config Class Initialized
INFO - 2017-02-14 09:05:07 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:05:07 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:05:07 --> Utf8 Class Initialized
INFO - 2017-02-14 09:05:07 --> URI Class Initialized
INFO - 2017-02-14 09:05:07 --> Router Class Initialized
INFO - 2017-02-14 09:05:07 --> Output Class Initialized
INFO - 2017-02-14 09:05:07 --> Security Class Initialized
DEBUG - 2017-02-14 09:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:05:07 --> Input Class Initialized
INFO - 2017-02-14 09:05:07 --> Language Class Initialized
INFO - 2017-02-14 09:05:07 --> Loader Class Initialized
INFO - 2017-02-14 09:05:07 --> Helper loaded: url_helper
INFO - 2017-02-14 09:05:07 --> Helper loaded: language_helper
INFO - 2017-02-14 09:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:05:07 --> Controller Class Initialized
INFO - 2017-02-14 09:05:07 --> Database Driver Class Initialized
INFO - 2017-02-14 09:05:07 --> Model Class Initialized
INFO - 2017-02-14 09:05:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:05:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:05:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:05:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:05:07 --> Final output sent to browser
DEBUG - 2017-02-14 09:05:07 --> Total execution time: 0.0790
INFO - 2017-02-14 09:05:26 --> Config Class Initialized
INFO - 2017-02-14 09:05:26 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:05:26 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:05:26 --> Utf8 Class Initialized
INFO - 2017-02-14 09:05:26 --> URI Class Initialized
INFO - 2017-02-14 09:05:26 --> Router Class Initialized
INFO - 2017-02-14 09:05:26 --> Output Class Initialized
INFO - 2017-02-14 09:05:26 --> Security Class Initialized
DEBUG - 2017-02-14 09:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:05:26 --> Input Class Initialized
INFO - 2017-02-14 09:05:26 --> Language Class Initialized
INFO - 2017-02-14 09:05:26 --> Loader Class Initialized
INFO - 2017-02-14 09:05:26 --> Helper loaded: url_helper
INFO - 2017-02-14 09:05:26 --> Helper loaded: language_helper
INFO - 2017-02-14 09:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:05:26 --> Controller Class Initialized
INFO - 2017-02-14 09:05:26 --> Database Driver Class Initialized
INFO - 2017-02-14 09:05:26 --> Model Class Initialized
INFO - 2017-02-14 09:05:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:05:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:05:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:05:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:05:26 --> Final output sent to browser
DEBUG - 2017-02-14 09:05:26 --> Total execution time: 0.1011
INFO - 2017-02-14 09:05:49 --> Config Class Initialized
INFO - 2017-02-14 09:05:49 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:05:49 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:05:49 --> Utf8 Class Initialized
INFO - 2017-02-14 09:05:49 --> URI Class Initialized
INFO - 2017-02-14 09:05:49 --> Router Class Initialized
INFO - 2017-02-14 09:05:49 --> Output Class Initialized
INFO - 2017-02-14 09:05:49 --> Security Class Initialized
DEBUG - 2017-02-14 09:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:05:49 --> Input Class Initialized
INFO - 2017-02-14 09:05:49 --> Language Class Initialized
INFO - 2017-02-14 09:05:49 --> Loader Class Initialized
INFO - 2017-02-14 09:05:49 --> Helper loaded: url_helper
INFO - 2017-02-14 09:05:49 --> Helper loaded: language_helper
INFO - 2017-02-14 09:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:05:49 --> Controller Class Initialized
INFO - 2017-02-14 09:05:49 --> Database Driver Class Initialized
INFO - 2017-02-14 09:05:49 --> Model Class Initialized
INFO - 2017-02-14 09:05:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:05:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:05:49 --> Final output sent to browser
DEBUG - 2017-02-14 09:05:49 --> Total execution time: 0.0762
INFO - 2017-02-14 09:13:33 --> Config Class Initialized
INFO - 2017-02-14 09:13:33 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:13:33 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:13:33 --> Utf8 Class Initialized
INFO - 2017-02-14 09:13:33 --> URI Class Initialized
INFO - 2017-02-14 09:13:33 --> Router Class Initialized
INFO - 2017-02-14 09:13:33 --> Output Class Initialized
INFO - 2017-02-14 09:13:33 --> Security Class Initialized
DEBUG - 2017-02-14 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:13:33 --> Input Class Initialized
INFO - 2017-02-14 09:13:33 --> Language Class Initialized
INFO - 2017-02-14 09:13:33 --> Loader Class Initialized
INFO - 2017-02-14 09:13:33 --> Helper loaded: url_helper
INFO - 2017-02-14 09:13:33 --> Helper loaded: language_helper
INFO - 2017-02-14 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:13:33 --> Controller Class Initialized
INFO - 2017-02-14 09:13:33 --> Database Driver Class Initialized
INFO - 2017-02-14 09:13:33 --> Model Class Initialized
INFO - 2017-02-14 09:13:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:13:34 --> Helper loaded: form_helper
INFO - 2017-02-14 09:13:34 --> Form Validation Class Initialized
INFO - 2017-02-14 09:13:34 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-14 09:13:34 --> Query error: Column 'gid' cannot be null - Invalid query: INSERT INTO `users` (`email`, `registration_no`, `password`, `first_name`, `last_name`, `contact_no`, `gid`, `su`, `verify_code`) VALUES ('sangbima.net@gmail.com', NULL, '130530b4bd3a33fd383cbe7431aa176b', 'Khairil', 'Khairil', '082948924', NULL, '0', 2561)
INFO - 2017-02-14 09:13:34 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-02-14 09:14:25 --> Config Class Initialized
INFO - 2017-02-14 09:14:25 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:14:25 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:14:25 --> Utf8 Class Initialized
INFO - 2017-02-14 09:14:25 --> URI Class Initialized
INFO - 2017-02-14 09:14:25 --> Router Class Initialized
INFO - 2017-02-14 09:14:25 --> Output Class Initialized
INFO - 2017-02-14 09:14:25 --> Security Class Initialized
DEBUG - 2017-02-14 09:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:14:25 --> Input Class Initialized
INFO - 2017-02-14 09:14:25 --> Language Class Initialized
INFO - 2017-02-14 09:14:25 --> Loader Class Initialized
INFO - 2017-02-14 09:14:25 --> Helper loaded: url_helper
INFO - 2017-02-14 09:14:25 --> Helper loaded: language_helper
INFO - 2017-02-14 09:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:14:25 --> Controller Class Initialized
INFO - 2017-02-14 09:14:25 --> Database Driver Class Initialized
INFO - 2017-02-14 09:14:25 --> Model Class Initialized
INFO - 2017-02-14 09:14:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:14:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:14:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:14:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:14:25 --> Final output sent to browser
DEBUG - 2017-02-14 09:14:25 --> Total execution time: 0.0661
INFO - 2017-02-14 09:14:37 --> Config Class Initialized
INFO - 2017-02-14 09:14:37 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:14:37 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:14:37 --> Utf8 Class Initialized
INFO - 2017-02-14 09:14:37 --> URI Class Initialized
INFO - 2017-02-14 09:14:37 --> Router Class Initialized
INFO - 2017-02-14 09:14:37 --> Output Class Initialized
INFO - 2017-02-14 09:14:37 --> Security Class Initialized
DEBUG - 2017-02-14 09:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:14:37 --> Input Class Initialized
INFO - 2017-02-14 09:14:37 --> Language Class Initialized
INFO - 2017-02-14 09:14:37 --> Loader Class Initialized
INFO - 2017-02-14 09:14:37 --> Helper loaded: url_helper
INFO - 2017-02-14 09:14:37 --> Helper loaded: language_helper
INFO - 2017-02-14 09:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:14:37 --> Controller Class Initialized
INFO - 2017-02-14 09:14:37 --> Database Driver Class Initialized
INFO - 2017-02-14 09:14:37 --> Model Class Initialized
INFO - 2017-02-14 09:14:37 --> Model Class Initialized
INFO - 2017-02-14 09:14:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:14:37 --> Config Class Initialized
INFO - 2017-02-14 09:14:37 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:14:37 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:14:37 --> Utf8 Class Initialized
INFO - 2017-02-14 09:14:37 --> URI Class Initialized
INFO - 2017-02-14 09:14:37 --> Router Class Initialized
INFO - 2017-02-14 09:14:37 --> Output Class Initialized
INFO - 2017-02-14 09:14:37 --> Security Class Initialized
DEBUG - 2017-02-14 09:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:14:37 --> Input Class Initialized
INFO - 2017-02-14 09:14:37 --> Language Class Initialized
INFO - 2017-02-14 09:14:37 --> Loader Class Initialized
INFO - 2017-02-14 09:14:37 --> Helper loaded: url_helper
INFO - 2017-02-14 09:14:37 --> Helper loaded: language_helper
INFO - 2017-02-14 09:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:14:37 --> Controller Class Initialized
INFO - 2017-02-14 09:14:37 --> Database Driver Class Initialized
INFO - 2017-02-14 09:14:37 --> Model Class Initialized
INFO - 2017-02-14 09:14:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:14:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-14 09:14:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-14 09:14:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-14 09:14:37 --> Final output sent to browser
DEBUG - 2017-02-14 09:14:37 --> Total execution time: 0.0658
INFO - 2017-02-14 09:14:40 --> Config Class Initialized
INFO - 2017-02-14 09:14:40 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:14:40 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:14:40 --> Utf8 Class Initialized
INFO - 2017-02-14 09:14:40 --> URI Class Initialized
INFO - 2017-02-14 09:14:40 --> Router Class Initialized
INFO - 2017-02-14 09:14:40 --> Output Class Initialized
INFO - 2017-02-14 09:14:40 --> Security Class Initialized
DEBUG - 2017-02-14 09:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:14:40 --> Input Class Initialized
INFO - 2017-02-14 09:14:40 --> Language Class Initialized
INFO - 2017-02-14 09:14:40 --> Loader Class Initialized
INFO - 2017-02-14 09:14:40 --> Helper loaded: url_helper
INFO - 2017-02-14 09:14:40 --> Helper loaded: language_helper
INFO - 2017-02-14 09:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:14:40 --> Controller Class Initialized
INFO - 2017-02-14 09:14:40 --> Database Driver Class Initialized
INFO - 2017-02-14 09:14:40 --> Model Class Initialized
INFO - 2017-02-14 09:14:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:14:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:14:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:14:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:14:40 --> Final output sent to browser
DEBUG - 2017-02-14 09:14:40 --> Total execution time: 0.0695
INFO - 2017-02-14 09:15:08 --> Config Class Initialized
INFO - 2017-02-14 09:15:08 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:15:08 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:15:08 --> Utf8 Class Initialized
INFO - 2017-02-14 09:15:08 --> URI Class Initialized
INFO - 2017-02-14 09:15:08 --> Router Class Initialized
INFO - 2017-02-14 09:15:08 --> Output Class Initialized
INFO - 2017-02-14 09:15:08 --> Security Class Initialized
DEBUG - 2017-02-14 09:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:15:08 --> Input Class Initialized
INFO - 2017-02-14 09:15:08 --> Language Class Initialized
INFO - 2017-02-14 09:15:08 --> Loader Class Initialized
INFO - 2017-02-14 09:15:08 --> Helper loaded: url_helper
INFO - 2017-02-14 09:15:08 --> Helper loaded: language_helper
INFO - 2017-02-14 09:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:15:08 --> Controller Class Initialized
INFO - 2017-02-14 09:15:08 --> Database Driver Class Initialized
INFO - 2017-02-14 09:15:08 --> Model Class Initialized
INFO - 2017-02-14 09:15:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:15:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:15:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:15:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:15:08 --> Final output sent to browser
DEBUG - 2017-02-14 09:15:08 --> Total execution time: 0.0648
INFO - 2017-02-14 09:15:40 --> Config Class Initialized
INFO - 2017-02-14 09:15:40 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:15:40 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:15:40 --> Utf8 Class Initialized
INFO - 2017-02-14 09:15:40 --> URI Class Initialized
INFO - 2017-02-14 09:15:40 --> Router Class Initialized
INFO - 2017-02-14 09:15:40 --> Output Class Initialized
INFO - 2017-02-14 09:15:40 --> Security Class Initialized
DEBUG - 2017-02-14 09:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:15:40 --> Input Class Initialized
INFO - 2017-02-14 09:15:40 --> Language Class Initialized
INFO - 2017-02-14 09:15:40 --> Loader Class Initialized
INFO - 2017-02-14 09:15:40 --> Helper loaded: url_helper
INFO - 2017-02-14 09:15:40 --> Helper loaded: language_helper
INFO - 2017-02-14 09:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:15:40 --> Controller Class Initialized
INFO - 2017-02-14 09:15:40 --> Database Driver Class Initialized
INFO - 2017-02-14 09:15:40 --> Model Class Initialized
INFO - 2017-02-14 09:15:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:15:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:15:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:15:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:15:40 --> Final output sent to browser
DEBUG - 2017-02-14 09:15:40 --> Total execution time: 0.0649
INFO - 2017-02-14 09:16:20 --> Config Class Initialized
INFO - 2017-02-14 09:16:20 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:16:20 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:16:20 --> Utf8 Class Initialized
INFO - 2017-02-14 09:16:20 --> URI Class Initialized
INFO - 2017-02-14 09:16:20 --> Router Class Initialized
INFO - 2017-02-14 09:16:20 --> Output Class Initialized
INFO - 2017-02-14 09:16:20 --> Security Class Initialized
DEBUG - 2017-02-14 09:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:16:20 --> Input Class Initialized
INFO - 2017-02-14 09:16:20 --> Language Class Initialized
INFO - 2017-02-14 09:16:20 --> Loader Class Initialized
INFO - 2017-02-14 09:16:20 --> Helper loaded: url_helper
INFO - 2017-02-14 09:16:20 --> Helper loaded: language_helper
INFO - 2017-02-14 09:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:16:20 --> Controller Class Initialized
INFO - 2017-02-14 09:16:20 --> Database Driver Class Initialized
INFO - 2017-02-14 09:16:20 --> Model Class Initialized
INFO - 2017-02-14 09:16:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:16:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:16:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:16:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:16:20 --> Final output sent to browser
DEBUG - 2017-02-14 09:16:20 --> Total execution time: 0.0603
INFO - 2017-02-14 09:17:19 --> Config Class Initialized
INFO - 2017-02-14 09:17:19 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:17:19 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:17:19 --> Utf8 Class Initialized
INFO - 2017-02-14 09:17:19 --> URI Class Initialized
INFO - 2017-02-14 09:17:19 --> Router Class Initialized
INFO - 2017-02-14 09:17:19 --> Output Class Initialized
INFO - 2017-02-14 09:17:19 --> Security Class Initialized
DEBUG - 2017-02-14 09:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:17:19 --> Input Class Initialized
INFO - 2017-02-14 09:17:19 --> Language Class Initialized
INFO - 2017-02-14 09:17:19 --> Loader Class Initialized
INFO - 2017-02-14 09:17:19 --> Helper loaded: url_helper
INFO - 2017-02-14 09:17:19 --> Helper loaded: language_helper
INFO - 2017-02-14 09:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:17:19 --> Controller Class Initialized
INFO - 2017-02-14 09:17:19 --> Database Driver Class Initialized
INFO - 2017-02-14 09:17:19 --> Model Class Initialized
INFO - 2017-02-14 09:17:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:17:19 --> Final output sent to browser
DEBUG - 2017-02-14 09:17:19 --> Total execution time: 0.0642
INFO - 2017-02-14 09:23:18 --> Config Class Initialized
INFO - 2017-02-14 09:23:18 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:23:18 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:23:18 --> Utf8 Class Initialized
INFO - 2017-02-14 09:23:18 --> URI Class Initialized
INFO - 2017-02-14 09:23:18 --> Router Class Initialized
INFO - 2017-02-14 09:23:18 --> Output Class Initialized
INFO - 2017-02-14 09:23:18 --> Security Class Initialized
DEBUG - 2017-02-14 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:23:18 --> Input Class Initialized
INFO - 2017-02-14 09:23:18 --> Language Class Initialized
INFO - 2017-02-14 09:23:18 --> Loader Class Initialized
INFO - 2017-02-14 09:23:18 --> Helper loaded: url_helper
INFO - 2017-02-14 09:23:18 --> Helper loaded: language_helper
INFO - 2017-02-14 09:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:23:18 --> Controller Class Initialized
INFO - 2017-02-14 09:23:18 --> Database Driver Class Initialized
INFO - 2017-02-14 09:23:18 --> Model Class Initialized
INFO - 2017-02-14 09:23:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:23:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:23:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:23:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:23:18 --> Final output sent to browser
DEBUG - 2017-02-14 09:23:18 --> Total execution time: 0.0614
INFO - 2017-02-14 09:26:12 --> Config Class Initialized
INFO - 2017-02-14 09:26:12 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:26:12 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:26:12 --> Utf8 Class Initialized
INFO - 2017-02-14 09:26:12 --> URI Class Initialized
INFO - 2017-02-14 09:26:12 --> Router Class Initialized
INFO - 2017-02-14 09:26:12 --> Output Class Initialized
INFO - 2017-02-14 09:26:12 --> Security Class Initialized
DEBUG - 2017-02-14 09:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:26:12 --> Input Class Initialized
INFO - 2017-02-14 09:26:12 --> Language Class Initialized
INFO - 2017-02-14 09:26:12 --> Loader Class Initialized
INFO - 2017-02-14 09:26:12 --> Helper loaded: url_helper
INFO - 2017-02-14 09:26:12 --> Helper loaded: language_helper
INFO - 2017-02-14 09:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:26:12 --> Controller Class Initialized
INFO - 2017-02-14 09:26:12 --> Database Driver Class Initialized
INFO - 2017-02-14 09:26:12 --> Model Class Initialized
INFO - 2017-02-14 09:26:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:26:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:26:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:26:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:26:12 --> Final output sent to browser
DEBUG - 2017-02-14 09:26:12 --> Total execution time: 0.0661
INFO - 2017-02-14 09:26:31 --> Config Class Initialized
INFO - 2017-02-14 09:26:31 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:26:31 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:26:31 --> Utf8 Class Initialized
INFO - 2017-02-14 09:26:31 --> URI Class Initialized
INFO - 2017-02-14 09:26:31 --> Router Class Initialized
INFO - 2017-02-14 09:26:31 --> Output Class Initialized
INFO - 2017-02-14 09:26:31 --> Security Class Initialized
DEBUG - 2017-02-14 09:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:26:31 --> Input Class Initialized
INFO - 2017-02-14 09:26:31 --> Language Class Initialized
INFO - 2017-02-14 09:26:31 --> Loader Class Initialized
INFO - 2017-02-14 09:26:31 --> Helper loaded: url_helper
INFO - 2017-02-14 09:26:31 --> Helper loaded: language_helper
INFO - 2017-02-14 09:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:26:31 --> Controller Class Initialized
INFO - 2017-02-14 09:26:31 --> Database Driver Class Initialized
INFO - 2017-02-14 09:26:31 --> Model Class Initialized
INFO - 2017-02-14 09:26:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:26:31 --> Final output sent to browser
DEBUG - 2017-02-14 09:26:31 --> Total execution time: 0.0680
INFO - 2017-02-14 09:26:31 --> Config Class Initialized
INFO - 2017-02-14 09:26:31 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:26:31 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:26:31 --> Utf8 Class Initialized
INFO - 2017-02-14 09:26:31 --> URI Class Initialized
INFO - 2017-02-14 09:26:31 --> Router Class Initialized
INFO - 2017-02-14 09:26:31 --> Output Class Initialized
INFO - 2017-02-14 09:26:31 --> Security Class Initialized
DEBUG - 2017-02-14 09:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:26:31 --> Input Class Initialized
INFO - 2017-02-14 09:26:31 --> Language Class Initialized
INFO - 2017-02-14 09:26:31 --> Loader Class Initialized
INFO - 2017-02-14 09:26:31 --> Helper loaded: url_helper
INFO - 2017-02-14 09:26:31 --> Helper loaded: language_helper
INFO - 2017-02-14 09:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:26:31 --> Controller Class Initialized
INFO - 2017-02-14 09:26:31 --> Database Driver Class Initialized
INFO - 2017-02-14 09:26:31 --> Model Class Initialized
INFO - 2017-02-14 09:26:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:26:31 --> Final output sent to browser
DEBUG - 2017-02-14 09:26:31 --> Total execution time: 0.0654
INFO - 2017-02-14 09:27:00 --> Config Class Initialized
INFO - 2017-02-14 09:27:00 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:27:00 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:27:00 --> Utf8 Class Initialized
INFO - 2017-02-14 09:27:00 --> URI Class Initialized
INFO - 2017-02-14 09:27:00 --> Router Class Initialized
INFO - 2017-02-14 09:27:00 --> Output Class Initialized
INFO - 2017-02-14 09:27:00 --> Security Class Initialized
DEBUG - 2017-02-14 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:27:00 --> Input Class Initialized
INFO - 2017-02-14 09:27:00 --> Language Class Initialized
INFO - 2017-02-14 09:27:00 --> Loader Class Initialized
INFO - 2017-02-14 09:27:00 --> Helper loaded: url_helper
INFO - 2017-02-14 09:27:00 --> Helper loaded: language_helper
INFO - 2017-02-14 09:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:27:00 --> Controller Class Initialized
INFO - 2017-02-14 09:27:00 --> Database Driver Class Initialized
INFO - 2017-02-14 09:27:00 --> Model Class Initialized
INFO - 2017-02-14 09:27:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:27:00 --> Config Class Initialized
INFO - 2017-02-14 09:27:00 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:27:00 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:27:00 --> Utf8 Class Initialized
INFO - 2017-02-14 09:27:00 --> URI Class Initialized
INFO - 2017-02-14 09:27:00 --> Router Class Initialized
INFO - 2017-02-14 09:27:00 --> Output Class Initialized
INFO - 2017-02-14 09:27:00 --> Security Class Initialized
DEBUG - 2017-02-14 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:27:00 --> Input Class Initialized
INFO - 2017-02-14 09:27:00 --> Language Class Initialized
INFO - 2017-02-14 09:27:00 --> Loader Class Initialized
INFO - 2017-02-14 09:27:00 --> Helper loaded: url_helper
INFO - 2017-02-14 09:27:00 --> Helper loaded: language_helper
INFO - 2017-02-14 09:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:27:00 --> Controller Class Initialized
INFO - 2017-02-14 09:27:00 --> Database Driver Class Initialized
INFO - 2017-02-14 09:27:00 --> Model Class Initialized
INFO - 2017-02-14 09:27:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:27:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:27:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-14 09:27:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:27:01 --> Final output sent to browser
DEBUG - 2017-02-14 09:27:01 --> Total execution time: 0.0733
INFO - 2017-02-14 09:27:31 --> Config Class Initialized
INFO - 2017-02-14 09:27:31 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:27:31 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:27:31 --> Utf8 Class Initialized
INFO - 2017-02-14 09:27:31 --> URI Class Initialized
INFO - 2017-02-14 09:27:31 --> Router Class Initialized
INFO - 2017-02-14 09:27:31 --> Output Class Initialized
INFO - 2017-02-14 09:27:31 --> Security Class Initialized
DEBUG - 2017-02-14 09:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:27:31 --> Input Class Initialized
INFO - 2017-02-14 09:27:31 --> Language Class Initialized
INFO - 2017-02-14 09:27:31 --> Loader Class Initialized
INFO - 2017-02-14 09:27:31 --> Helper loaded: url_helper
INFO - 2017-02-14 09:27:31 --> Helper loaded: language_helper
INFO - 2017-02-14 09:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:27:32 --> Controller Class Initialized
INFO - 2017-02-14 09:27:32 --> Database Driver Class Initialized
INFO - 2017-02-14 09:27:32 --> Model Class Initialized
INFO - 2017-02-14 09:27:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:27:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:27:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-14 09:27:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:27:32 --> Final output sent to browser
DEBUG - 2017-02-14 09:27:32 --> Total execution time: 0.0630
INFO - 2017-02-14 09:34:49 --> Config Class Initialized
INFO - 2017-02-14 09:34:49 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:34:49 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:34:49 --> Utf8 Class Initialized
INFO - 2017-02-14 09:34:49 --> URI Class Initialized
INFO - 2017-02-14 09:34:49 --> Router Class Initialized
INFO - 2017-02-14 09:34:49 --> Output Class Initialized
INFO - 2017-02-14 09:34:49 --> Security Class Initialized
DEBUG - 2017-02-14 09:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:34:49 --> Input Class Initialized
INFO - 2017-02-14 09:34:49 --> Language Class Initialized
INFO - 2017-02-14 09:34:49 --> Loader Class Initialized
INFO - 2017-02-14 09:34:49 --> Helper loaded: url_helper
INFO - 2017-02-14 09:34:49 --> Helper loaded: language_helper
INFO - 2017-02-14 09:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:34:49 --> Controller Class Initialized
INFO - 2017-02-14 09:34:49 --> Database Driver Class Initialized
INFO - 2017-02-14 09:34:49 --> Model Class Initialized
INFO - 2017-02-14 09:34:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:34:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-14 09:34:49 --> Severity: Error --> Call to undefined function validation_errors() C:\wamp64\www\savsoftquiz\application\views\register_new.php 4
INFO - 2017-02-14 09:38:47 --> Config Class Initialized
INFO - 2017-02-14 09:38:47 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:38:47 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:38:47 --> Utf8 Class Initialized
INFO - 2017-02-14 09:38:47 --> URI Class Initialized
INFO - 2017-02-14 09:38:47 --> Router Class Initialized
INFO - 2017-02-14 09:38:47 --> Output Class Initialized
INFO - 2017-02-14 09:38:47 --> Security Class Initialized
DEBUG - 2017-02-14 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:38:47 --> Input Class Initialized
INFO - 2017-02-14 09:38:47 --> Language Class Initialized
INFO - 2017-02-14 09:38:47 --> Loader Class Initialized
INFO - 2017-02-14 09:38:47 --> Helper loaded: url_helper
INFO - 2017-02-14 09:38:47 --> Helper loaded: language_helper
INFO - 2017-02-14 09:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:38:47 --> Controller Class Initialized
INFO - 2017-02-14 09:38:47 --> Database Driver Class Initialized
INFO - 2017-02-14 09:38:47 --> Model Class Initialized
INFO - 2017-02-14 09:38:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:38:47 --> Helper loaded: form_helper
INFO - 2017-02-14 09:38:47 --> Form Validation Class Initialized
INFO - 2017-02-14 09:38:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:38:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:38:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:38:47 --> Final output sent to browser
DEBUG - 2017-02-14 09:38:47 --> Total execution time: 0.0791
INFO - 2017-02-14 09:39:22 --> Config Class Initialized
INFO - 2017-02-14 09:39:22 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:39:22 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:39:22 --> Utf8 Class Initialized
INFO - 2017-02-14 09:39:22 --> URI Class Initialized
INFO - 2017-02-14 09:39:22 --> Router Class Initialized
INFO - 2017-02-14 09:39:22 --> Output Class Initialized
INFO - 2017-02-14 09:39:22 --> Security Class Initialized
DEBUG - 2017-02-14 09:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:39:22 --> Input Class Initialized
INFO - 2017-02-14 09:39:22 --> Language Class Initialized
ERROR - 2017-02-14 09:39:22 --> 404 Page Not Found: Form/index
INFO - 2017-02-14 09:39:44 --> Config Class Initialized
INFO - 2017-02-14 09:39:44 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:39:44 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:39:44 --> Utf8 Class Initialized
INFO - 2017-02-14 09:39:44 --> URI Class Initialized
INFO - 2017-02-14 09:39:44 --> Router Class Initialized
INFO - 2017-02-14 09:39:44 --> Output Class Initialized
INFO - 2017-02-14 09:39:44 --> Security Class Initialized
DEBUG - 2017-02-14 09:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:39:44 --> Input Class Initialized
INFO - 2017-02-14 09:39:44 --> Language Class Initialized
INFO - 2017-02-14 09:39:44 --> Loader Class Initialized
INFO - 2017-02-14 09:39:44 --> Helper loaded: url_helper
INFO - 2017-02-14 09:39:44 --> Helper loaded: language_helper
INFO - 2017-02-14 09:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:39:44 --> Controller Class Initialized
INFO - 2017-02-14 09:39:44 --> Database Driver Class Initialized
INFO - 2017-02-14 09:39:44 --> Model Class Initialized
INFO - 2017-02-14 09:39:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:39:44 --> Helper loaded: form_helper
INFO - 2017-02-14 09:39:44 --> Form Validation Class Initialized
INFO - 2017-02-14 09:39:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:39:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:39:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:39:44 --> Final output sent to browser
DEBUG - 2017-02-14 09:39:44 --> Total execution time: 0.0800
INFO - 2017-02-14 09:40:11 --> Config Class Initialized
INFO - 2017-02-14 09:40:11 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:40:11 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:40:11 --> Utf8 Class Initialized
INFO - 2017-02-14 09:40:11 --> URI Class Initialized
INFO - 2017-02-14 09:40:11 --> Router Class Initialized
INFO - 2017-02-14 09:40:11 --> Output Class Initialized
INFO - 2017-02-14 09:40:11 --> Security Class Initialized
DEBUG - 2017-02-14 09:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:40:11 --> Input Class Initialized
INFO - 2017-02-14 09:40:11 --> Language Class Initialized
INFO - 2017-02-14 09:40:11 --> Loader Class Initialized
INFO - 2017-02-14 09:40:11 --> Helper loaded: url_helper
INFO - 2017-02-14 09:40:11 --> Helper loaded: language_helper
INFO - 2017-02-14 09:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:40:11 --> Controller Class Initialized
INFO - 2017-02-14 09:40:11 --> Database Driver Class Initialized
INFO - 2017-02-14 09:40:11 --> Model Class Initialized
INFO - 2017-02-14 09:40:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:40:11 --> Helper loaded: form_helper
INFO - 2017-02-14 09:40:11 --> Form Validation Class Initialized
INFO - 2017-02-14 09:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:40:11 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 09:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-14 09:40:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:40:11 --> Final output sent to browser
DEBUG - 2017-02-14 09:40:11 --> Total execution time: 0.0787
INFO - 2017-02-14 09:46:34 --> Config Class Initialized
INFO - 2017-02-14 09:46:34 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:46:34 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:46:34 --> Utf8 Class Initialized
INFO - 2017-02-14 09:46:34 --> URI Class Initialized
INFO - 2017-02-14 09:46:34 --> Router Class Initialized
INFO - 2017-02-14 09:46:34 --> Output Class Initialized
INFO - 2017-02-14 09:46:34 --> Security Class Initialized
DEBUG - 2017-02-14 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:46:34 --> Input Class Initialized
INFO - 2017-02-14 09:46:34 --> Language Class Initialized
INFO - 2017-02-14 09:46:34 --> Loader Class Initialized
INFO - 2017-02-14 09:46:34 --> Helper loaded: url_helper
INFO - 2017-02-14 09:46:34 --> Helper loaded: language_helper
INFO - 2017-02-14 09:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:46:34 --> Controller Class Initialized
INFO - 2017-02-14 09:46:34 --> Database Driver Class Initialized
INFO - 2017-02-14 09:46:34 --> Model Class Initialized
INFO - 2017-02-14 09:46:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:46:34 --> Helper loaded: form_helper
INFO - 2017-02-14 09:46:34 --> Form Validation Class Initialized
INFO - 2017-02-14 09:46:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:46:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:46:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:46:34 --> Final output sent to browser
DEBUG - 2017-02-14 09:46:34 --> Total execution time: 0.0669
INFO - 2017-02-14 09:49:00 --> Config Class Initialized
INFO - 2017-02-14 09:49:00 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:49:00 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:49:00 --> Utf8 Class Initialized
INFO - 2017-02-14 09:49:00 --> URI Class Initialized
INFO - 2017-02-14 09:49:00 --> Router Class Initialized
INFO - 2017-02-14 09:49:00 --> Output Class Initialized
INFO - 2017-02-14 09:49:00 --> Security Class Initialized
DEBUG - 2017-02-14 09:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:49:00 --> Input Class Initialized
INFO - 2017-02-14 09:49:00 --> Language Class Initialized
INFO - 2017-02-14 09:49:00 --> Loader Class Initialized
INFO - 2017-02-14 09:49:00 --> Helper loaded: url_helper
INFO - 2017-02-14 09:49:00 --> Helper loaded: language_helper
INFO - 2017-02-14 09:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:49:00 --> Controller Class Initialized
INFO - 2017-02-14 09:49:00 --> Database Driver Class Initialized
INFO - 2017-02-14 09:49:00 --> Model Class Initialized
INFO - 2017-02-14 09:49:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:49:00 --> Helper loaded: form_helper
INFO - 2017-02-14 09:49:00 --> Form Validation Class Initialized
INFO - 2017-02-14 09:49:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:49:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 09:49:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:49:00 --> Final output sent to browser
DEBUG - 2017-02-14 09:49:00 --> Total execution time: 0.0782
INFO - 2017-02-14 09:49:30 --> Config Class Initialized
INFO - 2017-02-14 09:49:30 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:49:30 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:49:30 --> Utf8 Class Initialized
INFO - 2017-02-14 09:49:30 --> URI Class Initialized
INFO - 2017-02-14 09:49:30 --> Router Class Initialized
INFO - 2017-02-14 09:49:30 --> Output Class Initialized
INFO - 2017-02-14 09:49:30 --> Security Class Initialized
DEBUG - 2017-02-14 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:49:30 --> Input Class Initialized
INFO - 2017-02-14 09:49:30 --> Language Class Initialized
INFO - 2017-02-14 09:49:30 --> Loader Class Initialized
INFO - 2017-02-14 09:49:30 --> Helper loaded: url_helper
INFO - 2017-02-14 09:49:30 --> Helper loaded: language_helper
INFO - 2017-02-14 09:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:49:30 --> Controller Class Initialized
INFO - 2017-02-14 09:49:30 --> Database Driver Class Initialized
INFO - 2017-02-14 09:49:30 --> Model Class Initialized
INFO - 2017-02-14 09:49:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:49:30 --> Helper loaded: form_helper
INFO - 2017-02-14 09:49:30 --> Form Validation Class Initialized
INFO - 2017-02-14 09:49:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:49:30 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 09:49:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-14 09:49:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:49:30 --> Final output sent to browser
DEBUG - 2017-02-14 09:49:30 --> Total execution time: 0.0803
INFO - 2017-02-14 09:49:45 --> Config Class Initialized
INFO - 2017-02-14 09:49:45 --> Hooks Class Initialized
DEBUG - 2017-02-14 09:49:45 --> UTF-8 Support Enabled
INFO - 2017-02-14 09:49:45 --> Utf8 Class Initialized
INFO - 2017-02-14 09:49:45 --> URI Class Initialized
INFO - 2017-02-14 09:49:45 --> Router Class Initialized
INFO - 2017-02-14 09:49:45 --> Output Class Initialized
INFO - 2017-02-14 09:49:45 --> Security Class Initialized
DEBUG - 2017-02-14 09:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 09:49:45 --> Input Class Initialized
INFO - 2017-02-14 09:49:45 --> Language Class Initialized
INFO - 2017-02-14 09:49:45 --> Loader Class Initialized
INFO - 2017-02-14 09:49:45 --> Helper loaded: url_helper
INFO - 2017-02-14 09:49:45 --> Helper loaded: language_helper
INFO - 2017-02-14 09:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 09:49:45 --> Controller Class Initialized
INFO - 2017-02-14 09:49:45 --> Database Driver Class Initialized
INFO - 2017-02-14 09:49:45 --> Model Class Initialized
INFO - 2017-02-14 09:49:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 09:49:45 --> Helper loaded: form_helper
INFO - 2017-02-14 09:49:45 --> Form Validation Class Initialized
INFO - 2017-02-14 09:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 09:49:45 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 09:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-14 09:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 09:49:45 --> Final output sent to browser
DEBUG - 2017-02-14 09:49:45 --> Total execution time: 0.0705
INFO - 2017-02-14 11:22:07 --> Config Class Initialized
INFO - 2017-02-14 11:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:22:07 --> Utf8 Class Initialized
INFO - 2017-02-14 11:22:07 --> URI Class Initialized
INFO - 2017-02-14 11:22:07 --> Router Class Initialized
INFO - 2017-02-14 11:22:07 --> Output Class Initialized
INFO - 2017-02-14 11:22:07 --> Security Class Initialized
DEBUG - 2017-02-14 11:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:22:07 --> Input Class Initialized
INFO - 2017-02-14 11:22:07 --> Language Class Initialized
INFO - 2017-02-14 11:22:07 --> Loader Class Initialized
INFO - 2017-02-14 11:22:07 --> Helper loaded: url_helper
INFO - 2017-02-14 11:22:07 --> Helper loaded: language_helper
INFO - 2017-02-14 11:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:22:07 --> Controller Class Initialized
INFO - 2017-02-14 11:22:07 --> Database Driver Class Initialized
INFO - 2017-02-14 11:22:07 --> Model Class Initialized
INFO - 2017-02-14 11:22:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:22:07 --> Helper loaded: form_helper
INFO - 2017-02-14 11:22:07 --> Form Validation Class Initialized
INFO - 2017-02-14 11:22:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:22:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:22:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:22:07 --> Final output sent to browser
DEBUG - 2017-02-14 11:22:07 --> Total execution time: 0.0655
INFO - 2017-02-14 11:24:07 --> Config Class Initialized
INFO - 2017-02-14 11:24:07 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:24:07 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:24:07 --> Utf8 Class Initialized
INFO - 2017-02-14 11:24:07 --> URI Class Initialized
INFO - 2017-02-14 11:24:07 --> Router Class Initialized
INFO - 2017-02-14 11:24:07 --> Output Class Initialized
INFO - 2017-02-14 11:24:07 --> Security Class Initialized
DEBUG - 2017-02-14 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:24:07 --> Input Class Initialized
INFO - 2017-02-14 11:24:07 --> Language Class Initialized
INFO - 2017-02-14 11:24:07 --> Loader Class Initialized
INFO - 2017-02-14 11:24:07 --> Helper loaded: url_helper
INFO - 2017-02-14 11:24:07 --> Helper loaded: language_helper
INFO - 2017-02-14 11:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:24:07 --> Controller Class Initialized
INFO - 2017-02-14 11:24:07 --> Database Driver Class Initialized
INFO - 2017-02-14 11:24:07 --> Model Class Initialized
INFO - 2017-02-14 11:24:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:24:07 --> Helper loaded: form_helper
INFO - 2017-02-14 11:24:07 --> Form Validation Class Initialized
INFO - 2017-02-14 11:24:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:24:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:24:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:24:07 --> Final output sent to browser
DEBUG - 2017-02-14 11:24:07 --> Total execution time: 0.0697
INFO - 2017-02-14 11:24:09 --> Config Class Initialized
INFO - 2017-02-14 11:24:09 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:24:09 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:24:09 --> Utf8 Class Initialized
INFO - 2017-02-14 11:24:09 --> URI Class Initialized
INFO - 2017-02-14 11:24:09 --> Router Class Initialized
INFO - 2017-02-14 11:24:09 --> Output Class Initialized
INFO - 2017-02-14 11:24:09 --> Security Class Initialized
DEBUG - 2017-02-14 11:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:24:09 --> Input Class Initialized
INFO - 2017-02-14 11:24:09 --> Language Class Initialized
INFO - 2017-02-14 11:24:09 --> Loader Class Initialized
INFO - 2017-02-14 11:24:09 --> Helper loaded: url_helper
INFO - 2017-02-14 11:24:09 --> Helper loaded: language_helper
INFO - 2017-02-14 11:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:24:09 --> Controller Class Initialized
INFO - 2017-02-14 11:24:09 --> Database Driver Class Initialized
INFO - 2017-02-14 11:24:09 --> Model Class Initialized
INFO - 2017-02-14 11:24:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:24:09 --> Helper loaded: form_helper
INFO - 2017-02-14 11:24:09 --> Form Validation Class Initialized
INFO - 2017-02-14 11:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:24:09 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 11:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:24:09 --> Config Class Initialized
INFO - 2017-02-14 11:24:09 --> Final output sent to browser
INFO - 2017-02-14 11:24:09 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:24:09 --> Total execution time: 0.1055
DEBUG - 2017-02-14 11:24:09 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:24:09 --> Utf8 Class Initialized
INFO - 2017-02-14 11:24:09 --> URI Class Initialized
INFO - 2017-02-14 11:24:09 --> Router Class Initialized
INFO - 2017-02-14 11:24:09 --> Output Class Initialized
INFO - 2017-02-14 11:24:09 --> Security Class Initialized
DEBUG - 2017-02-14 11:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:24:09 --> Input Class Initialized
INFO - 2017-02-14 11:24:09 --> Language Class Initialized
INFO - 2017-02-14 11:24:09 --> Loader Class Initialized
INFO - 2017-02-14 11:24:09 --> Helper loaded: url_helper
INFO - 2017-02-14 11:24:09 --> Helper loaded: language_helper
INFO - 2017-02-14 11:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:24:09 --> Controller Class Initialized
INFO - 2017-02-14 11:24:09 --> Database Driver Class Initialized
INFO - 2017-02-14 11:24:09 --> Model Class Initialized
INFO - 2017-02-14 11:24:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:24:09 --> Helper loaded: form_helper
INFO - 2017-02-14 11:24:09 --> Form Validation Class Initialized
INFO - 2017-02-14 11:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:24:09 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 11:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:24:09 --> Final output sent to browser
DEBUG - 2017-02-14 11:24:09 --> Total execution time: 0.0894
INFO - 2017-02-14 11:24:33 --> Config Class Initialized
INFO - 2017-02-14 11:24:33 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:24:33 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:24:33 --> Utf8 Class Initialized
INFO - 2017-02-14 11:24:33 --> URI Class Initialized
INFO - 2017-02-14 11:24:33 --> Router Class Initialized
INFO - 2017-02-14 11:24:33 --> Output Class Initialized
INFO - 2017-02-14 11:24:33 --> Security Class Initialized
DEBUG - 2017-02-14 11:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:24:33 --> Input Class Initialized
INFO - 2017-02-14 11:24:33 --> Language Class Initialized
INFO - 2017-02-14 11:24:33 --> Loader Class Initialized
INFO - 2017-02-14 11:24:33 --> Helper loaded: url_helper
INFO - 2017-02-14 11:24:33 --> Helper loaded: language_helper
INFO - 2017-02-14 11:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:24:33 --> Controller Class Initialized
INFO - 2017-02-14 11:24:33 --> Database Driver Class Initialized
INFO - 2017-02-14 11:24:33 --> Model Class Initialized
INFO - 2017-02-14 11:24:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:24:33 --> Helper loaded: form_helper
INFO - 2017-02-14 11:24:33 --> Form Validation Class Initialized
INFO - 2017-02-14 11:24:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:24:33 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 11:24:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:24:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:24:33 --> Final output sent to browser
DEBUG - 2017-02-14 11:24:33 --> Total execution time: 0.0768
INFO - 2017-02-14 11:24:33 --> Config Class Initialized
INFO - 2017-02-14 11:24:33 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:24:33 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:24:33 --> Utf8 Class Initialized
INFO - 2017-02-14 11:24:33 --> URI Class Initialized
INFO - 2017-02-14 11:24:33 --> Router Class Initialized
INFO - 2017-02-14 11:24:33 --> Output Class Initialized
INFO - 2017-02-14 11:24:33 --> Security Class Initialized
DEBUG - 2017-02-14 11:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:24:33 --> Input Class Initialized
INFO - 2017-02-14 11:24:33 --> Language Class Initialized
INFO - 2017-02-14 11:24:33 --> Loader Class Initialized
INFO - 2017-02-14 11:24:33 --> Helper loaded: url_helper
INFO - 2017-02-14 11:24:33 --> Helper loaded: language_helper
INFO - 2017-02-14 11:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:24:33 --> Controller Class Initialized
INFO - 2017-02-14 11:24:33 --> Database Driver Class Initialized
INFO - 2017-02-14 11:24:33 --> Model Class Initialized
INFO - 2017-02-14 11:24:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:24:33 --> Helper loaded: form_helper
INFO - 2017-02-14 11:24:33 --> Form Validation Class Initialized
INFO - 2017-02-14 11:24:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:24:33 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 11:24:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:24:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:24:33 --> Final output sent to browser
DEBUG - 2017-02-14 11:24:33 --> Total execution time: 0.0764
INFO - 2017-02-14 11:25:05 --> Config Class Initialized
INFO - 2017-02-14 11:25:05 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:25:05 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:25:05 --> Utf8 Class Initialized
INFO - 2017-02-14 11:25:05 --> URI Class Initialized
INFO - 2017-02-14 11:25:05 --> Router Class Initialized
INFO - 2017-02-14 11:25:05 --> Output Class Initialized
INFO - 2017-02-14 11:25:05 --> Security Class Initialized
DEBUG - 2017-02-14 11:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:25:05 --> Input Class Initialized
INFO - 2017-02-14 11:25:05 --> Language Class Initialized
INFO - 2017-02-14 11:25:05 --> Loader Class Initialized
INFO - 2017-02-14 11:25:05 --> Helper loaded: url_helper
INFO - 2017-02-14 11:25:05 --> Helper loaded: language_helper
INFO - 2017-02-14 11:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:25:05 --> Controller Class Initialized
INFO - 2017-02-14 11:25:05 --> Database Driver Class Initialized
INFO - 2017-02-14 11:25:05 --> Model Class Initialized
INFO - 2017-02-14 11:25:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:25:05 --> Helper loaded: form_helper
INFO - 2017-02-14 11:25:05 --> Form Validation Class Initialized
INFO - 2017-02-14 11:25:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:25:05 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 11:25:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-14 11:25:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:25:05 --> Final output sent to browser
DEBUG - 2017-02-14 11:25:05 --> Total execution time: 0.0761
INFO - 2017-02-14 11:26:37 --> Config Class Initialized
INFO - 2017-02-14 11:26:37 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:26:37 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:26:37 --> Utf8 Class Initialized
INFO - 2017-02-14 11:26:37 --> URI Class Initialized
INFO - 2017-02-14 11:26:37 --> Router Class Initialized
INFO - 2017-02-14 11:26:37 --> Output Class Initialized
INFO - 2017-02-14 11:26:37 --> Security Class Initialized
DEBUG - 2017-02-14 11:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:26:37 --> Input Class Initialized
INFO - 2017-02-14 11:26:37 --> Language Class Initialized
INFO - 2017-02-14 11:26:37 --> Loader Class Initialized
INFO - 2017-02-14 11:26:37 --> Helper loaded: url_helper
INFO - 2017-02-14 11:26:37 --> Helper loaded: language_helper
INFO - 2017-02-14 11:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:26:37 --> Controller Class Initialized
INFO - 2017-02-14 11:26:37 --> Database Driver Class Initialized
INFO - 2017-02-14 11:26:37 --> Model Class Initialized
INFO - 2017-02-14 11:26:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:26:37 --> Helper loaded: form_helper
INFO - 2017-02-14 11:26:37 --> Form Validation Class Initialized
INFO - 2017-02-14 11:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:26:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:26:37 --> Final output sent to browser
DEBUG - 2017-02-14 11:26:37 --> Total execution time: 0.0654
INFO - 2017-02-14 11:27:06 --> Config Class Initialized
INFO - 2017-02-14 11:27:06 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:27:06 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:27:06 --> Utf8 Class Initialized
INFO - 2017-02-14 11:27:06 --> URI Class Initialized
INFO - 2017-02-14 11:27:06 --> Router Class Initialized
INFO - 2017-02-14 11:27:06 --> Output Class Initialized
INFO - 2017-02-14 11:27:06 --> Security Class Initialized
DEBUG - 2017-02-14 11:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:27:06 --> Input Class Initialized
INFO - 2017-02-14 11:27:06 --> Language Class Initialized
INFO - 2017-02-14 11:27:06 --> Loader Class Initialized
INFO - 2017-02-14 11:27:06 --> Helper loaded: url_helper
INFO - 2017-02-14 11:27:06 --> Helper loaded: language_helper
INFO - 2017-02-14 11:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:27:06 --> Controller Class Initialized
INFO - 2017-02-14 11:27:06 --> Database Driver Class Initialized
INFO - 2017-02-14 11:27:06 --> Model Class Initialized
INFO - 2017-02-14 11:27:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:27:06 --> Helper loaded: form_helper
INFO - 2017-02-14 11:27:06 --> Form Validation Class Initialized
INFO - 2017-02-14 11:27:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:27:06 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 11:27:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:27:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:27:06 --> Final output sent to browser
DEBUG - 2017-02-14 11:27:06 --> Total execution time: 0.0764
INFO - 2017-02-14 11:29:52 --> Config Class Initialized
INFO - 2017-02-14 11:29:52 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:29:52 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:29:52 --> Utf8 Class Initialized
INFO - 2017-02-14 11:29:52 --> URI Class Initialized
INFO - 2017-02-14 11:29:52 --> Router Class Initialized
INFO - 2017-02-14 11:29:52 --> Output Class Initialized
INFO - 2017-02-14 11:29:52 --> Security Class Initialized
DEBUG - 2017-02-14 11:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:29:52 --> Input Class Initialized
INFO - 2017-02-14 11:29:52 --> Language Class Initialized
INFO - 2017-02-14 11:29:52 --> Loader Class Initialized
INFO - 2017-02-14 11:29:52 --> Helper loaded: url_helper
INFO - 2017-02-14 11:29:52 --> Helper loaded: language_helper
INFO - 2017-02-14 11:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:29:52 --> Controller Class Initialized
INFO - 2017-02-14 11:29:52 --> Database Driver Class Initialized
INFO - 2017-02-14 11:29:52 --> Model Class Initialized
INFO - 2017-02-14 11:29:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:29:52 --> Helper loaded: form_helper
INFO - 2017-02-14 11:29:52 --> Form Validation Class Initialized
INFO - 2017-02-14 11:29:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:29:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:29:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:29:52 --> Final output sent to browser
DEBUG - 2017-02-14 11:29:52 --> Total execution time: 0.1801
INFO - 2017-02-14 11:30:34 --> Config Class Initialized
INFO - 2017-02-14 11:30:34 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:30:34 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:30:34 --> Utf8 Class Initialized
INFO - 2017-02-14 11:30:34 --> URI Class Initialized
INFO - 2017-02-14 11:30:34 --> Router Class Initialized
INFO - 2017-02-14 11:30:34 --> Output Class Initialized
INFO - 2017-02-14 11:30:34 --> Security Class Initialized
DEBUG - 2017-02-14 11:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:30:34 --> Input Class Initialized
INFO - 2017-02-14 11:30:34 --> Language Class Initialized
INFO - 2017-02-14 11:30:34 --> Loader Class Initialized
INFO - 2017-02-14 11:30:34 --> Helper loaded: url_helper
INFO - 2017-02-14 11:30:34 --> Helper loaded: language_helper
INFO - 2017-02-14 11:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:30:34 --> Controller Class Initialized
INFO - 2017-02-14 11:30:34 --> Database Driver Class Initialized
INFO - 2017-02-14 11:30:34 --> Model Class Initialized
INFO - 2017-02-14 11:30:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:30:34 --> Helper loaded: form_helper
INFO - 2017-02-14 11:30:34 --> Form Validation Class Initialized
INFO - 2017-02-14 11:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:30:34 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-02-14 11:30:34 --> Unable to find validation rule: number
ERROR - 2017-02-14 11:30:34 --> Could not find the language line "form_validation_number"
INFO - 2017-02-14 11:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:30:34 --> Final output sent to browser
DEBUG - 2017-02-14 11:30:34 --> Total execution time: 0.0895
INFO - 2017-02-14 11:30:34 --> Config Class Initialized
INFO - 2017-02-14 11:30:34 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:30:34 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:30:34 --> Utf8 Class Initialized
INFO - 2017-02-14 11:30:34 --> URI Class Initialized
INFO - 2017-02-14 11:30:34 --> Router Class Initialized
INFO - 2017-02-14 11:30:34 --> Output Class Initialized
INFO - 2017-02-14 11:30:34 --> Security Class Initialized
DEBUG - 2017-02-14 11:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:30:34 --> Input Class Initialized
INFO - 2017-02-14 11:30:34 --> Language Class Initialized
INFO - 2017-02-14 11:30:34 --> Loader Class Initialized
INFO - 2017-02-14 11:30:34 --> Helper loaded: url_helper
INFO - 2017-02-14 11:30:34 --> Helper loaded: language_helper
INFO - 2017-02-14 11:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:30:34 --> Controller Class Initialized
INFO - 2017-02-14 11:30:34 --> Database Driver Class Initialized
INFO - 2017-02-14 11:30:34 --> Model Class Initialized
INFO - 2017-02-14 11:30:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:30:34 --> Helper loaded: form_helper
INFO - 2017-02-14 11:30:34 --> Form Validation Class Initialized
INFO - 2017-02-14 11:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:30:34 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-02-14 11:30:34 --> Unable to find validation rule: number
ERROR - 2017-02-14 11:30:34 --> Could not find the language line "form_validation_number"
INFO - 2017-02-14 11:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:30:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:30:34 --> Final output sent to browser
DEBUG - 2017-02-14 11:30:34 --> Total execution time: 0.0795
INFO - 2017-02-14 11:31:19 --> Config Class Initialized
INFO - 2017-02-14 11:31:19 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:31:19 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:31:19 --> Utf8 Class Initialized
INFO - 2017-02-14 11:31:19 --> URI Class Initialized
INFO - 2017-02-14 11:31:19 --> Router Class Initialized
INFO - 2017-02-14 11:31:19 --> Output Class Initialized
INFO - 2017-02-14 11:31:19 --> Security Class Initialized
DEBUG - 2017-02-14 11:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:31:19 --> Input Class Initialized
INFO - 2017-02-14 11:31:19 --> Language Class Initialized
INFO - 2017-02-14 11:31:19 --> Loader Class Initialized
INFO - 2017-02-14 11:31:19 --> Helper loaded: url_helper
INFO - 2017-02-14 11:31:19 --> Helper loaded: language_helper
INFO - 2017-02-14 11:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:31:19 --> Controller Class Initialized
INFO - 2017-02-14 11:31:19 --> Database Driver Class Initialized
INFO - 2017-02-14 11:31:19 --> Model Class Initialized
INFO - 2017-02-14 11:31:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:31:19 --> Helper loaded: form_helper
INFO - 2017-02-14 11:31:19 --> Form Validation Class Initialized
INFO - 2017-02-14 11:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:31:19 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-02-14 11:31:19 --> Unable to find validation rule: number
ERROR - 2017-02-14 11:31:19 --> Could not find the language line "form_validation_number"
INFO - 2017-02-14 11:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:31:19 --> Final output sent to browser
DEBUG - 2017-02-14 11:31:19 --> Total execution time: 0.0743
INFO - 2017-02-14 11:31:19 --> Config Class Initialized
INFO - 2017-02-14 11:31:19 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:31:19 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:31:19 --> Utf8 Class Initialized
INFO - 2017-02-14 11:31:19 --> URI Class Initialized
INFO - 2017-02-14 11:31:19 --> Router Class Initialized
INFO - 2017-02-14 11:31:19 --> Output Class Initialized
INFO - 2017-02-14 11:31:19 --> Security Class Initialized
DEBUG - 2017-02-14 11:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:31:19 --> Input Class Initialized
INFO - 2017-02-14 11:31:19 --> Language Class Initialized
INFO - 2017-02-14 11:31:19 --> Loader Class Initialized
INFO - 2017-02-14 11:31:19 --> Helper loaded: url_helper
INFO - 2017-02-14 11:31:19 --> Helper loaded: language_helper
INFO - 2017-02-14 11:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:31:19 --> Controller Class Initialized
INFO - 2017-02-14 11:31:19 --> Database Driver Class Initialized
INFO - 2017-02-14 11:31:19 --> Model Class Initialized
INFO - 2017-02-14 11:31:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:31:19 --> Helper loaded: form_helper
INFO - 2017-02-14 11:31:19 --> Form Validation Class Initialized
INFO - 2017-02-14 11:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:31:19 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-02-14 11:31:19 --> Unable to find validation rule: number
ERROR - 2017-02-14 11:31:19 --> Could not find the language line "form_validation_number"
INFO - 2017-02-14 11:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:31:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:31:19 --> Final output sent to browser
DEBUG - 2017-02-14 11:31:19 --> Total execution time: 0.0873
INFO - 2017-02-14 11:32:44 --> Config Class Initialized
INFO - 2017-02-14 11:32:44 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:32:44 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:32:44 --> Utf8 Class Initialized
INFO - 2017-02-14 11:32:44 --> URI Class Initialized
INFO - 2017-02-14 11:32:44 --> Router Class Initialized
INFO - 2017-02-14 11:32:44 --> Output Class Initialized
INFO - 2017-02-14 11:32:44 --> Security Class Initialized
DEBUG - 2017-02-14 11:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:32:44 --> Input Class Initialized
INFO - 2017-02-14 11:32:44 --> Language Class Initialized
INFO - 2017-02-14 11:32:44 --> Loader Class Initialized
INFO - 2017-02-14 11:32:44 --> Helper loaded: url_helper
INFO - 2017-02-14 11:32:44 --> Helper loaded: language_helper
INFO - 2017-02-14 11:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:32:44 --> Controller Class Initialized
INFO - 2017-02-14 11:32:44 --> Database Driver Class Initialized
INFO - 2017-02-14 11:32:44 --> Model Class Initialized
INFO - 2017-02-14 11:32:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:32:44 --> Helper loaded: form_helper
INFO - 2017-02-14 11:32:44 --> Form Validation Class Initialized
INFO - 2017-02-14 11:32:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:32:44 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 11:32:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:32:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:32:44 --> Final output sent to browser
DEBUG - 2017-02-14 11:32:44 --> Total execution time: 0.0804
INFO - 2017-02-14 11:33:25 --> Config Class Initialized
INFO - 2017-02-14 11:33:25 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:33:25 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:33:25 --> Utf8 Class Initialized
INFO - 2017-02-14 11:33:25 --> URI Class Initialized
INFO - 2017-02-14 11:33:25 --> Router Class Initialized
INFO - 2017-02-14 11:33:25 --> Output Class Initialized
INFO - 2017-02-14 11:33:25 --> Security Class Initialized
DEBUG - 2017-02-14 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:33:25 --> Input Class Initialized
INFO - 2017-02-14 11:33:25 --> Language Class Initialized
INFO - 2017-02-14 11:33:25 --> Loader Class Initialized
INFO - 2017-02-14 11:33:25 --> Helper loaded: url_helper
INFO - 2017-02-14 11:33:25 --> Helper loaded: language_helper
INFO - 2017-02-14 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:33:25 --> Controller Class Initialized
INFO - 2017-02-14 11:33:25 --> Database Driver Class Initialized
INFO - 2017-02-14 11:33:25 --> Model Class Initialized
INFO - 2017-02-14 11:33:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:33:25 --> Helper loaded: form_helper
INFO - 2017-02-14 11:33:25 --> Form Validation Class Initialized
INFO - 2017-02-14 11:33:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:33:25 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-14 11:33:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-14 11:33:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:33:25 --> Final output sent to browser
DEBUG - 2017-02-14 11:33:25 --> Total execution time: 0.0742
INFO - 2017-02-14 11:33:50 --> Config Class Initialized
INFO - 2017-02-14 11:33:50 --> Hooks Class Initialized
DEBUG - 2017-02-14 11:33:50 --> UTF-8 Support Enabled
INFO - 2017-02-14 11:33:50 --> Utf8 Class Initialized
INFO - 2017-02-14 11:33:50 --> URI Class Initialized
INFO - 2017-02-14 11:33:50 --> Router Class Initialized
INFO - 2017-02-14 11:33:50 --> Output Class Initialized
INFO - 2017-02-14 11:33:50 --> Security Class Initialized
DEBUG - 2017-02-14 11:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 11:33:50 --> Input Class Initialized
INFO - 2017-02-14 11:33:50 --> Language Class Initialized
INFO - 2017-02-14 11:33:50 --> Loader Class Initialized
INFO - 2017-02-14 11:33:50 --> Helper loaded: url_helper
INFO - 2017-02-14 11:33:50 --> Helper loaded: language_helper
INFO - 2017-02-14 11:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 11:33:50 --> Controller Class Initialized
INFO - 2017-02-14 11:33:50 --> Database Driver Class Initialized
INFO - 2017-02-14 11:33:50 --> Model Class Initialized
INFO - 2017-02-14 11:33:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 11:33:50 --> Helper loaded: form_helper
INFO - 2017-02-14 11:33:50 --> Form Validation Class Initialized
INFO - 2017-02-14 11:33:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 11:33:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 11:33:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 11:33:50 --> Final output sent to browser
DEBUG - 2017-02-14 11:33:50 --> Total execution time: 0.0640
INFO - 2017-02-14 15:29:37 --> Config Class Initialized
INFO - 2017-02-14 15:29:38 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:29:38 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:29:38 --> Utf8 Class Initialized
INFO - 2017-02-14 15:29:38 --> URI Class Initialized
DEBUG - 2017-02-14 15:29:38 --> No URI present. Default controller set.
INFO - 2017-02-14 15:29:38 --> Router Class Initialized
INFO - 2017-02-14 15:29:38 --> Output Class Initialized
INFO - 2017-02-14 15:29:38 --> Security Class Initialized
DEBUG - 2017-02-14 15:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:29:38 --> Input Class Initialized
INFO - 2017-02-14 15:29:38 --> Language Class Initialized
INFO - 2017-02-14 15:29:38 --> Loader Class Initialized
INFO - 2017-02-14 15:29:38 --> Helper loaded: url_helper
INFO - 2017-02-14 15:29:38 --> Helper loaded: language_helper
INFO - 2017-02-14 15:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:29:38 --> Controller Class Initialized
INFO - 2017-02-14 15:29:38 --> Database Driver Class Initialized
INFO - 2017-02-14 15:29:38 --> Model Class Initialized
INFO - 2017-02-14 15:29:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-14 15:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-14 15:29:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-14 15:29:38 --> Final output sent to browser
DEBUG - 2017-02-14 15:29:38 --> Total execution time: 0.4477
INFO - 2017-02-14 15:29:45 --> Config Class Initialized
INFO - 2017-02-14 15:29:45 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:29:45 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:29:45 --> Utf8 Class Initialized
INFO - 2017-02-14 15:29:45 --> URI Class Initialized
INFO - 2017-02-14 15:29:45 --> Router Class Initialized
INFO - 2017-02-14 15:29:45 --> Output Class Initialized
INFO - 2017-02-14 15:29:45 --> Security Class Initialized
DEBUG - 2017-02-14 15:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:29:45 --> Input Class Initialized
INFO - 2017-02-14 15:29:45 --> Language Class Initialized
INFO - 2017-02-14 15:29:45 --> Loader Class Initialized
INFO - 2017-02-14 15:29:45 --> Helper loaded: url_helper
INFO - 2017-02-14 15:29:45 --> Helper loaded: language_helper
INFO - 2017-02-14 15:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:29:46 --> Controller Class Initialized
INFO - 2017-02-14 15:29:46 --> Database Driver Class Initialized
INFO - 2017-02-14 15:29:46 --> Model Class Initialized
INFO - 2017-02-14 15:29:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:29:46 --> Config Class Initialized
INFO - 2017-02-14 15:29:46 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:29:46 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:29:46 --> Utf8 Class Initialized
INFO - 2017-02-14 15:29:46 --> URI Class Initialized
INFO - 2017-02-14 15:29:46 --> Router Class Initialized
INFO - 2017-02-14 15:29:46 --> Output Class Initialized
INFO - 2017-02-14 15:29:46 --> Security Class Initialized
DEBUG - 2017-02-14 15:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:29:46 --> Input Class Initialized
INFO - 2017-02-14 15:29:46 --> Language Class Initialized
INFO - 2017-02-14 15:29:46 --> Loader Class Initialized
INFO - 2017-02-14 15:29:46 --> Helper loaded: url_helper
INFO - 2017-02-14 15:29:46 --> Helper loaded: language_helper
INFO - 2017-02-14 15:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:29:46 --> Controller Class Initialized
INFO - 2017-02-14 15:29:46 --> Database Driver Class Initialized
INFO - 2017-02-14 15:29:46 --> Model Class Initialized
INFO - 2017-02-14 15:29:46 --> Model Class Initialized
INFO - 2017-02-14 15:29:46 --> Model Class Initialized
INFO - 2017-02-14 15:29:46 --> Model Class Initialized
INFO - 2017-02-14 15:29:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:29:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 15:29:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-14 15:29:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 15:29:46 --> Final output sent to browser
DEBUG - 2017-02-14 15:29:46 --> Total execution time: 0.5373
INFO - 2017-02-14 15:30:04 --> Config Class Initialized
INFO - 2017-02-14 15:30:04 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:30:04 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:30:04 --> Utf8 Class Initialized
INFO - 2017-02-14 15:30:04 --> URI Class Initialized
INFO - 2017-02-14 15:30:04 --> Router Class Initialized
INFO - 2017-02-14 15:30:04 --> Output Class Initialized
INFO - 2017-02-14 15:30:04 --> Security Class Initialized
DEBUG - 2017-02-14 15:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:30:04 --> Input Class Initialized
INFO - 2017-02-14 15:30:04 --> Language Class Initialized
INFO - 2017-02-14 15:30:04 --> Loader Class Initialized
INFO - 2017-02-14 15:30:04 --> Helper loaded: url_helper
INFO - 2017-02-14 15:30:04 --> Helper loaded: language_helper
INFO - 2017-02-14 15:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:30:04 --> Controller Class Initialized
INFO - 2017-02-14 15:30:04 --> Config Class Initialized
INFO - 2017-02-14 15:30:04 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:30:04 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:30:04 --> Utf8 Class Initialized
INFO - 2017-02-14 15:30:04 --> URI Class Initialized
INFO - 2017-02-14 15:30:04 --> Router Class Initialized
INFO - 2017-02-14 15:30:04 --> Output Class Initialized
INFO - 2017-02-14 15:30:04 --> Security Class Initialized
DEBUG - 2017-02-14 15:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:30:04 --> Input Class Initialized
INFO - 2017-02-14 15:30:04 --> Language Class Initialized
INFO - 2017-02-14 15:30:04 --> Loader Class Initialized
INFO - 2017-02-14 15:30:04 --> Helper loaded: url_helper
INFO - 2017-02-14 15:30:04 --> Helper loaded: language_helper
INFO - 2017-02-14 15:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:30:04 --> Controller Class Initialized
INFO - 2017-02-14 15:30:04 --> Database Driver Class Initialized
INFO - 2017-02-14 15:30:04 --> Model Class Initialized
INFO - 2017-02-14 15:30:04 --> Model Class Initialized
INFO - 2017-02-14 15:30:04 --> Model Class Initialized
INFO - 2017-02-14 15:30:04 --> Model Class Initialized
INFO - 2017-02-14 15:30:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:30:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 15:30:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-14 15:30:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 15:30:05 --> Final output sent to browser
DEBUG - 2017-02-14 15:30:05 --> Total execution time: 0.5007
INFO - 2017-02-14 15:30:25 --> Config Class Initialized
INFO - 2017-02-14 15:30:25 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:30:25 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:30:25 --> Utf8 Class Initialized
INFO - 2017-02-14 15:30:25 --> URI Class Initialized
INFO - 2017-02-14 15:30:25 --> Router Class Initialized
INFO - 2017-02-14 15:30:25 --> Output Class Initialized
INFO - 2017-02-14 15:30:25 --> Security Class Initialized
DEBUG - 2017-02-14 15:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:30:25 --> Input Class Initialized
INFO - 2017-02-14 15:30:25 --> Language Class Initialized
INFO - 2017-02-14 15:30:25 --> Loader Class Initialized
INFO - 2017-02-14 15:30:25 --> Helper loaded: url_helper
INFO - 2017-02-14 15:30:25 --> Helper loaded: language_helper
INFO - 2017-02-14 15:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:30:25 --> Controller Class Initialized
INFO - 2017-02-14 15:30:25 --> Database Driver Class Initialized
INFO - 2017-02-14 15:30:25 --> Model Class Initialized
INFO - 2017-02-14 15:30:25 --> Model Class Initialized
INFO - 2017-02-14 15:30:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:30:26 --> Config Class Initialized
INFO - 2017-02-14 15:30:26 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:30:26 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:30:26 --> Utf8 Class Initialized
INFO - 2017-02-14 15:30:26 --> URI Class Initialized
INFO - 2017-02-14 15:30:26 --> Router Class Initialized
INFO - 2017-02-14 15:30:26 --> Output Class Initialized
INFO - 2017-02-14 15:30:26 --> Security Class Initialized
DEBUG - 2017-02-14 15:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:30:26 --> Input Class Initialized
INFO - 2017-02-14 15:30:26 --> Language Class Initialized
INFO - 2017-02-14 15:30:26 --> Loader Class Initialized
INFO - 2017-02-14 15:30:26 --> Helper loaded: url_helper
INFO - 2017-02-14 15:30:26 --> Helper loaded: language_helper
INFO - 2017-02-14 15:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:30:26 --> Controller Class Initialized
INFO - 2017-02-14 15:30:26 --> Database Driver Class Initialized
INFO - 2017-02-14 15:30:26 --> Model Class Initialized
INFO - 2017-02-14 15:30:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:30:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-14 15:30:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-14 15:30:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-14 15:30:26 --> Final output sent to browser
DEBUG - 2017-02-14 15:30:26 --> Total execution time: 0.6012
INFO - 2017-02-14 15:30:30 --> Config Class Initialized
INFO - 2017-02-14 15:30:30 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:30:30 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:30:30 --> Utf8 Class Initialized
INFO - 2017-02-14 15:30:30 --> URI Class Initialized
INFO - 2017-02-14 15:30:30 --> Router Class Initialized
INFO - 2017-02-14 15:30:30 --> Output Class Initialized
INFO - 2017-02-14 15:30:30 --> Security Class Initialized
DEBUG - 2017-02-14 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:30:30 --> Input Class Initialized
INFO - 2017-02-14 15:30:30 --> Language Class Initialized
INFO - 2017-02-14 15:30:30 --> Loader Class Initialized
INFO - 2017-02-14 15:30:30 --> Helper loaded: url_helper
INFO - 2017-02-14 15:30:30 --> Helper loaded: language_helper
INFO - 2017-02-14 15:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:30:30 --> Controller Class Initialized
INFO - 2017-02-14 15:30:30 --> Database Driver Class Initialized
INFO - 2017-02-14 15:30:30 --> Model Class Initialized
INFO - 2017-02-14 15:30:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:30:30 --> Helper loaded: form_helper
INFO - 2017-02-14 15:30:30 --> Form Validation Class Initialized
INFO - 2017-02-14 15:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 15:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 15:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 15:30:30 --> Final output sent to browser
DEBUG - 2017-02-14 15:30:30 --> Total execution time: 0.3967
INFO - 2017-02-14 15:31:33 --> Config Class Initialized
INFO - 2017-02-14 15:31:33 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:31:33 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:31:33 --> Utf8 Class Initialized
INFO - 2017-02-14 15:31:33 --> URI Class Initialized
DEBUG - 2017-02-14 15:31:33 --> No URI present. Default controller set.
INFO - 2017-02-14 15:31:33 --> Router Class Initialized
INFO - 2017-02-14 15:31:33 --> Output Class Initialized
INFO - 2017-02-14 15:31:33 --> Security Class Initialized
DEBUG - 2017-02-14 15:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:31:33 --> Input Class Initialized
INFO - 2017-02-14 15:31:33 --> Language Class Initialized
INFO - 2017-02-14 15:31:33 --> Loader Class Initialized
INFO - 2017-02-14 15:31:33 --> Helper loaded: url_helper
INFO - 2017-02-14 15:31:33 --> Helper loaded: language_helper
INFO - 2017-02-14 15:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:31:33 --> Controller Class Initialized
INFO - 2017-02-14 15:31:33 --> Database Driver Class Initialized
INFO - 2017-02-14 15:31:33 --> Model Class Initialized
INFO - 2017-02-14 15:31:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-14 15:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-14 15:31:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-14 15:31:33 --> Final output sent to browser
DEBUG - 2017-02-14 15:31:33 --> Total execution time: 0.1313
INFO - 2017-02-14 15:33:03 --> Config Class Initialized
INFO - 2017-02-14 15:33:03 --> Hooks Class Initialized
DEBUG - 2017-02-14 15:33:03 --> UTF-8 Support Enabled
INFO - 2017-02-14 15:33:03 --> Utf8 Class Initialized
INFO - 2017-02-14 15:33:03 --> URI Class Initialized
INFO - 2017-02-14 15:33:03 --> Router Class Initialized
INFO - 2017-02-14 15:33:03 --> Output Class Initialized
INFO - 2017-02-14 15:33:03 --> Security Class Initialized
DEBUG - 2017-02-14 15:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-14 15:33:03 --> Input Class Initialized
INFO - 2017-02-14 15:33:03 --> Language Class Initialized
INFO - 2017-02-14 15:33:03 --> Loader Class Initialized
INFO - 2017-02-14 15:33:03 --> Helper loaded: url_helper
INFO - 2017-02-14 15:33:03 --> Helper loaded: language_helper
INFO - 2017-02-14 15:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-14 15:33:04 --> Controller Class Initialized
INFO - 2017-02-14 15:33:04 --> Database Driver Class Initialized
INFO - 2017-02-14 15:33:04 --> Model Class Initialized
INFO - 2017-02-14 15:33:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-14 15:33:04 --> Helper loaded: form_helper
INFO - 2017-02-14 15:33:04 --> Form Validation Class Initialized
INFO - 2017-02-14 15:33:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-14 15:33:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-14 15:33:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-14 15:33:04 --> Final output sent to browser
DEBUG - 2017-02-14 15:33:04 --> Total execution time: 0.1171
