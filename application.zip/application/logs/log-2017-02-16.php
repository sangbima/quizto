<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-16 10:25:28 --> Config Class Initialized
INFO - 2017-02-16 10:25:28 --> Hooks Class Initialized
DEBUG - 2017-02-16 10:25:28 --> UTF-8 Support Enabled
INFO - 2017-02-16 10:25:28 --> Utf8 Class Initialized
INFO - 2017-02-16 10:25:28 --> URI Class Initialized
DEBUG - 2017-02-16 10:25:28 --> No URI present. Default controller set.
INFO - 2017-02-16 10:25:28 --> Router Class Initialized
INFO - 2017-02-16 10:25:28 --> Output Class Initialized
INFO - 2017-02-16 10:25:28 --> Security Class Initialized
DEBUG - 2017-02-16 10:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 10:25:28 --> Input Class Initialized
INFO - 2017-02-16 10:25:28 --> Language Class Initialized
INFO - 2017-02-16 10:25:28 --> Loader Class Initialized
INFO - 2017-02-16 10:25:28 --> Helper loaded: url_helper
INFO - 2017-02-16 10:25:28 --> Helper loaded: language_helper
INFO - 2017-02-16 10:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 10:25:28 --> Controller Class Initialized
INFO - 2017-02-16 10:25:28 --> Database Driver Class Initialized
INFO - 2017-02-16 10:25:28 --> Model Class Initialized
INFO - 2017-02-16 10:25:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 10:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-16 10:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-16 10:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-16 10:25:28 --> Final output sent to browser
DEBUG - 2017-02-16 10:25:28 --> Total execution time: 0.2142
INFO - 2017-02-16 10:25:28 --> Config Class Initialized
INFO - 2017-02-16 10:25:28 --> Hooks Class Initialized
DEBUG - 2017-02-16 10:25:28 --> UTF-8 Support Enabled
INFO - 2017-02-16 10:25:28 --> Utf8 Class Initialized
INFO - 2017-02-16 10:25:28 --> URI Class Initialized
DEBUG - 2017-02-16 10:25:28 --> No URI present. Default controller set.
INFO - 2017-02-16 10:25:28 --> Router Class Initialized
INFO - 2017-02-16 10:25:28 --> Output Class Initialized
INFO - 2017-02-16 10:25:28 --> Security Class Initialized
DEBUG - 2017-02-16 10:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 10:25:28 --> Input Class Initialized
INFO - 2017-02-16 10:25:28 --> Language Class Initialized
INFO - 2017-02-16 10:25:28 --> Loader Class Initialized
INFO - 2017-02-16 10:25:28 --> Helper loaded: url_helper
INFO - 2017-02-16 10:25:28 --> Helper loaded: language_helper
INFO - 2017-02-16 10:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 10:25:28 --> Controller Class Initialized
INFO - 2017-02-16 10:25:28 --> Database Driver Class Initialized
INFO - 2017-02-16 10:25:28 --> Model Class Initialized
INFO - 2017-02-16 10:25:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 10:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-16 10:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-16 10:25:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-16 10:25:28 --> Final output sent to browser
DEBUG - 2017-02-16 10:25:28 --> Total execution time: 0.0810
INFO - 2017-02-16 10:25:29 --> Config Class Initialized
INFO - 2017-02-16 10:25:29 --> Hooks Class Initialized
DEBUG - 2017-02-16 10:25:29 --> UTF-8 Support Enabled
INFO - 2017-02-16 10:25:29 --> Utf8 Class Initialized
INFO - 2017-02-16 10:25:29 --> URI Class Initialized
INFO - 2017-02-16 10:25:29 --> Router Class Initialized
INFO - 2017-02-16 10:25:29 --> Output Class Initialized
INFO - 2017-02-16 10:25:29 --> Security Class Initialized
DEBUG - 2017-02-16 10:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 10:25:29 --> Input Class Initialized
INFO - 2017-02-16 10:25:29 --> Language Class Initialized
ERROR - 2017-02-16 10:25:29 --> 404 Page Not Found: Faviconico/index
INFO - 2017-02-16 10:25:35 --> Config Class Initialized
INFO - 2017-02-16 10:25:35 --> Hooks Class Initialized
DEBUG - 2017-02-16 10:25:35 --> UTF-8 Support Enabled
INFO - 2017-02-16 10:25:35 --> Utf8 Class Initialized
INFO - 2017-02-16 10:25:35 --> URI Class Initialized
INFO - 2017-02-16 10:25:35 --> Router Class Initialized
INFO - 2017-02-16 10:25:35 --> Output Class Initialized
INFO - 2017-02-16 10:25:35 --> Security Class Initialized
DEBUG - 2017-02-16 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 10:25:35 --> Input Class Initialized
INFO - 2017-02-16 10:25:35 --> Language Class Initialized
INFO - 2017-02-16 10:25:35 --> Loader Class Initialized
INFO - 2017-02-16 10:25:35 --> Helper loaded: url_helper
INFO - 2017-02-16 10:25:35 --> Helper loaded: language_helper
INFO - 2017-02-16 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 10:25:35 --> Controller Class Initialized
INFO - 2017-02-16 10:25:35 --> Database Driver Class Initialized
INFO - 2017-02-16 10:25:35 --> Model Class Initialized
INFO - 2017-02-16 10:25:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 10:25:35 --> Config Class Initialized
INFO - 2017-02-16 10:25:35 --> Hooks Class Initialized
DEBUG - 2017-02-16 10:25:35 --> UTF-8 Support Enabled
INFO - 2017-02-16 10:25:35 --> Utf8 Class Initialized
INFO - 2017-02-16 10:25:35 --> URI Class Initialized
INFO - 2017-02-16 10:25:35 --> Router Class Initialized
INFO - 2017-02-16 10:25:35 --> Output Class Initialized
INFO - 2017-02-16 10:25:35 --> Security Class Initialized
DEBUG - 2017-02-16 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 10:25:35 --> Input Class Initialized
INFO - 2017-02-16 10:25:35 --> Language Class Initialized
INFO - 2017-02-16 10:25:35 --> Loader Class Initialized
INFO - 2017-02-16 10:25:35 --> Helper loaded: url_helper
INFO - 2017-02-16 10:25:35 --> Helper loaded: language_helper
INFO - 2017-02-16 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 10:25:35 --> Controller Class Initialized
INFO - 2017-02-16 10:25:35 --> Database Driver Class Initialized
INFO - 2017-02-16 10:25:35 --> Model Class Initialized
INFO - 2017-02-16 10:25:35 --> Model Class Initialized
INFO - 2017-02-16 10:25:35 --> Model Class Initialized
INFO - 2017-02-16 10:25:35 --> Model Class Initialized
INFO - 2017-02-16 10:25:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 10:25:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 10:25:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-16 10:25:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 10:25:35 --> Final output sent to browser
DEBUG - 2017-02-16 10:25:35 --> Total execution time: 0.1362
INFO - 2017-02-16 10:25:37 --> Config Class Initialized
INFO - 2017-02-16 10:25:37 --> Hooks Class Initialized
DEBUG - 2017-02-16 10:25:37 --> UTF-8 Support Enabled
INFO - 2017-02-16 10:25:37 --> Utf8 Class Initialized
INFO - 2017-02-16 10:25:37 --> URI Class Initialized
INFO - 2017-02-16 10:25:37 --> Router Class Initialized
INFO - 2017-02-16 10:25:37 --> Output Class Initialized
INFO - 2017-02-16 10:25:37 --> Security Class Initialized
DEBUG - 2017-02-16 10:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 10:25:38 --> Input Class Initialized
INFO - 2017-02-16 10:25:38 --> Language Class Initialized
INFO - 2017-02-16 10:25:38 --> Loader Class Initialized
INFO - 2017-02-16 10:25:38 --> Helper loaded: url_helper
INFO - 2017-02-16 10:25:38 --> Helper loaded: language_helper
INFO - 2017-02-16 10:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 10:25:38 --> Controller Class Initialized
INFO - 2017-02-16 10:25:38 --> Database Driver Class Initialized
INFO - 2017-02-16 10:25:38 --> Model Class Initialized
INFO - 2017-02-16 10:25:38 --> Model Class Initialized
INFO - 2017-02-16 10:25:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 10:25:38 --> Helper loaded: form_helper
INFO - 2017-02-16 10:25:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 10:25:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 10:25:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 10:25:38 --> Final output sent to browser
DEBUG - 2017-02-16 10:25:38 --> Total execution time: 0.4313
INFO - 2017-02-16 16:29:04 --> Config Class Initialized
INFO - 2017-02-16 16:29:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:04 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:04 --> URI Class Initialized
INFO - 2017-02-16 16:29:04 --> Router Class Initialized
INFO - 2017-02-16 16:29:04 --> Output Class Initialized
INFO - 2017-02-16 16:29:04 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:04 --> Input Class Initialized
INFO - 2017-02-16 16:29:04 --> Language Class Initialized
INFO - 2017-02-16 16:29:04 --> Loader Class Initialized
INFO - 2017-02-16 16:29:04 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:04 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:04 --> Controller Class Initialized
INFO - 2017-02-16 16:29:04 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:04 --> Model Class Initialized
INFO - 2017-02-16 16:29:04 --> Model Class Initialized
INFO - 2017-02-16 16:29:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:04 --> Config Class Initialized
INFO - 2017-02-16 16:29:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:04 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:04 --> URI Class Initialized
INFO - 2017-02-16 16:29:04 --> Router Class Initialized
INFO - 2017-02-16 16:29:04 --> Output Class Initialized
INFO - 2017-02-16 16:29:04 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:04 --> Input Class Initialized
INFO - 2017-02-16 16:29:04 --> Language Class Initialized
INFO - 2017-02-16 16:29:04 --> Loader Class Initialized
INFO - 2017-02-16 16:29:04 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:04 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:04 --> Controller Class Initialized
INFO - 2017-02-16 16:29:04 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:04 --> Model Class Initialized
INFO - 2017-02-16 16:29:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-16 16:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-16 16:29:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-16 16:29:04 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:04 --> Total execution time: 0.1108
INFO - 2017-02-16 16:29:14 --> Config Class Initialized
INFO - 2017-02-16 16:29:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:14 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:14 --> URI Class Initialized
INFO - 2017-02-16 16:29:14 --> Router Class Initialized
INFO - 2017-02-16 16:29:14 --> Output Class Initialized
INFO - 2017-02-16 16:29:14 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:14 --> Input Class Initialized
INFO - 2017-02-16 16:29:14 --> Language Class Initialized
INFO - 2017-02-16 16:29:14 --> Loader Class Initialized
INFO - 2017-02-16 16:29:14 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:14 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:14 --> Controller Class Initialized
INFO - 2017-02-16 16:29:14 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:14 --> Model Class Initialized
INFO - 2017-02-16 16:29:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:14 --> Config Class Initialized
INFO - 2017-02-16 16:29:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:14 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:14 --> URI Class Initialized
INFO - 2017-02-16 16:29:14 --> Router Class Initialized
INFO - 2017-02-16 16:29:14 --> Output Class Initialized
INFO - 2017-02-16 16:29:14 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:14 --> Input Class Initialized
INFO - 2017-02-16 16:29:14 --> Language Class Initialized
INFO - 2017-02-16 16:29:14 --> Loader Class Initialized
INFO - 2017-02-16 16:29:14 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:14 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:14 --> Controller Class Initialized
INFO - 2017-02-16 16:29:14 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:14 --> Model Class Initialized
INFO - 2017-02-16 16:29:14 --> Model Class Initialized
INFO - 2017-02-16 16:29:14 --> Model Class Initialized
INFO - 2017-02-16 16:29:15 --> Model Class Initialized
INFO - 2017-02-16 16:29:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:29:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-16 16:29:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:29:15 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:15 --> Total execution time: 0.1680
INFO - 2017-02-16 16:29:18 --> Config Class Initialized
INFO - 2017-02-16 16:29:18 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:18 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:18 --> URI Class Initialized
INFO - 2017-02-16 16:29:18 --> Router Class Initialized
INFO - 2017-02-16 16:29:18 --> Output Class Initialized
INFO - 2017-02-16 16:29:18 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:18 --> Input Class Initialized
INFO - 2017-02-16 16:29:18 --> Language Class Initialized
INFO - 2017-02-16 16:29:18 --> Loader Class Initialized
INFO - 2017-02-16 16:29:18 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:18 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:18 --> Controller Class Initialized
INFO - 2017-02-16 16:29:18 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:18 --> Model Class Initialized
INFO - 2017-02-16 16:29:18 --> Model Class Initialized
INFO - 2017-02-16 16:29:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:18 --> Helper loaded: form_helper
INFO - 2017-02-16 16:29:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:29:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:29:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:29:19 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:19 --> Total execution time: 0.4157
INFO - 2017-02-16 16:29:28 --> Config Class Initialized
INFO - 2017-02-16 16:29:28 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:28 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:28 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:28 --> URI Class Initialized
INFO - 2017-02-16 16:29:28 --> Router Class Initialized
INFO - 2017-02-16 16:29:28 --> Output Class Initialized
INFO - 2017-02-16 16:29:28 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:28 --> Input Class Initialized
INFO - 2017-02-16 16:29:28 --> Language Class Initialized
INFO - 2017-02-16 16:29:28 --> Loader Class Initialized
INFO - 2017-02-16 16:29:28 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:28 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:28 --> Controller Class Initialized
INFO - 2017-02-16 16:29:28 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:28 --> Model Class Initialized
INFO - 2017-02-16 16:29:28 --> Model Class Initialized
INFO - 2017-02-16 16:29:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:28 --> Helper loaded: form_helper
INFO - 2017-02-16 16:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:29:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:29:28 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:28 --> Total execution time: 0.1529
INFO - 2017-02-16 16:29:32 --> Config Class Initialized
INFO - 2017-02-16 16:29:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:32 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:32 --> URI Class Initialized
INFO - 2017-02-16 16:29:32 --> Router Class Initialized
INFO - 2017-02-16 16:29:32 --> Output Class Initialized
INFO - 2017-02-16 16:29:32 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:32 --> Input Class Initialized
INFO - 2017-02-16 16:29:32 --> Language Class Initialized
INFO - 2017-02-16 16:29:32 --> Loader Class Initialized
INFO - 2017-02-16 16:29:32 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:32 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:32 --> Controller Class Initialized
INFO - 2017-02-16 16:29:32 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:32 --> Model Class Initialized
INFO - 2017-02-16 16:29:32 --> Model Class Initialized
INFO - 2017-02-16 16:29:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:33 --> Helper loaded: form_helper
INFO - 2017-02-16 16:29:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:29:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:29:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:29:33 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:33 --> Total execution time: 0.1840
INFO - 2017-02-16 16:29:37 --> Config Class Initialized
INFO - 2017-02-16 16:29:37 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:37 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:37 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:37 --> URI Class Initialized
INFO - 2017-02-16 16:29:37 --> Router Class Initialized
INFO - 2017-02-16 16:29:37 --> Output Class Initialized
INFO - 2017-02-16 16:29:37 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:37 --> Input Class Initialized
INFO - 2017-02-16 16:29:37 --> Language Class Initialized
INFO - 2017-02-16 16:29:37 --> Loader Class Initialized
INFO - 2017-02-16 16:29:37 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:37 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:37 --> Controller Class Initialized
INFO - 2017-02-16 16:29:37 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:37 --> Model Class Initialized
INFO - 2017-02-16 16:29:37 --> Model Class Initialized
INFO - 2017-02-16 16:29:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:37 --> Helper loaded: form_helper
INFO - 2017-02-16 16:29:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:29:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:29:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:29:37 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:37 --> Total execution time: 0.1536
INFO - 2017-02-16 16:29:41 --> Config Class Initialized
INFO - 2017-02-16 16:29:41 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:41 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:41 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:41 --> URI Class Initialized
INFO - 2017-02-16 16:29:41 --> Router Class Initialized
INFO - 2017-02-16 16:29:41 --> Output Class Initialized
INFO - 2017-02-16 16:29:41 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:41 --> Input Class Initialized
INFO - 2017-02-16 16:29:41 --> Language Class Initialized
INFO - 2017-02-16 16:29:41 --> Loader Class Initialized
INFO - 2017-02-16 16:29:41 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:41 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:41 --> Controller Class Initialized
INFO - 2017-02-16 16:29:41 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:41 --> Model Class Initialized
INFO - 2017-02-16 16:29:41 --> Model Class Initialized
INFO - 2017-02-16 16:29:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:41 --> Helper loaded: form_helper
INFO - 2017-02-16 16:29:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:29:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:29:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:29:41 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:41 --> Total execution time: 0.1447
INFO - 2017-02-16 16:29:50 --> Config Class Initialized
INFO - 2017-02-16 16:29:50 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:50 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:50 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:50 --> URI Class Initialized
INFO - 2017-02-16 16:29:50 --> Router Class Initialized
INFO - 2017-02-16 16:29:50 --> Output Class Initialized
INFO - 2017-02-16 16:29:50 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:50 --> Input Class Initialized
INFO - 2017-02-16 16:29:50 --> Language Class Initialized
INFO - 2017-02-16 16:29:50 --> Loader Class Initialized
INFO - 2017-02-16 16:29:50 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:50 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:50 --> Controller Class Initialized
INFO - 2017-02-16 16:29:50 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:50 --> Model Class Initialized
INFO - 2017-02-16 16:29:50 --> Model Class Initialized
INFO - 2017-02-16 16:29:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:50 --> Helper loaded: form_helper
INFO - 2017-02-16 16:29:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:29:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:29:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:29:50 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:50 --> Total execution time: 0.3216
INFO - 2017-02-16 16:29:55 --> Config Class Initialized
INFO - 2017-02-16 16:29:55 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:29:55 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:29:55 --> Utf8 Class Initialized
INFO - 2017-02-16 16:29:55 --> URI Class Initialized
INFO - 2017-02-16 16:29:55 --> Router Class Initialized
INFO - 2017-02-16 16:29:55 --> Output Class Initialized
INFO - 2017-02-16 16:29:55 --> Security Class Initialized
DEBUG - 2017-02-16 16:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:29:55 --> Input Class Initialized
INFO - 2017-02-16 16:29:55 --> Language Class Initialized
INFO - 2017-02-16 16:29:55 --> Loader Class Initialized
INFO - 2017-02-16 16:29:55 --> Helper loaded: url_helper
INFO - 2017-02-16 16:29:55 --> Helper loaded: language_helper
INFO - 2017-02-16 16:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:29:55 --> Controller Class Initialized
INFO - 2017-02-16 16:29:55 --> Database Driver Class Initialized
INFO - 2017-02-16 16:29:55 --> Model Class Initialized
INFO - 2017-02-16 16:29:55 --> Model Class Initialized
INFO - 2017-02-16 16:29:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:29:55 --> Helper loaded: form_helper
INFO - 2017-02-16 16:29:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:29:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:29:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:29:55 --> Final output sent to browser
DEBUG - 2017-02-16 16:29:55 --> Total execution time: 0.3259
INFO - 2017-02-16 16:32:06 --> Config Class Initialized
INFO - 2017-02-16 16:32:06 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:32:06 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:32:06 --> Utf8 Class Initialized
INFO - 2017-02-16 16:32:06 --> URI Class Initialized
INFO - 2017-02-16 16:32:06 --> Router Class Initialized
INFO - 2017-02-16 16:32:06 --> Output Class Initialized
INFO - 2017-02-16 16:32:06 --> Security Class Initialized
DEBUG - 2017-02-16 16:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:32:06 --> Input Class Initialized
INFO - 2017-02-16 16:32:06 --> Language Class Initialized
INFO - 2017-02-16 16:32:06 --> Loader Class Initialized
INFO - 2017-02-16 16:32:06 --> Helper loaded: url_helper
INFO - 2017-02-16 16:32:06 --> Helper loaded: language_helper
INFO - 2017-02-16 16:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:32:06 --> Controller Class Initialized
INFO - 2017-02-16 16:32:06 --> Database Driver Class Initialized
INFO - 2017-02-16 16:32:06 --> Model Class Initialized
INFO - 2017-02-16 16:32:06 --> Model Class Initialized
INFO - 2017-02-16 16:32:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:32:06 --> Helper loaded: form_helper
INFO - 2017-02-16 16:32:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:32:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:32:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:32:06 --> Final output sent to browser
DEBUG - 2017-02-16 16:32:06 --> Total execution time: 0.3630
INFO - 2017-02-16 16:32:16 --> Config Class Initialized
INFO - 2017-02-16 16:32:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:32:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:32:16 --> Utf8 Class Initialized
INFO - 2017-02-16 16:32:16 --> URI Class Initialized
INFO - 2017-02-16 16:32:16 --> Router Class Initialized
INFO - 2017-02-16 16:32:16 --> Output Class Initialized
INFO - 2017-02-16 16:32:16 --> Security Class Initialized
DEBUG - 2017-02-16 16:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:32:16 --> Input Class Initialized
INFO - 2017-02-16 16:32:16 --> Language Class Initialized
INFO - 2017-02-16 16:32:16 --> Loader Class Initialized
INFO - 2017-02-16 16:32:16 --> Helper loaded: url_helper
INFO - 2017-02-16 16:32:16 --> Helper loaded: language_helper
INFO - 2017-02-16 16:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:32:16 --> Controller Class Initialized
INFO - 2017-02-16 16:32:17 --> Database Driver Class Initialized
INFO - 2017-02-16 16:32:17 --> Model Class Initialized
INFO - 2017-02-16 16:32:17 --> Model Class Initialized
INFO - 2017-02-16 16:32:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:32:17 --> Helper loaded: form_helper
INFO - 2017-02-16 16:32:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:32:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:32:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:32:17 --> Final output sent to browser
DEBUG - 2017-02-16 16:32:17 --> Total execution time: 0.3188
INFO - 2017-02-16 16:32:58 --> Config Class Initialized
INFO - 2017-02-16 16:32:58 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:32:58 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:32:58 --> Utf8 Class Initialized
INFO - 2017-02-16 16:32:58 --> URI Class Initialized
INFO - 2017-02-16 16:32:58 --> Router Class Initialized
INFO - 2017-02-16 16:32:58 --> Output Class Initialized
INFO - 2017-02-16 16:32:58 --> Security Class Initialized
DEBUG - 2017-02-16 16:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:32:58 --> Input Class Initialized
INFO - 2017-02-16 16:32:58 --> Language Class Initialized
INFO - 2017-02-16 16:32:58 --> Loader Class Initialized
INFO - 2017-02-16 16:32:58 --> Helper loaded: url_helper
INFO - 2017-02-16 16:32:58 --> Helper loaded: language_helper
INFO - 2017-02-16 16:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:32:58 --> Controller Class Initialized
INFO - 2017-02-16 16:32:58 --> Database Driver Class Initialized
INFO - 2017-02-16 16:32:58 --> Model Class Initialized
INFO - 2017-02-16 16:32:58 --> Model Class Initialized
INFO - 2017-02-16 16:32:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:32:58 --> Helper loaded: form_helper
INFO - 2017-02-16 16:32:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:32:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:32:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:32:58 --> Final output sent to browser
DEBUG - 2017-02-16 16:32:58 --> Total execution time: 0.4559
INFO - 2017-02-16 16:33:46 --> Config Class Initialized
INFO - 2017-02-16 16:33:46 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:33:46 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:33:46 --> Utf8 Class Initialized
INFO - 2017-02-16 16:33:46 --> URI Class Initialized
INFO - 2017-02-16 16:33:46 --> Router Class Initialized
INFO - 2017-02-16 16:33:46 --> Output Class Initialized
INFO - 2017-02-16 16:33:46 --> Security Class Initialized
DEBUG - 2017-02-16 16:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:33:46 --> Input Class Initialized
INFO - 2017-02-16 16:33:46 --> Language Class Initialized
INFO - 2017-02-16 16:33:46 --> Loader Class Initialized
INFO - 2017-02-16 16:33:46 --> Helper loaded: url_helper
INFO - 2017-02-16 16:33:46 --> Helper loaded: language_helper
INFO - 2017-02-16 16:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:33:46 --> Controller Class Initialized
INFO - 2017-02-16 16:33:46 --> Database Driver Class Initialized
INFO - 2017-02-16 16:33:46 --> Model Class Initialized
INFO - 2017-02-16 16:33:46 --> Model Class Initialized
INFO - 2017-02-16 16:33:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:33:46 --> Helper loaded: form_helper
INFO - 2017-02-16 16:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:33:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:33:46 --> Final output sent to browser
DEBUG - 2017-02-16 16:33:46 --> Total execution time: 0.3965
INFO - 2017-02-16 16:34:21 --> Config Class Initialized
INFO - 2017-02-16 16:34:21 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:34:21 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:34:21 --> Utf8 Class Initialized
INFO - 2017-02-16 16:34:21 --> URI Class Initialized
INFO - 2017-02-16 16:34:21 --> Router Class Initialized
INFO - 2017-02-16 16:34:21 --> Output Class Initialized
INFO - 2017-02-16 16:34:21 --> Security Class Initialized
DEBUG - 2017-02-16 16:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:34:21 --> Input Class Initialized
INFO - 2017-02-16 16:34:21 --> Language Class Initialized
INFO - 2017-02-16 16:34:21 --> Loader Class Initialized
INFO - 2017-02-16 16:34:21 --> Helper loaded: url_helper
INFO - 2017-02-16 16:34:21 --> Helper loaded: language_helper
INFO - 2017-02-16 16:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:34:21 --> Controller Class Initialized
INFO - 2017-02-16 16:34:21 --> Database Driver Class Initialized
INFO - 2017-02-16 16:34:21 --> Model Class Initialized
INFO - 2017-02-16 16:34:21 --> Model Class Initialized
INFO - 2017-02-16 16:34:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:34:21 --> Helper loaded: form_helper
INFO - 2017-02-16 16:34:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:34:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:34:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:34:21 --> Final output sent to browser
DEBUG - 2017-02-16 16:34:21 --> Total execution time: 0.3615
INFO - 2017-02-16 16:34:27 --> Config Class Initialized
INFO - 2017-02-16 16:34:27 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:34:27 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:34:27 --> Utf8 Class Initialized
INFO - 2017-02-16 16:34:27 --> URI Class Initialized
INFO - 2017-02-16 16:34:27 --> Router Class Initialized
INFO - 2017-02-16 16:34:27 --> Output Class Initialized
INFO - 2017-02-16 16:34:27 --> Security Class Initialized
DEBUG - 2017-02-16 16:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:34:27 --> Input Class Initialized
INFO - 2017-02-16 16:34:27 --> Language Class Initialized
INFO - 2017-02-16 16:34:27 --> Loader Class Initialized
INFO - 2017-02-16 16:34:27 --> Helper loaded: url_helper
INFO - 2017-02-16 16:34:27 --> Helper loaded: language_helper
INFO - 2017-02-16 16:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:34:27 --> Controller Class Initialized
INFO - 2017-02-16 16:34:27 --> Database Driver Class Initialized
INFO - 2017-02-16 16:34:27 --> Model Class Initialized
INFO - 2017-02-16 16:34:27 --> Model Class Initialized
INFO - 2017-02-16 16:34:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:34:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:34:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:34:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:34:27 --> Final output sent to browser
DEBUG - 2017-02-16 16:34:27 --> Total execution time: 0.2397
INFO - 2017-02-16 16:34:28 --> Config Class Initialized
INFO - 2017-02-16 16:34:28 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:34:28 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:34:28 --> Utf8 Class Initialized
INFO - 2017-02-16 16:34:28 --> URI Class Initialized
INFO - 2017-02-16 16:34:28 --> Router Class Initialized
INFO - 2017-02-16 16:34:28 --> Output Class Initialized
INFO - 2017-02-16 16:34:28 --> Security Class Initialized
DEBUG - 2017-02-16 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:34:28 --> Input Class Initialized
INFO - 2017-02-16 16:34:28 --> Language Class Initialized
INFO - 2017-02-16 16:34:28 --> Loader Class Initialized
INFO - 2017-02-16 16:34:28 --> Helper loaded: url_helper
INFO - 2017-02-16 16:34:28 --> Helper loaded: language_helper
INFO - 2017-02-16 16:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:34:28 --> Controller Class Initialized
INFO - 2017-02-16 16:34:28 --> Database Driver Class Initialized
INFO - 2017-02-16 16:34:28 --> Model Class Initialized
INFO - 2017-02-16 16:34:28 --> Model Class Initialized
INFO - 2017-02-16 16:34:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:34:28 --> Final output sent to browser
DEBUG - 2017-02-16 16:34:28 --> Total execution time: 0.2006
INFO - 2017-02-16 16:35:07 --> Config Class Initialized
INFO - 2017-02-16 16:35:07 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:35:07 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:35:07 --> Utf8 Class Initialized
INFO - 2017-02-16 16:35:07 --> URI Class Initialized
INFO - 2017-02-16 16:35:07 --> Router Class Initialized
INFO - 2017-02-16 16:35:07 --> Output Class Initialized
INFO - 2017-02-16 16:35:07 --> Security Class Initialized
DEBUG - 2017-02-16 16:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:35:07 --> Input Class Initialized
INFO - 2017-02-16 16:35:07 --> Language Class Initialized
INFO - 2017-02-16 16:35:07 --> Loader Class Initialized
INFO - 2017-02-16 16:35:07 --> Helper loaded: url_helper
INFO - 2017-02-16 16:35:07 --> Helper loaded: language_helper
INFO - 2017-02-16 16:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:35:07 --> Controller Class Initialized
INFO - 2017-02-16 16:35:07 --> Database Driver Class Initialized
INFO - 2017-02-16 16:35:07 --> Model Class Initialized
INFO - 2017-02-16 16:35:07 --> Model Class Initialized
INFO - 2017-02-16 16:35:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:35:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:35:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:35:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:35:07 --> Final output sent to browser
DEBUG - 2017-02-16 16:35:07 --> Total execution time: 0.1000
INFO - 2017-02-16 16:35:07 --> Config Class Initialized
INFO - 2017-02-16 16:35:07 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:35:08 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:35:08 --> Utf8 Class Initialized
INFO - 2017-02-16 16:35:08 --> URI Class Initialized
INFO - 2017-02-16 16:35:08 --> Router Class Initialized
INFO - 2017-02-16 16:35:08 --> Output Class Initialized
INFO - 2017-02-16 16:35:08 --> Security Class Initialized
DEBUG - 2017-02-16 16:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:35:08 --> Input Class Initialized
INFO - 2017-02-16 16:35:08 --> Language Class Initialized
INFO - 2017-02-16 16:35:08 --> Loader Class Initialized
INFO - 2017-02-16 16:35:08 --> Helper loaded: url_helper
INFO - 2017-02-16 16:35:08 --> Helper loaded: language_helper
INFO - 2017-02-16 16:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:35:08 --> Controller Class Initialized
INFO - 2017-02-16 16:35:08 --> Database Driver Class Initialized
INFO - 2017-02-16 16:35:08 --> Model Class Initialized
INFO - 2017-02-16 16:35:08 --> Model Class Initialized
INFO - 2017-02-16 16:35:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:35:08 --> Final output sent to browser
DEBUG - 2017-02-16 16:35:08 --> Total execution time: 0.1227
INFO - 2017-02-16 16:35:11 --> Config Class Initialized
INFO - 2017-02-16 16:35:11 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:35:11 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:35:11 --> Utf8 Class Initialized
INFO - 2017-02-16 16:35:11 --> URI Class Initialized
INFO - 2017-02-16 16:35:11 --> Router Class Initialized
INFO - 2017-02-16 16:35:11 --> Output Class Initialized
INFO - 2017-02-16 16:35:11 --> Security Class Initialized
DEBUG - 2017-02-16 16:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:35:11 --> Input Class Initialized
INFO - 2017-02-16 16:35:11 --> Language Class Initialized
INFO - 2017-02-16 16:35:11 --> Loader Class Initialized
INFO - 2017-02-16 16:35:11 --> Helper loaded: url_helper
INFO - 2017-02-16 16:35:11 --> Helper loaded: language_helper
INFO - 2017-02-16 16:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:35:11 --> Controller Class Initialized
INFO - 2017-02-16 16:35:11 --> Database Driver Class Initialized
INFO - 2017-02-16 16:35:11 --> Model Class Initialized
INFO - 2017-02-16 16:35:11 --> Model Class Initialized
INFO - 2017-02-16 16:35:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:35:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:35:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:35:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:35:11 --> Final output sent to browser
DEBUG - 2017-02-16 16:35:11 --> Total execution time: 0.1650
INFO - 2017-02-16 16:35:23 --> Config Class Initialized
INFO - 2017-02-16 16:35:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:35:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:35:23 --> Utf8 Class Initialized
INFO - 2017-02-16 16:35:23 --> URI Class Initialized
INFO - 2017-02-16 16:35:23 --> Router Class Initialized
INFO - 2017-02-16 16:35:23 --> Output Class Initialized
INFO - 2017-02-16 16:35:23 --> Security Class Initialized
DEBUG - 2017-02-16 16:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:35:23 --> Input Class Initialized
INFO - 2017-02-16 16:35:23 --> Language Class Initialized
INFO - 2017-02-16 16:35:23 --> Loader Class Initialized
INFO - 2017-02-16 16:35:23 --> Helper loaded: url_helper
INFO - 2017-02-16 16:35:23 --> Helper loaded: language_helper
INFO - 2017-02-16 16:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:35:23 --> Controller Class Initialized
INFO - 2017-02-16 16:35:23 --> Database Driver Class Initialized
INFO - 2017-02-16 16:35:23 --> Model Class Initialized
INFO - 2017-02-16 16:35:23 --> Model Class Initialized
INFO - 2017-02-16 16:35:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:35:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:35:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:35:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:35:23 --> Final output sent to browser
DEBUG - 2017-02-16 16:35:23 --> Total execution time: 0.1463
INFO - 2017-02-16 16:35:23 --> Config Class Initialized
INFO - 2017-02-16 16:35:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:35:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:35:23 --> Utf8 Class Initialized
INFO - 2017-02-16 16:35:23 --> URI Class Initialized
INFO - 2017-02-16 16:35:23 --> Router Class Initialized
INFO - 2017-02-16 16:35:23 --> Output Class Initialized
INFO - 2017-02-16 16:35:23 --> Security Class Initialized
DEBUG - 2017-02-16 16:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:35:23 --> Input Class Initialized
INFO - 2017-02-16 16:35:23 --> Language Class Initialized
INFO - 2017-02-16 16:35:23 --> Loader Class Initialized
INFO - 2017-02-16 16:35:23 --> Helper loaded: url_helper
INFO - 2017-02-16 16:35:23 --> Helper loaded: language_helper
INFO - 2017-02-16 16:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:35:23 --> Controller Class Initialized
INFO - 2017-02-16 16:35:23 --> Database Driver Class Initialized
INFO - 2017-02-16 16:35:23 --> Model Class Initialized
INFO - 2017-02-16 16:35:23 --> Model Class Initialized
INFO - 2017-02-16 16:35:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:35:23 --> Final output sent to browser
DEBUG - 2017-02-16 16:35:23 --> Total execution time: 0.1276
INFO - 2017-02-16 16:36:45 --> Config Class Initialized
INFO - 2017-02-16 16:36:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:36:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:36:45 --> Utf8 Class Initialized
INFO - 2017-02-16 16:36:45 --> URI Class Initialized
INFO - 2017-02-16 16:36:45 --> Router Class Initialized
INFO - 2017-02-16 16:36:45 --> Output Class Initialized
INFO - 2017-02-16 16:36:45 --> Security Class Initialized
DEBUG - 2017-02-16 16:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:36:45 --> Input Class Initialized
INFO - 2017-02-16 16:36:45 --> Language Class Initialized
INFO - 2017-02-16 16:36:45 --> Loader Class Initialized
INFO - 2017-02-16 16:36:45 --> Helper loaded: url_helper
INFO - 2017-02-16 16:36:45 --> Helper loaded: language_helper
INFO - 2017-02-16 16:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:36:45 --> Controller Class Initialized
INFO - 2017-02-16 16:36:45 --> Database Driver Class Initialized
INFO - 2017-02-16 16:36:45 --> Model Class Initialized
INFO - 2017-02-16 16:36:45 --> Model Class Initialized
INFO - 2017-02-16 16:36:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:36:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:36:45 --> Final output sent to browser
DEBUG - 2017-02-16 16:36:45 --> Total execution time: 0.1152
INFO - 2017-02-16 16:36:45 --> Config Class Initialized
INFO - 2017-02-16 16:36:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:36:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:36:45 --> Utf8 Class Initialized
INFO - 2017-02-16 16:36:45 --> URI Class Initialized
INFO - 2017-02-16 16:36:45 --> Router Class Initialized
INFO - 2017-02-16 16:36:45 --> Output Class Initialized
INFO - 2017-02-16 16:36:45 --> Security Class Initialized
DEBUG - 2017-02-16 16:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:36:45 --> Input Class Initialized
INFO - 2017-02-16 16:36:45 --> Language Class Initialized
INFO - 2017-02-16 16:36:45 --> Loader Class Initialized
INFO - 2017-02-16 16:36:45 --> Helper loaded: url_helper
INFO - 2017-02-16 16:36:45 --> Helper loaded: language_helper
INFO - 2017-02-16 16:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:36:45 --> Controller Class Initialized
INFO - 2017-02-16 16:36:46 --> Database Driver Class Initialized
INFO - 2017-02-16 16:36:46 --> Model Class Initialized
INFO - 2017-02-16 16:36:46 --> Model Class Initialized
INFO - 2017-02-16 16:36:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:36:46 --> Final output sent to browser
DEBUG - 2017-02-16 16:36:46 --> Total execution time: 0.1546
INFO - 2017-02-16 16:37:28 --> Config Class Initialized
INFO - 2017-02-16 16:37:28 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:37:28 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:37:28 --> Utf8 Class Initialized
INFO - 2017-02-16 16:37:28 --> URI Class Initialized
INFO - 2017-02-16 16:37:28 --> Router Class Initialized
INFO - 2017-02-16 16:37:28 --> Output Class Initialized
INFO - 2017-02-16 16:37:29 --> Security Class Initialized
DEBUG - 2017-02-16 16:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:37:29 --> Input Class Initialized
INFO - 2017-02-16 16:37:29 --> Language Class Initialized
INFO - 2017-02-16 16:37:29 --> Loader Class Initialized
INFO - 2017-02-16 16:37:29 --> Helper loaded: url_helper
INFO - 2017-02-16 16:37:29 --> Helper loaded: language_helper
INFO - 2017-02-16 16:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:37:29 --> Controller Class Initialized
INFO - 2017-02-16 16:37:29 --> Database Driver Class Initialized
INFO - 2017-02-16 16:37:29 --> Model Class Initialized
INFO - 2017-02-16 16:37:29 --> Model Class Initialized
INFO - 2017-02-16 16:37:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:37:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:37:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:37:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:37:29 --> Final output sent to browser
DEBUG - 2017-02-16 16:37:29 --> Total execution time: 0.1810
INFO - 2017-02-16 16:37:29 --> Config Class Initialized
INFO - 2017-02-16 16:37:29 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:37:29 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:37:29 --> Utf8 Class Initialized
INFO - 2017-02-16 16:37:29 --> URI Class Initialized
INFO - 2017-02-16 16:37:29 --> Router Class Initialized
INFO - 2017-02-16 16:37:29 --> Output Class Initialized
INFO - 2017-02-16 16:37:29 --> Security Class Initialized
DEBUG - 2017-02-16 16:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:37:29 --> Input Class Initialized
INFO - 2017-02-16 16:37:29 --> Language Class Initialized
INFO - 2017-02-16 16:37:29 --> Loader Class Initialized
INFO - 2017-02-16 16:37:29 --> Helper loaded: url_helper
INFO - 2017-02-16 16:37:29 --> Helper loaded: language_helper
INFO - 2017-02-16 16:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:37:29 --> Controller Class Initialized
INFO - 2017-02-16 16:37:29 --> Database Driver Class Initialized
INFO - 2017-02-16 16:37:29 --> Model Class Initialized
INFO - 2017-02-16 16:37:29 --> Model Class Initialized
INFO - 2017-02-16 16:37:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:37:29 --> Final output sent to browser
DEBUG - 2017-02-16 16:37:29 --> Total execution time: 0.1330
INFO - 2017-02-16 16:37:32 --> Config Class Initialized
INFO - 2017-02-16 16:37:32 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:37:32 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:37:32 --> Utf8 Class Initialized
INFO - 2017-02-16 16:37:32 --> URI Class Initialized
INFO - 2017-02-16 16:37:32 --> Router Class Initialized
INFO - 2017-02-16 16:37:32 --> Output Class Initialized
INFO - 2017-02-16 16:37:32 --> Security Class Initialized
DEBUG - 2017-02-16 16:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:37:32 --> Input Class Initialized
INFO - 2017-02-16 16:37:32 --> Language Class Initialized
INFO - 2017-02-16 16:37:32 --> Loader Class Initialized
INFO - 2017-02-16 16:37:32 --> Helper loaded: url_helper
INFO - 2017-02-16 16:37:32 --> Helper loaded: language_helper
INFO - 2017-02-16 16:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:37:32 --> Controller Class Initialized
INFO - 2017-02-16 16:37:32 --> Database Driver Class Initialized
INFO - 2017-02-16 16:37:32 --> Model Class Initialized
INFO - 2017-02-16 16:37:32 --> Model Class Initialized
INFO - 2017-02-16 16:37:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:37:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:37:32 --> Final output sent to browser
DEBUG - 2017-02-16 16:37:32 --> Total execution time: 0.1351
INFO - 2017-02-16 16:37:33 --> Config Class Initialized
INFO - 2017-02-16 16:37:33 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:37:33 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:37:33 --> Utf8 Class Initialized
INFO - 2017-02-16 16:37:33 --> URI Class Initialized
INFO - 2017-02-16 16:37:33 --> Router Class Initialized
INFO - 2017-02-16 16:37:33 --> Output Class Initialized
INFO - 2017-02-16 16:37:33 --> Security Class Initialized
DEBUG - 2017-02-16 16:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:37:33 --> Input Class Initialized
INFO - 2017-02-16 16:37:33 --> Language Class Initialized
INFO - 2017-02-16 16:37:33 --> Loader Class Initialized
INFO - 2017-02-16 16:37:33 --> Helper loaded: url_helper
INFO - 2017-02-16 16:37:33 --> Helper loaded: language_helper
INFO - 2017-02-16 16:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:37:33 --> Controller Class Initialized
INFO - 2017-02-16 16:37:33 --> Database Driver Class Initialized
INFO - 2017-02-16 16:37:33 --> Model Class Initialized
INFO - 2017-02-16 16:37:33 --> Model Class Initialized
INFO - 2017-02-16 16:37:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:37:33 --> Final output sent to browser
DEBUG - 2017-02-16 16:37:33 --> Total execution time: 0.1433
INFO - 2017-02-16 16:37:48 --> Config Class Initialized
INFO - 2017-02-16 16:37:48 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:37:48 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:37:48 --> Utf8 Class Initialized
INFO - 2017-02-16 16:37:48 --> URI Class Initialized
INFO - 2017-02-16 16:37:48 --> Router Class Initialized
INFO - 2017-02-16 16:37:48 --> Output Class Initialized
INFO - 2017-02-16 16:37:48 --> Security Class Initialized
DEBUG - 2017-02-16 16:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:37:48 --> Input Class Initialized
INFO - 2017-02-16 16:37:48 --> Language Class Initialized
INFO - 2017-02-16 16:37:48 --> Loader Class Initialized
INFO - 2017-02-16 16:37:48 --> Helper loaded: url_helper
INFO - 2017-02-16 16:37:48 --> Helper loaded: language_helper
INFO - 2017-02-16 16:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:37:48 --> Controller Class Initialized
INFO - 2017-02-16 16:37:48 --> Database Driver Class Initialized
INFO - 2017-02-16 16:37:48 --> Model Class Initialized
INFO - 2017-02-16 16:37:48 --> Model Class Initialized
INFO - 2017-02-16 16:37:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:37:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:37:48 --> Final output sent to browser
DEBUG - 2017-02-16 16:37:48 --> Total execution time: 0.1216
INFO - 2017-02-16 16:37:48 --> Config Class Initialized
INFO - 2017-02-16 16:37:48 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:37:48 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:37:48 --> Utf8 Class Initialized
INFO - 2017-02-16 16:37:48 --> URI Class Initialized
INFO - 2017-02-16 16:37:48 --> Router Class Initialized
INFO - 2017-02-16 16:37:48 --> Output Class Initialized
INFO - 2017-02-16 16:37:48 --> Security Class Initialized
DEBUG - 2017-02-16 16:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:37:48 --> Input Class Initialized
INFO - 2017-02-16 16:37:48 --> Language Class Initialized
INFO - 2017-02-16 16:37:48 --> Loader Class Initialized
INFO - 2017-02-16 16:37:48 --> Helper loaded: url_helper
INFO - 2017-02-16 16:37:48 --> Helper loaded: language_helper
INFO - 2017-02-16 16:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:37:48 --> Controller Class Initialized
INFO - 2017-02-16 16:37:48 --> Database Driver Class Initialized
INFO - 2017-02-16 16:37:48 --> Model Class Initialized
INFO - 2017-02-16 16:37:48 --> Model Class Initialized
INFO - 2017-02-16 16:37:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:37:48 --> Final output sent to browser
DEBUG - 2017-02-16 16:37:48 --> Total execution time: 0.1494
INFO - 2017-02-16 16:39:02 --> Config Class Initialized
INFO - 2017-02-16 16:39:02 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:39:02 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:39:02 --> Utf8 Class Initialized
INFO - 2017-02-16 16:39:02 --> URI Class Initialized
INFO - 2017-02-16 16:39:02 --> Router Class Initialized
INFO - 2017-02-16 16:39:02 --> Output Class Initialized
INFO - 2017-02-16 16:39:02 --> Security Class Initialized
DEBUG - 2017-02-16 16:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:39:02 --> Input Class Initialized
INFO - 2017-02-16 16:39:02 --> Language Class Initialized
INFO - 2017-02-16 16:39:02 --> Loader Class Initialized
INFO - 2017-02-16 16:39:02 --> Helper loaded: url_helper
INFO - 2017-02-16 16:39:02 --> Helper loaded: language_helper
INFO - 2017-02-16 16:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:39:02 --> Controller Class Initialized
INFO - 2017-02-16 16:39:03 --> Database Driver Class Initialized
INFO - 2017-02-16 16:39:03 --> Model Class Initialized
INFO - 2017-02-16 16:39:03 --> Model Class Initialized
INFO - 2017-02-16 16:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:39:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:39:03 --> Final output sent to browser
DEBUG - 2017-02-16 16:39:03 --> Total execution time: 0.1514
INFO - 2017-02-16 16:39:03 --> Config Class Initialized
INFO - 2017-02-16 16:39:03 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:39:03 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:39:03 --> Utf8 Class Initialized
INFO - 2017-02-16 16:39:03 --> URI Class Initialized
INFO - 2017-02-16 16:39:03 --> Router Class Initialized
INFO - 2017-02-16 16:39:03 --> Output Class Initialized
INFO - 2017-02-16 16:39:03 --> Security Class Initialized
DEBUG - 2017-02-16 16:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:39:03 --> Input Class Initialized
INFO - 2017-02-16 16:39:03 --> Language Class Initialized
INFO - 2017-02-16 16:39:03 --> Loader Class Initialized
INFO - 2017-02-16 16:39:03 --> Helper loaded: url_helper
INFO - 2017-02-16 16:39:03 --> Helper loaded: language_helper
INFO - 2017-02-16 16:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:39:03 --> Controller Class Initialized
INFO - 2017-02-16 16:39:03 --> Database Driver Class Initialized
INFO - 2017-02-16 16:39:03 --> Model Class Initialized
INFO - 2017-02-16 16:39:03 --> Model Class Initialized
INFO - 2017-02-16 16:39:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:39:03 --> Final output sent to browser
DEBUG - 2017-02-16 16:39:03 --> Total execution time: 0.1568
INFO - 2017-02-16 16:39:06 --> Config Class Initialized
INFO - 2017-02-16 16:39:06 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:39:06 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:39:06 --> Utf8 Class Initialized
INFO - 2017-02-16 16:39:06 --> URI Class Initialized
INFO - 2017-02-16 16:39:06 --> Router Class Initialized
INFO - 2017-02-16 16:39:06 --> Output Class Initialized
INFO - 2017-02-16 16:39:06 --> Security Class Initialized
DEBUG - 2017-02-16 16:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:39:06 --> Input Class Initialized
INFO - 2017-02-16 16:39:06 --> Language Class Initialized
INFO - 2017-02-16 16:39:06 --> Loader Class Initialized
INFO - 2017-02-16 16:39:06 --> Helper loaded: url_helper
INFO - 2017-02-16 16:39:06 --> Helper loaded: language_helper
INFO - 2017-02-16 16:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:39:06 --> Controller Class Initialized
INFO - 2017-02-16 16:39:06 --> Database Driver Class Initialized
INFO - 2017-02-16 16:39:06 --> Model Class Initialized
INFO - 2017-02-16 16:39:06 --> Model Class Initialized
INFO - 2017-02-16 16:39:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:39:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:39:06 --> Final output sent to browser
DEBUG - 2017-02-16 16:39:06 --> Total execution time: 0.1775
INFO - 2017-02-16 16:39:06 --> Config Class Initialized
INFO - 2017-02-16 16:39:06 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:39:06 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:39:06 --> Utf8 Class Initialized
INFO - 2017-02-16 16:39:06 --> URI Class Initialized
INFO - 2017-02-16 16:39:06 --> Router Class Initialized
INFO - 2017-02-16 16:39:06 --> Output Class Initialized
INFO - 2017-02-16 16:39:06 --> Security Class Initialized
DEBUG - 2017-02-16 16:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:39:06 --> Input Class Initialized
INFO - 2017-02-16 16:39:06 --> Language Class Initialized
INFO - 2017-02-16 16:39:06 --> Loader Class Initialized
INFO - 2017-02-16 16:39:06 --> Helper loaded: url_helper
INFO - 2017-02-16 16:39:06 --> Helper loaded: language_helper
INFO - 2017-02-16 16:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:39:06 --> Controller Class Initialized
INFO - 2017-02-16 16:39:06 --> Database Driver Class Initialized
INFO - 2017-02-16 16:39:06 --> Model Class Initialized
INFO - 2017-02-16 16:39:06 --> Model Class Initialized
INFO - 2017-02-16 16:39:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:39:06 --> Final output sent to browser
DEBUG - 2017-02-16 16:39:06 --> Total execution time: 0.1741
INFO - 2017-02-16 16:39:23 --> Config Class Initialized
INFO - 2017-02-16 16:39:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:39:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:39:23 --> Utf8 Class Initialized
INFO - 2017-02-16 16:39:23 --> URI Class Initialized
INFO - 2017-02-16 16:39:23 --> Router Class Initialized
INFO - 2017-02-16 16:39:23 --> Output Class Initialized
INFO - 2017-02-16 16:39:23 --> Security Class Initialized
DEBUG - 2017-02-16 16:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:39:23 --> Input Class Initialized
INFO - 2017-02-16 16:39:23 --> Language Class Initialized
INFO - 2017-02-16 16:39:23 --> Loader Class Initialized
INFO - 2017-02-16 16:39:23 --> Helper loaded: url_helper
INFO - 2017-02-16 16:39:23 --> Helper loaded: language_helper
INFO - 2017-02-16 16:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:39:23 --> Controller Class Initialized
INFO - 2017-02-16 16:39:23 --> Database Driver Class Initialized
INFO - 2017-02-16 16:39:23 --> Model Class Initialized
INFO - 2017-02-16 16:39:23 --> Model Class Initialized
INFO - 2017-02-16 16:39:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:39:23 --> Helper loaded: form_helper
INFO - 2017-02-16 16:39:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:39:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 16:39:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:39:23 --> Final output sent to browser
DEBUG - 2017-02-16 16:39:23 --> Total execution time: 0.3110
INFO - 2017-02-16 16:39:34 --> Config Class Initialized
INFO - 2017-02-16 16:39:34 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:39:34 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:39:34 --> Utf8 Class Initialized
INFO - 2017-02-16 16:39:34 --> URI Class Initialized
INFO - 2017-02-16 16:39:34 --> Router Class Initialized
INFO - 2017-02-16 16:39:34 --> Output Class Initialized
INFO - 2017-02-16 16:39:34 --> Security Class Initialized
DEBUG - 2017-02-16 16:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:39:34 --> Input Class Initialized
INFO - 2017-02-16 16:39:34 --> Language Class Initialized
INFO - 2017-02-16 16:39:34 --> Loader Class Initialized
INFO - 2017-02-16 16:39:34 --> Helper loaded: url_helper
INFO - 2017-02-16 16:39:34 --> Helper loaded: language_helper
INFO - 2017-02-16 16:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:39:34 --> Controller Class Initialized
INFO - 2017-02-16 16:39:34 --> Database Driver Class Initialized
INFO - 2017-02-16 16:39:35 --> Model Class Initialized
INFO - 2017-02-16 16:39:35 --> Model Class Initialized
INFO - 2017-02-16 16:39:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:39:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:39:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:39:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:39:35 --> Final output sent to browser
DEBUG - 2017-02-16 16:39:35 --> Total execution time: 0.0887
INFO - 2017-02-16 16:39:35 --> Config Class Initialized
INFO - 2017-02-16 16:39:35 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:39:35 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:39:35 --> Utf8 Class Initialized
INFO - 2017-02-16 16:39:35 --> URI Class Initialized
INFO - 2017-02-16 16:39:35 --> Router Class Initialized
INFO - 2017-02-16 16:39:35 --> Output Class Initialized
INFO - 2017-02-16 16:39:35 --> Security Class Initialized
DEBUG - 2017-02-16 16:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:39:35 --> Input Class Initialized
INFO - 2017-02-16 16:39:35 --> Language Class Initialized
INFO - 2017-02-16 16:39:35 --> Loader Class Initialized
INFO - 2017-02-16 16:39:35 --> Helper loaded: url_helper
INFO - 2017-02-16 16:39:35 --> Helper loaded: language_helper
INFO - 2017-02-16 16:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:39:35 --> Controller Class Initialized
INFO - 2017-02-16 16:39:35 --> Database Driver Class Initialized
INFO - 2017-02-16 16:39:35 --> Model Class Initialized
INFO - 2017-02-16 16:39:35 --> Model Class Initialized
INFO - 2017-02-16 16:39:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:39:35 --> Final output sent to browser
DEBUG - 2017-02-16 16:39:35 --> Total execution time: 0.1569
INFO - 2017-02-16 16:40:22 --> Config Class Initialized
INFO - 2017-02-16 16:40:22 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:40:22 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:40:22 --> Utf8 Class Initialized
INFO - 2017-02-16 16:40:22 --> URI Class Initialized
INFO - 2017-02-16 16:40:22 --> Router Class Initialized
INFO - 2017-02-16 16:40:22 --> Output Class Initialized
INFO - 2017-02-16 16:40:22 --> Security Class Initialized
DEBUG - 2017-02-16 16:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:40:22 --> Input Class Initialized
INFO - 2017-02-16 16:40:22 --> Language Class Initialized
INFO - 2017-02-16 16:40:22 --> Loader Class Initialized
INFO - 2017-02-16 16:40:22 --> Helper loaded: url_helper
INFO - 2017-02-16 16:40:22 --> Helper loaded: language_helper
INFO - 2017-02-16 16:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:40:22 --> Controller Class Initialized
INFO - 2017-02-16 16:40:22 --> Database Driver Class Initialized
INFO - 2017-02-16 16:40:22 --> Model Class Initialized
INFO - 2017-02-16 16:40:22 --> Model Class Initialized
INFO - 2017-02-16 16:40:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:40:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:40:22 --> Final output sent to browser
DEBUG - 2017-02-16 16:40:22 --> Total execution time: 0.1460
INFO - 2017-02-16 16:40:22 --> Config Class Initialized
INFO - 2017-02-16 16:40:22 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:40:22 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:40:22 --> Utf8 Class Initialized
INFO - 2017-02-16 16:40:22 --> URI Class Initialized
INFO - 2017-02-16 16:40:22 --> Router Class Initialized
INFO - 2017-02-16 16:40:22 --> Output Class Initialized
INFO - 2017-02-16 16:40:22 --> Security Class Initialized
DEBUG - 2017-02-16 16:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:40:22 --> Input Class Initialized
INFO - 2017-02-16 16:40:22 --> Language Class Initialized
INFO - 2017-02-16 16:40:22 --> Loader Class Initialized
INFO - 2017-02-16 16:40:22 --> Helper loaded: url_helper
INFO - 2017-02-16 16:40:22 --> Helper loaded: language_helper
INFO - 2017-02-16 16:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:40:22 --> Controller Class Initialized
INFO - 2017-02-16 16:40:22 --> Database Driver Class Initialized
INFO - 2017-02-16 16:40:22 --> Model Class Initialized
INFO - 2017-02-16 16:40:22 --> Model Class Initialized
INFO - 2017-02-16 16:40:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:40:22 --> Final output sent to browser
DEBUG - 2017-02-16 16:40:22 --> Total execution time: 0.1395
INFO - 2017-02-16 16:40:33 --> Config Class Initialized
INFO - 2017-02-16 16:40:33 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:40:33 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:40:33 --> Utf8 Class Initialized
INFO - 2017-02-16 16:40:33 --> URI Class Initialized
INFO - 2017-02-16 16:40:33 --> Router Class Initialized
INFO - 2017-02-16 16:40:33 --> Output Class Initialized
INFO - 2017-02-16 16:40:33 --> Security Class Initialized
DEBUG - 2017-02-16 16:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:40:33 --> Input Class Initialized
INFO - 2017-02-16 16:40:33 --> Language Class Initialized
INFO - 2017-02-16 16:40:33 --> Loader Class Initialized
INFO - 2017-02-16 16:40:33 --> Helper loaded: url_helper
INFO - 2017-02-16 16:40:33 --> Helper loaded: language_helper
INFO - 2017-02-16 16:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:40:33 --> Controller Class Initialized
INFO - 2017-02-16 16:40:33 --> Database Driver Class Initialized
INFO - 2017-02-16 16:40:33 --> Model Class Initialized
INFO - 2017-02-16 16:40:33 --> Model Class Initialized
INFO - 2017-02-16 16:40:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:40:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 16:40:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 16:40:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 16:40:33 --> Final output sent to browser
DEBUG - 2017-02-16 16:40:33 --> Total execution time: 0.0880
INFO - 2017-02-16 16:40:33 --> Config Class Initialized
INFO - 2017-02-16 16:40:33 --> Hooks Class Initialized
DEBUG - 2017-02-16 16:40:33 --> UTF-8 Support Enabled
INFO - 2017-02-16 16:40:33 --> Utf8 Class Initialized
INFO - 2017-02-16 16:40:33 --> URI Class Initialized
INFO - 2017-02-16 16:40:33 --> Router Class Initialized
INFO - 2017-02-16 16:40:33 --> Output Class Initialized
INFO - 2017-02-16 16:40:33 --> Security Class Initialized
DEBUG - 2017-02-16 16:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 16:40:33 --> Input Class Initialized
INFO - 2017-02-16 16:40:33 --> Language Class Initialized
INFO - 2017-02-16 16:40:33 --> Loader Class Initialized
INFO - 2017-02-16 16:40:33 --> Helper loaded: url_helper
INFO - 2017-02-16 16:40:33 --> Helper loaded: language_helper
INFO - 2017-02-16 16:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 16:40:33 --> Controller Class Initialized
INFO - 2017-02-16 16:40:33 --> Database Driver Class Initialized
INFO - 2017-02-16 16:40:33 --> Model Class Initialized
INFO - 2017-02-16 16:40:33 --> Model Class Initialized
INFO - 2017-02-16 16:40:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 16:40:33 --> Final output sent to browser
DEBUG - 2017-02-16 16:40:33 --> Total execution time: 0.1425
INFO - 2017-02-16 18:55:11 --> Config Class Initialized
INFO - 2017-02-16 18:55:11 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:55:11 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:55:11 --> Utf8 Class Initialized
INFO - 2017-02-16 18:55:11 --> URI Class Initialized
INFO - 2017-02-16 18:55:11 --> Router Class Initialized
INFO - 2017-02-16 18:55:11 --> Output Class Initialized
INFO - 2017-02-16 18:55:11 --> Security Class Initialized
DEBUG - 2017-02-16 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:55:11 --> Input Class Initialized
INFO - 2017-02-16 18:55:11 --> Language Class Initialized
INFO - 2017-02-16 18:55:11 --> Loader Class Initialized
INFO - 2017-02-16 18:55:11 --> Helper loaded: url_helper
INFO - 2017-02-16 18:55:11 --> Helper loaded: language_helper
INFO - 2017-02-16 18:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:55:11 --> Controller Class Initialized
INFO - 2017-02-16 18:55:11 --> Database Driver Class Initialized
INFO - 2017-02-16 18:55:11 --> Model Class Initialized
INFO - 2017-02-16 18:55:11 --> Model Class Initialized
INFO - 2017-02-16 18:55:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:55:11 --> Config Class Initialized
INFO - 2017-02-16 18:55:11 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:55:11 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:55:11 --> Utf8 Class Initialized
INFO - 2017-02-16 18:55:11 --> URI Class Initialized
INFO - 2017-02-16 18:55:11 --> Router Class Initialized
INFO - 2017-02-16 18:55:11 --> Output Class Initialized
INFO - 2017-02-16 18:55:11 --> Security Class Initialized
DEBUG - 2017-02-16 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:55:11 --> Input Class Initialized
INFO - 2017-02-16 18:55:11 --> Language Class Initialized
INFO - 2017-02-16 18:55:11 --> Loader Class Initialized
INFO - 2017-02-16 18:55:11 --> Helper loaded: url_helper
INFO - 2017-02-16 18:55:11 --> Helper loaded: language_helper
INFO - 2017-02-16 18:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:55:11 --> Controller Class Initialized
INFO - 2017-02-16 18:55:11 --> Database Driver Class Initialized
INFO - 2017-02-16 18:55:11 --> Model Class Initialized
INFO - 2017-02-16 18:55:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:55:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-16 18:55:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-16 18:55:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-16 18:55:11 --> Final output sent to browser
DEBUG - 2017-02-16 18:55:11 --> Total execution time: 0.0881
INFO - 2017-02-16 18:55:17 --> Config Class Initialized
INFO - 2017-02-16 18:55:17 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:55:17 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:55:17 --> Utf8 Class Initialized
INFO - 2017-02-16 18:55:17 --> URI Class Initialized
INFO - 2017-02-16 18:55:17 --> Router Class Initialized
INFO - 2017-02-16 18:55:17 --> Output Class Initialized
INFO - 2017-02-16 18:55:17 --> Security Class Initialized
DEBUG - 2017-02-16 18:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:55:17 --> Input Class Initialized
INFO - 2017-02-16 18:55:17 --> Language Class Initialized
INFO - 2017-02-16 18:55:17 --> Loader Class Initialized
INFO - 2017-02-16 18:55:17 --> Helper loaded: url_helper
INFO - 2017-02-16 18:55:17 --> Helper loaded: language_helper
INFO - 2017-02-16 18:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:55:17 --> Controller Class Initialized
INFO - 2017-02-16 18:55:17 --> Database Driver Class Initialized
INFO - 2017-02-16 18:55:17 --> Model Class Initialized
INFO - 2017-02-16 18:55:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:55:17 --> Config Class Initialized
INFO - 2017-02-16 18:55:17 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:55:17 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:55:17 --> Utf8 Class Initialized
INFO - 2017-02-16 18:55:17 --> URI Class Initialized
INFO - 2017-02-16 18:55:17 --> Router Class Initialized
INFO - 2017-02-16 18:55:17 --> Output Class Initialized
INFO - 2017-02-16 18:55:17 --> Security Class Initialized
DEBUG - 2017-02-16 18:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:55:17 --> Input Class Initialized
INFO - 2017-02-16 18:55:17 --> Language Class Initialized
INFO - 2017-02-16 18:55:17 --> Loader Class Initialized
INFO - 2017-02-16 18:55:17 --> Helper loaded: url_helper
INFO - 2017-02-16 18:55:17 --> Helper loaded: language_helper
INFO - 2017-02-16 18:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:55:17 --> Controller Class Initialized
INFO - 2017-02-16 18:55:17 --> Database Driver Class Initialized
INFO - 2017-02-16 18:55:17 --> Model Class Initialized
INFO - 2017-02-16 18:55:17 --> Model Class Initialized
INFO - 2017-02-16 18:55:17 --> Model Class Initialized
INFO - 2017-02-16 18:55:17 --> Model Class Initialized
INFO - 2017-02-16 18:55:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-16 18:55:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:55:17 --> Final output sent to browser
DEBUG - 2017-02-16 18:55:17 --> Total execution time: 0.1188
INFO - 2017-02-16 18:55:20 --> Config Class Initialized
INFO - 2017-02-16 18:55:20 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:55:20 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:55:20 --> Utf8 Class Initialized
INFO - 2017-02-16 18:55:20 --> URI Class Initialized
INFO - 2017-02-16 18:55:20 --> Router Class Initialized
INFO - 2017-02-16 18:55:20 --> Output Class Initialized
INFO - 2017-02-16 18:55:20 --> Security Class Initialized
DEBUG - 2017-02-16 18:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:55:20 --> Input Class Initialized
INFO - 2017-02-16 18:55:20 --> Language Class Initialized
INFO - 2017-02-16 18:55:20 --> Loader Class Initialized
INFO - 2017-02-16 18:55:20 --> Helper loaded: url_helper
INFO - 2017-02-16 18:55:20 --> Helper loaded: language_helper
INFO - 2017-02-16 18:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:55:20 --> Controller Class Initialized
INFO - 2017-02-16 18:55:20 --> Database Driver Class Initialized
INFO - 2017-02-16 18:55:20 --> Model Class Initialized
INFO - 2017-02-16 18:55:20 --> Model Class Initialized
INFO - 2017-02-16 18:55:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:55:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:55:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 18:55:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:55:20 --> Final output sent to browser
DEBUG - 2017-02-16 18:55:20 --> Total execution time: 0.0978
INFO - 2017-02-16 18:55:20 --> Config Class Initialized
INFO - 2017-02-16 18:55:20 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:55:20 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:55:20 --> Utf8 Class Initialized
INFO - 2017-02-16 18:55:20 --> URI Class Initialized
INFO - 2017-02-16 18:55:20 --> Router Class Initialized
INFO - 2017-02-16 18:55:20 --> Output Class Initialized
INFO - 2017-02-16 18:55:20 --> Security Class Initialized
DEBUG - 2017-02-16 18:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:55:20 --> Input Class Initialized
INFO - 2017-02-16 18:55:20 --> Language Class Initialized
INFO - 2017-02-16 18:55:20 --> Loader Class Initialized
INFO - 2017-02-16 18:55:20 --> Helper loaded: url_helper
INFO - 2017-02-16 18:55:20 --> Helper loaded: language_helper
INFO - 2017-02-16 18:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:55:20 --> Controller Class Initialized
INFO - 2017-02-16 18:55:20 --> Database Driver Class Initialized
INFO - 2017-02-16 18:55:20 --> Model Class Initialized
INFO - 2017-02-16 18:55:20 --> Model Class Initialized
INFO - 2017-02-16 18:55:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:55:20 --> Final output sent to browser
DEBUG - 2017-02-16 18:55:20 --> Total execution time: 0.1624
INFO - 2017-02-16 18:56:55 --> Config Class Initialized
INFO - 2017-02-16 18:56:55 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:56:55 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:56:55 --> Utf8 Class Initialized
INFO - 2017-02-16 18:56:55 --> URI Class Initialized
INFO - 2017-02-16 18:56:55 --> Router Class Initialized
INFO - 2017-02-16 18:56:55 --> Output Class Initialized
INFO - 2017-02-16 18:56:55 --> Security Class Initialized
DEBUG - 2017-02-16 18:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:56:55 --> Input Class Initialized
INFO - 2017-02-16 18:56:55 --> Language Class Initialized
INFO - 2017-02-16 18:56:55 --> Loader Class Initialized
INFO - 2017-02-16 18:56:55 --> Helper loaded: url_helper
INFO - 2017-02-16 18:56:55 --> Helper loaded: language_helper
INFO - 2017-02-16 18:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:56:55 --> Controller Class Initialized
INFO - 2017-02-16 18:56:55 --> Database Driver Class Initialized
INFO - 2017-02-16 18:56:55 --> Model Class Initialized
INFO - 2017-02-16 18:56:55 --> Model Class Initialized
INFO - 2017-02-16 18:56:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:56:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:56:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 18:56:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:56:55 --> Final output sent to browser
DEBUG - 2017-02-16 18:56:55 --> Total execution time: 0.1376
INFO - 2017-02-16 18:56:55 --> Config Class Initialized
INFO - 2017-02-16 18:56:55 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:56:55 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:56:55 --> Utf8 Class Initialized
INFO - 2017-02-16 18:56:55 --> URI Class Initialized
INFO - 2017-02-16 18:56:55 --> Router Class Initialized
INFO - 2017-02-16 18:56:55 --> Output Class Initialized
INFO - 2017-02-16 18:56:55 --> Security Class Initialized
DEBUG - 2017-02-16 18:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:56:55 --> Input Class Initialized
INFO - 2017-02-16 18:56:55 --> Language Class Initialized
INFO - 2017-02-16 18:56:55 --> Loader Class Initialized
INFO - 2017-02-16 18:56:55 --> Helper loaded: url_helper
INFO - 2017-02-16 18:56:55 --> Helper loaded: language_helper
INFO - 2017-02-16 18:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:56:55 --> Controller Class Initialized
INFO - 2017-02-16 18:56:55 --> Database Driver Class Initialized
INFO - 2017-02-16 18:56:55 --> Model Class Initialized
INFO - 2017-02-16 18:56:55 --> Model Class Initialized
INFO - 2017-02-16 18:56:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:56:55 --> Final output sent to browser
DEBUG - 2017-02-16 18:56:55 --> Total execution time: 0.1389
INFO - 2017-02-16 18:57:08 --> Config Class Initialized
INFO - 2017-02-16 18:57:08 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:57:08 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:57:08 --> Utf8 Class Initialized
INFO - 2017-02-16 18:57:08 --> URI Class Initialized
INFO - 2017-02-16 18:57:08 --> Router Class Initialized
INFO - 2017-02-16 18:57:08 --> Output Class Initialized
INFO - 2017-02-16 18:57:08 --> Security Class Initialized
DEBUG - 2017-02-16 18:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:57:08 --> Input Class Initialized
INFO - 2017-02-16 18:57:08 --> Language Class Initialized
INFO - 2017-02-16 18:57:08 --> Loader Class Initialized
INFO - 2017-02-16 18:57:08 --> Helper loaded: url_helper
INFO - 2017-02-16 18:57:08 --> Helper loaded: language_helper
INFO - 2017-02-16 18:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:57:08 --> Controller Class Initialized
INFO - 2017-02-16 18:57:08 --> Database Driver Class Initialized
INFO - 2017-02-16 18:57:08 --> Model Class Initialized
INFO - 2017-02-16 18:57:08 --> Model Class Initialized
INFO - 2017-02-16 18:57:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:57:08 --> Helper loaded: form_helper
INFO - 2017-02-16 18:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 18:57:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:57:08 --> Final output sent to browser
DEBUG - 2017-02-16 18:57:08 --> Total execution time: 0.3699
INFO - 2017-02-16 18:57:28 --> Config Class Initialized
INFO - 2017-02-16 18:57:28 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:57:28 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:57:28 --> Utf8 Class Initialized
INFO - 2017-02-16 18:57:28 --> URI Class Initialized
INFO - 2017-02-16 18:57:28 --> Router Class Initialized
INFO - 2017-02-16 18:57:28 --> Output Class Initialized
INFO - 2017-02-16 18:57:28 --> Security Class Initialized
DEBUG - 2017-02-16 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:57:28 --> Input Class Initialized
INFO - 2017-02-16 18:57:28 --> Language Class Initialized
INFO - 2017-02-16 18:57:28 --> Loader Class Initialized
INFO - 2017-02-16 18:57:28 --> Helper loaded: url_helper
INFO - 2017-02-16 18:57:28 --> Helper loaded: language_helper
INFO - 2017-02-16 18:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:57:28 --> Controller Class Initialized
INFO - 2017-02-16 18:57:28 --> Database Driver Class Initialized
INFO - 2017-02-16 18:57:28 --> Model Class Initialized
INFO - 2017-02-16 18:57:28 --> Model Class Initialized
INFO - 2017-02-16 18:57:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:57:28 --> Helper loaded: form_helper
INFO - 2017-02-16 18:57:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:57:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 18:57:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:57:29 --> Final output sent to browser
DEBUG - 2017-02-16 18:57:29 --> Total execution time: 0.3550
INFO - 2017-02-16 18:57:38 --> Config Class Initialized
INFO - 2017-02-16 18:57:38 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:57:38 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:57:38 --> Utf8 Class Initialized
INFO - 2017-02-16 18:57:38 --> URI Class Initialized
INFO - 2017-02-16 18:57:38 --> Router Class Initialized
INFO - 2017-02-16 18:57:38 --> Output Class Initialized
INFO - 2017-02-16 18:57:38 --> Security Class Initialized
DEBUG - 2017-02-16 18:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:57:38 --> Input Class Initialized
INFO - 2017-02-16 18:57:38 --> Language Class Initialized
INFO - 2017-02-16 18:57:38 --> Loader Class Initialized
INFO - 2017-02-16 18:57:38 --> Helper loaded: url_helper
INFO - 2017-02-16 18:57:38 --> Helper loaded: language_helper
INFO - 2017-02-16 18:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:57:38 --> Controller Class Initialized
INFO - 2017-02-16 18:57:39 --> Database Driver Class Initialized
INFO - 2017-02-16 18:57:39 --> Model Class Initialized
INFO - 2017-02-16 18:57:39 --> Model Class Initialized
INFO - 2017-02-16 18:57:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:57:39 --> Helper loaded: form_helper
INFO - 2017-02-16 18:57:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:57:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 18:57:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:57:39 --> Final output sent to browser
DEBUG - 2017-02-16 18:57:39 --> Total execution time: 0.3391
INFO - 2017-02-16 18:57:42 --> Config Class Initialized
INFO - 2017-02-16 18:57:42 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:57:43 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:57:43 --> Utf8 Class Initialized
INFO - 2017-02-16 18:57:43 --> URI Class Initialized
INFO - 2017-02-16 18:57:43 --> Router Class Initialized
INFO - 2017-02-16 18:57:43 --> Output Class Initialized
INFO - 2017-02-16 18:57:43 --> Security Class Initialized
DEBUG - 2017-02-16 18:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:57:43 --> Input Class Initialized
INFO - 2017-02-16 18:57:43 --> Language Class Initialized
INFO - 2017-02-16 18:57:43 --> Loader Class Initialized
INFO - 2017-02-16 18:57:43 --> Helper loaded: url_helper
INFO - 2017-02-16 18:57:43 --> Helper loaded: language_helper
INFO - 2017-02-16 18:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:57:43 --> Controller Class Initialized
INFO - 2017-02-16 18:57:43 --> Database Driver Class Initialized
INFO - 2017-02-16 18:57:43 --> Model Class Initialized
INFO - 2017-02-16 18:57:43 --> Model Class Initialized
INFO - 2017-02-16 18:57:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:57:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:57:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 18:57:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:57:43 --> Final output sent to browser
DEBUG - 2017-02-16 18:57:43 --> Total execution time: 0.1569
INFO - 2017-02-16 18:57:43 --> Config Class Initialized
INFO - 2017-02-16 18:57:43 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:57:43 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:57:43 --> Utf8 Class Initialized
INFO - 2017-02-16 18:57:43 --> URI Class Initialized
INFO - 2017-02-16 18:57:43 --> Router Class Initialized
INFO - 2017-02-16 18:57:43 --> Output Class Initialized
INFO - 2017-02-16 18:57:43 --> Security Class Initialized
DEBUG - 2017-02-16 18:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:57:43 --> Input Class Initialized
INFO - 2017-02-16 18:57:43 --> Language Class Initialized
INFO - 2017-02-16 18:57:43 --> Loader Class Initialized
INFO - 2017-02-16 18:57:43 --> Helper loaded: url_helper
INFO - 2017-02-16 18:57:43 --> Helper loaded: language_helper
INFO - 2017-02-16 18:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:57:43 --> Controller Class Initialized
INFO - 2017-02-16 18:57:43 --> Database Driver Class Initialized
INFO - 2017-02-16 18:57:43 --> Model Class Initialized
INFO - 2017-02-16 18:57:43 --> Model Class Initialized
INFO - 2017-02-16 18:57:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:57:43 --> Final output sent to browser
DEBUG - 2017-02-16 18:57:43 --> Total execution time: 0.1658
INFO - 2017-02-16 18:58:04 --> Config Class Initialized
INFO - 2017-02-16 18:58:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:58:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:58:04 --> Utf8 Class Initialized
INFO - 2017-02-16 18:58:04 --> URI Class Initialized
INFO - 2017-02-16 18:58:04 --> Router Class Initialized
INFO - 2017-02-16 18:58:04 --> Output Class Initialized
INFO - 2017-02-16 18:58:04 --> Security Class Initialized
DEBUG - 2017-02-16 18:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:58:04 --> Input Class Initialized
INFO - 2017-02-16 18:58:04 --> Language Class Initialized
INFO - 2017-02-16 18:58:04 --> Loader Class Initialized
INFO - 2017-02-16 18:58:04 --> Helper loaded: url_helper
INFO - 2017-02-16 18:58:04 --> Helper loaded: language_helper
INFO - 2017-02-16 18:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:58:04 --> Controller Class Initialized
INFO - 2017-02-16 18:58:04 --> Database Driver Class Initialized
INFO - 2017-02-16 18:58:04 --> Model Class Initialized
INFO - 2017-02-16 18:58:04 --> Model Class Initialized
INFO - 2017-02-16 18:58:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:58:04 --> Config Class Initialized
INFO - 2017-02-16 18:58:04 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:58:04 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:58:04 --> Utf8 Class Initialized
INFO - 2017-02-16 18:58:04 --> URI Class Initialized
INFO - 2017-02-16 18:58:04 --> Router Class Initialized
INFO - 2017-02-16 18:58:04 --> Output Class Initialized
INFO - 2017-02-16 18:58:04 --> Security Class Initialized
DEBUG - 2017-02-16 18:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:58:04 --> Input Class Initialized
INFO - 2017-02-16 18:58:04 --> Language Class Initialized
INFO - 2017-02-16 18:58:04 --> Loader Class Initialized
INFO - 2017-02-16 18:58:04 --> Helper loaded: url_helper
INFO - 2017-02-16 18:58:04 --> Helper loaded: language_helper
INFO - 2017-02-16 18:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:58:04 --> Controller Class Initialized
INFO - 2017-02-16 18:58:04 --> Database Driver Class Initialized
INFO - 2017-02-16 18:58:04 --> Model Class Initialized
INFO - 2017-02-16 18:58:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:58:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-16 18:58:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-16 18:58:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-16 18:58:04 --> Final output sent to browser
DEBUG - 2017-02-16 18:58:04 --> Total execution time: 0.0999
INFO - 2017-02-16 18:58:07 --> Config Class Initialized
INFO - 2017-02-16 18:58:07 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:58:07 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:58:07 --> Utf8 Class Initialized
INFO - 2017-02-16 18:58:07 --> URI Class Initialized
INFO - 2017-02-16 18:58:07 --> Router Class Initialized
INFO - 2017-02-16 18:58:07 --> Output Class Initialized
INFO - 2017-02-16 18:58:07 --> Security Class Initialized
DEBUG - 2017-02-16 18:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:58:07 --> Input Class Initialized
INFO - 2017-02-16 18:58:07 --> Language Class Initialized
INFO - 2017-02-16 18:58:07 --> Loader Class Initialized
INFO - 2017-02-16 18:58:07 --> Helper loaded: url_helper
INFO - 2017-02-16 18:58:07 --> Helper loaded: language_helper
INFO - 2017-02-16 18:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:58:07 --> Controller Class Initialized
INFO - 2017-02-16 18:58:07 --> Database Driver Class Initialized
INFO - 2017-02-16 18:58:07 --> Model Class Initialized
INFO - 2017-02-16 18:58:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:58:07 --> Helper loaded: form_helper
INFO - 2017-02-16 18:58:07 --> Form Validation Class Initialized
INFO - 2017-02-16 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-16 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:58:07 --> Final output sent to browser
DEBUG - 2017-02-16 18:58:07 --> Total execution time: 0.1200
INFO - 2017-02-16 18:58:07 --> Config Class Initialized
INFO - 2017-02-16 18:58:07 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:58:07 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:58:07 --> Utf8 Class Initialized
INFO - 2017-02-16 18:58:07 --> URI Class Initialized
INFO - 2017-02-16 18:58:07 --> Router Class Initialized
INFO - 2017-02-16 18:58:07 --> Output Class Initialized
INFO - 2017-02-16 18:58:07 --> Security Class Initialized
DEBUG - 2017-02-16 18:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:58:07 --> Input Class Initialized
INFO - 2017-02-16 18:58:07 --> Language Class Initialized
INFO - 2017-02-16 18:58:07 --> Loader Class Initialized
INFO - 2017-02-16 18:58:07 --> Helper loaded: url_helper
INFO - 2017-02-16 18:58:07 --> Helper loaded: language_helper
INFO - 2017-02-16 18:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:58:07 --> Controller Class Initialized
INFO - 2017-02-16 18:58:07 --> Database Driver Class Initialized
INFO - 2017-02-16 18:58:07 --> Model Class Initialized
INFO - 2017-02-16 18:58:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:58:07 --> Helper loaded: form_helper
INFO - 2017-02-16 18:58:07 --> Form Validation Class Initialized
INFO - 2017-02-16 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-16 18:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:58:07 --> Final output sent to browser
DEBUG - 2017-02-16 18:58:07 --> Total execution time: 0.1581
INFO - 2017-02-16 18:58:45 --> Config Class Initialized
INFO - 2017-02-16 18:58:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:58:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:58:45 --> Utf8 Class Initialized
INFO - 2017-02-16 18:58:45 --> URI Class Initialized
INFO - 2017-02-16 18:58:45 --> Router Class Initialized
INFO - 2017-02-16 18:58:45 --> Output Class Initialized
INFO - 2017-02-16 18:58:45 --> Security Class Initialized
DEBUG - 2017-02-16 18:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:58:45 --> Input Class Initialized
INFO - 2017-02-16 18:58:45 --> Language Class Initialized
INFO - 2017-02-16 18:58:45 --> Loader Class Initialized
INFO - 2017-02-16 18:58:45 --> Helper loaded: url_helper
INFO - 2017-02-16 18:58:45 --> Helper loaded: language_helper
INFO - 2017-02-16 18:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:58:45 --> Controller Class Initialized
INFO - 2017-02-16 18:58:45 --> Database Driver Class Initialized
INFO - 2017-02-16 18:58:45 --> Model Class Initialized
INFO - 2017-02-16 18:58:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:58:45 --> Helper loaded: form_helper
INFO - 2017-02-16 18:58:45 --> Form Validation Class Initialized
INFO - 2017-02-16 18:58:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:58:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-16 18:58:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:58:45 --> Final output sent to browser
DEBUG - 2017-02-16 18:58:45 --> Total execution time: 0.2031
INFO - 2017-02-16 18:59:05 --> Config Class Initialized
INFO - 2017-02-16 18:59:05 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:05 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:05 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:05 --> URI Class Initialized
INFO - 2017-02-16 18:59:05 --> Router Class Initialized
INFO - 2017-02-16 18:59:05 --> Output Class Initialized
INFO - 2017-02-16 18:59:05 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:05 --> Input Class Initialized
INFO - 2017-02-16 18:59:05 --> Language Class Initialized
INFO - 2017-02-16 18:59:05 --> Loader Class Initialized
INFO - 2017-02-16 18:59:05 --> Helper loaded: url_helper
INFO - 2017-02-16 18:59:05 --> Helper loaded: language_helper
INFO - 2017-02-16 18:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:05 --> Controller Class Initialized
INFO - 2017-02-16 18:59:05 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:05 --> Model Class Initialized
INFO - 2017-02-16 18:59:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:59:05 --> Helper loaded: form_helper
INFO - 2017-02-16 18:59:05 --> Form Validation Class Initialized
INFO - 2017-02-16 18:59:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:59:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-16 18:59:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:59:05 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:05 --> Total execution time: 0.1218
INFO - 2017-02-16 18:59:09 --> Config Class Initialized
INFO - 2017-02-16 18:59:09 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:09 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:09 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:09 --> URI Class Initialized
INFO - 2017-02-16 18:59:09 --> Router Class Initialized
INFO - 2017-02-16 18:59:09 --> Output Class Initialized
INFO - 2017-02-16 18:59:09 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:09 --> Input Class Initialized
INFO - 2017-02-16 18:59:09 --> Language Class Initialized
INFO - 2017-02-16 18:59:09 --> Loader Class Initialized
INFO - 2017-02-16 18:59:09 --> Helper loaded: url_helper
INFO - 2017-02-16 18:59:09 --> Helper loaded: language_helper
INFO - 2017-02-16 18:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:09 --> Controller Class Initialized
INFO - 2017-02-16 18:59:09 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:09 --> Model Class Initialized
INFO - 2017-02-16 18:59:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:59:09 --> Helper loaded: form_helper
INFO - 2017-02-16 18:59:09 --> Form Validation Class Initialized
INFO - 2017-02-16 18:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-16 18:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:59:09 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:09 --> Total execution time: 0.1108
INFO - 2017-02-16 18:59:16 --> Config Class Initialized
INFO - 2017-02-16 18:59:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:16 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:16 --> URI Class Initialized
INFO - 2017-02-16 18:59:16 --> Router Class Initialized
INFO - 2017-02-16 18:59:16 --> Output Class Initialized
INFO - 2017-02-16 18:59:16 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:16 --> Input Class Initialized
INFO - 2017-02-16 18:59:16 --> Language Class Initialized
INFO - 2017-02-16 18:59:16 --> Loader Class Initialized
INFO - 2017-02-16 18:59:16 --> Helper loaded: url_helper
INFO - 2017-02-16 18:59:16 --> Helper loaded: language_helper
INFO - 2017-02-16 18:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:16 --> Controller Class Initialized
INFO - 2017-02-16 18:59:16 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:16 --> Model Class Initialized
INFO - 2017-02-16 18:59:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:59:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-16 18:59:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-16 18:59:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-16 18:59:16 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:16 --> Total execution time: 0.1336
INFO - 2017-02-16 18:59:23 --> Config Class Initialized
INFO - 2017-02-16 18:59:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:23 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:23 --> URI Class Initialized
INFO - 2017-02-16 18:59:23 --> Router Class Initialized
INFO - 2017-02-16 18:59:23 --> Output Class Initialized
INFO - 2017-02-16 18:59:23 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:23 --> Input Class Initialized
INFO - 2017-02-16 18:59:23 --> Language Class Initialized
INFO - 2017-02-16 18:59:23 --> Loader Class Initialized
INFO - 2017-02-16 18:59:23 --> Helper loaded: url_helper
INFO - 2017-02-16 18:59:23 --> Helper loaded: language_helper
INFO - 2017-02-16 18:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:23 --> Controller Class Initialized
INFO - 2017-02-16 18:59:23 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:23 --> Model Class Initialized
INFO - 2017-02-16 18:59:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:59:23 --> Config Class Initialized
INFO - 2017-02-16 18:59:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:23 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:23 --> URI Class Initialized
INFO - 2017-02-16 18:59:23 --> Router Class Initialized
INFO - 2017-02-16 18:59:23 --> Output Class Initialized
INFO - 2017-02-16 18:59:23 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:23 --> Input Class Initialized
INFO - 2017-02-16 18:59:23 --> Language Class Initialized
INFO - 2017-02-16 18:59:23 --> Loader Class Initialized
INFO - 2017-02-16 18:59:23 --> Helper loaded: url_helper
INFO - 2017-02-16 18:59:23 --> Helper loaded: language_helper
INFO - 2017-02-16 18:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:23 --> Controller Class Initialized
INFO - 2017-02-16 18:59:23 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:23 --> Model Class Initialized
INFO - 2017-02-16 18:59:23 --> Model Class Initialized
INFO - 2017-02-16 18:59:23 --> Model Class Initialized
INFO - 2017-02-16 18:59:23 --> Model Class Initialized
INFO - 2017-02-16 18:59:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:59:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:59:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-16 18:59:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:59:23 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:23 --> Total execution time: 0.1918
INFO - 2017-02-16 18:59:28 --> Config Class Initialized
INFO - 2017-02-16 18:59:28 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:28 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:28 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:28 --> URI Class Initialized
INFO - 2017-02-16 18:59:28 --> Router Class Initialized
INFO - 2017-02-16 18:59:28 --> Output Class Initialized
INFO - 2017-02-16 18:59:28 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:28 --> Input Class Initialized
INFO - 2017-02-16 18:59:28 --> Language Class Initialized
INFO - 2017-02-16 18:59:28 --> Loader Class Initialized
INFO - 2017-02-16 18:59:28 --> Helper loaded: url_helper
INFO - 2017-02-16 18:59:28 --> Helper loaded: language_helper
INFO - 2017-02-16 18:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:28 --> Controller Class Initialized
INFO - 2017-02-16 18:59:28 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:28 --> Model Class Initialized
INFO - 2017-02-16 18:59:28 --> Model Class Initialized
INFO - 2017-02-16 18:59:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:59:28 --> Helper loaded: form_helper
INFO - 2017-02-16 18:59:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:59:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 18:59:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:59:28 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:28 --> Total execution time: 0.3193
INFO - 2017-02-16 18:59:53 --> Config Class Initialized
INFO - 2017-02-16 18:59:53 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:53 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:53 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:53 --> URI Class Initialized
INFO - 2017-02-16 18:59:53 --> Router Class Initialized
INFO - 2017-02-16 18:59:53 --> Output Class Initialized
INFO - 2017-02-16 18:59:53 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:53 --> Input Class Initialized
INFO - 2017-02-16 18:59:53 --> Language Class Initialized
INFO - 2017-02-16 18:59:53 --> Loader Class Initialized
INFO - 2017-02-16 18:59:53 --> Helper loaded: url_helper
INFO - 2017-02-16 18:59:53 --> Helper loaded: language_helper
INFO - 2017-02-16 18:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:53 --> Controller Class Initialized
INFO - 2017-02-16 18:59:53 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:53 --> Model Class Initialized
INFO - 2017-02-16 18:59:53 --> Model Class Initialized
INFO - 2017-02-16 18:59:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 18:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 18:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 18:59:53 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:53 --> Total execution time: 0.1550
INFO - 2017-02-16 18:59:54 --> Config Class Initialized
INFO - 2017-02-16 18:59:54 --> Hooks Class Initialized
DEBUG - 2017-02-16 18:59:54 --> UTF-8 Support Enabled
INFO - 2017-02-16 18:59:54 --> Utf8 Class Initialized
INFO - 2017-02-16 18:59:54 --> URI Class Initialized
INFO - 2017-02-16 18:59:54 --> Router Class Initialized
INFO - 2017-02-16 18:59:54 --> Output Class Initialized
INFO - 2017-02-16 18:59:54 --> Security Class Initialized
DEBUG - 2017-02-16 18:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 18:59:54 --> Input Class Initialized
INFO - 2017-02-16 18:59:54 --> Language Class Initialized
INFO - 2017-02-16 18:59:54 --> Loader Class Initialized
INFO - 2017-02-16 18:59:54 --> Helper loaded: url_helper
INFO - 2017-02-16 18:59:54 --> Helper loaded: language_helper
INFO - 2017-02-16 18:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 18:59:54 --> Controller Class Initialized
INFO - 2017-02-16 18:59:54 --> Database Driver Class Initialized
INFO - 2017-02-16 18:59:54 --> Model Class Initialized
INFO - 2017-02-16 18:59:54 --> Model Class Initialized
INFO - 2017-02-16 18:59:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 18:59:54 --> Final output sent to browser
DEBUG - 2017-02-16 18:59:54 --> Total execution time: 0.1395
INFO - 2017-02-16 19:00:16 --> Config Class Initialized
INFO - 2017-02-16 19:00:16 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:00:16 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:00:16 --> Utf8 Class Initialized
INFO - 2017-02-16 19:00:16 --> URI Class Initialized
INFO - 2017-02-16 19:00:16 --> Router Class Initialized
INFO - 2017-02-16 19:00:16 --> Output Class Initialized
INFO - 2017-02-16 19:00:16 --> Security Class Initialized
DEBUG - 2017-02-16 19:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:00:16 --> Input Class Initialized
INFO - 2017-02-16 19:00:16 --> Language Class Initialized
INFO - 2017-02-16 19:00:16 --> Loader Class Initialized
INFO - 2017-02-16 19:00:16 --> Helper loaded: url_helper
INFO - 2017-02-16 19:00:16 --> Helper loaded: language_helper
INFO - 2017-02-16 19:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:00:16 --> Controller Class Initialized
INFO - 2017-02-16 19:00:16 --> Database Driver Class Initialized
INFO - 2017-02-16 19:00:16 --> Model Class Initialized
INFO - 2017-02-16 19:00:16 --> Model Class Initialized
INFO - 2017-02-16 19:00:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:00:16 --> Helper loaded: form_helper
INFO - 2017-02-16 19:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 19:00:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:00:16 --> Final output sent to browser
DEBUG - 2017-02-16 19:00:16 --> Total execution time: 0.2804
INFO - 2017-02-16 19:03:24 --> Config Class Initialized
INFO - 2017-02-16 19:03:24 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:03:24 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:03:24 --> Utf8 Class Initialized
INFO - 2017-02-16 19:03:24 --> URI Class Initialized
INFO - 2017-02-16 19:03:24 --> Router Class Initialized
INFO - 2017-02-16 19:03:24 --> Output Class Initialized
INFO - 2017-02-16 19:03:24 --> Security Class Initialized
DEBUG - 2017-02-16 19:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:03:24 --> Input Class Initialized
INFO - 2017-02-16 19:03:24 --> Language Class Initialized
INFO - 2017-02-16 19:03:24 --> Loader Class Initialized
INFO - 2017-02-16 19:03:24 --> Helper loaded: url_helper
INFO - 2017-02-16 19:03:24 --> Helper loaded: language_helper
INFO - 2017-02-16 19:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:03:24 --> Controller Class Initialized
INFO - 2017-02-16 19:03:24 --> Database Driver Class Initialized
INFO - 2017-02-16 19:03:24 --> Model Class Initialized
INFO - 2017-02-16 19:03:24 --> Model Class Initialized
INFO - 2017-02-16 19:03:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:03:24 --> Helper loaded: form_helper
INFO - 2017-02-16 19:03:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:03:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 19:03:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:03:25 --> Final output sent to browser
DEBUG - 2017-02-16 19:03:25 --> Total execution time: 0.3440
INFO - 2017-02-16 19:03:41 --> Config Class Initialized
INFO - 2017-02-16 19:03:41 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:03:41 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:03:41 --> Utf8 Class Initialized
INFO - 2017-02-16 19:03:41 --> URI Class Initialized
INFO - 2017-02-16 19:03:41 --> Router Class Initialized
INFO - 2017-02-16 19:03:41 --> Output Class Initialized
INFO - 2017-02-16 19:03:41 --> Security Class Initialized
DEBUG - 2017-02-16 19:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:03:41 --> Input Class Initialized
INFO - 2017-02-16 19:03:41 --> Language Class Initialized
INFO - 2017-02-16 19:03:41 --> Loader Class Initialized
INFO - 2017-02-16 19:03:41 --> Helper loaded: url_helper
INFO - 2017-02-16 19:03:41 --> Helper loaded: language_helper
INFO - 2017-02-16 19:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:03:41 --> Controller Class Initialized
INFO - 2017-02-16 19:03:41 --> Database Driver Class Initialized
INFO - 2017-02-16 19:03:41 --> Model Class Initialized
INFO - 2017-02-16 19:03:41 --> Model Class Initialized
INFO - 2017-02-16 19:03:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:03:41 --> Helper loaded: form_helper
INFO - 2017-02-16 19:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 19:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:03:41 --> Final output sent to browser
DEBUG - 2017-02-16 19:03:41 --> Total execution time: 0.3433
INFO - 2017-02-16 19:04:08 --> Config Class Initialized
INFO - 2017-02-16 19:04:08 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:04:08 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:04:08 --> Utf8 Class Initialized
INFO - 2017-02-16 19:04:08 --> URI Class Initialized
INFO - 2017-02-16 19:04:08 --> Router Class Initialized
INFO - 2017-02-16 19:04:08 --> Output Class Initialized
INFO - 2017-02-16 19:04:08 --> Security Class Initialized
DEBUG - 2017-02-16 19:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:04:08 --> Input Class Initialized
INFO - 2017-02-16 19:04:08 --> Language Class Initialized
INFO - 2017-02-16 19:04:08 --> Loader Class Initialized
INFO - 2017-02-16 19:04:08 --> Helper loaded: url_helper
INFO - 2017-02-16 19:04:08 --> Helper loaded: language_helper
INFO - 2017-02-16 19:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:04:08 --> Controller Class Initialized
INFO - 2017-02-16 19:04:08 --> Database Driver Class Initialized
INFO - 2017-02-16 19:04:08 --> Model Class Initialized
INFO - 2017-02-16 19:04:08 --> Model Class Initialized
INFO - 2017-02-16 19:04:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:04:08 --> Helper loaded: form_helper
INFO - 2017-02-16 19:04:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:04:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 19:04:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:04:08 --> Final output sent to browser
DEBUG - 2017-02-16 19:04:08 --> Total execution time: 0.3447
INFO - 2017-02-16 19:04:13 --> Config Class Initialized
INFO - 2017-02-16 19:04:13 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:04:13 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:04:13 --> Utf8 Class Initialized
INFO - 2017-02-16 19:04:13 --> URI Class Initialized
INFO - 2017-02-16 19:04:13 --> Router Class Initialized
INFO - 2017-02-16 19:04:13 --> Output Class Initialized
INFO - 2017-02-16 19:04:13 --> Security Class Initialized
DEBUG - 2017-02-16 19:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:04:13 --> Input Class Initialized
INFO - 2017-02-16 19:04:13 --> Language Class Initialized
INFO - 2017-02-16 19:04:13 --> Loader Class Initialized
INFO - 2017-02-16 19:04:13 --> Helper loaded: url_helper
INFO - 2017-02-16 19:04:13 --> Helper loaded: language_helper
INFO - 2017-02-16 19:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:04:13 --> Controller Class Initialized
INFO - 2017-02-16 19:04:13 --> Database Driver Class Initialized
INFO - 2017-02-16 19:04:13 --> Model Class Initialized
INFO - 2017-02-16 19:04:13 --> Model Class Initialized
INFO - 2017-02-16 19:04:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 19:04:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:04:13 --> Final output sent to browser
DEBUG - 2017-02-16 19:04:13 --> Total execution time: 0.1116
INFO - 2017-02-16 19:04:14 --> Config Class Initialized
INFO - 2017-02-16 19:04:14 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:04:14 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:04:14 --> Utf8 Class Initialized
INFO - 2017-02-16 19:04:14 --> URI Class Initialized
INFO - 2017-02-16 19:04:14 --> Router Class Initialized
INFO - 2017-02-16 19:04:14 --> Output Class Initialized
INFO - 2017-02-16 19:04:14 --> Security Class Initialized
DEBUG - 2017-02-16 19:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:04:14 --> Input Class Initialized
INFO - 2017-02-16 19:04:14 --> Language Class Initialized
INFO - 2017-02-16 19:04:14 --> Loader Class Initialized
INFO - 2017-02-16 19:04:14 --> Helper loaded: url_helper
INFO - 2017-02-16 19:04:14 --> Helper loaded: language_helper
INFO - 2017-02-16 19:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:04:14 --> Controller Class Initialized
INFO - 2017-02-16 19:04:14 --> Database Driver Class Initialized
INFO - 2017-02-16 19:04:14 --> Model Class Initialized
INFO - 2017-02-16 19:04:14 --> Model Class Initialized
INFO - 2017-02-16 19:04:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:04:14 --> Final output sent to browser
DEBUG - 2017-02-16 19:04:14 --> Total execution time: 0.1250
INFO - 2017-02-16 19:04:25 --> Config Class Initialized
INFO - 2017-02-16 19:04:25 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:04:25 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:04:25 --> Utf8 Class Initialized
INFO - 2017-02-16 19:04:25 --> URI Class Initialized
INFO - 2017-02-16 19:04:25 --> Router Class Initialized
INFO - 2017-02-16 19:04:25 --> Output Class Initialized
INFO - 2017-02-16 19:04:25 --> Security Class Initialized
DEBUG - 2017-02-16 19:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:04:25 --> Input Class Initialized
INFO - 2017-02-16 19:04:25 --> Language Class Initialized
INFO - 2017-02-16 19:04:25 --> Loader Class Initialized
INFO - 2017-02-16 19:04:25 --> Helper loaded: url_helper
INFO - 2017-02-16 19:04:25 --> Helper loaded: language_helper
INFO - 2017-02-16 19:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:04:25 --> Controller Class Initialized
INFO - 2017-02-16 19:04:25 --> Database Driver Class Initialized
INFO - 2017-02-16 19:04:25 --> Model Class Initialized
INFO - 2017-02-16 19:04:25 --> Model Class Initialized
INFO - 2017-02-16 19:04:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:04:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:04:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 19:04:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:04:25 --> Final output sent to browser
DEBUG - 2017-02-16 19:04:25 --> Total execution time: 0.1291
INFO - 2017-02-16 19:04:25 --> Config Class Initialized
INFO - 2017-02-16 19:04:25 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:04:25 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:04:25 --> Utf8 Class Initialized
INFO - 2017-02-16 19:04:25 --> URI Class Initialized
INFO - 2017-02-16 19:04:25 --> Router Class Initialized
INFO - 2017-02-16 19:04:25 --> Output Class Initialized
INFO - 2017-02-16 19:04:25 --> Security Class Initialized
DEBUG - 2017-02-16 19:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:04:25 --> Input Class Initialized
INFO - 2017-02-16 19:04:25 --> Language Class Initialized
INFO - 2017-02-16 19:04:25 --> Loader Class Initialized
INFO - 2017-02-16 19:04:25 --> Helper loaded: url_helper
INFO - 2017-02-16 19:04:25 --> Helper loaded: language_helper
INFO - 2017-02-16 19:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:04:26 --> Controller Class Initialized
INFO - 2017-02-16 19:04:26 --> Database Driver Class Initialized
INFO - 2017-02-16 19:04:26 --> Model Class Initialized
INFO - 2017-02-16 19:04:26 --> Model Class Initialized
INFO - 2017-02-16 19:04:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:04:26 --> Final output sent to browser
DEBUG - 2017-02-16 19:04:26 --> Total execution time: 0.1458
INFO - 2017-02-16 19:04:47 --> Config Class Initialized
INFO - 2017-02-16 19:04:47 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:04:47 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:04:47 --> Utf8 Class Initialized
INFO - 2017-02-16 19:04:47 --> URI Class Initialized
INFO - 2017-02-16 19:04:47 --> Router Class Initialized
INFO - 2017-02-16 19:04:47 --> Output Class Initialized
INFO - 2017-02-16 19:04:47 --> Security Class Initialized
DEBUG - 2017-02-16 19:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:04:47 --> Input Class Initialized
INFO - 2017-02-16 19:04:47 --> Language Class Initialized
INFO - 2017-02-16 19:04:47 --> Loader Class Initialized
INFO - 2017-02-16 19:04:47 --> Helper loaded: url_helper
INFO - 2017-02-16 19:04:47 --> Helper loaded: language_helper
INFO - 2017-02-16 19:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:04:47 --> Controller Class Initialized
INFO - 2017-02-16 19:04:47 --> Database Driver Class Initialized
INFO - 2017-02-16 19:04:47 --> Model Class Initialized
INFO - 2017-02-16 19:04:47 --> Model Class Initialized
INFO - 2017-02-16 19:04:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:04:47 --> Helper loaded: form_helper
INFO - 2017-02-16 19:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 19:04:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:04:47 --> Final output sent to browser
DEBUG - 2017-02-16 19:04:47 --> Total execution time: 0.2707
INFO - 2017-02-16 19:06:10 --> Config Class Initialized
INFO - 2017-02-16 19:06:10 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:06:10 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:06:10 --> Utf8 Class Initialized
INFO - 2017-02-16 19:06:10 --> URI Class Initialized
INFO - 2017-02-16 19:06:10 --> Router Class Initialized
INFO - 2017-02-16 19:06:10 --> Output Class Initialized
INFO - 2017-02-16 19:06:10 --> Security Class Initialized
DEBUG - 2017-02-16 19:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:06:10 --> Input Class Initialized
INFO - 2017-02-16 19:06:10 --> Language Class Initialized
INFO - 2017-02-16 19:06:10 --> Loader Class Initialized
INFO - 2017-02-16 19:06:10 --> Helper loaded: url_helper
INFO - 2017-02-16 19:06:10 --> Helper loaded: language_helper
INFO - 2017-02-16 19:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:06:10 --> Controller Class Initialized
INFO - 2017-02-16 19:06:10 --> Database Driver Class Initialized
INFO - 2017-02-16 19:06:10 --> Model Class Initialized
INFO - 2017-02-16 19:06:10 --> Model Class Initialized
INFO - 2017-02-16 19:06:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:06:10 --> Helper loaded: form_helper
INFO - 2017-02-16 19:06:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:06:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 19:06:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:06:10 --> Final output sent to browser
DEBUG - 2017-02-16 19:06:10 --> Total execution time: 0.3447
INFO - 2017-02-16 19:06:22 --> Config Class Initialized
INFO - 2017-02-16 19:06:22 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:06:22 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:06:22 --> Utf8 Class Initialized
INFO - 2017-02-16 19:06:22 --> URI Class Initialized
INFO - 2017-02-16 19:06:22 --> Router Class Initialized
INFO - 2017-02-16 19:06:22 --> Output Class Initialized
INFO - 2017-02-16 19:06:22 --> Security Class Initialized
DEBUG - 2017-02-16 19:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:06:22 --> Input Class Initialized
INFO - 2017-02-16 19:06:22 --> Language Class Initialized
INFO - 2017-02-16 19:06:22 --> Loader Class Initialized
INFO - 2017-02-16 19:06:22 --> Helper loaded: url_helper
INFO - 2017-02-16 19:06:22 --> Helper loaded: language_helper
INFO - 2017-02-16 19:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:06:22 --> Controller Class Initialized
INFO - 2017-02-16 19:06:22 --> Database Driver Class Initialized
INFO - 2017-02-16 19:06:22 --> Model Class Initialized
INFO - 2017-02-16 19:06:22 --> Model Class Initialized
INFO - 2017-02-16 19:06:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:06:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:06:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-16 19:06:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:06:22 --> Final output sent to browser
DEBUG - 2017-02-16 19:06:22 --> Total execution time: 0.1734
INFO - 2017-02-16 19:06:23 --> Config Class Initialized
INFO - 2017-02-16 19:06:23 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:06:23 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:06:23 --> Utf8 Class Initialized
INFO - 2017-02-16 19:06:23 --> URI Class Initialized
INFO - 2017-02-16 19:06:23 --> Router Class Initialized
INFO - 2017-02-16 19:06:23 --> Output Class Initialized
INFO - 2017-02-16 19:06:23 --> Security Class Initialized
DEBUG - 2017-02-16 19:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:06:23 --> Input Class Initialized
INFO - 2017-02-16 19:06:23 --> Language Class Initialized
INFO - 2017-02-16 19:06:23 --> Loader Class Initialized
INFO - 2017-02-16 19:06:23 --> Helper loaded: url_helper
INFO - 2017-02-16 19:06:23 --> Helper loaded: language_helper
INFO - 2017-02-16 19:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:06:23 --> Controller Class Initialized
INFO - 2017-02-16 19:06:23 --> Database Driver Class Initialized
INFO - 2017-02-16 19:06:23 --> Model Class Initialized
INFO - 2017-02-16 19:06:23 --> Model Class Initialized
INFO - 2017-02-16 19:06:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:06:23 --> Final output sent to browser
DEBUG - 2017-02-16 19:06:23 --> Total execution time: 0.1491
INFO - 2017-02-16 19:06:31 --> Config Class Initialized
INFO - 2017-02-16 19:06:31 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:06:31 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:06:31 --> Utf8 Class Initialized
INFO - 2017-02-16 19:06:31 --> URI Class Initialized
INFO - 2017-02-16 19:06:31 --> Router Class Initialized
INFO - 2017-02-16 19:06:31 --> Output Class Initialized
INFO - 2017-02-16 19:06:31 --> Security Class Initialized
DEBUG - 2017-02-16 19:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:06:31 --> Input Class Initialized
INFO - 2017-02-16 19:06:31 --> Language Class Initialized
INFO - 2017-02-16 19:06:31 --> Loader Class Initialized
INFO - 2017-02-16 19:06:31 --> Helper loaded: url_helper
INFO - 2017-02-16 19:06:31 --> Helper loaded: language_helper
INFO - 2017-02-16 19:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:06:31 --> Controller Class Initialized
INFO - 2017-02-16 19:06:31 --> Database Driver Class Initialized
INFO - 2017-02-16 19:06:31 --> Model Class Initialized
INFO - 2017-02-16 19:06:31 --> Model Class Initialized
INFO - 2017-02-16 19:06:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:06:31 --> Helper loaded: form_helper
INFO - 2017-02-16 19:06:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:06:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 19:06:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:06:31 --> Final output sent to browser
DEBUG - 2017-02-16 19:06:31 --> Total execution time: 0.3673
INFO - 2017-02-16 19:06:34 --> Config Class Initialized
INFO - 2017-02-16 19:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:06:34 --> Utf8 Class Initialized
INFO - 2017-02-16 19:06:34 --> URI Class Initialized
INFO - 2017-02-16 19:06:34 --> Router Class Initialized
INFO - 2017-02-16 19:06:34 --> Output Class Initialized
INFO - 2017-02-16 19:06:34 --> Security Class Initialized
DEBUG - 2017-02-16 19:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:06:34 --> Input Class Initialized
INFO - 2017-02-16 19:06:34 --> Language Class Initialized
INFO - 2017-02-16 19:06:34 --> Loader Class Initialized
INFO - 2017-02-16 19:06:34 --> Helper loaded: url_helper
INFO - 2017-02-16 19:06:34 --> Helper loaded: language_helper
INFO - 2017-02-16 19:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:06:34 --> Controller Class Initialized
INFO - 2017-02-16 19:06:34 --> Database Driver Class Initialized
INFO - 2017-02-16 19:06:34 --> Model Class Initialized
INFO - 2017-02-16 19:06:34 --> Model Class Initialized
INFO - 2017-02-16 19:06:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:06:34 --> Helper loaded: form_helper
INFO - 2017-02-16 19:06:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:06:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-16 19:06:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:06:35 --> Final output sent to browser
DEBUG - 2017-02-16 19:06:35 --> Total execution time: 0.2286
INFO - 2017-02-16 19:06:38 --> Config Class Initialized
INFO - 2017-02-16 19:06:38 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:06:38 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:06:38 --> Utf8 Class Initialized
INFO - 2017-02-16 19:06:38 --> URI Class Initialized
INFO - 2017-02-16 19:06:38 --> Router Class Initialized
INFO - 2017-02-16 19:06:38 --> Output Class Initialized
INFO - 2017-02-16 19:06:38 --> Security Class Initialized
DEBUG - 2017-02-16 19:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:06:38 --> Input Class Initialized
INFO - 2017-02-16 19:06:38 --> Language Class Initialized
INFO - 2017-02-16 19:06:38 --> Loader Class Initialized
INFO - 2017-02-16 19:06:38 --> Helper loaded: url_helper
INFO - 2017-02-16 19:06:38 --> Helper loaded: language_helper
INFO - 2017-02-16 19:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:06:38 --> Controller Class Initialized
INFO - 2017-02-16 19:06:38 --> Database Driver Class Initialized
INFO - 2017-02-16 19:06:38 --> Model Class Initialized
INFO - 2017-02-16 19:06:38 --> Model Class Initialized
INFO - 2017-02-16 19:06:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:06:38 --> Helper loaded: form_helper
INFO - 2017-02-16 19:06:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:06:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-16 19:06:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:06:38 --> Final output sent to browser
DEBUG - 2017-02-16 19:06:38 --> Total execution time: 0.2203
INFO - 2017-02-16 19:06:41 --> Config Class Initialized
INFO - 2017-02-16 19:06:41 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:06:41 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:06:41 --> Utf8 Class Initialized
INFO - 2017-02-16 19:06:41 --> URI Class Initialized
INFO - 2017-02-16 19:06:41 --> Router Class Initialized
INFO - 2017-02-16 19:06:41 --> Output Class Initialized
INFO - 2017-02-16 19:06:41 --> Security Class Initialized
DEBUG - 2017-02-16 19:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:06:41 --> Input Class Initialized
INFO - 2017-02-16 19:06:41 --> Language Class Initialized
INFO - 2017-02-16 19:06:41 --> Loader Class Initialized
INFO - 2017-02-16 19:06:41 --> Helper loaded: url_helper
INFO - 2017-02-16 19:06:41 --> Helper loaded: language_helper
INFO - 2017-02-16 19:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:06:41 --> Controller Class Initialized
INFO - 2017-02-16 19:06:41 --> Database Driver Class Initialized
INFO - 2017-02-16 19:06:41 --> Model Class Initialized
INFO - 2017-02-16 19:06:41 --> Model Class Initialized
INFO - 2017-02-16 19:06:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:06:41 --> Model Class Initialized
INFO - 2017-02-16 19:06:41 --> Helper loaded: form_helper
INFO - 2017-02-16 19:06:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:06:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-16 19:06:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:06:41 --> Final output sent to browser
DEBUG - 2017-02-16 19:06:41 --> Total execution time: 0.6176
INFO - 2017-02-16 19:06:45 --> Config Class Initialized
INFO - 2017-02-16 19:06:45 --> Hooks Class Initialized
DEBUG - 2017-02-16 19:06:45 --> UTF-8 Support Enabled
INFO - 2017-02-16 19:06:45 --> Utf8 Class Initialized
INFO - 2017-02-16 19:06:45 --> URI Class Initialized
INFO - 2017-02-16 19:06:45 --> Router Class Initialized
INFO - 2017-02-16 19:06:45 --> Output Class Initialized
INFO - 2017-02-16 19:06:45 --> Security Class Initialized
DEBUG - 2017-02-16 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-16 19:06:45 --> Input Class Initialized
INFO - 2017-02-16 19:06:45 --> Language Class Initialized
INFO - 2017-02-16 19:06:45 --> Loader Class Initialized
INFO - 2017-02-16 19:06:46 --> Helper loaded: url_helper
INFO - 2017-02-16 19:06:46 --> Helper loaded: language_helper
INFO - 2017-02-16 19:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-16 19:06:46 --> Controller Class Initialized
INFO - 2017-02-16 19:06:46 --> Database Driver Class Initialized
INFO - 2017-02-16 19:06:46 --> Model Class Initialized
INFO - 2017-02-16 19:06:46 --> Model Class Initialized
INFO - 2017-02-16 19:06:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-16 19:06:46 --> Helper loaded: form_helper
INFO - 2017-02-16 19:06:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-16 19:06:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-16 19:06:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-16 19:06:46 --> Final output sent to browser
DEBUG - 2017-02-16 19:06:46 --> Total execution time: 0.2689
