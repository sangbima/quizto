<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-17 10:41:08 --> Config Class Initialized
INFO - 2017-02-17 10:41:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:08 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:08 --> URI Class Initialized
INFO - 2017-02-17 10:41:08 --> Router Class Initialized
INFO - 2017-02-17 10:41:08 --> Output Class Initialized
INFO - 2017-02-17 10:41:08 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:08 --> Input Class Initialized
INFO - 2017-02-17 10:41:08 --> Language Class Initialized
INFO - 2017-02-17 10:41:08 --> Loader Class Initialized
INFO - 2017-02-17 10:41:08 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:08 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:08 --> Controller Class Initialized
INFO - 2017-02-17 10:41:08 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:08 --> Model Class Initialized
INFO - 2017-02-17 10:41:08 --> Model Class Initialized
INFO - 2017-02-17 10:41:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:08 --> Config Class Initialized
INFO - 2017-02-17 10:41:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:08 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:08 --> URI Class Initialized
INFO - 2017-02-17 10:41:08 --> Router Class Initialized
INFO - 2017-02-17 10:41:08 --> Output Class Initialized
INFO - 2017-02-17 10:41:08 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:08 --> Input Class Initialized
INFO - 2017-02-17 10:41:08 --> Language Class Initialized
INFO - 2017-02-17 10:41:08 --> Loader Class Initialized
INFO - 2017-02-17 10:41:08 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:08 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:08 --> Controller Class Initialized
INFO - 2017-02-17 10:41:08 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:08 --> Model Class Initialized
INFO - 2017-02-17 10:41:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-17 10:41:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-17 10:41:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-17 10:41:09 --> Final output sent to browser
DEBUG - 2017-02-17 10:41:09 --> Total execution time: 0.1070
INFO - 2017-02-17 10:41:15 --> Config Class Initialized
INFO - 2017-02-17 10:41:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:15 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:15 --> URI Class Initialized
INFO - 2017-02-17 10:41:15 --> Router Class Initialized
INFO - 2017-02-17 10:41:15 --> Output Class Initialized
INFO - 2017-02-17 10:41:15 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:15 --> Input Class Initialized
INFO - 2017-02-17 10:41:15 --> Language Class Initialized
INFO - 2017-02-17 10:41:15 --> Loader Class Initialized
INFO - 2017-02-17 10:41:15 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:15 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:15 --> Controller Class Initialized
INFO - 2017-02-17 10:41:15 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:15 --> Model Class Initialized
INFO - 2017-02-17 10:41:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:16 --> Config Class Initialized
INFO - 2017-02-17 10:41:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:16 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:16 --> URI Class Initialized
INFO - 2017-02-17 10:41:16 --> Router Class Initialized
INFO - 2017-02-17 10:41:16 --> Output Class Initialized
INFO - 2017-02-17 10:41:16 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:16 --> Input Class Initialized
INFO - 2017-02-17 10:41:16 --> Language Class Initialized
INFO - 2017-02-17 10:41:16 --> Loader Class Initialized
INFO - 2017-02-17 10:41:16 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:16 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:16 --> Controller Class Initialized
INFO - 2017-02-17 10:41:16 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:16 --> Model Class Initialized
INFO - 2017-02-17 10:41:16 --> Model Class Initialized
INFO - 2017-02-17 10:41:16 --> Model Class Initialized
INFO - 2017-02-17 10:41:16 --> Model Class Initialized
INFO - 2017-02-17 10:41:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:41:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-17 10:41:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:41:16 --> Final output sent to browser
DEBUG - 2017-02-17 10:41:16 --> Total execution time: 0.1567
INFO - 2017-02-17 10:41:19 --> Config Class Initialized
INFO - 2017-02-17 10:41:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:19 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:19 --> URI Class Initialized
INFO - 2017-02-17 10:41:19 --> Router Class Initialized
INFO - 2017-02-17 10:41:19 --> Output Class Initialized
INFO - 2017-02-17 10:41:19 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:19 --> Input Class Initialized
INFO - 2017-02-17 10:41:19 --> Language Class Initialized
INFO - 2017-02-17 10:41:19 --> Loader Class Initialized
INFO - 2017-02-17 10:41:19 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:19 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:19 --> Controller Class Initialized
INFO - 2017-02-17 10:41:19 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:19 --> Model Class Initialized
INFO - 2017-02-17 10:41:19 --> Model Class Initialized
INFO - 2017-02-17 10:41:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-17 10:41:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:41:19 --> Final output sent to browser
DEBUG - 2017-02-17 10:41:19 --> Total execution time: 0.0912
INFO - 2017-02-17 10:41:29 --> Config Class Initialized
INFO - 2017-02-17 10:41:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:29 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:29 --> URI Class Initialized
INFO - 2017-02-17 10:41:29 --> Router Class Initialized
INFO - 2017-02-17 10:41:29 --> Output Class Initialized
INFO - 2017-02-17 10:41:29 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:29 --> Input Class Initialized
INFO - 2017-02-17 10:41:29 --> Language Class Initialized
INFO - 2017-02-17 10:41:29 --> Loader Class Initialized
INFO - 2017-02-17 10:41:29 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:29 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:29 --> Controller Class Initialized
INFO - 2017-02-17 10:41:29 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:29 --> Model Class Initialized
INFO - 2017-02-17 10:41:29 --> Model Class Initialized
INFO - 2017-02-17 10:41:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:29 --> Config Class Initialized
INFO - 2017-02-17 10:41:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:29 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:29 --> URI Class Initialized
INFO - 2017-02-17 10:41:29 --> Router Class Initialized
INFO - 2017-02-17 10:41:29 --> Output Class Initialized
INFO - 2017-02-17 10:41:29 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:29 --> Input Class Initialized
INFO - 2017-02-17 10:41:29 --> Language Class Initialized
INFO - 2017-02-17 10:41:29 --> Loader Class Initialized
INFO - 2017-02-17 10:41:29 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:29 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:29 --> Controller Class Initialized
INFO - 2017-02-17 10:41:29 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:29 --> Model Class Initialized
INFO - 2017-02-17 10:41:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-17 10:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-17 10:41:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-17 10:41:29 --> Final output sent to browser
DEBUG - 2017-02-17 10:41:29 --> Total execution time: 0.1159
INFO - 2017-02-17 10:41:38 --> Config Class Initialized
INFO - 2017-02-17 10:41:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:38 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:38 --> URI Class Initialized
INFO - 2017-02-17 10:41:38 --> Router Class Initialized
INFO - 2017-02-17 10:41:38 --> Output Class Initialized
INFO - 2017-02-17 10:41:38 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:38 --> Input Class Initialized
INFO - 2017-02-17 10:41:38 --> Language Class Initialized
INFO - 2017-02-17 10:41:38 --> Loader Class Initialized
INFO - 2017-02-17 10:41:38 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:38 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:38 --> Controller Class Initialized
INFO - 2017-02-17 10:41:38 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:38 --> Model Class Initialized
INFO - 2017-02-17 10:41:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:38 --> Config Class Initialized
INFO - 2017-02-17 10:41:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:38 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:38 --> URI Class Initialized
INFO - 2017-02-17 10:41:38 --> Router Class Initialized
INFO - 2017-02-17 10:41:38 --> Output Class Initialized
INFO - 2017-02-17 10:41:38 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:38 --> Input Class Initialized
INFO - 2017-02-17 10:41:38 --> Language Class Initialized
INFO - 2017-02-17 10:41:38 --> Loader Class Initialized
INFO - 2017-02-17 10:41:38 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:38 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:38 --> Controller Class Initialized
INFO - 2017-02-17 10:41:38 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:38 --> Model Class Initialized
INFO - 2017-02-17 10:41:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-17 10:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-17 10:41:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-17 10:41:38 --> Final output sent to browser
DEBUG - 2017-02-17 10:41:38 --> Total execution time: 0.1214
INFO - 2017-02-17 10:41:45 --> Config Class Initialized
INFO - 2017-02-17 10:41:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:45 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:45 --> URI Class Initialized
INFO - 2017-02-17 10:41:45 --> Router Class Initialized
INFO - 2017-02-17 10:41:45 --> Output Class Initialized
INFO - 2017-02-17 10:41:45 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:45 --> Input Class Initialized
INFO - 2017-02-17 10:41:45 --> Language Class Initialized
INFO - 2017-02-17 10:41:45 --> Loader Class Initialized
INFO - 2017-02-17 10:41:45 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:45 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:45 --> Controller Class Initialized
INFO - 2017-02-17 10:41:45 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:45 --> Model Class Initialized
INFO - 2017-02-17 10:41:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:45 --> Config Class Initialized
INFO - 2017-02-17 10:41:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:45 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:45 --> URI Class Initialized
INFO - 2017-02-17 10:41:45 --> Router Class Initialized
INFO - 2017-02-17 10:41:45 --> Output Class Initialized
INFO - 2017-02-17 10:41:45 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:45 --> Input Class Initialized
INFO - 2017-02-17 10:41:45 --> Language Class Initialized
INFO - 2017-02-17 10:41:45 --> Loader Class Initialized
INFO - 2017-02-17 10:41:45 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:45 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:45 --> Controller Class Initialized
INFO - 2017-02-17 10:41:45 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:45 --> Model Class Initialized
INFO - 2017-02-17 10:41:45 --> Model Class Initialized
INFO - 2017-02-17 10:41:45 --> Model Class Initialized
INFO - 2017-02-17 10:41:45 --> Model Class Initialized
INFO - 2017-02-17 10:41:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:41:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-17 10:41:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:41:46 --> Final output sent to browser
DEBUG - 2017-02-17 10:41:46 --> Total execution time: 0.1397
INFO - 2017-02-17 10:41:50 --> Config Class Initialized
INFO - 2017-02-17 10:41:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:50 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:50 --> URI Class Initialized
INFO - 2017-02-17 10:41:50 --> Router Class Initialized
INFO - 2017-02-17 10:41:50 --> Output Class Initialized
INFO - 2017-02-17 10:41:50 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:50 --> Input Class Initialized
INFO - 2017-02-17 10:41:50 --> Language Class Initialized
INFO - 2017-02-17 10:41:50 --> Loader Class Initialized
INFO - 2017-02-17 10:41:50 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:50 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:50 --> Controller Class Initialized
INFO - 2017-02-17 10:41:50 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:50 --> Model Class Initialized
INFO - 2017-02-17 10:41:50 --> Model Class Initialized
INFO - 2017-02-17 10:41:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:50 --> Helper loaded: form_helper
INFO - 2017-02-17 10:41:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:41:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-17 10:41:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:41:51 --> Final output sent to browser
DEBUG - 2017-02-17 10:41:51 --> Total execution time: 0.3144
INFO - 2017-02-17 10:41:55 --> Config Class Initialized
INFO - 2017-02-17 10:41:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:55 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:55 --> URI Class Initialized
INFO - 2017-02-17 10:41:55 --> Router Class Initialized
INFO - 2017-02-17 10:41:55 --> Output Class Initialized
INFO - 2017-02-17 10:41:55 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:55 --> Input Class Initialized
INFO - 2017-02-17 10:41:55 --> Language Class Initialized
INFO - 2017-02-17 10:41:55 --> Loader Class Initialized
INFO - 2017-02-17 10:41:55 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:55 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:55 --> Controller Class Initialized
INFO - 2017-02-17 10:41:55 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:55 --> Model Class Initialized
INFO - 2017-02-17 10:41:55 --> Model Class Initialized
INFO - 2017-02-17 10:41:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:55 --> Config Class Initialized
INFO - 2017-02-17 10:41:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:41:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:41:55 --> Utf8 Class Initialized
INFO - 2017-02-17 10:41:55 --> URI Class Initialized
INFO - 2017-02-17 10:41:55 --> Router Class Initialized
INFO - 2017-02-17 10:41:55 --> Output Class Initialized
INFO - 2017-02-17 10:41:55 --> Security Class Initialized
DEBUG - 2017-02-17 10:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:41:55 --> Input Class Initialized
INFO - 2017-02-17 10:41:55 --> Language Class Initialized
INFO - 2017-02-17 10:41:55 --> Loader Class Initialized
INFO - 2017-02-17 10:41:55 --> Helper loaded: url_helper
INFO - 2017-02-17 10:41:55 --> Helper loaded: language_helper
INFO - 2017-02-17 10:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:41:55 --> Controller Class Initialized
INFO - 2017-02-17 10:41:55 --> Database Driver Class Initialized
INFO - 2017-02-17 10:41:55 --> Model Class Initialized
INFO - 2017-02-17 10:41:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:41:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-17 10:41:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-17 10:41:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-17 10:41:55 --> Final output sent to browser
DEBUG - 2017-02-17 10:41:55 --> Total execution time: 0.0849
INFO - 2017-02-17 10:43:23 --> Config Class Initialized
INFO - 2017-02-17 10:43:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:43:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:43:23 --> Utf8 Class Initialized
INFO - 2017-02-17 10:43:23 --> URI Class Initialized
INFO - 2017-02-17 10:43:23 --> Router Class Initialized
INFO - 2017-02-17 10:43:23 --> Output Class Initialized
INFO - 2017-02-17 10:43:23 --> Security Class Initialized
DEBUG - 2017-02-17 10:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:43:23 --> Input Class Initialized
INFO - 2017-02-17 10:43:23 --> Language Class Initialized
INFO - 2017-02-17 10:43:23 --> Loader Class Initialized
INFO - 2017-02-17 10:43:23 --> Helper loaded: url_helper
INFO - 2017-02-17 10:43:23 --> Helper loaded: language_helper
INFO - 2017-02-17 10:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:43:23 --> Controller Class Initialized
INFO - 2017-02-17 10:43:23 --> Database Driver Class Initialized
INFO - 2017-02-17 10:43:23 --> Model Class Initialized
INFO - 2017-02-17 10:43:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:43:23 --> Config Class Initialized
INFO - 2017-02-17 10:43:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:43:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:43:23 --> Utf8 Class Initialized
INFO - 2017-02-17 10:43:23 --> URI Class Initialized
INFO - 2017-02-17 10:43:23 --> Router Class Initialized
INFO - 2017-02-17 10:43:23 --> Output Class Initialized
INFO - 2017-02-17 10:43:23 --> Security Class Initialized
DEBUG - 2017-02-17 10:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:43:23 --> Input Class Initialized
INFO - 2017-02-17 10:43:23 --> Language Class Initialized
INFO - 2017-02-17 10:43:23 --> Loader Class Initialized
INFO - 2017-02-17 10:43:23 --> Helper loaded: url_helper
INFO - 2017-02-17 10:43:23 --> Helper loaded: language_helper
INFO - 2017-02-17 10:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:43:23 --> Controller Class Initialized
INFO - 2017-02-17 10:43:23 --> Database Driver Class Initialized
INFO - 2017-02-17 10:43:23 --> Model Class Initialized
INFO - 2017-02-17 10:43:23 --> Model Class Initialized
INFO - 2017-02-17 10:43:23 --> Model Class Initialized
INFO - 2017-02-17 10:43:23 --> Model Class Initialized
INFO - 2017-02-17 10:43:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:43:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:43:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-17 10:43:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:43:23 --> Final output sent to browser
DEBUG - 2017-02-17 10:43:23 --> Total execution time: 0.1914
INFO - 2017-02-17 10:43:26 --> Config Class Initialized
INFO - 2017-02-17 10:43:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:43:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:43:26 --> Utf8 Class Initialized
INFO - 2017-02-17 10:43:26 --> URI Class Initialized
INFO - 2017-02-17 10:43:26 --> Router Class Initialized
INFO - 2017-02-17 10:43:26 --> Output Class Initialized
INFO - 2017-02-17 10:43:26 --> Security Class Initialized
DEBUG - 2017-02-17 10:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:43:26 --> Input Class Initialized
INFO - 2017-02-17 10:43:26 --> Language Class Initialized
INFO - 2017-02-17 10:43:26 --> Loader Class Initialized
INFO - 2017-02-17 10:43:26 --> Helper loaded: url_helper
INFO - 2017-02-17 10:43:26 --> Helper loaded: language_helper
INFO - 2017-02-17 10:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:43:26 --> Controller Class Initialized
INFO - 2017-02-17 10:43:26 --> Database Driver Class Initialized
INFO - 2017-02-17 10:43:26 --> Model Class Initialized
INFO - 2017-02-17 10:43:26 --> Model Class Initialized
INFO - 2017-02-17 10:43:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:43:26 --> Helper loaded: form_helper
INFO - 2017-02-17 10:43:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:43:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-17 10:43:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:43:27 --> Final output sent to browser
DEBUG - 2017-02-17 10:43:27 --> Total execution time: 0.3031
INFO - 2017-02-17 10:43:31 --> Config Class Initialized
INFO - 2017-02-17 10:43:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:43:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:43:31 --> Utf8 Class Initialized
INFO - 2017-02-17 10:43:31 --> URI Class Initialized
INFO - 2017-02-17 10:43:31 --> Router Class Initialized
INFO - 2017-02-17 10:43:31 --> Output Class Initialized
INFO - 2017-02-17 10:43:31 --> Security Class Initialized
DEBUG - 2017-02-17 10:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:43:31 --> Input Class Initialized
INFO - 2017-02-17 10:43:31 --> Language Class Initialized
INFO - 2017-02-17 10:43:31 --> Loader Class Initialized
INFO - 2017-02-17 10:43:31 --> Helper loaded: url_helper
INFO - 2017-02-17 10:43:31 --> Helper loaded: language_helper
INFO - 2017-02-17 10:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:43:31 --> Controller Class Initialized
INFO - 2017-02-17 10:43:31 --> Database Driver Class Initialized
INFO - 2017-02-17 10:43:31 --> Model Class Initialized
INFO - 2017-02-17 10:43:31 --> Model Class Initialized
INFO - 2017-02-17 10:43:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:43:31 --> Config Class Initialized
INFO - 2017-02-17 10:43:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:43:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:43:31 --> Utf8 Class Initialized
INFO - 2017-02-17 10:43:31 --> URI Class Initialized
INFO - 2017-02-17 10:43:31 --> Router Class Initialized
INFO - 2017-02-17 10:43:31 --> Output Class Initialized
INFO - 2017-02-17 10:43:31 --> Security Class Initialized
DEBUG - 2017-02-17 10:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:43:31 --> Input Class Initialized
INFO - 2017-02-17 10:43:31 --> Language Class Initialized
INFO - 2017-02-17 10:43:31 --> Loader Class Initialized
INFO - 2017-02-17 10:43:31 --> Helper loaded: url_helper
INFO - 2017-02-17 10:43:31 --> Helper loaded: language_helper
INFO - 2017-02-17 10:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:43:31 --> Controller Class Initialized
INFO - 2017-02-17 10:43:31 --> Database Driver Class Initialized
INFO - 2017-02-17 10:43:31 --> Model Class Initialized
INFO - 2017-02-17 10:43:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-17 10:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-17 10:43:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-17 10:43:31 --> Final output sent to browser
DEBUG - 2017-02-17 10:43:31 --> Total execution time: 0.1143
INFO - 2017-02-17 10:43:36 --> Config Class Initialized
INFO - 2017-02-17 10:43:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:43:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:43:36 --> Utf8 Class Initialized
INFO - 2017-02-17 10:43:36 --> URI Class Initialized
INFO - 2017-02-17 10:43:36 --> Router Class Initialized
INFO - 2017-02-17 10:43:36 --> Output Class Initialized
INFO - 2017-02-17 10:43:36 --> Security Class Initialized
DEBUG - 2017-02-17 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:43:36 --> Input Class Initialized
INFO - 2017-02-17 10:43:36 --> Language Class Initialized
INFO - 2017-02-17 10:43:36 --> Loader Class Initialized
INFO - 2017-02-17 10:43:36 --> Helper loaded: url_helper
INFO - 2017-02-17 10:43:36 --> Helper loaded: language_helper
INFO - 2017-02-17 10:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:43:36 --> Controller Class Initialized
INFO - 2017-02-17 10:43:36 --> Database Driver Class Initialized
INFO - 2017-02-17 10:43:36 --> Model Class Initialized
INFO - 2017-02-17 10:43:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:43:36 --> Config Class Initialized
INFO - 2017-02-17 10:43:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:43:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:43:36 --> Utf8 Class Initialized
INFO - 2017-02-17 10:43:36 --> URI Class Initialized
INFO - 2017-02-17 10:43:36 --> Router Class Initialized
INFO - 2017-02-17 10:43:36 --> Output Class Initialized
INFO - 2017-02-17 10:43:37 --> Security Class Initialized
DEBUG - 2017-02-17 10:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:43:37 --> Input Class Initialized
INFO - 2017-02-17 10:43:37 --> Language Class Initialized
INFO - 2017-02-17 10:43:37 --> Loader Class Initialized
INFO - 2017-02-17 10:43:37 --> Helper loaded: url_helper
INFO - 2017-02-17 10:43:37 --> Helper loaded: language_helper
INFO - 2017-02-17 10:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:43:37 --> Controller Class Initialized
INFO - 2017-02-17 10:43:37 --> Database Driver Class Initialized
INFO - 2017-02-17 10:43:37 --> Model Class Initialized
INFO - 2017-02-17 10:43:37 --> Model Class Initialized
INFO - 2017-02-17 10:43:37 --> Model Class Initialized
INFO - 2017-02-17 10:43:37 --> Model Class Initialized
INFO - 2017-02-17 10:43:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:43:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:43:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-17 10:43:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:43:37 --> Final output sent to browser
DEBUG - 2017-02-17 10:43:37 --> Total execution time: 0.1945
INFO - 2017-02-17 10:43:39 --> Config Class Initialized
INFO - 2017-02-17 10:43:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:43:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:43:39 --> Utf8 Class Initialized
INFO - 2017-02-17 10:43:39 --> URI Class Initialized
INFO - 2017-02-17 10:43:39 --> Router Class Initialized
INFO - 2017-02-17 10:43:39 --> Output Class Initialized
INFO - 2017-02-17 10:43:39 --> Security Class Initialized
DEBUG - 2017-02-17 10:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:43:39 --> Input Class Initialized
INFO - 2017-02-17 10:43:39 --> Language Class Initialized
INFO - 2017-02-17 10:43:39 --> Loader Class Initialized
INFO - 2017-02-17 10:43:39 --> Helper loaded: url_helper
INFO - 2017-02-17 10:43:39 --> Helper loaded: language_helper
INFO - 2017-02-17 10:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:43:39 --> Controller Class Initialized
INFO - 2017-02-17 10:43:39 --> Database Driver Class Initialized
INFO - 2017-02-17 10:43:39 --> Model Class Initialized
INFO - 2017-02-17 10:43:39 --> Model Class Initialized
INFO - 2017-02-17 10:43:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:43:39 --> Helper loaded: form_helper
INFO - 2017-02-17 10:43:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:43:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-17 10:43:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:43:40 --> Final output sent to browser
DEBUG - 2017-02-17 10:43:40 --> Total execution time: 0.3234
INFO - 2017-02-17 10:55:39 --> Config Class Initialized
INFO - 2017-02-17 10:55:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:55:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:55:39 --> Utf8 Class Initialized
INFO - 2017-02-17 10:55:39 --> URI Class Initialized
INFO - 2017-02-17 10:55:39 --> Router Class Initialized
INFO - 2017-02-17 10:55:39 --> Output Class Initialized
INFO - 2017-02-17 10:55:39 --> Security Class Initialized
DEBUG - 2017-02-17 10:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:55:39 --> Input Class Initialized
INFO - 2017-02-17 10:55:39 --> Language Class Initialized
INFO - 2017-02-17 10:55:39 --> Loader Class Initialized
INFO - 2017-02-17 10:55:39 --> Helper loaded: url_helper
INFO - 2017-02-17 10:55:39 --> Helper loaded: language_helper
INFO - 2017-02-17 10:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:55:39 --> Controller Class Initialized
INFO - 2017-02-17 10:55:39 --> Database Driver Class Initialized
INFO - 2017-02-17 10:55:39 --> Model Class Initialized
INFO - 2017-02-17 10:55:39 --> Model Class Initialized
INFO - 2017-02-17 10:55:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:55:39 --> Config Class Initialized
INFO - 2017-02-17 10:55:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:55:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:55:39 --> Utf8 Class Initialized
INFO - 2017-02-17 10:55:39 --> URI Class Initialized
INFO - 2017-02-17 10:55:39 --> Router Class Initialized
INFO - 2017-02-17 10:55:39 --> Output Class Initialized
INFO - 2017-02-17 10:55:39 --> Security Class Initialized
DEBUG - 2017-02-17 10:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:55:39 --> Input Class Initialized
INFO - 2017-02-17 10:55:39 --> Language Class Initialized
INFO - 2017-02-17 10:55:39 --> Loader Class Initialized
INFO - 2017-02-17 10:55:39 --> Helper loaded: url_helper
INFO - 2017-02-17 10:55:39 --> Helper loaded: language_helper
INFO - 2017-02-17 10:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:55:39 --> Controller Class Initialized
INFO - 2017-02-17 10:55:40 --> Database Driver Class Initialized
INFO - 2017-02-17 10:55:40 --> Model Class Initialized
INFO - 2017-02-17 10:55:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-17 10:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-17 10:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-17 10:55:40 --> Final output sent to browser
DEBUG - 2017-02-17 10:55:40 --> Total execution time: 0.0981
INFO - 2017-02-17 10:55:42 --> Config Class Initialized
INFO - 2017-02-17 10:55:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 10:55:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 10:55:42 --> Utf8 Class Initialized
INFO - 2017-02-17 10:55:42 --> URI Class Initialized
INFO - 2017-02-17 10:55:42 --> Router Class Initialized
INFO - 2017-02-17 10:55:42 --> Output Class Initialized
INFO - 2017-02-17 10:55:42 --> Security Class Initialized
DEBUG - 2017-02-17 10:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 10:55:42 --> Input Class Initialized
INFO - 2017-02-17 10:55:42 --> Language Class Initialized
INFO - 2017-02-17 10:55:42 --> Loader Class Initialized
INFO - 2017-02-17 10:55:42 --> Helper loaded: url_helper
INFO - 2017-02-17 10:55:42 --> Helper loaded: language_helper
INFO - 2017-02-17 10:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 10:55:42 --> Controller Class Initialized
INFO - 2017-02-17 10:55:42 --> Database Driver Class Initialized
INFO - 2017-02-17 10:55:42 --> Model Class Initialized
INFO - 2017-02-17 10:55:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 10:55:42 --> Helper loaded: form_helper
INFO - 2017-02-17 10:55:42 --> Form Validation Class Initialized
INFO - 2017-02-17 10:55:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 10:55:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 10:55:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 10:55:42 --> Final output sent to browser
DEBUG - 2017-02-17 10:55:42 --> Total execution time: 0.1428
INFO - 2017-02-17 11:00:01 --> Config Class Initialized
INFO - 2017-02-17 11:00:01 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:00:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:00:01 --> Utf8 Class Initialized
INFO - 2017-02-17 11:00:01 --> URI Class Initialized
INFO - 2017-02-17 11:00:01 --> Router Class Initialized
INFO - 2017-02-17 11:00:01 --> Output Class Initialized
INFO - 2017-02-17 11:00:01 --> Security Class Initialized
DEBUG - 2017-02-17 11:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:00:01 --> Input Class Initialized
INFO - 2017-02-17 11:00:01 --> Language Class Initialized
INFO - 2017-02-17 11:00:01 --> Loader Class Initialized
INFO - 2017-02-17 11:00:01 --> Helper loaded: url_helper
INFO - 2017-02-17 11:00:01 --> Helper loaded: language_helper
INFO - 2017-02-17 11:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:00:01 --> Controller Class Initialized
INFO - 2017-02-17 11:00:01 --> Database Driver Class Initialized
INFO - 2017-02-17 11:00:01 --> Model Class Initialized
INFO - 2017-02-17 11:00:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:00:01 --> Helper loaded: form_helper
INFO - 2017-02-17 11:00:01 --> Form Validation Class Initialized
INFO - 2017-02-17 11:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:00:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:00:01 --> Final output sent to browser
DEBUG - 2017-02-17 11:00:01 --> Total execution time: 0.1111
INFO - 2017-02-17 11:02:50 --> Config Class Initialized
INFO - 2017-02-17 11:02:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:02:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:02:50 --> Utf8 Class Initialized
INFO - 2017-02-17 11:02:50 --> URI Class Initialized
INFO - 2017-02-17 11:02:50 --> Router Class Initialized
INFO - 2017-02-17 11:02:50 --> Output Class Initialized
INFO - 2017-02-17 11:02:50 --> Security Class Initialized
DEBUG - 2017-02-17 11:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:02:50 --> Input Class Initialized
INFO - 2017-02-17 11:02:50 --> Language Class Initialized
INFO - 2017-02-17 11:02:50 --> Loader Class Initialized
INFO - 2017-02-17 11:02:50 --> Helper loaded: url_helper
INFO - 2017-02-17 11:02:50 --> Helper loaded: language_helper
INFO - 2017-02-17 11:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:02:50 --> Controller Class Initialized
INFO - 2017-02-17 11:02:50 --> Database Driver Class Initialized
INFO - 2017-02-17 11:02:50 --> Model Class Initialized
INFO - 2017-02-17 11:02:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:02:50 --> Helper loaded: form_helper
INFO - 2017-02-17 11:02:50 --> Form Validation Class Initialized
INFO - 2017-02-17 11:02:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:02:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:02:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:02:50 --> Final output sent to browser
DEBUG - 2017-02-17 11:02:50 --> Total execution time: 0.0990
INFO - 2017-02-17 11:03:20 --> Config Class Initialized
INFO - 2017-02-17 11:03:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:03:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:03:20 --> Utf8 Class Initialized
INFO - 2017-02-17 11:03:20 --> URI Class Initialized
INFO - 2017-02-17 11:03:20 --> Router Class Initialized
INFO - 2017-02-17 11:03:20 --> Output Class Initialized
INFO - 2017-02-17 11:03:20 --> Security Class Initialized
DEBUG - 2017-02-17 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:03:20 --> Input Class Initialized
INFO - 2017-02-17 11:03:20 --> Language Class Initialized
INFO - 2017-02-17 11:03:21 --> Loader Class Initialized
INFO - 2017-02-17 11:03:21 --> Helper loaded: url_helper
INFO - 2017-02-17 11:03:21 --> Helper loaded: language_helper
INFO - 2017-02-17 11:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:03:21 --> Controller Class Initialized
INFO - 2017-02-17 11:03:21 --> Database Driver Class Initialized
INFO - 2017-02-17 11:03:21 --> Model Class Initialized
INFO - 2017-02-17 11:03:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:03:21 --> Helper loaded: form_helper
INFO - 2017-02-17 11:03:21 --> Form Validation Class Initialized
INFO - 2017-02-17 11:03:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:03:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:03:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:03:21 --> Final output sent to browser
DEBUG - 2017-02-17 11:03:21 --> Total execution time: 0.1140
INFO - 2017-02-17 11:05:42 --> Config Class Initialized
INFO - 2017-02-17 11:05:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:05:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:05:42 --> Utf8 Class Initialized
INFO - 2017-02-17 11:05:42 --> URI Class Initialized
INFO - 2017-02-17 11:05:42 --> Router Class Initialized
INFO - 2017-02-17 11:05:42 --> Output Class Initialized
INFO - 2017-02-17 11:05:42 --> Security Class Initialized
DEBUG - 2017-02-17 11:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:05:42 --> Input Class Initialized
INFO - 2017-02-17 11:05:42 --> Language Class Initialized
INFO - 2017-02-17 11:05:42 --> Loader Class Initialized
INFO - 2017-02-17 11:05:42 --> Helper loaded: url_helper
INFO - 2017-02-17 11:05:42 --> Helper loaded: language_helper
INFO - 2017-02-17 11:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:05:42 --> Controller Class Initialized
INFO - 2017-02-17 11:05:43 --> Database Driver Class Initialized
INFO - 2017-02-17 11:05:43 --> Model Class Initialized
INFO - 2017-02-17 11:05:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:05:43 --> Helper loaded: form_helper
INFO - 2017-02-17 11:05:43 --> Form Validation Class Initialized
INFO - 2017-02-17 11:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:05:43 --> Final output sent to browser
DEBUG - 2017-02-17 11:05:43 --> Total execution time: 0.1870
INFO - 2017-02-17 11:05:54 --> Config Class Initialized
INFO - 2017-02-17 11:05:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:05:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:05:54 --> Utf8 Class Initialized
INFO - 2017-02-17 11:05:54 --> URI Class Initialized
INFO - 2017-02-17 11:05:54 --> Router Class Initialized
INFO - 2017-02-17 11:05:54 --> Output Class Initialized
INFO - 2017-02-17 11:05:54 --> Security Class Initialized
DEBUG - 2017-02-17 11:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:05:54 --> Input Class Initialized
INFO - 2017-02-17 11:05:54 --> Language Class Initialized
INFO - 2017-02-17 11:05:54 --> Loader Class Initialized
INFO - 2017-02-17 11:05:54 --> Helper loaded: url_helper
INFO - 2017-02-17 11:05:54 --> Helper loaded: language_helper
INFO - 2017-02-17 11:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:05:54 --> Controller Class Initialized
INFO - 2017-02-17 11:05:54 --> Database Driver Class Initialized
INFO - 2017-02-17 11:05:54 --> Model Class Initialized
INFO - 2017-02-17 11:05:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:05:54 --> Helper loaded: form_helper
INFO - 2017-02-17 11:05:54 --> Form Validation Class Initialized
INFO - 2017-02-17 11:05:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:05:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:05:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:05:54 --> Final output sent to browser
DEBUG - 2017-02-17 11:05:54 --> Total execution time: 0.1437
INFO - 2017-02-17 11:06:36 --> Config Class Initialized
INFO - 2017-02-17 11:06:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:06:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:06:36 --> Utf8 Class Initialized
INFO - 2017-02-17 11:06:36 --> URI Class Initialized
INFO - 2017-02-17 11:06:36 --> Router Class Initialized
INFO - 2017-02-17 11:06:36 --> Output Class Initialized
INFO - 2017-02-17 11:06:36 --> Security Class Initialized
DEBUG - 2017-02-17 11:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:06:36 --> Input Class Initialized
INFO - 2017-02-17 11:06:36 --> Language Class Initialized
INFO - 2017-02-17 11:06:36 --> Loader Class Initialized
INFO - 2017-02-17 11:06:36 --> Helper loaded: url_helper
INFO - 2017-02-17 11:06:36 --> Helper loaded: language_helper
INFO - 2017-02-17 11:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:06:36 --> Controller Class Initialized
INFO - 2017-02-17 11:06:36 --> Database Driver Class Initialized
INFO - 2017-02-17 11:06:36 --> Model Class Initialized
INFO - 2017-02-17 11:06:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:06:36 --> Helper loaded: form_helper
INFO - 2017-02-17 11:06:36 --> Form Validation Class Initialized
INFO - 2017-02-17 11:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:06:36 --> Final output sent to browser
DEBUG - 2017-02-17 11:06:36 --> Total execution time: 0.1413
INFO - 2017-02-17 11:06:54 --> Config Class Initialized
INFO - 2017-02-17 11:06:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:06:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:06:54 --> Utf8 Class Initialized
INFO - 2017-02-17 11:06:54 --> URI Class Initialized
INFO - 2017-02-17 11:06:54 --> Router Class Initialized
INFO - 2017-02-17 11:06:54 --> Output Class Initialized
INFO - 2017-02-17 11:06:54 --> Security Class Initialized
DEBUG - 2017-02-17 11:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:06:54 --> Input Class Initialized
INFO - 2017-02-17 11:06:54 --> Language Class Initialized
INFO - 2017-02-17 11:06:54 --> Loader Class Initialized
INFO - 2017-02-17 11:06:54 --> Helper loaded: url_helper
INFO - 2017-02-17 11:06:54 --> Helper loaded: language_helper
INFO - 2017-02-17 11:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:06:54 --> Controller Class Initialized
INFO - 2017-02-17 11:06:54 --> Database Driver Class Initialized
INFO - 2017-02-17 11:06:54 --> Model Class Initialized
INFO - 2017-02-17 11:06:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:06:54 --> Helper loaded: form_helper
INFO - 2017-02-17 11:06:54 --> Form Validation Class Initialized
INFO - 2017-02-17 11:06:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:06:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:06:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:06:54 --> Final output sent to browser
DEBUG - 2017-02-17 11:06:54 --> Total execution time: 0.1408
INFO - 2017-02-17 11:07:41 --> Config Class Initialized
INFO - 2017-02-17 11:07:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:07:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:07:41 --> Utf8 Class Initialized
INFO - 2017-02-17 11:07:41 --> URI Class Initialized
INFO - 2017-02-17 11:07:41 --> Router Class Initialized
INFO - 2017-02-17 11:07:41 --> Output Class Initialized
INFO - 2017-02-17 11:07:41 --> Security Class Initialized
DEBUG - 2017-02-17 11:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:07:41 --> Input Class Initialized
INFO - 2017-02-17 11:07:41 --> Language Class Initialized
INFO - 2017-02-17 11:07:41 --> Loader Class Initialized
INFO - 2017-02-17 11:07:41 --> Helper loaded: url_helper
INFO - 2017-02-17 11:07:41 --> Helper loaded: language_helper
INFO - 2017-02-17 11:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:07:41 --> Controller Class Initialized
INFO - 2017-02-17 11:07:41 --> Database Driver Class Initialized
INFO - 2017-02-17 11:07:41 --> Model Class Initialized
INFO - 2017-02-17 11:07:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:07:41 --> Helper loaded: form_helper
INFO - 2017-02-17 11:07:41 --> Form Validation Class Initialized
INFO - 2017-02-17 11:07:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:07:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:07:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:07:41 --> Final output sent to browser
DEBUG - 2017-02-17 11:07:41 --> Total execution time: 0.1250
INFO - 2017-02-17 11:08:12 --> Config Class Initialized
INFO - 2017-02-17 11:08:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:08:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:08:12 --> Utf8 Class Initialized
INFO - 2017-02-17 11:08:12 --> URI Class Initialized
INFO - 2017-02-17 11:08:12 --> Router Class Initialized
INFO - 2017-02-17 11:08:12 --> Output Class Initialized
INFO - 2017-02-17 11:08:12 --> Security Class Initialized
DEBUG - 2017-02-17 11:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:08:12 --> Input Class Initialized
INFO - 2017-02-17 11:08:12 --> Language Class Initialized
INFO - 2017-02-17 11:08:12 --> Loader Class Initialized
INFO - 2017-02-17 11:08:12 --> Helper loaded: url_helper
INFO - 2017-02-17 11:08:12 --> Helper loaded: language_helper
INFO - 2017-02-17 11:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:08:12 --> Controller Class Initialized
INFO - 2017-02-17 11:08:12 --> Database Driver Class Initialized
INFO - 2017-02-17 11:08:12 --> Model Class Initialized
INFO - 2017-02-17 11:08:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:08:12 --> Helper loaded: form_helper
INFO - 2017-02-17 11:08:12 --> Form Validation Class Initialized
INFO - 2017-02-17 11:08:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:08:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:08:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:08:12 --> Final output sent to browser
DEBUG - 2017-02-17 11:08:12 --> Total execution time: 0.1210
INFO - 2017-02-17 11:09:14 --> Config Class Initialized
INFO - 2017-02-17 11:09:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:09:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:09:14 --> Utf8 Class Initialized
INFO - 2017-02-17 11:09:14 --> URI Class Initialized
INFO - 2017-02-17 11:09:14 --> Router Class Initialized
INFO - 2017-02-17 11:09:14 --> Output Class Initialized
INFO - 2017-02-17 11:09:14 --> Security Class Initialized
DEBUG - 2017-02-17 11:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:09:14 --> Input Class Initialized
INFO - 2017-02-17 11:09:14 --> Language Class Initialized
INFO - 2017-02-17 11:09:14 --> Loader Class Initialized
INFO - 2017-02-17 11:09:14 --> Helper loaded: url_helper
INFO - 2017-02-17 11:09:14 --> Helper loaded: language_helper
INFO - 2017-02-17 11:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:09:14 --> Controller Class Initialized
INFO - 2017-02-17 11:09:14 --> Database Driver Class Initialized
INFO - 2017-02-17 11:09:14 --> Model Class Initialized
INFO - 2017-02-17 11:09:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:09:14 --> Helper loaded: form_helper
INFO - 2017-02-17 11:09:14 --> Form Validation Class Initialized
INFO - 2017-02-17 11:09:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:09:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:09:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:09:14 --> Final output sent to browser
DEBUG - 2017-02-17 11:09:14 --> Total execution time: 0.1126
INFO - 2017-02-17 11:10:25 --> Config Class Initialized
INFO - 2017-02-17 11:10:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:10:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:10:25 --> Utf8 Class Initialized
INFO - 2017-02-17 11:10:25 --> URI Class Initialized
INFO - 2017-02-17 11:10:25 --> Router Class Initialized
INFO - 2017-02-17 11:10:25 --> Output Class Initialized
INFO - 2017-02-17 11:10:25 --> Security Class Initialized
DEBUG - 2017-02-17 11:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:10:25 --> Input Class Initialized
INFO - 2017-02-17 11:10:25 --> Language Class Initialized
INFO - 2017-02-17 11:10:25 --> Loader Class Initialized
INFO - 2017-02-17 11:10:25 --> Helper loaded: url_helper
INFO - 2017-02-17 11:10:25 --> Helper loaded: language_helper
INFO - 2017-02-17 11:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:10:25 --> Controller Class Initialized
INFO - 2017-02-17 11:10:25 --> Database Driver Class Initialized
INFO - 2017-02-17 11:10:25 --> Model Class Initialized
INFO - 2017-02-17 11:10:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:10:25 --> Helper loaded: form_helper
INFO - 2017-02-17 11:10:25 --> Form Validation Class Initialized
INFO - 2017-02-17 11:10:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:10:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:10:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:10:25 --> Final output sent to browser
DEBUG - 2017-02-17 11:10:25 --> Total execution time: 0.1507
INFO - 2017-02-17 11:12:09 --> Config Class Initialized
INFO - 2017-02-17 11:12:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:12:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:12:09 --> Utf8 Class Initialized
INFO - 2017-02-17 11:12:09 --> URI Class Initialized
INFO - 2017-02-17 11:12:09 --> Router Class Initialized
INFO - 2017-02-17 11:12:09 --> Output Class Initialized
INFO - 2017-02-17 11:12:09 --> Security Class Initialized
DEBUG - 2017-02-17 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:12:09 --> Input Class Initialized
INFO - 2017-02-17 11:12:09 --> Language Class Initialized
INFO - 2017-02-17 11:12:09 --> Loader Class Initialized
INFO - 2017-02-17 11:12:09 --> Helper loaded: url_helper
INFO - 2017-02-17 11:12:09 --> Helper loaded: language_helper
INFO - 2017-02-17 11:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:12:09 --> Controller Class Initialized
INFO - 2017-02-17 11:12:09 --> Database Driver Class Initialized
INFO - 2017-02-17 11:12:09 --> Model Class Initialized
INFO - 2017-02-17 11:12:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:12:09 --> Helper loaded: form_helper
INFO - 2017-02-17 11:12:09 --> Form Validation Class Initialized
INFO - 2017-02-17 11:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:12:09 --> Final output sent to browser
DEBUG - 2017-02-17 11:12:09 --> Total execution time: 0.1154
INFO - 2017-02-17 11:13:13 --> Config Class Initialized
INFO - 2017-02-17 11:13:13 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:13:13 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:13:13 --> Utf8 Class Initialized
INFO - 2017-02-17 11:13:13 --> URI Class Initialized
INFO - 2017-02-17 11:13:13 --> Router Class Initialized
INFO - 2017-02-17 11:13:13 --> Output Class Initialized
INFO - 2017-02-17 11:13:13 --> Security Class Initialized
DEBUG - 2017-02-17 11:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:13:13 --> Input Class Initialized
INFO - 2017-02-17 11:13:13 --> Language Class Initialized
INFO - 2017-02-17 11:13:13 --> Loader Class Initialized
INFO - 2017-02-17 11:13:13 --> Helper loaded: url_helper
INFO - 2017-02-17 11:13:13 --> Helper loaded: language_helper
INFO - 2017-02-17 11:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:13:13 --> Controller Class Initialized
INFO - 2017-02-17 11:13:13 --> Database Driver Class Initialized
INFO - 2017-02-17 11:13:13 --> Model Class Initialized
INFO - 2017-02-17 11:13:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:13:13 --> Helper loaded: form_helper
INFO - 2017-02-17 11:13:13 --> Form Validation Class Initialized
INFO - 2017-02-17 11:13:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:13:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:13:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:13:13 --> Final output sent to browser
DEBUG - 2017-02-17 11:13:13 --> Total execution time: 0.0986
INFO - 2017-02-17 11:14:02 --> Config Class Initialized
INFO - 2017-02-17 11:14:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:14:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:14:02 --> Utf8 Class Initialized
INFO - 2017-02-17 11:14:02 --> URI Class Initialized
INFO - 2017-02-17 11:14:02 --> Router Class Initialized
INFO - 2017-02-17 11:14:02 --> Output Class Initialized
INFO - 2017-02-17 11:14:02 --> Security Class Initialized
DEBUG - 2017-02-17 11:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:14:02 --> Input Class Initialized
INFO - 2017-02-17 11:14:02 --> Language Class Initialized
INFO - 2017-02-17 11:14:02 --> Loader Class Initialized
INFO - 2017-02-17 11:14:02 --> Helper loaded: url_helper
INFO - 2017-02-17 11:14:02 --> Helper loaded: language_helper
INFO - 2017-02-17 11:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:14:02 --> Controller Class Initialized
INFO - 2017-02-17 11:14:02 --> Database Driver Class Initialized
INFO - 2017-02-17 11:14:02 --> Model Class Initialized
INFO - 2017-02-17 11:14:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:14:02 --> Helper loaded: form_helper
INFO - 2017-02-17 11:14:02 --> Form Validation Class Initialized
INFO - 2017-02-17 11:14:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:14:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:14:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:14:02 --> Final output sent to browser
DEBUG - 2017-02-17 11:14:02 --> Total execution time: 0.1115
INFO - 2017-02-17 11:14:13 --> Config Class Initialized
INFO - 2017-02-17 11:14:13 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:14:13 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:14:13 --> Utf8 Class Initialized
INFO - 2017-02-17 11:14:13 --> URI Class Initialized
INFO - 2017-02-17 11:14:13 --> Router Class Initialized
INFO - 2017-02-17 11:14:13 --> Output Class Initialized
INFO - 2017-02-17 11:14:13 --> Security Class Initialized
DEBUG - 2017-02-17 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:14:13 --> Input Class Initialized
INFO - 2017-02-17 11:14:13 --> Language Class Initialized
INFO - 2017-02-17 11:14:13 --> Loader Class Initialized
INFO - 2017-02-17 11:14:13 --> Helper loaded: url_helper
INFO - 2017-02-17 11:14:13 --> Helper loaded: language_helper
INFO - 2017-02-17 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:14:13 --> Controller Class Initialized
INFO - 2017-02-17 11:14:13 --> Database Driver Class Initialized
INFO - 2017-02-17 11:14:13 --> Model Class Initialized
INFO - 2017-02-17 11:14:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:14:13 --> Helper loaded: form_helper
INFO - 2017-02-17 11:14:13 --> Form Validation Class Initialized
INFO - 2017-02-17 11:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:14:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:14:13 --> Final output sent to browser
DEBUG - 2017-02-17 11:14:13 --> Total execution time: 0.1505
INFO - 2017-02-17 11:14:30 --> Config Class Initialized
INFO - 2017-02-17 11:14:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:14:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:14:30 --> Utf8 Class Initialized
INFO - 2017-02-17 11:14:30 --> URI Class Initialized
INFO - 2017-02-17 11:14:30 --> Router Class Initialized
INFO - 2017-02-17 11:14:30 --> Output Class Initialized
INFO - 2017-02-17 11:14:30 --> Security Class Initialized
DEBUG - 2017-02-17 11:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:14:30 --> Input Class Initialized
INFO - 2017-02-17 11:14:30 --> Language Class Initialized
INFO - 2017-02-17 11:14:30 --> Loader Class Initialized
INFO - 2017-02-17 11:14:30 --> Helper loaded: url_helper
INFO - 2017-02-17 11:14:30 --> Helper loaded: language_helper
INFO - 2017-02-17 11:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:14:30 --> Controller Class Initialized
INFO - 2017-02-17 11:14:30 --> Database Driver Class Initialized
INFO - 2017-02-17 11:14:30 --> Model Class Initialized
INFO - 2017-02-17 11:14:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:14:30 --> Helper loaded: form_helper
INFO - 2017-02-17 11:14:30 --> Form Validation Class Initialized
INFO - 2017-02-17 11:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:14:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:14:30 --> Final output sent to browser
DEBUG - 2017-02-17 11:14:30 --> Total execution time: 0.0947
INFO - 2017-02-17 11:14:58 --> Config Class Initialized
INFO - 2017-02-17 11:14:58 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:14:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:14:59 --> Utf8 Class Initialized
INFO - 2017-02-17 11:14:59 --> URI Class Initialized
INFO - 2017-02-17 11:14:59 --> Router Class Initialized
INFO - 2017-02-17 11:14:59 --> Output Class Initialized
INFO - 2017-02-17 11:14:59 --> Security Class Initialized
DEBUG - 2017-02-17 11:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:14:59 --> Input Class Initialized
INFO - 2017-02-17 11:14:59 --> Language Class Initialized
INFO - 2017-02-17 11:14:59 --> Loader Class Initialized
INFO - 2017-02-17 11:14:59 --> Helper loaded: url_helper
INFO - 2017-02-17 11:14:59 --> Helper loaded: language_helper
INFO - 2017-02-17 11:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:14:59 --> Controller Class Initialized
INFO - 2017-02-17 11:14:59 --> Database Driver Class Initialized
INFO - 2017-02-17 11:14:59 --> Model Class Initialized
INFO - 2017-02-17 11:14:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-17 11:14:59 --> Helper loaded: form_helper
INFO - 2017-02-17 11:14:59 --> Form Validation Class Initialized
INFO - 2017-02-17 11:14:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-17 11:14:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-17 11:14:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-17 11:14:59 --> Final output sent to browser
DEBUG - 2017-02-17 11:14:59 --> Total execution time: 0.1154
