<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-18 10:42:39 --> Config Class Initialized
INFO - 2017-02-18 10:42:39 --> Hooks Class Initialized
DEBUG - 2017-02-18 10:42:39 --> UTF-8 Support Enabled
INFO - 2017-02-18 10:42:39 --> Utf8 Class Initialized
INFO - 2017-02-18 10:42:39 --> URI Class Initialized
INFO - 2017-02-18 10:42:39 --> Router Class Initialized
INFO - 2017-02-18 10:42:39 --> Output Class Initialized
INFO - 2017-02-18 10:42:39 --> Security Class Initialized
DEBUG - 2017-02-18 10:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 10:42:39 --> Input Class Initialized
INFO - 2017-02-18 10:42:39 --> Language Class Initialized
INFO - 2017-02-18 10:42:39 --> Loader Class Initialized
INFO - 2017-02-18 10:42:39 --> Helper loaded: url_helper
INFO - 2017-02-18 10:42:39 --> Helper loaded: language_helper
INFO - 2017-02-18 10:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 10:42:39 --> Controller Class Initialized
INFO - 2017-02-18 10:42:39 --> Database Driver Class Initialized
INFO - 2017-02-18 10:42:39 --> Model Class Initialized
INFO - 2017-02-18 10:42:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 10:42:39 --> Helper loaded: form_helper
INFO - 2017-02-18 10:42:39 --> Form Validation Class Initialized
INFO - 2017-02-18 10:42:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 10:42:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 10:42:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 10:42:39 --> Final output sent to browser
DEBUG - 2017-02-18 10:42:39 --> Total execution time: 0.1176
INFO - 2017-02-18 10:47:42 --> Config Class Initialized
INFO - 2017-02-18 10:47:42 --> Hooks Class Initialized
DEBUG - 2017-02-18 10:47:42 --> UTF-8 Support Enabled
INFO - 2017-02-18 10:47:42 --> Utf8 Class Initialized
INFO - 2017-02-18 10:47:42 --> URI Class Initialized
INFO - 2017-02-18 10:47:42 --> Router Class Initialized
INFO - 2017-02-18 10:47:42 --> Output Class Initialized
INFO - 2017-02-18 10:47:42 --> Security Class Initialized
DEBUG - 2017-02-18 10:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 10:47:42 --> Input Class Initialized
INFO - 2017-02-18 10:47:42 --> Language Class Initialized
INFO - 2017-02-18 10:47:42 --> Loader Class Initialized
INFO - 2017-02-18 10:47:42 --> Helper loaded: url_helper
INFO - 2017-02-18 10:47:42 --> Helper loaded: language_helper
INFO - 2017-02-18 10:47:42 --> Helper loaded: html_helper
INFO - 2017-02-18 10:47:42 --> Helper loaded: form_helper
INFO - 2017-02-18 10:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 10:47:42 --> Controller Class Initialized
INFO - 2017-02-18 10:47:42 --> Database Driver Class Initialized
INFO - 2017-02-18 10:47:42 --> Model Class Initialized
INFO - 2017-02-18 10:47:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 10:47:42 --> Form Validation Class Initialized
INFO - 2017-02-18 10:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 10:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 10:47:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 10:47:42 --> Final output sent to browser
DEBUG - 2017-02-18 10:47:42 --> Total execution time: 0.0845
INFO - 2017-02-18 10:48:31 --> Config Class Initialized
INFO - 2017-02-18 10:48:31 --> Hooks Class Initialized
DEBUG - 2017-02-18 10:48:31 --> UTF-8 Support Enabled
INFO - 2017-02-18 10:48:31 --> Utf8 Class Initialized
INFO - 2017-02-18 10:48:31 --> URI Class Initialized
INFO - 2017-02-18 10:48:31 --> Router Class Initialized
INFO - 2017-02-18 10:48:31 --> Output Class Initialized
INFO - 2017-02-18 10:48:31 --> Security Class Initialized
DEBUG - 2017-02-18 10:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 10:48:31 --> Input Class Initialized
INFO - 2017-02-18 10:48:31 --> Language Class Initialized
INFO - 2017-02-18 10:48:31 --> Loader Class Initialized
INFO - 2017-02-18 10:48:31 --> Helper loaded: url_helper
INFO - 2017-02-18 10:48:31 --> Helper loaded: language_helper
INFO - 2017-02-18 10:48:31 --> Helper loaded: html_helper
INFO - 2017-02-18 10:48:31 --> Helper loaded: form_helper
INFO - 2017-02-18 10:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 10:48:31 --> Controller Class Initialized
INFO - 2017-02-18 10:48:31 --> Database Driver Class Initialized
INFO - 2017-02-18 10:48:31 --> Model Class Initialized
INFO - 2017-02-18 10:48:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 10:48:31 --> Form Validation Class Initialized
INFO - 2017-02-18 10:48:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-18 10:48:31 --> Severity: Parsing Error --> syntax error, unexpected 'for' (T_FOR) C:\wamp64\www\savsoftquiz\application\views\register_new.php 21
INFO - 2017-02-18 10:48:50 --> Config Class Initialized
INFO - 2017-02-18 10:48:50 --> Hooks Class Initialized
DEBUG - 2017-02-18 10:48:50 --> UTF-8 Support Enabled
INFO - 2017-02-18 10:48:50 --> Utf8 Class Initialized
INFO - 2017-02-18 10:48:50 --> URI Class Initialized
INFO - 2017-02-18 10:48:50 --> Router Class Initialized
INFO - 2017-02-18 10:48:50 --> Output Class Initialized
INFO - 2017-02-18 10:48:50 --> Security Class Initialized
DEBUG - 2017-02-18 10:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 10:48:50 --> Input Class Initialized
INFO - 2017-02-18 10:48:50 --> Language Class Initialized
INFO - 2017-02-18 10:48:50 --> Loader Class Initialized
INFO - 2017-02-18 10:48:50 --> Helper loaded: url_helper
INFO - 2017-02-18 10:48:50 --> Helper loaded: language_helper
INFO - 2017-02-18 10:48:50 --> Helper loaded: html_helper
INFO - 2017-02-18 10:48:50 --> Helper loaded: form_helper
INFO - 2017-02-18 10:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 10:48:50 --> Controller Class Initialized
INFO - 2017-02-18 10:48:50 --> Database Driver Class Initialized
INFO - 2017-02-18 10:48:50 --> Model Class Initialized
INFO - 2017-02-18 10:48:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 10:48:50 --> Form Validation Class Initialized
INFO - 2017-02-18 10:48:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 10:48:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 10:48:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 10:48:50 --> Final output sent to browser
DEBUG - 2017-02-18 10:48:50 --> Total execution time: 0.0789
INFO - 2017-02-18 10:54:16 --> Config Class Initialized
INFO - 2017-02-18 10:54:16 --> Hooks Class Initialized
DEBUG - 2017-02-18 10:54:16 --> UTF-8 Support Enabled
INFO - 2017-02-18 10:54:16 --> Utf8 Class Initialized
INFO - 2017-02-18 10:54:16 --> URI Class Initialized
INFO - 2017-02-18 10:54:16 --> Router Class Initialized
INFO - 2017-02-18 10:54:16 --> Output Class Initialized
INFO - 2017-02-18 10:54:16 --> Security Class Initialized
DEBUG - 2017-02-18 10:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 10:54:16 --> Input Class Initialized
INFO - 2017-02-18 10:54:16 --> Language Class Initialized
INFO - 2017-02-18 10:54:16 --> Loader Class Initialized
INFO - 2017-02-18 10:54:16 --> Helper loaded: url_helper
INFO - 2017-02-18 10:54:16 --> Helper loaded: language_helper
INFO - 2017-02-18 10:54:16 --> Helper loaded: html_helper
INFO - 2017-02-18 10:54:16 --> Helper loaded: form_helper
INFO - 2017-02-18 10:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 10:54:16 --> Controller Class Initialized
INFO - 2017-02-18 10:54:16 --> Database Driver Class Initialized
INFO - 2017-02-18 10:54:16 --> Model Class Initialized
INFO - 2017-02-18 10:54:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 10:54:16 --> Form Validation Class Initialized
INFO - 2017-02-18 10:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 10:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 10:54:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 10:54:16 --> Final output sent to browser
DEBUG - 2017-02-18 10:54:16 --> Total execution time: 0.1036
INFO - 2017-02-18 10:55:07 --> Config Class Initialized
INFO - 2017-02-18 10:55:07 --> Hooks Class Initialized
DEBUG - 2017-02-18 10:55:07 --> UTF-8 Support Enabled
INFO - 2017-02-18 10:55:07 --> Utf8 Class Initialized
INFO - 2017-02-18 10:55:07 --> URI Class Initialized
INFO - 2017-02-18 10:55:07 --> Router Class Initialized
INFO - 2017-02-18 10:55:07 --> Output Class Initialized
INFO - 2017-02-18 10:55:07 --> Security Class Initialized
DEBUG - 2017-02-18 10:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 10:55:07 --> Input Class Initialized
INFO - 2017-02-18 10:55:07 --> Language Class Initialized
INFO - 2017-02-18 10:55:07 --> Loader Class Initialized
INFO - 2017-02-18 10:55:07 --> Helper loaded: url_helper
INFO - 2017-02-18 10:55:07 --> Helper loaded: language_helper
INFO - 2017-02-18 10:55:07 --> Helper loaded: html_helper
INFO - 2017-02-18 10:55:07 --> Helper loaded: form_helper
INFO - 2017-02-18 10:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 10:55:07 --> Controller Class Initialized
INFO - 2017-02-18 10:55:07 --> Database Driver Class Initialized
INFO - 2017-02-18 10:55:07 --> Model Class Initialized
INFO - 2017-02-18 10:55:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 10:55:07 --> Form Validation Class Initialized
INFO - 2017-02-18 10:55:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 10:55:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 10:55:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 10:55:07 --> Final output sent to browser
DEBUG - 2017-02-18 10:55:07 --> Total execution time: 0.0789
INFO - 2017-02-18 11:00:13 --> Config Class Initialized
INFO - 2017-02-18 11:00:13 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:00:13 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:00:13 --> Utf8 Class Initialized
INFO - 2017-02-18 11:00:13 --> URI Class Initialized
INFO - 2017-02-18 11:00:13 --> Router Class Initialized
INFO - 2017-02-18 11:00:13 --> Output Class Initialized
INFO - 2017-02-18 11:00:13 --> Security Class Initialized
DEBUG - 2017-02-18 11:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:00:13 --> Input Class Initialized
INFO - 2017-02-18 11:00:13 --> Language Class Initialized
INFO - 2017-02-18 11:00:13 --> Loader Class Initialized
INFO - 2017-02-18 11:00:13 --> Helper loaded: url_helper
INFO - 2017-02-18 11:00:13 --> Helper loaded: language_helper
INFO - 2017-02-18 11:00:13 --> Helper loaded: html_helper
INFO - 2017-02-18 11:00:13 --> Helper loaded: form_helper
INFO - 2017-02-18 11:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:00:13 --> Controller Class Initialized
INFO - 2017-02-18 11:00:13 --> Database Driver Class Initialized
INFO - 2017-02-18 11:00:13 --> Model Class Initialized
INFO - 2017-02-18 11:00:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:00:13 --> Form Validation Class Initialized
INFO - 2017-02-18 11:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:00:13 --> Final output sent to browser
DEBUG - 2017-02-18 11:00:13 --> Total execution time: 0.0836
INFO - 2017-02-18 11:00:29 --> Config Class Initialized
INFO - 2017-02-18 11:00:29 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:00:29 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:00:29 --> Utf8 Class Initialized
INFO - 2017-02-18 11:00:29 --> URI Class Initialized
INFO - 2017-02-18 11:00:29 --> Router Class Initialized
INFO - 2017-02-18 11:00:29 --> Output Class Initialized
INFO - 2017-02-18 11:00:29 --> Security Class Initialized
DEBUG - 2017-02-18 11:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:00:29 --> Input Class Initialized
INFO - 2017-02-18 11:00:29 --> Language Class Initialized
INFO - 2017-02-18 11:00:29 --> Loader Class Initialized
INFO - 2017-02-18 11:00:29 --> Helper loaded: url_helper
INFO - 2017-02-18 11:00:29 --> Helper loaded: language_helper
INFO - 2017-02-18 11:00:29 --> Helper loaded: html_helper
INFO - 2017-02-18 11:00:29 --> Helper loaded: form_helper
INFO - 2017-02-18 11:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:00:29 --> Controller Class Initialized
INFO - 2017-02-18 11:00:29 --> Database Driver Class Initialized
INFO - 2017-02-18 11:00:29 --> Model Class Initialized
INFO - 2017-02-18 11:00:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:00:29 --> Form Validation Class Initialized
INFO - 2017-02-18 11:00:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:00:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:00:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:00:29 --> Final output sent to browser
DEBUG - 2017-02-18 11:00:29 --> Total execution time: 0.0789
INFO - 2017-02-18 11:06:32 --> Config Class Initialized
INFO - 2017-02-18 11:06:32 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:06:32 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:06:32 --> Utf8 Class Initialized
INFO - 2017-02-18 11:06:32 --> URI Class Initialized
INFO - 2017-02-18 11:06:32 --> Router Class Initialized
INFO - 2017-02-18 11:06:32 --> Output Class Initialized
INFO - 2017-02-18 11:06:32 --> Security Class Initialized
DEBUG - 2017-02-18 11:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:06:32 --> Input Class Initialized
INFO - 2017-02-18 11:06:32 --> Language Class Initialized
INFO - 2017-02-18 11:06:32 --> Loader Class Initialized
INFO - 2017-02-18 11:06:32 --> Helper loaded: url_helper
INFO - 2017-02-18 11:06:32 --> Helper loaded: language_helper
INFO - 2017-02-18 11:06:32 --> Helper loaded: html_helper
INFO - 2017-02-18 11:06:32 --> Helper loaded: form_helper
INFO - 2017-02-18 11:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:06:32 --> Controller Class Initialized
INFO - 2017-02-18 11:06:32 --> Database Driver Class Initialized
INFO - 2017-02-18 11:06:32 --> Model Class Initialized
INFO - 2017-02-18 11:06:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:06:32 --> Form Validation Class Initialized
INFO - 2017-02-18 11:06:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:06:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:06:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:06:32 --> Final output sent to browser
DEBUG - 2017-02-18 11:06:32 --> Total execution time: 0.0850
INFO - 2017-02-18 11:12:19 --> Config Class Initialized
INFO - 2017-02-18 11:12:19 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:12:19 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:12:19 --> Utf8 Class Initialized
INFO - 2017-02-18 11:12:19 --> URI Class Initialized
INFO - 2017-02-18 11:12:19 --> Router Class Initialized
INFO - 2017-02-18 11:12:19 --> Output Class Initialized
INFO - 2017-02-18 11:12:19 --> Security Class Initialized
DEBUG - 2017-02-18 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:12:19 --> Input Class Initialized
INFO - 2017-02-18 11:12:19 --> Language Class Initialized
INFO - 2017-02-18 11:12:19 --> Loader Class Initialized
INFO - 2017-02-18 11:12:19 --> Helper loaded: url_helper
INFO - 2017-02-18 11:12:19 --> Helper loaded: language_helper
INFO - 2017-02-18 11:12:19 --> Helper loaded: html_helper
INFO - 2017-02-18 11:12:19 --> Helper loaded: form_helper
INFO - 2017-02-18 11:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:12:19 --> Controller Class Initialized
INFO - 2017-02-18 11:12:19 --> Database Driver Class Initialized
INFO - 2017-02-18 11:12:19 --> Model Class Initialized
INFO - 2017-02-18 11:12:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:12:19 --> Form Validation Class Initialized
INFO - 2017-02-18 11:12:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:12:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:12:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:12:19 --> Final output sent to browser
DEBUG - 2017-02-18 11:12:19 --> Total execution time: 0.0827
INFO - 2017-02-18 11:12:22 --> Config Class Initialized
INFO - 2017-02-18 11:12:22 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:12:22 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:12:22 --> Utf8 Class Initialized
INFO - 2017-02-18 11:12:22 --> URI Class Initialized
INFO - 2017-02-18 11:12:22 --> Router Class Initialized
INFO - 2017-02-18 11:12:22 --> Output Class Initialized
INFO - 2017-02-18 11:12:22 --> Security Class Initialized
DEBUG - 2017-02-18 11:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:12:22 --> Input Class Initialized
INFO - 2017-02-18 11:12:22 --> Language Class Initialized
INFO - 2017-02-18 11:12:22 --> Loader Class Initialized
INFO - 2017-02-18 11:12:22 --> Helper loaded: url_helper
INFO - 2017-02-18 11:12:22 --> Helper loaded: language_helper
INFO - 2017-02-18 11:12:22 --> Helper loaded: html_helper
INFO - 2017-02-18 11:12:22 --> Helper loaded: form_helper
INFO - 2017-02-18 11:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:12:22 --> Controller Class Initialized
INFO - 2017-02-18 11:12:22 --> Database Driver Class Initialized
INFO - 2017-02-18 11:12:22 --> Model Class Initialized
INFO - 2017-02-18 11:12:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:12:22 --> Form Validation Class Initialized
INFO - 2017-02-18 11:12:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:12:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:12:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:12:22 --> Final output sent to browser
DEBUG - 2017-02-18 11:12:22 --> Total execution time: 0.0821
INFO - 2017-02-18 11:13:37 --> Config Class Initialized
INFO - 2017-02-18 11:13:37 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:13:37 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:13:37 --> Utf8 Class Initialized
INFO - 2017-02-18 11:13:37 --> URI Class Initialized
INFO - 2017-02-18 11:13:37 --> Router Class Initialized
INFO - 2017-02-18 11:13:37 --> Output Class Initialized
INFO - 2017-02-18 11:13:37 --> Security Class Initialized
DEBUG - 2017-02-18 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:13:37 --> Input Class Initialized
INFO - 2017-02-18 11:13:37 --> Language Class Initialized
INFO - 2017-02-18 11:13:37 --> Loader Class Initialized
INFO - 2017-02-18 11:13:37 --> Helper loaded: url_helper
INFO - 2017-02-18 11:13:37 --> Helper loaded: language_helper
INFO - 2017-02-18 11:13:37 --> Helper loaded: html_helper
INFO - 2017-02-18 11:13:37 --> Helper loaded: form_helper
INFO - 2017-02-18 11:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:13:37 --> Controller Class Initialized
INFO - 2017-02-18 11:13:37 --> Database Driver Class Initialized
INFO - 2017-02-18 11:13:37 --> Model Class Initialized
INFO - 2017-02-18 11:13:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:13:37 --> Form Validation Class Initialized
INFO - 2017-02-18 11:13:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:13:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:13:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:13:37 --> Final output sent to browser
DEBUG - 2017-02-18 11:13:37 --> Total execution time: 0.0822
INFO - 2017-02-18 11:19:36 --> Config Class Initialized
INFO - 2017-02-18 11:19:36 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:19:36 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:19:36 --> Utf8 Class Initialized
INFO - 2017-02-18 11:19:36 --> URI Class Initialized
INFO - 2017-02-18 11:19:36 --> Router Class Initialized
INFO - 2017-02-18 11:19:36 --> Output Class Initialized
INFO - 2017-02-18 11:19:36 --> Security Class Initialized
DEBUG - 2017-02-18 11:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:19:36 --> Input Class Initialized
INFO - 2017-02-18 11:19:36 --> Language Class Initialized
INFO - 2017-02-18 11:19:36 --> Loader Class Initialized
INFO - 2017-02-18 11:19:36 --> Helper loaded: url_helper
INFO - 2017-02-18 11:19:36 --> Helper loaded: language_helper
INFO - 2017-02-18 11:19:36 --> Helper loaded: html_helper
INFO - 2017-02-18 11:19:36 --> Helper loaded: form_helper
INFO - 2017-02-18 11:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:19:36 --> Controller Class Initialized
INFO - 2017-02-18 11:19:36 --> Database Driver Class Initialized
INFO - 2017-02-18 11:19:36 --> Model Class Initialized
INFO - 2017-02-18 11:19:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:19:36 --> Form Validation Class Initialized
INFO - 2017-02-18 11:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:19:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:19:36 --> Final output sent to browser
DEBUG - 2017-02-18 11:19:36 --> Total execution time: 0.0974
INFO - 2017-02-18 11:21:01 --> Config Class Initialized
INFO - 2017-02-18 11:21:01 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:21:01 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:21:01 --> Utf8 Class Initialized
INFO - 2017-02-18 11:21:02 --> URI Class Initialized
INFO - 2017-02-18 11:21:02 --> Router Class Initialized
INFO - 2017-02-18 11:21:02 --> Output Class Initialized
INFO - 2017-02-18 11:21:02 --> Security Class Initialized
DEBUG - 2017-02-18 11:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:21:02 --> Input Class Initialized
INFO - 2017-02-18 11:21:02 --> Language Class Initialized
INFO - 2017-02-18 11:21:02 --> Loader Class Initialized
INFO - 2017-02-18 11:21:02 --> Helper loaded: url_helper
INFO - 2017-02-18 11:21:02 --> Helper loaded: language_helper
INFO - 2017-02-18 11:21:02 --> Helper loaded: html_helper
INFO - 2017-02-18 11:21:02 --> Helper loaded: form_helper
INFO - 2017-02-18 11:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:21:02 --> Controller Class Initialized
INFO - 2017-02-18 11:21:02 --> Database Driver Class Initialized
INFO - 2017-02-18 11:21:02 --> Model Class Initialized
INFO - 2017-02-18 11:21:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:21:02 --> Form Validation Class Initialized
INFO - 2017-02-18 11:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:21:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:21:02 --> Final output sent to browser
DEBUG - 2017-02-18 11:21:02 --> Total execution time: 0.0791
INFO - 2017-02-18 11:21:45 --> Config Class Initialized
INFO - 2017-02-18 11:21:45 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:21:45 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:21:45 --> Utf8 Class Initialized
INFO - 2017-02-18 11:21:45 --> URI Class Initialized
INFO - 2017-02-18 11:21:45 --> Router Class Initialized
INFO - 2017-02-18 11:21:45 --> Output Class Initialized
INFO - 2017-02-18 11:21:45 --> Security Class Initialized
DEBUG - 2017-02-18 11:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:21:45 --> Input Class Initialized
INFO - 2017-02-18 11:21:45 --> Language Class Initialized
INFO - 2017-02-18 11:21:45 --> Loader Class Initialized
INFO - 2017-02-18 11:21:45 --> Helper loaded: url_helper
INFO - 2017-02-18 11:21:45 --> Helper loaded: language_helper
INFO - 2017-02-18 11:21:45 --> Helper loaded: html_helper
INFO - 2017-02-18 11:21:45 --> Helper loaded: form_helper
INFO - 2017-02-18 11:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:21:45 --> Controller Class Initialized
INFO - 2017-02-18 11:21:45 --> Database Driver Class Initialized
INFO - 2017-02-18 11:21:45 --> Model Class Initialized
INFO - 2017-02-18 11:21:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:21:45 --> Form Validation Class Initialized
INFO - 2017-02-18 11:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:21:45 --> Final output sent to browser
DEBUG - 2017-02-18 11:21:45 --> Total execution time: 0.0829
INFO - 2017-02-18 11:21:56 --> Config Class Initialized
INFO - 2017-02-18 11:21:56 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:21:56 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:21:56 --> Utf8 Class Initialized
INFO - 2017-02-18 11:21:56 --> URI Class Initialized
INFO - 2017-02-18 11:21:56 --> Router Class Initialized
INFO - 2017-02-18 11:21:56 --> Output Class Initialized
INFO - 2017-02-18 11:21:56 --> Security Class Initialized
DEBUG - 2017-02-18 11:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:21:56 --> Input Class Initialized
INFO - 2017-02-18 11:21:56 --> Language Class Initialized
INFO - 2017-02-18 11:21:56 --> Loader Class Initialized
INFO - 2017-02-18 11:21:56 --> Helper loaded: url_helper
INFO - 2017-02-18 11:21:56 --> Helper loaded: language_helper
INFO - 2017-02-18 11:21:56 --> Helper loaded: html_helper
INFO - 2017-02-18 11:21:56 --> Helper loaded: form_helper
INFO - 2017-02-18 11:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:21:56 --> Controller Class Initialized
INFO - 2017-02-18 11:21:56 --> Database Driver Class Initialized
INFO - 2017-02-18 11:21:56 --> Model Class Initialized
INFO - 2017-02-18 11:21:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:21:56 --> Form Validation Class Initialized
INFO - 2017-02-18 11:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:21:56 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 11:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:21:56 --> Final output sent to browser
DEBUG - 2017-02-18 11:21:56 --> Total execution time: 0.0853
INFO - 2017-02-18 11:24:10 --> Config Class Initialized
INFO - 2017-02-18 11:24:10 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:24:10 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:24:10 --> Utf8 Class Initialized
INFO - 2017-02-18 11:24:10 --> URI Class Initialized
INFO - 2017-02-18 11:24:10 --> Router Class Initialized
INFO - 2017-02-18 11:24:10 --> Output Class Initialized
INFO - 2017-02-18 11:24:10 --> Security Class Initialized
DEBUG - 2017-02-18 11:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:24:10 --> Input Class Initialized
INFO - 2017-02-18 11:24:10 --> Language Class Initialized
INFO - 2017-02-18 11:24:10 --> Loader Class Initialized
INFO - 2017-02-18 11:24:10 --> Helper loaded: url_helper
INFO - 2017-02-18 11:24:10 --> Helper loaded: language_helper
INFO - 2017-02-18 11:24:10 --> Helper loaded: html_helper
INFO - 2017-02-18 11:24:10 --> Helper loaded: form_helper
INFO - 2017-02-18 11:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:24:10 --> Controller Class Initialized
INFO - 2017-02-18 11:24:10 --> Database Driver Class Initialized
INFO - 2017-02-18 11:24:10 --> Model Class Initialized
INFO - 2017-02-18 11:24:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:24:10 --> Form Validation Class Initialized
ERROR - 2017-02-18 11:24:10 --> Severity: Notice --> Undefined property: Register::$valid C:\wamp64\www\savsoftquiz\application\controllers\Register.php 37
ERROR - 2017-02-18 11:24:10 --> Severity: Error --> Call to a member function set_message() on null C:\wamp64\www\savsoftquiz\application\controllers\Register.php 37
INFO - 2017-02-18 11:26:34 --> Config Class Initialized
INFO - 2017-02-18 11:26:34 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:26:34 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:26:34 --> Utf8 Class Initialized
INFO - 2017-02-18 11:26:34 --> URI Class Initialized
INFO - 2017-02-18 11:26:34 --> Router Class Initialized
INFO - 2017-02-18 11:26:34 --> Output Class Initialized
INFO - 2017-02-18 11:26:34 --> Security Class Initialized
DEBUG - 2017-02-18 11:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:26:34 --> Input Class Initialized
INFO - 2017-02-18 11:26:34 --> Language Class Initialized
INFO - 2017-02-18 11:26:34 --> Loader Class Initialized
INFO - 2017-02-18 11:26:34 --> Helper loaded: url_helper
INFO - 2017-02-18 11:26:34 --> Helper loaded: language_helper
INFO - 2017-02-18 11:26:34 --> Helper loaded: html_helper
INFO - 2017-02-18 11:26:34 --> Helper loaded: form_helper
INFO - 2017-02-18 11:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:26:34 --> Controller Class Initialized
INFO - 2017-02-18 11:26:34 --> Database Driver Class Initialized
INFO - 2017-02-18 11:26:34 --> Model Class Initialized
INFO - 2017-02-18 11:26:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:26:34 --> Form Validation Class Initialized
INFO - 2017-02-18 11:26:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:26:34 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 11:26:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:26:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:26:34 --> Final output sent to browser
DEBUG - 2017-02-18 11:26:34 --> Total execution time: 0.0869
INFO - 2017-02-18 11:27:58 --> Config Class Initialized
INFO - 2017-02-18 11:27:58 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:27:58 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:27:58 --> Utf8 Class Initialized
INFO - 2017-02-18 11:27:58 --> URI Class Initialized
INFO - 2017-02-18 11:27:58 --> Router Class Initialized
INFO - 2017-02-18 11:27:58 --> Output Class Initialized
INFO - 2017-02-18 11:27:58 --> Security Class Initialized
DEBUG - 2017-02-18 11:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:27:58 --> Input Class Initialized
INFO - 2017-02-18 11:27:58 --> Language Class Initialized
INFO - 2017-02-18 11:27:58 --> Loader Class Initialized
INFO - 2017-02-18 11:27:58 --> Helper loaded: url_helper
INFO - 2017-02-18 11:27:58 --> Helper loaded: language_helper
INFO - 2017-02-18 11:27:58 --> Helper loaded: html_helper
INFO - 2017-02-18 11:27:58 --> Helper loaded: form_helper
INFO - 2017-02-18 11:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:27:58 --> Controller Class Initialized
INFO - 2017-02-18 11:27:58 --> Database Driver Class Initialized
INFO - 2017-02-18 11:27:58 --> Model Class Initialized
INFO - 2017-02-18 11:27:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:27:58 --> Form Validation Class Initialized
INFO - 2017-02-18 11:27:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:27:58 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 11:27:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:27:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:27:58 --> Final output sent to browser
DEBUG - 2017-02-18 11:27:58 --> Total execution time: 0.0797
INFO - 2017-02-18 11:28:38 --> Config Class Initialized
INFO - 2017-02-18 11:28:38 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:28:38 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:28:38 --> Utf8 Class Initialized
INFO - 2017-02-18 11:28:38 --> URI Class Initialized
INFO - 2017-02-18 11:28:38 --> Router Class Initialized
INFO - 2017-02-18 11:28:38 --> Output Class Initialized
INFO - 2017-02-18 11:28:38 --> Security Class Initialized
DEBUG - 2017-02-18 11:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:28:38 --> Input Class Initialized
INFO - 2017-02-18 11:28:38 --> Language Class Initialized
INFO - 2017-02-18 11:28:38 --> Loader Class Initialized
INFO - 2017-02-18 11:28:38 --> Helper loaded: url_helper
INFO - 2017-02-18 11:28:39 --> Helper loaded: language_helper
INFO - 2017-02-18 11:28:39 --> Helper loaded: html_helper
INFO - 2017-02-18 11:28:39 --> Helper loaded: form_helper
INFO - 2017-02-18 11:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:28:39 --> Controller Class Initialized
INFO - 2017-02-18 11:28:39 --> Database Driver Class Initialized
INFO - 2017-02-18 11:28:39 --> Model Class Initialized
INFO - 2017-02-18 11:28:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:28:39 --> Form Validation Class Initialized
INFO - 2017-02-18 11:28:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:28:39 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 11:28:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:28:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:28:39 --> Final output sent to browser
DEBUG - 2017-02-18 11:28:39 --> Total execution time: 0.1145
INFO - 2017-02-18 11:35:25 --> Config Class Initialized
INFO - 2017-02-18 11:35:25 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:35:25 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:35:25 --> Utf8 Class Initialized
INFO - 2017-02-18 11:35:25 --> URI Class Initialized
INFO - 2017-02-18 11:35:25 --> Router Class Initialized
INFO - 2017-02-18 11:35:25 --> Output Class Initialized
INFO - 2017-02-18 11:35:25 --> Security Class Initialized
DEBUG - 2017-02-18 11:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:35:25 --> Input Class Initialized
INFO - 2017-02-18 11:35:25 --> Language Class Initialized
INFO - 2017-02-18 11:35:25 --> Loader Class Initialized
INFO - 2017-02-18 11:35:25 --> Helper loaded: url_helper
INFO - 2017-02-18 11:35:25 --> Helper loaded: language_helper
INFO - 2017-02-18 11:35:25 --> Helper loaded: html_helper
INFO - 2017-02-18 11:35:25 --> Helper loaded: form_helper
INFO - 2017-02-18 11:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:35:25 --> Controller Class Initialized
INFO - 2017-02-18 11:35:25 --> Database Driver Class Initialized
INFO - 2017-02-18 11:35:25 --> Model Class Initialized
INFO - 2017-02-18 11:35:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:35:25 --> Form Validation Class Initialized
INFO - 2017-02-18 11:35:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:35:25 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-18 11:35:25 --> Severity: Parsing Error --> syntax error, unexpected ''data-selecter-options'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\wamp64\www\savsoftquiz\application\views\register_new.php 217
INFO - 2017-02-18 11:35:59 --> Config Class Initialized
INFO - 2017-02-18 11:35:59 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:35:59 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:35:59 --> Utf8 Class Initialized
INFO - 2017-02-18 11:35:59 --> URI Class Initialized
INFO - 2017-02-18 11:35:59 --> Router Class Initialized
INFO - 2017-02-18 11:35:59 --> Output Class Initialized
INFO - 2017-02-18 11:35:59 --> Security Class Initialized
DEBUG - 2017-02-18 11:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:35:59 --> Input Class Initialized
INFO - 2017-02-18 11:35:59 --> Language Class Initialized
INFO - 2017-02-18 11:35:59 --> Loader Class Initialized
INFO - 2017-02-18 11:35:59 --> Helper loaded: url_helper
INFO - 2017-02-18 11:35:59 --> Helper loaded: language_helper
INFO - 2017-02-18 11:35:59 --> Helper loaded: html_helper
INFO - 2017-02-18 11:35:59 --> Helper loaded: form_helper
INFO - 2017-02-18 11:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:35:59 --> Controller Class Initialized
INFO - 2017-02-18 11:36:00 --> Database Driver Class Initialized
INFO - 2017-02-18 11:36:00 --> Model Class Initialized
INFO - 2017-02-18 11:36:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:36:00 --> Form Validation Class Initialized
INFO - 2017-02-18 11:36:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:36:00 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-18 11:36:00 --> Severity: Parsing Error --> syntax error, unexpected ''required'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\wamp64\www\savsoftquiz\application\views\register_new.php 218
INFO - 2017-02-18 11:37:00 --> Config Class Initialized
INFO - 2017-02-18 11:37:00 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:37:00 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:37:00 --> Utf8 Class Initialized
INFO - 2017-02-18 11:37:00 --> URI Class Initialized
INFO - 2017-02-18 11:37:00 --> Router Class Initialized
INFO - 2017-02-18 11:37:00 --> Output Class Initialized
INFO - 2017-02-18 11:37:00 --> Security Class Initialized
DEBUG - 2017-02-18 11:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:37:00 --> Input Class Initialized
INFO - 2017-02-18 11:37:00 --> Language Class Initialized
INFO - 2017-02-18 11:37:00 --> Loader Class Initialized
INFO - 2017-02-18 11:37:00 --> Helper loaded: url_helper
INFO - 2017-02-18 11:37:00 --> Helper loaded: language_helper
INFO - 2017-02-18 11:37:00 --> Helper loaded: html_helper
INFO - 2017-02-18 11:37:00 --> Helper loaded: form_helper
INFO - 2017-02-18 11:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:37:00 --> Controller Class Initialized
INFO - 2017-02-18 11:37:00 --> Database Driver Class Initialized
INFO - 2017-02-18 11:37:00 --> Model Class Initialized
INFO - 2017-02-18 11:37:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:37:00 --> Form Validation Class Initialized
INFO - 2017-02-18 11:37:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:37:00 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-18 11:37:00 --> Severity: Parsing Error --> syntax error, unexpected ''required'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\wamp64\www\savsoftquiz\application\views\register_new.php 219
INFO - 2017-02-18 11:38:31 --> Config Class Initialized
INFO - 2017-02-18 11:38:31 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:38:31 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:38:31 --> Utf8 Class Initialized
INFO - 2017-02-18 11:38:31 --> URI Class Initialized
INFO - 2017-02-18 11:38:31 --> Router Class Initialized
INFO - 2017-02-18 11:38:31 --> Output Class Initialized
INFO - 2017-02-18 11:38:31 --> Security Class Initialized
DEBUG - 2017-02-18 11:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:38:31 --> Input Class Initialized
INFO - 2017-02-18 11:38:31 --> Language Class Initialized
INFO - 2017-02-18 11:38:31 --> Loader Class Initialized
INFO - 2017-02-18 11:38:31 --> Helper loaded: url_helper
INFO - 2017-02-18 11:38:31 --> Helper loaded: language_helper
INFO - 2017-02-18 11:38:31 --> Helper loaded: html_helper
INFO - 2017-02-18 11:38:31 --> Helper loaded: form_helper
INFO - 2017-02-18 11:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:38:31 --> Controller Class Initialized
INFO - 2017-02-18 11:38:31 --> Database Driver Class Initialized
INFO - 2017-02-18 11:38:31 --> Model Class Initialized
INFO - 2017-02-18 11:38:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:38:31 --> Form Validation Class Initialized
INFO - 2017-02-18 11:38:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:38:31 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-18 11:38:31 --> Severity: Parsing Error --> syntax error, unexpected ''required'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\wamp64\www\savsoftquiz\application\views\register_new.php 218
INFO - 2017-02-18 11:38:48 --> Config Class Initialized
INFO - 2017-02-18 11:38:48 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:38:48 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:38:48 --> Utf8 Class Initialized
INFO - 2017-02-18 11:38:48 --> URI Class Initialized
INFO - 2017-02-18 11:38:48 --> Router Class Initialized
INFO - 2017-02-18 11:38:48 --> Output Class Initialized
INFO - 2017-02-18 11:38:48 --> Security Class Initialized
DEBUG - 2017-02-18 11:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:38:48 --> Input Class Initialized
INFO - 2017-02-18 11:38:48 --> Language Class Initialized
INFO - 2017-02-18 11:38:48 --> Loader Class Initialized
INFO - 2017-02-18 11:38:48 --> Helper loaded: url_helper
INFO - 2017-02-18 11:38:48 --> Helper loaded: language_helper
INFO - 2017-02-18 11:38:48 --> Helper loaded: html_helper
INFO - 2017-02-18 11:38:48 --> Helper loaded: form_helper
INFO - 2017-02-18 11:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:38:48 --> Controller Class Initialized
INFO - 2017-02-18 11:38:48 --> Database Driver Class Initialized
INFO - 2017-02-18 11:38:48 --> Model Class Initialized
INFO - 2017-02-18 11:38:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:38:48 --> Form Validation Class Initialized
INFO - 2017-02-18 11:38:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:38:48 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 11:38:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:38:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:38:48 --> Final output sent to browser
DEBUG - 2017-02-18 11:38:48 --> Total execution time: 0.0852
INFO - 2017-02-18 11:39:30 --> Config Class Initialized
INFO - 2017-02-18 11:39:30 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:39:30 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:39:30 --> Utf8 Class Initialized
INFO - 2017-02-18 11:39:30 --> URI Class Initialized
INFO - 2017-02-18 11:39:30 --> Router Class Initialized
INFO - 2017-02-18 11:39:30 --> Output Class Initialized
INFO - 2017-02-18 11:39:30 --> Security Class Initialized
DEBUG - 2017-02-18 11:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:39:30 --> Input Class Initialized
INFO - 2017-02-18 11:39:30 --> Language Class Initialized
INFO - 2017-02-18 11:39:30 --> Loader Class Initialized
INFO - 2017-02-18 11:39:30 --> Helper loaded: url_helper
INFO - 2017-02-18 11:39:30 --> Helper loaded: language_helper
INFO - 2017-02-18 11:39:30 --> Helper loaded: html_helper
INFO - 2017-02-18 11:39:30 --> Helper loaded: form_helper
INFO - 2017-02-18 11:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:39:30 --> Controller Class Initialized
INFO - 2017-02-18 11:39:30 --> Database Driver Class Initialized
INFO - 2017-02-18 11:39:30 --> Model Class Initialized
INFO - 2017-02-18 11:39:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:39:30 --> Form Validation Class Initialized
INFO - 2017-02-18 11:39:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:39:30 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 11:39:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:39:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:39:30 --> Final output sent to browser
DEBUG - 2017-02-18 11:39:30 --> Total execution time: 0.0815
INFO - 2017-02-18 11:39:37 --> Config Class Initialized
INFO - 2017-02-18 11:39:37 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:39:37 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:39:37 --> Utf8 Class Initialized
INFO - 2017-02-18 11:39:37 --> URI Class Initialized
INFO - 2017-02-18 11:39:37 --> Router Class Initialized
INFO - 2017-02-18 11:39:37 --> Output Class Initialized
INFO - 2017-02-18 11:39:37 --> Security Class Initialized
DEBUG - 2017-02-18 11:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:39:37 --> Input Class Initialized
INFO - 2017-02-18 11:39:37 --> Language Class Initialized
INFO - 2017-02-18 11:39:37 --> Loader Class Initialized
INFO - 2017-02-18 11:39:37 --> Helper loaded: url_helper
INFO - 2017-02-18 11:39:37 --> Helper loaded: language_helper
INFO - 2017-02-18 11:39:37 --> Helper loaded: html_helper
INFO - 2017-02-18 11:39:37 --> Helper loaded: form_helper
INFO - 2017-02-18 11:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:39:37 --> Controller Class Initialized
INFO - 2017-02-18 11:39:37 --> Database Driver Class Initialized
INFO - 2017-02-18 11:39:37 --> Model Class Initialized
INFO - 2017-02-18 11:39:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:39:37 --> Form Validation Class Initialized
INFO - 2017-02-18 11:39:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:39:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:39:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:39:37 --> Final output sent to browser
DEBUG - 2017-02-18 11:39:37 --> Total execution time: 0.0776
INFO - 2017-02-18 11:41:46 --> Config Class Initialized
INFO - 2017-02-18 11:41:46 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:41:46 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:41:46 --> Utf8 Class Initialized
INFO - 2017-02-18 11:41:46 --> URI Class Initialized
INFO - 2017-02-18 11:41:46 --> Router Class Initialized
INFO - 2017-02-18 11:41:46 --> Output Class Initialized
INFO - 2017-02-18 11:41:46 --> Security Class Initialized
DEBUG - 2017-02-18 11:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:41:46 --> Input Class Initialized
INFO - 2017-02-18 11:41:46 --> Language Class Initialized
INFO - 2017-02-18 11:41:46 --> Loader Class Initialized
INFO - 2017-02-18 11:41:46 --> Helper loaded: url_helper
INFO - 2017-02-18 11:41:46 --> Helper loaded: language_helper
INFO - 2017-02-18 11:41:46 --> Helper loaded: html_helper
INFO - 2017-02-18 11:41:46 --> Helper loaded: form_helper
INFO - 2017-02-18 11:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:41:46 --> Controller Class Initialized
INFO - 2017-02-18 11:41:46 --> Database Driver Class Initialized
INFO - 2017-02-18 11:41:46 --> Model Class Initialized
INFO - 2017-02-18 11:41:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:41:46 --> Form Validation Class Initialized
INFO - 2017-02-18 11:41:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:41:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:41:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:41:46 --> Final output sent to browser
DEBUG - 2017-02-18 11:41:46 --> Total execution time: 0.0855
INFO - 2017-02-18 11:42:03 --> Config Class Initialized
INFO - 2017-02-18 11:42:03 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:42:03 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:42:03 --> Utf8 Class Initialized
INFO - 2017-02-18 11:42:03 --> URI Class Initialized
INFO - 2017-02-18 11:42:04 --> Router Class Initialized
INFO - 2017-02-18 11:42:04 --> Output Class Initialized
INFO - 2017-02-18 11:42:04 --> Security Class Initialized
DEBUG - 2017-02-18 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:42:04 --> Input Class Initialized
INFO - 2017-02-18 11:42:04 --> Language Class Initialized
INFO - 2017-02-18 11:42:04 --> Loader Class Initialized
INFO - 2017-02-18 11:42:04 --> Helper loaded: url_helper
INFO - 2017-02-18 11:42:04 --> Helper loaded: language_helper
INFO - 2017-02-18 11:42:04 --> Helper loaded: html_helper
INFO - 2017-02-18 11:42:04 --> Helper loaded: form_helper
INFO - 2017-02-18 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:42:04 --> Controller Class Initialized
INFO - 2017-02-18 11:42:04 --> Database Driver Class Initialized
INFO - 2017-02-18 11:42:04 --> Model Class Initialized
INFO - 2017-02-18 11:42:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:42:04 --> Form Validation Class Initialized
INFO - 2017-02-18 11:42:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:42:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:42:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:42:04 --> Final output sent to browser
DEBUG - 2017-02-18 11:42:04 --> Total execution time: 0.0840
INFO - 2017-02-18 11:42:28 --> Config Class Initialized
INFO - 2017-02-18 11:42:28 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:42:28 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:42:28 --> Utf8 Class Initialized
INFO - 2017-02-18 11:42:28 --> URI Class Initialized
INFO - 2017-02-18 11:42:28 --> Router Class Initialized
INFO - 2017-02-18 11:42:28 --> Output Class Initialized
INFO - 2017-02-18 11:42:28 --> Security Class Initialized
DEBUG - 2017-02-18 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:42:28 --> Input Class Initialized
INFO - 2017-02-18 11:42:28 --> Language Class Initialized
INFO - 2017-02-18 11:42:28 --> Loader Class Initialized
INFO - 2017-02-18 11:42:28 --> Helper loaded: url_helper
INFO - 2017-02-18 11:42:28 --> Helper loaded: language_helper
INFO - 2017-02-18 11:42:28 --> Helper loaded: html_helper
INFO - 2017-02-18 11:42:28 --> Helper loaded: form_helper
INFO - 2017-02-18 11:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:42:29 --> Controller Class Initialized
INFO - 2017-02-18 11:42:29 --> Database Driver Class Initialized
INFO - 2017-02-18 11:42:29 --> Model Class Initialized
INFO - 2017-02-18 11:42:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:42:29 --> Form Validation Class Initialized
INFO - 2017-02-18 11:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:42:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:42:29 --> Final output sent to browser
DEBUG - 2017-02-18 11:42:29 --> Total execution time: 0.0830
INFO - 2017-02-18 11:43:21 --> Config Class Initialized
INFO - 2017-02-18 11:43:21 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:43:21 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:43:21 --> Utf8 Class Initialized
INFO - 2017-02-18 11:43:21 --> URI Class Initialized
INFO - 2017-02-18 11:43:21 --> Router Class Initialized
INFO - 2017-02-18 11:43:21 --> Output Class Initialized
INFO - 2017-02-18 11:43:21 --> Security Class Initialized
DEBUG - 2017-02-18 11:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:43:21 --> Input Class Initialized
INFO - 2017-02-18 11:43:21 --> Language Class Initialized
INFO - 2017-02-18 11:43:21 --> Loader Class Initialized
INFO - 2017-02-18 11:43:21 --> Helper loaded: url_helper
INFO - 2017-02-18 11:43:21 --> Helper loaded: language_helper
INFO - 2017-02-18 11:43:21 --> Helper loaded: html_helper
INFO - 2017-02-18 11:43:21 --> Helper loaded: form_helper
INFO - 2017-02-18 11:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:43:21 --> Controller Class Initialized
INFO - 2017-02-18 11:43:21 --> Database Driver Class Initialized
INFO - 2017-02-18 11:43:21 --> Model Class Initialized
INFO - 2017-02-18 11:43:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:43:21 --> Form Validation Class Initialized
INFO - 2017-02-18 11:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:43:21 --> Final output sent to browser
DEBUG - 2017-02-18 11:43:21 --> Total execution time: 0.0836
INFO - 2017-02-18 11:45:23 --> Config Class Initialized
INFO - 2017-02-18 11:45:23 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:45:23 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:45:23 --> Utf8 Class Initialized
INFO - 2017-02-18 11:45:23 --> URI Class Initialized
INFO - 2017-02-18 11:45:23 --> Router Class Initialized
INFO - 2017-02-18 11:45:23 --> Output Class Initialized
INFO - 2017-02-18 11:45:23 --> Security Class Initialized
DEBUG - 2017-02-18 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:45:23 --> Input Class Initialized
INFO - 2017-02-18 11:45:23 --> Language Class Initialized
INFO - 2017-02-18 11:45:23 --> Loader Class Initialized
INFO - 2017-02-18 11:45:23 --> Helper loaded: url_helper
INFO - 2017-02-18 11:45:23 --> Helper loaded: language_helper
INFO - 2017-02-18 11:45:23 --> Helper loaded: html_helper
INFO - 2017-02-18 11:45:23 --> Helper loaded: form_helper
INFO - 2017-02-18 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:45:23 --> Controller Class Initialized
INFO - 2017-02-18 11:45:23 --> Database Driver Class Initialized
INFO - 2017-02-18 11:45:23 --> Model Class Initialized
INFO - 2017-02-18 11:45:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:45:23 --> Form Validation Class Initialized
INFO - 2017-02-18 11:45:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-18 11:45:23 --> Severity: Parsing Error --> syntax error, unexpected ''required'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\wamp64\www\savsoftquiz\application\views\register_new.php 218
INFO - 2017-02-18 11:45:35 --> Config Class Initialized
INFO - 2017-02-18 11:45:35 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:45:35 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:45:35 --> Utf8 Class Initialized
INFO - 2017-02-18 11:45:35 --> URI Class Initialized
INFO - 2017-02-18 11:45:35 --> Router Class Initialized
INFO - 2017-02-18 11:45:35 --> Output Class Initialized
INFO - 2017-02-18 11:45:35 --> Security Class Initialized
DEBUG - 2017-02-18 11:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:45:35 --> Input Class Initialized
INFO - 2017-02-18 11:45:35 --> Language Class Initialized
INFO - 2017-02-18 11:45:35 --> Loader Class Initialized
INFO - 2017-02-18 11:45:35 --> Helper loaded: url_helper
INFO - 2017-02-18 11:45:35 --> Helper loaded: language_helper
INFO - 2017-02-18 11:45:35 --> Helper loaded: html_helper
INFO - 2017-02-18 11:45:35 --> Helper loaded: form_helper
INFO - 2017-02-18 11:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:45:35 --> Controller Class Initialized
INFO - 2017-02-18 11:45:35 --> Database Driver Class Initialized
INFO - 2017-02-18 11:45:35 --> Model Class Initialized
INFO - 2017-02-18 11:45:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:45:35 --> Form Validation Class Initialized
INFO - 2017-02-18 11:45:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-18 11:45:35 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\system\helpers\form_helper.php 949
ERROR - 2017-02-18 11:45:35 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\system\helpers\form_helper.php 949
INFO - 2017-02-18 11:45:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:45:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:45:35 --> Final output sent to browser
DEBUG - 2017-02-18 11:45:35 --> Total execution time: 0.0851
INFO - 2017-02-18 11:47:11 --> Config Class Initialized
INFO - 2017-02-18 11:47:11 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:47:11 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:47:11 --> Utf8 Class Initialized
INFO - 2017-02-18 11:47:11 --> URI Class Initialized
INFO - 2017-02-18 11:47:11 --> Router Class Initialized
INFO - 2017-02-18 11:47:11 --> Output Class Initialized
INFO - 2017-02-18 11:47:11 --> Security Class Initialized
DEBUG - 2017-02-18 11:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:47:11 --> Input Class Initialized
INFO - 2017-02-18 11:47:11 --> Language Class Initialized
INFO - 2017-02-18 11:47:11 --> Loader Class Initialized
INFO - 2017-02-18 11:47:11 --> Helper loaded: url_helper
INFO - 2017-02-18 11:47:11 --> Helper loaded: language_helper
INFO - 2017-02-18 11:47:11 --> Helper loaded: html_helper
INFO - 2017-02-18 11:47:11 --> Helper loaded: form_helper
INFO - 2017-02-18 11:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:47:11 --> Controller Class Initialized
INFO - 2017-02-18 11:47:11 --> Database Driver Class Initialized
INFO - 2017-02-18 11:47:11 --> Model Class Initialized
INFO - 2017-02-18 11:47:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:47:11 --> Form Validation Class Initialized
INFO - 2017-02-18 11:47:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-18 11:47:11 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\system\helpers\form_helper.php 949
INFO - 2017-02-18 11:47:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:47:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:47:11 --> Final output sent to browser
DEBUG - 2017-02-18 11:47:11 --> Total execution time: 0.0876
INFO - 2017-02-18 11:48:21 --> Config Class Initialized
INFO - 2017-02-18 11:48:21 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:48:21 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:48:21 --> Utf8 Class Initialized
INFO - 2017-02-18 11:48:21 --> URI Class Initialized
INFO - 2017-02-18 11:48:21 --> Router Class Initialized
INFO - 2017-02-18 11:48:21 --> Output Class Initialized
INFO - 2017-02-18 11:48:21 --> Security Class Initialized
DEBUG - 2017-02-18 11:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:48:21 --> Input Class Initialized
INFO - 2017-02-18 11:48:21 --> Language Class Initialized
INFO - 2017-02-18 11:48:21 --> Loader Class Initialized
INFO - 2017-02-18 11:48:21 --> Helper loaded: url_helper
INFO - 2017-02-18 11:48:21 --> Helper loaded: language_helper
INFO - 2017-02-18 11:48:21 --> Helper loaded: html_helper
INFO - 2017-02-18 11:48:21 --> Helper loaded: form_helper
INFO - 2017-02-18 11:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:48:21 --> Controller Class Initialized
INFO - 2017-02-18 11:48:21 --> Database Driver Class Initialized
INFO - 2017-02-18 11:48:21 --> Model Class Initialized
INFO - 2017-02-18 11:48:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:48:21 --> Form Validation Class Initialized
INFO - 2017-02-18 11:48:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:48:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:48:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:48:21 --> Final output sent to browser
DEBUG - 2017-02-18 11:48:21 --> Total execution time: 0.0800
INFO - 2017-02-18 11:48:46 --> Config Class Initialized
INFO - 2017-02-18 11:48:46 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:48:46 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:48:46 --> Utf8 Class Initialized
INFO - 2017-02-18 11:48:46 --> URI Class Initialized
INFO - 2017-02-18 11:48:46 --> Router Class Initialized
INFO - 2017-02-18 11:48:46 --> Output Class Initialized
INFO - 2017-02-18 11:48:46 --> Security Class Initialized
DEBUG - 2017-02-18 11:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:48:46 --> Input Class Initialized
INFO - 2017-02-18 11:48:46 --> Language Class Initialized
INFO - 2017-02-18 11:48:46 --> Loader Class Initialized
INFO - 2017-02-18 11:48:46 --> Helper loaded: url_helper
INFO - 2017-02-18 11:48:46 --> Helper loaded: language_helper
INFO - 2017-02-18 11:48:46 --> Helper loaded: html_helper
INFO - 2017-02-18 11:48:46 --> Helper loaded: form_helper
INFO - 2017-02-18 11:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:48:46 --> Controller Class Initialized
INFO - 2017-02-18 11:48:46 --> Database Driver Class Initialized
INFO - 2017-02-18 11:48:46 --> Model Class Initialized
INFO - 2017-02-18 11:48:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:48:47 --> Form Validation Class Initialized
INFO - 2017-02-18 11:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:48:47 --> Final output sent to browser
DEBUG - 2017-02-18 11:48:47 --> Total execution time: 0.0791
INFO - 2017-02-18 11:49:50 --> Config Class Initialized
INFO - 2017-02-18 11:49:50 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:49:50 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:49:50 --> Utf8 Class Initialized
INFO - 2017-02-18 11:49:50 --> URI Class Initialized
INFO - 2017-02-18 11:49:50 --> Router Class Initialized
INFO - 2017-02-18 11:49:50 --> Output Class Initialized
INFO - 2017-02-18 11:49:50 --> Security Class Initialized
DEBUG - 2017-02-18 11:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:49:50 --> Input Class Initialized
INFO - 2017-02-18 11:49:50 --> Language Class Initialized
INFO - 2017-02-18 11:49:50 --> Loader Class Initialized
INFO - 2017-02-18 11:49:50 --> Helper loaded: url_helper
INFO - 2017-02-18 11:49:50 --> Helper loaded: language_helper
INFO - 2017-02-18 11:49:50 --> Helper loaded: html_helper
INFO - 2017-02-18 11:49:50 --> Helper loaded: form_helper
INFO - 2017-02-18 11:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:49:50 --> Controller Class Initialized
INFO - 2017-02-18 11:49:50 --> Database Driver Class Initialized
INFO - 2017-02-18 11:49:50 --> Model Class Initialized
INFO - 2017-02-18 11:49:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:49:50 --> Form Validation Class Initialized
INFO - 2017-02-18 11:49:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:49:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:49:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:49:50 --> Final output sent to browser
DEBUG - 2017-02-18 11:49:50 --> Total execution time: 0.0823
INFO - 2017-02-18 11:50:58 --> Config Class Initialized
INFO - 2017-02-18 11:50:58 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:50:58 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:50:58 --> Utf8 Class Initialized
INFO - 2017-02-18 11:50:58 --> URI Class Initialized
INFO - 2017-02-18 11:50:58 --> Router Class Initialized
INFO - 2017-02-18 11:50:58 --> Output Class Initialized
INFO - 2017-02-18 11:50:58 --> Security Class Initialized
DEBUG - 2017-02-18 11:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:50:58 --> Input Class Initialized
INFO - 2017-02-18 11:50:58 --> Language Class Initialized
INFO - 2017-02-18 11:50:58 --> Loader Class Initialized
INFO - 2017-02-18 11:50:58 --> Helper loaded: url_helper
INFO - 2017-02-18 11:50:58 --> Helper loaded: language_helper
INFO - 2017-02-18 11:50:58 --> Helper loaded: html_helper
INFO - 2017-02-18 11:50:58 --> Helper loaded: form_helper
INFO - 2017-02-18 11:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:50:58 --> Controller Class Initialized
INFO - 2017-02-18 11:50:58 --> Database Driver Class Initialized
INFO - 2017-02-18 11:50:58 --> Model Class Initialized
INFO - 2017-02-18 11:50:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:50:58 --> Form Validation Class Initialized
INFO - 2017-02-18 11:50:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-18 11:50:58 --> Severity: Parsing Error --> syntax error, unexpected ''data-selecter-options'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\wamp64\www\savsoftquiz\application\views\register_new.php 218
INFO - 2017-02-18 11:51:10 --> Config Class Initialized
INFO - 2017-02-18 11:51:10 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:51:10 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:51:10 --> Utf8 Class Initialized
INFO - 2017-02-18 11:51:10 --> URI Class Initialized
INFO - 2017-02-18 11:51:10 --> Router Class Initialized
INFO - 2017-02-18 11:51:10 --> Output Class Initialized
INFO - 2017-02-18 11:51:10 --> Security Class Initialized
DEBUG - 2017-02-18 11:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:51:10 --> Input Class Initialized
INFO - 2017-02-18 11:51:10 --> Language Class Initialized
INFO - 2017-02-18 11:51:10 --> Loader Class Initialized
INFO - 2017-02-18 11:51:10 --> Helper loaded: url_helper
INFO - 2017-02-18 11:51:10 --> Helper loaded: language_helper
INFO - 2017-02-18 11:51:10 --> Helper loaded: html_helper
INFO - 2017-02-18 11:51:10 --> Helper loaded: form_helper
INFO - 2017-02-18 11:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:51:10 --> Controller Class Initialized
INFO - 2017-02-18 11:51:10 --> Database Driver Class Initialized
INFO - 2017-02-18 11:51:10 --> Model Class Initialized
INFO - 2017-02-18 11:51:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:51:10 --> Form Validation Class Initialized
INFO - 2017-02-18 11:51:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:51:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:51:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:51:10 --> Final output sent to browser
DEBUG - 2017-02-18 11:51:10 --> Total execution time: 0.0852
INFO - 2017-02-18 11:56:27 --> Config Class Initialized
INFO - 2017-02-18 11:56:27 --> Hooks Class Initialized
DEBUG - 2017-02-18 11:56:27 --> UTF-8 Support Enabled
INFO - 2017-02-18 11:56:27 --> Utf8 Class Initialized
INFO - 2017-02-18 11:56:27 --> URI Class Initialized
INFO - 2017-02-18 11:56:27 --> Router Class Initialized
INFO - 2017-02-18 11:56:27 --> Output Class Initialized
INFO - 2017-02-18 11:56:27 --> Security Class Initialized
DEBUG - 2017-02-18 11:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 11:56:27 --> Input Class Initialized
INFO - 2017-02-18 11:56:27 --> Language Class Initialized
INFO - 2017-02-18 11:56:27 --> Loader Class Initialized
INFO - 2017-02-18 11:56:27 --> Helper loaded: url_helper
INFO - 2017-02-18 11:56:27 --> Helper loaded: language_helper
INFO - 2017-02-18 11:56:27 --> Helper loaded: html_helper
INFO - 2017-02-18 11:56:27 --> Helper loaded: form_helper
INFO - 2017-02-18 11:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 11:56:27 --> Controller Class Initialized
INFO - 2017-02-18 11:56:27 --> Database Driver Class Initialized
INFO - 2017-02-18 11:56:27 --> Model Class Initialized
INFO - 2017-02-18 11:56:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 11:56:27 --> Form Validation Class Initialized
INFO - 2017-02-18 11:56:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 11:56:27 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 11:56:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 11:56:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 11:56:27 --> Final output sent to browser
DEBUG - 2017-02-18 11:56:27 --> Total execution time: 0.0862
INFO - 2017-02-18 12:00:40 --> Config Class Initialized
INFO - 2017-02-18 12:00:40 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:00:40 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:00:40 --> Utf8 Class Initialized
INFO - 2017-02-18 12:00:40 --> URI Class Initialized
INFO - 2017-02-18 12:00:40 --> Router Class Initialized
INFO - 2017-02-18 12:00:40 --> Output Class Initialized
INFO - 2017-02-18 12:00:40 --> Security Class Initialized
DEBUG - 2017-02-18 12:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:00:40 --> Input Class Initialized
INFO - 2017-02-18 12:00:40 --> Language Class Initialized
INFO - 2017-02-18 12:00:40 --> Loader Class Initialized
INFO - 2017-02-18 12:00:40 --> Helper loaded: url_helper
INFO - 2017-02-18 12:00:40 --> Helper loaded: language_helper
INFO - 2017-02-18 12:00:40 --> Helper loaded: html_helper
INFO - 2017-02-18 12:00:40 --> Helper loaded: form_helper
INFO - 2017-02-18 12:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:00:40 --> Controller Class Initialized
INFO - 2017-02-18 12:00:40 --> Database Driver Class Initialized
INFO - 2017-02-18 12:00:40 --> Model Class Initialized
INFO - 2017-02-18 12:00:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:00:40 --> Form Validation Class Initialized
INFO - 2017-02-18 12:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:00:40 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:00:40 --> Final output sent to browser
DEBUG - 2017-02-18 12:00:40 --> Total execution time: 0.1018
INFO - 2017-02-18 12:01:31 --> Config Class Initialized
INFO - 2017-02-18 12:01:31 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:01:31 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:01:31 --> Utf8 Class Initialized
INFO - 2017-02-18 12:01:31 --> URI Class Initialized
INFO - 2017-02-18 12:01:31 --> Router Class Initialized
INFO - 2017-02-18 12:01:31 --> Output Class Initialized
INFO - 2017-02-18 12:01:31 --> Security Class Initialized
DEBUG - 2017-02-18 12:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:01:31 --> Input Class Initialized
INFO - 2017-02-18 12:01:31 --> Language Class Initialized
INFO - 2017-02-18 12:01:31 --> Loader Class Initialized
INFO - 2017-02-18 12:01:31 --> Helper loaded: url_helper
INFO - 2017-02-18 12:01:31 --> Helper loaded: language_helper
INFO - 2017-02-18 12:01:31 --> Helper loaded: html_helper
INFO - 2017-02-18 12:01:31 --> Helper loaded: form_helper
INFO - 2017-02-18 12:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:01:31 --> Controller Class Initialized
INFO - 2017-02-18 12:01:31 --> Database Driver Class Initialized
INFO - 2017-02-18 12:01:31 --> Model Class Initialized
INFO - 2017-02-18 12:01:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:01:31 --> Form Validation Class Initialized
INFO - 2017-02-18 12:01:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:01:31 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:01:31 --> Config Class Initialized
INFO - 2017-02-18 12:01:31 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:01:31 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:01:31 --> Utf8 Class Initialized
INFO - 2017-02-18 12:01:31 --> URI Class Initialized
INFO - 2017-02-18 12:01:31 --> Router Class Initialized
INFO - 2017-02-18 12:01:31 --> Output Class Initialized
INFO - 2017-02-18 12:01:31 --> Security Class Initialized
DEBUG - 2017-02-18 12:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:01:31 --> Input Class Initialized
INFO - 2017-02-18 12:01:31 --> Language Class Initialized
INFO - 2017-02-18 12:01:31 --> Loader Class Initialized
INFO - 2017-02-18 12:01:31 --> Helper loaded: url_helper
INFO - 2017-02-18 12:01:31 --> Helper loaded: language_helper
INFO - 2017-02-18 12:01:31 --> Helper loaded: html_helper
INFO - 2017-02-18 12:01:31 --> Helper loaded: form_helper
INFO - 2017-02-18 12:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:01:31 --> Controller Class Initialized
INFO - 2017-02-18 12:01:31 --> Database Driver Class Initialized
INFO - 2017-02-18 12:01:31 --> Model Class Initialized
INFO - 2017-02-18 12:01:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:01:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:01:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-18 12:01:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:01:31 --> Final output sent to browser
DEBUG - 2017-02-18 12:01:31 --> Total execution time: 0.0683
INFO - 2017-02-18 12:01:57 --> Config Class Initialized
INFO - 2017-02-18 12:01:57 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:01:57 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:01:57 --> Utf8 Class Initialized
INFO - 2017-02-18 12:01:57 --> URI Class Initialized
INFO - 2017-02-18 12:01:57 --> Router Class Initialized
INFO - 2017-02-18 12:01:57 --> Output Class Initialized
INFO - 2017-02-18 12:01:57 --> Security Class Initialized
DEBUG - 2017-02-18 12:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:01:57 --> Input Class Initialized
INFO - 2017-02-18 12:01:57 --> Language Class Initialized
INFO - 2017-02-18 12:01:57 --> Loader Class Initialized
INFO - 2017-02-18 12:01:57 --> Helper loaded: url_helper
INFO - 2017-02-18 12:01:57 --> Helper loaded: language_helper
INFO - 2017-02-18 12:01:57 --> Helper loaded: html_helper
INFO - 2017-02-18 12:01:57 --> Helper loaded: form_helper
INFO - 2017-02-18 12:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:01:57 --> Controller Class Initialized
INFO - 2017-02-18 12:01:58 --> Database Driver Class Initialized
INFO - 2017-02-18 12:01:58 --> Model Class Initialized
INFO - 2017-02-18 12:01:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-18 12:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:01:58 --> Final output sent to browser
DEBUG - 2017-02-18 12:01:58 --> Total execution time: 0.0691
INFO - 2017-02-18 12:02:05 --> Config Class Initialized
INFO - 2017-02-18 12:02:05 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:02:05 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:02:05 --> Utf8 Class Initialized
INFO - 2017-02-18 12:02:05 --> URI Class Initialized
INFO - 2017-02-18 12:02:05 --> Router Class Initialized
INFO - 2017-02-18 12:02:05 --> Output Class Initialized
INFO - 2017-02-18 12:02:05 --> Security Class Initialized
DEBUG - 2017-02-18 12:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:02:05 --> Input Class Initialized
INFO - 2017-02-18 12:02:05 --> Language Class Initialized
INFO - 2017-02-18 12:02:05 --> Loader Class Initialized
INFO - 2017-02-18 12:02:05 --> Helper loaded: url_helper
INFO - 2017-02-18 12:02:05 --> Helper loaded: language_helper
INFO - 2017-02-18 12:02:05 --> Helper loaded: html_helper
INFO - 2017-02-18 12:02:05 --> Helper loaded: form_helper
INFO - 2017-02-18 12:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:02:05 --> Controller Class Initialized
INFO - 2017-02-18 12:02:05 --> Database Driver Class Initialized
INFO - 2017-02-18 12:02:05 --> Model Class Initialized
INFO - 2017-02-18 12:02:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:02:05 --> Form Validation Class Initialized
INFO - 2017-02-18 12:02:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:02:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:02:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:02:05 --> Final output sent to browser
DEBUG - 2017-02-18 12:02:05 --> Total execution time: 0.0802
INFO - 2017-02-18 12:02:44 --> Config Class Initialized
INFO - 2017-02-18 12:02:44 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:02:44 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:02:44 --> Utf8 Class Initialized
INFO - 2017-02-18 12:02:44 --> URI Class Initialized
INFO - 2017-02-18 12:02:44 --> Router Class Initialized
INFO - 2017-02-18 12:02:44 --> Output Class Initialized
INFO - 2017-02-18 12:02:44 --> Security Class Initialized
DEBUG - 2017-02-18 12:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:02:44 --> Input Class Initialized
INFO - 2017-02-18 12:02:44 --> Language Class Initialized
INFO - 2017-02-18 12:02:44 --> Loader Class Initialized
INFO - 2017-02-18 12:02:44 --> Helper loaded: url_helper
INFO - 2017-02-18 12:02:44 --> Helper loaded: language_helper
INFO - 2017-02-18 12:02:44 --> Helper loaded: html_helper
INFO - 2017-02-18 12:02:44 --> Helper loaded: form_helper
INFO - 2017-02-18 12:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:02:44 --> Controller Class Initialized
INFO - 2017-02-18 12:02:44 --> Database Driver Class Initialized
INFO - 2017-02-18 12:02:44 --> Model Class Initialized
INFO - 2017-02-18 12:02:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:02:44 --> Form Validation Class Initialized
INFO - 2017-02-18 12:02:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:02:44 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:02:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:02:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:02:44 --> Final output sent to browser
DEBUG - 2017-02-18 12:02:44 --> Total execution time: 0.0845
INFO - 2017-02-18 12:03:45 --> Config Class Initialized
INFO - 2017-02-18 12:03:45 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:03:45 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:03:45 --> Utf8 Class Initialized
INFO - 2017-02-18 12:03:45 --> URI Class Initialized
INFO - 2017-02-18 12:03:45 --> Router Class Initialized
INFO - 2017-02-18 12:03:45 --> Output Class Initialized
INFO - 2017-02-18 12:03:45 --> Security Class Initialized
DEBUG - 2017-02-18 12:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:03:45 --> Input Class Initialized
INFO - 2017-02-18 12:03:45 --> Language Class Initialized
INFO - 2017-02-18 12:03:45 --> Loader Class Initialized
INFO - 2017-02-18 12:03:45 --> Helper loaded: url_helper
INFO - 2017-02-18 12:03:45 --> Helper loaded: language_helper
INFO - 2017-02-18 12:03:45 --> Helper loaded: html_helper
INFO - 2017-02-18 12:03:45 --> Helper loaded: form_helper
INFO - 2017-02-18 12:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:03:45 --> Controller Class Initialized
INFO - 2017-02-18 12:03:45 --> Database Driver Class Initialized
INFO - 2017-02-18 12:03:45 --> Model Class Initialized
INFO - 2017-02-18 12:03:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:03:45 --> Form Validation Class Initialized
INFO - 2017-02-18 12:03:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:03:45 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:03:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:03:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:03:45 --> Final output sent to browser
DEBUG - 2017-02-18 12:03:45 --> Total execution time: 0.0883
INFO - 2017-02-18 12:03:49 --> Config Class Initialized
INFO - 2017-02-18 12:03:49 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:03:49 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:03:49 --> Utf8 Class Initialized
INFO - 2017-02-18 12:03:49 --> URI Class Initialized
INFO - 2017-02-18 12:03:49 --> Router Class Initialized
INFO - 2017-02-18 12:03:49 --> Output Class Initialized
INFO - 2017-02-18 12:03:49 --> Security Class Initialized
DEBUG - 2017-02-18 12:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:03:49 --> Input Class Initialized
INFO - 2017-02-18 12:03:49 --> Language Class Initialized
INFO - 2017-02-18 12:03:49 --> Loader Class Initialized
INFO - 2017-02-18 12:03:49 --> Helper loaded: url_helper
INFO - 2017-02-18 12:03:49 --> Helper loaded: language_helper
INFO - 2017-02-18 12:03:49 --> Helper loaded: html_helper
INFO - 2017-02-18 12:03:49 --> Helper loaded: form_helper
INFO - 2017-02-18 12:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:03:49 --> Controller Class Initialized
INFO - 2017-02-18 12:03:49 --> Database Driver Class Initialized
INFO - 2017-02-18 12:03:49 --> Model Class Initialized
INFO - 2017-02-18 12:03:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:03:49 --> Form Validation Class Initialized
INFO - 2017-02-18 12:03:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:03:49 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:03:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:03:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:03:49 --> Final output sent to browser
DEBUG - 2017-02-18 12:03:49 --> Total execution time: 0.0893
INFO - 2017-02-18 12:04:44 --> Config Class Initialized
INFO - 2017-02-18 12:04:44 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:04:44 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:04:44 --> Utf8 Class Initialized
INFO - 2017-02-18 12:04:44 --> URI Class Initialized
INFO - 2017-02-18 12:04:44 --> Router Class Initialized
INFO - 2017-02-18 12:04:44 --> Output Class Initialized
INFO - 2017-02-18 12:04:44 --> Security Class Initialized
DEBUG - 2017-02-18 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:04:44 --> Input Class Initialized
INFO - 2017-02-18 12:04:44 --> Language Class Initialized
INFO - 2017-02-18 12:04:44 --> Loader Class Initialized
INFO - 2017-02-18 12:04:44 --> Helper loaded: url_helper
INFO - 2017-02-18 12:04:44 --> Helper loaded: language_helper
INFO - 2017-02-18 12:04:44 --> Helper loaded: html_helper
INFO - 2017-02-18 12:04:44 --> Helper loaded: form_helper
INFO - 2017-02-18 12:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:04:44 --> Controller Class Initialized
INFO - 2017-02-18 12:04:44 --> Database Driver Class Initialized
INFO - 2017-02-18 12:04:44 --> Model Class Initialized
INFO - 2017-02-18 12:04:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:04:44 --> Form Validation Class Initialized
INFO - 2017-02-18 12:04:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:04:44 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:04:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:04:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:04:44 --> Final output sent to browser
DEBUG - 2017-02-18 12:04:44 --> Total execution time: 0.0836
INFO - 2017-02-18 12:07:45 --> Config Class Initialized
INFO - 2017-02-18 12:07:45 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:07:45 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:07:45 --> Utf8 Class Initialized
INFO - 2017-02-18 12:07:45 --> URI Class Initialized
INFO - 2017-02-18 12:07:45 --> Router Class Initialized
INFO - 2017-02-18 12:07:45 --> Output Class Initialized
INFO - 2017-02-18 12:07:45 --> Security Class Initialized
DEBUG - 2017-02-18 12:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:07:45 --> Input Class Initialized
INFO - 2017-02-18 12:07:45 --> Language Class Initialized
INFO - 2017-02-18 12:07:45 --> Loader Class Initialized
INFO - 2017-02-18 12:07:45 --> Helper loaded: url_helper
INFO - 2017-02-18 12:07:45 --> Helper loaded: language_helper
INFO - 2017-02-18 12:07:45 --> Helper loaded: html_helper
INFO - 2017-02-18 12:07:45 --> Helper loaded: form_helper
INFO - 2017-02-18 12:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:07:45 --> Controller Class Initialized
INFO - 2017-02-18 12:07:45 --> Database Driver Class Initialized
INFO - 2017-02-18 12:07:45 --> Model Class Initialized
INFO - 2017-02-18 12:07:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:07:45 --> Form Validation Class Initialized
INFO - 2017-02-18 12:07:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:07:45 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:07:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:07:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:07:45 --> Final output sent to browser
DEBUG - 2017-02-18 12:07:45 --> Total execution time: 0.0999
INFO - 2017-02-18 12:08:15 --> Config Class Initialized
INFO - 2017-02-18 12:08:15 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:08:15 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:08:15 --> Utf8 Class Initialized
INFO - 2017-02-18 12:08:15 --> URI Class Initialized
INFO - 2017-02-18 12:08:15 --> Router Class Initialized
INFO - 2017-02-18 12:08:15 --> Output Class Initialized
INFO - 2017-02-18 12:08:15 --> Security Class Initialized
DEBUG - 2017-02-18 12:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:08:15 --> Input Class Initialized
INFO - 2017-02-18 12:08:15 --> Language Class Initialized
INFO - 2017-02-18 12:08:15 --> Loader Class Initialized
INFO - 2017-02-18 12:08:15 --> Helper loaded: url_helper
INFO - 2017-02-18 12:08:15 --> Helper loaded: language_helper
INFO - 2017-02-18 12:08:15 --> Helper loaded: html_helper
INFO - 2017-02-18 12:08:15 --> Helper loaded: form_helper
INFO - 2017-02-18 12:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:08:15 --> Controller Class Initialized
INFO - 2017-02-18 12:08:15 --> Database Driver Class Initialized
INFO - 2017-02-18 12:08:15 --> Model Class Initialized
INFO - 2017-02-18 12:08:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:08:15 --> Form Validation Class Initialized
INFO - 2017-02-18 12:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:08:15 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:08:15 --> Final output sent to browser
DEBUG - 2017-02-18 12:08:15 --> Total execution time: 0.0845
INFO - 2017-02-18 12:09:43 --> Config Class Initialized
INFO - 2017-02-18 12:09:43 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:09:43 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:09:43 --> Utf8 Class Initialized
INFO - 2017-02-18 12:09:43 --> URI Class Initialized
INFO - 2017-02-18 12:09:43 --> Router Class Initialized
INFO - 2017-02-18 12:09:43 --> Output Class Initialized
INFO - 2017-02-18 12:09:43 --> Security Class Initialized
DEBUG - 2017-02-18 12:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:09:43 --> Input Class Initialized
INFO - 2017-02-18 12:09:43 --> Language Class Initialized
INFO - 2017-02-18 12:09:43 --> Loader Class Initialized
INFO - 2017-02-18 12:09:43 --> Helper loaded: url_helper
INFO - 2017-02-18 12:09:43 --> Helper loaded: language_helper
INFO - 2017-02-18 12:09:43 --> Helper loaded: html_helper
INFO - 2017-02-18 12:09:43 --> Helper loaded: form_helper
INFO - 2017-02-18 12:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:09:43 --> Controller Class Initialized
INFO - 2017-02-18 12:09:43 --> Database Driver Class Initialized
INFO - 2017-02-18 12:09:43 --> Model Class Initialized
INFO - 2017-02-18 12:09:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:09:43 --> Form Validation Class Initialized
INFO - 2017-02-18 12:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:09:43 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:09:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:09:43 --> Final output sent to browser
DEBUG - 2017-02-18 12:09:43 --> Total execution time: 0.0931
INFO - 2017-02-18 12:09:45 --> Config Class Initialized
INFO - 2017-02-18 12:09:45 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:09:45 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:09:45 --> Utf8 Class Initialized
INFO - 2017-02-18 12:09:45 --> URI Class Initialized
INFO - 2017-02-18 12:09:45 --> Router Class Initialized
INFO - 2017-02-18 12:09:45 --> Output Class Initialized
INFO - 2017-02-18 12:09:45 --> Security Class Initialized
DEBUG - 2017-02-18 12:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:09:45 --> Input Class Initialized
INFO - 2017-02-18 12:09:45 --> Language Class Initialized
INFO - 2017-02-18 12:09:45 --> Loader Class Initialized
INFO - 2017-02-18 12:09:45 --> Helper loaded: url_helper
INFO - 2017-02-18 12:09:45 --> Helper loaded: language_helper
INFO - 2017-02-18 12:09:45 --> Helper loaded: html_helper
INFO - 2017-02-18 12:09:45 --> Helper loaded: form_helper
INFO - 2017-02-18 12:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:09:45 --> Controller Class Initialized
INFO - 2017-02-18 12:09:45 --> Database Driver Class Initialized
INFO - 2017-02-18 12:09:45 --> Model Class Initialized
INFO - 2017-02-18 12:09:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:09:45 --> Form Validation Class Initialized
INFO - 2017-02-18 12:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:09:45 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:09:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:09:45 --> Final output sent to browser
DEBUG - 2017-02-18 12:09:45 --> Total execution time: 0.0837
INFO - 2017-02-18 12:11:17 --> Config Class Initialized
INFO - 2017-02-18 12:11:17 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:11:17 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:11:17 --> Utf8 Class Initialized
INFO - 2017-02-18 12:11:17 --> URI Class Initialized
INFO - 2017-02-18 12:11:17 --> Router Class Initialized
INFO - 2017-02-18 12:11:17 --> Output Class Initialized
INFO - 2017-02-18 12:11:17 --> Security Class Initialized
DEBUG - 2017-02-18 12:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:11:17 --> Input Class Initialized
INFO - 2017-02-18 12:11:17 --> Language Class Initialized
INFO - 2017-02-18 12:11:17 --> Loader Class Initialized
INFO - 2017-02-18 12:11:17 --> Helper loaded: url_helper
INFO - 2017-02-18 12:11:17 --> Helper loaded: language_helper
INFO - 2017-02-18 12:11:17 --> Helper loaded: html_helper
INFO - 2017-02-18 12:11:17 --> Helper loaded: form_helper
INFO - 2017-02-18 12:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:11:17 --> Controller Class Initialized
INFO - 2017-02-18 12:11:17 --> Database Driver Class Initialized
INFO - 2017-02-18 12:11:17 --> Model Class Initialized
INFO - 2017-02-18 12:11:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:11:17 --> Form Validation Class Initialized
INFO - 2017-02-18 12:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:11:17 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:11:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:11:17 --> Final output sent to browser
DEBUG - 2017-02-18 12:11:17 --> Total execution time: 0.1251
INFO - 2017-02-18 12:11:37 --> Config Class Initialized
INFO - 2017-02-18 12:11:37 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:11:37 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:11:37 --> Utf8 Class Initialized
INFO - 2017-02-18 12:11:37 --> URI Class Initialized
INFO - 2017-02-18 12:11:37 --> Router Class Initialized
INFO - 2017-02-18 12:11:37 --> Output Class Initialized
INFO - 2017-02-18 12:11:37 --> Security Class Initialized
DEBUG - 2017-02-18 12:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:11:37 --> Input Class Initialized
INFO - 2017-02-18 12:11:37 --> Language Class Initialized
INFO - 2017-02-18 12:11:37 --> Loader Class Initialized
INFO - 2017-02-18 12:11:37 --> Helper loaded: url_helper
INFO - 2017-02-18 12:11:37 --> Helper loaded: language_helper
INFO - 2017-02-18 12:11:37 --> Helper loaded: html_helper
INFO - 2017-02-18 12:11:37 --> Helper loaded: form_helper
INFO - 2017-02-18 12:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:11:37 --> Controller Class Initialized
INFO - 2017-02-18 12:11:37 --> Database Driver Class Initialized
INFO - 2017-02-18 12:11:37 --> Model Class Initialized
INFO - 2017-02-18 12:11:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:11:37 --> Form Validation Class Initialized
INFO - 2017-02-18 12:11:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:11:37 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:11:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:11:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:11:37 --> Final output sent to browser
DEBUG - 2017-02-18 12:11:37 --> Total execution time: 0.1261
INFO - 2017-02-18 12:11:53 --> Config Class Initialized
INFO - 2017-02-18 12:11:53 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:11:53 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:11:53 --> Utf8 Class Initialized
INFO - 2017-02-18 12:11:53 --> URI Class Initialized
INFO - 2017-02-18 12:11:53 --> Router Class Initialized
INFO - 2017-02-18 12:11:53 --> Output Class Initialized
INFO - 2017-02-18 12:11:53 --> Security Class Initialized
DEBUG - 2017-02-18 12:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:11:53 --> Input Class Initialized
INFO - 2017-02-18 12:11:53 --> Language Class Initialized
INFO - 2017-02-18 12:11:53 --> Loader Class Initialized
INFO - 2017-02-18 12:11:53 --> Helper loaded: url_helper
INFO - 2017-02-18 12:11:53 --> Helper loaded: language_helper
INFO - 2017-02-18 12:11:53 --> Helper loaded: html_helper
INFO - 2017-02-18 12:11:53 --> Helper loaded: form_helper
INFO - 2017-02-18 12:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:11:53 --> Controller Class Initialized
INFO - 2017-02-18 12:11:53 --> Database Driver Class Initialized
INFO - 2017-02-18 12:11:53 --> Model Class Initialized
INFO - 2017-02-18 12:11:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:11:53 --> Form Validation Class Initialized
INFO - 2017-02-18 12:11:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:11:53 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:11:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:11:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:11:53 --> Final output sent to browser
DEBUG - 2017-02-18 12:11:53 --> Total execution time: 0.1123
INFO - 2017-02-18 12:14:11 --> Config Class Initialized
INFO - 2017-02-18 12:14:11 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:14:11 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:14:11 --> Utf8 Class Initialized
INFO - 2017-02-18 12:14:11 --> URI Class Initialized
INFO - 2017-02-18 12:14:11 --> Router Class Initialized
INFO - 2017-02-18 12:14:11 --> Output Class Initialized
INFO - 2017-02-18 12:14:11 --> Security Class Initialized
DEBUG - 2017-02-18 12:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:14:11 --> Input Class Initialized
INFO - 2017-02-18 12:14:11 --> Language Class Initialized
INFO - 2017-02-18 12:14:11 --> Loader Class Initialized
INFO - 2017-02-18 12:14:11 --> Helper loaded: url_helper
INFO - 2017-02-18 12:14:11 --> Helper loaded: language_helper
INFO - 2017-02-18 12:14:11 --> Helper loaded: html_helper
INFO - 2017-02-18 12:14:11 --> Helper loaded: form_helper
INFO - 2017-02-18 12:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:14:11 --> Controller Class Initialized
INFO - 2017-02-18 12:14:11 --> Database Driver Class Initialized
INFO - 2017-02-18 12:14:11 --> Model Class Initialized
INFO - 2017-02-18 12:14:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:14:11 --> Form Validation Class Initialized
INFO - 2017-02-18 12:14:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:14:11 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:14:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:14:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:14:11 --> Final output sent to browser
DEBUG - 2017-02-18 12:14:11 --> Total execution time: 0.0968
INFO - 2017-02-18 12:15:17 --> Config Class Initialized
INFO - 2017-02-18 12:15:17 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:15:17 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:15:17 --> Utf8 Class Initialized
INFO - 2017-02-18 12:15:17 --> URI Class Initialized
INFO - 2017-02-18 12:15:17 --> Router Class Initialized
INFO - 2017-02-18 12:15:17 --> Output Class Initialized
INFO - 2017-02-18 12:15:17 --> Security Class Initialized
DEBUG - 2017-02-18 12:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:15:17 --> Input Class Initialized
INFO - 2017-02-18 12:15:17 --> Language Class Initialized
INFO - 2017-02-18 12:15:17 --> Loader Class Initialized
INFO - 2017-02-18 12:15:17 --> Helper loaded: url_helper
INFO - 2017-02-18 12:15:17 --> Helper loaded: language_helper
INFO - 2017-02-18 12:15:17 --> Helper loaded: html_helper
INFO - 2017-02-18 12:15:17 --> Helper loaded: form_helper
INFO - 2017-02-18 12:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:15:17 --> Controller Class Initialized
INFO - 2017-02-18 12:15:17 --> Database Driver Class Initialized
INFO - 2017-02-18 12:15:17 --> Model Class Initialized
INFO - 2017-02-18 12:15:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:15:17 --> Form Validation Class Initialized
INFO - 2017-02-18 12:15:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:15:17 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:15:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-18 12:15:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:15:17 --> Final output sent to browser
DEBUG - 2017-02-18 12:15:17 --> Total execution time: 0.1128
INFO - 2017-02-18 12:15:33 --> Config Class Initialized
INFO - 2017-02-18 12:15:33 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:15:33 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:15:33 --> Utf8 Class Initialized
INFO - 2017-02-18 12:15:33 --> URI Class Initialized
INFO - 2017-02-18 12:15:33 --> Router Class Initialized
INFO - 2017-02-18 12:15:33 --> Output Class Initialized
INFO - 2017-02-18 12:15:33 --> Security Class Initialized
DEBUG - 2017-02-18 12:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:15:33 --> Input Class Initialized
INFO - 2017-02-18 12:15:33 --> Language Class Initialized
INFO - 2017-02-18 12:15:33 --> Loader Class Initialized
INFO - 2017-02-18 12:15:33 --> Helper loaded: url_helper
INFO - 2017-02-18 12:15:33 --> Helper loaded: language_helper
INFO - 2017-02-18 12:15:33 --> Helper loaded: html_helper
INFO - 2017-02-18 12:15:33 --> Helper loaded: form_helper
INFO - 2017-02-18 12:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:15:33 --> Controller Class Initialized
INFO - 2017-02-18 12:15:33 --> Database Driver Class Initialized
INFO - 2017-02-18 12:15:33 --> Model Class Initialized
INFO - 2017-02-18 12:15:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:15:33 --> Form Validation Class Initialized
INFO - 2017-02-18 12:15:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:15:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:15:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:15:33 --> Final output sent to browser
DEBUG - 2017-02-18 12:15:33 --> Total execution time: 0.1012
INFO - 2017-02-18 12:15:55 --> Config Class Initialized
INFO - 2017-02-18 12:15:55 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:15:55 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:15:55 --> Utf8 Class Initialized
INFO - 2017-02-18 12:15:55 --> URI Class Initialized
INFO - 2017-02-18 12:15:55 --> Router Class Initialized
INFO - 2017-02-18 12:15:55 --> Output Class Initialized
INFO - 2017-02-18 12:15:55 --> Security Class Initialized
DEBUG - 2017-02-18 12:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:15:55 --> Input Class Initialized
INFO - 2017-02-18 12:15:55 --> Language Class Initialized
INFO - 2017-02-18 12:15:55 --> Loader Class Initialized
INFO - 2017-02-18 12:15:55 --> Helper loaded: url_helper
INFO - 2017-02-18 12:15:55 --> Helper loaded: language_helper
INFO - 2017-02-18 12:15:55 --> Helper loaded: html_helper
INFO - 2017-02-18 12:15:55 --> Helper loaded: form_helper
INFO - 2017-02-18 12:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:15:55 --> Controller Class Initialized
INFO - 2017-02-18 12:15:55 --> Database Driver Class Initialized
INFO - 2017-02-18 12:15:55 --> Model Class Initialized
INFO - 2017-02-18 12:15:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:15:55 --> Form Validation Class Initialized
INFO - 2017-02-18 12:15:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:15:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:15:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:15:55 --> Final output sent to browser
DEBUG - 2017-02-18 12:15:55 --> Total execution time: 0.1160
INFO - 2017-02-18 12:16:24 --> Config Class Initialized
INFO - 2017-02-18 12:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:16:24 --> Utf8 Class Initialized
INFO - 2017-02-18 12:16:24 --> URI Class Initialized
INFO - 2017-02-18 12:16:24 --> Router Class Initialized
INFO - 2017-02-18 12:16:24 --> Output Class Initialized
INFO - 2017-02-18 12:16:24 --> Security Class Initialized
DEBUG - 2017-02-18 12:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:16:24 --> Input Class Initialized
INFO - 2017-02-18 12:16:24 --> Language Class Initialized
INFO - 2017-02-18 12:16:24 --> Loader Class Initialized
INFO - 2017-02-18 12:16:24 --> Helper loaded: url_helper
INFO - 2017-02-18 12:16:24 --> Helper loaded: language_helper
INFO - 2017-02-18 12:16:24 --> Helper loaded: html_helper
INFO - 2017-02-18 12:16:24 --> Helper loaded: form_helper
INFO - 2017-02-18 12:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:16:24 --> Controller Class Initialized
INFO - 2017-02-18 12:16:24 --> Database Driver Class Initialized
INFO - 2017-02-18 12:16:24 --> Model Class Initialized
INFO - 2017-02-18 12:16:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:16:24 --> Form Validation Class Initialized
INFO - 2017-02-18 12:16:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:16:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:16:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:16:24 --> Final output sent to browser
DEBUG - 2017-02-18 12:16:24 --> Total execution time: 0.1535
INFO - 2017-02-18 12:16:39 --> Config Class Initialized
INFO - 2017-02-18 12:16:39 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:16:39 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:16:39 --> Utf8 Class Initialized
INFO - 2017-02-18 12:16:39 --> URI Class Initialized
INFO - 2017-02-18 12:16:39 --> Router Class Initialized
INFO - 2017-02-18 12:16:39 --> Output Class Initialized
INFO - 2017-02-18 12:16:39 --> Security Class Initialized
DEBUG - 2017-02-18 12:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:16:40 --> Input Class Initialized
INFO - 2017-02-18 12:16:40 --> Language Class Initialized
INFO - 2017-02-18 12:16:40 --> Loader Class Initialized
INFO - 2017-02-18 12:16:40 --> Helper loaded: url_helper
INFO - 2017-02-18 12:16:40 --> Helper loaded: language_helper
INFO - 2017-02-18 12:16:40 --> Helper loaded: html_helper
INFO - 2017-02-18 12:16:40 --> Helper loaded: form_helper
INFO - 2017-02-18 12:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:16:40 --> Controller Class Initialized
INFO - 2017-02-18 12:16:40 --> Database Driver Class Initialized
INFO - 2017-02-18 12:16:40 --> Model Class Initialized
INFO - 2017-02-18 12:16:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:16:40 --> Form Validation Class Initialized
INFO - 2017-02-18 12:16:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:16:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:16:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:16:40 --> Final output sent to browser
DEBUG - 2017-02-18 12:16:40 --> Total execution time: 0.1728
INFO - 2017-02-18 12:16:54 --> Config Class Initialized
INFO - 2017-02-18 12:16:54 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:16:54 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:16:54 --> Utf8 Class Initialized
INFO - 2017-02-18 12:16:54 --> URI Class Initialized
INFO - 2017-02-18 12:16:54 --> Router Class Initialized
INFO - 2017-02-18 12:16:54 --> Output Class Initialized
INFO - 2017-02-18 12:16:54 --> Security Class Initialized
DEBUG - 2017-02-18 12:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:16:54 --> Input Class Initialized
INFO - 2017-02-18 12:16:54 --> Language Class Initialized
INFO - 2017-02-18 12:16:54 --> Loader Class Initialized
INFO - 2017-02-18 12:16:54 --> Helper loaded: url_helper
INFO - 2017-02-18 12:16:54 --> Helper loaded: language_helper
INFO - 2017-02-18 12:16:54 --> Helper loaded: html_helper
INFO - 2017-02-18 12:16:54 --> Helper loaded: form_helper
INFO - 2017-02-18 12:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:16:54 --> Controller Class Initialized
INFO - 2017-02-18 12:16:54 --> Database Driver Class Initialized
INFO - 2017-02-18 12:16:54 --> Model Class Initialized
INFO - 2017-02-18 12:16:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:16:54 --> Form Validation Class Initialized
INFO - 2017-02-18 12:16:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:16:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:16:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:16:54 --> Final output sent to browser
DEBUG - 2017-02-18 12:16:54 --> Total execution time: 0.1831
INFO - 2017-02-18 12:23:46 --> Config Class Initialized
INFO - 2017-02-18 12:23:46 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:23:46 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:23:46 --> Utf8 Class Initialized
INFO - 2017-02-18 12:23:46 --> URI Class Initialized
INFO - 2017-02-18 12:23:46 --> Router Class Initialized
INFO - 2017-02-18 12:23:46 --> Output Class Initialized
INFO - 2017-02-18 12:23:46 --> Security Class Initialized
DEBUG - 2017-02-18 12:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:23:46 --> Input Class Initialized
INFO - 2017-02-18 12:23:46 --> Language Class Initialized
INFO - 2017-02-18 12:23:46 --> Loader Class Initialized
INFO - 2017-02-18 12:23:46 --> Helper loaded: url_helper
INFO - 2017-02-18 12:23:46 --> Helper loaded: language_helper
INFO - 2017-02-18 12:23:46 --> Helper loaded: html_helper
INFO - 2017-02-18 12:23:46 --> Helper loaded: form_helper
INFO - 2017-02-18 12:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:23:46 --> Controller Class Initialized
INFO - 2017-02-18 12:23:46 --> Database Driver Class Initialized
INFO - 2017-02-18 12:23:46 --> Model Class Initialized
INFO - 2017-02-18 12:23:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:23:46 --> Form Validation Class Initialized
INFO - 2017-02-18 12:23:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:23:46 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:23:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:23:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:23:46 --> Final output sent to browser
DEBUG - 2017-02-18 12:23:46 --> Total execution time: 0.1191
INFO - 2017-02-18 12:25:03 --> Config Class Initialized
INFO - 2017-02-18 12:25:03 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:25:03 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:25:03 --> Utf8 Class Initialized
INFO - 2017-02-18 12:25:03 --> URI Class Initialized
INFO - 2017-02-18 12:25:03 --> Router Class Initialized
INFO - 2017-02-18 12:25:03 --> Output Class Initialized
INFO - 2017-02-18 12:25:03 --> Security Class Initialized
DEBUG - 2017-02-18 12:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:25:03 --> Input Class Initialized
INFO - 2017-02-18 12:25:03 --> Language Class Initialized
INFO - 2017-02-18 12:25:03 --> Loader Class Initialized
INFO - 2017-02-18 12:25:03 --> Helper loaded: url_helper
INFO - 2017-02-18 12:25:03 --> Helper loaded: language_helper
INFO - 2017-02-18 12:25:03 --> Helper loaded: html_helper
INFO - 2017-02-18 12:25:03 --> Helper loaded: form_helper
INFO - 2017-02-18 12:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:25:03 --> Controller Class Initialized
INFO - 2017-02-18 12:25:03 --> Database Driver Class Initialized
INFO - 2017-02-18 12:25:03 --> Model Class Initialized
INFO - 2017-02-18 12:25:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:25:03 --> Form Validation Class Initialized
INFO - 2017-02-18 12:25:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:25:03 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:25:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-18 12:25:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:25:03 --> Final output sent to browser
DEBUG - 2017-02-18 12:25:03 --> Total execution time: 0.1113
INFO - 2017-02-18 12:31:23 --> Config Class Initialized
INFO - 2017-02-18 12:31:23 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:31:23 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:31:23 --> Utf8 Class Initialized
INFO - 2017-02-18 12:31:23 --> URI Class Initialized
INFO - 2017-02-18 12:31:23 --> Router Class Initialized
INFO - 2017-02-18 12:31:23 --> Output Class Initialized
INFO - 2017-02-18 12:31:23 --> Security Class Initialized
DEBUG - 2017-02-18 12:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:31:23 --> Input Class Initialized
INFO - 2017-02-18 12:31:23 --> Language Class Initialized
INFO - 2017-02-18 12:31:23 --> Loader Class Initialized
INFO - 2017-02-18 12:31:23 --> Helper loaded: url_helper
INFO - 2017-02-18 12:31:23 --> Helper loaded: language_helper
INFO - 2017-02-18 12:31:23 --> Helper loaded: html_helper
INFO - 2017-02-18 12:31:23 --> Helper loaded: form_helper
INFO - 2017-02-18 12:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:31:23 --> Controller Class Initialized
INFO - 2017-02-18 12:31:23 --> Database Driver Class Initialized
INFO - 2017-02-18 12:31:23 --> Model Class Initialized
INFO - 2017-02-18 12:31:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:31:23 --> Form Validation Class Initialized
INFO - 2017-02-18 12:31:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:31:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:31:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:31:23 --> Final output sent to browser
DEBUG - 2017-02-18 12:31:23 --> Total execution time: 0.1120
INFO - 2017-02-18 12:38:24 --> Config Class Initialized
INFO - 2017-02-18 12:38:24 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:38:24 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:38:24 --> Utf8 Class Initialized
INFO - 2017-02-18 12:38:24 --> URI Class Initialized
INFO - 2017-02-18 12:38:24 --> Router Class Initialized
INFO - 2017-02-18 12:38:24 --> Output Class Initialized
INFO - 2017-02-18 12:38:24 --> Security Class Initialized
DEBUG - 2017-02-18 12:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:38:24 --> Input Class Initialized
INFO - 2017-02-18 12:38:24 --> Language Class Initialized
INFO - 2017-02-18 12:38:24 --> Loader Class Initialized
INFO - 2017-02-18 12:38:24 --> Helper loaded: url_helper
INFO - 2017-02-18 12:38:24 --> Helper loaded: language_helper
INFO - 2017-02-18 12:38:24 --> Helper loaded: html_helper
INFO - 2017-02-18 12:38:24 --> Helper loaded: form_helper
INFO - 2017-02-18 12:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:38:24 --> Controller Class Initialized
INFO - 2017-02-18 12:38:24 --> Database Driver Class Initialized
INFO - 2017-02-18 12:38:24 --> Model Class Initialized
INFO - 2017-02-18 12:38:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:38:24 --> Form Validation Class Initialized
INFO - 2017-02-18 12:38:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:38:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 12:38:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:38:24 --> Final output sent to browser
DEBUG - 2017-02-18 12:38:24 --> Total execution time: 0.1529
INFO - 2017-02-18 12:39:25 --> Config Class Initialized
INFO - 2017-02-18 12:39:25 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:39:25 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:39:25 --> Utf8 Class Initialized
INFO - 2017-02-18 12:39:25 --> URI Class Initialized
INFO - 2017-02-18 12:39:25 --> Router Class Initialized
INFO - 2017-02-18 12:39:25 --> Output Class Initialized
INFO - 2017-02-18 12:39:25 --> Security Class Initialized
DEBUG - 2017-02-18 12:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:39:25 --> Input Class Initialized
INFO - 2017-02-18 12:39:25 --> Language Class Initialized
INFO - 2017-02-18 12:39:25 --> Loader Class Initialized
INFO - 2017-02-18 12:39:25 --> Helper loaded: url_helper
INFO - 2017-02-18 12:39:25 --> Helper loaded: language_helper
INFO - 2017-02-18 12:39:25 --> Helper loaded: html_helper
INFO - 2017-02-18 12:39:25 --> Helper loaded: form_helper
INFO - 2017-02-18 12:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:39:25 --> Controller Class Initialized
INFO - 2017-02-18 12:39:25 --> Database Driver Class Initialized
INFO - 2017-02-18 12:39:25 --> Model Class Initialized
INFO - 2017-02-18 12:39:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:39:25 --> Form Validation Class Initialized
INFO - 2017-02-18 12:39:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:39:25 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:39:50 --> Config Class Initialized
INFO - 2017-02-18 12:39:50 --> Hooks Class Initialized
DEBUG - 2017-02-18 12:39:50 --> UTF-8 Support Enabled
INFO - 2017-02-18 12:39:50 --> Utf8 Class Initialized
INFO - 2017-02-18 12:39:50 --> URI Class Initialized
INFO - 2017-02-18 12:39:50 --> Router Class Initialized
INFO - 2017-02-18 12:39:50 --> Output Class Initialized
INFO - 2017-02-18 12:39:50 --> Security Class Initialized
DEBUG - 2017-02-18 12:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 12:39:50 --> Input Class Initialized
INFO - 2017-02-18 12:39:50 --> Language Class Initialized
INFO - 2017-02-18 12:39:50 --> Loader Class Initialized
INFO - 2017-02-18 12:39:50 --> Helper loaded: url_helper
INFO - 2017-02-18 12:39:50 --> Helper loaded: language_helper
INFO - 2017-02-18 12:39:50 --> Helper loaded: html_helper
INFO - 2017-02-18 12:39:50 --> Helper loaded: form_helper
INFO - 2017-02-18 12:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 12:39:50 --> Controller Class Initialized
INFO - 2017-02-18 12:39:50 --> Database Driver Class Initialized
INFO - 2017-02-18 12:39:50 --> Model Class Initialized
INFO - 2017-02-18 12:39:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 12:39:50 --> Form Validation Class Initialized
INFO - 2017-02-18 12:39:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 12:39:50 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 12:39:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-18 12:39:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 12:39:50 --> Final output sent to browser
DEBUG - 2017-02-18 12:39:50 --> Total execution time: 0.1588
INFO - 2017-02-18 13:05:27 --> Config Class Initialized
INFO - 2017-02-18 13:05:27 --> Hooks Class Initialized
DEBUG - 2017-02-18 13:05:27 --> UTF-8 Support Enabled
INFO - 2017-02-18 13:05:27 --> Utf8 Class Initialized
INFO - 2017-02-18 13:05:27 --> URI Class Initialized
INFO - 2017-02-18 13:05:27 --> Router Class Initialized
INFO - 2017-02-18 13:05:27 --> Output Class Initialized
INFO - 2017-02-18 13:05:27 --> Security Class Initialized
DEBUG - 2017-02-18 13:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 13:05:27 --> Input Class Initialized
INFO - 2017-02-18 13:05:27 --> Language Class Initialized
INFO - 2017-02-18 13:05:27 --> Loader Class Initialized
INFO - 2017-02-18 13:05:27 --> Helper loaded: url_helper
INFO - 2017-02-18 13:05:27 --> Helper loaded: language_helper
INFO - 2017-02-18 13:05:27 --> Helper loaded: html_helper
INFO - 2017-02-18 13:05:27 --> Helper loaded: form_helper
INFO - 2017-02-18 13:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 13:05:27 --> Controller Class Initialized
INFO - 2017-02-18 13:05:27 --> Database Driver Class Initialized
INFO - 2017-02-18 13:05:27 --> Model Class Initialized
INFO - 2017-02-18 13:05:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 13:05:27 --> Form Validation Class Initialized
INFO - 2017-02-18 13:05:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 13:05:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 13:05:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 13:05:27 --> Final output sent to browser
DEBUG - 2017-02-18 13:05:27 --> Total execution time: 0.1319
INFO - 2017-02-18 13:06:21 --> Config Class Initialized
INFO - 2017-02-18 13:06:21 --> Hooks Class Initialized
DEBUG - 2017-02-18 13:06:21 --> UTF-8 Support Enabled
INFO - 2017-02-18 13:06:21 --> Utf8 Class Initialized
INFO - 2017-02-18 13:06:21 --> URI Class Initialized
INFO - 2017-02-18 13:06:21 --> Router Class Initialized
INFO - 2017-02-18 13:06:21 --> Output Class Initialized
INFO - 2017-02-18 13:06:21 --> Security Class Initialized
DEBUG - 2017-02-18 13:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 13:06:21 --> Input Class Initialized
INFO - 2017-02-18 13:06:21 --> Language Class Initialized
INFO - 2017-02-18 13:06:21 --> Loader Class Initialized
INFO - 2017-02-18 13:06:21 --> Helper loaded: url_helper
INFO - 2017-02-18 13:06:21 --> Helper loaded: language_helper
INFO - 2017-02-18 13:06:21 --> Helper loaded: html_helper
INFO - 2017-02-18 13:06:21 --> Helper loaded: form_helper
INFO - 2017-02-18 13:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 13:06:21 --> Controller Class Initialized
INFO - 2017-02-18 13:06:21 --> Database Driver Class Initialized
INFO - 2017-02-18 13:06:21 --> Model Class Initialized
INFO - 2017-02-18 13:06:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 13:06:21 --> Form Validation Class Initialized
INFO - 2017-02-18 13:06:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 13:06:21 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-18 13:06:21 --> Severity: Notice --> A non well formed numeric value encountered C:\wamp64\www\savsoftquiz\application\models\Register_model.php 11
INFO - 2017-02-18 13:07:59 --> Config Class Initialized
INFO - 2017-02-18 13:07:59 --> Hooks Class Initialized
DEBUG - 2017-02-18 13:07:59 --> UTF-8 Support Enabled
INFO - 2017-02-18 13:07:59 --> Utf8 Class Initialized
INFO - 2017-02-18 13:07:59 --> URI Class Initialized
INFO - 2017-02-18 13:07:59 --> Router Class Initialized
INFO - 2017-02-18 13:07:59 --> Output Class Initialized
INFO - 2017-02-18 13:07:59 --> Security Class Initialized
DEBUG - 2017-02-18 13:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 13:07:59 --> Input Class Initialized
INFO - 2017-02-18 13:07:59 --> Language Class Initialized
INFO - 2017-02-18 13:07:59 --> Loader Class Initialized
INFO - 2017-02-18 13:07:59 --> Helper loaded: url_helper
INFO - 2017-02-18 13:07:59 --> Helper loaded: language_helper
INFO - 2017-02-18 13:07:59 --> Helper loaded: html_helper
INFO - 2017-02-18 13:07:59 --> Helper loaded: form_helper
INFO - 2017-02-18 13:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 13:07:59 --> Controller Class Initialized
INFO - 2017-02-18 13:07:59 --> Database Driver Class Initialized
INFO - 2017-02-18 13:07:59 --> Model Class Initialized
INFO - 2017-02-18 13:07:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 13:07:59 --> Form Validation Class Initialized
INFO - 2017-02-18 13:07:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 13:07:59 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 13:08:12 --> Config Class Initialized
INFO - 2017-02-18 13:08:12 --> Hooks Class Initialized
DEBUG - 2017-02-18 13:08:12 --> UTF-8 Support Enabled
INFO - 2017-02-18 13:08:12 --> Utf8 Class Initialized
INFO - 2017-02-18 13:08:12 --> URI Class Initialized
INFO - 2017-02-18 13:08:12 --> Router Class Initialized
INFO - 2017-02-18 13:08:12 --> Output Class Initialized
INFO - 2017-02-18 13:08:12 --> Security Class Initialized
DEBUG - 2017-02-18 13:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 13:08:12 --> Input Class Initialized
INFO - 2017-02-18 13:08:12 --> Language Class Initialized
INFO - 2017-02-18 13:08:12 --> Loader Class Initialized
INFO - 2017-02-18 13:08:12 --> Helper loaded: url_helper
INFO - 2017-02-18 13:08:12 --> Helper loaded: language_helper
INFO - 2017-02-18 13:08:12 --> Helper loaded: html_helper
INFO - 2017-02-18 13:08:12 --> Helper loaded: form_helper
INFO - 2017-02-18 13:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 13:08:13 --> Controller Class Initialized
INFO - 2017-02-18 13:08:13 --> Database Driver Class Initialized
INFO - 2017-02-18 13:08:13 --> Model Class Initialized
INFO - 2017-02-18 13:08:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 13:08:13 --> Form Validation Class Initialized
INFO - 2017-02-18 13:08:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 13:08:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 13:08:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 13:08:13 --> Final output sent to browser
DEBUG - 2017-02-18 13:08:13 --> Total execution time: 0.1770
INFO - 2017-02-18 13:09:38 --> Config Class Initialized
INFO - 2017-02-18 13:09:38 --> Hooks Class Initialized
DEBUG - 2017-02-18 13:09:38 --> UTF-8 Support Enabled
INFO - 2017-02-18 13:09:38 --> Utf8 Class Initialized
INFO - 2017-02-18 13:09:38 --> URI Class Initialized
INFO - 2017-02-18 13:09:38 --> Router Class Initialized
INFO - 2017-02-18 13:09:38 --> Output Class Initialized
INFO - 2017-02-18 13:09:38 --> Security Class Initialized
DEBUG - 2017-02-18 13:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 13:09:38 --> Input Class Initialized
INFO - 2017-02-18 13:09:38 --> Language Class Initialized
INFO - 2017-02-18 13:09:38 --> Loader Class Initialized
INFO - 2017-02-18 13:09:38 --> Helper loaded: url_helper
INFO - 2017-02-18 13:09:38 --> Helper loaded: language_helper
INFO - 2017-02-18 13:09:38 --> Helper loaded: html_helper
INFO - 2017-02-18 13:09:38 --> Helper loaded: form_helper
INFO - 2017-02-18 13:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 13:09:38 --> Controller Class Initialized
INFO - 2017-02-18 13:09:38 --> Database Driver Class Initialized
INFO - 2017-02-18 13:09:38 --> Model Class Initialized
INFO - 2017-02-18 13:09:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 13:09:38 --> Form Validation Class Initialized
INFO - 2017-02-18 13:09:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 13:09:38 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 13:09:52 --> Config Class Initialized
INFO - 2017-02-18 13:09:52 --> Hooks Class Initialized
DEBUG - 2017-02-18 13:09:52 --> UTF-8 Support Enabled
INFO - 2017-02-18 13:09:52 --> Utf8 Class Initialized
INFO - 2017-02-18 13:09:52 --> URI Class Initialized
INFO - 2017-02-18 13:09:52 --> Router Class Initialized
INFO - 2017-02-18 13:09:52 --> Output Class Initialized
INFO - 2017-02-18 13:09:52 --> Security Class Initialized
DEBUG - 2017-02-18 13:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 13:09:52 --> Input Class Initialized
INFO - 2017-02-18 13:09:52 --> Language Class Initialized
INFO - 2017-02-18 13:09:52 --> Loader Class Initialized
INFO - 2017-02-18 13:09:52 --> Helper loaded: url_helper
INFO - 2017-02-18 13:09:52 --> Helper loaded: language_helper
INFO - 2017-02-18 13:09:52 --> Helper loaded: html_helper
INFO - 2017-02-18 13:09:52 --> Helper loaded: form_helper
INFO - 2017-02-18 13:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 13:09:52 --> Controller Class Initialized
INFO - 2017-02-18 13:09:52 --> Database Driver Class Initialized
INFO - 2017-02-18 13:09:52 --> Model Class Initialized
INFO - 2017-02-18 13:09:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 13:09:52 --> Form Validation Class Initialized
INFO - 2017-02-18 13:09:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 13:09:52 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-18 13:09:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-18 13:09:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 13:09:53 --> Final output sent to browser
DEBUG - 2017-02-18 13:09:53 --> Total execution time: 0.1654
INFO - 2017-02-18 15:34:44 --> Config Class Initialized
INFO - 2017-02-18 15:34:44 --> Hooks Class Initialized
DEBUG - 2017-02-18 15:34:44 --> UTF-8 Support Enabled
INFO - 2017-02-18 15:34:44 --> Utf8 Class Initialized
INFO - 2017-02-18 15:34:44 --> URI Class Initialized
INFO - 2017-02-18 15:34:44 --> Router Class Initialized
INFO - 2017-02-18 15:34:44 --> Output Class Initialized
INFO - 2017-02-18 15:34:44 --> Security Class Initialized
DEBUG - 2017-02-18 15:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-18 15:34:44 --> Input Class Initialized
INFO - 2017-02-18 15:34:44 --> Language Class Initialized
INFO - 2017-02-18 15:34:44 --> Loader Class Initialized
INFO - 2017-02-18 15:34:44 --> Helper loaded: url_helper
INFO - 2017-02-18 15:34:44 --> Helper loaded: language_helper
INFO - 2017-02-18 15:34:44 --> Helper loaded: html_helper
INFO - 2017-02-18 15:34:44 --> Helper loaded: form_helper
INFO - 2017-02-18 15:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-18 15:34:44 --> Controller Class Initialized
INFO - 2017-02-18 15:34:44 --> Database Driver Class Initialized
INFO - 2017-02-18 15:34:44 --> Model Class Initialized
INFO - 2017-02-18 15:34:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-18 15:34:44 --> Form Validation Class Initialized
INFO - 2017-02-18 15:34:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-18 15:34:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-18 15:34:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-18 15:34:44 --> Final output sent to browser
DEBUG - 2017-02-18 15:34:44 --> Total execution time: 0.1141
