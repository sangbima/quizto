<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-19 18:57:12 --> Config Class Initialized
INFO - 2017-02-19 18:57:12 --> Hooks Class Initialized
DEBUG - 2017-02-19 18:57:12 --> UTF-8 Support Enabled
INFO - 2017-02-19 18:57:12 --> Utf8 Class Initialized
INFO - 2017-02-19 18:57:12 --> URI Class Initialized
INFO - 2017-02-19 18:57:12 --> Router Class Initialized
INFO - 2017-02-19 18:57:12 --> Output Class Initialized
INFO - 2017-02-19 18:57:12 --> Security Class Initialized
DEBUG - 2017-02-19 18:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 18:57:12 --> Input Class Initialized
INFO - 2017-02-19 18:57:12 --> Language Class Initialized
INFO - 2017-02-19 18:57:12 --> Loader Class Initialized
INFO - 2017-02-19 18:57:12 --> Helper loaded: url_helper
INFO - 2017-02-19 18:57:12 --> Helper loaded: language_helper
INFO - 2017-02-19 18:57:12 --> Helper loaded: html_helper
INFO - 2017-02-19 18:57:12 --> Helper loaded: form_helper
INFO - 2017-02-19 18:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 18:57:12 --> Controller Class Initialized
INFO - 2017-02-19 18:57:12 --> Database Driver Class Initialized
INFO - 2017-02-19 18:57:12 --> Model Class Initialized
INFO - 2017-02-19 18:57:12 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-19 18:57:12 --> Severity: Notice --> Undefined variable: numbers C:\wamp64\www\savsoftquiz\application\controllers\Register.php 83
ERROR - 2017-02-19 18:57:12 --> Severity: Warning --> array_slice() expects parameter 1 to be array, null given C:\wamp64\www\savsoftquiz\application\controllers\Register.php 83
INFO - 2017-02-19 18:57:12 --> Final output sent to browser
DEBUG - 2017-02-19 18:57:12 --> Total execution time: 0.1211
INFO - 2017-02-19 18:57:35 --> Config Class Initialized
INFO - 2017-02-19 18:57:35 --> Hooks Class Initialized
DEBUG - 2017-02-19 18:57:35 --> UTF-8 Support Enabled
INFO - 2017-02-19 18:57:35 --> Utf8 Class Initialized
INFO - 2017-02-19 18:57:35 --> URI Class Initialized
INFO - 2017-02-19 18:57:35 --> Router Class Initialized
INFO - 2017-02-19 18:57:35 --> Output Class Initialized
INFO - 2017-02-19 18:57:35 --> Security Class Initialized
DEBUG - 2017-02-19 18:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 18:57:35 --> Input Class Initialized
INFO - 2017-02-19 18:57:35 --> Language Class Initialized
INFO - 2017-02-19 18:57:35 --> Loader Class Initialized
INFO - 2017-02-19 18:57:35 --> Helper loaded: url_helper
INFO - 2017-02-19 18:57:35 --> Helper loaded: language_helper
INFO - 2017-02-19 18:57:35 --> Helper loaded: html_helper
INFO - 2017-02-19 18:57:35 --> Helper loaded: form_helper
INFO - 2017-02-19 18:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 18:57:35 --> Controller Class Initialized
INFO - 2017-02-19 18:57:35 --> Database Driver Class Initialized
INFO - 2017-02-19 18:57:35 --> Model Class Initialized
INFO - 2017-02-19 18:57:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-19 18:57:35 --> Severity: Warning --> array_slice() expects parameter 1 to be array, boolean given C:\wamp64\www\savsoftquiz\application\controllers\Register.php 83
INFO - 2017-02-19 18:57:35 --> Final output sent to browser
DEBUG - 2017-02-19 18:57:35 --> Total execution time: 0.0726
INFO - 2017-02-19 18:58:15 --> Config Class Initialized
INFO - 2017-02-19 18:58:15 --> Hooks Class Initialized
DEBUG - 2017-02-19 18:58:15 --> UTF-8 Support Enabled
INFO - 2017-02-19 18:58:15 --> Utf8 Class Initialized
INFO - 2017-02-19 18:58:15 --> URI Class Initialized
INFO - 2017-02-19 18:58:15 --> Router Class Initialized
INFO - 2017-02-19 18:58:15 --> Output Class Initialized
INFO - 2017-02-19 18:58:15 --> Security Class Initialized
DEBUG - 2017-02-19 18:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 18:58:15 --> Input Class Initialized
INFO - 2017-02-19 18:58:15 --> Language Class Initialized
INFO - 2017-02-19 18:58:15 --> Loader Class Initialized
INFO - 2017-02-19 18:58:15 --> Helper loaded: url_helper
INFO - 2017-02-19 18:58:15 --> Helper loaded: language_helper
INFO - 2017-02-19 18:58:15 --> Helper loaded: html_helper
INFO - 2017-02-19 18:58:15 --> Helper loaded: form_helper
INFO - 2017-02-19 18:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 18:58:15 --> Controller Class Initialized
INFO - 2017-02-19 18:58:15 --> Database Driver Class Initialized
INFO - 2017-02-19 18:58:15 --> Model Class Initialized
INFO - 2017-02-19 18:58:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 18:58:15 --> Final output sent to browser
DEBUG - 2017-02-19 18:58:15 --> Total execution time: 0.0705
INFO - 2017-02-19 19:19:18 --> Config Class Initialized
INFO - 2017-02-19 19:19:18 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:19:18 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:19:18 --> Utf8 Class Initialized
INFO - 2017-02-19 19:19:18 --> URI Class Initialized
INFO - 2017-02-19 19:19:18 --> Router Class Initialized
INFO - 2017-02-19 19:19:18 --> Output Class Initialized
INFO - 2017-02-19 19:19:18 --> Security Class Initialized
DEBUG - 2017-02-19 19:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:19:18 --> Input Class Initialized
INFO - 2017-02-19 19:19:18 --> Language Class Initialized
INFO - 2017-02-19 19:19:18 --> Loader Class Initialized
INFO - 2017-02-19 19:19:18 --> Helper loaded: url_helper
INFO - 2017-02-19 19:19:18 --> Helper loaded: language_helper
INFO - 2017-02-19 19:19:18 --> Helper loaded: html_helper
INFO - 2017-02-19 19:19:18 --> Helper loaded: form_helper
INFO - 2017-02-19 19:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:19:18 --> Controller Class Initialized
INFO - 2017-02-19 19:19:18 --> Database Driver Class Initialized
INFO - 2017-02-19 19:19:18 --> Model Class Initialized
INFO - 2017-02-19 19:19:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:19:18 --> Final output sent to browser
DEBUG - 2017-02-19 19:19:18 --> Total execution time: 0.0680
INFO - 2017-02-19 19:19:20 --> Config Class Initialized
INFO - 2017-02-19 19:19:20 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:19:20 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:19:20 --> Utf8 Class Initialized
INFO - 2017-02-19 19:19:20 --> URI Class Initialized
INFO - 2017-02-19 19:19:20 --> Router Class Initialized
INFO - 2017-02-19 19:19:20 --> Output Class Initialized
INFO - 2017-02-19 19:19:20 --> Security Class Initialized
DEBUG - 2017-02-19 19:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:19:20 --> Input Class Initialized
INFO - 2017-02-19 19:19:20 --> Language Class Initialized
INFO - 2017-02-19 19:19:20 --> Loader Class Initialized
INFO - 2017-02-19 19:19:20 --> Helper loaded: url_helper
INFO - 2017-02-19 19:19:20 --> Helper loaded: language_helper
INFO - 2017-02-19 19:19:20 --> Helper loaded: html_helper
INFO - 2017-02-19 19:19:20 --> Helper loaded: form_helper
INFO - 2017-02-19 19:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:19:20 --> Controller Class Initialized
INFO - 2017-02-19 19:19:20 --> Database Driver Class Initialized
INFO - 2017-02-19 19:19:20 --> Model Class Initialized
INFO - 2017-02-19 19:19:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:19:20 --> Final output sent to browser
DEBUG - 2017-02-19 19:19:20 --> Total execution time: 0.1067
INFO - 2017-02-19 19:19:21 --> Config Class Initialized
INFO - 2017-02-19 19:19:21 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:19:21 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:19:21 --> Utf8 Class Initialized
INFO - 2017-02-19 19:19:21 --> URI Class Initialized
INFO - 2017-02-19 19:19:21 --> Router Class Initialized
INFO - 2017-02-19 19:19:21 --> Output Class Initialized
INFO - 2017-02-19 19:19:21 --> Security Class Initialized
DEBUG - 2017-02-19 19:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:19:21 --> Input Class Initialized
INFO - 2017-02-19 19:19:21 --> Language Class Initialized
INFO - 2017-02-19 19:19:21 --> Loader Class Initialized
INFO - 2017-02-19 19:19:21 --> Helper loaded: url_helper
INFO - 2017-02-19 19:19:21 --> Helper loaded: language_helper
INFO - 2017-02-19 19:19:21 --> Helper loaded: html_helper
INFO - 2017-02-19 19:19:21 --> Helper loaded: form_helper
INFO - 2017-02-19 19:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:19:21 --> Controller Class Initialized
INFO - 2017-02-19 19:19:21 --> Database Driver Class Initialized
INFO - 2017-02-19 19:19:21 --> Model Class Initialized
INFO - 2017-02-19 19:19:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:19:21 --> Final output sent to browser
DEBUG - 2017-02-19 19:19:21 --> Total execution time: 0.0640
INFO - 2017-02-19 19:19:40 --> Config Class Initialized
INFO - 2017-02-19 19:19:40 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:19:40 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:19:40 --> Utf8 Class Initialized
INFO - 2017-02-19 19:19:40 --> URI Class Initialized
INFO - 2017-02-19 19:19:40 --> Router Class Initialized
INFO - 2017-02-19 19:19:40 --> Output Class Initialized
INFO - 2017-02-19 19:19:40 --> Security Class Initialized
DEBUG - 2017-02-19 19:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:19:40 --> Input Class Initialized
INFO - 2017-02-19 19:19:40 --> Language Class Initialized
INFO - 2017-02-19 19:19:40 --> Loader Class Initialized
INFO - 2017-02-19 19:19:40 --> Helper loaded: url_helper
INFO - 2017-02-19 19:19:40 --> Helper loaded: language_helper
INFO - 2017-02-19 19:19:40 --> Helper loaded: html_helper
INFO - 2017-02-19 19:19:40 --> Helper loaded: form_helper
INFO - 2017-02-19 19:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:19:40 --> Controller Class Initialized
INFO - 2017-02-19 19:19:40 --> Database Driver Class Initialized
INFO - 2017-02-19 19:19:40 --> Model Class Initialized
INFO - 2017-02-19 19:19:40 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-19 19:19:40 --> Severity: Runtime Notice --> mktime(): You should be using the time() function instead C:\wamp64\www\savsoftquiz\application\controllers\Register.php 85
INFO - 2017-02-19 19:19:40 --> Final output sent to browser
DEBUG - 2017-02-19 19:19:40 --> Total execution time: 0.0712
INFO - 2017-02-19 19:19:59 --> Config Class Initialized
INFO - 2017-02-19 19:19:59 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:19:59 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:19:59 --> Utf8 Class Initialized
INFO - 2017-02-19 19:19:59 --> URI Class Initialized
INFO - 2017-02-19 19:19:59 --> Router Class Initialized
INFO - 2017-02-19 19:19:59 --> Output Class Initialized
INFO - 2017-02-19 19:19:59 --> Security Class Initialized
DEBUG - 2017-02-19 19:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:19:59 --> Input Class Initialized
INFO - 2017-02-19 19:19:59 --> Language Class Initialized
INFO - 2017-02-19 19:19:59 --> Loader Class Initialized
INFO - 2017-02-19 19:19:59 --> Helper loaded: url_helper
INFO - 2017-02-19 19:19:59 --> Helper loaded: language_helper
INFO - 2017-02-19 19:19:59 --> Helper loaded: html_helper
INFO - 2017-02-19 19:19:59 --> Helper loaded: form_helper
INFO - 2017-02-19 19:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:19:59 --> Controller Class Initialized
INFO - 2017-02-19 19:19:59 --> Database Driver Class Initialized
INFO - 2017-02-19 19:19:59 --> Model Class Initialized
INFO - 2017-02-19 19:19:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:19:59 --> Final output sent to browser
DEBUG - 2017-02-19 19:19:59 --> Total execution time: 0.0698
INFO - 2017-02-19 19:20:01 --> Config Class Initialized
INFO - 2017-02-19 19:20:01 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:20:01 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:20:01 --> Utf8 Class Initialized
INFO - 2017-02-19 19:20:01 --> URI Class Initialized
INFO - 2017-02-19 19:20:01 --> Router Class Initialized
INFO - 2017-02-19 19:20:01 --> Output Class Initialized
INFO - 2017-02-19 19:20:01 --> Security Class Initialized
DEBUG - 2017-02-19 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:20:01 --> Input Class Initialized
INFO - 2017-02-19 19:20:01 --> Language Class Initialized
INFO - 2017-02-19 19:20:01 --> Loader Class Initialized
INFO - 2017-02-19 19:20:01 --> Helper loaded: url_helper
INFO - 2017-02-19 19:20:01 --> Helper loaded: language_helper
INFO - 2017-02-19 19:20:01 --> Helper loaded: html_helper
INFO - 2017-02-19 19:20:01 --> Helper loaded: form_helper
INFO - 2017-02-19 19:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:20:01 --> Controller Class Initialized
INFO - 2017-02-19 19:20:01 --> Database Driver Class Initialized
INFO - 2017-02-19 19:20:01 --> Model Class Initialized
INFO - 2017-02-19 19:20:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:20:01 --> Final output sent to browser
DEBUG - 2017-02-19 19:20:01 --> Total execution time: 0.0747
INFO - 2017-02-19 19:20:01 --> Config Class Initialized
INFO - 2017-02-19 19:20:01 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:20:01 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:20:01 --> Utf8 Class Initialized
INFO - 2017-02-19 19:20:01 --> URI Class Initialized
INFO - 2017-02-19 19:20:01 --> Router Class Initialized
INFO - 2017-02-19 19:20:01 --> Output Class Initialized
INFO - 2017-02-19 19:20:01 --> Security Class Initialized
DEBUG - 2017-02-19 19:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:20:01 --> Input Class Initialized
INFO - 2017-02-19 19:20:01 --> Language Class Initialized
INFO - 2017-02-19 19:20:01 --> Loader Class Initialized
INFO - 2017-02-19 19:20:01 --> Helper loaded: url_helper
INFO - 2017-02-19 19:20:01 --> Helper loaded: language_helper
INFO - 2017-02-19 19:20:01 --> Helper loaded: html_helper
INFO - 2017-02-19 19:20:01 --> Helper loaded: form_helper
INFO - 2017-02-19 19:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:20:01 --> Controller Class Initialized
INFO - 2017-02-19 19:20:01 --> Database Driver Class Initialized
INFO - 2017-02-19 19:20:01 --> Model Class Initialized
INFO - 2017-02-19 19:20:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:20:01 --> Final output sent to browser
DEBUG - 2017-02-19 19:20:01 --> Total execution time: 0.0651
INFO - 2017-02-19 19:20:03 --> Config Class Initialized
INFO - 2017-02-19 19:20:03 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:20:03 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:20:03 --> Utf8 Class Initialized
INFO - 2017-02-19 19:20:03 --> URI Class Initialized
INFO - 2017-02-19 19:20:03 --> Router Class Initialized
INFO - 2017-02-19 19:20:03 --> Output Class Initialized
INFO - 2017-02-19 19:20:03 --> Security Class Initialized
DEBUG - 2017-02-19 19:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:20:03 --> Input Class Initialized
INFO - 2017-02-19 19:20:03 --> Language Class Initialized
INFO - 2017-02-19 19:20:03 --> Loader Class Initialized
INFO - 2017-02-19 19:20:03 --> Helper loaded: url_helper
INFO - 2017-02-19 19:20:03 --> Helper loaded: language_helper
INFO - 2017-02-19 19:20:03 --> Helper loaded: html_helper
INFO - 2017-02-19 19:20:03 --> Helper loaded: form_helper
INFO - 2017-02-19 19:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:20:03 --> Controller Class Initialized
INFO - 2017-02-19 19:20:03 --> Database Driver Class Initialized
INFO - 2017-02-19 19:20:03 --> Model Class Initialized
INFO - 2017-02-19 19:20:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:20:03 --> Final output sent to browser
DEBUG - 2017-02-19 19:20:03 --> Total execution time: 0.0757
INFO - 2017-02-19 19:20:03 --> Config Class Initialized
INFO - 2017-02-19 19:20:03 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:20:03 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:20:03 --> Utf8 Class Initialized
INFO - 2017-02-19 19:20:03 --> URI Class Initialized
INFO - 2017-02-19 19:20:03 --> Router Class Initialized
INFO - 2017-02-19 19:20:03 --> Output Class Initialized
INFO - 2017-02-19 19:20:03 --> Security Class Initialized
DEBUG - 2017-02-19 19:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:20:03 --> Input Class Initialized
INFO - 2017-02-19 19:20:03 --> Language Class Initialized
INFO - 2017-02-19 19:20:03 --> Loader Class Initialized
INFO - 2017-02-19 19:20:03 --> Helper loaded: url_helper
INFO - 2017-02-19 19:20:03 --> Helper loaded: language_helper
INFO - 2017-02-19 19:20:03 --> Helper loaded: html_helper
INFO - 2017-02-19 19:20:03 --> Helper loaded: form_helper
INFO - 2017-02-19 19:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:20:03 --> Controller Class Initialized
INFO - 2017-02-19 19:20:03 --> Database Driver Class Initialized
INFO - 2017-02-19 19:20:03 --> Model Class Initialized
INFO - 2017-02-19 19:20:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:20:04 --> Final output sent to browser
DEBUG - 2017-02-19 19:20:04 --> Total execution time: 0.0751
INFO - 2017-02-19 19:20:04 --> Config Class Initialized
INFO - 2017-02-19 19:20:04 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:20:04 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:20:04 --> Utf8 Class Initialized
INFO - 2017-02-19 19:20:04 --> URI Class Initialized
INFO - 2017-02-19 19:20:04 --> Router Class Initialized
INFO - 2017-02-19 19:20:04 --> Output Class Initialized
INFO - 2017-02-19 19:20:04 --> Security Class Initialized
DEBUG - 2017-02-19 19:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:20:04 --> Input Class Initialized
INFO - 2017-02-19 19:20:04 --> Language Class Initialized
INFO - 2017-02-19 19:20:04 --> Loader Class Initialized
INFO - 2017-02-19 19:20:04 --> Helper loaded: url_helper
INFO - 2017-02-19 19:20:04 --> Helper loaded: language_helper
INFO - 2017-02-19 19:20:04 --> Helper loaded: html_helper
INFO - 2017-02-19 19:20:04 --> Helper loaded: form_helper
INFO - 2017-02-19 19:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:20:04 --> Controller Class Initialized
INFO - 2017-02-19 19:20:04 --> Database Driver Class Initialized
INFO - 2017-02-19 19:20:04 --> Model Class Initialized
INFO - 2017-02-19 19:20:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:20:04 --> Final output sent to browser
DEBUG - 2017-02-19 19:20:04 --> Total execution time: 0.0782
INFO - 2017-02-19 19:20:05 --> Config Class Initialized
INFO - 2017-02-19 19:20:05 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:20:05 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:20:05 --> Utf8 Class Initialized
INFO - 2017-02-19 19:20:05 --> URI Class Initialized
INFO - 2017-02-19 19:20:05 --> Router Class Initialized
INFO - 2017-02-19 19:20:05 --> Output Class Initialized
INFO - 2017-02-19 19:20:05 --> Security Class Initialized
DEBUG - 2017-02-19 19:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:20:05 --> Input Class Initialized
INFO - 2017-02-19 19:20:05 --> Language Class Initialized
INFO - 2017-02-19 19:20:05 --> Loader Class Initialized
INFO - 2017-02-19 19:20:05 --> Helper loaded: url_helper
INFO - 2017-02-19 19:20:05 --> Helper loaded: language_helper
INFO - 2017-02-19 19:20:05 --> Helper loaded: html_helper
INFO - 2017-02-19 19:20:05 --> Helper loaded: form_helper
INFO - 2017-02-19 19:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:20:05 --> Controller Class Initialized
INFO - 2017-02-19 19:20:05 --> Database Driver Class Initialized
INFO - 2017-02-19 19:20:05 --> Model Class Initialized
INFO - 2017-02-19 19:20:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:20:05 --> Final output sent to browser
DEBUG - 2017-02-19 19:20:05 --> Total execution time: 0.0639
INFO - 2017-02-19 19:20:06 --> Config Class Initialized
INFO - 2017-02-19 19:20:06 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:20:06 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:20:06 --> Utf8 Class Initialized
INFO - 2017-02-19 19:20:06 --> URI Class Initialized
INFO - 2017-02-19 19:20:06 --> Router Class Initialized
INFO - 2017-02-19 19:20:06 --> Output Class Initialized
INFO - 2017-02-19 19:20:06 --> Security Class Initialized
DEBUG - 2017-02-19 19:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:20:06 --> Input Class Initialized
INFO - 2017-02-19 19:20:06 --> Language Class Initialized
INFO - 2017-02-19 19:20:06 --> Loader Class Initialized
INFO - 2017-02-19 19:20:06 --> Helper loaded: url_helper
INFO - 2017-02-19 19:20:06 --> Helper loaded: language_helper
INFO - 2017-02-19 19:20:06 --> Helper loaded: html_helper
INFO - 2017-02-19 19:20:06 --> Helper loaded: form_helper
INFO - 2017-02-19 19:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:20:06 --> Controller Class Initialized
INFO - 2017-02-19 19:20:06 --> Database Driver Class Initialized
INFO - 2017-02-19 19:20:06 --> Model Class Initialized
INFO - 2017-02-19 19:20:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:20:06 --> Final output sent to browser
DEBUG - 2017-02-19 19:20:06 --> Total execution time: 0.1057
INFO - 2017-02-19 19:20:06 --> Config Class Initialized
INFO - 2017-02-19 19:20:06 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:20:06 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:20:06 --> Utf8 Class Initialized
INFO - 2017-02-19 19:20:06 --> URI Class Initialized
INFO - 2017-02-19 19:20:06 --> Router Class Initialized
INFO - 2017-02-19 19:20:06 --> Output Class Initialized
INFO - 2017-02-19 19:20:06 --> Security Class Initialized
DEBUG - 2017-02-19 19:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:20:06 --> Input Class Initialized
INFO - 2017-02-19 19:20:06 --> Language Class Initialized
INFO - 2017-02-19 19:20:06 --> Loader Class Initialized
INFO - 2017-02-19 19:20:06 --> Helper loaded: url_helper
INFO - 2017-02-19 19:20:06 --> Helper loaded: language_helper
INFO - 2017-02-19 19:20:06 --> Helper loaded: html_helper
INFO - 2017-02-19 19:20:06 --> Helper loaded: form_helper
INFO - 2017-02-19 19:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:20:06 --> Controller Class Initialized
INFO - 2017-02-19 19:20:06 --> Database Driver Class Initialized
INFO - 2017-02-19 19:20:06 --> Model Class Initialized
INFO - 2017-02-19 19:20:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-19 19:20:06 --> Final output sent to browser
DEBUG - 2017-02-19 19:20:06 --> Total execution time: 0.0728
INFO - 2017-02-19 19:35:13 --> Config Class Initialized
INFO - 2017-02-19 19:35:13 --> Hooks Class Initialized
DEBUG - 2017-02-19 19:35:13 --> UTF-8 Support Enabled
INFO - 2017-02-19 19:35:13 --> Utf8 Class Initialized
INFO - 2017-02-19 19:35:13 --> URI Class Initialized
INFO - 2017-02-19 19:35:13 --> Router Class Initialized
INFO - 2017-02-19 19:35:13 --> Output Class Initialized
INFO - 2017-02-19 19:35:13 --> Security Class Initialized
DEBUG - 2017-02-19 19:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-19 19:35:13 --> Input Class Initialized
INFO - 2017-02-19 19:35:13 --> Language Class Initialized
INFO - 2017-02-19 19:35:13 --> Loader Class Initialized
INFO - 2017-02-19 19:35:13 --> Helper loaded: url_helper
INFO - 2017-02-19 19:35:13 --> Helper loaded: language_helper
INFO - 2017-02-19 19:35:13 --> Helper loaded: html_helper
INFO - 2017-02-19 19:35:13 --> Helper loaded: form_helper
INFO - 2017-02-19 19:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-19 19:35:13 --> Controller Class Initialized
INFO - 2017-02-19 19:35:13 --> Database Driver Class Initialized
INFO - 2017-02-19 19:35:13 --> Model Class Initialized
INFO - 2017-02-19 19:35:13 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-19 19:35:13 --> Severity: Notice --> Use of undefined constant about - assumed 'about' C:\wamp64\www\savsoftquiz\application\controllers\Register.php 82
ERROR - 2017-02-19 19:35:13 --> Severity: Notice --> Use of undefined constant about - assumed 'about' C:\wamp64\www\savsoftquiz\application\controllers\Register.php 87
INFO - 2017-02-19 19:35:13 --> Final output sent to browser
DEBUG - 2017-02-19 19:35:13 --> Total execution time: 0.0723
