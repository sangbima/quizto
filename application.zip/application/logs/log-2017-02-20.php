<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-20 11:43:28 --> Config Class Initialized
INFO - 2017-02-20 11:43:28 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:43:28 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:43:28 --> Utf8 Class Initialized
INFO - 2017-02-20 11:43:28 --> URI Class Initialized
INFO - 2017-02-20 11:43:28 --> Router Class Initialized
INFO - 2017-02-20 11:43:28 --> Output Class Initialized
INFO - 2017-02-20 11:43:28 --> Security Class Initialized
DEBUG - 2017-02-20 11:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:43:28 --> Input Class Initialized
INFO - 2017-02-20 11:43:28 --> Language Class Initialized
INFO - 2017-02-20 11:43:28 --> Loader Class Initialized
INFO - 2017-02-20 11:43:28 --> Helper loaded: url_helper
INFO - 2017-02-20 11:43:28 --> Helper loaded: language_helper
INFO - 2017-02-20 11:43:28 --> Helper loaded: html_helper
INFO - 2017-02-20 11:43:28 --> Helper loaded: form_helper
INFO - 2017-02-20 11:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:43:28 --> Controller Class Initialized
INFO - 2017-02-20 11:43:28 --> Database Driver Class Initialized
INFO - 2017-02-20 11:43:28 --> Model Class Initialized
INFO - 2017-02-20 11:43:28 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 11:43:28 --> Severity: Notice --> Undefined variable: lastId C:\wamp64\www\savsoftquiz\application\models\Register_model.php 46
INFO - 2017-02-20 11:43:28 --> Final output sent to browser
DEBUG - 2017-02-20 11:43:28 --> Total execution time: 0.1331
INFO - 2017-02-20 11:47:56 --> Config Class Initialized
INFO - 2017-02-20 11:47:56 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:47:56 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:47:56 --> Utf8 Class Initialized
INFO - 2017-02-20 11:47:56 --> URI Class Initialized
INFO - 2017-02-20 11:47:56 --> Router Class Initialized
INFO - 2017-02-20 11:47:56 --> Output Class Initialized
INFO - 2017-02-20 11:47:56 --> Security Class Initialized
DEBUG - 2017-02-20 11:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:47:56 --> Input Class Initialized
INFO - 2017-02-20 11:47:56 --> Language Class Initialized
INFO - 2017-02-20 11:47:56 --> Loader Class Initialized
INFO - 2017-02-20 11:47:56 --> Helper loaded: url_helper
INFO - 2017-02-20 11:47:56 --> Helper loaded: language_helper
INFO - 2017-02-20 11:47:56 --> Helper loaded: html_helper
INFO - 2017-02-20 11:47:56 --> Helper loaded: form_helper
INFO - 2017-02-20 11:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:47:56 --> Controller Class Initialized
INFO - 2017-02-20 11:47:56 --> Database Driver Class Initialized
INFO - 2017-02-20 11:47:56 --> Model Class Initialized
INFO - 2017-02-20 11:47:56 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 11:47:56 --> Query error: Table 'quizto.register_no' doesn't exist - Invalid query: SELECT *
FROM `register_no`
WHERE `id` =0
INFO - 2017-02-20 11:47:56 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-02-20 11:48:16 --> Config Class Initialized
INFO - 2017-02-20 11:48:16 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:48:16 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:48:16 --> Utf8 Class Initialized
INFO - 2017-02-20 11:48:16 --> URI Class Initialized
INFO - 2017-02-20 11:48:16 --> Router Class Initialized
INFO - 2017-02-20 11:48:16 --> Output Class Initialized
INFO - 2017-02-20 11:48:16 --> Security Class Initialized
DEBUG - 2017-02-20 11:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:48:16 --> Input Class Initialized
INFO - 2017-02-20 11:48:16 --> Language Class Initialized
INFO - 2017-02-20 11:48:16 --> Loader Class Initialized
INFO - 2017-02-20 11:48:16 --> Helper loaded: url_helper
INFO - 2017-02-20 11:48:16 --> Helper loaded: language_helper
INFO - 2017-02-20 11:48:16 --> Helper loaded: html_helper
INFO - 2017-02-20 11:48:16 --> Helper loaded: form_helper
INFO - 2017-02-20 11:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:48:16 --> Controller Class Initialized
INFO - 2017-02-20 11:48:16 --> Database Driver Class Initialized
INFO - 2017-02-20 11:48:16 --> Model Class Initialized
INFO - 2017-02-20 11:48:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 11:48:16 --> Final output sent to browser
DEBUG - 2017-02-20 11:48:16 --> Total execution time: 0.1715
INFO - 2017-02-20 11:48:28 --> Config Class Initialized
INFO - 2017-02-20 11:48:28 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:48:28 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:48:28 --> Utf8 Class Initialized
INFO - 2017-02-20 11:48:28 --> URI Class Initialized
INFO - 2017-02-20 11:48:28 --> Router Class Initialized
INFO - 2017-02-20 11:48:28 --> Output Class Initialized
INFO - 2017-02-20 11:48:28 --> Security Class Initialized
DEBUG - 2017-02-20 11:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:48:28 --> Input Class Initialized
INFO - 2017-02-20 11:48:28 --> Language Class Initialized
INFO - 2017-02-20 11:48:28 --> Loader Class Initialized
INFO - 2017-02-20 11:48:28 --> Helper loaded: url_helper
INFO - 2017-02-20 11:48:28 --> Helper loaded: language_helper
INFO - 2017-02-20 11:48:28 --> Helper loaded: html_helper
INFO - 2017-02-20 11:48:28 --> Helper loaded: form_helper
INFO - 2017-02-20 11:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:48:28 --> Controller Class Initialized
INFO - 2017-02-20 11:48:28 --> Database Driver Class Initialized
INFO - 2017-02-20 11:48:28 --> Model Class Initialized
INFO - 2017-02-20 11:48:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 11:48:28 --> Final output sent to browser
DEBUG - 2017-02-20 11:48:28 --> Total execution time: 0.1426
INFO - 2017-02-20 11:48:42 --> Config Class Initialized
INFO - 2017-02-20 11:48:42 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:48:42 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:48:42 --> Utf8 Class Initialized
INFO - 2017-02-20 11:48:42 --> URI Class Initialized
INFO - 2017-02-20 11:48:42 --> Router Class Initialized
INFO - 2017-02-20 11:48:42 --> Output Class Initialized
INFO - 2017-02-20 11:48:42 --> Security Class Initialized
DEBUG - 2017-02-20 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:48:42 --> Input Class Initialized
INFO - 2017-02-20 11:48:42 --> Language Class Initialized
INFO - 2017-02-20 11:48:42 --> Loader Class Initialized
INFO - 2017-02-20 11:48:42 --> Helper loaded: url_helper
INFO - 2017-02-20 11:48:42 --> Helper loaded: language_helper
INFO - 2017-02-20 11:48:42 --> Helper loaded: html_helper
INFO - 2017-02-20 11:48:42 --> Helper loaded: form_helper
INFO - 2017-02-20 11:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:48:42 --> Controller Class Initialized
INFO - 2017-02-20 11:48:42 --> Database Driver Class Initialized
INFO - 2017-02-20 11:48:42 --> Model Class Initialized
INFO - 2017-02-20 11:48:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 11:48:42 --> Final output sent to browser
DEBUG - 2017-02-20 11:48:42 --> Total execution time: 0.1031
INFO - 2017-02-20 11:48:56 --> Config Class Initialized
INFO - 2017-02-20 11:48:56 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:48:56 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:48:56 --> Utf8 Class Initialized
INFO - 2017-02-20 11:48:56 --> URI Class Initialized
INFO - 2017-02-20 11:48:56 --> Router Class Initialized
INFO - 2017-02-20 11:48:56 --> Output Class Initialized
INFO - 2017-02-20 11:48:56 --> Security Class Initialized
DEBUG - 2017-02-20 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:48:56 --> Input Class Initialized
INFO - 2017-02-20 11:48:56 --> Language Class Initialized
INFO - 2017-02-20 11:48:56 --> Loader Class Initialized
INFO - 2017-02-20 11:48:56 --> Helper loaded: url_helper
INFO - 2017-02-20 11:48:56 --> Helper loaded: language_helper
INFO - 2017-02-20 11:48:56 --> Helper loaded: html_helper
INFO - 2017-02-20 11:48:56 --> Helper loaded: form_helper
INFO - 2017-02-20 11:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:48:56 --> Controller Class Initialized
INFO - 2017-02-20 11:48:56 --> Database Driver Class Initialized
INFO - 2017-02-20 11:48:56 --> Model Class Initialized
INFO - 2017-02-20 11:48:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 11:48:56 --> Final output sent to browser
DEBUG - 2017-02-20 11:48:56 --> Total execution time: 0.1481
INFO - 2017-02-20 11:49:21 --> Config Class Initialized
INFO - 2017-02-20 11:49:21 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:49:21 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:49:21 --> Utf8 Class Initialized
INFO - 2017-02-20 11:49:21 --> URI Class Initialized
INFO - 2017-02-20 11:49:21 --> Router Class Initialized
INFO - 2017-02-20 11:49:21 --> Output Class Initialized
INFO - 2017-02-20 11:49:21 --> Security Class Initialized
DEBUG - 2017-02-20 11:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:49:21 --> Input Class Initialized
INFO - 2017-02-20 11:49:21 --> Language Class Initialized
INFO - 2017-02-20 11:49:21 --> Loader Class Initialized
INFO - 2017-02-20 11:49:21 --> Helper loaded: url_helper
INFO - 2017-02-20 11:49:21 --> Helper loaded: language_helper
INFO - 2017-02-20 11:49:21 --> Helper loaded: html_helper
INFO - 2017-02-20 11:49:21 --> Helper loaded: form_helper
INFO - 2017-02-20 11:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:49:21 --> Controller Class Initialized
INFO - 2017-02-20 11:49:21 --> Database Driver Class Initialized
INFO - 2017-02-20 11:49:21 --> Model Class Initialized
INFO - 2017-02-20 11:49:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 11:49:21 --> Final output sent to browser
DEBUG - 2017-02-20 11:49:21 --> Total execution time: 0.1048
INFO - 2017-02-20 11:49:31 --> Config Class Initialized
INFO - 2017-02-20 11:49:31 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:49:31 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:49:31 --> Utf8 Class Initialized
INFO - 2017-02-20 11:49:31 --> URI Class Initialized
INFO - 2017-02-20 11:49:31 --> Router Class Initialized
INFO - 2017-02-20 11:49:31 --> Output Class Initialized
INFO - 2017-02-20 11:49:31 --> Security Class Initialized
DEBUG - 2017-02-20 11:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:49:31 --> Input Class Initialized
INFO - 2017-02-20 11:49:31 --> Language Class Initialized
INFO - 2017-02-20 11:49:31 --> Loader Class Initialized
INFO - 2017-02-20 11:49:31 --> Helper loaded: url_helper
INFO - 2017-02-20 11:49:31 --> Helper loaded: language_helper
INFO - 2017-02-20 11:49:31 --> Helper loaded: html_helper
INFO - 2017-02-20 11:49:31 --> Helper loaded: form_helper
INFO - 2017-02-20 11:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:49:31 --> Controller Class Initialized
INFO - 2017-02-20 11:49:31 --> Database Driver Class Initialized
INFO - 2017-02-20 11:49:31 --> Model Class Initialized
INFO - 2017-02-20 11:49:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 11:49:31 --> Final output sent to browser
DEBUG - 2017-02-20 11:49:31 --> Total execution time: 0.1404
INFO - 2017-02-20 11:50:45 --> Config Class Initialized
INFO - 2017-02-20 11:50:45 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:50:45 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:50:45 --> Utf8 Class Initialized
INFO - 2017-02-20 11:50:45 --> URI Class Initialized
INFO - 2017-02-20 11:50:45 --> Router Class Initialized
INFO - 2017-02-20 11:50:45 --> Output Class Initialized
INFO - 2017-02-20 11:50:45 --> Security Class Initialized
DEBUG - 2017-02-20 11:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:50:45 --> Input Class Initialized
INFO - 2017-02-20 11:50:45 --> Language Class Initialized
INFO - 2017-02-20 11:50:45 --> Loader Class Initialized
INFO - 2017-02-20 11:50:45 --> Helper loaded: url_helper
INFO - 2017-02-20 11:50:45 --> Helper loaded: language_helper
INFO - 2017-02-20 11:50:45 --> Helper loaded: html_helper
INFO - 2017-02-20 11:50:45 --> Helper loaded: form_helper
INFO - 2017-02-20 11:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:50:45 --> Controller Class Initialized
INFO - 2017-02-20 11:50:45 --> Database Driver Class Initialized
INFO - 2017-02-20 11:50:45 --> Model Class Initialized
INFO - 2017-02-20 11:50:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 11:50:45 --> Final output sent to browser
DEBUG - 2017-02-20 11:50:45 --> Total execution time: 0.1345
INFO - 2017-02-20 11:54:07 --> Config Class Initialized
INFO - 2017-02-20 11:54:07 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:54:07 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:54:07 --> Utf8 Class Initialized
INFO - 2017-02-20 11:54:07 --> URI Class Initialized
INFO - 2017-02-20 11:54:07 --> Router Class Initialized
INFO - 2017-02-20 11:54:07 --> Output Class Initialized
INFO - 2017-02-20 11:54:07 --> Security Class Initialized
DEBUG - 2017-02-20 11:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:54:07 --> Input Class Initialized
INFO - 2017-02-20 11:54:07 --> Language Class Initialized
INFO - 2017-02-20 11:54:07 --> Loader Class Initialized
INFO - 2017-02-20 11:54:07 --> Helper loaded: url_helper
INFO - 2017-02-20 11:54:07 --> Helper loaded: language_helper
INFO - 2017-02-20 11:54:07 --> Helper loaded: html_helper
INFO - 2017-02-20 11:54:07 --> Helper loaded: form_helper
INFO - 2017-02-20 11:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:54:07 --> Controller Class Initialized
INFO - 2017-02-20 11:54:07 --> Database Driver Class Initialized
INFO - 2017-02-20 11:54:07 --> Model Class Initialized
INFO - 2017-02-20 11:54:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 11:54:07 --> Final output sent to browser
DEBUG - 2017-02-20 11:54:07 --> Total execution time: 0.1163
INFO - 2017-02-20 11:57:07 --> Config Class Initialized
INFO - 2017-02-20 11:57:07 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:57:07 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:57:07 --> Utf8 Class Initialized
INFO - 2017-02-20 11:57:07 --> URI Class Initialized
INFO - 2017-02-20 11:57:07 --> Router Class Initialized
INFO - 2017-02-20 11:57:07 --> Output Class Initialized
INFO - 2017-02-20 11:57:07 --> Security Class Initialized
DEBUG - 2017-02-20 11:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:57:07 --> Input Class Initialized
INFO - 2017-02-20 11:57:07 --> Language Class Initialized
INFO - 2017-02-20 11:57:07 --> Loader Class Initialized
INFO - 2017-02-20 11:57:07 --> Helper loaded: url_helper
INFO - 2017-02-20 11:57:07 --> Helper loaded: language_helper
INFO - 2017-02-20 11:57:07 --> Helper loaded: html_helper
INFO - 2017-02-20 11:57:07 --> Helper loaded: form_helper
INFO - 2017-02-20 11:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:57:07 --> Controller Class Initialized
INFO - 2017-02-20 11:57:07 --> Database Driver Class Initialized
INFO - 2017-02-20 11:57:07 --> Model Class Initialized
INFO - 2017-02-20 11:57:07 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 11:57:07 --> Severity: Notice --> Undefined variable: lastId C:\wamp64\www\savsoftquiz\application\models\Register_model.php 53
INFO - 2017-02-20 11:57:07 --> Final output sent to browser
DEBUG - 2017-02-20 11:57:07 --> Total execution time: 0.1222
INFO - 2017-02-20 11:58:19 --> Config Class Initialized
INFO - 2017-02-20 11:58:19 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:58:19 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:58:19 --> Utf8 Class Initialized
INFO - 2017-02-20 11:58:19 --> URI Class Initialized
INFO - 2017-02-20 11:58:19 --> Router Class Initialized
INFO - 2017-02-20 11:58:19 --> Output Class Initialized
INFO - 2017-02-20 11:58:19 --> Security Class Initialized
DEBUG - 2017-02-20 11:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:58:19 --> Input Class Initialized
INFO - 2017-02-20 11:58:19 --> Language Class Initialized
INFO - 2017-02-20 11:58:19 --> Loader Class Initialized
INFO - 2017-02-20 11:58:19 --> Helper loaded: url_helper
INFO - 2017-02-20 11:58:19 --> Helper loaded: language_helper
INFO - 2017-02-20 11:58:19 --> Helper loaded: html_helper
INFO - 2017-02-20 11:58:19 --> Helper loaded: form_helper
INFO - 2017-02-20 11:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:58:19 --> Controller Class Initialized
INFO - 2017-02-20 11:58:19 --> Database Driver Class Initialized
INFO - 2017-02-20 11:58:19 --> Model Class Initialized
INFO - 2017-02-20 11:58:19 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 11:58:19 --> Severity: Notice --> Undefined variable: lastId C:\wamp64\www\savsoftquiz\application\models\Register_model.php 53
INFO - 2017-02-20 11:58:19 --> Final output sent to browser
DEBUG - 2017-02-20 11:58:19 --> Total execution time: 0.1023
INFO - 2017-02-20 11:59:38 --> Config Class Initialized
INFO - 2017-02-20 11:59:38 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:59:38 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:59:38 --> Utf8 Class Initialized
INFO - 2017-02-20 11:59:38 --> URI Class Initialized
INFO - 2017-02-20 11:59:38 --> Router Class Initialized
INFO - 2017-02-20 11:59:38 --> Output Class Initialized
INFO - 2017-02-20 11:59:38 --> Security Class Initialized
DEBUG - 2017-02-20 11:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:59:38 --> Input Class Initialized
INFO - 2017-02-20 11:59:38 --> Language Class Initialized
INFO - 2017-02-20 11:59:38 --> Loader Class Initialized
INFO - 2017-02-20 11:59:38 --> Helper loaded: url_helper
INFO - 2017-02-20 11:59:38 --> Helper loaded: language_helper
INFO - 2017-02-20 11:59:38 --> Helper loaded: html_helper
INFO - 2017-02-20 11:59:38 --> Helper loaded: form_helper
INFO - 2017-02-20 11:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:59:38 --> Controller Class Initialized
INFO - 2017-02-20 11:59:38 --> Database Driver Class Initialized
INFO - 2017-02-20 11:59:38 --> Model Class Initialized
INFO - 2017-02-20 11:59:38 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 11:59:38 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\system\database\DB_query_builder.php 669
ERROR - 2017-02-20 11:59:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `register`
WHERE `id` = `Array`
INFO - 2017-02-20 11:59:38 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-02-20 11:59:53 --> Config Class Initialized
INFO - 2017-02-20 11:59:53 --> Hooks Class Initialized
DEBUG - 2017-02-20 11:59:53 --> UTF-8 Support Enabled
INFO - 2017-02-20 11:59:53 --> Utf8 Class Initialized
INFO - 2017-02-20 11:59:53 --> URI Class Initialized
INFO - 2017-02-20 11:59:53 --> Router Class Initialized
INFO - 2017-02-20 11:59:53 --> Output Class Initialized
INFO - 2017-02-20 11:59:53 --> Security Class Initialized
DEBUG - 2017-02-20 11:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 11:59:53 --> Input Class Initialized
INFO - 2017-02-20 11:59:53 --> Language Class Initialized
INFO - 2017-02-20 11:59:53 --> Loader Class Initialized
INFO - 2017-02-20 11:59:53 --> Helper loaded: url_helper
INFO - 2017-02-20 11:59:53 --> Helper loaded: language_helper
INFO - 2017-02-20 11:59:53 --> Helper loaded: html_helper
INFO - 2017-02-20 11:59:53 --> Helper loaded: form_helper
INFO - 2017-02-20 11:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 11:59:53 --> Controller Class Initialized
INFO - 2017-02-20 11:59:53 --> Database Driver Class Initialized
INFO - 2017-02-20 11:59:53 --> Model Class Initialized
INFO - 2017-02-20 11:59:53 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 11:59:53 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\system\database\DB_query_builder.php 669
ERROR - 2017-02-20 11:59:53 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `register`
WHERE `id` = `Array`
INFO - 2017-02-20 11:59:53 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-02-20 12:00:05 --> Config Class Initialized
INFO - 2017-02-20 12:00:05 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:00:05 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:00:05 --> Utf8 Class Initialized
INFO - 2017-02-20 12:00:05 --> URI Class Initialized
INFO - 2017-02-20 12:00:05 --> Router Class Initialized
INFO - 2017-02-20 12:00:05 --> Output Class Initialized
INFO - 2017-02-20 12:00:05 --> Security Class Initialized
DEBUG - 2017-02-20 12:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:00:05 --> Input Class Initialized
INFO - 2017-02-20 12:00:05 --> Language Class Initialized
INFO - 2017-02-20 12:00:05 --> Loader Class Initialized
INFO - 2017-02-20 12:00:05 --> Helper loaded: url_helper
INFO - 2017-02-20 12:00:05 --> Helper loaded: language_helper
INFO - 2017-02-20 12:00:05 --> Helper loaded: html_helper
INFO - 2017-02-20 12:00:05 --> Helper loaded: form_helper
INFO - 2017-02-20 12:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:00:05 --> Controller Class Initialized
INFO - 2017-02-20 12:00:05 --> Database Driver Class Initialized
INFO - 2017-02-20 12:00:05 --> Model Class Initialized
INFO - 2017-02-20 12:00:05 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 12:00:05 --> Severity: Notice --> Array to string conversion C:\wamp64\www\savsoftquiz\system\database\DB_query_builder.php 669
ERROR - 2017-02-20 12:00:05 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `register`
WHERE `id` = `Array`
INFO - 2017-02-20 12:00:05 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-02-20 12:03:36 --> Config Class Initialized
INFO - 2017-02-20 12:03:36 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:03:36 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:03:36 --> Utf8 Class Initialized
INFO - 2017-02-20 12:03:37 --> URI Class Initialized
INFO - 2017-02-20 12:03:37 --> Router Class Initialized
INFO - 2017-02-20 12:03:37 --> Output Class Initialized
INFO - 2017-02-20 12:03:37 --> Security Class Initialized
DEBUG - 2017-02-20 12:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:03:37 --> Input Class Initialized
INFO - 2017-02-20 12:03:37 --> Language Class Initialized
INFO - 2017-02-20 12:03:37 --> Loader Class Initialized
INFO - 2017-02-20 12:03:37 --> Helper loaded: url_helper
INFO - 2017-02-20 12:03:37 --> Helper loaded: language_helper
INFO - 2017-02-20 12:03:37 --> Helper loaded: html_helper
INFO - 2017-02-20 12:03:37 --> Helper loaded: form_helper
INFO - 2017-02-20 12:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:03:37 --> Controller Class Initialized
INFO - 2017-02-20 12:03:37 --> Database Driver Class Initialized
INFO - 2017-02-20 12:03:37 --> Model Class Initialized
INFO - 2017-02-20 12:03:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 12:03:37 --> Final output sent to browser
DEBUG - 2017-02-20 12:03:37 --> Total execution time: 0.1439
INFO - 2017-02-20 12:09:24 --> Config Class Initialized
INFO - 2017-02-20 12:09:24 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:09:24 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:09:24 --> Utf8 Class Initialized
INFO - 2017-02-20 12:09:24 --> URI Class Initialized
INFO - 2017-02-20 12:09:24 --> Router Class Initialized
INFO - 2017-02-20 12:09:24 --> Output Class Initialized
INFO - 2017-02-20 12:09:24 --> Security Class Initialized
DEBUG - 2017-02-20 12:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:09:24 --> Input Class Initialized
INFO - 2017-02-20 12:09:24 --> Language Class Initialized
INFO - 2017-02-20 12:09:24 --> Loader Class Initialized
INFO - 2017-02-20 12:09:24 --> Helper loaded: url_helper
INFO - 2017-02-20 12:09:24 --> Helper loaded: language_helper
INFO - 2017-02-20 12:09:24 --> Helper loaded: html_helper
INFO - 2017-02-20 12:09:24 --> Helper loaded: form_helper
INFO - 2017-02-20 12:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:09:24 --> Controller Class Initialized
INFO - 2017-02-20 12:09:24 --> Database Driver Class Initialized
INFO - 2017-02-20 12:09:24 --> Model Class Initialized
INFO - 2017-02-20 12:09:24 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 12:09:24 --> Severity: Error --> Call to undefined function len() C:\wamp64\www\savsoftquiz\application\controllers\Register.php 86
INFO - 2017-02-20 12:10:09 --> Config Class Initialized
INFO - 2017-02-20 12:10:09 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:10:09 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:10:09 --> Utf8 Class Initialized
INFO - 2017-02-20 12:10:09 --> URI Class Initialized
INFO - 2017-02-20 12:10:09 --> Router Class Initialized
INFO - 2017-02-20 12:10:09 --> Output Class Initialized
INFO - 2017-02-20 12:10:09 --> Security Class Initialized
DEBUG - 2017-02-20 12:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:10:09 --> Input Class Initialized
INFO - 2017-02-20 12:10:09 --> Language Class Initialized
INFO - 2017-02-20 12:10:09 --> Loader Class Initialized
INFO - 2017-02-20 12:10:09 --> Helper loaded: url_helper
INFO - 2017-02-20 12:10:09 --> Helper loaded: language_helper
INFO - 2017-02-20 12:10:09 --> Helper loaded: html_helper
INFO - 2017-02-20 12:10:09 --> Helper loaded: form_helper
INFO - 2017-02-20 12:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:10:09 --> Controller Class Initialized
INFO - 2017-02-20 12:10:09 --> Database Driver Class Initialized
INFO - 2017-02-20 12:10:09 --> Model Class Initialized
INFO - 2017-02-20 12:10:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 12:10:09 --> Final output sent to browser
DEBUG - 2017-02-20 12:10:09 --> Total execution time: 0.0956
INFO - 2017-02-20 12:10:38 --> Config Class Initialized
INFO - 2017-02-20 12:10:38 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:10:38 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:10:38 --> Utf8 Class Initialized
INFO - 2017-02-20 12:10:38 --> URI Class Initialized
INFO - 2017-02-20 12:10:38 --> Router Class Initialized
INFO - 2017-02-20 12:10:38 --> Output Class Initialized
INFO - 2017-02-20 12:10:38 --> Security Class Initialized
DEBUG - 2017-02-20 12:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:10:38 --> Input Class Initialized
INFO - 2017-02-20 12:10:38 --> Language Class Initialized
ERROR - 2017-02-20 12:10:38 --> Severity: Parsing Error --> syntax error, unexpected '$genAwal' (T_VARIABLE) C:\wamp64\www\savsoftquiz\application\controllers\Register.php 86
INFO - 2017-02-20 12:10:44 --> Config Class Initialized
INFO - 2017-02-20 12:10:44 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:10:44 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:10:44 --> Utf8 Class Initialized
INFO - 2017-02-20 12:10:44 --> URI Class Initialized
INFO - 2017-02-20 12:10:44 --> Router Class Initialized
INFO - 2017-02-20 12:10:44 --> Output Class Initialized
INFO - 2017-02-20 12:10:44 --> Security Class Initialized
DEBUG - 2017-02-20 12:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:10:44 --> Input Class Initialized
INFO - 2017-02-20 12:10:44 --> Language Class Initialized
INFO - 2017-02-20 12:10:44 --> Loader Class Initialized
INFO - 2017-02-20 12:10:44 --> Helper loaded: url_helper
INFO - 2017-02-20 12:10:44 --> Helper loaded: language_helper
INFO - 2017-02-20 12:10:44 --> Helper loaded: html_helper
INFO - 2017-02-20 12:10:44 --> Helper loaded: form_helper
INFO - 2017-02-20 12:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:10:44 --> Controller Class Initialized
INFO - 2017-02-20 12:10:44 --> Database Driver Class Initialized
INFO - 2017-02-20 12:10:44 --> Model Class Initialized
INFO - 2017-02-20 12:10:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 12:10:44 --> Final output sent to browser
DEBUG - 2017-02-20 12:10:44 --> Total execution time: 0.1024
INFO - 2017-02-20 12:10:50 --> Config Class Initialized
INFO - 2017-02-20 12:10:50 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:10:50 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:10:50 --> Utf8 Class Initialized
INFO - 2017-02-20 12:10:50 --> URI Class Initialized
INFO - 2017-02-20 12:10:50 --> Router Class Initialized
INFO - 2017-02-20 12:10:50 --> Output Class Initialized
INFO - 2017-02-20 12:10:50 --> Security Class Initialized
DEBUG - 2017-02-20 12:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:10:50 --> Input Class Initialized
INFO - 2017-02-20 12:10:50 --> Language Class Initialized
INFO - 2017-02-20 12:10:50 --> Loader Class Initialized
INFO - 2017-02-20 12:10:50 --> Helper loaded: url_helper
INFO - 2017-02-20 12:10:50 --> Helper loaded: language_helper
INFO - 2017-02-20 12:10:50 --> Helper loaded: html_helper
INFO - 2017-02-20 12:10:50 --> Helper loaded: form_helper
INFO - 2017-02-20 12:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:10:50 --> Controller Class Initialized
INFO - 2017-02-20 12:10:50 --> Database Driver Class Initialized
INFO - 2017-02-20 12:10:50 --> Model Class Initialized
INFO - 2017-02-20 12:10:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 12:10:50 --> Final output sent to browser
DEBUG - 2017-02-20 12:10:50 --> Total execution time: 0.1006
INFO - 2017-02-20 12:11:03 --> Config Class Initialized
INFO - 2017-02-20 12:11:03 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:11:03 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:11:03 --> Utf8 Class Initialized
INFO - 2017-02-20 12:11:03 --> URI Class Initialized
INFO - 2017-02-20 12:11:03 --> Router Class Initialized
INFO - 2017-02-20 12:11:03 --> Output Class Initialized
INFO - 2017-02-20 12:11:03 --> Security Class Initialized
DEBUG - 2017-02-20 12:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:11:03 --> Input Class Initialized
INFO - 2017-02-20 12:11:03 --> Language Class Initialized
INFO - 2017-02-20 12:11:03 --> Loader Class Initialized
INFO - 2017-02-20 12:11:03 --> Helper loaded: url_helper
INFO - 2017-02-20 12:11:03 --> Helper loaded: language_helper
INFO - 2017-02-20 12:11:03 --> Helper loaded: html_helper
INFO - 2017-02-20 12:11:03 --> Helper loaded: form_helper
INFO - 2017-02-20 12:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:11:03 --> Controller Class Initialized
INFO - 2017-02-20 12:11:03 --> Database Driver Class Initialized
INFO - 2017-02-20 12:11:03 --> Model Class Initialized
INFO - 2017-02-20 12:11:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 12:11:03 --> Final output sent to browser
DEBUG - 2017-02-20 12:11:03 --> Total execution time: 0.1241
INFO - 2017-02-20 12:11:21 --> Config Class Initialized
INFO - 2017-02-20 12:11:21 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:11:21 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:11:21 --> Utf8 Class Initialized
INFO - 2017-02-20 12:11:21 --> URI Class Initialized
INFO - 2017-02-20 12:11:21 --> Router Class Initialized
INFO - 2017-02-20 12:11:21 --> Output Class Initialized
INFO - 2017-02-20 12:11:21 --> Security Class Initialized
DEBUG - 2017-02-20 12:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:11:21 --> Input Class Initialized
INFO - 2017-02-20 12:11:21 --> Language Class Initialized
INFO - 2017-02-20 12:11:21 --> Loader Class Initialized
INFO - 2017-02-20 12:11:21 --> Helper loaded: url_helper
INFO - 2017-02-20 12:11:21 --> Helper loaded: language_helper
INFO - 2017-02-20 12:11:21 --> Helper loaded: html_helper
INFO - 2017-02-20 12:11:21 --> Helper loaded: form_helper
INFO - 2017-02-20 12:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:11:21 --> Controller Class Initialized
INFO - 2017-02-20 12:11:21 --> Database Driver Class Initialized
INFO - 2017-02-20 12:11:21 --> Model Class Initialized
INFO - 2017-02-20 12:11:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 12:11:21 --> Final output sent to browser
DEBUG - 2017-02-20 12:11:21 --> Total execution time: 0.1119
INFO - 2017-02-20 12:12:36 --> Config Class Initialized
INFO - 2017-02-20 12:12:36 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:12:36 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:12:36 --> Utf8 Class Initialized
INFO - 2017-02-20 12:12:36 --> URI Class Initialized
INFO - 2017-02-20 12:12:36 --> Router Class Initialized
INFO - 2017-02-20 12:12:36 --> Output Class Initialized
INFO - 2017-02-20 12:12:36 --> Security Class Initialized
DEBUG - 2017-02-20 12:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:12:36 --> Input Class Initialized
INFO - 2017-02-20 12:12:36 --> Language Class Initialized
INFO - 2017-02-20 12:12:36 --> Loader Class Initialized
INFO - 2017-02-20 12:12:36 --> Helper loaded: url_helper
INFO - 2017-02-20 12:12:36 --> Helper loaded: language_helper
INFO - 2017-02-20 12:12:36 --> Helper loaded: html_helper
INFO - 2017-02-20 12:12:36 --> Helper loaded: form_helper
INFO - 2017-02-20 12:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:12:36 --> Controller Class Initialized
INFO - 2017-02-20 12:12:36 --> Database Driver Class Initialized
INFO - 2017-02-20 12:12:36 --> Model Class Initialized
INFO - 2017-02-20 12:12:36 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 12:12:36 --> Severity: Error --> Call to undefined function data() C:\wamp64\www\savsoftquiz\application\controllers\Register.php 84
INFO - 2017-02-20 12:12:47 --> Config Class Initialized
INFO - 2017-02-20 12:12:47 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:12:47 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:12:47 --> Utf8 Class Initialized
INFO - 2017-02-20 12:12:47 --> URI Class Initialized
INFO - 2017-02-20 12:12:47 --> Router Class Initialized
INFO - 2017-02-20 12:12:47 --> Output Class Initialized
INFO - 2017-02-20 12:12:47 --> Security Class Initialized
DEBUG - 2017-02-20 12:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:12:47 --> Input Class Initialized
INFO - 2017-02-20 12:12:47 --> Language Class Initialized
INFO - 2017-02-20 12:12:47 --> Loader Class Initialized
INFO - 2017-02-20 12:12:47 --> Helper loaded: url_helper
INFO - 2017-02-20 12:12:47 --> Helper loaded: language_helper
INFO - 2017-02-20 12:12:47 --> Helper loaded: html_helper
INFO - 2017-02-20 12:12:47 --> Helper loaded: form_helper
INFO - 2017-02-20 12:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:12:47 --> Controller Class Initialized
INFO - 2017-02-20 12:12:47 --> Database Driver Class Initialized
INFO - 2017-02-20 12:12:47 --> Model Class Initialized
INFO - 2017-02-20 12:12:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 12:12:47 --> Final output sent to browser
DEBUG - 2017-02-20 12:12:47 --> Total execution time: 0.1231
INFO - 2017-02-20 12:13:10 --> Config Class Initialized
INFO - 2017-02-20 12:13:10 --> Hooks Class Initialized
DEBUG - 2017-02-20 12:13:10 --> UTF-8 Support Enabled
INFO - 2017-02-20 12:13:10 --> Utf8 Class Initialized
INFO - 2017-02-20 12:13:10 --> URI Class Initialized
INFO - 2017-02-20 12:13:10 --> Router Class Initialized
INFO - 2017-02-20 12:13:10 --> Output Class Initialized
INFO - 2017-02-20 12:13:10 --> Security Class Initialized
DEBUG - 2017-02-20 12:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 12:13:10 --> Input Class Initialized
INFO - 2017-02-20 12:13:10 --> Language Class Initialized
INFO - 2017-02-20 12:13:10 --> Loader Class Initialized
INFO - 2017-02-20 12:13:10 --> Helper loaded: url_helper
INFO - 2017-02-20 12:13:10 --> Helper loaded: language_helper
INFO - 2017-02-20 12:13:10 --> Helper loaded: html_helper
INFO - 2017-02-20 12:13:10 --> Helper loaded: form_helper
INFO - 2017-02-20 12:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 12:13:10 --> Controller Class Initialized
INFO - 2017-02-20 12:13:10 --> Database Driver Class Initialized
INFO - 2017-02-20 12:13:10 --> Model Class Initialized
INFO - 2017-02-20 12:13:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 12:13:10 --> Final output sent to browser
DEBUG - 2017-02-20 12:13:10 --> Total execution time: 0.1308
INFO - 2017-02-20 16:18:38 --> Config Class Initialized
INFO - 2017-02-20 16:18:38 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:18:38 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:18:38 --> Utf8 Class Initialized
INFO - 2017-02-20 16:18:38 --> URI Class Initialized
INFO - 2017-02-20 16:18:38 --> Router Class Initialized
INFO - 2017-02-20 16:18:38 --> Output Class Initialized
INFO - 2017-02-20 16:18:38 --> Security Class Initialized
DEBUG - 2017-02-20 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:18:38 --> Input Class Initialized
INFO - 2017-02-20 16:18:38 --> Language Class Initialized
INFO - 2017-02-20 16:18:38 --> Loader Class Initialized
INFO - 2017-02-20 16:18:38 --> Helper loaded: url_helper
INFO - 2017-02-20 16:18:38 --> Helper loaded: language_helper
INFO - 2017-02-20 16:18:38 --> Helper loaded: html_helper
INFO - 2017-02-20 16:18:38 --> Helper loaded: form_helper
INFO - 2017-02-20 16:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:18:38 --> Controller Class Initialized
INFO - 2017-02-20 16:18:38 --> Database Driver Class Initialized
INFO - 2017-02-20 16:18:38 --> Model Class Initialized
INFO - 2017-02-20 16:18:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:18:38 --> Final output sent to browser
DEBUG - 2017-02-20 16:18:38 --> Total execution time: 0.1489
INFO - 2017-02-20 16:18:54 --> Config Class Initialized
INFO - 2017-02-20 16:18:54 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:18:54 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:18:54 --> Utf8 Class Initialized
INFO - 2017-02-20 16:18:54 --> URI Class Initialized
INFO - 2017-02-20 16:18:54 --> Router Class Initialized
INFO - 2017-02-20 16:18:54 --> Output Class Initialized
INFO - 2017-02-20 16:18:54 --> Security Class Initialized
DEBUG - 2017-02-20 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:18:54 --> Input Class Initialized
INFO - 2017-02-20 16:18:54 --> Language Class Initialized
INFO - 2017-02-20 16:18:54 --> Loader Class Initialized
INFO - 2017-02-20 16:18:54 --> Helper loaded: url_helper
INFO - 2017-02-20 16:18:54 --> Helper loaded: language_helper
INFO - 2017-02-20 16:18:54 --> Helper loaded: html_helper
INFO - 2017-02-20 16:18:54 --> Helper loaded: form_helper
INFO - 2017-02-20 16:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:18:54 --> Controller Class Initialized
INFO - 2017-02-20 16:18:54 --> Database Driver Class Initialized
INFO - 2017-02-20 16:18:54 --> Model Class Initialized
INFO - 2017-02-20 16:18:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:18:54 --> Final output sent to browser
DEBUG - 2017-02-20 16:18:54 --> Total execution time: 0.1398
INFO - 2017-02-20 16:19:14 --> Config Class Initialized
INFO - 2017-02-20 16:19:14 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:19:14 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:19:14 --> Utf8 Class Initialized
INFO - 2017-02-20 16:19:14 --> URI Class Initialized
INFO - 2017-02-20 16:19:14 --> Router Class Initialized
INFO - 2017-02-20 16:19:14 --> Output Class Initialized
INFO - 2017-02-20 16:19:14 --> Security Class Initialized
DEBUG - 2017-02-20 16:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:19:14 --> Input Class Initialized
INFO - 2017-02-20 16:19:14 --> Language Class Initialized
INFO - 2017-02-20 16:19:14 --> Loader Class Initialized
INFO - 2017-02-20 16:19:14 --> Helper loaded: url_helper
INFO - 2017-02-20 16:19:14 --> Helper loaded: language_helper
INFO - 2017-02-20 16:19:14 --> Helper loaded: html_helper
INFO - 2017-02-20 16:19:14 --> Helper loaded: form_helper
INFO - 2017-02-20 16:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:19:14 --> Controller Class Initialized
INFO - 2017-02-20 16:19:14 --> Database Driver Class Initialized
INFO - 2017-02-20 16:19:14 --> Model Class Initialized
INFO - 2017-02-20 16:19:14 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 16:19:14 --> Severity: Notice --> Undefined index: registration_no C:\wamp64\www\savsoftquiz\application\models\Register_model.php 47
INFO - 2017-02-20 16:19:14 --> Final output sent to browser
DEBUG - 2017-02-20 16:19:14 --> Total execution time: 0.1377
INFO - 2017-02-20 16:19:31 --> Config Class Initialized
INFO - 2017-02-20 16:19:31 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:19:31 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:19:31 --> Utf8 Class Initialized
INFO - 2017-02-20 16:19:31 --> URI Class Initialized
INFO - 2017-02-20 16:19:31 --> Router Class Initialized
INFO - 2017-02-20 16:19:31 --> Output Class Initialized
INFO - 2017-02-20 16:19:32 --> Security Class Initialized
DEBUG - 2017-02-20 16:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:19:32 --> Input Class Initialized
INFO - 2017-02-20 16:19:32 --> Language Class Initialized
INFO - 2017-02-20 16:19:32 --> Loader Class Initialized
INFO - 2017-02-20 16:19:32 --> Helper loaded: url_helper
INFO - 2017-02-20 16:19:32 --> Helper loaded: language_helper
INFO - 2017-02-20 16:19:32 --> Helper loaded: html_helper
INFO - 2017-02-20 16:19:32 --> Helper loaded: form_helper
INFO - 2017-02-20 16:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:19:32 --> Controller Class Initialized
INFO - 2017-02-20 16:19:32 --> Database Driver Class Initialized
INFO - 2017-02-20 16:19:32 --> Model Class Initialized
INFO - 2017-02-20 16:19:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:19:32 --> Final output sent to browser
DEBUG - 2017-02-20 16:19:32 --> Total execution time: 0.1752
INFO - 2017-02-20 16:19:58 --> Config Class Initialized
INFO - 2017-02-20 16:19:58 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:19:58 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:19:58 --> Utf8 Class Initialized
INFO - 2017-02-20 16:19:58 --> URI Class Initialized
INFO - 2017-02-20 16:19:58 --> Router Class Initialized
INFO - 2017-02-20 16:19:59 --> Output Class Initialized
INFO - 2017-02-20 16:19:59 --> Security Class Initialized
DEBUG - 2017-02-20 16:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:19:59 --> Input Class Initialized
INFO - 2017-02-20 16:19:59 --> Language Class Initialized
INFO - 2017-02-20 16:19:59 --> Loader Class Initialized
INFO - 2017-02-20 16:19:59 --> Helper loaded: url_helper
INFO - 2017-02-20 16:19:59 --> Helper loaded: language_helper
INFO - 2017-02-20 16:19:59 --> Helper loaded: html_helper
INFO - 2017-02-20 16:19:59 --> Helper loaded: form_helper
INFO - 2017-02-20 16:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:19:59 --> Controller Class Initialized
INFO - 2017-02-20 16:19:59 --> Database Driver Class Initialized
INFO - 2017-02-20 16:19:59 --> Model Class Initialized
INFO - 2017-02-20 16:19:59 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 16:19:59 --> Severity: Error --> Cannot use object of type stdClass as array C:\wamp64\www\savsoftquiz\application\models\Register_model.php 47
INFO - 2017-02-20 16:20:13 --> Config Class Initialized
INFO - 2017-02-20 16:20:13 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:20:13 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:20:13 --> Utf8 Class Initialized
INFO - 2017-02-20 16:20:13 --> URI Class Initialized
INFO - 2017-02-20 16:20:13 --> Router Class Initialized
INFO - 2017-02-20 16:20:13 --> Output Class Initialized
INFO - 2017-02-20 16:20:13 --> Security Class Initialized
DEBUG - 2017-02-20 16:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:20:13 --> Input Class Initialized
INFO - 2017-02-20 16:20:13 --> Language Class Initialized
INFO - 2017-02-20 16:20:13 --> Loader Class Initialized
INFO - 2017-02-20 16:20:13 --> Helper loaded: url_helper
INFO - 2017-02-20 16:20:13 --> Helper loaded: language_helper
INFO - 2017-02-20 16:20:13 --> Helper loaded: html_helper
INFO - 2017-02-20 16:20:13 --> Helper loaded: form_helper
INFO - 2017-02-20 16:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:20:13 --> Controller Class Initialized
INFO - 2017-02-20 16:20:13 --> Database Driver Class Initialized
INFO - 2017-02-20 16:20:13 --> Model Class Initialized
INFO - 2017-02-20 16:20:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:20:13 --> Final output sent to browser
DEBUG - 2017-02-20 16:20:13 --> Total execution time: 0.1192
INFO - 2017-02-20 16:20:50 --> Config Class Initialized
INFO - 2017-02-20 16:20:50 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:20:50 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:20:50 --> Utf8 Class Initialized
INFO - 2017-02-20 16:20:50 --> URI Class Initialized
INFO - 2017-02-20 16:20:50 --> Router Class Initialized
INFO - 2017-02-20 16:20:50 --> Output Class Initialized
INFO - 2017-02-20 16:20:50 --> Security Class Initialized
DEBUG - 2017-02-20 16:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:20:50 --> Input Class Initialized
INFO - 2017-02-20 16:20:50 --> Language Class Initialized
INFO - 2017-02-20 16:20:50 --> Loader Class Initialized
INFO - 2017-02-20 16:20:50 --> Helper loaded: url_helper
INFO - 2017-02-20 16:20:50 --> Helper loaded: language_helper
INFO - 2017-02-20 16:20:50 --> Helper loaded: html_helper
INFO - 2017-02-20 16:20:50 --> Helper loaded: form_helper
INFO - 2017-02-20 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:20:50 --> Controller Class Initialized
INFO - 2017-02-20 16:20:50 --> Database Driver Class Initialized
INFO - 2017-02-20 16:20:51 --> Model Class Initialized
INFO - 2017-02-20 16:20:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:20:51 --> Final output sent to browser
DEBUG - 2017-02-20 16:20:51 --> Total execution time: 0.1288
INFO - 2017-02-20 16:21:58 --> Config Class Initialized
INFO - 2017-02-20 16:21:58 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:21:58 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:21:58 --> Utf8 Class Initialized
INFO - 2017-02-20 16:21:58 --> URI Class Initialized
INFO - 2017-02-20 16:21:58 --> Router Class Initialized
INFO - 2017-02-20 16:21:58 --> Output Class Initialized
INFO - 2017-02-20 16:21:58 --> Security Class Initialized
DEBUG - 2017-02-20 16:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:21:58 --> Input Class Initialized
INFO - 2017-02-20 16:21:58 --> Language Class Initialized
INFO - 2017-02-20 16:21:58 --> Loader Class Initialized
INFO - 2017-02-20 16:21:58 --> Helper loaded: url_helper
INFO - 2017-02-20 16:21:58 --> Helper loaded: language_helper
INFO - 2017-02-20 16:21:58 --> Helper loaded: html_helper
INFO - 2017-02-20 16:21:58 --> Helper loaded: form_helper
INFO - 2017-02-20 16:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:21:58 --> Controller Class Initialized
INFO - 2017-02-20 16:21:58 --> Database Driver Class Initialized
INFO - 2017-02-20 16:21:58 --> Model Class Initialized
INFO - 2017-02-20 16:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:21:58 --> Final output sent to browser
DEBUG - 2017-02-20 16:21:58 --> Total execution time: 0.1287
INFO - 2017-02-20 16:22:17 --> Config Class Initialized
INFO - 2017-02-20 16:22:17 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:22:17 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:22:17 --> Utf8 Class Initialized
INFO - 2017-02-20 16:22:17 --> URI Class Initialized
INFO - 2017-02-20 16:22:17 --> Router Class Initialized
INFO - 2017-02-20 16:22:17 --> Output Class Initialized
INFO - 2017-02-20 16:22:17 --> Security Class Initialized
DEBUG - 2017-02-20 16:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:22:17 --> Input Class Initialized
INFO - 2017-02-20 16:22:17 --> Language Class Initialized
INFO - 2017-02-20 16:22:17 --> Loader Class Initialized
INFO - 2017-02-20 16:22:17 --> Helper loaded: url_helper
INFO - 2017-02-20 16:22:17 --> Helper loaded: language_helper
INFO - 2017-02-20 16:22:17 --> Helper loaded: html_helper
INFO - 2017-02-20 16:22:17 --> Helper loaded: form_helper
INFO - 2017-02-20 16:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:22:17 --> Controller Class Initialized
INFO - 2017-02-20 16:22:17 --> Database Driver Class Initialized
INFO - 2017-02-20 16:22:17 --> Model Class Initialized
INFO - 2017-02-20 16:22:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:22:17 --> Final output sent to browser
DEBUG - 2017-02-20 16:22:17 --> Total execution time: 0.1140
INFO - 2017-02-20 16:22:54 --> Config Class Initialized
INFO - 2017-02-20 16:22:54 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:22:54 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:22:54 --> Utf8 Class Initialized
INFO - 2017-02-20 16:22:54 --> URI Class Initialized
INFO - 2017-02-20 16:22:54 --> Router Class Initialized
INFO - 2017-02-20 16:22:54 --> Output Class Initialized
INFO - 2017-02-20 16:22:54 --> Security Class Initialized
DEBUG - 2017-02-20 16:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:22:54 --> Input Class Initialized
INFO - 2017-02-20 16:22:54 --> Language Class Initialized
INFO - 2017-02-20 16:22:54 --> Loader Class Initialized
INFO - 2017-02-20 16:22:54 --> Helper loaded: url_helper
INFO - 2017-02-20 16:22:54 --> Helper loaded: language_helper
INFO - 2017-02-20 16:22:54 --> Helper loaded: html_helper
INFO - 2017-02-20 16:22:54 --> Helper loaded: form_helper
INFO - 2017-02-20 16:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:22:54 --> Controller Class Initialized
INFO - 2017-02-20 16:22:54 --> Database Driver Class Initialized
INFO - 2017-02-20 16:22:54 --> Model Class Initialized
INFO - 2017-02-20 16:22:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:22:54 --> Final output sent to browser
DEBUG - 2017-02-20 16:22:54 --> Total execution time: 0.0894
INFO - 2017-02-20 16:22:55 --> Config Class Initialized
INFO - 2017-02-20 16:22:55 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:22:55 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:22:55 --> Utf8 Class Initialized
INFO - 2017-02-20 16:22:55 --> URI Class Initialized
INFO - 2017-02-20 16:22:55 --> Router Class Initialized
INFO - 2017-02-20 16:22:55 --> Output Class Initialized
INFO - 2017-02-20 16:22:55 --> Security Class Initialized
DEBUG - 2017-02-20 16:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:22:55 --> Input Class Initialized
INFO - 2017-02-20 16:22:55 --> Language Class Initialized
INFO - 2017-02-20 16:22:55 --> Loader Class Initialized
INFO - 2017-02-20 16:22:55 --> Helper loaded: url_helper
INFO - 2017-02-20 16:22:55 --> Helper loaded: language_helper
INFO - 2017-02-20 16:22:55 --> Helper loaded: html_helper
INFO - 2017-02-20 16:22:55 --> Helper loaded: form_helper
INFO - 2017-02-20 16:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:22:55 --> Controller Class Initialized
INFO - 2017-02-20 16:22:55 --> Database Driver Class Initialized
INFO - 2017-02-20 16:22:56 --> Model Class Initialized
INFO - 2017-02-20 16:22:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:22:56 --> Final output sent to browser
DEBUG - 2017-02-20 16:22:56 --> Total execution time: 0.1444
INFO - 2017-02-20 16:24:09 --> Config Class Initialized
INFO - 2017-02-20 16:24:09 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:24:10 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:24:10 --> Utf8 Class Initialized
INFO - 2017-02-20 16:24:10 --> URI Class Initialized
INFO - 2017-02-20 16:24:10 --> Router Class Initialized
INFO - 2017-02-20 16:24:10 --> Output Class Initialized
INFO - 2017-02-20 16:24:10 --> Security Class Initialized
DEBUG - 2017-02-20 16:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:24:10 --> Input Class Initialized
INFO - 2017-02-20 16:24:10 --> Language Class Initialized
INFO - 2017-02-20 16:24:10 --> Loader Class Initialized
INFO - 2017-02-20 16:24:10 --> Helper loaded: url_helper
INFO - 2017-02-20 16:24:10 --> Helper loaded: language_helper
INFO - 2017-02-20 16:24:10 --> Helper loaded: html_helper
INFO - 2017-02-20 16:24:10 --> Helper loaded: form_helper
INFO - 2017-02-20 16:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:24:10 --> Controller Class Initialized
INFO - 2017-02-20 16:24:10 --> Database Driver Class Initialized
INFO - 2017-02-20 16:24:10 --> Model Class Initialized
INFO - 2017-02-20 16:24:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:24:10 --> Final output sent to browser
DEBUG - 2017-02-20 16:24:10 --> Total execution time: 0.1607
INFO - 2017-02-20 16:24:26 --> Config Class Initialized
INFO - 2017-02-20 16:24:26 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:24:26 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:24:26 --> Utf8 Class Initialized
INFO - 2017-02-20 16:24:26 --> URI Class Initialized
INFO - 2017-02-20 16:24:26 --> Router Class Initialized
INFO - 2017-02-20 16:24:26 --> Output Class Initialized
INFO - 2017-02-20 16:24:26 --> Security Class Initialized
DEBUG - 2017-02-20 16:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:24:26 --> Input Class Initialized
INFO - 2017-02-20 16:24:26 --> Language Class Initialized
INFO - 2017-02-20 16:24:26 --> Loader Class Initialized
INFO - 2017-02-20 16:24:26 --> Helper loaded: url_helper
INFO - 2017-02-20 16:24:26 --> Helper loaded: language_helper
INFO - 2017-02-20 16:24:26 --> Helper loaded: html_helper
INFO - 2017-02-20 16:24:26 --> Helper loaded: form_helper
INFO - 2017-02-20 16:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:24:26 --> Controller Class Initialized
INFO - 2017-02-20 16:24:26 --> Database Driver Class Initialized
INFO - 2017-02-20 16:24:26 --> Model Class Initialized
INFO - 2017-02-20 16:24:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:24:26 --> Final output sent to browser
DEBUG - 2017-02-20 16:24:26 --> Total execution time: 0.1230
INFO - 2017-02-20 16:24:57 --> Config Class Initialized
INFO - 2017-02-20 16:24:57 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:24:57 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:24:57 --> Utf8 Class Initialized
INFO - 2017-02-20 16:24:57 --> URI Class Initialized
INFO - 2017-02-20 16:24:57 --> Router Class Initialized
INFO - 2017-02-20 16:24:57 --> Output Class Initialized
INFO - 2017-02-20 16:24:57 --> Security Class Initialized
DEBUG - 2017-02-20 16:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:24:57 --> Input Class Initialized
INFO - 2017-02-20 16:24:57 --> Language Class Initialized
INFO - 2017-02-20 16:24:57 --> Loader Class Initialized
INFO - 2017-02-20 16:24:57 --> Helper loaded: url_helper
INFO - 2017-02-20 16:24:57 --> Helper loaded: language_helper
INFO - 2017-02-20 16:24:57 --> Helper loaded: html_helper
INFO - 2017-02-20 16:24:57 --> Helper loaded: form_helper
INFO - 2017-02-20 16:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:24:57 --> Controller Class Initialized
INFO - 2017-02-20 16:24:57 --> Database Driver Class Initialized
INFO - 2017-02-20 16:24:57 --> Model Class Initialized
INFO - 2017-02-20 16:24:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:24:57 --> Final output sent to browser
DEBUG - 2017-02-20 16:24:57 --> Total execution time: 0.0926
INFO - 2017-02-20 16:25:29 --> Config Class Initialized
INFO - 2017-02-20 16:25:29 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:25:29 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:25:29 --> Utf8 Class Initialized
INFO - 2017-02-20 16:25:29 --> URI Class Initialized
INFO - 2017-02-20 16:25:29 --> Router Class Initialized
INFO - 2017-02-20 16:25:29 --> Output Class Initialized
INFO - 2017-02-20 16:25:29 --> Security Class Initialized
DEBUG - 2017-02-20 16:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:25:29 --> Input Class Initialized
INFO - 2017-02-20 16:25:29 --> Language Class Initialized
INFO - 2017-02-20 16:25:29 --> Loader Class Initialized
INFO - 2017-02-20 16:25:29 --> Helper loaded: url_helper
INFO - 2017-02-20 16:25:29 --> Helper loaded: language_helper
INFO - 2017-02-20 16:25:29 --> Helper loaded: html_helper
INFO - 2017-02-20 16:25:29 --> Helper loaded: form_helper
INFO - 2017-02-20 16:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:25:29 --> Controller Class Initialized
INFO - 2017-02-20 16:25:29 --> Database Driver Class Initialized
INFO - 2017-02-20 16:25:29 --> Model Class Initialized
INFO - 2017-02-20 16:25:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:25:29 --> Final output sent to browser
DEBUG - 2017-02-20 16:25:29 --> Total execution time: 0.1034
INFO - 2017-02-20 16:29:23 --> Config Class Initialized
INFO - 2017-02-20 16:29:23 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:29:23 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:29:23 --> Utf8 Class Initialized
INFO - 2017-02-20 16:29:23 --> URI Class Initialized
INFO - 2017-02-20 16:29:23 --> Router Class Initialized
INFO - 2017-02-20 16:29:23 --> Output Class Initialized
INFO - 2017-02-20 16:29:23 --> Security Class Initialized
DEBUG - 2017-02-20 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:29:23 --> Input Class Initialized
INFO - 2017-02-20 16:29:23 --> Language Class Initialized
INFO - 2017-02-20 16:29:23 --> Loader Class Initialized
INFO - 2017-02-20 16:29:23 --> Helper loaded: url_helper
INFO - 2017-02-20 16:29:23 --> Helper loaded: language_helper
INFO - 2017-02-20 16:29:23 --> Helper loaded: html_helper
INFO - 2017-02-20 16:29:23 --> Helper loaded: form_helper
INFO - 2017-02-20 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:29:23 --> Controller Class Initialized
INFO - 2017-02-20 16:29:23 --> Database Driver Class Initialized
INFO - 2017-02-20 16:29:23 --> Model Class Initialized
INFO - 2017-02-20 16:29:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:29:23 --> Final output sent to browser
DEBUG - 2017-02-20 16:29:23 --> Total execution time: 0.1270
INFO - 2017-02-20 16:38:57 --> Config Class Initialized
INFO - 2017-02-20 16:38:57 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:38:57 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:38:57 --> Utf8 Class Initialized
INFO - 2017-02-20 16:38:57 --> URI Class Initialized
INFO - 2017-02-20 16:38:57 --> Router Class Initialized
INFO - 2017-02-20 16:38:57 --> Output Class Initialized
INFO - 2017-02-20 16:38:57 --> Security Class Initialized
DEBUG - 2017-02-20 16:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:38:57 --> Input Class Initialized
INFO - 2017-02-20 16:38:57 --> Language Class Initialized
INFO - 2017-02-20 16:38:58 --> Loader Class Initialized
INFO - 2017-02-20 16:38:58 --> Helper loaded: url_helper
INFO - 2017-02-20 16:38:58 --> Helper loaded: language_helper
INFO - 2017-02-20 16:38:58 --> Helper loaded: html_helper
INFO - 2017-02-20 16:38:58 --> Helper loaded: form_helper
INFO - 2017-02-20 16:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:38:58 --> Controller Class Initialized
INFO - 2017-02-20 16:38:58 --> Database Driver Class Initialized
INFO - 2017-02-20 16:38:58 --> Model Class Initialized
INFO - 2017-02-20 16:38:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:38:58 --> Final output sent to browser
DEBUG - 2017-02-20 16:38:58 --> Total execution time: 0.1264
INFO - 2017-02-20 16:39:53 --> Config Class Initialized
INFO - 2017-02-20 16:39:53 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:39:53 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:39:53 --> Utf8 Class Initialized
INFO - 2017-02-20 16:39:53 --> URI Class Initialized
INFO - 2017-02-20 16:39:53 --> Router Class Initialized
INFO - 2017-02-20 16:39:53 --> Output Class Initialized
INFO - 2017-02-20 16:39:53 --> Security Class Initialized
DEBUG - 2017-02-20 16:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:39:53 --> Input Class Initialized
INFO - 2017-02-20 16:39:53 --> Language Class Initialized
INFO - 2017-02-20 16:39:53 --> Loader Class Initialized
INFO - 2017-02-20 16:39:53 --> Helper loaded: url_helper
INFO - 2017-02-20 16:39:53 --> Helper loaded: language_helper
INFO - 2017-02-20 16:39:53 --> Helper loaded: html_helper
INFO - 2017-02-20 16:39:53 --> Helper loaded: form_helper
INFO - 2017-02-20 16:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:39:53 --> Controller Class Initialized
INFO - 2017-02-20 16:39:53 --> Database Driver Class Initialized
INFO - 2017-02-20 16:39:53 --> Model Class Initialized
INFO - 2017-02-20 16:39:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:39:53 --> Final output sent to browser
DEBUG - 2017-02-20 16:39:53 --> Total execution time: 0.1479
INFO - 2017-02-20 16:49:06 --> Config Class Initialized
INFO - 2017-02-20 16:49:06 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:49:06 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:49:06 --> Utf8 Class Initialized
INFO - 2017-02-20 16:49:06 --> URI Class Initialized
INFO - 2017-02-20 16:49:06 --> Router Class Initialized
INFO - 2017-02-20 16:49:06 --> Output Class Initialized
INFO - 2017-02-20 16:49:06 --> Security Class Initialized
DEBUG - 2017-02-20 16:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:49:06 --> Input Class Initialized
INFO - 2017-02-20 16:49:06 --> Language Class Initialized
INFO - 2017-02-20 16:49:06 --> Loader Class Initialized
INFO - 2017-02-20 16:49:06 --> Helper loaded: url_helper
INFO - 2017-02-20 16:49:06 --> Helper loaded: language_helper
INFO - 2017-02-20 16:49:07 --> Helper loaded: html_helper
INFO - 2017-02-20 16:49:07 --> Helper loaded: form_helper
INFO - 2017-02-20 16:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:49:07 --> Controller Class Initialized
INFO - 2017-02-20 16:49:07 --> Database Driver Class Initialized
INFO - 2017-02-20 16:49:07 --> Model Class Initialized
INFO - 2017-02-20 16:49:07 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-02-20 16:49:07 --> Severity: Notice --> Undefined variable: inc C:\wamp64\www\savsoftquiz\application\models\Register_model.php 45
ERROR - 2017-02-20 16:49:07 --> Severity: Notice --> Undefined variable: awal C:\wamp64\www\savsoftquiz\application\models\Register_model.php 45
INFO - 2017-02-20 16:49:07 --> Final output sent to browser
DEBUG - 2017-02-20 16:49:07 --> Total execution time: 0.0939
INFO - 2017-02-20 16:49:50 --> Config Class Initialized
INFO - 2017-02-20 16:49:50 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:49:50 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:49:50 --> Utf8 Class Initialized
INFO - 2017-02-20 16:49:50 --> URI Class Initialized
INFO - 2017-02-20 16:49:50 --> Router Class Initialized
INFO - 2017-02-20 16:49:50 --> Output Class Initialized
INFO - 2017-02-20 16:49:50 --> Security Class Initialized
DEBUG - 2017-02-20 16:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:49:50 --> Input Class Initialized
INFO - 2017-02-20 16:49:50 --> Language Class Initialized
INFO - 2017-02-20 16:49:50 --> Loader Class Initialized
INFO - 2017-02-20 16:49:50 --> Helper loaded: url_helper
INFO - 2017-02-20 16:49:50 --> Helper loaded: language_helper
INFO - 2017-02-20 16:49:50 --> Helper loaded: html_helper
INFO - 2017-02-20 16:49:50 --> Helper loaded: form_helper
INFO - 2017-02-20 16:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:49:50 --> Controller Class Initialized
INFO - 2017-02-20 16:49:50 --> Database Driver Class Initialized
INFO - 2017-02-20 16:49:50 --> Model Class Initialized
INFO - 2017-02-20 16:49:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:49:50 --> Final output sent to browser
DEBUG - 2017-02-20 16:49:50 --> Total execution time: 0.1148
INFO - 2017-02-20 16:50:05 --> Config Class Initialized
INFO - 2017-02-20 16:50:05 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:50:05 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:50:05 --> Utf8 Class Initialized
INFO - 2017-02-20 16:50:05 --> URI Class Initialized
INFO - 2017-02-20 16:50:05 --> Router Class Initialized
INFO - 2017-02-20 16:50:05 --> Output Class Initialized
INFO - 2017-02-20 16:50:05 --> Security Class Initialized
DEBUG - 2017-02-20 16:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:50:05 --> Input Class Initialized
INFO - 2017-02-20 16:50:05 --> Language Class Initialized
INFO - 2017-02-20 16:50:05 --> Loader Class Initialized
INFO - 2017-02-20 16:50:05 --> Helper loaded: url_helper
INFO - 2017-02-20 16:50:05 --> Helper loaded: language_helper
INFO - 2017-02-20 16:50:05 --> Helper loaded: html_helper
INFO - 2017-02-20 16:50:05 --> Helper loaded: form_helper
INFO - 2017-02-20 16:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:50:05 --> Controller Class Initialized
INFO - 2017-02-20 16:50:05 --> Database Driver Class Initialized
INFO - 2017-02-20 16:50:05 --> Model Class Initialized
INFO - 2017-02-20 16:50:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:50:05 --> Final output sent to browser
DEBUG - 2017-02-20 16:50:05 --> Total execution time: 0.1253
INFO - 2017-02-20 16:50:20 --> Config Class Initialized
INFO - 2017-02-20 16:50:20 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:50:20 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:50:20 --> Utf8 Class Initialized
INFO - 2017-02-20 16:50:20 --> URI Class Initialized
INFO - 2017-02-20 16:50:20 --> Router Class Initialized
INFO - 2017-02-20 16:50:20 --> Output Class Initialized
INFO - 2017-02-20 16:50:20 --> Security Class Initialized
DEBUG - 2017-02-20 16:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:50:20 --> Input Class Initialized
INFO - 2017-02-20 16:50:20 --> Language Class Initialized
INFO - 2017-02-20 16:50:20 --> Loader Class Initialized
INFO - 2017-02-20 16:50:20 --> Helper loaded: url_helper
INFO - 2017-02-20 16:50:20 --> Helper loaded: language_helper
INFO - 2017-02-20 16:50:20 --> Helper loaded: html_helper
INFO - 2017-02-20 16:50:20 --> Helper loaded: form_helper
INFO - 2017-02-20 16:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:50:20 --> Controller Class Initialized
INFO - 2017-02-20 16:50:20 --> Database Driver Class Initialized
INFO - 2017-02-20 16:50:20 --> Model Class Initialized
INFO - 2017-02-20 16:50:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:50:20 --> Final output sent to browser
DEBUG - 2017-02-20 16:50:20 --> Total execution time: 0.1339
INFO - 2017-02-20 16:50:34 --> Config Class Initialized
INFO - 2017-02-20 16:50:34 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:50:34 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:50:34 --> Utf8 Class Initialized
INFO - 2017-02-20 16:50:34 --> URI Class Initialized
INFO - 2017-02-20 16:50:34 --> Router Class Initialized
INFO - 2017-02-20 16:50:34 --> Output Class Initialized
INFO - 2017-02-20 16:50:34 --> Security Class Initialized
DEBUG - 2017-02-20 16:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:50:34 --> Input Class Initialized
INFO - 2017-02-20 16:50:34 --> Language Class Initialized
INFO - 2017-02-20 16:50:34 --> Loader Class Initialized
INFO - 2017-02-20 16:50:34 --> Helper loaded: url_helper
INFO - 2017-02-20 16:50:34 --> Helper loaded: language_helper
INFO - 2017-02-20 16:50:34 --> Helper loaded: html_helper
INFO - 2017-02-20 16:50:34 --> Helper loaded: form_helper
INFO - 2017-02-20 16:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:50:34 --> Controller Class Initialized
INFO - 2017-02-20 16:50:34 --> Database Driver Class Initialized
INFO - 2017-02-20 16:50:34 --> Model Class Initialized
INFO - 2017-02-20 16:50:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:50:34 --> Final output sent to browser
DEBUG - 2017-02-20 16:50:34 --> Total execution time: 0.1252
INFO - 2017-02-20 16:50:42 --> Config Class Initialized
INFO - 2017-02-20 16:50:42 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:50:42 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:50:42 --> Utf8 Class Initialized
INFO - 2017-02-20 16:50:42 --> URI Class Initialized
INFO - 2017-02-20 16:50:42 --> Router Class Initialized
INFO - 2017-02-20 16:50:42 --> Output Class Initialized
INFO - 2017-02-20 16:50:42 --> Security Class Initialized
DEBUG - 2017-02-20 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:50:42 --> Input Class Initialized
INFO - 2017-02-20 16:50:42 --> Language Class Initialized
INFO - 2017-02-20 16:50:42 --> Loader Class Initialized
INFO - 2017-02-20 16:50:42 --> Helper loaded: url_helper
INFO - 2017-02-20 16:50:42 --> Helper loaded: language_helper
INFO - 2017-02-20 16:50:42 --> Helper loaded: html_helper
INFO - 2017-02-20 16:50:42 --> Helper loaded: form_helper
INFO - 2017-02-20 16:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:50:43 --> Controller Class Initialized
INFO - 2017-02-20 16:50:43 --> Database Driver Class Initialized
INFO - 2017-02-20 16:50:43 --> Model Class Initialized
INFO - 2017-02-20 16:50:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:50:43 --> Final output sent to browser
DEBUG - 2017-02-20 16:50:43 --> Total execution time: 0.1122
INFO - 2017-02-20 16:50:57 --> Config Class Initialized
INFO - 2017-02-20 16:50:57 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:50:57 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:50:57 --> Utf8 Class Initialized
INFO - 2017-02-20 16:50:57 --> URI Class Initialized
INFO - 2017-02-20 16:50:57 --> Router Class Initialized
INFO - 2017-02-20 16:50:57 --> Output Class Initialized
INFO - 2017-02-20 16:50:57 --> Security Class Initialized
DEBUG - 2017-02-20 16:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:50:57 --> Input Class Initialized
INFO - 2017-02-20 16:50:57 --> Language Class Initialized
INFO - 2017-02-20 16:50:57 --> Loader Class Initialized
INFO - 2017-02-20 16:50:57 --> Helper loaded: url_helper
INFO - 2017-02-20 16:50:57 --> Helper loaded: language_helper
INFO - 2017-02-20 16:50:57 --> Helper loaded: html_helper
INFO - 2017-02-20 16:50:57 --> Helper loaded: form_helper
INFO - 2017-02-20 16:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:50:57 --> Controller Class Initialized
INFO - 2017-02-20 16:50:57 --> Database Driver Class Initialized
INFO - 2017-02-20 16:50:57 --> Model Class Initialized
INFO - 2017-02-20 16:50:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:50:57 --> Final output sent to browser
DEBUG - 2017-02-20 16:50:57 --> Total execution time: 0.1249
INFO - 2017-02-20 16:52:19 --> Config Class Initialized
INFO - 2017-02-20 16:52:19 --> Hooks Class Initialized
DEBUG - 2017-02-20 16:52:19 --> UTF-8 Support Enabled
INFO - 2017-02-20 16:52:19 --> Utf8 Class Initialized
INFO - 2017-02-20 16:52:19 --> URI Class Initialized
INFO - 2017-02-20 16:52:19 --> Router Class Initialized
INFO - 2017-02-20 16:52:19 --> Output Class Initialized
INFO - 2017-02-20 16:52:19 --> Security Class Initialized
DEBUG - 2017-02-20 16:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 16:52:19 --> Input Class Initialized
INFO - 2017-02-20 16:52:19 --> Language Class Initialized
INFO - 2017-02-20 16:52:19 --> Loader Class Initialized
INFO - 2017-02-20 16:52:19 --> Helper loaded: url_helper
INFO - 2017-02-20 16:52:19 --> Helper loaded: language_helper
INFO - 2017-02-20 16:52:19 --> Helper loaded: html_helper
INFO - 2017-02-20 16:52:19 --> Helper loaded: form_helper
INFO - 2017-02-20 16:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 16:52:19 --> Controller Class Initialized
INFO - 2017-02-20 16:52:19 --> Database Driver Class Initialized
INFO - 2017-02-20 16:52:19 --> Model Class Initialized
INFO - 2017-02-20 16:52:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 16:52:19 --> Final output sent to browser
DEBUG - 2017-02-20 16:52:19 --> Total execution time: 0.1230
INFO - 2017-02-20 21:33:42 --> Config Class Initialized
INFO - 2017-02-20 21:33:42 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:33:42 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:33:42 --> Utf8 Class Initialized
INFO - 2017-02-20 21:33:42 --> URI Class Initialized
INFO - 2017-02-20 21:33:42 --> Router Class Initialized
INFO - 2017-02-20 21:33:42 --> Output Class Initialized
INFO - 2017-02-20 21:33:42 --> Security Class Initialized
DEBUG - 2017-02-20 21:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:33:42 --> Input Class Initialized
INFO - 2017-02-20 21:33:42 --> Language Class Initialized
INFO - 2017-02-20 21:33:42 --> Loader Class Initialized
INFO - 2017-02-20 21:33:42 --> Helper loaded: url_helper
INFO - 2017-02-20 21:33:42 --> Helper loaded: language_helper
INFO - 2017-02-20 21:33:42 --> Helper loaded: html_helper
INFO - 2017-02-20 21:33:42 --> Helper loaded: form_helper
INFO - 2017-02-20 21:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:33:42 --> Controller Class Initialized
INFO - 2017-02-20 21:33:42 --> Database Driver Class Initialized
INFO - 2017-02-20 21:33:42 --> Model Class Initialized
INFO - 2017-02-20 21:33:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:33:42 --> Form Validation Class Initialized
INFO - 2017-02-20 21:33:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 21:33:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-20 21:33:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 21:33:42 --> Final output sent to browser
DEBUG - 2017-02-20 21:33:42 --> Total execution time: 0.1469
INFO - 2017-02-20 21:35:54 --> Config Class Initialized
INFO - 2017-02-20 21:35:54 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:35:54 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:35:54 --> Utf8 Class Initialized
INFO - 2017-02-20 21:35:54 --> URI Class Initialized
INFO - 2017-02-20 21:35:54 --> Router Class Initialized
INFO - 2017-02-20 21:35:54 --> Output Class Initialized
INFO - 2017-02-20 21:35:54 --> Security Class Initialized
DEBUG - 2017-02-20 21:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:35:54 --> Input Class Initialized
INFO - 2017-02-20 21:35:54 --> Language Class Initialized
INFO - 2017-02-20 21:35:54 --> Loader Class Initialized
INFO - 2017-02-20 21:35:54 --> Helper loaded: url_helper
INFO - 2017-02-20 21:35:54 --> Helper loaded: language_helper
INFO - 2017-02-20 21:35:54 --> Helper loaded: html_helper
INFO - 2017-02-20 21:35:54 --> Helper loaded: form_helper
INFO - 2017-02-20 21:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:35:54 --> Controller Class Initialized
INFO - 2017-02-20 21:35:54 --> Database Driver Class Initialized
INFO - 2017-02-20 21:35:54 --> Model Class Initialized
INFO - 2017-02-20 21:35:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:35:54 --> Form Validation Class Initialized
INFO - 2017-02-20 21:35:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 21:35:54 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-20 21:35:54 --> Email Class Initialized
ERROR - 2017-02-20 21:35:55 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1845
INFO - 2017-02-20 21:35:55 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-20 21:46:46 --> Config Class Initialized
INFO - 2017-02-20 21:46:46 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:46:46 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:46:46 --> Utf8 Class Initialized
INFO - 2017-02-20 21:46:46 --> URI Class Initialized
INFO - 2017-02-20 21:46:46 --> Router Class Initialized
INFO - 2017-02-20 21:46:46 --> Output Class Initialized
INFO - 2017-02-20 21:46:46 --> Security Class Initialized
DEBUG - 2017-02-20 21:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:46:46 --> Input Class Initialized
INFO - 2017-02-20 21:46:46 --> Language Class Initialized
INFO - 2017-02-20 21:46:46 --> Loader Class Initialized
INFO - 2017-02-20 21:46:46 --> Helper loaded: url_helper
INFO - 2017-02-20 21:46:46 --> Helper loaded: language_helper
INFO - 2017-02-20 21:46:46 --> Helper loaded: html_helper
INFO - 2017-02-20 21:46:46 --> Helper loaded: form_helper
INFO - 2017-02-20 21:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:46:46 --> Controller Class Initialized
INFO - 2017-02-20 21:46:46 --> Database Driver Class Initialized
INFO - 2017-02-20 21:46:46 --> Model Class Initialized
INFO - 2017-02-20 21:46:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:46:46 --> Email Class Initialized
ERROR - 2017-02-20 21:46:47 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-20 21:46:47 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-20 21:46:47 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-20 21:46:47 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-20 21:46:47 --> Final output sent to browser
DEBUG - 2017-02-20 21:46:47 --> Total execution time: 1.3809
INFO - 2017-02-20 21:48:07 --> Config Class Initialized
INFO - 2017-02-20 21:48:07 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:48:07 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:48:07 --> Utf8 Class Initialized
INFO - 2017-02-20 21:48:07 --> URI Class Initialized
INFO - 2017-02-20 21:48:07 --> Router Class Initialized
INFO - 2017-02-20 21:48:07 --> Output Class Initialized
INFO - 2017-02-20 21:48:07 --> Security Class Initialized
DEBUG - 2017-02-20 21:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:48:07 --> Input Class Initialized
INFO - 2017-02-20 21:48:07 --> Language Class Initialized
INFO - 2017-02-20 21:48:07 --> Loader Class Initialized
INFO - 2017-02-20 21:48:07 --> Helper loaded: url_helper
INFO - 2017-02-20 21:48:07 --> Helper loaded: language_helper
INFO - 2017-02-20 21:48:07 --> Helper loaded: html_helper
INFO - 2017-02-20 21:48:07 --> Helper loaded: form_helper
INFO - 2017-02-20 21:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:48:07 --> Controller Class Initialized
INFO - 2017-02-20 21:48:07 --> Database Driver Class Initialized
INFO - 2017-02-20 21:48:07 --> Model Class Initialized
INFO - 2017-02-20 21:48:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:48:07 --> Email Class Initialized
ERROR - 2017-02-20 21:48:07 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-20 21:48:07 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-20 21:48:07 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-20 21:48:07 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-20 21:48:07 --> Final output sent to browser
DEBUG - 2017-02-20 21:48:07 --> Total execution time: 0.2629
INFO - 2017-02-20 21:48:23 --> Config Class Initialized
INFO - 2017-02-20 21:48:23 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:48:23 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:48:23 --> Utf8 Class Initialized
INFO - 2017-02-20 21:48:23 --> URI Class Initialized
INFO - 2017-02-20 21:48:23 --> Router Class Initialized
INFO - 2017-02-20 21:48:23 --> Output Class Initialized
INFO - 2017-02-20 21:48:23 --> Security Class Initialized
DEBUG - 2017-02-20 21:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:48:23 --> Input Class Initialized
INFO - 2017-02-20 21:48:23 --> Language Class Initialized
INFO - 2017-02-20 21:48:23 --> Loader Class Initialized
INFO - 2017-02-20 21:48:23 --> Helper loaded: url_helper
INFO - 2017-02-20 21:48:23 --> Helper loaded: language_helper
INFO - 2017-02-20 21:48:23 --> Helper loaded: html_helper
INFO - 2017-02-20 21:48:23 --> Helper loaded: form_helper
INFO - 2017-02-20 21:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:48:23 --> Controller Class Initialized
INFO - 2017-02-20 21:48:23 --> Database Driver Class Initialized
INFO - 2017-02-20 21:48:23 --> Model Class Initialized
INFO - 2017-02-20 21:48:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:48:23 --> Email Class Initialized
ERROR - 2017-02-20 21:48:23 --> Severity: Warning --> fsockopen(): SSL: An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-20 21:48:23 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-20 21:48:23 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:587 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-20 21:48:23 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-20 21:48:23 --> Final output sent to browser
DEBUG - 2017-02-20 21:48:23 --> Total execution time: 0.2943
INFO - 2017-02-20 21:53:08 --> Config Class Initialized
INFO - 2017-02-20 21:53:08 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:53:08 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:53:08 --> Utf8 Class Initialized
INFO - 2017-02-20 21:53:08 --> URI Class Initialized
INFO - 2017-02-20 21:53:08 --> Router Class Initialized
INFO - 2017-02-20 21:53:08 --> Output Class Initialized
INFO - 2017-02-20 21:53:08 --> Security Class Initialized
DEBUG - 2017-02-20 21:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:53:08 --> Input Class Initialized
INFO - 2017-02-20 21:53:08 --> Language Class Initialized
INFO - 2017-02-20 21:53:08 --> Loader Class Initialized
INFO - 2017-02-20 21:53:08 --> Helper loaded: url_helper
INFO - 2017-02-20 21:53:08 --> Helper loaded: language_helper
INFO - 2017-02-20 21:53:08 --> Helper loaded: html_helper
INFO - 2017-02-20 21:53:08 --> Helper loaded: form_helper
INFO - 2017-02-20 21:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:53:08 --> Controller Class Initialized
INFO - 2017-02-20 21:53:08 --> Database Driver Class Initialized
INFO - 2017-02-20 21:53:08 --> Model Class Initialized
INFO - 2017-02-20 21:53:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:53:08 --> Email Class Initialized
ERROR - 2017-02-20 21:53:09 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:140770FC:SSL routines:SSL23_GET_SERVER_HELLO:unknown protocol C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-20 21:53:09 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-20 21:53:09 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:587 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-20 21:53:09 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-20 21:53:09 --> Final output sent to browser
DEBUG - 2017-02-20 21:53:09 --> Total execution time: 1.1830
INFO - 2017-02-20 21:53:28 --> Config Class Initialized
INFO - 2017-02-20 21:53:28 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:53:28 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:53:28 --> Utf8 Class Initialized
INFO - 2017-02-20 21:53:28 --> URI Class Initialized
INFO - 2017-02-20 21:53:28 --> Router Class Initialized
INFO - 2017-02-20 21:53:28 --> Output Class Initialized
INFO - 2017-02-20 21:53:28 --> Security Class Initialized
DEBUG - 2017-02-20 21:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:53:28 --> Input Class Initialized
INFO - 2017-02-20 21:53:28 --> Language Class Initialized
INFO - 2017-02-20 21:53:28 --> Loader Class Initialized
INFO - 2017-02-20 21:53:28 --> Helper loaded: url_helper
INFO - 2017-02-20 21:53:28 --> Helper loaded: language_helper
INFO - 2017-02-20 21:53:28 --> Helper loaded: html_helper
INFO - 2017-02-20 21:53:28 --> Helper loaded: form_helper
INFO - 2017-02-20 21:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:53:28 --> Controller Class Initialized
INFO - 2017-02-20 21:53:28 --> Database Driver Class Initialized
INFO - 2017-02-20 21:53:28 --> Model Class Initialized
INFO - 2017-02-20 21:53:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:53:28 --> Email Class Initialized
INFO - 2017-02-20 21:53:28 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-20 21:53:29 --> Final output sent to browser
DEBUG - 2017-02-20 21:53:29 --> Total execution time: 0.7188
INFO - 2017-02-20 21:54:42 --> Config Class Initialized
INFO - 2017-02-20 21:54:42 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:54:42 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:54:42 --> Utf8 Class Initialized
INFO - 2017-02-20 21:54:42 --> URI Class Initialized
INFO - 2017-02-20 21:54:42 --> Router Class Initialized
INFO - 2017-02-20 21:54:42 --> Output Class Initialized
INFO - 2017-02-20 21:54:42 --> Security Class Initialized
DEBUG - 2017-02-20 21:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:54:42 --> Input Class Initialized
INFO - 2017-02-20 21:54:42 --> Language Class Initialized
INFO - 2017-02-20 21:54:42 --> Loader Class Initialized
INFO - 2017-02-20 21:54:42 --> Helper loaded: url_helper
INFO - 2017-02-20 21:54:42 --> Helper loaded: language_helper
INFO - 2017-02-20 21:54:42 --> Helper loaded: html_helper
INFO - 2017-02-20 21:54:42 --> Helper loaded: form_helper
INFO - 2017-02-20 21:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:54:42 --> Controller Class Initialized
INFO - 2017-02-20 21:54:42 --> Database Driver Class Initialized
INFO - 2017-02-20 21:54:42 --> Model Class Initialized
INFO - 2017-02-20 21:54:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:54:42 --> Email Class Initialized
INFO - 2017-02-20 21:54:43 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-20 21:58:00 --> Config Class Initialized
INFO - 2017-02-20 21:58:00 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:58:00 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:58:00 --> Utf8 Class Initialized
INFO - 2017-02-20 21:58:00 --> URI Class Initialized
INFO - 2017-02-20 21:58:00 --> Router Class Initialized
INFO - 2017-02-20 21:58:00 --> Output Class Initialized
INFO - 2017-02-20 21:58:00 --> Security Class Initialized
DEBUG - 2017-02-20 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:58:00 --> Input Class Initialized
INFO - 2017-02-20 21:58:00 --> Language Class Initialized
INFO - 2017-02-20 21:58:00 --> Loader Class Initialized
INFO - 2017-02-20 21:58:00 --> Helper loaded: url_helper
INFO - 2017-02-20 21:58:00 --> Helper loaded: language_helper
INFO - 2017-02-20 21:58:00 --> Helper loaded: html_helper
INFO - 2017-02-20 21:58:00 --> Helper loaded: form_helper
INFO - 2017-02-20 21:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:58:00 --> Controller Class Initialized
INFO - 2017-02-20 21:58:00 --> Database Driver Class Initialized
INFO - 2017-02-20 21:58:00 --> Model Class Initialized
INFO - 2017-02-20 21:58:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:58:00 --> Email Class Initialized
INFO - 2017-02-20 21:58:05 --> Language file loaded: language/indonesia/email_lang.php
ERROR - 2017-02-20 21:58:05 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:05 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:05 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:58:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
INFO - 2017-02-20 21:59:28 --> Config Class Initialized
INFO - 2017-02-20 21:59:28 --> Hooks Class Initialized
DEBUG - 2017-02-20 21:59:28 --> UTF-8 Support Enabled
INFO - 2017-02-20 21:59:28 --> Utf8 Class Initialized
INFO - 2017-02-20 21:59:28 --> URI Class Initialized
INFO - 2017-02-20 21:59:28 --> Router Class Initialized
INFO - 2017-02-20 21:59:28 --> Output Class Initialized
INFO - 2017-02-20 21:59:28 --> Security Class Initialized
DEBUG - 2017-02-20 21:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 21:59:28 --> Input Class Initialized
INFO - 2017-02-20 21:59:28 --> Language Class Initialized
INFO - 2017-02-20 21:59:28 --> Loader Class Initialized
INFO - 2017-02-20 21:59:28 --> Helper loaded: url_helper
INFO - 2017-02-20 21:59:28 --> Helper loaded: language_helper
INFO - 2017-02-20 21:59:28 --> Helper loaded: html_helper
INFO - 2017-02-20 21:59:28 --> Helper loaded: form_helper
INFO - 2017-02-20 21:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 21:59:28 --> Controller Class Initialized
INFO - 2017-02-20 21:59:28 --> Database Driver Class Initialized
INFO - 2017-02-20 21:59:28 --> Model Class Initialized
INFO - 2017-02-20 21:59:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 21:59:28 --> Email Class Initialized
INFO - 2017-02-20 21:59:33 --> Language file loaded: language/indonesia/email_lang.php
ERROR - 2017-02-20 21:59:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:36 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:37 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:37 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:37 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:37 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:38 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:38 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:38 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:38 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 21:59:39 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
INFO - 2017-02-20 22:10:08 --> Config Class Initialized
INFO - 2017-02-20 22:10:08 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:10:08 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:10:08 --> Utf8 Class Initialized
INFO - 2017-02-20 22:10:08 --> URI Class Initialized
INFO - 2017-02-20 22:10:08 --> Router Class Initialized
INFO - 2017-02-20 22:10:08 --> Output Class Initialized
INFO - 2017-02-20 22:10:08 --> Security Class Initialized
DEBUG - 2017-02-20 22:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:10:08 --> Input Class Initialized
INFO - 2017-02-20 22:10:08 --> Language Class Initialized
INFO - 2017-02-20 22:10:08 --> Loader Class Initialized
INFO - 2017-02-20 22:10:08 --> Helper loaded: url_helper
INFO - 2017-02-20 22:10:08 --> Helper loaded: language_helper
INFO - 2017-02-20 22:10:08 --> Helper loaded: html_helper
INFO - 2017-02-20 22:10:08 --> Helper loaded: form_helper
INFO - 2017-02-20 22:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:10:08 --> Controller Class Initialized
INFO - 2017-02-20 22:10:08 --> Database Driver Class Initialized
INFO - 2017-02-20 22:10:08 --> Model Class Initialized
INFO - 2017-02-20 22:10:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:10:08 --> Email Class Initialized
INFO - 2017-02-20 22:10:13 --> Language file loaded: language/indonesia/email_lang.php
ERROR - 2017-02-20 22:10:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:13 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:14 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:15 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:16 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:17 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:18 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:18 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:18 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:18 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:10:19 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
INFO - 2017-02-20 22:24:00 --> Config Class Initialized
INFO - 2017-02-20 22:24:00 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:24:00 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:24:00 --> Utf8 Class Initialized
INFO - 2017-02-20 22:24:00 --> URI Class Initialized
INFO - 2017-02-20 22:24:00 --> Router Class Initialized
INFO - 2017-02-20 22:24:00 --> Output Class Initialized
INFO - 2017-02-20 22:24:00 --> Security Class Initialized
DEBUG - 2017-02-20 22:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:24:00 --> Input Class Initialized
INFO - 2017-02-20 22:24:00 --> Language Class Initialized
INFO - 2017-02-20 22:24:00 --> Loader Class Initialized
INFO - 2017-02-20 22:24:00 --> Helper loaded: url_helper
INFO - 2017-02-20 22:24:00 --> Helper loaded: language_helper
INFO - 2017-02-20 22:24:00 --> Helper loaded: html_helper
INFO - 2017-02-20 22:24:00 --> Helper loaded: form_helper
INFO - 2017-02-20 22:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:24:00 --> Controller Class Initialized
INFO - 2017-02-20 22:24:00 --> Database Driver Class Initialized
INFO - 2017-02-20 22:24:00 --> Model Class Initialized
INFO - 2017-02-20 22:24:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:24:00 --> Email Class Initialized
INFO - 2017-02-20 22:24:06 --> Language file loaded: language/indonesia/email_lang.php
ERROR - 2017-02-20 22:24:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:06 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:07 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:08 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:09 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:10 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:11 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
ERROR - 2017-02-20 22:24:12 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 C:\wamp64\www\savsoftquiz\system\libraries\Email.php 2172
INFO - 2017-02-20 22:26:03 --> Config Class Initialized
INFO - 2017-02-20 22:26:03 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:26:03 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:26:03 --> Utf8 Class Initialized
INFO - 2017-02-20 22:26:03 --> URI Class Initialized
INFO - 2017-02-20 22:26:03 --> Router Class Initialized
INFO - 2017-02-20 22:26:03 --> Output Class Initialized
INFO - 2017-02-20 22:26:03 --> Security Class Initialized
DEBUG - 2017-02-20 22:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:26:03 --> Input Class Initialized
INFO - 2017-02-20 22:26:03 --> Language Class Initialized
INFO - 2017-02-20 22:26:03 --> Loader Class Initialized
INFO - 2017-02-20 22:26:03 --> Helper loaded: url_helper
INFO - 2017-02-20 22:26:03 --> Helper loaded: language_helper
INFO - 2017-02-20 22:26:03 --> Helper loaded: html_helper
INFO - 2017-02-20 22:26:03 --> Helper loaded: form_helper
INFO - 2017-02-20 22:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:26:03 --> Controller Class Initialized
INFO - 2017-02-20 22:26:03 --> Database Driver Class Initialized
INFO - 2017-02-20 22:26:03 --> Model Class Initialized
INFO - 2017-02-20 22:26:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:26:08 --> Final output sent to browser
DEBUG - 2017-02-20 22:26:08 --> Total execution time: 5.5343
INFO - 2017-02-20 22:29:50 --> Config Class Initialized
INFO - 2017-02-20 22:29:50 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:29:50 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:29:50 --> Utf8 Class Initialized
INFO - 2017-02-20 22:29:50 --> URI Class Initialized
INFO - 2017-02-20 22:29:50 --> Router Class Initialized
INFO - 2017-02-20 22:29:50 --> Output Class Initialized
INFO - 2017-02-20 22:29:50 --> Security Class Initialized
DEBUG - 2017-02-20 22:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:29:50 --> Input Class Initialized
INFO - 2017-02-20 22:29:50 --> Language Class Initialized
INFO - 2017-02-20 22:29:50 --> Loader Class Initialized
INFO - 2017-02-20 22:29:50 --> Helper loaded: url_helper
INFO - 2017-02-20 22:29:50 --> Helper loaded: language_helper
INFO - 2017-02-20 22:29:50 --> Helper loaded: html_helper
INFO - 2017-02-20 22:29:50 --> Helper loaded: form_helper
INFO - 2017-02-20 22:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:29:50 --> Controller Class Initialized
INFO - 2017-02-20 22:29:50 --> Database Driver Class Initialized
INFO - 2017-02-20 22:29:50 --> Model Class Initialized
INFO - 2017-02-20 22:29:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:29:50 --> Form Validation Class Initialized
INFO - 2017-02-20 22:29:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:29:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-20 22:29:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:29:50 --> Final output sent to browser
DEBUG - 2017-02-20 22:29:50 --> Total execution time: 0.1136
INFO - 2017-02-20 22:30:53 --> Config Class Initialized
INFO - 2017-02-20 22:30:53 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:30:53 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:30:53 --> Utf8 Class Initialized
INFO - 2017-02-20 22:30:53 --> URI Class Initialized
INFO - 2017-02-20 22:30:53 --> Router Class Initialized
INFO - 2017-02-20 22:30:53 --> Output Class Initialized
INFO - 2017-02-20 22:30:53 --> Security Class Initialized
DEBUG - 2017-02-20 22:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:30:53 --> Input Class Initialized
INFO - 2017-02-20 22:30:53 --> Language Class Initialized
INFO - 2017-02-20 22:30:53 --> Loader Class Initialized
INFO - 2017-02-20 22:30:53 --> Helper loaded: url_helper
INFO - 2017-02-20 22:30:53 --> Helper loaded: language_helper
INFO - 2017-02-20 22:30:53 --> Helper loaded: html_helper
INFO - 2017-02-20 22:30:53 --> Helper loaded: form_helper
INFO - 2017-02-20 22:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:30:53 --> Controller Class Initialized
INFO - 2017-02-20 22:30:53 --> Database Driver Class Initialized
INFO - 2017-02-20 22:30:53 --> Model Class Initialized
INFO - 2017-02-20 22:30:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:30:53 --> Form Validation Class Initialized
INFO - 2017-02-20 22:30:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:30:53 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-20 22:30:53 --> Email Class Initialized
INFO - 2017-02-20 22:30:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-20 22:30:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:30:58 --> Final output sent to browser
DEBUG - 2017-02-20 22:30:58 --> Total execution time: 5.2628
INFO - 2017-02-20 22:32:42 --> Config Class Initialized
INFO - 2017-02-20 22:32:42 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:32:42 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:32:42 --> Utf8 Class Initialized
INFO - 2017-02-20 22:32:42 --> URI Class Initialized
INFO - 2017-02-20 22:32:42 --> Router Class Initialized
INFO - 2017-02-20 22:32:42 --> Output Class Initialized
INFO - 2017-02-20 22:32:42 --> Security Class Initialized
DEBUG - 2017-02-20 22:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:32:42 --> Input Class Initialized
INFO - 2017-02-20 22:32:42 --> Language Class Initialized
INFO - 2017-02-20 22:32:42 --> Loader Class Initialized
INFO - 2017-02-20 22:32:42 --> Helper loaded: url_helper
INFO - 2017-02-20 22:32:42 --> Helper loaded: language_helper
INFO - 2017-02-20 22:32:42 --> Helper loaded: html_helper
INFO - 2017-02-20 22:32:42 --> Helper loaded: form_helper
INFO - 2017-02-20 22:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:32:42 --> Controller Class Initialized
INFO - 2017-02-20 22:32:42 --> Database Driver Class Initialized
INFO - 2017-02-20 22:32:42 --> Model Class Initialized
INFO - 2017-02-20 22:32:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:32:42 --> Form Validation Class Initialized
INFO - 2017-02-20 22:32:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:32:42 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-20 22:32:42 --> Email Class Initialized
INFO - 2017-02-20 22:32:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-20 22:32:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:32:47 --> Final output sent to browser
DEBUG - 2017-02-20 22:32:47 --> Total execution time: 5.0797
INFO - 2017-02-20 22:40:43 --> Config Class Initialized
INFO - 2017-02-20 22:40:43 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:40:43 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:40:43 --> Utf8 Class Initialized
INFO - 2017-02-20 22:40:43 --> URI Class Initialized
INFO - 2017-02-20 22:40:43 --> Router Class Initialized
INFO - 2017-02-20 22:40:43 --> Output Class Initialized
INFO - 2017-02-20 22:40:43 --> Security Class Initialized
DEBUG - 2017-02-20 22:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:40:43 --> Input Class Initialized
INFO - 2017-02-20 22:40:43 --> Language Class Initialized
INFO - 2017-02-20 22:40:43 --> Loader Class Initialized
INFO - 2017-02-20 22:40:43 --> Helper loaded: url_helper
INFO - 2017-02-20 22:40:43 --> Helper loaded: language_helper
INFO - 2017-02-20 22:40:43 --> Helper loaded: html_helper
INFO - 2017-02-20 22:40:43 --> Helper loaded: form_helper
INFO - 2017-02-20 22:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:40:43 --> Controller Class Initialized
INFO - 2017-02-20 22:40:43 --> Database Driver Class Initialized
INFO - 2017-02-20 22:40:43 --> Model Class Initialized
INFO - 2017-02-20 22:40:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:40:43 --> Form Validation Class Initialized
INFO - 2017-02-20 22:40:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:40:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-20 22:40:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:40:43 --> Final output sent to browser
DEBUG - 2017-02-20 22:40:43 --> Total execution time: 0.1093
INFO - 2017-02-20 22:42:02 --> Config Class Initialized
INFO - 2017-02-20 22:42:02 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:42:02 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:42:02 --> Utf8 Class Initialized
INFO - 2017-02-20 22:42:02 --> URI Class Initialized
INFO - 2017-02-20 22:42:02 --> Router Class Initialized
INFO - 2017-02-20 22:42:02 --> Output Class Initialized
INFO - 2017-02-20 22:42:02 --> Security Class Initialized
DEBUG - 2017-02-20 22:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:42:02 --> Input Class Initialized
INFO - 2017-02-20 22:42:02 --> Language Class Initialized
INFO - 2017-02-20 22:42:02 --> Loader Class Initialized
INFO - 2017-02-20 22:42:02 --> Helper loaded: url_helper
INFO - 2017-02-20 22:42:02 --> Helper loaded: language_helper
INFO - 2017-02-20 22:42:02 --> Helper loaded: html_helper
INFO - 2017-02-20 22:42:02 --> Helper loaded: form_helper
INFO - 2017-02-20 22:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:42:02 --> Controller Class Initialized
INFO - 2017-02-20 22:42:02 --> Database Driver Class Initialized
INFO - 2017-02-20 22:42:02 --> Model Class Initialized
INFO - 2017-02-20 22:42:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:42:02 --> Form Validation Class Initialized
INFO - 2017-02-20 22:42:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:42:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-20 22:42:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:42:02 --> Final output sent to browser
DEBUG - 2017-02-20 22:42:02 --> Total execution time: 0.1591
INFO - 2017-02-20 22:43:19 --> Config Class Initialized
INFO - 2017-02-20 22:43:19 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:43:19 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:43:19 --> Utf8 Class Initialized
INFO - 2017-02-20 22:43:19 --> URI Class Initialized
INFO - 2017-02-20 22:43:19 --> Router Class Initialized
INFO - 2017-02-20 22:43:19 --> Output Class Initialized
INFO - 2017-02-20 22:43:19 --> Security Class Initialized
DEBUG - 2017-02-20 22:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:43:19 --> Input Class Initialized
INFO - 2017-02-20 22:43:19 --> Language Class Initialized
INFO - 2017-02-20 22:43:19 --> Loader Class Initialized
INFO - 2017-02-20 22:43:19 --> Helper loaded: url_helper
INFO - 2017-02-20 22:43:19 --> Helper loaded: language_helper
INFO - 2017-02-20 22:43:19 --> Helper loaded: html_helper
INFO - 2017-02-20 22:43:19 --> Helper loaded: form_helper
INFO - 2017-02-20 22:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:43:19 --> Controller Class Initialized
INFO - 2017-02-20 22:43:19 --> Database Driver Class Initialized
INFO - 2017-02-20 22:43:19 --> Model Class Initialized
INFO - 2017-02-20 22:43:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:43:19 --> Form Validation Class Initialized
INFO - 2017-02-20 22:43:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:43:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-20 22:43:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:43:19 --> Final output sent to browser
DEBUG - 2017-02-20 22:43:19 --> Total execution time: 0.1259
INFO - 2017-02-20 22:43:30 --> Config Class Initialized
INFO - 2017-02-20 22:43:30 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:43:30 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:43:30 --> Utf8 Class Initialized
INFO - 2017-02-20 22:43:30 --> URI Class Initialized
INFO - 2017-02-20 22:43:30 --> Router Class Initialized
INFO - 2017-02-20 22:43:30 --> Output Class Initialized
INFO - 2017-02-20 22:43:30 --> Security Class Initialized
DEBUG - 2017-02-20 22:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:43:30 --> Input Class Initialized
INFO - 2017-02-20 22:43:30 --> Language Class Initialized
INFO - 2017-02-20 22:43:30 --> Loader Class Initialized
INFO - 2017-02-20 22:43:30 --> Helper loaded: url_helper
INFO - 2017-02-20 22:43:30 --> Helper loaded: language_helper
INFO - 2017-02-20 22:43:30 --> Helper loaded: html_helper
INFO - 2017-02-20 22:43:30 --> Helper loaded: form_helper
INFO - 2017-02-20 22:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:43:30 --> Controller Class Initialized
INFO - 2017-02-20 22:43:30 --> Database Driver Class Initialized
INFO - 2017-02-20 22:43:30 --> Model Class Initialized
INFO - 2017-02-20 22:43:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:43:30 --> Form Validation Class Initialized
INFO - 2017-02-20 22:43:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:43:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-20 22:43:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:43:30 --> Final output sent to browser
DEBUG - 2017-02-20 22:43:30 --> Total execution time: 0.1432
INFO - 2017-02-20 22:43:33 --> Config Class Initialized
INFO - 2017-02-20 22:43:33 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:43:33 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:43:33 --> Utf8 Class Initialized
INFO - 2017-02-20 22:43:33 --> URI Class Initialized
DEBUG - 2017-02-20 22:43:33 --> No URI present. Default controller set.
INFO - 2017-02-20 22:43:33 --> Router Class Initialized
INFO - 2017-02-20 22:43:33 --> Output Class Initialized
INFO - 2017-02-20 22:43:33 --> Security Class Initialized
DEBUG - 2017-02-20 22:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:43:33 --> Input Class Initialized
INFO - 2017-02-20 22:43:33 --> Language Class Initialized
INFO - 2017-02-20 22:43:33 --> Loader Class Initialized
INFO - 2017-02-20 22:43:33 --> Helper loaded: url_helper
INFO - 2017-02-20 22:43:33 --> Helper loaded: language_helper
INFO - 2017-02-20 22:43:33 --> Helper loaded: html_helper
INFO - 2017-02-20 22:43:33 --> Helper loaded: form_helper
INFO - 2017-02-20 22:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:43:33 --> Controller Class Initialized
INFO - 2017-02-20 22:43:33 --> Database Driver Class Initialized
INFO - 2017-02-20 22:43:33 --> Model Class Initialized
INFO - 2017-02-20 22:43:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:43:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:43:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:43:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:43:33 --> Final output sent to browser
DEBUG - 2017-02-20 22:43:33 --> Total execution time: 0.0969
INFO - 2017-02-20 22:46:51 --> Config Class Initialized
INFO - 2017-02-20 22:46:51 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:46:51 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:46:51 --> Utf8 Class Initialized
INFO - 2017-02-20 22:46:51 --> URI Class Initialized
DEBUG - 2017-02-20 22:46:51 --> No URI present. Default controller set.
INFO - 2017-02-20 22:46:51 --> Router Class Initialized
INFO - 2017-02-20 22:46:51 --> Output Class Initialized
INFO - 2017-02-20 22:46:51 --> Security Class Initialized
DEBUG - 2017-02-20 22:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:46:51 --> Input Class Initialized
INFO - 2017-02-20 22:46:51 --> Language Class Initialized
INFO - 2017-02-20 22:46:51 --> Loader Class Initialized
INFO - 2017-02-20 22:46:51 --> Helper loaded: url_helper
INFO - 2017-02-20 22:46:51 --> Helper loaded: language_helper
INFO - 2017-02-20 22:46:51 --> Helper loaded: html_helper
INFO - 2017-02-20 22:46:51 --> Helper loaded: form_helper
INFO - 2017-02-20 22:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:46:51 --> Controller Class Initialized
INFO - 2017-02-20 22:46:51 --> Database Driver Class Initialized
INFO - 2017-02-20 22:46:51 --> Model Class Initialized
INFO - 2017-02-20 22:46:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:46:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
ERROR - 2017-02-20 22:46:51 --> Could not find the language line "register"
INFO - 2017-02-20 22:46:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:46:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:46:51 --> Final output sent to browser
DEBUG - 2017-02-20 22:46:51 --> Total execution time: 0.1359
INFO - 2017-02-20 22:47:08 --> Config Class Initialized
INFO - 2017-02-20 22:47:08 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:47:08 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:47:08 --> Utf8 Class Initialized
INFO - 2017-02-20 22:47:08 --> URI Class Initialized
DEBUG - 2017-02-20 22:47:08 --> No URI present. Default controller set.
INFO - 2017-02-20 22:47:08 --> Router Class Initialized
INFO - 2017-02-20 22:47:08 --> Output Class Initialized
INFO - 2017-02-20 22:47:08 --> Security Class Initialized
DEBUG - 2017-02-20 22:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:47:08 --> Input Class Initialized
INFO - 2017-02-20 22:47:08 --> Language Class Initialized
INFO - 2017-02-20 22:47:08 --> Loader Class Initialized
INFO - 2017-02-20 22:47:08 --> Helper loaded: url_helper
INFO - 2017-02-20 22:47:08 --> Helper loaded: language_helper
INFO - 2017-02-20 22:47:08 --> Helper loaded: html_helper
INFO - 2017-02-20 22:47:08 --> Helper loaded: form_helper
INFO - 2017-02-20 22:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:47:08 --> Controller Class Initialized
INFO - 2017-02-20 22:47:08 --> Database Driver Class Initialized
INFO - 2017-02-20 22:47:09 --> Model Class Initialized
INFO - 2017-02-20 22:47:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:47:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:47:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:47:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:47:09 --> Final output sent to browser
DEBUG - 2017-02-20 22:47:09 --> Total execution time: 0.1327
INFO - 2017-02-20 22:47:13 --> Config Class Initialized
INFO - 2017-02-20 22:47:13 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:47:13 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:47:13 --> Utf8 Class Initialized
INFO - 2017-02-20 22:47:13 --> URI Class Initialized
INFO - 2017-02-20 22:47:13 --> Router Class Initialized
INFO - 2017-02-20 22:47:13 --> Output Class Initialized
INFO - 2017-02-20 22:47:13 --> Security Class Initialized
DEBUG - 2017-02-20 22:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:47:13 --> Input Class Initialized
INFO - 2017-02-20 22:47:13 --> Language Class Initialized
INFO - 2017-02-20 22:47:13 --> Loader Class Initialized
INFO - 2017-02-20 22:47:13 --> Helper loaded: url_helper
INFO - 2017-02-20 22:47:13 --> Helper loaded: language_helper
INFO - 2017-02-20 22:47:13 --> Helper loaded: html_helper
INFO - 2017-02-20 22:47:13 --> Helper loaded: form_helper
INFO - 2017-02-20 22:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:47:13 --> Controller Class Initialized
INFO - 2017-02-20 22:47:13 --> Database Driver Class Initialized
INFO - 2017-02-20 22:47:13 --> Model Class Initialized
INFO - 2017-02-20 22:47:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:47:13 --> Form Validation Class Initialized
INFO - 2017-02-20 22:47:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:47:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-20 22:47:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:47:13 --> Final output sent to browser
DEBUG - 2017-02-20 22:47:13 --> Total execution time: 0.1568
INFO - 2017-02-20 22:47:23 --> Config Class Initialized
INFO - 2017-02-20 22:47:23 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:47:23 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:47:23 --> Utf8 Class Initialized
INFO - 2017-02-20 22:47:23 --> URI Class Initialized
DEBUG - 2017-02-20 22:47:23 --> No URI present. Default controller set.
INFO - 2017-02-20 22:47:23 --> Router Class Initialized
INFO - 2017-02-20 22:47:23 --> Output Class Initialized
INFO - 2017-02-20 22:47:23 --> Security Class Initialized
DEBUG - 2017-02-20 22:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:47:23 --> Input Class Initialized
INFO - 2017-02-20 22:47:23 --> Language Class Initialized
INFO - 2017-02-20 22:47:23 --> Loader Class Initialized
INFO - 2017-02-20 22:47:23 --> Helper loaded: url_helper
INFO - 2017-02-20 22:47:23 --> Helper loaded: language_helper
INFO - 2017-02-20 22:47:23 --> Helper loaded: html_helper
INFO - 2017-02-20 22:47:23 --> Helper loaded: form_helper
INFO - 2017-02-20 22:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:47:23 --> Controller Class Initialized
INFO - 2017-02-20 22:47:23 --> Database Driver Class Initialized
INFO - 2017-02-20 22:47:23 --> Model Class Initialized
INFO - 2017-02-20 22:47:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:47:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:47:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:47:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:47:23 --> Final output sent to browser
DEBUG - 2017-02-20 22:47:23 --> Total execution time: 0.1383
INFO - 2017-02-20 22:47:39 --> Config Class Initialized
INFO - 2017-02-20 22:47:39 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:47:39 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:47:39 --> Utf8 Class Initialized
INFO - 2017-02-20 22:47:39 --> URI Class Initialized
DEBUG - 2017-02-20 22:47:39 --> No URI present. Default controller set.
INFO - 2017-02-20 22:47:39 --> Router Class Initialized
INFO - 2017-02-20 22:47:39 --> Output Class Initialized
INFO - 2017-02-20 22:47:40 --> Security Class Initialized
DEBUG - 2017-02-20 22:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:47:40 --> Input Class Initialized
INFO - 2017-02-20 22:47:40 --> Language Class Initialized
INFO - 2017-02-20 22:47:40 --> Loader Class Initialized
INFO - 2017-02-20 22:47:40 --> Helper loaded: url_helper
INFO - 2017-02-20 22:47:40 --> Helper loaded: language_helper
INFO - 2017-02-20 22:47:40 --> Helper loaded: html_helper
INFO - 2017-02-20 22:47:40 --> Helper loaded: form_helper
INFO - 2017-02-20 22:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:47:40 --> Controller Class Initialized
INFO - 2017-02-20 22:47:40 --> Database Driver Class Initialized
INFO - 2017-02-20 22:47:40 --> Model Class Initialized
INFO - 2017-02-20 22:47:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:47:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:47:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:47:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:47:40 --> Final output sent to browser
DEBUG - 2017-02-20 22:47:40 --> Total execution time: 0.1256
INFO - 2017-02-20 22:47:50 --> Config Class Initialized
INFO - 2017-02-20 22:47:50 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:47:50 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:47:50 --> Utf8 Class Initialized
INFO - 2017-02-20 22:47:50 --> URI Class Initialized
DEBUG - 2017-02-20 22:47:50 --> No URI present. Default controller set.
INFO - 2017-02-20 22:47:50 --> Router Class Initialized
INFO - 2017-02-20 22:47:50 --> Output Class Initialized
INFO - 2017-02-20 22:47:50 --> Security Class Initialized
DEBUG - 2017-02-20 22:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:47:50 --> Input Class Initialized
INFO - 2017-02-20 22:47:50 --> Language Class Initialized
INFO - 2017-02-20 22:47:50 --> Loader Class Initialized
INFO - 2017-02-20 22:47:50 --> Helper loaded: url_helper
INFO - 2017-02-20 22:47:50 --> Helper loaded: language_helper
INFO - 2017-02-20 22:47:50 --> Helper loaded: html_helper
INFO - 2017-02-20 22:47:50 --> Helper loaded: form_helper
INFO - 2017-02-20 22:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:47:50 --> Controller Class Initialized
INFO - 2017-02-20 22:47:50 --> Database Driver Class Initialized
INFO - 2017-02-20 22:47:50 --> Model Class Initialized
INFO - 2017-02-20 22:47:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:47:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:47:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:47:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:47:50 --> Final output sent to browser
DEBUG - 2017-02-20 22:47:50 --> Total execution time: 0.1141
INFO - 2017-02-20 22:48:17 --> Config Class Initialized
INFO - 2017-02-20 22:48:17 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:48:17 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:48:17 --> Utf8 Class Initialized
INFO - 2017-02-20 22:48:17 --> URI Class Initialized
DEBUG - 2017-02-20 22:48:17 --> No URI present. Default controller set.
INFO - 2017-02-20 22:48:17 --> Router Class Initialized
INFO - 2017-02-20 22:48:17 --> Output Class Initialized
INFO - 2017-02-20 22:48:17 --> Security Class Initialized
DEBUG - 2017-02-20 22:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:48:17 --> Input Class Initialized
INFO - 2017-02-20 22:48:17 --> Language Class Initialized
INFO - 2017-02-20 22:48:17 --> Loader Class Initialized
INFO - 2017-02-20 22:48:17 --> Helper loaded: url_helper
INFO - 2017-02-20 22:48:17 --> Helper loaded: language_helper
INFO - 2017-02-20 22:48:17 --> Helper loaded: html_helper
INFO - 2017-02-20 22:48:17 --> Helper loaded: form_helper
INFO - 2017-02-20 22:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:48:17 --> Controller Class Initialized
INFO - 2017-02-20 22:48:17 --> Database Driver Class Initialized
INFO - 2017-02-20 22:48:17 --> Model Class Initialized
INFO - 2017-02-20 22:48:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:48:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:48:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:48:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:48:17 --> Final output sent to browser
DEBUG - 2017-02-20 22:48:17 --> Total execution time: 0.1613
INFO - 2017-02-20 22:48:30 --> Config Class Initialized
INFO - 2017-02-20 22:48:30 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:48:30 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:48:30 --> Utf8 Class Initialized
INFO - 2017-02-20 22:48:30 --> URI Class Initialized
DEBUG - 2017-02-20 22:48:30 --> No URI present. Default controller set.
INFO - 2017-02-20 22:48:30 --> Router Class Initialized
INFO - 2017-02-20 22:48:30 --> Output Class Initialized
INFO - 2017-02-20 22:48:30 --> Security Class Initialized
DEBUG - 2017-02-20 22:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:48:30 --> Input Class Initialized
INFO - 2017-02-20 22:48:30 --> Language Class Initialized
INFO - 2017-02-20 22:48:30 --> Loader Class Initialized
INFO - 2017-02-20 22:48:30 --> Helper loaded: url_helper
INFO - 2017-02-20 22:48:30 --> Helper loaded: language_helper
INFO - 2017-02-20 22:48:30 --> Helper loaded: html_helper
INFO - 2017-02-20 22:48:30 --> Helper loaded: form_helper
INFO - 2017-02-20 22:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:48:30 --> Controller Class Initialized
INFO - 2017-02-20 22:48:30 --> Database Driver Class Initialized
INFO - 2017-02-20 22:48:30 --> Model Class Initialized
INFO - 2017-02-20 22:48:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:48:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:48:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:48:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:48:30 --> Final output sent to browser
DEBUG - 2017-02-20 22:48:30 --> Total execution time: 0.1443
INFO - 2017-02-20 22:49:19 --> Config Class Initialized
INFO - 2017-02-20 22:49:19 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:49:19 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:49:19 --> Utf8 Class Initialized
INFO - 2017-02-20 22:49:19 --> URI Class Initialized
DEBUG - 2017-02-20 22:49:19 --> No URI present. Default controller set.
INFO - 2017-02-20 22:49:19 --> Router Class Initialized
INFO - 2017-02-20 22:49:19 --> Output Class Initialized
INFO - 2017-02-20 22:49:19 --> Security Class Initialized
DEBUG - 2017-02-20 22:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:49:19 --> Input Class Initialized
INFO - 2017-02-20 22:49:19 --> Language Class Initialized
INFO - 2017-02-20 22:49:19 --> Loader Class Initialized
INFO - 2017-02-20 22:49:19 --> Helper loaded: url_helper
INFO - 2017-02-20 22:49:19 --> Helper loaded: language_helper
INFO - 2017-02-20 22:49:19 --> Helper loaded: html_helper
INFO - 2017-02-20 22:49:19 --> Helper loaded: form_helper
INFO - 2017-02-20 22:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:49:19 --> Controller Class Initialized
INFO - 2017-02-20 22:49:20 --> Database Driver Class Initialized
INFO - 2017-02-20 22:49:20 --> Model Class Initialized
INFO - 2017-02-20 22:49:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:49:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:49:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:49:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:49:20 --> Final output sent to browser
DEBUG - 2017-02-20 22:49:20 --> Total execution time: 0.1473
INFO - 2017-02-20 22:50:29 --> Config Class Initialized
INFO - 2017-02-20 22:50:29 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:50:29 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:50:29 --> Utf8 Class Initialized
INFO - 2017-02-20 22:50:29 --> URI Class Initialized
DEBUG - 2017-02-20 22:50:29 --> No URI present. Default controller set.
INFO - 2017-02-20 22:50:29 --> Router Class Initialized
INFO - 2017-02-20 22:50:29 --> Output Class Initialized
INFO - 2017-02-20 22:50:29 --> Security Class Initialized
DEBUG - 2017-02-20 22:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:50:29 --> Input Class Initialized
INFO - 2017-02-20 22:50:29 --> Language Class Initialized
INFO - 2017-02-20 22:50:29 --> Loader Class Initialized
INFO - 2017-02-20 22:50:29 --> Helper loaded: url_helper
INFO - 2017-02-20 22:50:29 --> Helper loaded: language_helper
INFO - 2017-02-20 22:50:29 --> Helper loaded: html_helper
INFO - 2017-02-20 22:50:29 --> Helper loaded: form_helper
INFO - 2017-02-20 22:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:50:29 --> Controller Class Initialized
INFO - 2017-02-20 22:50:29 --> Database Driver Class Initialized
INFO - 2017-02-20 22:50:29 --> Model Class Initialized
INFO - 2017-02-20 22:50:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:50:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:50:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:50:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:50:29 --> Final output sent to browser
DEBUG - 2017-02-20 22:50:29 --> Total execution time: 0.1536
INFO - 2017-02-20 22:50:54 --> Config Class Initialized
INFO - 2017-02-20 22:50:54 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:50:54 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:50:54 --> Utf8 Class Initialized
INFO - 2017-02-20 22:50:54 --> URI Class Initialized
DEBUG - 2017-02-20 22:50:54 --> No URI present. Default controller set.
INFO - 2017-02-20 22:50:54 --> Router Class Initialized
INFO - 2017-02-20 22:50:54 --> Output Class Initialized
INFO - 2017-02-20 22:50:54 --> Security Class Initialized
DEBUG - 2017-02-20 22:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:50:54 --> Input Class Initialized
INFO - 2017-02-20 22:50:54 --> Language Class Initialized
INFO - 2017-02-20 22:50:54 --> Loader Class Initialized
INFO - 2017-02-20 22:50:54 --> Helper loaded: url_helper
INFO - 2017-02-20 22:50:54 --> Helper loaded: language_helper
INFO - 2017-02-20 22:50:54 --> Helper loaded: html_helper
INFO - 2017-02-20 22:50:54 --> Helper loaded: form_helper
INFO - 2017-02-20 22:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:50:54 --> Controller Class Initialized
INFO - 2017-02-20 22:50:54 --> Database Driver Class Initialized
INFO - 2017-02-20 22:50:54 --> Model Class Initialized
INFO - 2017-02-20 22:50:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:50:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:50:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:50:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:50:54 --> Final output sent to browser
DEBUG - 2017-02-20 22:50:54 --> Total execution time: 0.1097
INFO - 2017-02-20 22:51:06 --> Config Class Initialized
INFO - 2017-02-20 22:51:06 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:51:06 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:51:06 --> Utf8 Class Initialized
INFO - 2017-02-20 22:51:06 --> URI Class Initialized
DEBUG - 2017-02-20 22:51:06 --> No URI present. Default controller set.
INFO - 2017-02-20 22:51:06 --> Router Class Initialized
INFO - 2017-02-20 22:51:06 --> Output Class Initialized
INFO - 2017-02-20 22:51:06 --> Security Class Initialized
DEBUG - 2017-02-20 22:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:51:06 --> Input Class Initialized
INFO - 2017-02-20 22:51:06 --> Language Class Initialized
INFO - 2017-02-20 22:51:06 --> Loader Class Initialized
INFO - 2017-02-20 22:51:06 --> Helper loaded: url_helper
INFO - 2017-02-20 22:51:06 --> Helper loaded: language_helper
INFO - 2017-02-20 22:51:06 --> Helper loaded: html_helper
INFO - 2017-02-20 22:51:06 --> Helper loaded: form_helper
INFO - 2017-02-20 22:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:51:06 --> Controller Class Initialized
INFO - 2017-02-20 22:51:06 --> Database Driver Class Initialized
ERROR - 2017-02-20 22:51:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\wamp64\www\savsoftquiz\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-02-20 22:51:08 --> Unable to connect to the database
INFO - 2017-02-20 22:51:08 --> Language file loaded: language/indonesia/db_lang.php
INFO - 2017-02-20 22:51:13 --> Config Class Initialized
INFO - 2017-02-20 22:51:13 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:51:13 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:51:13 --> Utf8 Class Initialized
INFO - 2017-02-20 22:51:13 --> URI Class Initialized
DEBUG - 2017-02-20 22:51:13 --> No URI present. Default controller set.
INFO - 2017-02-20 22:51:13 --> Router Class Initialized
INFO - 2017-02-20 22:51:13 --> Output Class Initialized
INFO - 2017-02-20 22:51:13 --> Security Class Initialized
DEBUG - 2017-02-20 22:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:51:13 --> Input Class Initialized
INFO - 2017-02-20 22:51:13 --> Language Class Initialized
INFO - 2017-02-20 22:51:13 --> Loader Class Initialized
INFO - 2017-02-20 22:51:13 --> Helper loaded: url_helper
INFO - 2017-02-20 22:51:13 --> Helper loaded: language_helper
INFO - 2017-02-20 22:51:13 --> Helper loaded: html_helper
INFO - 2017-02-20 22:51:13 --> Helper loaded: form_helper
INFO - 2017-02-20 22:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:51:13 --> Controller Class Initialized
INFO - 2017-02-20 22:51:13 --> Database Driver Class Initialized
INFO - 2017-02-20 22:51:13 --> Model Class Initialized
INFO - 2017-02-20 22:51:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:51:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:51:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:51:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:51:13 --> Final output sent to browser
DEBUG - 2017-02-20 22:51:13 --> Total execution time: 0.1367
INFO - 2017-02-20 22:51:21 --> Config Class Initialized
INFO - 2017-02-20 22:51:21 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:51:21 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:51:21 --> Utf8 Class Initialized
INFO - 2017-02-20 22:51:21 --> URI Class Initialized
DEBUG - 2017-02-20 22:51:21 --> No URI present. Default controller set.
INFO - 2017-02-20 22:51:21 --> Router Class Initialized
INFO - 2017-02-20 22:51:21 --> Output Class Initialized
INFO - 2017-02-20 22:51:21 --> Security Class Initialized
DEBUG - 2017-02-20 22:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:51:21 --> Input Class Initialized
INFO - 2017-02-20 22:51:21 --> Language Class Initialized
INFO - 2017-02-20 22:51:21 --> Loader Class Initialized
INFO - 2017-02-20 22:51:21 --> Helper loaded: url_helper
INFO - 2017-02-20 22:51:21 --> Helper loaded: language_helper
INFO - 2017-02-20 22:51:21 --> Helper loaded: html_helper
INFO - 2017-02-20 22:51:21 --> Helper loaded: form_helper
INFO - 2017-02-20 22:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:51:21 --> Controller Class Initialized
INFO - 2017-02-20 22:51:21 --> Database Driver Class Initialized
INFO - 2017-02-20 22:51:21 --> Model Class Initialized
INFO - 2017-02-20 22:51:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:51:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:51:21 --> Final output sent to browser
DEBUG - 2017-02-20 22:51:21 --> Total execution time: 0.1985
INFO - 2017-02-20 22:51:33 --> Config Class Initialized
INFO - 2017-02-20 22:51:33 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:51:33 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:51:33 --> Utf8 Class Initialized
INFO - 2017-02-20 22:51:33 --> URI Class Initialized
DEBUG - 2017-02-20 22:51:33 --> No URI present. Default controller set.
INFO - 2017-02-20 22:51:33 --> Router Class Initialized
INFO - 2017-02-20 22:51:33 --> Output Class Initialized
INFO - 2017-02-20 22:51:33 --> Security Class Initialized
DEBUG - 2017-02-20 22:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:51:33 --> Input Class Initialized
INFO - 2017-02-20 22:51:33 --> Language Class Initialized
INFO - 2017-02-20 22:51:33 --> Loader Class Initialized
INFO - 2017-02-20 22:51:33 --> Helper loaded: url_helper
INFO - 2017-02-20 22:51:33 --> Helper loaded: language_helper
INFO - 2017-02-20 22:51:33 --> Helper loaded: html_helper
INFO - 2017-02-20 22:51:33 --> Helper loaded: form_helper
INFO - 2017-02-20 22:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:51:33 --> Controller Class Initialized
INFO - 2017-02-20 22:51:33 --> Database Driver Class Initialized
INFO - 2017-02-20 22:51:33 --> Model Class Initialized
INFO - 2017-02-20 22:51:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:51:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:51:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:51:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:51:33 --> Final output sent to browser
DEBUG - 2017-02-20 22:51:33 --> Total execution time: 0.1638
INFO - 2017-02-20 22:51:55 --> Config Class Initialized
INFO - 2017-02-20 22:51:55 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:51:55 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:51:55 --> Utf8 Class Initialized
INFO - 2017-02-20 22:51:55 --> URI Class Initialized
INFO - 2017-02-20 22:51:55 --> Router Class Initialized
INFO - 2017-02-20 22:51:55 --> Output Class Initialized
INFO - 2017-02-20 22:51:55 --> Security Class Initialized
DEBUG - 2017-02-20 22:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:51:55 --> Input Class Initialized
INFO - 2017-02-20 22:51:55 --> Language Class Initialized
INFO - 2017-02-20 22:51:55 --> Loader Class Initialized
INFO - 2017-02-20 22:51:55 --> Helper loaded: url_helper
INFO - 2017-02-20 22:51:55 --> Helper loaded: language_helper
INFO - 2017-02-20 22:51:55 --> Helper loaded: html_helper
INFO - 2017-02-20 22:51:55 --> Helper loaded: form_helper
INFO - 2017-02-20 22:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:51:55 --> Controller Class Initialized
INFO - 2017-02-20 22:51:55 --> Database Driver Class Initialized
INFO - 2017-02-20 22:51:55 --> Model Class Initialized
INFO - 2017-02-20 22:51:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:51:55 --> Form Validation Class Initialized
INFO - 2017-02-20 22:51:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-20 22:51:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-20 22:51:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-20 22:51:55 --> Final output sent to browser
DEBUG - 2017-02-20 22:51:55 --> Total execution time: 0.1584
INFO - 2017-02-20 22:52:00 --> Config Class Initialized
INFO - 2017-02-20 22:52:00 --> Hooks Class Initialized
DEBUG - 2017-02-20 22:52:00 --> UTF-8 Support Enabled
INFO - 2017-02-20 22:52:00 --> Utf8 Class Initialized
INFO - 2017-02-20 22:52:00 --> URI Class Initialized
DEBUG - 2017-02-20 22:52:00 --> No URI present. Default controller set.
INFO - 2017-02-20 22:52:00 --> Router Class Initialized
INFO - 2017-02-20 22:52:00 --> Output Class Initialized
INFO - 2017-02-20 22:52:00 --> Security Class Initialized
DEBUG - 2017-02-20 22:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-20 22:52:00 --> Input Class Initialized
INFO - 2017-02-20 22:52:00 --> Language Class Initialized
INFO - 2017-02-20 22:52:00 --> Loader Class Initialized
INFO - 2017-02-20 22:52:00 --> Helper loaded: url_helper
INFO - 2017-02-20 22:52:00 --> Helper loaded: language_helper
INFO - 2017-02-20 22:52:00 --> Helper loaded: html_helper
INFO - 2017-02-20 22:52:00 --> Helper loaded: form_helper
INFO - 2017-02-20 22:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-20 22:52:00 --> Controller Class Initialized
INFO - 2017-02-20 22:52:00 --> Database Driver Class Initialized
INFO - 2017-02-20 22:52:00 --> Model Class Initialized
INFO - 2017-02-20 22:52:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-20 22:52:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-20 22:52:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-20 22:52:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-20 22:52:00 --> Final output sent to browser
DEBUG - 2017-02-20 22:52:00 --> Total execution time: 0.1490
