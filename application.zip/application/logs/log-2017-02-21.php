<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-21 09:18:49 --> Config Class Initialized
INFO - 2017-02-21 09:18:49 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:18:49 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:18:49 --> Utf8 Class Initialized
INFO - 2017-02-21 09:18:49 --> URI Class Initialized
INFO - 2017-02-21 09:18:49 --> Router Class Initialized
INFO - 2017-02-21 09:18:49 --> Output Class Initialized
INFO - 2017-02-21 09:18:49 --> Security Class Initialized
DEBUG - 2017-02-21 09:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:18:49 --> Input Class Initialized
INFO - 2017-02-21 09:18:49 --> Language Class Initialized
INFO - 2017-02-21 09:18:49 --> Loader Class Initialized
INFO - 2017-02-21 09:18:50 --> Helper loaded: url_helper
INFO - 2017-02-21 09:18:50 --> Helper loaded: language_helper
INFO - 2017-02-21 09:18:50 --> Helper loaded: html_helper
INFO - 2017-02-21 09:18:50 --> Helper loaded: form_helper
INFO - 2017-02-21 09:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:18:50 --> Controller Class Initialized
INFO - 2017-02-21 09:18:50 --> Database Driver Class Initialized
INFO - 2017-02-21 09:18:50 --> Model Class Initialized
INFO - 2017-02-21 09:18:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:18:50 --> Config Class Initialized
INFO - 2017-02-21 09:18:50 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:18:50 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:18:50 --> Utf8 Class Initialized
INFO - 2017-02-21 09:18:50 --> URI Class Initialized
INFO - 2017-02-21 09:18:50 --> Router Class Initialized
INFO - 2017-02-21 09:18:50 --> Output Class Initialized
INFO - 2017-02-21 09:18:50 --> Security Class Initialized
DEBUG - 2017-02-21 09:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:18:50 --> Input Class Initialized
INFO - 2017-02-21 09:18:50 --> Language Class Initialized
INFO - 2017-02-21 09:18:50 --> Loader Class Initialized
INFO - 2017-02-21 09:18:50 --> Helper loaded: url_helper
INFO - 2017-02-21 09:18:50 --> Helper loaded: language_helper
INFO - 2017-02-21 09:18:50 --> Helper loaded: html_helper
INFO - 2017-02-21 09:18:50 --> Helper loaded: form_helper
INFO - 2017-02-21 09:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:18:50 --> Controller Class Initialized
INFO - 2017-02-21 09:18:50 --> Database Driver Class Initialized
INFO - 2017-02-21 09:18:50 --> Model Class Initialized
INFO - 2017-02-21 09:18:50 --> Model Class Initialized
INFO - 2017-02-21 09:18:50 --> Model Class Initialized
INFO - 2017-02-21 09:18:50 --> Model Class Initialized
INFO - 2017-02-21 09:18:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:18:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:18:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-21 09:18:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:18:50 --> Final output sent to browser
DEBUG - 2017-02-21 09:18:50 --> Total execution time: 0.1175
INFO - 2017-02-21 09:18:52 --> Config Class Initialized
INFO - 2017-02-21 09:18:52 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:18:52 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:18:52 --> Utf8 Class Initialized
INFO - 2017-02-21 09:18:52 --> URI Class Initialized
INFO - 2017-02-21 09:18:52 --> Router Class Initialized
INFO - 2017-02-21 09:18:52 --> Output Class Initialized
INFO - 2017-02-21 09:18:52 --> Security Class Initialized
DEBUG - 2017-02-21 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:18:52 --> Input Class Initialized
INFO - 2017-02-21 09:18:52 --> Language Class Initialized
INFO - 2017-02-21 09:18:52 --> Loader Class Initialized
INFO - 2017-02-21 09:18:52 --> Helper loaded: url_helper
INFO - 2017-02-21 09:18:52 --> Helper loaded: language_helper
INFO - 2017-02-21 09:18:52 --> Helper loaded: html_helper
INFO - 2017-02-21 09:18:52 --> Helper loaded: form_helper
INFO - 2017-02-21 09:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:18:52 --> Controller Class Initialized
INFO - 2017-02-21 09:18:52 --> Database Driver Class Initialized
INFO - 2017-02-21 09:18:52 --> Model Class Initialized
INFO - 2017-02-21 09:18:52 --> Model Class Initialized
INFO - 2017-02-21 09:18:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:18:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:18:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-21 09:18:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:18:53 --> Final output sent to browser
DEBUG - 2017-02-21 09:18:53 --> Total execution time: 0.2837
INFO - 2017-02-21 09:21:27 --> Config Class Initialized
INFO - 2017-02-21 09:21:27 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:21:27 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:21:27 --> Utf8 Class Initialized
INFO - 2017-02-21 09:21:27 --> URI Class Initialized
INFO - 2017-02-21 09:21:27 --> Router Class Initialized
INFO - 2017-02-21 09:21:27 --> Output Class Initialized
INFO - 2017-02-21 09:21:27 --> Security Class Initialized
DEBUG - 2017-02-21 09:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:21:27 --> Input Class Initialized
INFO - 2017-02-21 09:21:27 --> Language Class Initialized
INFO - 2017-02-21 09:21:27 --> Loader Class Initialized
INFO - 2017-02-21 09:21:27 --> Helper loaded: url_helper
INFO - 2017-02-21 09:21:27 --> Helper loaded: language_helper
INFO - 2017-02-21 09:21:27 --> Helper loaded: html_helper
INFO - 2017-02-21 09:21:27 --> Helper loaded: form_helper
INFO - 2017-02-21 09:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:21:27 --> Controller Class Initialized
INFO - 2017-02-21 09:21:27 --> Database Driver Class Initialized
INFO - 2017-02-21 09:21:27 --> Model Class Initialized
INFO - 2017-02-21 09:21:27 --> Model Class Initialized
INFO - 2017-02-21 09:21:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:21:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:21:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-21 09:21:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:21:27 --> Final output sent to browser
DEBUG - 2017-02-21 09:21:27 --> Total execution time: 0.2122
INFO - 2017-02-21 09:21:29 --> Config Class Initialized
INFO - 2017-02-21 09:21:29 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:21:29 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:21:29 --> Utf8 Class Initialized
INFO - 2017-02-21 09:21:29 --> URI Class Initialized
INFO - 2017-02-21 09:21:29 --> Router Class Initialized
INFO - 2017-02-21 09:21:29 --> Output Class Initialized
INFO - 2017-02-21 09:21:29 --> Security Class Initialized
DEBUG - 2017-02-21 09:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:21:29 --> Input Class Initialized
INFO - 2017-02-21 09:21:29 --> Language Class Initialized
INFO - 2017-02-21 09:21:29 --> Loader Class Initialized
INFO - 2017-02-21 09:21:29 --> Helper loaded: url_helper
INFO - 2017-02-21 09:21:29 --> Helper loaded: language_helper
INFO - 2017-02-21 09:21:29 --> Helper loaded: html_helper
INFO - 2017-02-21 09:21:29 --> Helper loaded: form_helper
INFO - 2017-02-21 09:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:21:29 --> Controller Class Initialized
INFO - 2017-02-21 09:21:29 --> Database Driver Class Initialized
INFO - 2017-02-21 09:21:29 --> Model Class Initialized
INFO - 2017-02-21 09:21:29 --> Model Class Initialized
INFO - 2017-02-21 09:21:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:21:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:21:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-21 09:21:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:21:29 --> Final output sent to browser
DEBUG - 2017-02-21 09:21:29 --> Total execution time: 0.1955
INFO - 2017-02-21 09:21:34 --> Config Class Initialized
INFO - 2017-02-21 09:21:34 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:21:34 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:21:34 --> Utf8 Class Initialized
INFO - 2017-02-21 09:21:34 --> URI Class Initialized
INFO - 2017-02-21 09:21:34 --> Router Class Initialized
INFO - 2017-02-21 09:21:34 --> Output Class Initialized
INFO - 2017-02-21 09:21:34 --> Security Class Initialized
DEBUG - 2017-02-21 09:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:21:34 --> Input Class Initialized
INFO - 2017-02-21 09:21:34 --> Language Class Initialized
INFO - 2017-02-21 09:21:34 --> Loader Class Initialized
INFO - 2017-02-21 09:21:34 --> Helper loaded: url_helper
INFO - 2017-02-21 09:21:34 --> Helper loaded: language_helper
INFO - 2017-02-21 09:21:34 --> Helper loaded: html_helper
INFO - 2017-02-21 09:21:34 --> Helper loaded: form_helper
INFO - 2017-02-21 09:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:21:34 --> Controller Class Initialized
INFO - 2017-02-21 09:21:34 --> Database Driver Class Initialized
INFO - 2017-02-21 09:21:34 --> Model Class Initialized
INFO - 2017-02-21 09:21:34 --> Model Class Initialized
INFO - 2017-02-21 09:21:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:21:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:21:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-21 09:21:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:21:34 --> Final output sent to browser
DEBUG - 2017-02-21 09:21:34 --> Total execution time: 0.1420
INFO - 2017-02-21 09:21:40 --> Config Class Initialized
INFO - 2017-02-21 09:21:40 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:21:40 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:21:40 --> Utf8 Class Initialized
INFO - 2017-02-21 09:21:40 --> URI Class Initialized
INFO - 2017-02-21 09:21:40 --> Router Class Initialized
INFO - 2017-02-21 09:21:40 --> Output Class Initialized
INFO - 2017-02-21 09:21:40 --> Security Class Initialized
DEBUG - 2017-02-21 09:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:21:40 --> Input Class Initialized
INFO - 2017-02-21 09:21:40 --> Language Class Initialized
INFO - 2017-02-21 09:21:40 --> Loader Class Initialized
INFO - 2017-02-21 09:21:40 --> Helper loaded: url_helper
INFO - 2017-02-21 09:21:40 --> Helper loaded: language_helper
INFO - 2017-02-21 09:21:40 --> Helper loaded: html_helper
INFO - 2017-02-21 09:21:40 --> Helper loaded: form_helper
INFO - 2017-02-21 09:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:21:40 --> Controller Class Initialized
INFO - 2017-02-21 09:21:40 --> Database Driver Class Initialized
INFO - 2017-02-21 09:21:40 --> Model Class Initialized
INFO - 2017-02-21 09:21:40 --> Model Class Initialized
INFO - 2017-02-21 09:21:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:21:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:21:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-21 09:21:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:21:40 --> Final output sent to browser
DEBUG - 2017-02-21 09:21:40 --> Total execution time: 0.1154
INFO - 2017-02-21 09:21:45 --> Config Class Initialized
INFO - 2017-02-21 09:21:45 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:21:45 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:21:45 --> Utf8 Class Initialized
INFO - 2017-02-21 09:21:45 --> URI Class Initialized
INFO - 2017-02-21 09:21:45 --> Router Class Initialized
INFO - 2017-02-21 09:21:45 --> Output Class Initialized
INFO - 2017-02-21 09:21:45 --> Security Class Initialized
DEBUG - 2017-02-21 09:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:21:45 --> Input Class Initialized
INFO - 2017-02-21 09:21:45 --> Language Class Initialized
INFO - 2017-02-21 09:21:45 --> Loader Class Initialized
INFO - 2017-02-21 09:21:45 --> Helper loaded: url_helper
INFO - 2017-02-21 09:21:45 --> Helper loaded: language_helper
INFO - 2017-02-21 09:21:45 --> Helper loaded: html_helper
INFO - 2017-02-21 09:21:45 --> Helper loaded: form_helper
INFO - 2017-02-21 09:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:21:45 --> Controller Class Initialized
INFO - 2017-02-21 09:21:45 --> Database Driver Class Initialized
INFO - 2017-02-21 09:21:45 --> Model Class Initialized
INFO - 2017-02-21 09:21:45 --> Model Class Initialized
INFO - 2017-02-21 09:21:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-21 09:21:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:21:45 --> Final output sent to browser
DEBUG - 2017-02-21 09:21:45 --> Total execution time: 0.1356
INFO - 2017-02-21 09:21:48 --> Config Class Initialized
INFO - 2017-02-21 09:21:48 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:21:48 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:21:48 --> Utf8 Class Initialized
INFO - 2017-02-21 09:21:48 --> URI Class Initialized
INFO - 2017-02-21 09:21:48 --> Router Class Initialized
INFO - 2017-02-21 09:21:48 --> Output Class Initialized
INFO - 2017-02-21 09:21:48 --> Security Class Initialized
DEBUG - 2017-02-21 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:21:48 --> Input Class Initialized
INFO - 2017-02-21 09:21:48 --> Language Class Initialized
INFO - 2017-02-21 09:21:48 --> Loader Class Initialized
INFO - 2017-02-21 09:21:48 --> Helper loaded: url_helper
INFO - 2017-02-21 09:21:48 --> Helper loaded: language_helper
INFO - 2017-02-21 09:21:48 --> Helper loaded: html_helper
INFO - 2017-02-21 09:21:48 --> Helper loaded: form_helper
INFO - 2017-02-21 09:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:21:48 --> Controller Class Initialized
INFO - 2017-02-21 09:21:48 --> Database Driver Class Initialized
INFO - 2017-02-21 09:21:48 --> Model Class Initialized
INFO - 2017-02-21 09:21:48 --> Model Class Initialized
INFO - 2017-02-21 09:21:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:21:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:21:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-21 09:21:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:21:49 --> Final output sent to browser
DEBUG - 2017-02-21 09:21:49 --> Total execution time: 0.1275
INFO - 2017-02-21 09:21:52 --> Config Class Initialized
INFO - 2017-02-21 09:21:52 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:21:52 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:21:52 --> Utf8 Class Initialized
INFO - 2017-02-21 09:21:52 --> URI Class Initialized
INFO - 2017-02-21 09:21:52 --> Router Class Initialized
INFO - 2017-02-21 09:21:52 --> Output Class Initialized
INFO - 2017-02-21 09:21:52 --> Security Class Initialized
DEBUG - 2017-02-21 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:21:52 --> Input Class Initialized
INFO - 2017-02-21 09:21:52 --> Language Class Initialized
INFO - 2017-02-21 09:21:52 --> Loader Class Initialized
INFO - 2017-02-21 09:21:52 --> Helper loaded: url_helper
INFO - 2017-02-21 09:21:52 --> Helper loaded: language_helper
INFO - 2017-02-21 09:21:52 --> Helper loaded: html_helper
INFO - 2017-02-21 09:21:52 --> Helper loaded: form_helper
INFO - 2017-02-21 09:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:21:52 --> Controller Class Initialized
INFO - 2017-02-21 09:21:52 --> Database Driver Class Initialized
INFO - 2017-02-21 09:21:52 --> Model Class Initialized
INFO - 2017-02-21 09:21:52 --> Model Class Initialized
INFO - 2017-02-21 09:21:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-21 09:21:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:21:52 --> Final output sent to browser
DEBUG - 2017-02-21 09:21:52 --> Total execution time: 0.1131
INFO - 2017-02-21 09:21:56 --> Config Class Initialized
INFO - 2017-02-21 09:21:56 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:21:56 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:21:56 --> Utf8 Class Initialized
INFO - 2017-02-21 09:21:56 --> URI Class Initialized
INFO - 2017-02-21 09:21:56 --> Router Class Initialized
INFO - 2017-02-21 09:21:56 --> Output Class Initialized
INFO - 2017-02-21 09:21:56 --> Security Class Initialized
DEBUG - 2017-02-21 09:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:21:56 --> Input Class Initialized
INFO - 2017-02-21 09:21:56 --> Language Class Initialized
INFO - 2017-02-21 09:21:56 --> Loader Class Initialized
INFO - 2017-02-21 09:21:56 --> Helper loaded: url_helper
INFO - 2017-02-21 09:21:56 --> Helper loaded: language_helper
INFO - 2017-02-21 09:21:56 --> Helper loaded: html_helper
INFO - 2017-02-21 09:21:56 --> Helper loaded: form_helper
INFO - 2017-02-21 09:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:21:56 --> Controller Class Initialized
INFO - 2017-02-21 09:21:56 --> Database Driver Class Initialized
INFO - 2017-02-21 09:21:56 --> Model Class Initialized
INFO - 2017-02-21 09:21:56 --> Model Class Initialized
INFO - 2017-02-21 09:21:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-21 09:21:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:21:56 --> Final output sent to browser
DEBUG - 2017-02-21 09:21:56 --> Total execution time: 0.1573
INFO - 2017-02-21 09:22:07 --> Config Class Initialized
INFO - 2017-02-21 09:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:22:07 --> Utf8 Class Initialized
INFO - 2017-02-21 09:22:07 --> URI Class Initialized
INFO - 2017-02-21 09:22:07 --> Router Class Initialized
INFO - 2017-02-21 09:22:07 --> Output Class Initialized
INFO - 2017-02-21 09:22:07 --> Security Class Initialized
DEBUG - 2017-02-21 09:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:22:07 --> Input Class Initialized
INFO - 2017-02-21 09:22:07 --> Language Class Initialized
INFO - 2017-02-21 09:22:07 --> Loader Class Initialized
INFO - 2017-02-21 09:22:07 --> Helper loaded: url_helper
INFO - 2017-02-21 09:22:07 --> Helper loaded: language_helper
INFO - 2017-02-21 09:22:07 --> Helper loaded: html_helper
INFO - 2017-02-21 09:22:07 --> Helper loaded: form_helper
INFO - 2017-02-21 09:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:22:07 --> Controller Class Initialized
INFO - 2017-02-21 09:22:07 --> Database Driver Class Initialized
INFO - 2017-02-21 09:22:07 --> Model Class Initialized
INFO - 2017-02-21 09:22:07 --> Model Class Initialized
INFO - 2017-02-21 09:22:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:22:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:22:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 09:22:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:22:07 --> Final output sent to browser
DEBUG - 2017-02-21 09:22:07 --> Total execution time: 0.2057
INFO - 2017-02-21 09:22:12 --> Config Class Initialized
INFO - 2017-02-21 09:22:12 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:22:12 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:22:12 --> Utf8 Class Initialized
INFO - 2017-02-21 09:22:12 --> URI Class Initialized
INFO - 2017-02-21 09:22:12 --> Router Class Initialized
INFO - 2017-02-21 09:22:12 --> Output Class Initialized
INFO - 2017-02-21 09:22:12 --> Security Class Initialized
DEBUG - 2017-02-21 09:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:22:12 --> Input Class Initialized
INFO - 2017-02-21 09:22:12 --> Language Class Initialized
INFO - 2017-02-21 09:22:12 --> Loader Class Initialized
INFO - 2017-02-21 09:22:12 --> Helper loaded: url_helper
INFO - 2017-02-21 09:22:12 --> Helper loaded: language_helper
INFO - 2017-02-21 09:22:12 --> Helper loaded: html_helper
INFO - 2017-02-21 09:22:12 --> Helper loaded: form_helper
INFO - 2017-02-21 09:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:22:12 --> Controller Class Initialized
INFO - 2017-02-21 09:22:12 --> Database Driver Class Initialized
INFO - 2017-02-21 09:22:12 --> Model Class Initialized
INFO - 2017-02-21 09:22:12 --> Model Class Initialized
INFO - 2017-02-21 09:22:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 09:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:22:12 --> Final output sent to browser
DEBUG - 2017-02-21 09:22:12 --> Total execution time: 0.1618
INFO - 2017-02-21 09:22:15 --> Config Class Initialized
INFO - 2017-02-21 09:22:15 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:22:15 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:22:15 --> Utf8 Class Initialized
INFO - 2017-02-21 09:22:15 --> URI Class Initialized
INFO - 2017-02-21 09:22:15 --> Router Class Initialized
INFO - 2017-02-21 09:22:15 --> Output Class Initialized
INFO - 2017-02-21 09:22:15 --> Security Class Initialized
DEBUG - 2017-02-21 09:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:22:15 --> Input Class Initialized
INFO - 2017-02-21 09:22:15 --> Language Class Initialized
INFO - 2017-02-21 09:22:15 --> Loader Class Initialized
INFO - 2017-02-21 09:22:15 --> Helper loaded: url_helper
INFO - 2017-02-21 09:22:15 --> Helper loaded: language_helper
INFO - 2017-02-21 09:22:15 --> Helper loaded: html_helper
INFO - 2017-02-21 09:22:15 --> Helper loaded: form_helper
INFO - 2017-02-21 09:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:22:15 --> Controller Class Initialized
INFO - 2017-02-21 09:22:15 --> Database Driver Class Initialized
INFO - 2017-02-21 09:22:15 --> Model Class Initialized
INFO - 2017-02-21 09:22:15 --> Model Class Initialized
INFO - 2017-02-21 09:22:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 09:22:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:22:15 --> Final output sent to browser
DEBUG - 2017-02-21 09:22:15 --> Total execution time: 0.1607
INFO - 2017-02-21 09:22:21 --> Config Class Initialized
INFO - 2017-02-21 09:22:21 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:22:21 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:22:21 --> Utf8 Class Initialized
INFO - 2017-02-21 09:22:21 --> URI Class Initialized
INFO - 2017-02-21 09:22:21 --> Router Class Initialized
INFO - 2017-02-21 09:22:21 --> Output Class Initialized
INFO - 2017-02-21 09:22:21 --> Security Class Initialized
DEBUG - 2017-02-21 09:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:22:21 --> Input Class Initialized
INFO - 2017-02-21 09:22:21 --> Language Class Initialized
INFO - 2017-02-21 09:22:21 --> Loader Class Initialized
INFO - 2017-02-21 09:22:21 --> Helper loaded: url_helper
INFO - 2017-02-21 09:22:21 --> Helper loaded: language_helper
INFO - 2017-02-21 09:22:21 --> Helper loaded: html_helper
INFO - 2017-02-21 09:22:21 --> Helper loaded: form_helper
INFO - 2017-02-21 09:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:22:21 --> Controller Class Initialized
INFO - 2017-02-21 09:22:21 --> Database Driver Class Initialized
INFO - 2017-02-21 09:22:21 --> Model Class Initialized
INFO - 2017-02-21 09:22:21 --> Model Class Initialized
INFO - 2017-02-21 09:22:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:22:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:22:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 09:22:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:22:21 --> Final output sent to browser
DEBUG - 2017-02-21 09:22:21 --> Total execution time: 0.1416
INFO - 2017-02-21 09:22:37 --> Config Class Initialized
INFO - 2017-02-21 09:22:37 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:22:37 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:22:37 --> Utf8 Class Initialized
INFO - 2017-02-21 09:22:37 --> URI Class Initialized
INFO - 2017-02-21 09:22:37 --> Router Class Initialized
INFO - 2017-02-21 09:22:37 --> Output Class Initialized
INFO - 2017-02-21 09:22:37 --> Security Class Initialized
DEBUG - 2017-02-21 09:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:22:37 --> Input Class Initialized
INFO - 2017-02-21 09:22:37 --> Language Class Initialized
INFO - 2017-02-21 09:22:37 --> Loader Class Initialized
INFO - 2017-02-21 09:22:37 --> Helper loaded: url_helper
INFO - 2017-02-21 09:22:37 --> Helper loaded: language_helper
INFO - 2017-02-21 09:22:37 --> Helper loaded: html_helper
INFO - 2017-02-21 09:22:37 --> Helper loaded: form_helper
INFO - 2017-02-21 09:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:22:37 --> Controller Class Initialized
INFO - 2017-02-21 09:22:37 --> Database Driver Class Initialized
INFO - 2017-02-21 09:22:37 --> Model Class Initialized
INFO - 2017-02-21 09:22:37 --> Model Class Initialized
INFO - 2017-02-21 09:22:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:22:37 --> Model Class Initialized
INFO - 2017-02-21 09:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-21 09:22:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:22:38 --> Final output sent to browser
DEBUG - 2017-02-21 09:22:38 --> Total execution time: 0.4039
INFO - 2017-02-21 09:22:51 --> Config Class Initialized
INFO - 2017-02-21 09:22:51 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:22:51 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:22:51 --> Utf8 Class Initialized
INFO - 2017-02-21 09:22:51 --> URI Class Initialized
INFO - 2017-02-21 09:22:51 --> Router Class Initialized
INFO - 2017-02-21 09:22:51 --> Output Class Initialized
INFO - 2017-02-21 09:22:51 --> Security Class Initialized
DEBUG - 2017-02-21 09:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:22:51 --> Input Class Initialized
INFO - 2017-02-21 09:22:51 --> Language Class Initialized
INFO - 2017-02-21 09:22:51 --> Loader Class Initialized
INFO - 2017-02-21 09:22:51 --> Helper loaded: url_helper
INFO - 2017-02-21 09:22:51 --> Helper loaded: language_helper
INFO - 2017-02-21 09:22:51 --> Helper loaded: html_helper
INFO - 2017-02-21 09:22:51 --> Helper loaded: form_helper
INFO - 2017-02-21 09:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:22:51 --> Controller Class Initialized
INFO - 2017-02-21 09:22:51 --> Database Driver Class Initialized
INFO - 2017-02-21 09:22:51 --> Model Class Initialized
INFO - 2017-02-21 09:22:51 --> Model Class Initialized
INFO - 2017-02-21 09:22:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-21 09:22:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:22:51 --> Final output sent to browser
DEBUG - 2017-02-21 09:22:51 --> Total execution time: 0.0804
INFO - 2017-02-21 09:22:56 --> Config Class Initialized
INFO - 2017-02-21 09:22:56 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:22:56 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:22:56 --> Utf8 Class Initialized
INFO - 2017-02-21 09:22:56 --> URI Class Initialized
INFO - 2017-02-21 09:22:56 --> Router Class Initialized
INFO - 2017-02-21 09:22:56 --> Output Class Initialized
INFO - 2017-02-21 09:22:56 --> Security Class Initialized
DEBUG - 2017-02-21 09:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:22:56 --> Input Class Initialized
INFO - 2017-02-21 09:22:56 --> Language Class Initialized
INFO - 2017-02-21 09:22:56 --> Loader Class Initialized
INFO - 2017-02-21 09:22:56 --> Helper loaded: url_helper
INFO - 2017-02-21 09:22:56 --> Helper loaded: language_helper
INFO - 2017-02-21 09:22:56 --> Helper loaded: html_helper
INFO - 2017-02-21 09:22:56 --> Helper loaded: form_helper
INFO - 2017-02-21 09:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:22:56 --> Controller Class Initialized
INFO - 2017-02-21 09:22:56 --> Database Driver Class Initialized
INFO - 2017-02-21 09:22:56 --> Model Class Initialized
INFO - 2017-02-21 09:22:56 --> Model Class Initialized
INFO - 2017-02-21 09:22:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:22:56 --> Config Class Initialized
INFO - 2017-02-21 09:22:56 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:22:56 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:22:56 --> Utf8 Class Initialized
INFO - 2017-02-21 09:22:56 --> URI Class Initialized
INFO - 2017-02-21 09:22:56 --> Router Class Initialized
INFO - 2017-02-21 09:22:56 --> Output Class Initialized
INFO - 2017-02-21 09:22:56 --> Security Class Initialized
DEBUG - 2017-02-21 09:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:22:56 --> Input Class Initialized
INFO - 2017-02-21 09:22:56 --> Language Class Initialized
INFO - 2017-02-21 09:22:56 --> Loader Class Initialized
INFO - 2017-02-21 09:22:56 --> Helper loaded: url_helper
INFO - 2017-02-21 09:22:57 --> Helper loaded: language_helper
INFO - 2017-02-21 09:22:57 --> Helper loaded: html_helper
INFO - 2017-02-21 09:22:57 --> Helper loaded: form_helper
INFO - 2017-02-21 09:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:22:57 --> Controller Class Initialized
INFO - 2017-02-21 09:22:57 --> Database Driver Class Initialized
INFO - 2017-02-21 09:22:57 --> Model Class Initialized
INFO - 2017-02-21 09:22:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 09:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 09:22:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 09:22:57 --> Final output sent to browser
DEBUG - 2017-02-21 09:22:57 --> Total execution time: 0.0912
INFO - 2017-02-21 09:23:02 --> Config Class Initialized
INFO - 2017-02-21 09:23:02 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:23:02 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:23:02 --> Utf8 Class Initialized
INFO - 2017-02-21 09:23:02 --> URI Class Initialized
INFO - 2017-02-21 09:23:02 --> Router Class Initialized
INFO - 2017-02-21 09:23:02 --> Output Class Initialized
INFO - 2017-02-21 09:23:02 --> Security Class Initialized
DEBUG - 2017-02-21 09:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:23:02 --> Input Class Initialized
INFO - 2017-02-21 09:23:02 --> Language Class Initialized
INFO - 2017-02-21 09:23:02 --> Loader Class Initialized
INFO - 2017-02-21 09:23:02 --> Helper loaded: url_helper
INFO - 2017-02-21 09:23:02 --> Helper loaded: language_helper
INFO - 2017-02-21 09:23:02 --> Helper loaded: html_helper
INFO - 2017-02-21 09:23:02 --> Helper loaded: form_helper
INFO - 2017-02-21 09:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:23:02 --> Controller Class Initialized
INFO - 2017-02-21 09:23:02 --> Database Driver Class Initialized
INFO - 2017-02-21 09:23:02 --> Model Class Initialized
INFO - 2017-02-21 09:23:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:23:02 --> Config Class Initialized
INFO - 2017-02-21 09:23:02 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:23:02 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:23:02 --> Utf8 Class Initialized
INFO - 2017-02-21 09:23:02 --> URI Class Initialized
INFO - 2017-02-21 09:23:02 --> Router Class Initialized
INFO - 2017-02-21 09:23:02 --> Output Class Initialized
INFO - 2017-02-21 09:23:02 --> Security Class Initialized
DEBUG - 2017-02-21 09:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:23:02 --> Input Class Initialized
INFO - 2017-02-21 09:23:02 --> Language Class Initialized
INFO - 2017-02-21 09:23:02 --> Loader Class Initialized
INFO - 2017-02-21 09:23:02 --> Helper loaded: url_helper
INFO - 2017-02-21 09:23:02 --> Helper loaded: language_helper
INFO - 2017-02-21 09:23:02 --> Helper loaded: html_helper
INFO - 2017-02-21 09:23:02 --> Helper loaded: form_helper
INFO - 2017-02-21 09:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:23:02 --> Controller Class Initialized
INFO - 2017-02-21 09:23:02 --> Database Driver Class Initialized
INFO - 2017-02-21 09:23:02 --> Model Class Initialized
INFO - 2017-02-21 09:23:02 --> Model Class Initialized
INFO - 2017-02-21 09:23:02 --> Model Class Initialized
INFO - 2017-02-21 09:23:02 --> Model Class Initialized
INFO - 2017-02-21 09:23:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-21 09:23:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:23:02 --> Final output sent to browser
DEBUG - 2017-02-21 09:23:02 --> Total execution time: 0.0915
INFO - 2017-02-21 09:23:05 --> Config Class Initialized
INFO - 2017-02-21 09:23:05 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:23:05 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:23:05 --> Utf8 Class Initialized
INFO - 2017-02-21 09:23:05 --> URI Class Initialized
INFO - 2017-02-21 09:23:05 --> Router Class Initialized
INFO - 2017-02-21 09:23:05 --> Output Class Initialized
INFO - 2017-02-21 09:23:05 --> Security Class Initialized
DEBUG - 2017-02-21 09:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:23:05 --> Input Class Initialized
INFO - 2017-02-21 09:23:05 --> Language Class Initialized
INFO - 2017-02-21 09:23:05 --> Loader Class Initialized
INFO - 2017-02-21 09:23:05 --> Helper loaded: url_helper
INFO - 2017-02-21 09:23:05 --> Helper loaded: language_helper
INFO - 2017-02-21 09:23:05 --> Helper loaded: html_helper
INFO - 2017-02-21 09:23:05 --> Helper loaded: form_helper
INFO - 2017-02-21 09:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:23:05 --> Controller Class Initialized
INFO - 2017-02-21 09:23:05 --> Database Driver Class Initialized
INFO - 2017-02-21 09:23:05 --> Model Class Initialized
INFO - 2017-02-21 09:23:05 --> Model Class Initialized
INFO - 2017-02-21 09:23:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:23:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:23:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-21 09:23:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:23:05 --> Final output sent to browser
DEBUG - 2017-02-21 09:23:05 --> Total execution time: 0.2046
INFO - 2017-02-21 09:23:08 --> Config Class Initialized
INFO - 2017-02-21 09:23:08 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:23:08 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:23:08 --> Utf8 Class Initialized
INFO - 2017-02-21 09:23:08 --> URI Class Initialized
INFO - 2017-02-21 09:23:08 --> Router Class Initialized
INFO - 2017-02-21 09:23:08 --> Output Class Initialized
INFO - 2017-02-21 09:23:08 --> Security Class Initialized
DEBUG - 2017-02-21 09:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:23:08 --> Input Class Initialized
INFO - 2017-02-21 09:23:08 --> Language Class Initialized
INFO - 2017-02-21 09:23:08 --> Loader Class Initialized
INFO - 2017-02-21 09:23:08 --> Helper loaded: url_helper
INFO - 2017-02-21 09:23:08 --> Helper loaded: language_helper
INFO - 2017-02-21 09:23:08 --> Helper loaded: html_helper
INFO - 2017-02-21 09:23:08 --> Helper loaded: form_helper
INFO - 2017-02-21 09:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:23:08 --> Controller Class Initialized
INFO - 2017-02-21 09:23:08 --> Database Driver Class Initialized
INFO - 2017-02-21 09:23:08 --> Model Class Initialized
INFO - 2017-02-21 09:23:08 --> Model Class Initialized
INFO - 2017-02-21 09:23:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:23:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:23:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-21 09:23:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:23:08 --> Final output sent to browser
DEBUG - 2017-02-21 09:23:08 --> Total execution time: 0.1845
INFO - 2017-02-21 09:23:10 --> Config Class Initialized
INFO - 2017-02-21 09:23:10 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:23:10 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:23:10 --> Utf8 Class Initialized
INFO - 2017-02-21 09:23:10 --> URI Class Initialized
INFO - 2017-02-21 09:23:10 --> Router Class Initialized
INFO - 2017-02-21 09:23:10 --> Output Class Initialized
INFO - 2017-02-21 09:23:10 --> Security Class Initialized
DEBUG - 2017-02-21 09:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:23:10 --> Input Class Initialized
INFO - 2017-02-21 09:23:10 --> Language Class Initialized
INFO - 2017-02-21 09:23:10 --> Loader Class Initialized
INFO - 2017-02-21 09:23:10 --> Helper loaded: url_helper
INFO - 2017-02-21 09:23:10 --> Helper loaded: language_helper
INFO - 2017-02-21 09:23:10 --> Helper loaded: html_helper
INFO - 2017-02-21 09:23:10 --> Helper loaded: form_helper
INFO - 2017-02-21 09:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:23:10 --> Controller Class Initialized
INFO - 2017-02-21 09:23:10 --> Database Driver Class Initialized
INFO - 2017-02-21 09:23:10 --> Model Class Initialized
INFO - 2017-02-21 09:23:10 --> Model Class Initialized
INFO - 2017-02-21 09:23:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:23:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:23:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 09:23:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:23:10 --> Final output sent to browser
DEBUG - 2017-02-21 09:23:10 --> Total execution time: 0.2670
INFO - 2017-02-21 09:23:12 --> Config Class Initialized
INFO - 2017-02-21 09:23:12 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:23:12 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:23:12 --> Utf8 Class Initialized
INFO - 2017-02-21 09:23:12 --> URI Class Initialized
INFO - 2017-02-21 09:23:12 --> Router Class Initialized
INFO - 2017-02-21 09:23:12 --> Output Class Initialized
INFO - 2017-02-21 09:23:12 --> Security Class Initialized
DEBUG - 2017-02-21 09:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:23:12 --> Input Class Initialized
INFO - 2017-02-21 09:23:12 --> Language Class Initialized
INFO - 2017-02-21 09:23:12 --> Loader Class Initialized
INFO - 2017-02-21 09:23:12 --> Helper loaded: url_helper
INFO - 2017-02-21 09:23:12 --> Helper loaded: language_helper
INFO - 2017-02-21 09:23:12 --> Helper loaded: html_helper
INFO - 2017-02-21 09:23:12 --> Helper loaded: form_helper
INFO - 2017-02-21 09:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:23:12 --> Controller Class Initialized
INFO - 2017-02-21 09:23:12 --> Database Driver Class Initialized
INFO - 2017-02-21 09:23:12 --> Model Class Initialized
INFO - 2017-02-21 09:23:12 --> Model Class Initialized
INFO - 2017-02-21 09:23:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:23:12 --> Model Class Initialized
INFO - 2017-02-21 09:23:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:23:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-21 09:23:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:23:12 --> Final output sent to browser
DEBUG - 2017-02-21 09:23:12 --> Total execution time: 0.4006
INFO - 2017-02-21 09:23:14 --> Config Class Initialized
INFO - 2017-02-21 09:23:14 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:23:14 --> Utf8 Class Initialized
INFO - 2017-02-21 09:23:14 --> URI Class Initialized
INFO - 2017-02-21 09:23:14 --> Router Class Initialized
INFO - 2017-02-21 09:23:14 --> Output Class Initialized
INFO - 2017-02-21 09:23:14 --> Security Class Initialized
DEBUG - 2017-02-21 09:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:23:14 --> Input Class Initialized
INFO - 2017-02-21 09:23:14 --> Language Class Initialized
INFO - 2017-02-21 09:23:14 --> Loader Class Initialized
INFO - 2017-02-21 09:23:14 --> Helper loaded: url_helper
INFO - 2017-02-21 09:23:14 --> Helper loaded: language_helper
INFO - 2017-02-21 09:23:14 --> Helper loaded: html_helper
INFO - 2017-02-21 09:23:14 --> Helper loaded: form_helper
INFO - 2017-02-21 09:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:23:14 --> Controller Class Initialized
INFO - 2017-02-21 09:23:14 --> Database Driver Class Initialized
INFO - 2017-02-21 09:23:14 --> Model Class Initialized
INFO - 2017-02-21 09:23:14 --> Model Class Initialized
INFO - 2017-02-21 09:23:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:23:14 --> Config Class Initialized
INFO - 2017-02-21 09:23:14 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:23:14 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:23:14 --> Utf8 Class Initialized
INFO - 2017-02-21 09:23:14 --> URI Class Initialized
INFO - 2017-02-21 09:23:14 --> Router Class Initialized
INFO - 2017-02-21 09:23:14 --> Output Class Initialized
INFO - 2017-02-21 09:23:14 --> Security Class Initialized
DEBUG - 2017-02-21 09:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:23:14 --> Input Class Initialized
INFO - 2017-02-21 09:23:14 --> Language Class Initialized
INFO - 2017-02-21 09:23:14 --> Loader Class Initialized
INFO - 2017-02-21 09:23:14 --> Helper loaded: url_helper
INFO - 2017-02-21 09:23:14 --> Helper loaded: language_helper
INFO - 2017-02-21 09:23:14 --> Helper loaded: html_helper
INFO - 2017-02-21 09:23:14 --> Helper loaded: form_helper
INFO - 2017-02-21 09:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:23:14 --> Controller Class Initialized
INFO - 2017-02-21 09:23:14 --> Database Driver Class Initialized
INFO - 2017-02-21 09:23:14 --> Model Class Initialized
INFO - 2017-02-21 09:23:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:23:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 09:23:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 09:23:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 09:23:14 --> Final output sent to browser
DEBUG - 2017-02-21 09:23:14 --> Total execution time: 0.0907
INFO - 2017-02-21 09:32:40 --> Config Class Initialized
INFO - 2017-02-21 09:32:40 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:32:40 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:32:40 --> Utf8 Class Initialized
INFO - 2017-02-21 09:32:40 --> URI Class Initialized
INFO - 2017-02-21 09:32:40 --> Router Class Initialized
INFO - 2017-02-21 09:32:40 --> Output Class Initialized
INFO - 2017-02-21 09:32:40 --> Security Class Initialized
DEBUG - 2017-02-21 09:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:32:40 --> Input Class Initialized
INFO - 2017-02-21 09:32:40 --> Language Class Initialized
INFO - 2017-02-21 09:32:40 --> Loader Class Initialized
INFO - 2017-02-21 09:32:40 --> Helper loaded: url_helper
INFO - 2017-02-21 09:32:40 --> Helper loaded: language_helper
INFO - 2017-02-21 09:32:40 --> Helper loaded: html_helper
INFO - 2017-02-21 09:32:40 --> Helper loaded: form_helper
INFO - 2017-02-21 09:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:32:40 --> Controller Class Initialized
INFO - 2017-02-21 09:32:40 --> Database Driver Class Initialized
INFO - 2017-02-21 09:32:40 --> Model Class Initialized
INFO - 2017-02-21 09:32:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:32:40 --> Config Class Initialized
INFO - 2017-02-21 09:32:40 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:32:40 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:32:40 --> Utf8 Class Initialized
INFO - 2017-02-21 09:32:40 --> URI Class Initialized
INFO - 2017-02-21 09:32:40 --> Router Class Initialized
INFO - 2017-02-21 09:32:40 --> Output Class Initialized
INFO - 2017-02-21 09:32:40 --> Security Class Initialized
DEBUG - 2017-02-21 09:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:32:40 --> Input Class Initialized
INFO - 2017-02-21 09:32:40 --> Language Class Initialized
INFO - 2017-02-21 09:32:40 --> Loader Class Initialized
INFO - 2017-02-21 09:32:40 --> Helper loaded: url_helper
INFO - 2017-02-21 09:32:40 --> Helper loaded: language_helper
INFO - 2017-02-21 09:32:40 --> Helper loaded: html_helper
INFO - 2017-02-21 09:32:40 --> Helper loaded: form_helper
INFO - 2017-02-21 09:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:32:40 --> Controller Class Initialized
INFO - 2017-02-21 09:32:40 --> Database Driver Class Initialized
INFO - 2017-02-21 09:32:40 --> Model Class Initialized
INFO - 2017-02-21 09:32:40 --> Model Class Initialized
INFO - 2017-02-21 09:32:40 --> Model Class Initialized
INFO - 2017-02-21 09:32:40 --> Model Class Initialized
INFO - 2017-02-21 09:32:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-21 09:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:32:40 --> Final output sent to browser
DEBUG - 2017-02-21 09:32:40 --> Total execution time: 0.1200
INFO - 2017-02-21 09:33:13 --> Config Class Initialized
INFO - 2017-02-21 09:33:13 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:33:13 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:33:13 --> Utf8 Class Initialized
INFO - 2017-02-21 09:33:13 --> URI Class Initialized
INFO - 2017-02-21 09:33:13 --> Router Class Initialized
INFO - 2017-02-21 09:33:13 --> Output Class Initialized
INFO - 2017-02-21 09:33:13 --> Security Class Initialized
DEBUG - 2017-02-21 09:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:33:13 --> Input Class Initialized
INFO - 2017-02-21 09:33:13 --> Language Class Initialized
INFO - 2017-02-21 09:33:13 --> Loader Class Initialized
INFO - 2017-02-21 09:33:13 --> Helper loaded: url_helper
INFO - 2017-02-21 09:33:13 --> Helper loaded: language_helper
INFO - 2017-02-21 09:33:13 --> Helper loaded: html_helper
INFO - 2017-02-21 09:33:13 --> Helper loaded: form_helper
INFO - 2017-02-21 09:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:33:13 --> Controller Class Initialized
INFO - 2017-02-21 09:33:13 --> Database Driver Class Initialized
INFO - 2017-02-21 09:33:13 --> Model Class Initialized
INFO - 2017-02-21 09:33:13 --> Model Class Initialized
INFO - 2017-02-21 09:33:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-21 09:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:33:13 --> Final output sent to browser
DEBUG - 2017-02-21 09:33:13 --> Total execution time: 0.2016
INFO - 2017-02-21 09:37:31 --> Config Class Initialized
INFO - 2017-02-21 09:37:31 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:37:31 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:37:31 --> Utf8 Class Initialized
INFO - 2017-02-21 09:37:31 --> URI Class Initialized
INFO - 2017-02-21 09:37:31 --> Router Class Initialized
INFO - 2017-02-21 09:37:31 --> Output Class Initialized
INFO - 2017-02-21 09:37:31 --> Security Class Initialized
DEBUG - 2017-02-21 09:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:37:31 --> Input Class Initialized
INFO - 2017-02-21 09:37:31 --> Language Class Initialized
INFO - 2017-02-21 09:37:31 --> Loader Class Initialized
INFO - 2017-02-21 09:37:31 --> Helper loaded: url_helper
INFO - 2017-02-21 09:37:31 --> Helper loaded: language_helper
INFO - 2017-02-21 09:37:31 --> Helper loaded: html_helper
INFO - 2017-02-21 09:37:31 --> Helper loaded: form_helper
INFO - 2017-02-21 09:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:37:31 --> Controller Class Initialized
INFO - 2017-02-21 09:37:31 --> Database Driver Class Initialized
INFO - 2017-02-21 09:37:31 --> Model Class Initialized
INFO - 2017-02-21 09:37:31 --> Model Class Initialized
INFO - 2017-02-21 09:37:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:37:31 --> Model Class Initialized
INFO - 2017-02-21 09:37:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:37:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-21 09:37:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:37:31 --> Final output sent to browser
DEBUG - 2017-02-21 09:37:31 --> Total execution time: 0.2333
INFO - 2017-02-21 09:41:07 --> Config Class Initialized
INFO - 2017-02-21 09:41:07 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:41:07 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:41:07 --> Utf8 Class Initialized
INFO - 2017-02-21 09:41:07 --> URI Class Initialized
INFO - 2017-02-21 09:41:07 --> Router Class Initialized
INFO - 2017-02-21 09:41:07 --> Output Class Initialized
INFO - 2017-02-21 09:41:07 --> Security Class Initialized
DEBUG - 2017-02-21 09:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:41:07 --> Input Class Initialized
INFO - 2017-02-21 09:41:07 --> Language Class Initialized
INFO - 2017-02-21 09:41:07 --> Loader Class Initialized
INFO - 2017-02-21 09:41:07 --> Helper loaded: url_helper
INFO - 2017-02-21 09:41:07 --> Helper loaded: language_helper
INFO - 2017-02-21 09:41:07 --> Helper loaded: html_helper
INFO - 2017-02-21 09:41:07 --> Helper loaded: form_helper
INFO - 2017-02-21 09:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:41:07 --> Controller Class Initialized
INFO - 2017-02-21 09:41:07 --> Database Driver Class Initialized
INFO - 2017-02-21 09:41:07 --> Model Class Initialized
INFO - 2017-02-21 09:41:07 --> Model Class Initialized
INFO - 2017-02-21 09:41:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:41:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:41:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 09:41:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:41:07 --> Final output sent to browser
DEBUG - 2017-02-21 09:41:07 --> Total execution time: 0.2133
INFO - 2017-02-21 09:41:10 --> Config Class Initialized
INFO - 2017-02-21 09:41:10 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:41:10 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:41:10 --> Utf8 Class Initialized
INFO - 2017-02-21 09:41:10 --> URI Class Initialized
INFO - 2017-02-21 09:41:10 --> Router Class Initialized
INFO - 2017-02-21 09:41:10 --> Output Class Initialized
INFO - 2017-02-21 09:41:10 --> Security Class Initialized
DEBUG - 2017-02-21 09:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:41:10 --> Input Class Initialized
INFO - 2017-02-21 09:41:10 --> Language Class Initialized
INFO - 2017-02-21 09:41:10 --> Loader Class Initialized
INFO - 2017-02-21 09:41:10 --> Helper loaded: url_helper
INFO - 2017-02-21 09:41:10 --> Helper loaded: language_helper
INFO - 2017-02-21 09:41:10 --> Helper loaded: html_helper
INFO - 2017-02-21 09:41:10 --> Helper loaded: form_helper
INFO - 2017-02-21 09:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:41:10 --> Controller Class Initialized
INFO - 2017-02-21 09:41:10 --> Database Driver Class Initialized
INFO - 2017-02-21 09:41:10 --> Model Class Initialized
INFO - 2017-02-21 09:41:10 --> Model Class Initialized
INFO - 2017-02-21 09:41:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:41:10 --> Model Class Initialized
INFO - 2017-02-21 09:41:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:41:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 09:41:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:41:10 --> Final output sent to browser
DEBUG - 2017-02-21 09:41:10 --> Total execution time: 0.1630
INFO - 2017-02-21 09:55:19 --> Config Class Initialized
INFO - 2017-02-21 09:55:19 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:55:19 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:55:19 --> Utf8 Class Initialized
INFO - 2017-02-21 09:55:19 --> URI Class Initialized
INFO - 2017-02-21 09:55:19 --> Router Class Initialized
INFO - 2017-02-21 09:55:19 --> Output Class Initialized
INFO - 2017-02-21 09:55:19 --> Security Class Initialized
DEBUG - 2017-02-21 09:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:55:19 --> Input Class Initialized
INFO - 2017-02-21 09:55:19 --> Language Class Initialized
INFO - 2017-02-21 09:55:19 --> Loader Class Initialized
INFO - 2017-02-21 09:55:19 --> Helper loaded: url_helper
INFO - 2017-02-21 09:55:19 --> Helper loaded: language_helper
INFO - 2017-02-21 09:55:19 --> Helper loaded: html_helper
INFO - 2017-02-21 09:55:19 --> Helper loaded: form_helper
INFO - 2017-02-21 09:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:55:19 --> Controller Class Initialized
INFO - 2017-02-21 09:55:19 --> Database Driver Class Initialized
INFO - 2017-02-21 09:55:19 --> Model Class Initialized
INFO - 2017-02-21 09:55:19 --> Model Class Initialized
INFO - 2017-02-21 09:55:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:55:19 --> Model Class Initialized
INFO - 2017-02-21 09:55:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:55:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 09:55:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:55:19 --> Final output sent to browser
DEBUG - 2017-02-21 09:55:19 --> Total execution time: 0.1318
INFO - 2017-02-21 09:57:49 --> Config Class Initialized
INFO - 2017-02-21 09:57:49 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:57:49 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:57:49 --> Utf8 Class Initialized
INFO - 2017-02-21 09:57:49 --> URI Class Initialized
INFO - 2017-02-21 09:57:49 --> Router Class Initialized
INFO - 2017-02-21 09:57:49 --> Output Class Initialized
INFO - 2017-02-21 09:57:49 --> Security Class Initialized
DEBUG - 2017-02-21 09:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:57:49 --> Input Class Initialized
INFO - 2017-02-21 09:57:49 --> Language Class Initialized
INFO - 2017-02-21 09:57:49 --> Loader Class Initialized
INFO - 2017-02-21 09:57:49 --> Helper loaded: url_helper
INFO - 2017-02-21 09:57:49 --> Helper loaded: language_helper
INFO - 2017-02-21 09:57:49 --> Helper loaded: html_helper
INFO - 2017-02-21 09:57:49 --> Helper loaded: form_helper
INFO - 2017-02-21 09:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:57:49 --> Controller Class Initialized
INFO - 2017-02-21 09:57:49 --> Database Driver Class Initialized
INFO - 2017-02-21 09:57:49 --> Model Class Initialized
INFO - 2017-02-21 09:57:49 --> Model Class Initialized
INFO - 2017-02-21 09:57:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:57:49 --> Model Class Initialized
INFO - 2017-02-21 09:57:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:57:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 09:57:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:57:49 --> Final output sent to browser
DEBUG - 2017-02-21 09:57:49 --> Total execution time: 0.1338
INFO - 2017-02-21 09:57:51 --> Config Class Initialized
INFO - 2017-02-21 09:57:51 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:57:51 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:57:51 --> Utf8 Class Initialized
INFO - 2017-02-21 09:57:51 --> URI Class Initialized
INFO - 2017-02-21 09:57:51 --> Router Class Initialized
INFO - 2017-02-21 09:57:51 --> Output Class Initialized
INFO - 2017-02-21 09:57:51 --> Security Class Initialized
DEBUG - 2017-02-21 09:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:57:51 --> Input Class Initialized
INFO - 2017-02-21 09:57:51 --> Language Class Initialized
INFO - 2017-02-21 09:57:51 --> Loader Class Initialized
INFO - 2017-02-21 09:57:51 --> Helper loaded: url_helper
INFO - 2017-02-21 09:57:51 --> Helper loaded: language_helper
INFO - 2017-02-21 09:57:51 --> Helper loaded: html_helper
INFO - 2017-02-21 09:57:51 --> Helper loaded: form_helper
INFO - 2017-02-21 09:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:57:51 --> Controller Class Initialized
INFO - 2017-02-21 09:57:51 --> Database Driver Class Initialized
INFO - 2017-02-21 09:57:51 --> Model Class Initialized
INFO - 2017-02-21 09:57:51 --> Model Class Initialized
INFO - 2017-02-21 09:57:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:57:51 --> Model Class Initialized
INFO - 2017-02-21 09:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 09:57:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:57:51 --> Final output sent to browser
DEBUG - 2017-02-21 09:57:51 --> Total execution time: 0.1498
INFO - 2017-02-21 09:57:53 --> Config Class Initialized
INFO - 2017-02-21 09:57:53 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:57:53 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:57:53 --> Utf8 Class Initialized
INFO - 2017-02-21 09:57:53 --> URI Class Initialized
INFO - 2017-02-21 09:57:53 --> Router Class Initialized
INFO - 2017-02-21 09:57:53 --> Output Class Initialized
INFO - 2017-02-21 09:57:53 --> Security Class Initialized
DEBUG - 2017-02-21 09:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:57:53 --> Input Class Initialized
INFO - 2017-02-21 09:57:53 --> Language Class Initialized
INFO - 2017-02-21 09:57:53 --> Loader Class Initialized
INFO - 2017-02-21 09:57:53 --> Helper loaded: url_helper
INFO - 2017-02-21 09:57:53 --> Helper loaded: language_helper
INFO - 2017-02-21 09:57:53 --> Helper loaded: html_helper
INFO - 2017-02-21 09:57:53 --> Helper loaded: form_helper
INFO - 2017-02-21 09:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:57:53 --> Controller Class Initialized
INFO - 2017-02-21 09:57:53 --> Database Driver Class Initialized
INFO - 2017-02-21 09:57:53 --> Model Class Initialized
INFO - 2017-02-21 09:57:53 --> Model Class Initialized
INFO - 2017-02-21 09:57:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:57:53 --> Model Class Initialized
INFO - 2017-02-21 09:57:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:57:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 09:57:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:57:53 --> Final output sent to browser
DEBUG - 2017-02-21 09:57:53 --> Total execution time: 0.1734
INFO - 2017-02-21 09:58:26 --> Config Class Initialized
INFO - 2017-02-21 09:58:26 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:58:26 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:58:26 --> Utf8 Class Initialized
INFO - 2017-02-21 09:58:26 --> URI Class Initialized
INFO - 2017-02-21 09:58:26 --> Router Class Initialized
INFO - 2017-02-21 09:58:26 --> Output Class Initialized
INFO - 2017-02-21 09:58:26 --> Security Class Initialized
DEBUG - 2017-02-21 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:58:26 --> Input Class Initialized
INFO - 2017-02-21 09:58:26 --> Language Class Initialized
INFO - 2017-02-21 09:58:26 --> Loader Class Initialized
INFO - 2017-02-21 09:58:26 --> Helper loaded: url_helper
INFO - 2017-02-21 09:58:26 --> Helper loaded: language_helper
INFO - 2017-02-21 09:58:26 --> Helper loaded: html_helper
INFO - 2017-02-21 09:58:26 --> Helper loaded: form_helper
INFO - 2017-02-21 09:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:58:26 --> Controller Class Initialized
INFO - 2017-02-21 09:58:26 --> Database Driver Class Initialized
INFO - 2017-02-21 09:58:26 --> Model Class Initialized
INFO - 2017-02-21 09:58:26 --> Model Class Initialized
INFO - 2017-02-21 09:58:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:58:26 --> Model Class Initialized
INFO - 2017-02-21 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:58:26 --> Final output sent to browser
DEBUG - 2017-02-21 09:58:26 --> Total execution time: 0.1321
INFO - 2017-02-21 09:59:06 --> Config Class Initialized
INFO - 2017-02-21 09:59:06 --> Hooks Class Initialized
DEBUG - 2017-02-21 09:59:06 --> UTF-8 Support Enabled
INFO - 2017-02-21 09:59:06 --> Utf8 Class Initialized
INFO - 2017-02-21 09:59:06 --> URI Class Initialized
INFO - 2017-02-21 09:59:06 --> Router Class Initialized
INFO - 2017-02-21 09:59:06 --> Output Class Initialized
INFO - 2017-02-21 09:59:06 --> Security Class Initialized
DEBUG - 2017-02-21 09:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 09:59:06 --> Input Class Initialized
INFO - 2017-02-21 09:59:06 --> Language Class Initialized
INFO - 2017-02-21 09:59:06 --> Loader Class Initialized
INFO - 2017-02-21 09:59:06 --> Helper loaded: url_helper
INFO - 2017-02-21 09:59:06 --> Helper loaded: language_helper
INFO - 2017-02-21 09:59:06 --> Helper loaded: html_helper
INFO - 2017-02-21 09:59:06 --> Helper loaded: form_helper
INFO - 2017-02-21 09:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 09:59:06 --> Controller Class Initialized
INFO - 2017-02-21 09:59:06 --> Database Driver Class Initialized
INFO - 2017-02-21 09:59:06 --> Model Class Initialized
INFO - 2017-02-21 09:59:06 --> Model Class Initialized
INFO - 2017-02-21 09:59:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 09:59:06 --> Model Class Initialized
INFO - 2017-02-21 09:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 09:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 09:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 09:59:06 --> Final output sent to browser
DEBUG - 2017-02-21 09:59:06 --> Total execution time: 0.1247
INFO - 2017-02-21 10:00:02 --> Config Class Initialized
INFO - 2017-02-21 10:00:02 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:00:02 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:00:02 --> Utf8 Class Initialized
INFO - 2017-02-21 10:00:02 --> URI Class Initialized
INFO - 2017-02-21 10:00:03 --> Router Class Initialized
INFO - 2017-02-21 10:00:03 --> Output Class Initialized
INFO - 2017-02-21 10:00:03 --> Security Class Initialized
DEBUG - 2017-02-21 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:00:03 --> Input Class Initialized
INFO - 2017-02-21 10:00:03 --> Language Class Initialized
INFO - 2017-02-21 10:00:03 --> Loader Class Initialized
INFO - 2017-02-21 10:00:03 --> Helper loaded: url_helper
INFO - 2017-02-21 10:00:03 --> Helper loaded: language_helper
INFO - 2017-02-21 10:00:03 --> Helper loaded: html_helper
INFO - 2017-02-21 10:00:03 --> Helper loaded: form_helper
INFO - 2017-02-21 10:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:00:03 --> Controller Class Initialized
INFO - 2017-02-21 10:00:03 --> Database Driver Class Initialized
INFO - 2017-02-21 10:00:03 --> Model Class Initialized
INFO - 2017-02-21 10:00:03 --> Model Class Initialized
INFO - 2017-02-21 10:00:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-21 10:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:00:03 --> Final output sent to browser
DEBUG - 2017-02-21 10:00:03 --> Total execution time: 0.2131
INFO - 2017-02-21 10:00:05 --> Config Class Initialized
INFO - 2017-02-21 10:00:05 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:00:05 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:00:05 --> Utf8 Class Initialized
INFO - 2017-02-21 10:00:05 --> URI Class Initialized
INFO - 2017-02-21 10:00:05 --> Router Class Initialized
INFO - 2017-02-21 10:00:05 --> Output Class Initialized
INFO - 2017-02-21 10:00:05 --> Security Class Initialized
DEBUG - 2017-02-21 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:00:05 --> Input Class Initialized
INFO - 2017-02-21 10:00:05 --> Language Class Initialized
INFO - 2017-02-21 10:00:05 --> Loader Class Initialized
INFO - 2017-02-21 10:00:05 --> Helper loaded: url_helper
INFO - 2017-02-21 10:00:05 --> Helper loaded: language_helper
INFO - 2017-02-21 10:00:05 --> Helper loaded: html_helper
INFO - 2017-02-21 10:00:05 --> Helper loaded: form_helper
INFO - 2017-02-21 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:00:05 --> Controller Class Initialized
INFO - 2017-02-21 10:00:05 --> Database Driver Class Initialized
INFO - 2017-02-21 10:00:05 --> Model Class Initialized
INFO - 2017-02-21 10:00:05 --> Model Class Initialized
INFO - 2017-02-21 10:00:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:00:05 --> Model Class Initialized
INFO - 2017-02-21 10:00:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:00:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-21 10:00:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:00:05 --> Final output sent to browser
DEBUG - 2017-02-21 10:00:05 --> Total execution time: 0.2256
INFO - 2017-02-21 10:00:40 --> Config Class Initialized
INFO - 2017-02-21 10:00:40 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:00:40 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:00:40 --> Utf8 Class Initialized
INFO - 2017-02-21 10:00:40 --> URI Class Initialized
INFO - 2017-02-21 10:00:40 --> Router Class Initialized
INFO - 2017-02-21 10:00:40 --> Output Class Initialized
INFO - 2017-02-21 10:00:40 --> Security Class Initialized
DEBUG - 2017-02-21 10:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:00:40 --> Input Class Initialized
INFO - 2017-02-21 10:00:40 --> Language Class Initialized
INFO - 2017-02-21 10:00:40 --> Loader Class Initialized
INFO - 2017-02-21 10:00:40 --> Helper loaded: url_helper
INFO - 2017-02-21 10:00:40 --> Helper loaded: language_helper
INFO - 2017-02-21 10:00:40 --> Helper loaded: html_helper
INFO - 2017-02-21 10:00:40 --> Helper loaded: form_helper
INFO - 2017-02-21 10:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:00:40 --> Controller Class Initialized
INFO - 2017-02-21 10:00:40 --> Database Driver Class Initialized
INFO - 2017-02-21 10:00:40 --> Model Class Initialized
INFO - 2017-02-21 10:00:40 --> Model Class Initialized
INFO - 2017-02-21 10:00:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:00:40 --> Model Class Initialized
INFO - 2017-02-21 10:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-21 10:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:00:40 --> Final output sent to browser
DEBUG - 2017-02-21 10:00:40 --> Total execution time: 0.1360
INFO - 2017-02-21 10:00:46 --> Config Class Initialized
INFO - 2017-02-21 10:00:46 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:00:46 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:00:46 --> Utf8 Class Initialized
INFO - 2017-02-21 10:00:46 --> URI Class Initialized
INFO - 2017-02-21 10:00:46 --> Router Class Initialized
INFO - 2017-02-21 10:00:46 --> Output Class Initialized
INFO - 2017-02-21 10:00:46 --> Security Class Initialized
DEBUG - 2017-02-21 10:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:00:46 --> Input Class Initialized
INFO - 2017-02-21 10:00:46 --> Language Class Initialized
INFO - 2017-02-21 10:00:46 --> Loader Class Initialized
INFO - 2017-02-21 10:00:46 --> Helper loaded: url_helper
INFO - 2017-02-21 10:00:46 --> Helper loaded: language_helper
INFO - 2017-02-21 10:00:46 --> Helper loaded: html_helper
INFO - 2017-02-21 10:00:46 --> Helper loaded: form_helper
INFO - 2017-02-21 10:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:00:46 --> Controller Class Initialized
INFO - 2017-02-21 10:00:46 --> Database Driver Class Initialized
INFO - 2017-02-21 10:00:46 --> Model Class Initialized
INFO - 2017-02-21 10:00:46 --> Model Class Initialized
INFO - 2017-02-21 10:00:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:00:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:00:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-21 10:00:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:00:46 --> Final output sent to browser
DEBUG - 2017-02-21 10:00:46 --> Total execution time: 0.1982
INFO - 2017-02-21 10:03:24 --> Config Class Initialized
INFO - 2017-02-21 10:03:24 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:03:24 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:03:24 --> Utf8 Class Initialized
INFO - 2017-02-21 10:03:24 --> URI Class Initialized
INFO - 2017-02-21 10:03:24 --> Router Class Initialized
INFO - 2017-02-21 10:03:24 --> Output Class Initialized
INFO - 2017-02-21 10:03:24 --> Security Class Initialized
DEBUG - 2017-02-21 10:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:03:24 --> Input Class Initialized
INFO - 2017-02-21 10:03:24 --> Language Class Initialized
INFO - 2017-02-21 10:03:24 --> Loader Class Initialized
INFO - 2017-02-21 10:03:24 --> Helper loaded: url_helper
INFO - 2017-02-21 10:03:24 --> Helper loaded: language_helper
INFO - 2017-02-21 10:03:24 --> Helper loaded: html_helper
INFO - 2017-02-21 10:03:24 --> Helper loaded: form_helper
INFO - 2017-02-21 10:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:03:24 --> Controller Class Initialized
INFO - 2017-02-21 10:03:24 --> Database Driver Class Initialized
INFO - 2017-02-21 10:03:24 --> Model Class Initialized
INFO - 2017-02-21 10:03:24 --> Model Class Initialized
INFO - 2017-02-21 10:03:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:03:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:03:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-21 10:03:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:03:24 --> Final output sent to browser
DEBUG - 2017-02-21 10:03:24 --> Total execution time: 0.2131
INFO - 2017-02-21 10:03:32 --> Config Class Initialized
INFO - 2017-02-21 10:03:32 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:03:32 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:03:32 --> Utf8 Class Initialized
INFO - 2017-02-21 10:03:32 --> URI Class Initialized
INFO - 2017-02-21 10:03:32 --> Router Class Initialized
INFO - 2017-02-21 10:03:32 --> Output Class Initialized
INFO - 2017-02-21 10:03:32 --> Security Class Initialized
DEBUG - 2017-02-21 10:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:03:32 --> Input Class Initialized
INFO - 2017-02-21 10:03:32 --> Language Class Initialized
INFO - 2017-02-21 10:03:32 --> Loader Class Initialized
INFO - 2017-02-21 10:03:32 --> Helper loaded: url_helper
INFO - 2017-02-21 10:03:32 --> Helper loaded: language_helper
INFO - 2017-02-21 10:03:32 --> Helper loaded: html_helper
INFO - 2017-02-21 10:03:32 --> Helper loaded: form_helper
INFO - 2017-02-21 10:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:03:32 --> Controller Class Initialized
INFO - 2017-02-21 10:03:32 --> Database Driver Class Initialized
INFO - 2017-02-21 10:03:32 --> Model Class Initialized
INFO - 2017-02-21 10:03:32 --> Model Class Initialized
INFO - 2017-02-21 10:03:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:03:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:03:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 10:03:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:03:32 --> Final output sent to browser
DEBUG - 2017-02-21 10:03:32 --> Total execution time: 0.1888
INFO - 2017-02-21 10:03:56 --> Config Class Initialized
INFO - 2017-02-21 10:03:56 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:03:56 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:03:56 --> Utf8 Class Initialized
INFO - 2017-02-21 10:03:56 --> URI Class Initialized
INFO - 2017-02-21 10:03:56 --> Router Class Initialized
INFO - 2017-02-21 10:03:56 --> Output Class Initialized
INFO - 2017-02-21 10:03:56 --> Security Class Initialized
DEBUG - 2017-02-21 10:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:03:56 --> Input Class Initialized
INFO - 2017-02-21 10:03:56 --> Language Class Initialized
INFO - 2017-02-21 10:03:56 --> Loader Class Initialized
INFO - 2017-02-21 10:03:56 --> Helper loaded: url_helper
INFO - 2017-02-21 10:03:56 --> Helper loaded: language_helper
INFO - 2017-02-21 10:03:56 --> Helper loaded: html_helper
INFO - 2017-02-21 10:03:56 --> Helper loaded: form_helper
INFO - 2017-02-21 10:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:03:56 --> Controller Class Initialized
INFO - 2017-02-21 10:03:56 --> Database Driver Class Initialized
INFO - 2017-02-21 10:03:56 --> Model Class Initialized
INFO - 2017-02-21 10:03:56 --> Model Class Initialized
INFO - 2017-02-21 10:03:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:03:56 --> Model Class Initialized
INFO - 2017-02-21 10:03:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:03:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 10:03:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:03:56 --> Final output sent to browser
DEBUG - 2017-02-21 10:03:56 --> Total execution time: 0.1634
INFO - 2017-02-21 10:08:47 --> Config Class Initialized
INFO - 2017-02-21 10:08:47 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:08:47 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:08:47 --> Utf8 Class Initialized
INFO - 2017-02-21 10:08:47 --> URI Class Initialized
INFO - 2017-02-21 10:08:47 --> Router Class Initialized
INFO - 2017-02-21 10:08:47 --> Output Class Initialized
INFO - 2017-02-21 10:08:47 --> Security Class Initialized
DEBUG - 2017-02-21 10:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:08:47 --> Input Class Initialized
INFO - 2017-02-21 10:08:47 --> Language Class Initialized
INFO - 2017-02-21 10:08:47 --> Loader Class Initialized
INFO - 2017-02-21 10:08:47 --> Helper loaded: url_helper
INFO - 2017-02-21 10:08:47 --> Helper loaded: language_helper
INFO - 2017-02-21 10:08:47 --> Helper loaded: html_helper
INFO - 2017-02-21 10:08:47 --> Helper loaded: form_helper
INFO - 2017-02-21 10:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:08:47 --> Controller Class Initialized
INFO - 2017-02-21 10:08:47 --> Database Driver Class Initialized
INFO - 2017-02-21 10:08:47 --> Model Class Initialized
INFO - 2017-02-21 10:08:47 --> Model Class Initialized
INFO - 2017-02-21 10:08:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:08:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
ERROR - 2017-02-21 10:08:47 --> Severity: Notice --> Undefined index: ist11 C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php 101
INFO - 2017-02-21 10:08:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 10:08:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:08:47 --> Final output sent to browser
DEBUG - 2017-02-21 10:08:47 --> Total execution time: 0.2619
INFO - 2017-02-21 10:08:58 --> Config Class Initialized
INFO - 2017-02-21 10:08:58 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:08:58 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:08:58 --> Utf8 Class Initialized
INFO - 2017-02-21 10:08:58 --> URI Class Initialized
INFO - 2017-02-21 10:08:58 --> Router Class Initialized
INFO - 2017-02-21 10:08:58 --> Output Class Initialized
INFO - 2017-02-21 10:08:58 --> Security Class Initialized
DEBUG - 2017-02-21 10:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:08:58 --> Input Class Initialized
INFO - 2017-02-21 10:08:58 --> Language Class Initialized
INFO - 2017-02-21 10:08:58 --> Loader Class Initialized
INFO - 2017-02-21 10:08:58 --> Helper loaded: url_helper
INFO - 2017-02-21 10:08:58 --> Helper loaded: language_helper
INFO - 2017-02-21 10:08:58 --> Helper loaded: html_helper
INFO - 2017-02-21 10:08:58 --> Helper loaded: form_helper
INFO - 2017-02-21 10:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:08:58 --> Controller Class Initialized
INFO - 2017-02-21 10:08:58 --> Database Driver Class Initialized
INFO - 2017-02-21 10:08:58 --> Model Class Initialized
INFO - 2017-02-21 10:08:58 --> Model Class Initialized
INFO - 2017-02-21 10:08:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:08:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:08:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 10:08:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:08:58 --> Final output sent to browser
DEBUG - 2017-02-21 10:08:58 --> Total execution time: 0.2038
INFO - 2017-02-21 10:09:10 --> Config Class Initialized
INFO - 2017-02-21 10:09:10 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:09:10 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:09:10 --> Utf8 Class Initialized
INFO - 2017-02-21 10:09:10 --> URI Class Initialized
INFO - 2017-02-21 10:09:10 --> Router Class Initialized
INFO - 2017-02-21 10:09:10 --> Output Class Initialized
INFO - 2017-02-21 10:09:10 --> Security Class Initialized
DEBUG - 2017-02-21 10:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:09:10 --> Input Class Initialized
INFO - 2017-02-21 10:09:10 --> Language Class Initialized
INFO - 2017-02-21 10:09:10 --> Loader Class Initialized
INFO - 2017-02-21 10:09:10 --> Helper loaded: url_helper
INFO - 2017-02-21 10:09:10 --> Helper loaded: language_helper
INFO - 2017-02-21 10:09:10 --> Helper loaded: html_helper
INFO - 2017-02-21 10:09:10 --> Helper loaded: form_helper
INFO - 2017-02-21 10:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:09:10 --> Controller Class Initialized
INFO - 2017-02-21 10:09:10 --> Database Driver Class Initialized
INFO - 2017-02-21 10:09:10 --> Model Class Initialized
INFO - 2017-02-21 10:09:10 --> Model Class Initialized
INFO - 2017-02-21 10:09:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:09:10 --> Config Class Initialized
INFO - 2017-02-21 10:09:10 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:09:10 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:09:10 --> Utf8 Class Initialized
INFO - 2017-02-21 10:09:10 --> URI Class Initialized
INFO - 2017-02-21 10:09:10 --> Router Class Initialized
INFO - 2017-02-21 10:09:10 --> Output Class Initialized
INFO - 2017-02-21 10:09:10 --> Security Class Initialized
DEBUG - 2017-02-21 10:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:09:10 --> Input Class Initialized
INFO - 2017-02-21 10:09:10 --> Language Class Initialized
INFO - 2017-02-21 10:09:10 --> Loader Class Initialized
INFO - 2017-02-21 10:09:10 --> Helper loaded: url_helper
INFO - 2017-02-21 10:09:10 --> Helper loaded: language_helper
INFO - 2017-02-21 10:09:10 --> Helper loaded: html_helper
INFO - 2017-02-21 10:09:10 --> Helper loaded: form_helper
INFO - 2017-02-21 10:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:09:10 --> Controller Class Initialized
INFO - 2017-02-21 10:09:10 --> Database Driver Class Initialized
INFO - 2017-02-21 10:09:10 --> Model Class Initialized
INFO - 2017-02-21 10:09:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 10:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 10:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 10:09:10 --> Final output sent to browser
DEBUG - 2017-02-21 10:09:10 --> Total execution time: 0.0706
INFO - 2017-02-21 10:09:26 --> Config Class Initialized
INFO - 2017-02-21 10:09:26 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:09:26 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:09:26 --> Utf8 Class Initialized
INFO - 2017-02-21 10:09:26 --> URI Class Initialized
INFO - 2017-02-21 10:09:26 --> Router Class Initialized
INFO - 2017-02-21 10:09:26 --> Output Class Initialized
INFO - 2017-02-21 10:09:26 --> Security Class Initialized
DEBUG - 2017-02-21 10:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:09:26 --> Input Class Initialized
INFO - 2017-02-21 10:09:26 --> Language Class Initialized
INFO - 2017-02-21 10:09:26 --> Loader Class Initialized
INFO - 2017-02-21 10:09:26 --> Helper loaded: url_helper
INFO - 2017-02-21 10:09:26 --> Helper loaded: language_helper
INFO - 2017-02-21 10:09:26 --> Helper loaded: html_helper
INFO - 2017-02-21 10:09:26 --> Helper loaded: form_helper
INFO - 2017-02-21 10:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:09:26 --> Controller Class Initialized
INFO - 2017-02-21 10:09:26 --> Database Driver Class Initialized
INFO - 2017-02-21 10:09:26 --> Model Class Initialized
INFO - 2017-02-21 10:09:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:09:26 --> Form Validation Class Initialized
INFO - 2017-02-21 10:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 10:09:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:09:26 --> Final output sent to browser
DEBUG - 2017-02-21 10:09:26 --> Total execution time: 0.1209
INFO - 2017-02-21 10:19:10 --> Config Class Initialized
INFO - 2017-02-21 10:19:10 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:19:10 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:19:10 --> Utf8 Class Initialized
INFO - 2017-02-21 10:19:10 --> URI Class Initialized
INFO - 2017-02-21 10:19:10 --> Router Class Initialized
INFO - 2017-02-21 10:19:10 --> Output Class Initialized
INFO - 2017-02-21 10:19:10 --> Security Class Initialized
DEBUG - 2017-02-21 10:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:19:10 --> Input Class Initialized
INFO - 2017-02-21 10:19:10 --> Language Class Initialized
INFO - 2017-02-21 10:19:10 --> Loader Class Initialized
INFO - 2017-02-21 10:19:10 --> Helper loaded: url_helper
INFO - 2017-02-21 10:19:10 --> Helper loaded: language_helper
INFO - 2017-02-21 10:19:10 --> Helper loaded: html_helper
INFO - 2017-02-21 10:19:10 --> Helper loaded: form_helper
INFO - 2017-02-21 10:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:19:10 --> Controller Class Initialized
INFO - 2017-02-21 10:19:10 --> Database Driver Class Initialized
INFO - 2017-02-21 10:19:10 --> Model Class Initialized
INFO - 2017-02-21 10:19:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:19:10 --> Form Validation Class Initialized
INFO - 2017-02-21 10:19:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:19:10 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 10:19:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 10:19:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:19:10 --> Final output sent to browser
DEBUG - 2017-02-21 10:19:10 --> Total execution time: 0.1343
INFO - 2017-02-21 10:22:59 --> Config Class Initialized
INFO - 2017-02-21 10:22:59 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:22:59 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:22:59 --> Utf8 Class Initialized
INFO - 2017-02-21 10:22:59 --> URI Class Initialized
INFO - 2017-02-21 10:22:59 --> Router Class Initialized
INFO - 2017-02-21 10:22:59 --> Output Class Initialized
INFO - 2017-02-21 10:22:59 --> Security Class Initialized
DEBUG - 2017-02-21 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:22:59 --> Input Class Initialized
INFO - 2017-02-21 10:22:59 --> Language Class Initialized
INFO - 2017-02-21 10:22:59 --> Loader Class Initialized
INFO - 2017-02-21 10:22:59 --> Helper loaded: url_helper
INFO - 2017-02-21 10:22:59 --> Helper loaded: language_helper
INFO - 2017-02-21 10:22:59 --> Helper loaded: html_helper
INFO - 2017-02-21 10:22:59 --> Helper loaded: form_helper
INFO - 2017-02-21 10:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:22:59 --> Controller Class Initialized
INFO - 2017-02-21 10:22:59 --> Database Driver Class Initialized
INFO - 2017-02-21 10:22:59 --> Model Class Initialized
INFO - 2017-02-21 10:22:59 --> Model Class Initialized
INFO - 2017-02-21 10:22:59 --> Model Class Initialized
INFO - 2017-02-21 10:22:59 --> Model Class Initialized
INFO - 2017-02-21 10:22:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:22:59 --> Config Class Initialized
INFO - 2017-02-21 10:22:59 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:22:59 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:22:59 --> Utf8 Class Initialized
INFO - 2017-02-21 10:22:59 --> URI Class Initialized
INFO - 2017-02-21 10:22:59 --> Router Class Initialized
INFO - 2017-02-21 10:22:59 --> Output Class Initialized
INFO - 2017-02-21 10:22:59 --> Security Class Initialized
DEBUG - 2017-02-21 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:22:59 --> Input Class Initialized
INFO - 2017-02-21 10:22:59 --> Language Class Initialized
INFO - 2017-02-21 10:22:59 --> Loader Class Initialized
INFO - 2017-02-21 10:22:59 --> Helper loaded: url_helper
INFO - 2017-02-21 10:22:59 --> Helper loaded: language_helper
INFO - 2017-02-21 10:22:59 --> Helper loaded: html_helper
INFO - 2017-02-21 10:22:59 --> Helper loaded: form_helper
INFO - 2017-02-21 10:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:22:59 --> Controller Class Initialized
INFO - 2017-02-21 10:22:59 --> Database Driver Class Initialized
INFO - 2017-02-21 10:22:59 --> Model Class Initialized
INFO - 2017-02-21 10:22:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:22:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 10:22:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 10:22:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 10:22:59 --> Final output sent to browser
DEBUG - 2017-02-21 10:22:59 --> Total execution time: 0.0933
INFO - 2017-02-21 10:23:07 --> Config Class Initialized
INFO - 2017-02-21 10:23:07 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:23:07 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:23:07 --> Utf8 Class Initialized
INFO - 2017-02-21 10:23:07 --> URI Class Initialized
INFO - 2017-02-21 10:23:07 --> Router Class Initialized
INFO - 2017-02-21 10:23:07 --> Output Class Initialized
INFO - 2017-02-21 10:23:07 --> Security Class Initialized
DEBUG - 2017-02-21 10:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:23:07 --> Input Class Initialized
INFO - 2017-02-21 10:23:07 --> Language Class Initialized
INFO - 2017-02-21 10:23:07 --> Loader Class Initialized
INFO - 2017-02-21 10:23:07 --> Helper loaded: url_helper
INFO - 2017-02-21 10:23:07 --> Helper loaded: language_helper
INFO - 2017-02-21 10:23:07 --> Helper loaded: html_helper
INFO - 2017-02-21 10:23:07 --> Helper loaded: form_helper
INFO - 2017-02-21 10:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:23:07 --> Controller Class Initialized
INFO - 2017-02-21 10:23:07 --> Database Driver Class Initialized
INFO - 2017-02-21 10:23:07 --> Model Class Initialized
INFO - 2017-02-21 10:23:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:23:08 --> Config Class Initialized
INFO - 2017-02-21 10:23:08 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:23:08 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:23:08 --> Utf8 Class Initialized
INFO - 2017-02-21 10:23:08 --> URI Class Initialized
INFO - 2017-02-21 10:23:08 --> Router Class Initialized
INFO - 2017-02-21 10:23:08 --> Output Class Initialized
INFO - 2017-02-21 10:23:08 --> Security Class Initialized
DEBUG - 2017-02-21 10:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:23:08 --> Input Class Initialized
INFO - 2017-02-21 10:23:08 --> Language Class Initialized
INFO - 2017-02-21 10:23:08 --> Loader Class Initialized
INFO - 2017-02-21 10:23:08 --> Helper loaded: url_helper
INFO - 2017-02-21 10:23:08 --> Helper loaded: language_helper
INFO - 2017-02-21 10:23:08 --> Helper loaded: html_helper
INFO - 2017-02-21 10:23:08 --> Helper loaded: form_helper
INFO - 2017-02-21 10:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:23:08 --> Controller Class Initialized
INFO - 2017-02-21 10:23:08 --> Database Driver Class Initialized
INFO - 2017-02-21 10:23:08 --> Model Class Initialized
INFO - 2017-02-21 10:23:08 --> Model Class Initialized
INFO - 2017-02-21 10:23:08 --> Model Class Initialized
INFO - 2017-02-21 10:23:08 --> Model Class Initialized
INFO - 2017-02-21 10:23:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:23:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:23:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-21 10:23:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:23:08 --> Final output sent to browser
DEBUG - 2017-02-21 10:23:08 --> Total execution time: 0.1190
INFO - 2017-02-21 10:23:21 --> Config Class Initialized
INFO - 2017-02-21 10:23:21 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:23:21 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:23:21 --> Utf8 Class Initialized
INFO - 2017-02-21 10:23:21 --> URI Class Initialized
INFO - 2017-02-21 10:23:21 --> Router Class Initialized
INFO - 2017-02-21 10:23:21 --> Output Class Initialized
INFO - 2017-02-21 10:23:21 --> Security Class Initialized
DEBUG - 2017-02-21 10:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:23:21 --> Input Class Initialized
INFO - 2017-02-21 10:23:21 --> Language Class Initialized
INFO - 2017-02-21 10:23:21 --> Loader Class Initialized
INFO - 2017-02-21 10:23:21 --> Helper loaded: url_helper
INFO - 2017-02-21 10:23:21 --> Helper loaded: language_helper
INFO - 2017-02-21 10:23:21 --> Helper loaded: html_helper
INFO - 2017-02-21 10:23:21 --> Helper loaded: form_helper
INFO - 2017-02-21 10:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:23:21 --> Controller Class Initialized
INFO - 2017-02-21 10:23:21 --> Database Driver Class Initialized
INFO - 2017-02-21 10:23:21 --> Model Class Initialized
INFO - 2017-02-21 10:23:21 --> Model Class Initialized
INFO - 2017-02-21 10:23:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-21 10:23:21 --> Could not find the language line "import_user"
INFO - 2017-02-21 10:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-21 10:23:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:23:21 --> Final output sent to browser
DEBUG - 2017-02-21 10:23:21 --> Total execution time: 0.1032
INFO - 2017-02-21 10:23:48 --> Config Class Initialized
INFO - 2017-02-21 10:23:48 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:23:48 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:23:48 --> Utf8 Class Initialized
INFO - 2017-02-21 10:23:48 --> URI Class Initialized
INFO - 2017-02-21 10:23:48 --> Router Class Initialized
INFO - 2017-02-21 10:23:48 --> Output Class Initialized
INFO - 2017-02-21 10:23:49 --> Security Class Initialized
DEBUG - 2017-02-21 10:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:23:49 --> Input Class Initialized
INFO - 2017-02-21 10:23:49 --> Language Class Initialized
INFO - 2017-02-21 10:23:49 --> Loader Class Initialized
INFO - 2017-02-21 10:23:49 --> Helper loaded: url_helper
INFO - 2017-02-21 10:23:49 --> Helper loaded: language_helper
INFO - 2017-02-21 10:23:49 --> Helper loaded: html_helper
INFO - 2017-02-21 10:23:49 --> Helper loaded: form_helper
INFO - 2017-02-21 10:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:23:49 --> Controller Class Initialized
INFO - 2017-02-21 10:23:49 --> Database Driver Class Initialized
INFO - 2017-02-21 10:23:49 --> Model Class Initialized
INFO - 2017-02-21 10:23:49 --> Model Class Initialized
INFO - 2017-02-21 10:23:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:23:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-21 10:23:49 --> Could not find the language line "import_user"
INFO - 2017-02-21 10:23:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-21 10:23:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:23:49 --> Final output sent to browser
DEBUG - 2017-02-21 10:23:49 --> Total execution time: 0.0990
INFO - 2017-02-21 10:23:50 --> Config Class Initialized
INFO - 2017-02-21 10:23:50 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:23:50 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:23:50 --> Utf8 Class Initialized
INFO - 2017-02-21 10:23:50 --> URI Class Initialized
INFO - 2017-02-21 10:23:50 --> Router Class Initialized
INFO - 2017-02-21 10:23:50 --> Output Class Initialized
INFO - 2017-02-21 10:23:50 --> Security Class Initialized
DEBUG - 2017-02-21 10:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:23:50 --> Input Class Initialized
INFO - 2017-02-21 10:23:50 --> Language Class Initialized
INFO - 2017-02-21 10:23:50 --> Loader Class Initialized
INFO - 2017-02-21 10:23:50 --> Helper loaded: url_helper
INFO - 2017-02-21 10:23:50 --> Helper loaded: language_helper
INFO - 2017-02-21 10:23:50 --> Helper loaded: html_helper
INFO - 2017-02-21 10:23:50 --> Helper loaded: form_helper
INFO - 2017-02-21 10:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:23:50 --> Controller Class Initialized
INFO - 2017-02-21 10:23:50 --> Database Driver Class Initialized
INFO - 2017-02-21 10:23:50 --> Model Class Initialized
INFO - 2017-02-21 10:23:50 --> Model Class Initialized
INFO - 2017-02-21 10:23:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\administrator.php
INFO - 2017-02-21 10:23:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:23:50 --> Final output sent to browser
DEBUG - 2017-02-21 10:23:50 --> Total execution time: 0.1230
INFO - 2017-02-21 10:23:53 --> Config Class Initialized
INFO - 2017-02-21 10:23:53 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:23:53 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:23:53 --> Utf8 Class Initialized
INFO - 2017-02-21 10:23:53 --> URI Class Initialized
INFO - 2017-02-21 10:23:53 --> Router Class Initialized
INFO - 2017-02-21 10:23:53 --> Output Class Initialized
INFO - 2017-02-21 10:23:53 --> Security Class Initialized
DEBUG - 2017-02-21 10:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:23:53 --> Input Class Initialized
INFO - 2017-02-21 10:23:53 --> Language Class Initialized
INFO - 2017-02-21 10:23:53 --> Loader Class Initialized
INFO - 2017-02-21 10:23:53 --> Helper loaded: url_helper
INFO - 2017-02-21 10:23:53 --> Helper loaded: language_helper
INFO - 2017-02-21 10:23:53 --> Helper loaded: html_helper
INFO - 2017-02-21 10:23:53 --> Helper loaded: form_helper
INFO - 2017-02-21 10:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:23:53 --> Controller Class Initialized
INFO - 2017-02-21 10:23:53 --> Database Driver Class Initialized
INFO - 2017-02-21 10:23:53 --> Model Class Initialized
INFO - 2017-02-21 10:23:53 --> Model Class Initialized
INFO - 2017-02-21 10:23:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-21 10:23:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:23:53 --> Final output sent to browser
DEBUG - 2017-02-21 10:23:53 --> Total execution time: 0.1079
INFO - 2017-02-21 10:24:09 --> Config Class Initialized
INFO - 2017-02-21 10:24:09 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:24:09 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:24:09 --> Utf8 Class Initialized
INFO - 2017-02-21 10:24:09 --> URI Class Initialized
INFO - 2017-02-21 10:24:09 --> Router Class Initialized
INFO - 2017-02-21 10:24:09 --> Output Class Initialized
INFO - 2017-02-21 10:24:09 --> Security Class Initialized
DEBUG - 2017-02-21 10:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:24:09 --> Input Class Initialized
INFO - 2017-02-21 10:24:09 --> Language Class Initialized
INFO - 2017-02-21 10:24:09 --> Loader Class Initialized
INFO - 2017-02-21 10:24:09 --> Helper loaded: url_helper
INFO - 2017-02-21 10:24:09 --> Helper loaded: language_helper
INFO - 2017-02-21 10:24:09 --> Helper loaded: html_helper
INFO - 2017-02-21 10:24:09 --> Helper loaded: form_helper
INFO - 2017-02-21 10:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:24:09 --> Controller Class Initialized
INFO - 2017-02-21 10:24:09 --> Database Driver Class Initialized
INFO - 2017-02-21 10:24:09 --> Model Class Initialized
INFO - 2017-02-21 10:24:09 --> Model Class Initialized
INFO - 2017-02-21 10:24:09 --> Model Class Initialized
INFO - 2017-02-21 10:24:09 --> Model Class Initialized
INFO - 2017-02-21 10:24:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-21 10:24:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:24:09 --> Final output sent to browser
DEBUG - 2017-02-21 10:24:09 --> Total execution time: 0.1032
INFO - 2017-02-21 10:30:22 --> Config Class Initialized
INFO - 2017-02-21 10:30:22 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:30:22 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:30:22 --> Utf8 Class Initialized
INFO - 2017-02-21 10:30:22 --> URI Class Initialized
DEBUG - 2017-02-21 10:30:22 --> No URI present. Default controller set.
INFO - 2017-02-21 10:30:22 --> Router Class Initialized
INFO - 2017-02-21 10:30:22 --> Output Class Initialized
INFO - 2017-02-21 10:30:22 --> Security Class Initialized
DEBUG - 2017-02-21 10:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:30:22 --> Input Class Initialized
INFO - 2017-02-21 10:30:22 --> Language Class Initialized
INFO - 2017-02-21 10:30:22 --> Loader Class Initialized
INFO - 2017-02-21 10:30:22 --> Helper loaded: url_helper
INFO - 2017-02-21 10:30:22 --> Helper loaded: language_helper
INFO - 2017-02-21 10:30:22 --> Helper loaded: html_helper
INFO - 2017-02-21 10:30:22 --> Helper loaded: form_helper
INFO - 2017-02-21 10:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:30:22 --> Controller Class Initialized
INFO - 2017-02-21 10:30:22 --> Database Driver Class Initialized
INFO - 2017-02-21 10:30:22 --> Model Class Initialized
INFO - 2017-02-21 10:30:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:30:22 --> Config Class Initialized
INFO - 2017-02-21 10:30:22 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:30:22 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:30:22 --> Utf8 Class Initialized
INFO - 2017-02-21 10:30:22 --> URI Class Initialized
INFO - 2017-02-21 10:30:22 --> Router Class Initialized
INFO - 2017-02-21 10:30:22 --> Output Class Initialized
INFO - 2017-02-21 10:30:22 --> Security Class Initialized
DEBUG - 2017-02-21 10:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:30:22 --> Input Class Initialized
INFO - 2017-02-21 10:30:22 --> Language Class Initialized
INFO - 2017-02-21 10:30:22 --> Loader Class Initialized
INFO - 2017-02-21 10:30:22 --> Helper loaded: url_helper
INFO - 2017-02-21 10:30:22 --> Helper loaded: language_helper
INFO - 2017-02-21 10:30:22 --> Helper loaded: html_helper
INFO - 2017-02-21 10:30:22 --> Helper loaded: form_helper
INFO - 2017-02-21 10:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:30:22 --> Controller Class Initialized
INFO - 2017-02-21 10:30:22 --> Database Driver Class Initialized
INFO - 2017-02-21 10:30:22 --> Model Class Initialized
INFO - 2017-02-21 10:30:22 --> Model Class Initialized
INFO - 2017-02-21 10:30:22 --> Model Class Initialized
INFO - 2017-02-21 10:30:22 --> Model Class Initialized
INFO - 2017-02-21 10:30:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-21 10:30:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:30:23 --> Final output sent to browser
DEBUG - 2017-02-21 10:30:23 --> Total execution time: 0.1070
INFO - 2017-02-21 10:30:24 --> Config Class Initialized
INFO - 2017-02-21 10:30:24 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:30:24 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:30:24 --> Utf8 Class Initialized
INFO - 2017-02-21 10:30:24 --> URI Class Initialized
INFO - 2017-02-21 10:30:24 --> Router Class Initialized
INFO - 2017-02-21 10:30:24 --> Output Class Initialized
INFO - 2017-02-21 10:30:24 --> Security Class Initialized
DEBUG - 2017-02-21 10:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:30:24 --> Input Class Initialized
INFO - 2017-02-21 10:30:24 --> Language Class Initialized
INFO - 2017-02-21 10:30:24 --> Loader Class Initialized
INFO - 2017-02-21 10:30:24 --> Helper loaded: url_helper
INFO - 2017-02-21 10:30:24 --> Helper loaded: language_helper
INFO - 2017-02-21 10:30:24 --> Helper loaded: html_helper
INFO - 2017-02-21 10:30:24 --> Helper loaded: form_helper
INFO - 2017-02-21 10:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:30:24 --> Controller Class Initialized
INFO - 2017-02-21 10:30:24 --> Database Driver Class Initialized
INFO - 2017-02-21 10:30:24 --> Model Class Initialized
INFO - 2017-02-21 10:30:24 --> Model Class Initialized
INFO - 2017-02-21 10:30:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:30:24 --> Config Class Initialized
INFO - 2017-02-21 10:30:24 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:30:24 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:30:24 --> Utf8 Class Initialized
INFO - 2017-02-21 10:30:24 --> URI Class Initialized
INFO - 2017-02-21 10:30:24 --> Router Class Initialized
INFO - 2017-02-21 10:30:24 --> Output Class Initialized
INFO - 2017-02-21 10:30:24 --> Security Class Initialized
DEBUG - 2017-02-21 10:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:30:24 --> Input Class Initialized
INFO - 2017-02-21 10:30:24 --> Language Class Initialized
INFO - 2017-02-21 10:30:24 --> Loader Class Initialized
INFO - 2017-02-21 10:30:24 --> Helper loaded: url_helper
INFO - 2017-02-21 10:30:24 --> Helper loaded: language_helper
INFO - 2017-02-21 10:30:24 --> Helper loaded: html_helper
INFO - 2017-02-21 10:30:24 --> Helper loaded: form_helper
INFO - 2017-02-21 10:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:30:24 --> Controller Class Initialized
INFO - 2017-02-21 10:30:24 --> Database Driver Class Initialized
INFO - 2017-02-21 10:30:24 --> Model Class Initialized
INFO - 2017-02-21 10:30:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:30:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 10:30:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 10:30:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 10:30:24 --> Final output sent to browser
DEBUG - 2017-02-21 10:30:24 --> Total execution time: 0.0831
INFO - 2017-02-21 10:30:29 --> Config Class Initialized
INFO - 2017-02-21 10:30:29 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:30:29 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:30:29 --> Utf8 Class Initialized
INFO - 2017-02-21 10:30:29 --> URI Class Initialized
INFO - 2017-02-21 10:30:29 --> Router Class Initialized
INFO - 2017-02-21 10:30:29 --> Output Class Initialized
INFO - 2017-02-21 10:30:29 --> Security Class Initialized
DEBUG - 2017-02-21 10:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:30:29 --> Input Class Initialized
INFO - 2017-02-21 10:30:29 --> Language Class Initialized
INFO - 2017-02-21 10:30:29 --> Loader Class Initialized
INFO - 2017-02-21 10:30:29 --> Helper loaded: url_helper
INFO - 2017-02-21 10:30:29 --> Helper loaded: language_helper
INFO - 2017-02-21 10:30:29 --> Helper loaded: html_helper
INFO - 2017-02-21 10:30:29 --> Helper loaded: form_helper
INFO - 2017-02-21 10:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:30:29 --> Controller Class Initialized
INFO - 2017-02-21 10:30:29 --> Database Driver Class Initialized
INFO - 2017-02-21 10:30:29 --> Model Class Initialized
INFO - 2017-02-21 10:30:29 --> Model Class Initialized
INFO - 2017-02-21 10:30:29 --> Model Class Initialized
INFO - 2017-02-21 10:30:29 --> Model Class Initialized
INFO - 2017-02-21 10:30:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:30:29 --> Config Class Initialized
INFO - 2017-02-21 10:30:29 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:30:29 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:30:29 --> Utf8 Class Initialized
INFO - 2017-02-21 10:30:29 --> URI Class Initialized
INFO - 2017-02-21 10:30:29 --> Router Class Initialized
INFO - 2017-02-21 10:30:29 --> Output Class Initialized
INFO - 2017-02-21 10:30:29 --> Security Class Initialized
DEBUG - 2017-02-21 10:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:30:29 --> Input Class Initialized
INFO - 2017-02-21 10:30:29 --> Language Class Initialized
INFO - 2017-02-21 10:30:29 --> Loader Class Initialized
INFO - 2017-02-21 10:30:29 --> Helper loaded: url_helper
INFO - 2017-02-21 10:30:29 --> Helper loaded: language_helper
INFO - 2017-02-21 10:30:29 --> Helper loaded: html_helper
INFO - 2017-02-21 10:30:29 --> Helper loaded: form_helper
INFO - 2017-02-21 10:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:30:29 --> Controller Class Initialized
INFO - 2017-02-21 10:30:29 --> Database Driver Class Initialized
INFO - 2017-02-21 10:30:29 --> Model Class Initialized
INFO - 2017-02-21 10:30:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:30:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 10:30:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 10:30:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 10:30:29 --> Final output sent to browser
DEBUG - 2017-02-21 10:30:29 --> Total execution time: 0.0836
INFO - 2017-02-21 10:30:30 --> Config Class Initialized
INFO - 2017-02-21 10:30:30 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:30:30 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:30:30 --> Utf8 Class Initialized
INFO - 2017-02-21 10:30:30 --> URI Class Initialized
INFO - 2017-02-21 10:30:30 --> Router Class Initialized
INFO - 2017-02-21 10:30:30 --> Output Class Initialized
INFO - 2017-02-21 10:30:30 --> Security Class Initialized
DEBUG - 2017-02-21 10:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:30:30 --> Input Class Initialized
INFO - 2017-02-21 10:30:30 --> Language Class Initialized
INFO - 2017-02-21 10:30:30 --> Loader Class Initialized
INFO - 2017-02-21 10:30:30 --> Helper loaded: url_helper
INFO - 2017-02-21 10:30:30 --> Helper loaded: language_helper
INFO - 2017-02-21 10:30:30 --> Helper loaded: html_helper
INFO - 2017-02-21 10:30:30 --> Helper loaded: form_helper
INFO - 2017-02-21 10:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:30:30 --> Controller Class Initialized
INFO - 2017-02-21 10:30:30 --> Database Driver Class Initialized
INFO - 2017-02-21 10:30:30 --> Model Class Initialized
INFO - 2017-02-21 10:30:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:30:30 --> Form Validation Class Initialized
INFO - 2017-02-21 10:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 10:30:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:30:30 --> Final output sent to browser
DEBUG - 2017-02-21 10:30:30 --> Total execution time: 0.1327
INFO - 2017-02-21 10:48:24 --> Config Class Initialized
INFO - 2017-02-21 10:48:24 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:48:24 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:48:24 --> Utf8 Class Initialized
INFO - 2017-02-21 10:48:24 --> URI Class Initialized
INFO - 2017-02-21 10:48:24 --> Router Class Initialized
INFO - 2017-02-21 10:48:24 --> Output Class Initialized
INFO - 2017-02-21 10:48:24 --> Security Class Initialized
DEBUG - 2017-02-21 10:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:48:24 --> Input Class Initialized
INFO - 2017-02-21 10:48:24 --> Language Class Initialized
INFO - 2017-02-21 10:48:24 --> Loader Class Initialized
INFO - 2017-02-21 10:48:24 --> Helper loaded: url_helper
INFO - 2017-02-21 10:48:24 --> Helper loaded: language_helper
INFO - 2017-02-21 10:48:24 --> Helper loaded: html_helper
INFO - 2017-02-21 10:48:24 --> Helper loaded: form_helper
INFO - 2017-02-21 10:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:48:24 --> Controller Class Initialized
INFO - 2017-02-21 10:48:24 --> Database Driver Class Initialized
INFO - 2017-02-21 10:48:24 --> Model Class Initialized
INFO - 2017-02-21 10:48:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:48:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 10:48:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 10:48:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 10:48:24 --> Final output sent to browser
DEBUG - 2017-02-21 10:48:24 --> Total execution time: 0.0879
INFO - 2017-02-21 10:48:42 --> Config Class Initialized
INFO - 2017-02-21 10:48:42 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:48:42 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:48:42 --> Utf8 Class Initialized
INFO - 2017-02-21 10:48:42 --> URI Class Initialized
INFO - 2017-02-21 10:48:42 --> Router Class Initialized
INFO - 2017-02-21 10:48:42 --> Output Class Initialized
INFO - 2017-02-21 10:48:42 --> Security Class Initialized
DEBUG - 2017-02-21 10:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:48:42 --> Input Class Initialized
INFO - 2017-02-21 10:48:42 --> Language Class Initialized
INFO - 2017-02-21 10:48:42 --> Loader Class Initialized
INFO - 2017-02-21 10:48:42 --> Helper loaded: url_helper
INFO - 2017-02-21 10:48:42 --> Helper loaded: language_helper
INFO - 2017-02-21 10:48:42 --> Helper loaded: html_helper
INFO - 2017-02-21 10:48:42 --> Helper loaded: form_helper
INFO - 2017-02-21 10:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:48:42 --> Controller Class Initialized
INFO - 2017-02-21 10:48:42 --> Database Driver Class Initialized
INFO - 2017-02-21 10:48:42 --> Model Class Initialized
INFO - 2017-02-21 10:48:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:48:42 --> Config Class Initialized
INFO - 2017-02-21 10:48:42 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:48:42 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:48:42 --> Utf8 Class Initialized
INFO - 2017-02-21 10:48:42 --> URI Class Initialized
INFO - 2017-02-21 10:48:42 --> Router Class Initialized
INFO - 2017-02-21 10:48:42 --> Output Class Initialized
INFO - 2017-02-21 10:48:42 --> Security Class Initialized
DEBUG - 2017-02-21 10:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:48:42 --> Input Class Initialized
INFO - 2017-02-21 10:48:42 --> Language Class Initialized
INFO - 2017-02-21 10:48:42 --> Loader Class Initialized
INFO - 2017-02-21 10:48:42 --> Helper loaded: url_helper
INFO - 2017-02-21 10:48:42 --> Helper loaded: language_helper
INFO - 2017-02-21 10:48:42 --> Helper loaded: html_helper
INFO - 2017-02-21 10:48:42 --> Helper loaded: form_helper
INFO - 2017-02-21 10:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:48:42 --> Controller Class Initialized
INFO - 2017-02-21 10:48:43 --> Database Driver Class Initialized
INFO - 2017-02-21 10:48:43 --> Model Class Initialized
INFO - 2017-02-21 10:48:43 --> Model Class Initialized
INFO - 2017-02-21 10:48:43 --> Model Class Initialized
INFO - 2017-02-21 10:48:43 --> Model Class Initialized
INFO - 2017-02-21 10:48:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:48:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:48:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-21 10:48:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:48:43 --> Final output sent to browser
DEBUG - 2017-02-21 10:48:43 --> Total execution time: 0.1406
INFO - 2017-02-21 10:48:46 --> Config Class Initialized
INFO - 2017-02-21 10:48:46 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:48:46 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:48:46 --> Utf8 Class Initialized
INFO - 2017-02-21 10:48:46 --> URI Class Initialized
INFO - 2017-02-21 10:48:46 --> Router Class Initialized
INFO - 2017-02-21 10:48:46 --> Output Class Initialized
INFO - 2017-02-21 10:48:46 --> Security Class Initialized
DEBUG - 2017-02-21 10:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:48:46 --> Input Class Initialized
INFO - 2017-02-21 10:48:46 --> Language Class Initialized
INFO - 2017-02-21 10:48:46 --> Loader Class Initialized
INFO - 2017-02-21 10:48:46 --> Helper loaded: url_helper
INFO - 2017-02-21 10:48:46 --> Helper loaded: language_helper
INFO - 2017-02-21 10:48:46 --> Helper loaded: html_helper
INFO - 2017-02-21 10:48:46 --> Helper loaded: form_helper
INFO - 2017-02-21 10:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:48:46 --> Controller Class Initialized
INFO - 2017-02-21 10:48:46 --> Database Driver Class Initialized
INFO - 2017-02-21 10:48:46 --> Model Class Initialized
INFO - 2017-02-21 10:48:46 --> Model Class Initialized
INFO - 2017-02-21 10:48:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 10:48:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:48:47 --> Final output sent to browser
DEBUG - 2017-02-21 10:48:47 --> Total execution time: 0.2803
INFO - 2017-02-21 10:49:45 --> Config Class Initialized
INFO - 2017-02-21 10:49:45 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:49:45 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:49:45 --> Utf8 Class Initialized
INFO - 2017-02-21 10:49:45 --> URI Class Initialized
INFO - 2017-02-21 10:49:45 --> Router Class Initialized
INFO - 2017-02-21 10:49:45 --> Output Class Initialized
INFO - 2017-02-21 10:49:45 --> Security Class Initialized
DEBUG - 2017-02-21 10:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:49:45 --> Input Class Initialized
INFO - 2017-02-21 10:49:45 --> Language Class Initialized
INFO - 2017-02-21 10:49:45 --> Loader Class Initialized
INFO - 2017-02-21 10:49:45 --> Helper loaded: url_helper
INFO - 2017-02-21 10:49:45 --> Helper loaded: language_helper
INFO - 2017-02-21 10:49:45 --> Helper loaded: html_helper
INFO - 2017-02-21 10:49:45 --> Helper loaded: form_helper
INFO - 2017-02-21 10:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:49:45 --> Controller Class Initialized
INFO - 2017-02-21 10:49:45 --> Database Driver Class Initialized
INFO - 2017-02-21 10:49:45 --> Model Class Initialized
INFO - 2017-02-21 10:49:45 --> Model Class Initialized
INFO - 2017-02-21 10:49:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:49:45 --> Model Class Initialized
INFO - 2017-02-21 10:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 10:49:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:49:45 --> Final output sent to browser
DEBUG - 2017-02-21 10:49:45 --> Total execution time: 0.1831
INFO - 2017-02-21 10:54:36 --> Config Class Initialized
INFO - 2017-02-21 10:54:36 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:54:36 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:54:36 --> Utf8 Class Initialized
INFO - 2017-02-21 10:54:36 --> URI Class Initialized
INFO - 2017-02-21 10:54:36 --> Router Class Initialized
INFO - 2017-02-21 10:54:36 --> Output Class Initialized
INFO - 2017-02-21 10:54:36 --> Security Class Initialized
DEBUG - 2017-02-21 10:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:54:36 --> Input Class Initialized
INFO - 2017-02-21 10:54:36 --> Language Class Initialized
INFO - 2017-02-21 10:54:36 --> Loader Class Initialized
INFO - 2017-02-21 10:54:36 --> Helper loaded: url_helper
INFO - 2017-02-21 10:54:36 --> Helper loaded: language_helper
INFO - 2017-02-21 10:54:36 --> Helper loaded: html_helper
INFO - 2017-02-21 10:54:36 --> Helper loaded: form_helper
INFO - 2017-02-21 10:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:54:36 --> Controller Class Initialized
INFO - 2017-02-21 10:54:36 --> Database Driver Class Initialized
INFO - 2017-02-21 10:54:36 --> Model Class Initialized
INFO - 2017-02-21 10:54:36 --> Model Class Initialized
INFO - 2017-02-21 10:54:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:54:36 --> Model Class Initialized
INFO - 2017-02-21 10:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 10:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:54:36 --> Final output sent to browser
DEBUG - 2017-02-21 10:54:36 --> Total execution time: 0.1529
INFO - 2017-02-21 10:56:36 --> Config Class Initialized
INFO - 2017-02-21 10:56:36 --> Hooks Class Initialized
DEBUG - 2017-02-21 10:56:36 --> UTF-8 Support Enabled
INFO - 2017-02-21 10:56:36 --> Utf8 Class Initialized
INFO - 2017-02-21 10:56:36 --> URI Class Initialized
INFO - 2017-02-21 10:56:36 --> Router Class Initialized
INFO - 2017-02-21 10:56:36 --> Output Class Initialized
INFO - 2017-02-21 10:56:36 --> Security Class Initialized
DEBUG - 2017-02-21 10:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 10:56:36 --> Input Class Initialized
INFO - 2017-02-21 10:56:36 --> Language Class Initialized
INFO - 2017-02-21 10:56:36 --> Loader Class Initialized
INFO - 2017-02-21 10:56:36 --> Helper loaded: url_helper
INFO - 2017-02-21 10:56:36 --> Helper loaded: language_helper
INFO - 2017-02-21 10:56:36 --> Helper loaded: html_helper
INFO - 2017-02-21 10:56:36 --> Helper loaded: form_helper
INFO - 2017-02-21 10:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 10:56:36 --> Controller Class Initialized
INFO - 2017-02-21 10:56:37 --> Database Driver Class Initialized
INFO - 2017-02-21 10:56:37 --> Model Class Initialized
INFO - 2017-02-21 10:56:37 --> Model Class Initialized
INFO - 2017-02-21 10:56:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 10:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 10:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 10:56:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 10:56:37 --> Final output sent to browser
DEBUG - 2017-02-21 10:56:37 --> Total execution time: 0.2492
INFO - 2017-02-21 11:02:54 --> Config Class Initialized
INFO - 2017-02-21 11:02:54 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:02:54 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:02:54 --> Utf8 Class Initialized
INFO - 2017-02-21 11:02:54 --> URI Class Initialized
INFO - 2017-02-21 11:02:54 --> Router Class Initialized
INFO - 2017-02-21 11:02:54 --> Output Class Initialized
INFO - 2017-02-21 11:02:54 --> Security Class Initialized
DEBUG - 2017-02-21 11:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:02:54 --> Input Class Initialized
INFO - 2017-02-21 11:02:54 --> Language Class Initialized
INFO - 2017-02-21 11:02:54 --> Loader Class Initialized
INFO - 2017-02-21 11:02:54 --> Helper loaded: url_helper
INFO - 2017-02-21 11:02:54 --> Helper loaded: language_helper
INFO - 2017-02-21 11:02:54 --> Helper loaded: html_helper
INFO - 2017-02-21 11:02:54 --> Helper loaded: form_helper
INFO - 2017-02-21 11:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:02:54 --> Controller Class Initialized
INFO - 2017-02-21 11:02:54 --> Database Driver Class Initialized
INFO - 2017-02-21 11:02:54 --> Model Class Initialized
INFO - 2017-02-21 11:02:54 --> Model Class Initialized
INFO - 2017-02-21 11:02:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 11:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-21 11:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 11:02:54 --> Final output sent to browser
DEBUG - 2017-02-21 11:02:54 --> Total execution time: 0.2758
INFO - 2017-02-21 11:16:11 --> Config Class Initialized
INFO - 2017-02-21 11:16:11 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:16:11 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:16:11 --> Utf8 Class Initialized
INFO - 2017-02-21 11:16:11 --> URI Class Initialized
INFO - 2017-02-21 11:16:11 --> Router Class Initialized
INFO - 2017-02-21 11:16:11 --> Output Class Initialized
INFO - 2017-02-21 11:16:11 --> Security Class Initialized
DEBUG - 2017-02-21 11:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:16:11 --> Input Class Initialized
INFO - 2017-02-21 11:16:11 --> Language Class Initialized
INFO - 2017-02-21 11:16:11 --> Loader Class Initialized
INFO - 2017-02-21 11:16:11 --> Helper loaded: url_helper
INFO - 2017-02-21 11:16:11 --> Helper loaded: language_helper
INFO - 2017-02-21 11:16:11 --> Helper loaded: html_helper
INFO - 2017-02-21 11:16:11 --> Helper loaded: form_helper
INFO - 2017-02-21 11:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:16:11 --> Controller Class Initialized
INFO - 2017-02-21 11:16:11 --> Database Driver Class Initialized
INFO - 2017-02-21 11:16:11 --> Model Class Initialized
INFO - 2017-02-21 11:16:11 --> Model Class Initialized
INFO - 2017-02-21 11:16:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:16:11 --> Model Class Initialized
INFO - 2017-02-21 11:16:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 11:16:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail_ist.php
INFO - 2017-02-21 11:16:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 11:16:11 --> Final output sent to browser
DEBUG - 2017-02-21 11:16:11 --> Total execution time: 0.1908
INFO - 2017-02-21 11:17:53 --> Config Class Initialized
INFO - 2017-02-21 11:17:53 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:17:53 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:17:53 --> Utf8 Class Initialized
INFO - 2017-02-21 11:17:53 --> URI Class Initialized
INFO - 2017-02-21 11:17:53 --> Router Class Initialized
INFO - 2017-02-21 11:17:53 --> Output Class Initialized
INFO - 2017-02-21 11:17:53 --> Security Class Initialized
DEBUG - 2017-02-21 11:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:17:53 --> Input Class Initialized
INFO - 2017-02-21 11:17:53 --> Language Class Initialized
INFO - 2017-02-21 11:17:53 --> Loader Class Initialized
INFO - 2017-02-21 11:17:53 --> Helper loaded: url_helper
INFO - 2017-02-21 11:17:53 --> Helper loaded: language_helper
INFO - 2017-02-21 11:17:53 --> Helper loaded: html_helper
INFO - 2017-02-21 11:17:53 --> Helper loaded: form_helper
INFO - 2017-02-21 11:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:17:53 --> Controller Class Initialized
INFO - 2017-02-21 11:17:53 --> Database Driver Class Initialized
INFO - 2017-02-21 11:17:53 --> Model Class Initialized
INFO - 2017-02-21 11:17:53 --> Model Class Initialized
INFO - 2017-02-21 11:17:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:17:53 --> Config Class Initialized
INFO - 2017-02-21 11:17:53 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:17:53 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:17:53 --> Utf8 Class Initialized
INFO - 2017-02-21 11:17:53 --> URI Class Initialized
INFO - 2017-02-21 11:17:53 --> Router Class Initialized
INFO - 2017-02-21 11:17:53 --> Output Class Initialized
INFO - 2017-02-21 11:17:53 --> Security Class Initialized
DEBUG - 2017-02-21 11:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:17:53 --> Input Class Initialized
INFO - 2017-02-21 11:17:53 --> Language Class Initialized
INFO - 2017-02-21 11:17:53 --> Loader Class Initialized
INFO - 2017-02-21 11:17:53 --> Helper loaded: url_helper
INFO - 2017-02-21 11:17:53 --> Helper loaded: language_helper
INFO - 2017-02-21 11:17:53 --> Helper loaded: html_helper
INFO - 2017-02-21 11:17:53 --> Helper loaded: form_helper
INFO - 2017-02-21 11:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:17:53 --> Controller Class Initialized
INFO - 2017-02-21 11:17:53 --> Database Driver Class Initialized
INFO - 2017-02-21 11:17:53 --> Model Class Initialized
INFO - 2017-02-21 11:17:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:17:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 11:17:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 11:17:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 11:17:53 --> Final output sent to browser
DEBUG - 2017-02-21 11:17:53 --> Total execution time: 0.0753
INFO - 2017-02-21 11:17:59 --> Config Class Initialized
INFO - 2017-02-21 11:17:59 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:17:59 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:17:59 --> Utf8 Class Initialized
INFO - 2017-02-21 11:17:59 --> URI Class Initialized
INFO - 2017-02-21 11:17:59 --> Router Class Initialized
INFO - 2017-02-21 11:17:59 --> Output Class Initialized
INFO - 2017-02-21 11:17:59 --> Security Class Initialized
DEBUG - 2017-02-21 11:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:17:59 --> Input Class Initialized
INFO - 2017-02-21 11:17:59 --> Language Class Initialized
INFO - 2017-02-21 11:17:59 --> Loader Class Initialized
INFO - 2017-02-21 11:17:59 --> Helper loaded: url_helper
INFO - 2017-02-21 11:17:59 --> Helper loaded: language_helper
INFO - 2017-02-21 11:17:59 --> Helper loaded: html_helper
INFO - 2017-02-21 11:17:59 --> Helper loaded: form_helper
INFO - 2017-02-21 11:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:17:59 --> Controller Class Initialized
INFO - 2017-02-21 11:17:59 --> Database Driver Class Initialized
INFO - 2017-02-21 11:17:59 --> Model Class Initialized
INFO - 2017-02-21 11:17:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:17:59 --> Form Validation Class Initialized
INFO - 2017-02-21 11:17:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 11:17:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 11:17:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 11:17:59 --> Final output sent to browser
DEBUG - 2017-02-21 11:17:59 --> Total execution time: 0.1292
INFO - 2017-02-21 11:21:46 --> Config Class Initialized
INFO - 2017-02-21 11:21:46 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:21:46 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:21:46 --> Utf8 Class Initialized
INFO - 2017-02-21 11:21:46 --> URI Class Initialized
INFO - 2017-02-21 11:21:46 --> Router Class Initialized
INFO - 2017-02-21 11:21:46 --> Output Class Initialized
INFO - 2017-02-21 11:21:46 --> Security Class Initialized
DEBUG - 2017-02-21 11:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:21:46 --> Input Class Initialized
INFO - 2017-02-21 11:21:46 --> Language Class Initialized
INFO - 2017-02-21 11:21:46 --> Loader Class Initialized
INFO - 2017-02-21 11:21:46 --> Helper loaded: url_helper
INFO - 2017-02-21 11:21:46 --> Helper loaded: language_helper
INFO - 2017-02-21 11:21:46 --> Helper loaded: html_helper
INFO - 2017-02-21 11:21:46 --> Helper loaded: form_helper
INFO - 2017-02-21 11:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:21:46 --> Controller Class Initialized
INFO - 2017-02-21 11:21:46 --> Database Driver Class Initialized
INFO - 2017-02-21 11:21:46 --> Model Class Initialized
INFO - 2017-02-21 11:21:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:21:46 --> Form Validation Class Initialized
INFO - 2017-02-21 11:21:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 11:21:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 11:21:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 11:21:46 --> Final output sent to browser
DEBUG - 2017-02-21 11:21:46 --> Total execution time: 0.0851
INFO - 2017-02-21 11:22:31 --> Config Class Initialized
INFO - 2017-02-21 11:22:31 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:22:31 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:22:31 --> Utf8 Class Initialized
INFO - 2017-02-21 11:22:31 --> URI Class Initialized
INFO - 2017-02-21 11:22:31 --> Router Class Initialized
INFO - 2017-02-21 11:22:31 --> Output Class Initialized
INFO - 2017-02-21 11:22:31 --> Security Class Initialized
DEBUG - 2017-02-21 11:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:22:31 --> Input Class Initialized
INFO - 2017-02-21 11:22:31 --> Language Class Initialized
INFO - 2017-02-21 11:22:31 --> Loader Class Initialized
INFO - 2017-02-21 11:22:31 --> Helper loaded: url_helper
INFO - 2017-02-21 11:22:31 --> Helper loaded: language_helper
INFO - 2017-02-21 11:22:31 --> Helper loaded: html_helper
INFO - 2017-02-21 11:22:31 --> Helper loaded: form_helper
INFO - 2017-02-21 11:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:22:31 --> Controller Class Initialized
INFO - 2017-02-21 11:22:31 --> Database Driver Class Initialized
INFO - 2017-02-21 11:22:31 --> Model Class Initialized
INFO - 2017-02-21 11:22:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:22:31 --> Form Validation Class Initialized
INFO - 2017-02-21 11:22:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 11:22:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 11:22:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 11:22:31 --> Final output sent to browser
DEBUG - 2017-02-21 11:22:31 --> Total execution time: 0.0870
INFO - 2017-02-21 11:22:39 --> Config Class Initialized
INFO - 2017-02-21 11:22:39 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:22:39 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:22:39 --> Utf8 Class Initialized
INFO - 2017-02-21 11:22:39 --> URI Class Initialized
INFO - 2017-02-21 11:22:39 --> Router Class Initialized
INFO - 2017-02-21 11:22:39 --> Output Class Initialized
INFO - 2017-02-21 11:22:39 --> Security Class Initialized
DEBUG - 2017-02-21 11:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:22:39 --> Input Class Initialized
INFO - 2017-02-21 11:22:39 --> Language Class Initialized
INFO - 2017-02-21 11:22:39 --> Loader Class Initialized
INFO - 2017-02-21 11:22:39 --> Helper loaded: url_helper
INFO - 2017-02-21 11:22:39 --> Helper loaded: language_helper
INFO - 2017-02-21 11:22:39 --> Helper loaded: html_helper
INFO - 2017-02-21 11:22:39 --> Helper loaded: form_helper
INFO - 2017-02-21 11:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:22:39 --> Controller Class Initialized
INFO - 2017-02-21 11:22:39 --> Database Driver Class Initialized
INFO - 2017-02-21 11:22:39 --> Model Class Initialized
INFO - 2017-02-21 11:22:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:22:39 --> Form Validation Class Initialized
INFO - 2017-02-21 11:22:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 11:22:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 11:22:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 11:22:39 --> Final output sent to browser
DEBUG - 2017-02-21 11:22:39 --> Total execution time: 0.0886
INFO - 2017-02-21 11:27:00 --> Config Class Initialized
INFO - 2017-02-21 11:27:00 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:27:00 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:27:00 --> Utf8 Class Initialized
INFO - 2017-02-21 11:27:00 --> URI Class Initialized
INFO - 2017-02-21 11:27:00 --> Router Class Initialized
INFO - 2017-02-21 11:27:00 --> Output Class Initialized
INFO - 2017-02-21 11:27:00 --> Security Class Initialized
DEBUG - 2017-02-21 11:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:27:00 --> Input Class Initialized
INFO - 2017-02-21 11:27:00 --> Language Class Initialized
INFO - 2017-02-21 11:27:00 --> Loader Class Initialized
INFO - 2017-02-21 11:27:00 --> Helper loaded: url_helper
INFO - 2017-02-21 11:27:00 --> Helper loaded: language_helper
INFO - 2017-02-21 11:27:00 --> Helper loaded: html_helper
INFO - 2017-02-21 11:27:00 --> Helper loaded: form_helper
INFO - 2017-02-21 11:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:27:00 --> Controller Class Initialized
INFO - 2017-02-21 11:27:00 --> Database Driver Class Initialized
INFO - 2017-02-21 11:27:00 --> Model Class Initialized
INFO - 2017-02-21 11:27:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:27:00 --> Form Validation Class Initialized
INFO - 2017-02-21 11:27:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 11:27:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 11:27:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 11:27:00 --> Final output sent to browser
DEBUG - 2017-02-21 11:27:00 --> Total execution time: 0.1133
INFO - 2017-02-21 11:31:11 --> Config Class Initialized
INFO - 2017-02-21 11:31:11 --> Hooks Class Initialized
DEBUG - 2017-02-21 11:31:11 --> UTF-8 Support Enabled
INFO - 2017-02-21 11:31:11 --> Utf8 Class Initialized
INFO - 2017-02-21 11:31:11 --> URI Class Initialized
INFO - 2017-02-21 11:31:11 --> Router Class Initialized
INFO - 2017-02-21 11:31:11 --> Output Class Initialized
INFO - 2017-02-21 11:31:11 --> Security Class Initialized
DEBUG - 2017-02-21 11:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 11:31:11 --> Input Class Initialized
INFO - 2017-02-21 11:31:11 --> Language Class Initialized
INFO - 2017-02-21 11:31:11 --> Loader Class Initialized
INFO - 2017-02-21 11:31:11 --> Helper loaded: url_helper
INFO - 2017-02-21 11:31:11 --> Helper loaded: language_helper
INFO - 2017-02-21 11:31:11 --> Helper loaded: html_helper
INFO - 2017-02-21 11:31:11 --> Helper loaded: form_helper
INFO - 2017-02-21 11:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 11:31:11 --> Controller Class Initialized
INFO - 2017-02-21 11:31:11 --> Database Driver Class Initialized
INFO - 2017-02-21 11:31:11 --> Model Class Initialized
INFO - 2017-02-21 11:31:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 11:31:11 --> Form Validation Class Initialized
INFO - 2017-02-21 11:31:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 11:31:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 11:31:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 11:31:11 --> Final output sent to browser
DEBUG - 2017-02-21 11:31:11 --> Total execution time: 0.0886
INFO - 2017-02-21 12:23:48 --> Config Class Initialized
INFO - 2017-02-21 12:23:48 --> Hooks Class Initialized
DEBUG - 2017-02-21 12:23:48 --> UTF-8 Support Enabled
INFO - 2017-02-21 12:23:48 --> Utf8 Class Initialized
INFO - 2017-02-21 12:23:48 --> URI Class Initialized
DEBUG - 2017-02-21 12:23:48 --> No URI present. Default controller set.
INFO - 2017-02-21 12:23:48 --> Router Class Initialized
INFO - 2017-02-21 12:23:48 --> Output Class Initialized
INFO - 2017-02-21 12:23:48 --> Security Class Initialized
DEBUG - 2017-02-21 12:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 12:23:48 --> Input Class Initialized
INFO - 2017-02-21 12:23:48 --> Language Class Initialized
INFO - 2017-02-21 12:23:48 --> Loader Class Initialized
INFO - 2017-02-21 12:23:48 --> Helper loaded: url_helper
INFO - 2017-02-21 12:23:48 --> Helper loaded: language_helper
INFO - 2017-02-21 12:23:48 --> Helper loaded: html_helper
INFO - 2017-02-21 12:23:48 --> Helper loaded: form_helper
INFO - 2017-02-21 12:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 12:23:48 --> Controller Class Initialized
INFO - 2017-02-21 12:23:48 --> Database Driver Class Initialized
INFO - 2017-02-21 12:23:48 --> Model Class Initialized
INFO - 2017-02-21 12:23:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 12:23:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 12:23:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 12:23:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 12:23:48 --> Final output sent to browser
DEBUG - 2017-02-21 12:23:48 --> Total execution time: 0.1460
INFO - 2017-02-21 12:30:59 --> Config Class Initialized
INFO - 2017-02-21 12:30:59 --> Hooks Class Initialized
DEBUG - 2017-02-21 12:30:59 --> UTF-8 Support Enabled
INFO - 2017-02-21 12:30:59 --> Utf8 Class Initialized
INFO - 2017-02-21 12:30:59 --> URI Class Initialized
DEBUG - 2017-02-21 12:30:59 --> No URI present. Default controller set.
INFO - 2017-02-21 12:30:59 --> Router Class Initialized
INFO - 2017-02-21 12:30:59 --> Output Class Initialized
INFO - 2017-02-21 12:30:59 --> Security Class Initialized
DEBUG - 2017-02-21 12:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 12:30:59 --> Input Class Initialized
INFO - 2017-02-21 12:30:59 --> Language Class Initialized
INFO - 2017-02-21 12:31:00 --> Loader Class Initialized
INFO - 2017-02-21 12:31:00 --> Helper loaded: url_helper
INFO - 2017-02-21 12:31:00 --> Helper loaded: language_helper
INFO - 2017-02-21 12:31:00 --> Helper loaded: html_helper
INFO - 2017-02-21 12:31:00 --> Helper loaded: form_helper
INFO - 2017-02-21 12:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 12:31:00 --> Controller Class Initialized
INFO - 2017-02-21 12:31:00 --> Database Driver Class Initialized
INFO - 2017-02-21 12:31:00 --> Model Class Initialized
INFO - 2017-02-21 12:31:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 12:31:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 12:31:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 12:31:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 12:31:00 --> Final output sent to browser
DEBUG - 2017-02-21 12:31:00 --> Total execution time: 0.0914
INFO - 2017-02-21 13:26:25 --> Config Class Initialized
INFO - 2017-02-21 13:26:25 --> Hooks Class Initialized
DEBUG - 2017-02-21 13:26:25 --> UTF-8 Support Enabled
INFO - 2017-02-21 13:26:25 --> Utf8 Class Initialized
INFO - 2017-02-21 13:26:25 --> URI Class Initialized
INFO - 2017-02-21 13:26:25 --> Router Class Initialized
INFO - 2017-02-21 13:26:25 --> Output Class Initialized
INFO - 2017-02-21 13:26:25 --> Security Class Initialized
DEBUG - 2017-02-21 13:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 13:26:25 --> Input Class Initialized
INFO - 2017-02-21 13:26:25 --> Language Class Initialized
INFO - 2017-02-21 13:26:25 --> Loader Class Initialized
INFO - 2017-02-21 13:26:25 --> Helper loaded: url_helper
INFO - 2017-02-21 13:26:25 --> Helper loaded: language_helper
INFO - 2017-02-21 13:26:25 --> Helper loaded: html_helper
INFO - 2017-02-21 13:26:25 --> Helper loaded: form_helper
INFO - 2017-02-21 13:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 13:26:25 --> Controller Class Initialized
INFO - 2017-02-21 13:26:25 --> Database Driver Class Initialized
INFO - 2017-02-21 13:26:25 --> Model Class Initialized
INFO - 2017-02-21 13:26:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 13:26:25 --> Form Validation Class Initialized
INFO - 2017-02-21 13:26:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 13:26:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 13:26:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 13:26:25 --> Final output sent to browser
DEBUG - 2017-02-21 13:26:25 --> Total execution time: 0.1635
INFO - 2017-02-21 13:56:23 --> Config Class Initialized
INFO - 2017-02-21 13:56:23 --> Hooks Class Initialized
DEBUG - 2017-02-21 13:56:23 --> UTF-8 Support Enabled
INFO - 2017-02-21 13:56:23 --> Utf8 Class Initialized
INFO - 2017-02-21 13:56:23 --> URI Class Initialized
INFO - 2017-02-21 13:56:23 --> Router Class Initialized
INFO - 2017-02-21 13:56:23 --> Output Class Initialized
INFO - 2017-02-21 13:56:23 --> Security Class Initialized
DEBUG - 2017-02-21 13:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 13:56:23 --> Input Class Initialized
INFO - 2017-02-21 13:56:23 --> Language Class Initialized
INFO - 2017-02-21 13:56:23 --> Loader Class Initialized
INFO - 2017-02-21 13:56:23 --> Helper loaded: url_helper
INFO - 2017-02-21 13:56:23 --> Helper loaded: language_helper
INFO - 2017-02-21 13:56:23 --> Helper loaded: html_helper
INFO - 2017-02-21 13:56:23 --> Helper loaded: form_helper
INFO - 2017-02-21 13:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 13:56:23 --> Controller Class Initialized
INFO - 2017-02-21 13:56:23 --> Database Driver Class Initialized
INFO - 2017-02-21 13:56:23 --> Model Class Initialized
INFO - 2017-02-21 13:56:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 13:56:23 --> Form Validation Class Initialized
INFO - 2017-02-21 13:56:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 13:56:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 13:56:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 13:56:23 --> Final output sent to browser
DEBUG - 2017-02-21 13:56:23 --> Total execution time: 0.1150
INFO - 2017-02-21 14:13:50 --> Config Class Initialized
INFO - 2017-02-21 14:13:50 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:13:50 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:13:50 --> Utf8 Class Initialized
INFO - 2017-02-21 14:13:50 --> URI Class Initialized
INFO - 2017-02-21 14:13:50 --> Router Class Initialized
INFO - 2017-02-21 14:13:50 --> Output Class Initialized
INFO - 2017-02-21 14:13:50 --> Security Class Initialized
DEBUG - 2017-02-21 14:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:13:50 --> Input Class Initialized
INFO - 2017-02-21 14:13:50 --> Language Class Initialized
INFO - 2017-02-21 14:13:50 --> Loader Class Initialized
INFO - 2017-02-21 14:13:50 --> Helper loaded: url_helper
INFO - 2017-02-21 14:13:50 --> Helper loaded: language_helper
INFO - 2017-02-21 14:13:50 --> Helper loaded: html_helper
INFO - 2017-02-21 14:13:50 --> Helper loaded: form_helper
INFO - 2017-02-21 14:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:13:50 --> Controller Class Initialized
INFO - 2017-02-21 14:13:51 --> Database Driver Class Initialized
INFO - 2017-02-21 14:13:51 --> Model Class Initialized
INFO - 2017-02-21 14:13:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:13:51 --> Form Validation Class Initialized
INFO - 2017-02-21 14:13:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 14:13:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 14:13:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 14:13:51 --> Final output sent to browser
DEBUG - 2017-02-21 14:13:51 --> Total execution time: 0.1022
INFO - 2017-02-21 14:14:01 --> Config Class Initialized
INFO - 2017-02-21 14:14:01 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:14:01 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:14:01 --> Utf8 Class Initialized
INFO - 2017-02-21 14:14:01 --> URI Class Initialized
INFO - 2017-02-21 14:14:01 --> Router Class Initialized
INFO - 2017-02-21 14:14:01 --> Output Class Initialized
INFO - 2017-02-21 14:14:01 --> Security Class Initialized
DEBUG - 2017-02-21 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:14:01 --> Input Class Initialized
INFO - 2017-02-21 14:14:01 --> Language Class Initialized
INFO - 2017-02-21 14:14:01 --> Loader Class Initialized
INFO - 2017-02-21 14:14:01 --> Helper loaded: url_helper
INFO - 2017-02-21 14:14:01 --> Helper loaded: language_helper
INFO - 2017-02-21 14:14:01 --> Helper loaded: html_helper
INFO - 2017-02-21 14:14:01 --> Helper loaded: form_helper
INFO - 2017-02-21 14:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:14:01 --> Controller Class Initialized
INFO - 2017-02-21 14:14:01 --> Database Driver Class Initialized
INFO - 2017-02-21 14:14:01 --> Model Class Initialized
INFO - 2017-02-21 14:14:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:14:01 --> Form Validation Class Initialized
INFO - 2017-02-21 14:14:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 14:14:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 14:14:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 14:14:01 --> Final output sent to browser
DEBUG - 2017-02-21 14:14:01 --> Total execution time: 0.0847
INFO - 2017-02-21 14:14:32 --> Config Class Initialized
INFO - 2017-02-21 14:14:32 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:14:32 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:14:32 --> Utf8 Class Initialized
INFO - 2017-02-21 14:14:32 --> URI Class Initialized
INFO - 2017-02-21 14:14:32 --> Router Class Initialized
INFO - 2017-02-21 14:14:32 --> Output Class Initialized
INFO - 2017-02-21 14:14:32 --> Security Class Initialized
DEBUG - 2017-02-21 14:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:14:32 --> Input Class Initialized
INFO - 2017-02-21 14:14:32 --> Language Class Initialized
INFO - 2017-02-21 14:14:32 --> Loader Class Initialized
INFO - 2017-02-21 14:14:32 --> Helper loaded: url_helper
INFO - 2017-02-21 14:14:32 --> Helper loaded: language_helper
INFO - 2017-02-21 14:14:32 --> Helper loaded: html_helper
INFO - 2017-02-21 14:14:32 --> Helper loaded: form_helper
INFO - 2017-02-21 14:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:14:32 --> Controller Class Initialized
INFO - 2017-02-21 14:14:32 --> Database Driver Class Initialized
INFO - 2017-02-21 14:14:32 --> Model Class Initialized
INFO - 2017-02-21 14:14:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:14:32 --> Form Validation Class Initialized
INFO - 2017-02-21 14:14:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 14:14:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 14:14:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 14:14:32 --> Final output sent to browser
DEBUG - 2017-02-21 14:14:32 --> Total execution time: 0.0949
INFO - 2017-02-21 14:19:52 --> Config Class Initialized
INFO - 2017-02-21 14:19:52 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:19:52 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:19:52 --> Utf8 Class Initialized
INFO - 2017-02-21 14:19:52 --> URI Class Initialized
INFO - 2017-02-21 14:19:52 --> Router Class Initialized
INFO - 2017-02-21 14:19:52 --> Output Class Initialized
INFO - 2017-02-21 14:19:52 --> Security Class Initialized
DEBUG - 2017-02-21 14:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:19:52 --> Input Class Initialized
INFO - 2017-02-21 14:19:52 --> Language Class Initialized
INFO - 2017-02-21 14:19:52 --> Loader Class Initialized
INFO - 2017-02-21 14:19:52 --> Helper loaded: url_helper
INFO - 2017-02-21 14:19:52 --> Helper loaded: language_helper
INFO - 2017-02-21 14:19:52 --> Helper loaded: html_helper
INFO - 2017-02-21 14:19:52 --> Helper loaded: form_helper
INFO - 2017-02-21 14:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:19:52 --> Controller Class Initialized
INFO - 2017-02-21 14:19:52 --> Database Driver Class Initialized
INFO - 2017-02-21 14:19:52 --> Model Class Initialized
INFO - 2017-02-21 14:19:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:19:52 --> Form Validation Class Initialized
INFO - 2017-02-21 14:19:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 14:19:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 14:19:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 14:19:52 --> Final output sent to browser
DEBUG - 2017-02-21 14:19:52 --> Total execution time: 0.0859
INFO - 2017-02-21 14:32:07 --> Config Class Initialized
INFO - 2017-02-21 14:32:07 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:32:07 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:32:07 --> Utf8 Class Initialized
INFO - 2017-02-21 14:32:07 --> URI Class Initialized
INFO - 2017-02-21 14:32:07 --> Router Class Initialized
INFO - 2017-02-21 14:32:07 --> Output Class Initialized
INFO - 2017-02-21 14:32:07 --> Security Class Initialized
DEBUG - 2017-02-21 14:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:32:07 --> Input Class Initialized
INFO - 2017-02-21 14:32:07 --> Language Class Initialized
INFO - 2017-02-21 14:32:07 --> Loader Class Initialized
INFO - 2017-02-21 14:32:07 --> Helper loaded: url_helper
INFO - 2017-02-21 14:32:07 --> Helper loaded: language_helper
INFO - 2017-02-21 14:32:07 --> Helper loaded: html_helper
INFO - 2017-02-21 14:32:07 --> Helper loaded: form_helper
INFO - 2017-02-21 14:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:32:07 --> Controller Class Initialized
INFO - 2017-02-21 14:32:07 --> Database Driver Class Initialized
INFO - 2017-02-21 14:32:07 --> Model Class Initialized
INFO - 2017-02-21 14:32:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:32:07 --> Form Validation Class Initialized
INFO - 2017-02-21 14:32:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 14:32:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 14:32:07 --> Final output sent to browser
DEBUG - 2017-02-21 14:32:07 --> Total execution time: 0.1173
INFO - 2017-02-21 14:40:45 --> Config Class Initialized
INFO - 2017-02-21 14:40:45 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:40:45 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:40:45 --> Utf8 Class Initialized
INFO - 2017-02-21 14:40:45 --> URI Class Initialized
INFO - 2017-02-21 14:40:45 --> Router Class Initialized
INFO - 2017-02-21 14:40:45 --> Output Class Initialized
INFO - 2017-02-21 14:40:45 --> Security Class Initialized
DEBUG - 2017-02-21 14:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:40:45 --> Input Class Initialized
INFO - 2017-02-21 14:40:45 --> Language Class Initialized
INFO - 2017-02-21 14:40:45 --> Loader Class Initialized
INFO - 2017-02-21 14:40:45 --> Helper loaded: url_helper
INFO - 2017-02-21 14:40:45 --> Helper loaded: language_helper
INFO - 2017-02-21 14:40:45 --> Helper loaded: html_helper
INFO - 2017-02-21 14:40:45 --> Helper loaded: form_helper
INFO - 2017-02-21 14:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:40:45 --> Controller Class Initialized
INFO - 2017-02-21 14:40:45 --> Database Driver Class Initialized
INFO - 2017-02-21 14:40:45 --> Model Class Initialized
INFO - 2017-02-21 14:40:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:40:45 --> Form Validation Class Initialized
INFO - 2017-02-21 14:40:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 14:40:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 14:40:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 14:40:45 --> Final output sent to browser
DEBUG - 2017-02-21 14:40:45 --> Total execution time: 0.0945
INFO - 2017-02-21 14:55:33 --> Config Class Initialized
INFO - 2017-02-21 14:55:33 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:55:33 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:55:33 --> Utf8 Class Initialized
INFO - 2017-02-21 14:55:33 --> URI Class Initialized
INFO - 2017-02-21 14:55:33 --> Router Class Initialized
INFO - 2017-02-21 14:55:33 --> Output Class Initialized
INFO - 2017-02-21 14:55:33 --> Security Class Initialized
DEBUG - 2017-02-21 14:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:55:33 --> Input Class Initialized
INFO - 2017-02-21 14:55:33 --> Language Class Initialized
INFO - 2017-02-21 14:55:33 --> Loader Class Initialized
INFO - 2017-02-21 14:55:33 --> Helper loaded: url_helper
INFO - 2017-02-21 14:55:33 --> Helper loaded: language_helper
INFO - 2017-02-21 14:55:33 --> Helper loaded: html_helper
INFO - 2017-02-21 14:55:33 --> Helper loaded: form_helper
INFO - 2017-02-21 14:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:55:33 --> Controller Class Initialized
INFO - 2017-02-21 14:55:33 --> Database Driver Class Initialized
INFO - 2017-02-21 14:55:33 --> Model Class Initialized
INFO - 2017-02-21 14:55:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:55:33 --> Email Class Initialized
INFO - 2017-02-21 14:55:36 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 14:56:51 --> Config Class Initialized
INFO - 2017-02-21 14:56:51 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:56:51 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:56:51 --> Utf8 Class Initialized
INFO - 2017-02-21 14:56:51 --> URI Class Initialized
INFO - 2017-02-21 14:56:51 --> Router Class Initialized
INFO - 2017-02-21 14:56:51 --> Output Class Initialized
INFO - 2017-02-21 14:56:51 --> Security Class Initialized
DEBUG - 2017-02-21 14:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:56:51 --> Input Class Initialized
INFO - 2017-02-21 14:56:51 --> Language Class Initialized
INFO - 2017-02-21 14:56:51 --> Loader Class Initialized
INFO - 2017-02-21 14:56:51 --> Helper loaded: url_helper
INFO - 2017-02-21 14:56:51 --> Helper loaded: language_helper
INFO - 2017-02-21 14:56:51 --> Helper loaded: html_helper
INFO - 2017-02-21 14:56:51 --> Helper loaded: form_helper
INFO - 2017-02-21 14:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:56:51 --> Controller Class Initialized
INFO - 2017-02-21 14:56:51 --> Database Driver Class Initialized
INFO - 2017-02-21 14:56:51 --> Model Class Initialized
INFO - 2017-02-21 14:56:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:56:51 --> Email Class Initialized
INFO - 2017-02-21 14:56:53 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 14:57:29 --> Config Class Initialized
INFO - 2017-02-21 14:57:29 --> Hooks Class Initialized
DEBUG - 2017-02-21 14:57:29 --> UTF-8 Support Enabled
INFO - 2017-02-21 14:57:29 --> Utf8 Class Initialized
INFO - 2017-02-21 14:57:29 --> URI Class Initialized
INFO - 2017-02-21 14:57:29 --> Router Class Initialized
INFO - 2017-02-21 14:57:29 --> Output Class Initialized
INFO - 2017-02-21 14:57:29 --> Security Class Initialized
DEBUG - 2017-02-21 14:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 14:57:29 --> Input Class Initialized
INFO - 2017-02-21 14:57:29 --> Language Class Initialized
INFO - 2017-02-21 14:57:29 --> Loader Class Initialized
INFO - 2017-02-21 14:57:29 --> Helper loaded: url_helper
INFO - 2017-02-21 14:57:29 --> Helper loaded: language_helper
INFO - 2017-02-21 14:57:29 --> Helper loaded: html_helper
INFO - 2017-02-21 14:57:29 --> Helper loaded: form_helper
INFO - 2017-02-21 14:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 14:57:29 --> Controller Class Initialized
INFO - 2017-02-21 14:57:30 --> Database Driver Class Initialized
INFO - 2017-02-21 14:57:30 --> Model Class Initialized
INFO - 2017-02-21 14:57:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 14:57:30 --> Email Class Initialized
INFO - 2017-02-21 14:57:31 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:01:52 --> Config Class Initialized
INFO - 2017-02-21 15:01:52 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:01:52 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:01:52 --> Utf8 Class Initialized
INFO - 2017-02-21 15:01:52 --> URI Class Initialized
INFO - 2017-02-21 15:01:52 --> Router Class Initialized
INFO - 2017-02-21 15:01:52 --> Output Class Initialized
INFO - 2017-02-21 15:01:52 --> Security Class Initialized
DEBUG - 2017-02-21 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:01:52 --> Input Class Initialized
INFO - 2017-02-21 15:01:52 --> Language Class Initialized
INFO - 2017-02-21 15:01:52 --> Loader Class Initialized
INFO - 2017-02-21 15:01:52 --> Helper loaded: url_helper
INFO - 2017-02-21 15:01:52 --> Helper loaded: language_helper
INFO - 2017-02-21 15:01:52 --> Helper loaded: html_helper
INFO - 2017-02-21 15:01:52 --> Helper loaded: form_helper
INFO - 2017-02-21 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:01:52 --> Controller Class Initialized
INFO - 2017-02-21 15:01:52 --> Database Driver Class Initialized
INFO - 2017-02-21 15:01:52 --> Model Class Initialized
INFO - 2017-02-21 15:01:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:01:52 --> Email Class Initialized
INFO - 2017-02-21 15:01:53 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:02:12 --> Config Class Initialized
INFO - 2017-02-21 15:02:12 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:02:12 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:02:12 --> Utf8 Class Initialized
INFO - 2017-02-21 15:02:12 --> URI Class Initialized
INFO - 2017-02-21 15:02:12 --> Router Class Initialized
INFO - 2017-02-21 15:02:12 --> Output Class Initialized
INFO - 2017-02-21 15:02:12 --> Security Class Initialized
DEBUG - 2017-02-21 15:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:02:12 --> Input Class Initialized
INFO - 2017-02-21 15:02:12 --> Language Class Initialized
INFO - 2017-02-21 15:02:12 --> Loader Class Initialized
INFO - 2017-02-21 15:02:12 --> Helper loaded: url_helper
INFO - 2017-02-21 15:02:12 --> Helper loaded: language_helper
INFO - 2017-02-21 15:02:12 --> Helper loaded: html_helper
INFO - 2017-02-21 15:02:12 --> Helper loaded: form_helper
INFO - 2017-02-21 15:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:02:12 --> Controller Class Initialized
INFO - 2017-02-21 15:02:12 --> Database Driver Class Initialized
INFO - 2017-02-21 15:02:12 --> Model Class Initialized
INFO - 2017-02-21 15:02:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:02:12 --> Email Class Initialized
INFO - 2017-02-21 15:02:12 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:02:49 --> Config Class Initialized
INFO - 2017-02-21 15:02:49 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:02:49 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:02:49 --> Utf8 Class Initialized
INFO - 2017-02-21 15:02:49 --> URI Class Initialized
INFO - 2017-02-21 15:02:49 --> Router Class Initialized
INFO - 2017-02-21 15:02:49 --> Output Class Initialized
INFO - 2017-02-21 15:02:49 --> Security Class Initialized
DEBUG - 2017-02-21 15:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:02:49 --> Input Class Initialized
INFO - 2017-02-21 15:02:49 --> Language Class Initialized
INFO - 2017-02-21 15:02:49 --> Loader Class Initialized
INFO - 2017-02-21 15:02:49 --> Helper loaded: url_helper
INFO - 2017-02-21 15:02:49 --> Helper loaded: language_helper
INFO - 2017-02-21 15:02:49 --> Helper loaded: html_helper
INFO - 2017-02-21 15:02:49 --> Helper loaded: form_helper
INFO - 2017-02-21 15:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:02:49 --> Controller Class Initialized
INFO - 2017-02-21 15:02:49 --> Database Driver Class Initialized
INFO - 2017-02-21 15:02:49 --> Model Class Initialized
INFO - 2017-02-21 15:02:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:02:49 --> Email Class Initialized
ERROR - 2017-02-21 15:02:50 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:140770FC:SSL routines:SSL23_GET_SERVER_HELLO:unknown protocol C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 15:02:50 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 15:02:50 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:587 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-21 15:02:50 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:03:14 --> Config Class Initialized
INFO - 2017-02-21 15:03:14 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:03:14 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:03:14 --> Utf8 Class Initialized
INFO - 2017-02-21 15:03:14 --> URI Class Initialized
INFO - 2017-02-21 15:03:14 --> Router Class Initialized
INFO - 2017-02-21 15:03:14 --> Output Class Initialized
INFO - 2017-02-21 15:03:14 --> Security Class Initialized
DEBUG - 2017-02-21 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:03:14 --> Input Class Initialized
INFO - 2017-02-21 15:03:14 --> Language Class Initialized
INFO - 2017-02-21 15:03:14 --> Loader Class Initialized
INFO - 2017-02-21 15:03:14 --> Helper loaded: url_helper
INFO - 2017-02-21 15:03:14 --> Helper loaded: language_helper
INFO - 2017-02-21 15:03:14 --> Helper loaded: html_helper
INFO - 2017-02-21 15:03:14 --> Helper loaded: form_helper
INFO - 2017-02-21 15:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:03:14 --> Controller Class Initialized
INFO - 2017-02-21 15:03:14 --> Database Driver Class Initialized
INFO - 2017-02-21 15:03:14 --> Model Class Initialized
INFO - 2017-02-21 15:03:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:03:14 --> Email Class Initialized
INFO - 2017-02-21 15:03:14 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:04:16 --> Config Class Initialized
INFO - 2017-02-21 15:04:16 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:04:16 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:04:16 --> Utf8 Class Initialized
INFO - 2017-02-21 15:04:16 --> URI Class Initialized
INFO - 2017-02-21 15:04:16 --> Router Class Initialized
INFO - 2017-02-21 15:04:16 --> Output Class Initialized
INFO - 2017-02-21 15:04:16 --> Security Class Initialized
DEBUG - 2017-02-21 15:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:04:16 --> Input Class Initialized
INFO - 2017-02-21 15:04:16 --> Language Class Initialized
INFO - 2017-02-21 15:04:16 --> Loader Class Initialized
INFO - 2017-02-21 15:04:16 --> Helper loaded: url_helper
INFO - 2017-02-21 15:04:16 --> Helper loaded: language_helper
INFO - 2017-02-21 15:04:16 --> Helper loaded: html_helper
INFO - 2017-02-21 15:04:16 --> Helper loaded: form_helper
INFO - 2017-02-21 15:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:04:16 --> Controller Class Initialized
INFO - 2017-02-21 15:04:16 --> Database Driver Class Initialized
INFO - 2017-02-21 15:04:16 --> Model Class Initialized
INFO - 2017-02-21 15:04:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:04:16 --> Email Class Initialized
INFO - 2017-02-21 15:04:16 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:05:52 --> Config Class Initialized
INFO - 2017-02-21 15:05:52 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:05:52 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:05:52 --> Utf8 Class Initialized
INFO - 2017-02-21 15:05:52 --> URI Class Initialized
INFO - 2017-02-21 15:05:52 --> Router Class Initialized
INFO - 2017-02-21 15:05:52 --> Output Class Initialized
INFO - 2017-02-21 15:05:52 --> Security Class Initialized
DEBUG - 2017-02-21 15:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:05:52 --> Input Class Initialized
INFO - 2017-02-21 15:05:52 --> Language Class Initialized
INFO - 2017-02-21 15:05:52 --> Loader Class Initialized
INFO - 2017-02-21 15:05:52 --> Helper loaded: url_helper
INFO - 2017-02-21 15:05:52 --> Helper loaded: language_helper
INFO - 2017-02-21 15:05:52 --> Helper loaded: html_helper
INFO - 2017-02-21 15:05:52 --> Helper loaded: form_helper
INFO - 2017-02-21 15:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:05:52 --> Controller Class Initialized
INFO - 2017-02-21 15:05:52 --> Database Driver Class Initialized
INFO - 2017-02-21 15:05:52 --> Model Class Initialized
INFO - 2017-02-21 15:05:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:05:52 --> Email Class Initialized
INFO - 2017-02-21 15:05:52 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:13:44 --> Config Class Initialized
INFO - 2017-02-21 15:13:44 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:13:44 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:13:44 --> Utf8 Class Initialized
INFO - 2017-02-21 15:13:44 --> URI Class Initialized
INFO - 2017-02-21 15:13:44 --> Router Class Initialized
INFO - 2017-02-21 15:13:44 --> Output Class Initialized
INFO - 2017-02-21 15:13:44 --> Security Class Initialized
DEBUG - 2017-02-21 15:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:13:44 --> Input Class Initialized
INFO - 2017-02-21 15:13:44 --> Language Class Initialized
INFO - 2017-02-21 15:13:44 --> Loader Class Initialized
INFO - 2017-02-21 15:13:44 --> Helper loaded: url_helper
INFO - 2017-02-21 15:13:44 --> Helper loaded: language_helper
INFO - 2017-02-21 15:13:44 --> Helper loaded: html_helper
INFO - 2017-02-21 15:13:44 --> Helper loaded: form_helper
INFO - 2017-02-21 15:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:13:44 --> Controller Class Initialized
INFO - 2017-02-21 15:13:44 --> Database Driver Class Initialized
INFO - 2017-02-21 15:13:44 --> Model Class Initialized
INFO - 2017-02-21 15:13:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:13:44 --> Email Class Initialized
INFO - 2017-02-21 15:13:48 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:17:14 --> Config Class Initialized
INFO - 2017-02-21 15:17:14 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:17:14 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:17:14 --> Utf8 Class Initialized
INFO - 2017-02-21 15:17:14 --> URI Class Initialized
INFO - 2017-02-21 15:17:14 --> Router Class Initialized
INFO - 2017-02-21 15:17:14 --> Output Class Initialized
INFO - 2017-02-21 15:17:14 --> Security Class Initialized
DEBUG - 2017-02-21 15:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:17:14 --> Input Class Initialized
INFO - 2017-02-21 15:17:14 --> Language Class Initialized
INFO - 2017-02-21 15:17:14 --> Loader Class Initialized
INFO - 2017-02-21 15:17:14 --> Helper loaded: url_helper
INFO - 2017-02-21 15:17:14 --> Helper loaded: language_helper
INFO - 2017-02-21 15:17:14 --> Helper loaded: html_helper
INFO - 2017-02-21 15:17:14 --> Helper loaded: form_helper
INFO - 2017-02-21 15:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:17:14 --> Controller Class Initialized
INFO - 2017-02-21 15:17:14 --> Database Driver Class Initialized
INFO - 2017-02-21 15:17:14 --> Model Class Initialized
INFO - 2017-02-21 15:17:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:17:14 --> Email Class Initialized
ERROR - 2017-02-21 15:17:15 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 15:17:15 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 15:17:15 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-21 15:17:15 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:18:39 --> Config Class Initialized
INFO - 2017-02-21 15:18:39 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:18:39 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:18:39 --> Utf8 Class Initialized
INFO - 2017-02-21 15:18:39 --> URI Class Initialized
INFO - 2017-02-21 15:18:39 --> Router Class Initialized
INFO - 2017-02-21 15:18:39 --> Output Class Initialized
INFO - 2017-02-21 15:18:39 --> Security Class Initialized
DEBUG - 2017-02-21 15:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:18:39 --> Input Class Initialized
INFO - 2017-02-21 15:18:39 --> Language Class Initialized
INFO - 2017-02-21 15:18:39 --> Loader Class Initialized
INFO - 2017-02-21 15:18:39 --> Helper loaded: url_helper
INFO - 2017-02-21 15:18:39 --> Helper loaded: language_helper
INFO - 2017-02-21 15:18:39 --> Helper loaded: html_helper
INFO - 2017-02-21 15:18:39 --> Helper loaded: form_helper
INFO - 2017-02-21 15:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:18:39 --> Controller Class Initialized
INFO - 2017-02-21 15:18:39 --> Database Driver Class Initialized
INFO - 2017-02-21 15:18:39 --> Model Class Initialized
INFO - 2017-02-21 15:18:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:18:39 --> Email Class Initialized
INFO - 2017-02-21 15:18:42 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:18:45 --> Final output sent to browser
DEBUG - 2017-02-21 15:18:45 --> Total execution time: 6.1432
INFO - 2017-02-21 15:19:15 --> Config Class Initialized
INFO - 2017-02-21 15:19:15 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:19:15 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:19:15 --> Utf8 Class Initialized
INFO - 2017-02-21 15:19:15 --> URI Class Initialized
INFO - 2017-02-21 15:19:15 --> Router Class Initialized
INFO - 2017-02-21 15:19:15 --> Output Class Initialized
INFO - 2017-02-21 15:19:15 --> Security Class Initialized
DEBUG - 2017-02-21 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:19:15 --> Input Class Initialized
INFO - 2017-02-21 15:19:15 --> Language Class Initialized
INFO - 2017-02-21 15:19:15 --> Loader Class Initialized
INFO - 2017-02-21 15:19:15 --> Helper loaded: url_helper
INFO - 2017-02-21 15:19:15 --> Helper loaded: language_helper
INFO - 2017-02-21 15:19:15 --> Helper loaded: html_helper
INFO - 2017-02-21 15:19:15 --> Helper loaded: form_helper
INFO - 2017-02-21 15:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:19:15 --> Controller Class Initialized
INFO - 2017-02-21 15:19:15 --> Database Driver Class Initialized
INFO - 2017-02-21 15:19:15 --> Model Class Initialized
INFO - 2017-02-21 15:19:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:19:15 --> Email Class Initialized
INFO - 2017-02-21 15:19:15 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:19:19 --> Final output sent to browser
DEBUG - 2017-02-21 15:19:19 --> Total execution time: 4.1078
INFO - 2017-02-21 15:48:12 --> Config Class Initialized
INFO - 2017-02-21 15:48:12 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:48:12 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:48:12 --> Utf8 Class Initialized
INFO - 2017-02-21 15:48:12 --> URI Class Initialized
INFO - 2017-02-21 15:48:12 --> Router Class Initialized
INFO - 2017-02-21 15:48:12 --> Output Class Initialized
INFO - 2017-02-21 15:48:12 --> Security Class Initialized
DEBUG - 2017-02-21 15:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:48:12 --> Input Class Initialized
INFO - 2017-02-21 15:48:12 --> Language Class Initialized
INFO - 2017-02-21 15:48:12 --> Loader Class Initialized
INFO - 2017-02-21 15:48:12 --> Helper loaded: url_helper
INFO - 2017-02-21 15:48:12 --> Helper loaded: language_helper
INFO - 2017-02-21 15:48:12 --> Helper loaded: html_helper
INFO - 2017-02-21 15:48:12 --> Helper loaded: form_helper
INFO - 2017-02-21 15:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:48:12 --> Controller Class Initialized
INFO - 2017-02-21 15:48:12 --> Database Driver Class Initialized
INFO - 2017-02-21 15:48:12 --> Model Class Initialized
INFO - 2017-02-21 15:48:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:48:12 --> Form Validation Class Initialized
INFO - 2017-02-21 15:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 15:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 15:48:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 15:48:12 --> Final output sent to browser
DEBUG - 2017-02-21 15:48:12 --> Total execution time: 0.2490
INFO - 2017-02-21 15:49:37 --> Config Class Initialized
INFO - 2017-02-21 15:49:37 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:49:37 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:49:37 --> Utf8 Class Initialized
INFO - 2017-02-21 15:49:37 --> URI Class Initialized
INFO - 2017-02-21 15:49:37 --> Router Class Initialized
INFO - 2017-02-21 15:49:37 --> Output Class Initialized
INFO - 2017-02-21 15:49:37 --> Security Class Initialized
DEBUG - 2017-02-21 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:49:37 --> Input Class Initialized
INFO - 2017-02-21 15:49:37 --> Language Class Initialized
INFO - 2017-02-21 15:49:38 --> Loader Class Initialized
INFO - 2017-02-21 15:49:38 --> Helper loaded: url_helper
INFO - 2017-02-21 15:49:38 --> Helper loaded: language_helper
INFO - 2017-02-21 15:49:38 --> Helper loaded: html_helper
INFO - 2017-02-21 15:49:38 --> Helper loaded: form_helper
INFO - 2017-02-21 15:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:49:38 --> Controller Class Initialized
INFO - 2017-02-21 15:49:38 --> Database Driver Class Initialized
INFO - 2017-02-21 15:49:38 --> Model Class Initialized
INFO - 2017-02-21 15:49:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:49:38 --> Form Validation Class Initialized
INFO - 2017-02-21 15:49:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 15:49:38 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-21 15:49:38 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\savsoftquiz\application\models\Register_model.php 144
INFO - 2017-02-21 15:49:38 --> Email Class Initialized
ERROR - 2017-02-21 15:49:38 --> Severity: Notice --> Undefined variable: toemail C:\wamp64\www\savsoftquiz\application\models\Register_model.php 53
ERROR - 2017-02-21 15:49:39 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 15:49:39 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 15:49:39 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-21 15:49:39 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:50:51 --> Config Class Initialized
INFO - 2017-02-21 15:50:51 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:50:51 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:50:51 --> Utf8 Class Initialized
INFO - 2017-02-21 15:50:51 --> URI Class Initialized
INFO - 2017-02-21 15:50:51 --> Router Class Initialized
INFO - 2017-02-21 15:50:51 --> Output Class Initialized
INFO - 2017-02-21 15:50:51 --> Security Class Initialized
DEBUG - 2017-02-21 15:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:50:51 --> Input Class Initialized
INFO - 2017-02-21 15:50:51 --> Language Class Initialized
INFO - 2017-02-21 15:50:51 --> Loader Class Initialized
INFO - 2017-02-21 15:50:51 --> Helper loaded: url_helper
INFO - 2017-02-21 15:50:51 --> Helper loaded: language_helper
INFO - 2017-02-21 15:50:51 --> Helper loaded: html_helper
INFO - 2017-02-21 15:50:51 --> Helper loaded: form_helper
INFO - 2017-02-21 15:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:50:51 --> Controller Class Initialized
INFO - 2017-02-21 15:50:51 --> Database Driver Class Initialized
INFO - 2017-02-21 15:50:51 --> Model Class Initialized
INFO - 2017-02-21 15:50:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:50:51 --> Form Validation Class Initialized
INFO - 2017-02-21 15:50:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 15:50:51 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-21 15:50:51 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\savsoftquiz\application\models\Register_model.php 146
INFO - 2017-02-21 15:50:51 --> Email Class Initialized
INFO - 2017-02-21 15:50:51 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:50:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-21 15:50:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 15:50:55 --> Final output sent to browser
DEBUG - 2017-02-21 15:50:55 --> Total execution time: 3.9193
INFO - 2017-02-21 15:53:36 --> Config Class Initialized
INFO - 2017-02-21 15:53:36 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:53:36 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:53:36 --> Utf8 Class Initialized
INFO - 2017-02-21 15:53:36 --> URI Class Initialized
INFO - 2017-02-21 15:53:36 --> Router Class Initialized
INFO - 2017-02-21 15:53:36 --> Output Class Initialized
INFO - 2017-02-21 15:53:36 --> Security Class Initialized
DEBUG - 2017-02-21 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:53:36 --> Input Class Initialized
INFO - 2017-02-21 15:53:36 --> Language Class Initialized
INFO - 2017-02-21 15:53:36 --> Loader Class Initialized
INFO - 2017-02-21 15:53:36 --> Helper loaded: url_helper
INFO - 2017-02-21 15:53:36 --> Helper loaded: language_helper
INFO - 2017-02-21 15:53:36 --> Helper loaded: html_helper
INFO - 2017-02-21 15:53:36 --> Helper loaded: form_helper
INFO - 2017-02-21 15:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:53:36 --> Controller Class Initialized
INFO - 2017-02-21 15:53:36 --> Database Driver Class Initialized
INFO - 2017-02-21 15:53:36 --> Model Class Initialized
INFO - 2017-02-21 15:53:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:53:36 --> Form Validation Class Initialized
INFO - 2017-02-21 15:53:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 15:53:36 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-21 15:53:36 --> Severity: Notice --> Trying to get property of non-object C:\wamp64\www\savsoftquiz\application\models\Register_model.php 145
INFO - 2017-02-21 15:53:49 --> Config Class Initialized
INFO - 2017-02-21 15:53:49 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:53:49 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:53:49 --> Utf8 Class Initialized
INFO - 2017-02-21 15:53:49 --> URI Class Initialized
INFO - 2017-02-21 15:53:49 --> Router Class Initialized
INFO - 2017-02-21 15:53:49 --> Output Class Initialized
INFO - 2017-02-21 15:53:49 --> Security Class Initialized
DEBUG - 2017-02-21 15:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:53:49 --> Input Class Initialized
INFO - 2017-02-21 15:53:49 --> Language Class Initialized
INFO - 2017-02-21 15:53:49 --> Loader Class Initialized
INFO - 2017-02-21 15:53:49 --> Helper loaded: url_helper
INFO - 2017-02-21 15:53:49 --> Helper loaded: language_helper
INFO - 2017-02-21 15:53:49 --> Helper loaded: html_helper
INFO - 2017-02-21 15:53:49 --> Helper loaded: form_helper
INFO - 2017-02-21 15:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:53:49 --> Controller Class Initialized
INFO - 2017-02-21 15:53:49 --> Database Driver Class Initialized
INFO - 2017-02-21 15:53:49 --> Model Class Initialized
INFO - 2017-02-21 15:53:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:53:49 --> Form Validation Class Initialized
INFO - 2017-02-21 15:53:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 15:53:49 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 15:54:18 --> Config Class Initialized
INFO - 2017-02-21 15:54:18 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:54:18 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:54:18 --> Utf8 Class Initialized
INFO - 2017-02-21 15:54:18 --> URI Class Initialized
INFO - 2017-02-21 15:54:18 --> Router Class Initialized
INFO - 2017-02-21 15:54:18 --> Output Class Initialized
INFO - 2017-02-21 15:54:18 --> Security Class Initialized
DEBUG - 2017-02-21 15:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:54:18 --> Input Class Initialized
INFO - 2017-02-21 15:54:18 --> Language Class Initialized
INFO - 2017-02-21 15:54:18 --> Loader Class Initialized
INFO - 2017-02-21 15:54:18 --> Helper loaded: url_helper
INFO - 2017-02-21 15:54:18 --> Helper loaded: language_helper
INFO - 2017-02-21 15:54:18 --> Helper loaded: html_helper
INFO - 2017-02-21 15:54:18 --> Helper loaded: form_helper
INFO - 2017-02-21 15:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:54:18 --> Controller Class Initialized
INFO - 2017-02-21 15:54:18 --> Database Driver Class Initialized
INFO - 2017-02-21 15:54:18 --> Model Class Initialized
INFO - 2017-02-21 15:54:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:54:18 --> Form Validation Class Initialized
INFO - 2017-02-21 15:54:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 15:54:18 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 15:54:18 --> Email Class Initialized
INFO - 2017-02-21 15:54:19 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 15:54:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-21 15:54:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 15:54:24 --> Final output sent to browser
DEBUG - 2017-02-21 15:54:24 --> Total execution time: 6.4239
INFO - 2017-02-21 15:56:52 --> Config Class Initialized
INFO - 2017-02-21 15:56:52 --> Hooks Class Initialized
DEBUG - 2017-02-21 15:56:52 --> UTF-8 Support Enabled
INFO - 2017-02-21 15:56:52 --> Utf8 Class Initialized
INFO - 2017-02-21 15:56:52 --> URI Class Initialized
INFO - 2017-02-21 15:56:52 --> Router Class Initialized
INFO - 2017-02-21 15:56:52 --> Output Class Initialized
INFO - 2017-02-21 15:56:52 --> Security Class Initialized
DEBUG - 2017-02-21 15:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 15:56:52 --> Input Class Initialized
INFO - 2017-02-21 15:56:52 --> Language Class Initialized
INFO - 2017-02-21 15:56:52 --> Loader Class Initialized
INFO - 2017-02-21 15:56:52 --> Helper loaded: url_helper
INFO - 2017-02-21 15:56:52 --> Helper loaded: language_helper
INFO - 2017-02-21 15:56:52 --> Helper loaded: html_helper
INFO - 2017-02-21 15:56:52 --> Helper loaded: form_helper
INFO - 2017-02-21 15:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 15:56:52 --> Controller Class Initialized
INFO - 2017-02-21 15:56:52 --> Database Driver Class Initialized
INFO - 2017-02-21 15:56:52 --> Model Class Initialized
INFO - 2017-02-21 15:56:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 15:56:52 --> Form Validation Class Initialized
INFO - 2017-02-21 15:56:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 15:56:52 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 15:56:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 15:56:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 15:56:52 --> Final output sent to browser
DEBUG - 2017-02-21 15:56:52 --> Total execution time: 0.1806
INFO - 2017-02-21 16:22:28 --> Config Class Initialized
INFO - 2017-02-21 16:22:28 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:22:28 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:22:28 --> Utf8 Class Initialized
INFO - 2017-02-21 16:22:28 --> URI Class Initialized
INFO - 2017-02-21 16:22:28 --> Router Class Initialized
INFO - 2017-02-21 16:22:28 --> Output Class Initialized
INFO - 2017-02-21 16:22:28 --> Security Class Initialized
DEBUG - 2017-02-21 16:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:22:28 --> Input Class Initialized
INFO - 2017-02-21 16:22:28 --> Language Class Initialized
INFO - 2017-02-21 16:22:28 --> Loader Class Initialized
INFO - 2017-02-21 16:22:28 --> Helper loaded: url_helper
INFO - 2017-02-21 16:22:28 --> Helper loaded: language_helper
INFO - 2017-02-21 16:22:28 --> Helper loaded: html_helper
INFO - 2017-02-21 16:22:28 --> Helper loaded: form_helper
INFO - 2017-02-21 16:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:22:28 --> Controller Class Initialized
INFO - 2017-02-21 16:22:28 --> Database Driver Class Initialized
INFO - 2017-02-21 16:22:28 --> Model Class Initialized
INFO - 2017-02-21 16:22:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:22:28 --> Form Validation Class Initialized
INFO - 2017-02-21 16:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 16:22:28 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-02-21 16:22:28 --> Unable to find validation rule: xss_clean
ERROR - 2017-02-21 16:22:28 --> Could not find the language line "form_validation_xss_clean"
INFO - 2017-02-21 16:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 16:22:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 16:22:28 --> Final output sent to browser
DEBUG - 2017-02-21 16:22:28 --> Total execution time: 0.1935
INFO - 2017-02-21 16:32:03 --> Config Class Initialized
INFO - 2017-02-21 16:32:03 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:32:03 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:32:03 --> Utf8 Class Initialized
INFO - 2017-02-21 16:32:03 --> URI Class Initialized
INFO - 2017-02-21 16:32:03 --> Router Class Initialized
INFO - 2017-02-21 16:32:03 --> Output Class Initialized
INFO - 2017-02-21 16:32:03 --> Security Class Initialized
DEBUG - 2017-02-21 16:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:32:03 --> Input Class Initialized
INFO - 2017-02-21 16:32:03 --> Language Class Initialized
INFO - 2017-02-21 16:32:03 --> Loader Class Initialized
INFO - 2017-02-21 16:32:03 --> Helper loaded: url_helper
INFO - 2017-02-21 16:32:03 --> Helper loaded: language_helper
INFO - 2017-02-21 16:32:03 --> Helper loaded: html_helper
INFO - 2017-02-21 16:32:03 --> Helper loaded: form_helper
INFO - 2017-02-21 16:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:32:03 --> Controller Class Initialized
INFO - 2017-02-21 16:32:03 --> Database Driver Class Initialized
INFO - 2017-02-21 16:32:03 --> Model Class Initialized
INFO - 2017-02-21 16:32:03 --> Email Class Initialized
INFO - 2017-02-21 16:32:03 --> Form Validation Class Initialized
INFO - 2017-02-21 16:32:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 16:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 16:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 16:32:03 --> Final output sent to browser
DEBUG - 2017-02-21 16:32:03 --> Total execution time: 0.1444
INFO - 2017-02-21 16:37:47 --> Config Class Initialized
INFO - 2017-02-21 16:37:47 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:37:47 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:37:47 --> Utf8 Class Initialized
INFO - 2017-02-21 16:37:47 --> URI Class Initialized
INFO - 2017-02-21 16:37:47 --> Router Class Initialized
INFO - 2017-02-21 16:37:47 --> Output Class Initialized
INFO - 2017-02-21 16:37:47 --> Security Class Initialized
DEBUG - 2017-02-21 16:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:37:47 --> Input Class Initialized
INFO - 2017-02-21 16:37:47 --> Language Class Initialized
INFO - 2017-02-21 16:37:47 --> Loader Class Initialized
INFO - 2017-02-21 16:37:47 --> Helper loaded: url_helper
INFO - 2017-02-21 16:37:47 --> Helper loaded: language_helper
INFO - 2017-02-21 16:37:47 --> Helper loaded: html_helper
INFO - 2017-02-21 16:37:47 --> Helper loaded: form_helper
INFO - 2017-02-21 16:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:37:47 --> Controller Class Initialized
INFO - 2017-02-21 16:37:47 --> Database Driver Class Initialized
INFO - 2017-02-21 16:37:47 --> Model Class Initialized
INFO - 2017-02-21 16:37:47 --> Email Class Initialized
INFO - 2017-02-21 16:37:47 --> Form Validation Class Initialized
INFO - 2017-02-21 16:37:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:37:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 16:37:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 16:37:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 16:37:47 --> Final output sent to browser
DEBUG - 2017-02-21 16:37:47 --> Total execution time: 0.1945
INFO - 2017-02-21 16:38:04 --> Config Class Initialized
INFO - 2017-02-21 16:38:04 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:38:04 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:38:04 --> Utf8 Class Initialized
INFO - 2017-02-21 16:38:04 --> URI Class Initialized
INFO - 2017-02-21 16:38:04 --> Router Class Initialized
INFO - 2017-02-21 16:38:04 --> Output Class Initialized
INFO - 2017-02-21 16:38:04 --> Security Class Initialized
DEBUG - 2017-02-21 16:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:38:04 --> Input Class Initialized
INFO - 2017-02-21 16:38:04 --> Language Class Initialized
INFO - 2017-02-21 16:38:04 --> Loader Class Initialized
INFO - 2017-02-21 16:38:04 --> Helper loaded: url_helper
INFO - 2017-02-21 16:38:04 --> Helper loaded: language_helper
INFO - 2017-02-21 16:38:04 --> Helper loaded: html_helper
INFO - 2017-02-21 16:38:04 --> Helper loaded: form_helper
INFO - 2017-02-21 16:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:38:04 --> Controller Class Initialized
INFO - 2017-02-21 16:38:04 --> Database Driver Class Initialized
INFO - 2017-02-21 16:38:04 --> Model Class Initialized
INFO - 2017-02-21 16:38:04 --> Email Class Initialized
INFO - 2017-02-21 16:38:04 --> Form Validation Class Initialized
INFO - 2017-02-21 16:38:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:38:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 16:38:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 16:38:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 16:38:04 --> Final output sent to browser
DEBUG - 2017-02-21 16:38:04 --> Total execution time: 0.1707
INFO - 2017-02-21 16:38:06 --> Config Class Initialized
INFO - 2017-02-21 16:38:06 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:38:06 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:38:06 --> Utf8 Class Initialized
INFO - 2017-02-21 16:38:06 --> URI Class Initialized
INFO - 2017-02-21 16:38:06 --> Router Class Initialized
INFO - 2017-02-21 16:38:06 --> Output Class Initialized
INFO - 2017-02-21 16:38:06 --> Security Class Initialized
DEBUG - 2017-02-21 16:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:38:06 --> Input Class Initialized
INFO - 2017-02-21 16:38:06 --> Language Class Initialized
INFO - 2017-02-21 16:38:06 --> Loader Class Initialized
INFO - 2017-02-21 16:38:06 --> Helper loaded: url_helper
INFO - 2017-02-21 16:38:06 --> Helper loaded: language_helper
INFO - 2017-02-21 16:38:06 --> Helper loaded: html_helper
INFO - 2017-02-21 16:38:06 --> Helper loaded: form_helper
INFO - 2017-02-21 16:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:38:06 --> Controller Class Initialized
INFO - 2017-02-21 16:38:06 --> Database Driver Class Initialized
INFO - 2017-02-21 16:38:06 --> Model Class Initialized
INFO - 2017-02-21 16:38:06 --> Email Class Initialized
INFO - 2017-02-21 16:38:06 --> Form Validation Class Initialized
INFO - 2017-02-21 16:38:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:38:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 16:38:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 16:38:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 16:38:06 --> Final output sent to browser
DEBUG - 2017-02-21 16:38:06 --> Total execution time: 0.1914
INFO - 2017-02-21 16:51:40 --> Config Class Initialized
INFO - 2017-02-21 16:51:40 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:51:40 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:51:40 --> Utf8 Class Initialized
INFO - 2017-02-21 16:51:40 --> URI Class Initialized
INFO - 2017-02-21 16:51:40 --> Router Class Initialized
INFO - 2017-02-21 16:51:40 --> Output Class Initialized
INFO - 2017-02-21 16:51:40 --> Security Class Initialized
DEBUG - 2017-02-21 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:51:40 --> Input Class Initialized
INFO - 2017-02-21 16:51:40 --> Language Class Initialized
INFO - 2017-02-21 16:51:40 --> Loader Class Initialized
INFO - 2017-02-21 16:51:40 --> Helper loaded: url_helper
INFO - 2017-02-21 16:51:40 --> Helper loaded: language_helper
INFO - 2017-02-21 16:51:40 --> Helper loaded: html_helper
INFO - 2017-02-21 16:51:40 --> Helper loaded: form_helper
INFO - 2017-02-21 16:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:51:40 --> Controller Class Initialized
INFO - 2017-02-21 16:51:40 --> Database Driver Class Initialized
INFO - 2017-02-21 16:51:40 --> Model Class Initialized
INFO - 2017-02-21 16:51:40 --> Email Class Initialized
INFO - 2017-02-21 16:51:40 --> Form Validation Class Initialized
INFO - 2017-02-21 16:51:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:51:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 16:51:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 16:51:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 16:51:40 --> Final output sent to browser
DEBUG - 2017-02-21 16:51:40 --> Total execution time: 0.2025
INFO - 2017-02-21 16:51:44 --> Config Class Initialized
INFO - 2017-02-21 16:51:44 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:51:44 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:51:44 --> Utf8 Class Initialized
INFO - 2017-02-21 16:51:44 --> URI Class Initialized
INFO - 2017-02-21 16:51:44 --> Router Class Initialized
INFO - 2017-02-21 16:51:44 --> Output Class Initialized
INFO - 2017-02-21 16:51:44 --> Security Class Initialized
DEBUG - 2017-02-21 16:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:51:44 --> Input Class Initialized
INFO - 2017-02-21 16:51:44 --> Language Class Initialized
INFO - 2017-02-21 16:51:44 --> Loader Class Initialized
INFO - 2017-02-21 16:51:44 --> Helper loaded: url_helper
INFO - 2017-02-21 16:51:44 --> Helper loaded: language_helper
INFO - 2017-02-21 16:51:44 --> Helper loaded: html_helper
INFO - 2017-02-21 16:51:44 --> Helper loaded: form_helper
INFO - 2017-02-21 16:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:51:44 --> Controller Class Initialized
INFO - 2017-02-21 16:51:44 --> Database Driver Class Initialized
INFO - 2017-02-21 16:51:44 --> Model Class Initialized
INFO - 2017-02-21 16:51:44 --> Email Class Initialized
INFO - 2017-02-21 16:51:44 --> Form Validation Class Initialized
INFO - 2017-02-21 16:51:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:51:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 16:51:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 16:51:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 16:51:44 --> Final output sent to browser
DEBUG - 2017-02-21 16:51:44 --> Total execution time: 0.2045
INFO - 2017-02-21 16:53:31 --> Config Class Initialized
INFO - 2017-02-21 16:53:31 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:53:31 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:53:31 --> Utf8 Class Initialized
INFO - 2017-02-21 16:53:31 --> URI Class Initialized
INFO - 2017-02-21 16:53:31 --> Router Class Initialized
INFO - 2017-02-21 16:53:31 --> Output Class Initialized
INFO - 2017-02-21 16:53:31 --> Security Class Initialized
DEBUG - 2017-02-21 16:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:53:31 --> Input Class Initialized
INFO - 2017-02-21 16:53:31 --> Language Class Initialized
INFO - 2017-02-21 16:53:31 --> Loader Class Initialized
INFO - 2017-02-21 16:53:31 --> Helper loaded: url_helper
INFO - 2017-02-21 16:53:31 --> Helper loaded: language_helper
INFO - 2017-02-21 16:53:31 --> Helper loaded: html_helper
INFO - 2017-02-21 16:53:31 --> Helper loaded: form_helper
INFO - 2017-02-21 16:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:53:31 --> Controller Class Initialized
INFO - 2017-02-21 16:53:31 --> Database Driver Class Initialized
INFO - 2017-02-21 16:53:31 --> Model Class Initialized
INFO - 2017-02-21 16:53:31 --> Email Class Initialized
INFO - 2017-02-21 16:53:31 --> Form Validation Class Initialized
INFO - 2017-02-21 16:53:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:53:31 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-21 16:53:32 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 16:53:32 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 16:53:32 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-21 16:53:32 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 16:53:50 --> Config Class Initialized
INFO - 2017-02-21 16:53:50 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:53:50 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:53:50 --> Utf8 Class Initialized
INFO - 2017-02-21 16:53:50 --> URI Class Initialized
INFO - 2017-02-21 16:53:50 --> Router Class Initialized
INFO - 2017-02-21 16:53:50 --> Output Class Initialized
INFO - 2017-02-21 16:53:50 --> Security Class Initialized
DEBUG - 2017-02-21 16:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:53:50 --> Input Class Initialized
INFO - 2017-02-21 16:53:50 --> Language Class Initialized
INFO - 2017-02-21 16:53:50 --> Loader Class Initialized
INFO - 2017-02-21 16:53:50 --> Helper loaded: url_helper
INFO - 2017-02-21 16:53:50 --> Helper loaded: language_helper
INFO - 2017-02-21 16:53:50 --> Helper loaded: html_helper
INFO - 2017-02-21 16:53:50 --> Helper loaded: form_helper
INFO - 2017-02-21 16:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:53:50 --> Controller Class Initialized
INFO - 2017-02-21 16:53:50 --> Database Driver Class Initialized
INFO - 2017-02-21 16:53:50 --> Model Class Initialized
INFO - 2017-02-21 16:53:50 --> Email Class Initialized
INFO - 2017-02-21 16:53:50 --> Form Validation Class Initialized
INFO - 2017-02-21 16:53:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:53:50 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 16:53:51 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 16:53:54 --> Final output sent to browser
DEBUG - 2017-02-21 16:53:54 --> Total execution time: 3.7050
INFO - 2017-02-21 16:54:17 --> Config Class Initialized
INFO - 2017-02-21 16:54:17 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:54:17 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:54:17 --> Utf8 Class Initialized
INFO - 2017-02-21 16:54:17 --> URI Class Initialized
INFO - 2017-02-21 16:54:17 --> Router Class Initialized
INFO - 2017-02-21 16:54:17 --> Output Class Initialized
INFO - 2017-02-21 16:54:17 --> Security Class Initialized
DEBUG - 2017-02-21 16:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:54:17 --> Input Class Initialized
INFO - 2017-02-21 16:54:17 --> Language Class Initialized
INFO - 2017-02-21 16:54:17 --> Loader Class Initialized
INFO - 2017-02-21 16:54:17 --> Helper loaded: url_helper
INFO - 2017-02-21 16:54:17 --> Helper loaded: language_helper
INFO - 2017-02-21 16:54:17 --> Helper loaded: html_helper
INFO - 2017-02-21 16:54:17 --> Helper loaded: form_helper
INFO - 2017-02-21 16:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:54:17 --> Controller Class Initialized
INFO - 2017-02-21 16:54:17 --> Database Driver Class Initialized
INFO - 2017-02-21 16:54:17 --> Model Class Initialized
INFO - 2017-02-21 16:54:17 --> Email Class Initialized
INFO - 2017-02-21 16:54:17 --> Form Validation Class Initialized
INFO - 2017-02-21 16:54:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:54:17 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-21 16:54:17 --> Severity: Notice --> Undefined variable: errors C:\wamp64\www\savsoftquiz\application\controllers\Register.php 55
INFO - 2017-02-21 16:54:17 --> Final output sent to browser
DEBUG - 2017-02-21 16:54:17 --> Total execution time: 0.1284
INFO - 2017-02-21 16:54:47 --> Config Class Initialized
INFO - 2017-02-21 16:54:47 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:54:47 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:54:47 --> Utf8 Class Initialized
INFO - 2017-02-21 16:54:47 --> URI Class Initialized
INFO - 2017-02-21 16:54:47 --> Router Class Initialized
INFO - 2017-02-21 16:54:47 --> Output Class Initialized
INFO - 2017-02-21 16:54:47 --> Security Class Initialized
DEBUG - 2017-02-21 16:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:54:47 --> Input Class Initialized
INFO - 2017-02-21 16:54:47 --> Language Class Initialized
INFO - 2017-02-21 16:54:47 --> Loader Class Initialized
INFO - 2017-02-21 16:54:47 --> Helper loaded: url_helper
INFO - 2017-02-21 16:54:47 --> Helper loaded: language_helper
INFO - 2017-02-21 16:54:47 --> Helper loaded: html_helper
INFO - 2017-02-21 16:54:47 --> Helper loaded: form_helper
INFO - 2017-02-21 16:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:54:47 --> Controller Class Initialized
INFO - 2017-02-21 16:54:47 --> Database Driver Class Initialized
INFO - 2017-02-21 16:54:47 --> Model Class Initialized
INFO - 2017-02-21 16:54:47 --> Email Class Initialized
INFO - 2017-02-21 16:54:47 --> Form Validation Class Initialized
INFO - 2017-02-21 16:54:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:54:47 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 16:54:47 --> Final output sent to browser
DEBUG - 2017-02-21 16:54:47 --> Total execution time: 0.1201
INFO - 2017-02-21 16:55:24 --> Config Class Initialized
INFO - 2017-02-21 16:55:24 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:55:24 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:55:24 --> Utf8 Class Initialized
INFO - 2017-02-21 16:55:24 --> URI Class Initialized
INFO - 2017-02-21 16:55:24 --> Router Class Initialized
INFO - 2017-02-21 16:55:24 --> Output Class Initialized
INFO - 2017-02-21 16:55:24 --> Security Class Initialized
DEBUG - 2017-02-21 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:55:24 --> Input Class Initialized
INFO - 2017-02-21 16:55:24 --> Language Class Initialized
INFO - 2017-02-21 16:55:24 --> Loader Class Initialized
INFO - 2017-02-21 16:55:24 --> Helper loaded: url_helper
INFO - 2017-02-21 16:55:24 --> Helper loaded: language_helper
INFO - 2017-02-21 16:55:24 --> Helper loaded: html_helper
INFO - 2017-02-21 16:55:24 --> Helper loaded: form_helper
INFO - 2017-02-21 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:55:24 --> Controller Class Initialized
INFO - 2017-02-21 16:55:24 --> Database Driver Class Initialized
INFO - 2017-02-21 16:55:24 --> Model Class Initialized
INFO - 2017-02-21 16:55:24 --> Email Class Initialized
INFO - 2017-02-21 16:55:24 --> Form Validation Class Initialized
INFO - 2017-02-21 16:55:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:55:24 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 16:55:24 --> Final output sent to browser
DEBUG - 2017-02-21 16:55:24 --> Total execution time: 0.1754
INFO - 2017-02-21 16:57:05 --> Config Class Initialized
INFO - 2017-02-21 16:57:05 --> Hooks Class Initialized
DEBUG - 2017-02-21 16:57:05 --> UTF-8 Support Enabled
INFO - 2017-02-21 16:57:05 --> Utf8 Class Initialized
INFO - 2017-02-21 16:57:05 --> URI Class Initialized
INFO - 2017-02-21 16:57:05 --> Router Class Initialized
INFO - 2017-02-21 16:57:05 --> Output Class Initialized
INFO - 2017-02-21 16:57:05 --> Security Class Initialized
DEBUG - 2017-02-21 16:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 16:57:05 --> Input Class Initialized
INFO - 2017-02-21 16:57:05 --> Language Class Initialized
INFO - 2017-02-21 16:57:05 --> Loader Class Initialized
INFO - 2017-02-21 16:57:05 --> Helper loaded: url_helper
INFO - 2017-02-21 16:57:05 --> Helper loaded: language_helper
INFO - 2017-02-21 16:57:05 --> Helper loaded: html_helper
INFO - 2017-02-21 16:57:05 --> Helper loaded: form_helper
INFO - 2017-02-21 16:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 16:57:05 --> Controller Class Initialized
INFO - 2017-02-21 16:57:05 --> Database Driver Class Initialized
INFO - 2017-02-21 16:57:05 --> Model Class Initialized
INFO - 2017-02-21 16:57:05 --> Email Class Initialized
INFO - 2017-02-21 16:57:05 --> Form Validation Class Initialized
INFO - 2017-02-21 16:57:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 16:57:06 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 16:57:06 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 16:57:09 --> Final output sent to browser
DEBUG - 2017-02-21 16:57:09 --> Total execution time: 3.6944
INFO - 2017-02-21 17:00:52 --> Config Class Initialized
INFO - 2017-02-21 17:00:52 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:00:52 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:00:52 --> Utf8 Class Initialized
INFO - 2017-02-21 17:00:52 --> URI Class Initialized
INFO - 2017-02-21 17:00:52 --> Router Class Initialized
INFO - 2017-02-21 17:00:52 --> Output Class Initialized
INFO - 2017-02-21 17:00:52 --> Security Class Initialized
DEBUG - 2017-02-21 17:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:00:52 --> Input Class Initialized
INFO - 2017-02-21 17:00:52 --> Language Class Initialized
INFO - 2017-02-21 17:00:52 --> Loader Class Initialized
INFO - 2017-02-21 17:00:52 --> Helper loaded: url_helper
INFO - 2017-02-21 17:00:52 --> Helper loaded: language_helper
INFO - 2017-02-21 17:00:52 --> Helper loaded: html_helper
INFO - 2017-02-21 17:00:52 --> Helper loaded: form_helper
INFO - 2017-02-21 17:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:00:52 --> Controller Class Initialized
INFO - 2017-02-21 17:00:52 --> Database Driver Class Initialized
INFO - 2017-02-21 17:00:52 --> Model Class Initialized
INFO - 2017-02-21 17:00:52 --> Email Class Initialized
INFO - 2017-02-21 17:00:52 --> Form Validation Class Initialized
INFO - 2017-02-21 17:00:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 17:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 17:00:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 17:00:52 --> Final output sent to browser
DEBUG - 2017-02-21 17:00:52 --> Total execution time: 0.1351
INFO - 2017-02-21 17:02:02 --> Config Class Initialized
INFO - 2017-02-21 17:02:02 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:02:02 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:02:02 --> Utf8 Class Initialized
INFO - 2017-02-21 17:02:02 --> URI Class Initialized
INFO - 2017-02-21 17:02:02 --> Router Class Initialized
INFO - 2017-02-21 17:02:02 --> Output Class Initialized
INFO - 2017-02-21 17:02:02 --> Security Class Initialized
DEBUG - 2017-02-21 17:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:02:02 --> Input Class Initialized
INFO - 2017-02-21 17:02:02 --> Language Class Initialized
INFO - 2017-02-21 17:02:02 --> Loader Class Initialized
INFO - 2017-02-21 17:02:02 --> Helper loaded: url_helper
INFO - 2017-02-21 17:02:02 --> Helper loaded: language_helper
INFO - 2017-02-21 17:02:02 --> Helper loaded: html_helper
INFO - 2017-02-21 17:02:02 --> Helper loaded: form_helper
INFO - 2017-02-21 17:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:02:02 --> Controller Class Initialized
INFO - 2017-02-21 17:02:02 --> Database Driver Class Initialized
INFO - 2017-02-21 17:02:02 --> Model Class Initialized
INFO - 2017-02-21 17:02:02 --> Email Class Initialized
INFO - 2017-02-21 17:02:02 --> Form Validation Class Initialized
INFO - 2017-02-21 17:02:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:02:02 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:02:02 --> Final output sent to browser
DEBUG - 2017-02-21 17:02:02 --> Total execution time: 0.1463
INFO - 2017-02-21 17:02:19 --> Config Class Initialized
INFO - 2017-02-21 17:02:19 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:02:19 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:02:19 --> Utf8 Class Initialized
INFO - 2017-02-21 17:02:19 --> URI Class Initialized
INFO - 2017-02-21 17:02:19 --> Router Class Initialized
INFO - 2017-02-21 17:02:19 --> Output Class Initialized
INFO - 2017-02-21 17:02:19 --> Security Class Initialized
DEBUG - 2017-02-21 17:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:02:19 --> Input Class Initialized
INFO - 2017-02-21 17:02:19 --> Language Class Initialized
INFO - 2017-02-21 17:02:19 --> Loader Class Initialized
INFO - 2017-02-21 17:02:19 --> Helper loaded: url_helper
INFO - 2017-02-21 17:02:19 --> Helper loaded: language_helper
INFO - 2017-02-21 17:02:19 --> Helper loaded: html_helper
INFO - 2017-02-21 17:02:19 --> Helper loaded: form_helper
INFO - 2017-02-21 17:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:02:19 --> Controller Class Initialized
INFO - 2017-02-21 17:02:19 --> Database Driver Class Initialized
INFO - 2017-02-21 17:02:19 --> Model Class Initialized
INFO - 2017-02-21 17:02:19 --> Email Class Initialized
INFO - 2017-02-21 17:02:19 --> Form Validation Class Initialized
INFO - 2017-02-21 17:02:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:02:19 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:02:19 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 17:02:23 --> Final output sent to browser
DEBUG - 2017-02-21 17:02:23 --> Total execution time: 4.4116
INFO - 2017-02-21 17:08:04 --> Config Class Initialized
INFO - 2017-02-21 17:08:04 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:08:04 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:08:04 --> Utf8 Class Initialized
INFO - 2017-02-21 17:08:04 --> URI Class Initialized
INFO - 2017-02-21 17:08:04 --> Router Class Initialized
INFO - 2017-02-21 17:08:04 --> Output Class Initialized
INFO - 2017-02-21 17:08:04 --> Security Class Initialized
DEBUG - 2017-02-21 17:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:08:04 --> Input Class Initialized
INFO - 2017-02-21 17:08:04 --> Language Class Initialized
INFO - 2017-02-21 17:08:04 --> Loader Class Initialized
INFO - 2017-02-21 17:08:04 --> Helper loaded: url_helper
INFO - 2017-02-21 17:08:04 --> Helper loaded: language_helper
INFO - 2017-02-21 17:08:04 --> Helper loaded: html_helper
INFO - 2017-02-21 17:08:04 --> Helper loaded: form_helper
INFO - 2017-02-21 17:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:08:04 --> Controller Class Initialized
INFO - 2017-02-21 17:08:04 --> Database Driver Class Initialized
INFO - 2017-02-21 17:08:04 --> Model Class Initialized
INFO - 2017-02-21 17:08:04 --> Email Class Initialized
INFO - 2017-02-21 17:08:04 --> Form Validation Class Initialized
INFO - 2017-02-21 17:08:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:08:04 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-21 17:08:05 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 17:08:05 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 17:08:05 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-21 17:08:05 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 17:08:21 --> Config Class Initialized
INFO - 2017-02-21 17:08:21 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:08:21 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:08:21 --> Utf8 Class Initialized
INFO - 2017-02-21 17:08:21 --> URI Class Initialized
INFO - 2017-02-21 17:08:21 --> Router Class Initialized
INFO - 2017-02-21 17:08:21 --> Output Class Initialized
INFO - 2017-02-21 17:08:21 --> Security Class Initialized
DEBUG - 2017-02-21 17:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:08:21 --> Input Class Initialized
INFO - 2017-02-21 17:08:21 --> Language Class Initialized
INFO - 2017-02-21 17:08:21 --> Loader Class Initialized
INFO - 2017-02-21 17:08:21 --> Helper loaded: url_helper
INFO - 2017-02-21 17:08:21 --> Helper loaded: language_helper
INFO - 2017-02-21 17:08:21 --> Helper loaded: html_helper
INFO - 2017-02-21 17:08:21 --> Helper loaded: form_helper
INFO - 2017-02-21 17:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:08:21 --> Controller Class Initialized
INFO - 2017-02-21 17:08:21 --> Database Driver Class Initialized
INFO - 2017-02-21 17:08:21 --> Model Class Initialized
INFO - 2017-02-21 17:08:21 --> Email Class Initialized
INFO - 2017-02-21 17:08:21 --> Form Validation Class Initialized
INFO - 2017-02-21 17:08:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:08:21 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:08:21 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 17:08:25 --> Final output sent to browser
DEBUG - 2017-02-21 17:08:25 --> Total execution time: 3.7603
INFO - 2017-02-21 17:11:51 --> Config Class Initialized
INFO - 2017-02-21 17:11:51 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:11:51 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:11:51 --> Utf8 Class Initialized
INFO - 2017-02-21 17:11:51 --> URI Class Initialized
INFO - 2017-02-21 17:11:51 --> Router Class Initialized
INFO - 2017-02-21 17:11:51 --> Output Class Initialized
INFO - 2017-02-21 17:11:51 --> Security Class Initialized
DEBUG - 2017-02-21 17:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:11:51 --> Input Class Initialized
INFO - 2017-02-21 17:11:51 --> Language Class Initialized
INFO - 2017-02-21 17:11:51 --> Loader Class Initialized
INFO - 2017-02-21 17:11:51 --> Helper loaded: url_helper
INFO - 2017-02-21 17:11:51 --> Helper loaded: language_helper
INFO - 2017-02-21 17:11:51 --> Helper loaded: html_helper
INFO - 2017-02-21 17:11:51 --> Helper loaded: form_helper
INFO - 2017-02-21 17:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:11:51 --> Controller Class Initialized
INFO - 2017-02-21 17:11:51 --> Database Driver Class Initialized
INFO - 2017-02-21 17:11:51 --> Model Class Initialized
INFO - 2017-02-21 17:11:51 --> Email Class Initialized
INFO - 2017-02-21 17:11:51 --> Form Validation Class Initialized
INFO - 2017-02-21 17:11:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:11:51 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:11:51 --> Final output sent to browser
DEBUG - 2017-02-21 17:11:51 --> Total execution time: 0.1588
INFO - 2017-02-21 17:12:19 --> Config Class Initialized
INFO - 2017-02-21 17:12:19 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:12:19 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:12:19 --> Utf8 Class Initialized
INFO - 2017-02-21 17:12:19 --> URI Class Initialized
INFO - 2017-02-21 17:12:19 --> Router Class Initialized
INFO - 2017-02-21 17:12:19 --> Output Class Initialized
INFO - 2017-02-21 17:12:19 --> Security Class Initialized
DEBUG - 2017-02-21 17:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:12:19 --> Input Class Initialized
INFO - 2017-02-21 17:12:19 --> Language Class Initialized
INFO - 2017-02-21 17:12:19 --> Loader Class Initialized
INFO - 2017-02-21 17:12:19 --> Helper loaded: url_helper
INFO - 2017-02-21 17:12:19 --> Helper loaded: language_helper
INFO - 2017-02-21 17:12:19 --> Helper loaded: html_helper
INFO - 2017-02-21 17:12:19 --> Helper loaded: form_helper
INFO - 2017-02-21 17:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:12:19 --> Controller Class Initialized
INFO - 2017-02-21 17:12:19 --> Database Driver Class Initialized
INFO - 2017-02-21 17:12:19 --> Model Class Initialized
INFO - 2017-02-21 17:12:19 --> Email Class Initialized
INFO - 2017-02-21 17:12:19 --> Form Validation Class Initialized
INFO - 2017-02-21 17:12:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:12:19 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:12:19 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 17:12:22 --> Final output sent to browser
DEBUG - 2017-02-21 17:12:22 --> Total execution time: 3.7341
INFO - 2017-02-21 17:17:48 --> Config Class Initialized
INFO - 2017-02-21 17:17:48 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:17:48 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:17:48 --> Utf8 Class Initialized
INFO - 2017-02-21 17:17:48 --> URI Class Initialized
INFO - 2017-02-21 17:17:48 --> Router Class Initialized
INFO - 2017-02-21 17:17:48 --> Output Class Initialized
INFO - 2017-02-21 17:17:48 --> Security Class Initialized
DEBUG - 2017-02-21 17:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:17:48 --> Input Class Initialized
INFO - 2017-02-21 17:17:48 --> Language Class Initialized
INFO - 2017-02-21 17:17:48 --> Loader Class Initialized
INFO - 2017-02-21 17:17:48 --> Helper loaded: url_helper
INFO - 2017-02-21 17:17:48 --> Helper loaded: language_helper
INFO - 2017-02-21 17:17:48 --> Helper loaded: html_helper
INFO - 2017-02-21 17:17:48 --> Helper loaded: form_helper
INFO - 2017-02-21 17:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:17:48 --> Controller Class Initialized
INFO - 2017-02-21 17:17:48 --> Database Driver Class Initialized
INFO - 2017-02-21 17:17:48 --> Model Class Initialized
INFO - 2017-02-21 17:17:48 --> Email Class Initialized
INFO - 2017-02-21 17:17:48 --> Form Validation Class Initialized
INFO - 2017-02-21 17:17:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:17:48 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:17:49 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 17:17:53 --> Final output sent to browser
DEBUG - 2017-02-21 17:17:53 --> Total execution time: 4.9519
INFO - 2017-02-21 17:18:39 --> Config Class Initialized
INFO - 2017-02-21 17:18:39 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:18:39 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:18:39 --> Utf8 Class Initialized
INFO - 2017-02-21 17:18:39 --> URI Class Initialized
INFO - 2017-02-21 17:18:39 --> Router Class Initialized
INFO - 2017-02-21 17:18:39 --> Output Class Initialized
INFO - 2017-02-21 17:18:39 --> Security Class Initialized
DEBUG - 2017-02-21 17:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:18:39 --> Input Class Initialized
INFO - 2017-02-21 17:18:39 --> Language Class Initialized
INFO - 2017-02-21 17:18:39 --> Loader Class Initialized
INFO - 2017-02-21 17:18:39 --> Helper loaded: url_helper
INFO - 2017-02-21 17:18:39 --> Helper loaded: language_helper
INFO - 2017-02-21 17:18:39 --> Helper loaded: html_helper
INFO - 2017-02-21 17:18:39 --> Helper loaded: form_helper
INFO - 2017-02-21 17:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:18:39 --> Controller Class Initialized
INFO - 2017-02-21 17:18:39 --> Database Driver Class Initialized
INFO - 2017-02-21 17:18:39 --> Model Class Initialized
INFO - 2017-02-21 17:18:39 --> Email Class Initialized
INFO - 2017-02-21 17:18:39 --> Form Validation Class Initialized
INFO - 2017-02-21 17:18:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:18:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 17:18:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 17:18:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 17:18:39 --> Final output sent to browser
DEBUG - 2017-02-21 17:18:39 --> Total execution time: 0.1368
INFO - 2017-02-21 17:21:17 --> Config Class Initialized
INFO - 2017-02-21 17:21:17 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:21:17 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:21:17 --> Utf8 Class Initialized
INFO - 2017-02-21 17:21:17 --> URI Class Initialized
INFO - 2017-02-21 17:21:17 --> Router Class Initialized
INFO - 2017-02-21 17:21:17 --> Output Class Initialized
INFO - 2017-02-21 17:21:17 --> Security Class Initialized
DEBUG - 2017-02-21 17:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:21:17 --> Input Class Initialized
INFO - 2017-02-21 17:21:17 --> Language Class Initialized
INFO - 2017-02-21 17:21:17 --> Loader Class Initialized
INFO - 2017-02-21 17:21:17 --> Helper loaded: url_helper
INFO - 2017-02-21 17:21:17 --> Helper loaded: language_helper
INFO - 2017-02-21 17:21:17 --> Helper loaded: html_helper
INFO - 2017-02-21 17:21:17 --> Helper loaded: form_helper
INFO - 2017-02-21 17:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:21:17 --> Controller Class Initialized
INFO - 2017-02-21 17:21:17 --> Database Driver Class Initialized
INFO - 2017-02-21 17:21:17 --> Model Class Initialized
INFO - 2017-02-21 17:21:17 --> Email Class Initialized
INFO - 2017-02-21 17:21:17 --> Form Validation Class Initialized
INFO - 2017-02-21 17:21:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:21:17 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:21:17 --> Final output sent to browser
DEBUG - 2017-02-21 17:21:17 --> Total execution time: 0.1499
INFO - 2017-02-21 17:21:46 --> Config Class Initialized
INFO - 2017-02-21 17:21:46 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:21:46 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:21:46 --> Utf8 Class Initialized
INFO - 2017-02-21 17:21:46 --> URI Class Initialized
INFO - 2017-02-21 17:21:46 --> Router Class Initialized
INFO - 2017-02-21 17:21:46 --> Output Class Initialized
INFO - 2017-02-21 17:21:46 --> Security Class Initialized
DEBUG - 2017-02-21 17:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:21:46 --> Input Class Initialized
INFO - 2017-02-21 17:21:46 --> Language Class Initialized
INFO - 2017-02-21 17:21:46 --> Loader Class Initialized
INFO - 2017-02-21 17:21:46 --> Helper loaded: url_helper
INFO - 2017-02-21 17:21:46 --> Helper loaded: language_helper
INFO - 2017-02-21 17:21:46 --> Helper loaded: html_helper
INFO - 2017-02-21 17:21:46 --> Helper loaded: form_helper
INFO - 2017-02-21 17:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:21:46 --> Controller Class Initialized
INFO - 2017-02-21 17:21:46 --> Database Driver Class Initialized
INFO - 2017-02-21 17:21:46 --> Model Class Initialized
INFO - 2017-02-21 17:21:46 --> Email Class Initialized
INFO - 2017-02-21 17:21:46 --> Form Validation Class Initialized
INFO - 2017-02-21 17:21:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:21:46 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:21:46 --> Final output sent to browser
DEBUG - 2017-02-21 17:21:46 --> Total execution time: 0.1752
INFO - 2017-02-21 17:21:55 --> Config Class Initialized
INFO - 2017-02-21 17:21:55 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:21:55 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:21:55 --> Utf8 Class Initialized
INFO - 2017-02-21 17:21:55 --> URI Class Initialized
INFO - 2017-02-21 17:21:55 --> Router Class Initialized
INFO - 2017-02-21 17:21:55 --> Output Class Initialized
INFO - 2017-02-21 17:21:55 --> Security Class Initialized
DEBUG - 2017-02-21 17:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:21:55 --> Input Class Initialized
INFO - 2017-02-21 17:21:55 --> Language Class Initialized
INFO - 2017-02-21 17:21:55 --> Loader Class Initialized
INFO - 2017-02-21 17:21:55 --> Helper loaded: url_helper
INFO - 2017-02-21 17:21:55 --> Helper loaded: language_helper
INFO - 2017-02-21 17:21:55 --> Helper loaded: html_helper
INFO - 2017-02-21 17:21:55 --> Helper loaded: form_helper
INFO - 2017-02-21 17:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:21:55 --> Controller Class Initialized
INFO - 2017-02-21 17:21:55 --> Database Driver Class Initialized
INFO - 2017-02-21 17:21:55 --> Model Class Initialized
INFO - 2017-02-21 17:21:55 --> Email Class Initialized
INFO - 2017-02-21 17:21:55 --> Form Validation Class Initialized
INFO - 2017-02-21 17:21:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:21:55 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-21 17:21:55 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 17:21:55 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 17:21:55 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-21 17:21:55 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 17:22:08 --> Config Class Initialized
INFO - 2017-02-21 17:22:08 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:22:08 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:22:08 --> Utf8 Class Initialized
INFO - 2017-02-21 17:22:08 --> URI Class Initialized
INFO - 2017-02-21 17:22:08 --> Router Class Initialized
INFO - 2017-02-21 17:22:08 --> Output Class Initialized
INFO - 2017-02-21 17:22:08 --> Security Class Initialized
DEBUG - 2017-02-21 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:22:08 --> Input Class Initialized
INFO - 2017-02-21 17:22:08 --> Language Class Initialized
INFO - 2017-02-21 17:22:08 --> Loader Class Initialized
INFO - 2017-02-21 17:22:08 --> Helper loaded: url_helper
INFO - 2017-02-21 17:22:08 --> Helper loaded: language_helper
INFO - 2017-02-21 17:22:08 --> Helper loaded: html_helper
INFO - 2017-02-21 17:22:08 --> Helper loaded: form_helper
INFO - 2017-02-21 17:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:22:08 --> Controller Class Initialized
INFO - 2017-02-21 17:22:08 --> Database Driver Class Initialized
INFO - 2017-02-21 17:22:08 --> Model Class Initialized
INFO - 2017-02-21 17:22:08 --> Email Class Initialized
INFO - 2017-02-21 17:22:08 --> Form Validation Class Initialized
INFO - 2017-02-21 17:22:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:22:08 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 17:22:09 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 17:22:13 --> Final output sent to browser
DEBUG - 2017-02-21 17:22:13 --> Total execution time: 5.5328
INFO - 2017-02-21 17:22:16 --> Config Class Initialized
INFO - 2017-02-21 17:22:16 --> Hooks Class Initialized
DEBUG - 2017-02-21 17:22:16 --> UTF-8 Support Enabled
INFO - 2017-02-21 17:22:16 --> Utf8 Class Initialized
INFO - 2017-02-21 17:22:16 --> URI Class Initialized
INFO - 2017-02-21 17:22:16 --> Router Class Initialized
INFO - 2017-02-21 17:22:16 --> Output Class Initialized
INFO - 2017-02-21 17:22:16 --> Security Class Initialized
DEBUG - 2017-02-21 17:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 17:22:16 --> Input Class Initialized
INFO - 2017-02-21 17:22:16 --> Language Class Initialized
INFO - 2017-02-21 17:22:16 --> Loader Class Initialized
INFO - 2017-02-21 17:22:16 --> Helper loaded: url_helper
INFO - 2017-02-21 17:22:16 --> Helper loaded: language_helper
INFO - 2017-02-21 17:22:16 --> Helper loaded: html_helper
INFO - 2017-02-21 17:22:16 --> Helper loaded: form_helper
INFO - 2017-02-21 17:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 17:22:16 --> Controller Class Initialized
INFO - 2017-02-21 17:22:16 --> Database Driver Class Initialized
INFO - 2017-02-21 17:22:16 --> Model Class Initialized
INFO - 2017-02-21 17:22:16 --> Email Class Initialized
INFO - 2017-02-21 17:22:16 --> Form Validation Class Initialized
INFO - 2017-02-21 17:22:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 17:22:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 17:22:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-21 17:22:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 17:22:16 --> Final output sent to browser
DEBUG - 2017-02-21 17:22:16 --> Total execution time: 0.1388
INFO - 2017-02-21 18:42:17 --> Config Class Initialized
INFO - 2017-02-21 18:42:17 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:42:17 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:42:17 --> Utf8 Class Initialized
INFO - 2017-02-21 18:42:17 --> URI Class Initialized
DEBUG - 2017-02-21 18:42:17 --> No URI present. Default controller set.
INFO - 2017-02-21 18:42:17 --> Router Class Initialized
INFO - 2017-02-21 18:42:17 --> Output Class Initialized
INFO - 2017-02-21 18:42:17 --> Security Class Initialized
DEBUG - 2017-02-21 18:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:42:17 --> Input Class Initialized
INFO - 2017-02-21 18:42:17 --> Language Class Initialized
INFO - 2017-02-21 18:42:17 --> Loader Class Initialized
INFO - 2017-02-21 18:42:17 --> Helper loaded: url_helper
INFO - 2017-02-21 18:42:17 --> Helper loaded: language_helper
INFO - 2017-02-21 18:42:17 --> Helper loaded: html_helper
INFO - 2017-02-21 18:42:17 --> Helper loaded: form_helper
INFO - 2017-02-21 18:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:42:17 --> Controller Class Initialized
INFO - 2017-02-21 18:42:17 --> Database Driver Class Initialized
INFO - 2017-02-21 18:42:17 --> Model Class Initialized
INFO - 2017-02-21 18:42:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:42:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:42:17 --> Final output sent to browser
DEBUG - 2017-02-21 18:42:17 --> Total execution time: 0.2032
INFO - 2017-02-21 18:50:27 --> Config Class Initialized
INFO - 2017-02-21 18:50:27 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:50:27 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:50:27 --> Utf8 Class Initialized
INFO - 2017-02-21 18:50:27 --> URI Class Initialized
INFO - 2017-02-21 18:50:27 --> Router Class Initialized
INFO - 2017-02-21 18:50:27 --> Output Class Initialized
INFO - 2017-02-21 18:50:27 --> Security Class Initialized
DEBUG - 2017-02-21 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:50:27 --> Input Class Initialized
INFO - 2017-02-21 18:50:27 --> Language Class Initialized
INFO - 2017-02-21 18:50:27 --> Loader Class Initialized
INFO - 2017-02-21 18:50:27 --> Helper loaded: url_helper
INFO - 2017-02-21 18:50:27 --> Helper loaded: language_helper
INFO - 2017-02-21 18:50:27 --> Helper loaded: html_helper
INFO - 2017-02-21 18:50:27 --> Helper loaded: form_helper
INFO - 2017-02-21 18:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:50:27 --> Controller Class Initialized
INFO - 2017-02-21 18:50:27 --> Database Driver Class Initialized
INFO - 2017-02-21 18:50:27 --> Model Class Initialized
INFO - 2017-02-21 18:50:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:50:27 --> Config Class Initialized
INFO - 2017-02-21 18:50:27 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:50:27 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:50:27 --> Utf8 Class Initialized
INFO - 2017-02-21 18:50:27 --> URI Class Initialized
INFO - 2017-02-21 18:50:27 --> Router Class Initialized
INFO - 2017-02-21 18:50:27 --> Output Class Initialized
INFO - 2017-02-21 18:50:27 --> Security Class Initialized
DEBUG - 2017-02-21 18:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:50:27 --> Input Class Initialized
INFO - 2017-02-21 18:50:27 --> Language Class Initialized
INFO - 2017-02-21 18:50:27 --> Loader Class Initialized
INFO - 2017-02-21 18:50:27 --> Helper loaded: url_helper
INFO - 2017-02-21 18:50:27 --> Helper loaded: language_helper
INFO - 2017-02-21 18:50:27 --> Helper loaded: html_helper
INFO - 2017-02-21 18:50:27 --> Helper loaded: form_helper
INFO - 2017-02-21 18:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:50:27 --> Controller Class Initialized
INFO - 2017-02-21 18:50:27 --> Database Driver Class Initialized
INFO - 2017-02-21 18:50:27 --> Model Class Initialized
INFO - 2017-02-21 18:50:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:50:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:50:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:50:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:50:27 --> Final output sent to browser
DEBUG - 2017-02-21 18:50:27 --> Total execution time: 0.1120
INFO - 2017-02-21 18:50:32 --> Config Class Initialized
INFO - 2017-02-21 18:50:32 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:50:32 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:50:32 --> Utf8 Class Initialized
INFO - 2017-02-21 18:50:32 --> URI Class Initialized
INFO - 2017-02-21 18:50:32 --> Router Class Initialized
INFO - 2017-02-21 18:50:32 --> Output Class Initialized
INFO - 2017-02-21 18:50:32 --> Security Class Initialized
DEBUG - 2017-02-21 18:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:50:32 --> Input Class Initialized
INFO - 2017-02-21 18:50:32 --> Language Class Initialized
INFO - 2017-02-21 18:50:32 --> Loader Class Initialized
INFO - 2017-02-21 18:50:32 --> Helper loaded: url_helper
INFO - 2017-02-21 18:50:32 --> Helper loaded: language_helper
INFO - 2017-02-21 18:50:32 --> Helper loaded: html_helper
INFO - 2017-02-21 18:50:32 --> Helper loaded: form_helper
INFO - 2017-02-21 18:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:50:32 --> Controller Class Initialized
INFO - 2017-02-21 18:50:32 --> Database Driver Class Initialized
INFO - 2017-02-21 18:50:32 --> Model Class Initialized
INFO - 2017-02-21 18:50:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:50:32 --> Config Class Initialized
INFO - 2017-02-21 18:50:32 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:50:32 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:50:32 --> Utf8 Class Initialized
INFO - 2017-02-21 18:50:32 --> URI Class Initialized
INFO - 2017-02-21 18:50:32 --> Router Class Initialized
INFO - 2017-02-21 18:50:32 --> Output Class Initialized
INFO - 2017-02-21 18:50:32 --> Security Class Initialized
DEBUG - 2017-02-21 18:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:50:32 --> Input Class Initialized
INFO - 2017-02-21 18:50:32 --> Language Class Initialized
INFO - 2017-02-21 18:50:32 --> Loader Class Initialized
INFO - 2017-02-21 18:50:32 --> Helper loaded: url_helper
INFO - 2017-02-21 18:50:32 --> Helper loaded: language_helper
INFO - 2017-02-21 18:50:32 --> Helper loaded: html_helper
INFO - 2017-02-21 18:50:32 --> Helper loaded: form_helper
INFO - 2017-02-21 18:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:50:32 --> Controller Class Initialized
INFO - 2017-02-21 18:50:32 --> Database Driver Class Initialized
INFO - 2017-02-21 18:50:32 --> Model Class Initialized
INFO - 2017-02-21 18:50:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:50:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:50:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:50:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:50:33 --> Final output sent to browser
DEBUG - 2017-02-21 18:50:33 --> Total execution time: 0.1052
INFO - 2017-02-21 18:51:45 --> Config Class Initialized
INFO - 2017-02-21 18:51:45 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:51:45 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:51:45 --> Utf8 Class Initialized
INFO - 2017-02-21 18:51:45 --> URI Class Initialized
INFO - 2017-02-21 18:51:45 --> Router Class Initialized
INFO - 2017-02-21 18:51:45 --> Output Class Initialized
INFO - 2017-02-21 18:51:45 --> Security Class Initialized
DEBUG - 2017-02-21 18:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:51:45 --> Input Class Initialized
INFO - 2017-02-21 18:51:45 --> Language Class Initialized
INFO - 2017-02-21 18:51:45 --> Loader Class Initialized
INFO - 2017-02-21 18:51:45 --> Helper loaded: url_helper
INFO - 2017-02-21 18:51:45 --> Helper loaded: language_helper
INFO - 2017-02-21 18:51:45 --> Helper loaded: html_helper
INFO - 2017-02-21 18:51:45 --> Helper loaded: form_helper
INFO - 2017-02-21 18:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:51:45 --> Controller Class Initialized
INFO - 2017-02-21 18:51:45 --> Database Driver Class Initialized
INFO - 2017-02-21 18:51:45 --> Model Class Initialized
INFO - 2017-02-21 18:51:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:51:45 --> Config Class Initialized
INFO - 2017-02-21 18:51:45 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:51:45 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:51:45 --> Utf8 Class Initialized
INFO - 2017-02-21 18:51:45 --> URI Class Initialized
INFO - 2017-02-21 18:51:45 --> Router Class Initialized
INFO - 2017-02-21 18:51:45 --> Output Class Initialized
INFO - 2017-02-21 18:51:45 --> Security Class Initialized
DEBUG - 2017-02-21 18:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:51:45 --> Input Class Initialized
INFO - 2017-02-21 18:51:45 --> Language Class Initialized
INFO - 2017-02-21 18:51:45 --> Loader Class Initialized
INFO - 2017-02-21 18:51:45 --> Helper loaded: url_helper
INFO - 2017-02-21 18:51:45 --> Helper loaded: language_helper
INFO - 2017-02-21 18:51:45 --> Helper loaded: html_helper
INFO - 2017-02-21 18:51:45 --> Helper loaded: form_helper
INFO - 2017-02-21 18:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:51:45 --> Controller Class Initialized
INFO - 2017-02-21 18:51:45 --> Database Driver Class Initialized
INFO - 2017-02-21 18:51:45 --> Model Class Initialized
INFO - 2017-02-21 18:51:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:51:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:51:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:51:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:51:45 --> Final output sent to browser
DEBUG - 2017-02-21 18:51:45 --> Total execution time: 0.1402
INFO - 2017-02-21 18:52:16 --> Config Class Initialized
INFO - 2017-02-21 18:52:16 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:52:17 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:52:17 --> Utf8 Class Initialized
INFO - 2017-02-21 18:52:17 --> URI Class Initialized
INFO - 2017-02-21 18:52:17 --> Router Class Initialized
INFO - 2017-02-21 18:52:17 --> Output Class Initialized
INFO - 2017-02-21 18:52:17 --> Security Class Initialized
DEBUG - 2017-02-21 18:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:52:17 --> Input Class Initialized
INFO - 2017-02-21 18:52:17 --> Language Class Initialized
INFO - 2017-02-21 18:52:17 --> Loader Class Initialized
INFO - 2017-02-21 18:52:17 --> Helper loaded: url_helper
INFO - 2017-02-21 18:52:17 --> Helper loaded: language_helper
INFO - 2017-02-21 18:52:17 --> Helper loaded: html_helper
INFO - 2017-02-21 18:52:17 --> Helper loaded: form_helper
INFO - 2017-02-21 18:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:52:17 --> Controller Class Initialized
INFO - 2017-02-21 18:52:17 --> Database Driver Class Initialized
INFO - 2017-02-21 18:52:17 --> Model Class Initialized
INFO - 2017-02-21 18:52:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:52:17 --> Config Class Initialized
INFO - 2017-02-21 18:52:17 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:52:17 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:52:17 --> Utf8 Class Initialized
INFO - 2017-02-21 18:52:17 --> URI Class Initialized
INFO - 2017-02-21 18:52:17 --> Router Class Initialized
INFO - 2017-02-21 18:52:17 --> Output Class Initialized
INFO - 2017-02-21 18:52:17 --> Security Class Initialized
DEBUG - 2017-02-21 18:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:52:17 --> Input Class Initialized
INFO - 2017-02-21 18:52:17 --> Language Class Initialized
INFO - 2017-02-21 18:52:17 --> Loader Class Initialized
INFO - 2017-02-21 18:52:17 --> Helper loaded: url_helper
INFO - 2017-02-21 18:52:17 --> Helper loaded: language_helper
INFO - 2017-02-21 18:52:17 --> Helper loaded: html_helper
INFO - 2017-02-21 18:52:17 --> Helper loaded: form_helper
INFO - 2017-02-21 18:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:52:17 --> Controller Class Initialized
INFO - 2017-02-21 18:52:17 --> Database Driver Class Initialized
INFO - 2017-02-21 18:52:17 --> Model Class Initialized
INFO - 2017-02-21 18:52:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:52:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:52:17 --> Final output sent to browser
DEBUG - 2017-02-21 18:52:17 --> Total execution time: 0.1599
INFO - 2017-02-21 18:54:54 --> Config Class Initialized
INFO - 2017-02-21 18:54:54 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:54:54 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:54:54 --> Utf8 Class Initialized
INFO - 2017-02-21 18:54:54 --> URI Class Initialized
INFO - 2017-02-21 18:54:54 --> Router Class Initialized
INFO - 2017-02-21 18:54:54 --> Output Class Initialized
INFO - 2017-02-21 18:54:54 --> Security Class Initialized
DEBUG - 2017-02-21 18:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:54:54 --> Input Class Initialized
INFO - 2017-02-21 18:54:54 --> Language Class Initialized
INFO - 2017-02-21 18:54:54 --> Loader Class Initialized
INFO - 2017-02-21 18:54:54 --> Helper loaded: url_helper
INFO - 2017-02-21 18:54:54 --> Helper loaded: language_helper
INFO - 2017-02-21 18:54:54 --> Helper loaded: html_helper
INFO - 2017-02-21 18:54:54 --> Helper loaded: form_helper
INFO - 2017-02-21 18:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:54:54 --> Controller Class Initialized
INFO - 2017-02-21 18:54:55 --> Database Driver Class Initialized
INFO - 2017-02-21 18:54:55 --> Model Class Initialized
INFO - 2017-02-21 18:54:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:54:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:54:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:54:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:54:55 --> Final output sent to browser
DEBUG - 2017-02-21 18:54:55 --> Total execution time: 0.1269
INFO - 2017-02-21 18:54:58 --> Config Class Initialized
INFO - 2017-02-21 18:54:58 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:54:58 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:54:58 --> Utf8 Class Initialized
INFO - 2017-02-21 18:54:58 --> URI Class Initialized
INFO - 2017-02-21 18:54:58 --> Router Class Initialized
INFO - 2017-02-21 18:54:58 --> Output Class Initialized
INFO - 2017-02-21 18:54:58 --> Security Class Initialized
DEBUG - 2017-02-21 18:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:54:58 --> Input Class Initialized
INFO - 2017-02-21 18:54:58 --> Language Class Initialized
INFO - 2017-02-21 18:54:58 --> Loader Class Initialized
INFO - 2017-02-21 18:54:58 --> Helper loaded: url_helper
INFO - 2017-02-21 18:54:58 --> Helper loaded: language_helper
INFO - 2017-02-21 18:54:58 --> Helper loaded: html_helper
INFO - 2017-02-21 18:54:58 --> Helper loaded: form_helper
INFO - 2017-02-21 18:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:54:58 --> Controller Class Initialized
INFO - 2017-02-21 18:54:58 --> Database Driver Class Initialized
INFO - 2017-02-21 18:54:58 --> Model Class Initialized
INFO - 2017-02-21 18:54:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:54:58 --> Config Class Initialized
INFO - 2017-02-21 18:54:58 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:54:58 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:54:58 --> Utf8 Class Initialized
INFO - 2017-02-21 18:54:58 --> URI Class Initialized
INFO - 2017-02-21 18:54:58 --> Router Class Initialized
INFO - 2017-02-21 18:54:58 --> Output Class Initialized
INFO - 2017-02-21 18:54:58 --> Security Class Initialized
DEBUG - 2017-02-21 18:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:54:58 --> Input Class Initialized
INFO - 2017-02-21 18:54:58 --> Language Class Initialized
INFO - 2017-02-21 18:54:58 --> Loader Class Initialized
INFO - 2017-02-21 18:54:58 --> Helper loaded: url_helper
INFO - 2017-02-21 18:54:58 --> Helper loaded: language_helper
INFO - 2017-02-21 18:54:58 --> Helper loaded: html_helper
INFO - 2017-02-21 18:54:58 --> Helper loaded: form_helper
INFO - 2017-02-21 18:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:54:58 --> Controller Class Initialized
INFO - 2017-02-21 18:54:58 --> Database Driver Class Initialized
INFO - 2017-02-21 18:54:58 --> Model Class Initialized
INFO - 2017-02-21 18:54:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:54:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:54:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:54:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:54:58 --> Final output sent to browser
DEBUG - 2017-02-21 18:54:58 --> Total execution time: 0.1234
INFO - 2017-02-21 18:55:06 --> Config Class Initialized
INFO - 2017-02-21 18:55:06 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:55:06 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:55:06 --> Utf8 Class Initialized
INFO - 2017-02-21 18:55:06 --> URI Class Initialized
INFO - 2017-02-21 18:55:06 --> Router Class Initialized
INFO - 2017-02-21 18:55:06 --> Output Class Initialized
INFO - 2017-02-21 18:55:06 --> Security Class Initialized
DEBUG - 2017-02-21 18:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:55:06 --> Input Class Initialized
INFO - 2017-02-21 18:55:06 --> Language Class Initialized
INFO - 2017-02-21 18:55:06 --> Loader Class Initialized
INFO - 2017-02-21 18:55:06 --> Helper loaded: url_helper
INFO - 2017-02-21 18:55:06 --> Helper loaded: language_helper
INFO - 2017-02-21 18:55:06 --> Helper loaded: html_helper
INFO - 2017-02-21 18:55:06 --> Helper loaded: form_helper
INFO - 2017-02-21 18:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:55:06 --> Controller Class Initialized
INFO - 2017-02-21 18:55:06 --> Database Driver Class Initialized
INFO - 2017-02-21 18:55:06 --> Model Class Initialized
INFO - 2017-02-21 18:55:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:55:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:55:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:55:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:55:06 --> Final output sent to browser
DEBUG - 2017-02-21 18:55:06 --> Total execution time: 0.1750
INFO - 2017-02-21 18:55:25 --> Config Class Initialized
INFO - 2017-02-21 18:55:25 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:55:25 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:55:25 --> Utf8 Class Initialized
INFO - 2017-02-21 18:55:25 --> URI Class Initialized
INFO - 2017-02-21 18:55:25 --> Router Class Initialized
INFO - 2017-02-21 18:55:25 --> Output Class Initialized
INFO - 2017-02-21 18:55:25 --> Security Class Initialized
DEBUG - 2017-02-21 18:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:55:25 --> Input Class Initialized
INFO - 2017-02-21 18:55:25 --> Language Class Initialized
INFO - 2017-02-21 18:55:25 --> Loader Class Initialized
INFO - 2017-02-21 18:55:25 --> Helper loaded: url_helper
INFO - 2017-02-21 18:55:25 --> Helper loaded: language_helper
INFO - 2017-02-21 18:55:25 --> Helper loaded: html_helper
INFO - 2017-02-21 18:55:25 --> Helper loaded: form_helper
INFO - 2017-02-21 18:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:55:25 --> Controller Class Initialized
INFO - 2017-02-21 18:55:25 --> Database Driver Class Initialized
INFO - 2017-02-21 18:55:25 --> Model Class Initialized
INFO - 2017-02-21 18:55:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:55:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:55:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:55:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:55:25 --> Final output sent to browser
DEBUG - 2017-02-21 18:55:25 --> Total execution time: 0.2321
INFO - 2017-02-21 18:55:40 --> Config Class Initialized
INFO - 2017-02-21 18:55:40 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:55:40 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:55:40 --> Utf8 Class Initialized
INFO - 2017-02-21 18:55:40 --> URI Class Initialized
INFO - 2017-02-21 18:55:40 --> Router Class Initialized
INFO - 2017-02-21 18:55:40 --> Output Class Initialized
INFO - 2017-02-21 18:55:40 --> Security Class Initialized
DEBUG - 2017-02-21 18:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:55:40 --> Input Class Initialized
INFO - 2017-02-21 18:55:40 --> Language Class Initialized
INFO - 2017-02-21 18:55:40 --> Loader Class Initialized
INFO - 2017-02-21 18:55:40 --> Helper loaded: url_helper
INFO - 2017-02-21 18:55:40 --> Helper loaded: language_helper
INFO - 2017-02-21 18:55:40 --> Helper loaded: html_helper
INFO - 2017-02-21 18:55:40 --> Helper loaded: form_helper
INFO - 2017-02-21 18:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:55:40 --> Controller Class Initialized
INFO - 2017-02-21 18:55:40 --> Database Driver Class Initialized
INFO - 2017-02-21 18:55:40 --> Model Class Initialized
INFO - 2017-02-21 18:55:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:55:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:55:40 --> Final output sent to browser
DEBUG - 2017-02-21 18:55:40 --> Total execution time: 0.1216
INFO - 2017-02-21 18:55:43 --> Config Class Initialized
INFO - 2017-02-21 18:55:43 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:55:43 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:55:43 --> Utf8 Class Initialized
INFO - 2017-02-21 18:55:43 --> URI Class Initialized
INFO - 2017-02-21 18:55:43 --> Router Class Initialized
INFO - 2017-02-21 18:55:43 --> Output Class Initialized
INFO - 2017-02-21 18:55:43 --> Security Class Initialized
DEBUG - 2017-02-21 18:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:55:43 --> Input Class Initialized
INFO - 2017-02-21 18:55:43 --> Language Class Initialized
INFO - 2017-02-21 18:55:43 --> Loader Class Initialized
INFO - 2017-02-21 18:55:43 --> Helper loaded: url_helper
INFO - 2017-02-21 18:55:43 --> Helper loaded: language_helper
INFO - 2017-02-21 18:55:43 --> Helper loaded: html_helper
INFO - 2017-02-21 18:55:43 --> Helper loaded: form_helper
INFO - 2017-02-21 18:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:55:43 --> Controller Class Initialized
INFO - 2017-02-21 18:55:43 --> Database Driver Class Initialized
INFO - 2017-02-21 18:55:43 --> Model Class Initialized
INFO - 2017-02-21 18:55:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:55:43 --> Config Class Initialized
INFO - 2017-02-21 18:55:43 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:55:43 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:55:43 --> Utf8 Class Initialized
INFO - 2017-02-21 18:55:43 --> URI Class Initialized
INFO - 2017-02-21 18:55:43 --> Router Class Initialized
INFO - 2017-02-21 18:55:43 --> Output Class Initialized
INFO - 2017-02-21 18:55:43 --> Security Class Initialized
DEBUG - 2017-02-21 18:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:55:43 --> Input Class Initialized
INFO - 2017-02-21 18:55:43 --> Language Class Initialized
INFO - 2017-02-21 18:55:43 --> Loader Class Initialized
INFO - 2017-02-21 18:55:43 --> Helper loaded: url_helper
INFO - 2017-02-21 18:55:43 --> Helper loaded: language_helper
INFO - 2017-02-21 18:55:43 --> Helper loaded: html_helper
INFO - 2017-02-21 18:55:44 --> Helper loaded: form_helper
INFO - 2017-02-21 18:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:55:44 --> Controller Class Initialized
INFO - 2017-02-21 18:55:44 --> Database Driver Class Initialized
INFO - 2017-02-21 18:55:44 --> Model Class Initialized
INFO - 2017-02-21 18:55:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:55:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 18:55:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 18:55:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 18:55:44 --> Final output sent to browser
DEBUG - 2017-02-21 18:55:44 --> Total execution time: 0.1776
INFO - 2017-02-21 18:56:15 --> Config Class Initialized
INFO - 2017-02-21 18:56:15 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:56:15 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:56:15 --> Utf8 Class Initialized
INFO - 2017-02-21 18:56:15 --> URI Class Initialized
INFO - 2017-02-21 18:56:15 --> Router Class Initialized
INFO - 2017-02-21 18:56:15 --> Output Class Initialized
INFO - 2017-02-21 18:56:15 --> Security Class Initialized
DEBUG - 2017-02-21 18:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:56:15 --> Input Class Initialized
INFO - 2017-02-21 18:56:15 --> Language Class Initialized
INFO - 2017-02-21 18:56:15 --> Loader Class Initialized
INFO - 2017-02-21 18:56:15 --> Helper loaded: url_helper
INFO - 2017-02-21 18:56:15 --> Helper loaded: language_helper
INFO - 2017-02-21 18:56:15 --> Helper loaded: html_helper
INFO - 2017-02-21 18:56:15 --> Helper loaded: form_helper
INFO - 2017-02-21 18:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:56:15 --> Controller Class Initialized
INFO - 2017-02-21 18:56:15 --> Database Driver Class Initialized
INFO - 2017-02-21 18:56:15 --> Model Class Initialized
INFO - 2017-02-21 18:56:15 --> Email Class Initialized
INFO - 2017-02-21 18:56:15 --> Form Validation Class Initialized
INFO - 2017-02-21 18:56:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 18:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 18:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 18:56:15 --> Final output sent to browser
DEBUG - 2017-02-21 18:56:15 --> Total execution time: 0.1615
INFO - 2017-02-21 18:56:15 --> Config Class Initialized
INFO - 2017-02-21 18:56:15 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:56:15 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:56:15 --> Utf8 Class Initialized
INFO - 2017-02-21 18:56:15 --> URI Class Initialized
INFO - 2017-02-21 18:56:15 --> Router Class Initialized
INFO - 2017-02-21 18:56:15 --> Output Class Initialized
INFO - 2017-02-21 18:56:15 --> Security Class Initialized
DEBUG - 2017-02-21 18:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:56:15 --> Input Class Initialized
INFO - 2017-02-21 18:56:15 --> Language Class Initialized
INFO - 2017-02-21 18:56:15 --> Loader Class Initialized
INFO - 2017-02-21 18:56:15 --> Helper loaded: url_helper
INFO - 2017-02-21 18:56:15 --> Helper loaded: language_helper
INFO - 2017-02-21 18:56:15 --> Helper loaded: html_helper
INFO - 2017-02-21 18:56:15 --> Helper loaded: form_helper
INFO - 2017-02-21 18:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:56:15 --> Controller Class Initialized
INFO - 2017-02-21 18:56:15 --> Database Driver Class Initialized
INFO - 2017-02-21 18:56:15 --> Model Class Initialized
INFO - 2017-02-21 18:56:15 --> Email Class Initialized
INFO - 2017-02-21 18:56:15 --> Form Validation Class Initialized
INFO - 2017-02-21 18:56:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 18:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 18:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 18:56:15 --> Final output sent to browser
DEBUG - 2017-02-21 18:56:15 --> Total execution time: 0.1909
INFO - 2017-02-21 18:57:17 --> Config Class Initialized
INFO - 2017-02-21 18:57:17 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:57:17 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:57:17 --> Utf8 Class Initialized
INFO - 2017-02-21 18:57:17 --> URI Class Initialized
INFO - 2017-02-21 18:57:17 --> Router Class Initialized
INFO - 2017-02-21 18:57:17 --> Output Class Initialized
INFO - 2017-02-21 18:57:17 --> Security Class Initialized
DEBUG - 2017-02-21 18:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:57:17 --> Input Class Initialized
INFO - 2017-02-21 18:57:17 --> Language Class Initialized
INFO - 2017-02-21 18:57:17 --> Loader Class Initialized
INFO - 2017-02-21 18:57:17 --> Helper loaded: url_helper
INFO - 2017-02-21 18:57:17 --> Helper loaded: language_helper
INFO - 2017-02-21 18:57:17 --> Helper loaded: html_helper
INFO - 2017-02-21 18:57:17 --> Helper loaded: form_helper
INFO - 2017-02-21 18:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:57:17 --> Controller Class Initialized
INFO - 2017-02-21 18:57:17 --> Database Driver Class Initialized
INFO - 2017-02-21 18:57:17 --> Model Class Initialized
INFO - 2017-02-21 18:57:17 --> Email Class Initialized
INFO - 2017-02-21 18:57:17 --> Form Validation Class Initialized
INFO - 2017-02-21 18:57:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:57:17 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-02-21 18:57:17 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 18:57:17 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-02-21 18:57:17 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-02-21 18:57:17 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 18:57:35 --> Config Class Initialized
INFO - 2017-02-21 18:57:35 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:57:35 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:57:35 --> Utf8 Class Initialized
INFO - 2017-02-21 18:57:35 --> URI Class Initialized
INFO - 2017-02-21 18:57:35 --> Router Class Initialized
INFO - 2017-02-21 18:57:35 --> Output Class Initialized
INFO - 2017-02-21 18:57:35 --> Security Class Initialized
DEBUG - 2017-02-21 18:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:57:35 --> Input Class Initialized
INFO - 2017-02-21 18:57:35 --> Language Class Initialized
INFO - 2017-02-21 18:57:35 --> Loader Class Initialized
INFO - 2017-02-21 18:57:35 --> Helper loaded: url_helper
INFO - 2017-02-21 18:57:35 --> Helper loaded: language_helper
INFO - 2017-02-21 18:57:35 --> Helper loaded: html_helper
INFO - 2017-02-21 18:57:35 --> Helper loaded: form_helper
INFO - 2017-02-21 18:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:57:35 --> Controller Class Initialized
INFO - 2017-02-21 18:57:35 --> Database Driver Class Initialized
INFO - 2017-02-21 18:57:35 --> Model Class Initialized
INFO - 2017-02-21 18:57:35 --> Email Class Initialized
INFO - 2017-02-21 18:57:35 --> Form Validation Class Initialized
INFO - 2017-02-21 18:57:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:57:35 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 18:57:36 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 18:57:40 --> Final output sent to browser
DEBUG - 2017-02-21 18:57:40 --> Total execution time: 4.6613
INFO - 2017-02-21 18:57:43 --> Config Class Initialized
INFO - 2017-02-21 18:57:43 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:57:43 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:57:43 --> Utf8 Class Initialized
INFO - 2017-02-21 18:57:43 --> URI Class Initialized
INFO - 2017-02-21 18:57:43 --> Router Class Initialized
INFO - 2017-02-21 18:57:44 --> Output Class Initialized
INFO - 2017-02-21 18:57:44 --> Security Class Initialized
DEBUG - 2017-02-21 18:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:57:44 --> Input Class Initialized
INFO - 2017-02-21 18:57:44 --> Language Class Initialized
INFO - 2017-02-21 18:57:44 --> Loader Class Initialized
INFO - 2017-02-21 18:57:44 --> Helper loaded: url_helper
INFO - 2017-02-21 18:57:44 --> Helper loaded: language_helper
INFO - 2017-02-21 18:57:44 --> Helper loaded: html_helper
INFO - 2017-02-21 18:57:44 --> Helper loaded: form_helper
INFO - 2017-02-21 18:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:57:44 --> Controller Class Initialized
INFO - 2017-02-21 18:57:44 --> Database Driver Class Initialized
INFO - 2017-02-21 18:57:44 --> Model Class Initialized
INFO - 2017-02-21 18:57:44 --> Email Class Initialized
INFO - 2017-02-21 18:57:44 --> Form Validation Class Initialized
INFO - 2017-02-21 18:57:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:57:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 18:57:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-21 18:57:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 18:57:44 --> Final output sent to browser
DEBUG - 2017-02-21 18:57:44 --> Total execution time: 0.1334
INFO - 2017-02-21 18:58:55 --> Config Class Initialized
INFO - 2017-02-21 18:58:55 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:58:55 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:58:55 --> Utf8 Class Initialized
INFO - 2017-02-21 18:58:55 --> URI Class Initialized
INFO - 2017-02-21 18:58:55 --> Router Class Initialized
INFO - 2017-02-21 18:58:55 --> Output Class Initialized
INFO - 2017-02-21 18:58:55 --> Security Class Initialized
DEBUG - 2017-02-21 18:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:58:55 --> Input Class Initialized
INFO - 2017-02-21 18:58:55 --> Language Class Initialized
INFO - 2017-02-21 18:58:55 --> Loader Class Initialized
INFO - 2017-02-21 18:58:55 --> Helper loaded: url_helper
INFO - 2017-02-21 18:58:55 --> Helper loaded: language_helper
INFO - 2017-02-21 18:58:55 --> Helper loaded: html_helper
INFO - 2017-02-21 18:58:55 --> Helper loaded: form_helper
INFO - 2017-02-21 18:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:58:55 --> Controller Class Initialized
INFO - 2017-02-21 18:58:55 --> Database Driver Class Initialized
INFO - 2017-02-21 18:58:55 --> Model Class Initialized
INFO - 2017-02-21 18:58:55 --> Email Class Initialized
INFO - 2017-02-21 18:58:55 --> Form Validation Class Initialized
INFO - 2017-02-21 18:58:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:58:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 18:58:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 18:58:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 18:58:55 --> Final output sent to browser
DEBUG - 2017-02-21 18:58:55 --> Total execution time: 0.1024
INFO - 2017-02-21 18:59:20 --> Config Class Initialized
INFO - 2017-02-21 18:59:20 --> Hooks Class Initialized
DEBUG - 2017-02-21 18:59:20 --> UTF-8 Support Enabled
INFO - 2017-02-21 18:59:20 --> Utf8 Class Initialized
INFO - 2017-02-21 18:59:20 --> URI Class Initialized
INFO - 2017-02-21 18:59:20 --> Router Class Initialized
INFO - 2017-02-21 18:59:20 --> Output Class Initialized
INFO - 2017-02-21 18:59:20 --> Security Class Initialized
DEBUG - 2017-02-21 18:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 18:59:20 --> Input Class Initialized
INFO - 2017-02-21 18:59:20 --> Language Class Initialized
INFO - 2017-02-21 18:59:20 --> Loader Class Initialized
INFO - 2017-02-21 18:59:20 --> Helper loaded: url_helper
INFO - 2017-02-21 18:59:20 --> Helper loaded: language_helper
INFO - 2017-02-21 18:59:20 --> Helper loaded: html_helper
INFO - 2017-02-21 18:59:20 --> Helper loaded: form_helper
INFO - 2017-02-21 18:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 18:59:20 --> Controller Class Initialized
INFO - 2017-02-21 18:59:20 --> Database Driver Class Initialized
INFO - 2017-02-21 18:59:20 --> Model Class Initialized
INFO - 2017-02-21 18:59:20 --> Email Class Initialized
INFO - 2017-02-21 18:59:20 --> Form Validation Class Initialized
INFO - 2017-02-21 18:59:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 18:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 18:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-02-21 18:59:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 18:59:20 --> Final output sent to browser
DEBUG - 2017-02-21 18:59:20 --> Total execution time: 0.1517
INFO - 2017-02-21 19:00:13 --> Config Class Initialized
INFO - 2017-02-21 19:00:13 --> Hooks Class Initialized
DEBUG - 2017-02-21 19:00:13 --> UTF-8 Support Enabled
INFO - 2017-02-21 19:00:13 --> Utf8 Class Initialized
INFO - 2017-02-21 19:00:13 --> URI Class Initialized
INFO - 2017-02-21 19:00:13 --> Router Class Initialized
INFO - 2017-02-21 19:00:13 --> Output Class Initialized
INFO - 2017-02-21 19:00:13 --> Security Class Initialized
DEBUG - 2017-02-21 19:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 19:00:13 --> Input Class Initialized
INFO - 2017-02-21 19:00:13 --> Language Class Initialized
INFO - 2017-02-21 19:00:13 --> Loader Class Initialized
INFO - 2017-02-21 19:00:13 --> Helper loaded: url_helper
INFO - 2017-02-21 19:00:13 --> Helper loaded: language_helper
INFO - 2017-02-21 19:00:13 --> Helper loaded: html_helper
INFO - 2017-02-21 19:00:13 --> Helper loaded: form_helper
INFO - 2017-02-21 19:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 19:00:13 --> Controller Class Initialized
INFO - 2017-02-21 19:00:13 --> Database Driver Class Initialized
INFO - 2017-02-21 19:00:13 --> Model Class Initialized
INFO - 2017-02-21 19:00:13 --> Email Class Initialized
INFO - 2017-02-21 19:00:13 --> Form Validation Class Initialized
INFO - 2017-02-21 19:00:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 19:00:14 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-02-21 19:00:14 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-02-21 19:00:18 --> Final output sent to browser
DEBUG - 2017-02-21 19:00:18 --> Total execution time: 4.5116
INFO - 2017-02-21 19:00:19 --> Config Class Initialized
INFO - 2017-02-21 19:00:19 --> Hooks Class Initialized
DEBUG - 2017-02-21 19:00:19 --> UTF-8 Support Enabled
INFO - 2017-02-21 19:00:19 --> Utf8 Class Initialized
INFO - 2017-02-21 19:00:19 --> URI Class Initialized
INFO - 2017-02-21 19:00:19 --> Router Class Initialized
INFO - 2017-02-21 19:00:20 --> Output Class Initialized
INFO - 2017-02-21 19:00:20 --> Security Class Initialized
DEBUG - 2017-02-21 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 19:00:20 --> Input Class Initialized
INFO - 2017-02-21 19:00:20 --> Language Class Initialized
INFO - 2017-02-21 19:00:20 --> Loader Class Initialized
INFO - 2017-02-21 19:00:20 --> Helper loaded: url_helper
INFO - 2017-02-21 19:00:20 --> Helper loaded: language_helper
INFO - 2017-02-21 19:00:20 --> Helper loaded: html_helper
INFO - 2017-02-21 19:00:20 --> Helper loaded: form_helper
INFO - 2017-02-21 19:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 19:00:20 --> Controller Class Initialized
INFO - 2017-02-21 19:00:20 --> Database Driver Class Initialized
INFO - 2017-02-21 19:00:20 --> Model Class Initialized
INFO - 2017-02-21 19:00:20 --> Email Class Initialized
INFO - 2017-02-21 19:00:20 --> Form Validation Class Initialized
INFO - 2017-02-21 19:00:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 19:00:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 19:00:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-02-21 19:00:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 19:00:20 --> Final output sent to browser
DEBUG - 2017-02-21 19:00:20 --> Total execution time: 0.1431
INFO - 2017-02-21 19:00:23 --> Config Class Initialized
INFO - 2017-02-21 19:00:23 --> Hooks Class Initialized
DEBUG - 2017-02-21 19:00:23 --> UTF-8 Support Enabled
INFO - 2017-02-21 19:00:23 --> Utf8 Class Initialized
INFO - 2017-02-21 19:00:23 --> URI Class Initialized
DEBUG - 2017-02-21 19:00:23 --> No URI present. Default controller set.
INFO - 2017-02-21 19:00:23 --> Router Class Initialized
INFO - 2017-02-21 19:00:23 --> Output Class Initialized
INFO - 2017-02-21 19:00:23 --> Security Class Initialized
DEBUG - 2017-02-21 19:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 19:00:23 --> Input Class Initialized
INFO - 2017-02-21 19:00:23 --> Language Class Initialized
INFO - 2017-02-21 19:00:23 --> Loader Class Initialized
INFO - 2017-02-21 19:00:23 --> Helper loaded: url_helper
INFO - 2017-02-21 19:00:23 --> Helper loaded: language_helper
INFO - 2017-02-21 19:00:23 --> Helper loaded: html_helper
INFO - 2017-02-21 19:00:23 --> Helper loaded: form_helper
INFO - 2017-02-21 19:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 19:00:23 --> Controller Class Initialized
INFO - 2017-02-21 19:00:23 --> Database Driver Class Initialized
INFO - 2017-02-21 19:00:23 --> Model Class Initialized
INFO - 2017-02-21 19:00:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 19:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 19:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 19:00:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 19:00:23 --> Final output sent to browser
DEBUG - 2017-02-21 19:00:23 --> Total execution time: 0.1104
INFO - 2017-02-21 19:28:29 --> Config Class Initialized
INFO - 2017-02-21 19:28:29 --> Hooks Class Initialized
DEBUG - 2017-02-21 19:28:29 --> UTF-8 Support Enabled
INFO - 2017-02-21 19:28:29 --> Utf8 Class Initialized
INFO - 2017-02-21 19:28:29 --> URI Class Initialized
DEBUG - 2017-02-21 19:28:29 --> No URI present. Default controller set.
INFO - 2017-02-21 19:28:29 --> Router Class Initialized
INFO - 2017-02-21 19:28:29 --> Output Class Initialized
INFO - 2017-02-21 19:28:29 --> Security Class Initialized
DEBUG - 2017-02-21 19:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 19:28:29 --> Input Class Initialized
INFO - 2017-02-21 19:28:29 --> Language Class Initialized
INFO - 2017-02-21 19:28:29 --> Loader Class Initialized
INFO - 2017-02-21 19:28:29 --> Helper loaded: url_helper
INFO - 2017-02-21 19:28:29 --> Helper loaded: language_helper
INFO - 2017-02-21 19:28:29 --> Helper loaded: html_helper
INFO - 2017-02-21 19:28:29 --> Helper loaded: form_helper
INFO - 2017-02-21 19:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 19:28:29 --> Controller Class Initialized
INFO - 2017-02-21 19:28:29 --> Database Driver Class Initialized
INFO - 2017-02-21 19:28:29 --> Model Class Initialized
INFO - 2017-02-21 19:28:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 19:28:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-21 19:28:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-21 19:28:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-21 19:28:29 --> Final output sent to browser
DEBUG - 2017-02-21 19:28:29 --> Total execution time: 0.1655
INFO - 2017-02-21 19:51:27 --> Config Class Initialized
INFO - 2017-02-21 19:51:27 --> Hooks Class Initialized
DEBUG - 2017-02-21 19:51:27 --> UTF-8 Support Enabled
INFO - 2017-02-21 19:51:27 --> Utf8 Class Initialized
INFO - 2017-02-21 19:51:27 --> URI Class Initialized
INFO - 2017-02-21 19:51:27 --> Router Class Initialized
INFO - 2017-02-21 19:51:27 --> Output Class Initialized
INFO - 2017-02-21 19:51:27 --> Security Class Initialized
DEBUG - 2017-02-21 19:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 19:51:27 --> Input Class Initialized
INFO - 2017-02-21 19:51:27 --> Language Class Initialized
INFO - 2017-02-21 19:51:27 --> Loader Class Initialized
INFO - 2017-02-21 19:51:27 --> Helper loaded: url_helper
INFO - 2017-02-21 19:51:27 --> Helper loaded: language_helper
INFO - 2017-02-21 19:51:27 --> Helper loaded: html_helper
INFO - 2017-02-21 19:51:27 --> Helper loaded: form_helper
INFO - 2017-02-21 19:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 19:51:27 --> Controller Class Initialized
INFO - 2017-02-21 19:51:27 --> Database Driver Class Initialized
INFO - 2017-02-21 19:51:27 --> Model Class Initialized
INFO - 2017-02-21 19:51:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 19:51:27 --> Config Class Initialized
INFO - 2017-02-21 19:51:27 --> Hooks Class Initialized
DEBUG - 2017-02-21 19:51:27 --> UTF-8 Support Enabled
INFO - 2017-02-21 19:51:27 --> Utf8 Class Initialized
INFO - 2017-02-21 19:51:27 --> URI Class Initialized
INFO - 2017-02-21 19:51:27 --> Router Class Initialized
INFO - 2017-02-21 19:51:27 --> Output Class Initialized
INFO - 2017-02-21 19:51:27 --> Security Class Initialized
DEBUG - 2017-02-21 19:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 19:51:28 --> Input Class Initialized
INFO - 2017-02-21 19:51:28 --> Language Class Initialized
INFO - 2017-02-21 19:51:28 --> Loader Class Initialized
INFO - 2017-02-21 19:51:28 --> Helper loaded: url_helper
INFO - 2017-02-21 19:51:28 --> Helper loaded: language_helper
INFO - 2017-02-21 19:51:28 --> Helper loaded: html_helper
INFO - 2017-02-21 19:51:28 --> Helper loaded: form_helper
INFO - 2017-02-21 19:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 19:51:28 --> Controller Class Initialized
INFO - 2017-02-21 19:51:28 --> Database Driver Class Initialized
INFO - 2017-02-21 19:51:28 --> Model Class Initialized
INFO - 2017-02-21 19:51:28 --> Model Class Initialized
INFO - 2017-02-21 19:51:28 --> Model Class Initialized
INFO - 2017-02-21 19:51:28 --> Model Class Initialized
INFO - 2017-02-21 19:51:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 19:51:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 19:51:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-21 19:51:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 19:51:28 --> Final output sent to browser
DEBUG - 2017-02-21 19:51:28 --> Total execution time: 0.2257
INFO - 2017-02-21 19:51:31 --> Config Class Initialized
INFO - 2017-02-21 19:51:31 --> Hooks Class Initialized
DEBUG - 2017-02-21 19:51:31 --> UTF-8 Support Enabled
INFO - 2017-02-21 19:51:31 --> Utf8 Class Initialized
INFO - 2017-02-21 19:51:31 --> URI Class Initialized
INFO - 2017-02-21 19:51:31 --> Router Class Initialized
INFO - 2017-02-21 19:51:31 --> Output Class Initialized
INFO - 2017-02-21 19:51:31 --> Security Class Initialized
DEBUG - 2017-02-21 19:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-21 19:51:31 --> Input Class Initialized
INFO - 2017-02-21 19:51:31 --> Language Class Initialized
INFO - 2017-02-21 19:51:31 --> Loader Class Initialized
INFO - 2017-02-21 19:51:31 --> Helper loaded: url_helper
INFO - 2017-02-21 19:51:31 --> Helper loaded: language_helper
INFO - 2017-02-21 19:51:31 --> Helper loaded: html_helper
INFO - 2017-02-21 19:51:31 --> Helper loaded: form_helper
INFO - 2017-02-21 19:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-21 19:51:31 --> Controller Class Initialized
INFO - 2017-02-21 19:51:31 --> Database Driver Class Initialized
INFO - 2017-02-21 19:51:31 --> Model Class Initialized
INFO - 2017-02-21 19:51:31 --> Model Class Initialized
INFO - 2017-02-21 19:51:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-21 19:51:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-21 19:51:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-21 19:51:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-21 19:51:31 --> Final output sent to browser
DEBUG - 2017-02-21 19:51:31 --> Total execution time: 0.3974
