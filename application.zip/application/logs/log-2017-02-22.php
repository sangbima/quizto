<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-22 10:11:14 --> Config Class Initialized
INFO - 2017-02-22 10:11:14 --> Hooks Class Initialized
DEBUG - 2017-02-22 10:11:14 --> UTF-8 Support Enabled
INFO - 2017-02-22 10:11:14 --> Utf8 Class Initialized
INFO - 2017-02-22 10:11:14 --> URI Class Initialized
INFO - 2017-02-22 10:11:14 --> Router Class Initialized
INFO - 2017-02-22 10:11:14 --> Output Class Initialized
INFO - 2017-02-22 10:11:14 --> Security Class Initialized
DEBUG - 2017-02-22 10:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 10:11:14 --> Input Class Initialized
INFO - 2017-02-22 10:11:14 --> Language Class Initialized
INFO - 2017-02-22 10:11:14 --> Loader Class Initialized
INFO - 2017-02-22 10:11:14 --> Helper loaded: url_helper
INFO - 2017-02-22 10:11:14 --> Helper loaded: language_helper
INFO - 2017-02-22 10:11:14 --> Helper loaded: html_helper
INFO - 2017-02-22 10:11:14 --> Helper loaded: form_helper
INFO - 2017-02-22 10:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 10:11:14 --> Controller Class Initialized
INFO - 2017-02-22 10:11:14 --> Database Driver Class Initialized
INFO - 2017-02-22 10:11:14 --> Model Class Initialized
INFO - 2017-02-22 10:11:14 --> Model Class Initialized
INFO - 2017-02-22 10:11:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 10:11:14 --> Config Class Initialized
INFO - 2017-02-22 10:11:14 --> Hooks Class Initialized
DEBUG - 2017-02-22 10:11:14 --> UTF-8 Support Enabled
INFO - 2017-02-22 10:11:14 --> Utf8 Class Initialized
INFO - 2017-02-22 10:11:14 --> URI Class Initialized
INFO - 2017-02-22 10:11:14 --> Router Class Initialized
INFO - 2017-02-22 10:11:14 --> Output Class Initialized
INFO - 2017-02-22 10:11:14 --> Security Class Initialized
DEBUG - 2017-02-22 10:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 10:11:14 --> Input Class Initialized
INFO - 2017-02-22 10:11:14 --> Language Class Initialized
INFO - 2017-02-22 10:11:14 --> Loader Class Initialized
INFO - 2017-02-22 10:11:14 --> Helper loaded: url_helper
INFO - 2017-02-22 10:11:14 --> Helper loaded: language_helper
INFO - 2017-02-22 10:11:14 --> Helper loaded: html_helper
INFO - 2017-02-22 10:11:14 --> Helper loaded: form_helper
INFO - 2017-02-22 10:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 10:11:14 --> Controller Class Initialized
INFO - 2017-02-22 10:11:14 --> Database Driver Class Initialized
INFO - 2017-02-22 10:11:14 --> Model Class Initialized
INFO - 2017-02-22 10:11:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 10:11:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-22 10:11:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-22 10:11:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-22 10:11:14 --> Final output sent to browser
DEBUG - 2017-02-22 10:11:14 --> Total execution time: 0.2104
INFO - 2017-02-22 11:19:31 --> Config Class Initialized
INFO - 2017-02-22 11:19:31 --> Hooks Class Initialized
DEBUG - 2017-02-22 11:19:31 --> UTF-8 Support Enabled
INFO - 2017-02-22 11:19:31 --> Utf8 Class Initialized
INFO - 2017-02-22 11:19:31 --> URI Class Initialized
INFO - 2017-02-22 11:19:31 --> Router Class Initialized
INFO - 2017-02-22 11:19:31 --> Output Class Initialized
INFO - 2017-02-22 11:19:31 --> Security Class Initialized
DEBUG - 2017-02-22 11:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 11:19:31 --> Input Class Initialized
INFO - 2017-02-22 11:19:31 --> Language Class Initialized
INFO - 2017-02-22 11:19:31 --> Loader Class Initialized
INFO - 2017-02-22 11:19:31 --> Helper loaded: url_helper
INFO - 2017-02-22 11:19:31 --> Helper loaded: language_helper
INFO - 2017-02-22 11:19:31 --> Helper loaded: html_helper
INFO - 2017-02-22 11:19:31 --> Helper loaded: form_helper
INFO - 2017-02-22 11:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 11:19:31 --> Controller Class Initialized
INFO - 2017-02-22 11:19:31 --> Database Driver Class Initialized
INFO - 2017-02-22 11:19:31 --> Model Class Initialized
INFO - 2017-02-22 11:19:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 11:19:32 --> Config Class Initialized
INFO - 2017-02-22 11:19:32 --> Hooks Class Initialized
DEBUG - 2017-02-22 11:19:32 --> UTF-8 Support Enabled
INFO - 2017-02-22 11:19:32 --> Utf8 Class Initialized
INFO - 2017-02-22 11:19:32 --> URI Class Initialized
INFO - 2017-02-22 11:19:32 --> Router Class Initialized
INFO - 2017-02-22 11:19:32 --> Output Class Initialized
INFO - 2017-02-22 11:19:32 --> Security Class Initialized
DEBUG - 2017-02-22 11:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 11:19:32 --> Input Class Initialized
INFO - 2017-02-22 11:19:32 --> Language Class Initialized
INFO - 2017-02-22 11:19:32 --> Loader Class Initialized
INFO - 2017-02-22 11:19:32 --> Helper loaded: url_helper
INFO - 2017-02-22 11:19:32 --> Helper loaded: language_helper
INFO - 2017-02-22 11:19:32 --> Helper loaded: html_helper
INFO - 2017-02-22 11:19:32 --> Helper loaded: form_helper
INFO - 2017-02-22 11:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 11:19:32 --> Controller Class Initialized
INFO - 2017-02-22 11:19:32 --> Database Driver Class Initialized
INFO - 2017-02-22 11:19:32 --> Model Class Initialized
INFO - 2017-02-22 11:19:32 --> Model Class Initialized
INFO - 2017-02-22 11:19:32 --> Model Class Initialized
INFO - 2017-02-22 11:19:32 --> Model Class Initialized
INFO - 2017-02-22 11:19:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 11:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 11:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-22 11:19:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 11:19:32 --> Final output sent to browser
DEBUG - 2017-02-22 11:19:32 --> Total execution time: 0.1994
INFO - 2017-02-22 11:19:44 --> Config Class Initialized
INFO - 2017-02-22 11:19:44 --> Hooks Class Initialized
DEBUG - 2017-02-22 11:19:44 --> UTF-8 Support Enabled
INFO - 2017-02-22 11:19:44 --> Utf8 Class Initialized
INFO - 2017-02-22 11:19:44 --> URI Class Initialized
INFO - 2017-02-22 11:19:44 --> Router Class Initialized
INFO - 2017-02-22 11:19:44 --> Output Class Initialized
INFO - 2017-02-22 11:19:44 --> Security Class Initialized
DEBUG - 2017-02-22 11:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 11:19:44 --> Input Class Initialized
INFO - 2017-02-22 11:19:44 --> Language Class Initialized
INFO - 2017-02-22 11:19:44 --> Loader Class Initialized
INFO - 2017-02-22 11:19:44 --> Helper loaded: url_helper
INFO - 2017-02-22 11:19:44 --> Helper loaded: language_helper
INFO - 2017-02-22 11:19:44 --> Helper loaded: html_helper
INFO - 2017-02-22 11:19:44 --> Helper loaded: form_helper
INFO - 2017-02-22 11:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 11:19:44 --> Controller Class Initialized
INFO - 2017-02-22 11:19:44 --> Database Driver Class Initialized
INFO - 2017-02-22 11:19:44 --> Model Class Initialized
INFO - 2017-02-22 11:19:44 --> Model Class Initialized
INFO - 2017-02-22 11:19:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 11:19:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 11:19:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-22 11:19:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 11:19:44 --> Final output sent to browser
DEBUG - 2017-02-22 11:19:44 --> Total execution time: 0.3640
INFO - 2017-02-22 11:19:46 --> Config Class Initialized
INFO - 2017-02-22 11:19:46 --> Hooks Class Initialized
DEBUG - 2017-02-22 11:19:46 --> UTF-8 Support Enabled
INFO - 2017-02-22 11:19:46 --> Utf8 Class Initialized
INFO - 2017-02-22 11:19:46 --> URI Class Initialized
INFO - 2017-02-22 11:19:46 --> Router Class Initialized
INFO - 2017-02-22 11:19:46 --> Output Class Initialized
INFO - 2017-02-22 11:19:46 --> Security Class Initialized
DEBUG - 2017-02-22 11:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 11:19:46 --> Input Class Initialized
INFO - 2017-02-22 11:19:46 --> Language Class Initialized
INFO - 2017-02-22 11:19:46 --> Loader Class Initialized
INFO - 2017-02-22 11:19:46 --> Helper loaded: url_helper
INFO - 2017-02-22 11:19:46 --> Helper loaded: language_helper
INFO - 2017-02-22 11:19:46 --> Helper loaded: html_helper
INFO - 2017-02-22 11:19:46 --> Helper loaded: form_helper
INFO - 2017-02-22 11:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 11:19:47 --> Controller Class Initialized
INFO - 2017-02-22 11:19:47 --> Database Driver Class Initialized
INFO - 2017-02-22 11:19:47 --> Model Class Initialized
INFO - 2017-02-22 11:19:47 --> Model Class Initialized
INFO - 2017-02-22 11:19:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 11:19:47 --> Model Class Initialized
INFO - 2017-02-22 11:19:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 11:19:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-22 11:19:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 11:19:47 --> Final output sent to browser
DEBUG - 2017-02-22 11:19:47 --> Total execution time: 0.3056
INFO - 2017-02-22 11:57:46 --> Config Class Initialized
INFO - 2017-02-22 11:57:46 --> Hooks Class Initialized
DEBUG - 2017-02-22 11:57:46 --> UTF-8 Support Enabled
INFO - 2017-02-22 11:57:46 --> Utf8 Class Initialized
INFO - 2017-02-22 11:57:46 --> URI Class Initialized
INFO - 2017-02-22 11:57:46 --> Router Class Initialized
INFO - 2017-02-22 11:57:46 --> Output Class Initialized
INFO - 2017-02-22 11:57:46 --> Security Class Initialized
DEBUG - 2017-02-22 11:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 11:57:46 --> Input Class Initialized
INFO - 2017-02-22 11:57:46 --> Language Class Initialized
INFO - 2017-02-22 11:57:46 --> Loader Class Initialized
INFO - 2017-02-22 11:57:46 --> Helper loaded: url_helper
INFO - 2017-02-22 11:57:46 --> Helper loaded: language_helper
INFO - 2017-02-22 11:57:46 --> Helper loaded: html_helper
INFO - 2017-02-22 11:57:46 --> Helper loaded: form_helper
INFO - 2017-02-22 11:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 11:57:46 --> Controller Class Initialized
INFO - 2017-02-22 11:57:46 --> Database Driver Class Initialized
INFO - 2017-02-22 11:57:47 --> Model Class Initialized
INFO - 2017-02-22 11:57:47 --> Model Class Initialized
INFO - 2017-02-22 11:57:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 11:57:47 --> Model Class Initialized
INFO - 2017-02-22 11:57:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 11:57:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_detail.php
INFO - 2017-02-22 11:57:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 11:57:47 --> Final output sent to browser
DEBUG - 2017-02-22 11:57:47 --> Total execution time: 0.4760
INFO - 2017-02-22 13:22:11 --> Config Class Initialized
INFO - 2017-02-22 13:22:11 --> Hooks Class Initialized
DEBUG - 2017-02-22 13:22:11 --> UTF-8 Support Enabled
INFO - 2017-02-22 13:22:11 --> Utf8 Class Initialized
INFO - 2017-02-22 13:22:11 --> URI Class Initialized
INFO - 2017-02-22 13:22:11 --> Router Class Initialized
INFO - 2017-02-22 13:22:11 --> Output Class Initialized
INFO - 2017-02-22 13:22:11 --> Security Class Initialized
DEBUG - 2017-02-22 13:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 13:22:11 --> Input Class Initialized
INFO - 2017-02-22 13:22:11 --> Language Class Initialized
INFO - 2017-02-22 13:22:11 --> Loader Class Initialized
INFO - 2017-02-22 13:22:11 --> Helper loaded: url_helper
INFO - 2017-02-22 13:22:11 --> Helper loaded: language_helper
INFO - 2017-02-22 13:22:11 --> Helper loaded: html_helper
INFO - 2017-02-22 13:22:11 --> Helper loaded: form_helper
INFO - 2017-02-22 13:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 13:22:11 --> Controller Class Initialized
INFO - 2017-02-22 13:22:11 --> Database Driver Class Initialized
INFO - 2017-02-22 13:22:11 --> Model Class Initialized
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "title"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "dashboard"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "users"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "add_new"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "user_list"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "adminlist"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "operatorlist"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "qbank"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "add_new"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "question_list"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "quiz"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "quiz_list"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "result"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "result_all"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "result_tpu_tpa"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "result_ist"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "result_disc"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "setting"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "group_list"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "category_list"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "level_list"
ERROR - 2017-02-22 13:22:11 --> Could not find the language line "logout"
INFO - 2017-02-22 13:22:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 13:22:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 13:22:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 13:22:11 --> Final output sent to browser
DEBUG - 2017-02-22 13:22:11 --> Total execution time: 0.1939
INFO - 2017-02-22 13:23:06 --> Config Class Initialized
INFO - 2017-02-22 13:23:06 --> Hooks Class Initialized
DEBUG - 2017-02-22 13:23:06 --> UTF-8 Support Enabled
INFO - 2017-02-22 13:23:06 --> Utf8 Class Initialized
INFO - 2017-02-22 13:23:06 --> URI Class Initialized
INFO - 2017-02-22 13:23:06 --> Router Class Initialized
INFO - 2017-02-22 13:23:06 --> Output Class Initialized
INFO - 2017-02-22 13:23:06 --> Security Class Initialized
DEBUG - 2017-02-22 13:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 13:23:06 --> Input Class Initialized
INFO - 2017-02-22 13:23:06 --> Language Class Initialized
INFO - 2017-02-22 13:23:06 --> Loader Class Initialized
INFO - 2017-02-22 13:23:06 --> Helper loaded: url_helper
INFO - 2017-02-22 13:23:06 --> Helper loaded: language_helper
INFO - 2017-02-22 13:23:06 --> Helper loaded: html_helper
INFO - 2017-02-22 13:23:06 --> Helper loaded: form_helper
INFO - 2017-02-22 13:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 13:23:06 --> Controller Class Initialized
INFO - 2017-02-22 13:23:06 --> Database Driver Class Initialized
INFO - 2017-02-22 13:23:06 --> Model Class Initialized
INFO - 2017-02-22 13:23:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 13:23:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 13:23:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 13:23:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 13:23:06 --> Final output sent to browser
DEBUG - 2017-02-22 13:23:06 --> Total execution time: 0.1172
INFO - 2017-02-22 13:28:41 --> Config Class Initialized
INFO - 2017-02-22 13:28:41 --> Hooks Class Initialized
DEBUG - 2017-02-22 13:28:41 --> UTF-8 Support Enabled
INFO - 2017-02-22 13:28:41 --> Utf8 Class Initialized
INFO - 2017-02-22 13:28:41 --> URI Class Initialized
INFO - 2017-02-22 13:28:41 --> Router Class Initialized
INFO - 2017-02-22 13:28:41 --> Output Class Initialized
INFO - 2017-02-22 13:28:41 --> Security Class Initialized
DEBUG - 2017-02-22 13:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 13:28:41 --> Input Class Initialized
INFO - 2017-02-22 13:28:41 --> Language Class Initialized
INFO - 2017-02-22 13:28:41 --> Loader Class Initialized
INFO - 2017-02-22 13:28:41 --> Helper loaded: url_helper
INFO - 2017-02-22 13:28:41 --> Helper loaded: language_helper
INFO - 2017-02-22 13:28:41 --> Helper loaded: html_helper
INFO - 2017-02-22 13:28:41 --> Helper loaded: form_helper
INFO - 2017-02-22 13:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 13:28:41 --> Controller Class Initialized
INFO - 2017-02-22 13:28:41 --> Database Driver Class Initialized
INFO - 2017-02-22 13:28:41 --> Model Class Initialized
INFO - 2017-02-22 13:28:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 13:28:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 13:28:41 --> Final output sent to browser
DEBUG - 2017-02-22 13:28:41 --> Total execution time: 0.1318
INFO - 2017-02-22 13:30:31 --> Config Class Initialized
INFO - 2017-02-22 13:30:31 --> Hooks Class Initialized
DEBUG - 2017-02-22 13:30:31 --> UTF-8 Support Enabled
INFO - 2017-02-22 13:30:31 --> Utf8 Class Initialized
INFO - 2017-02-22 13:30:31 --> URI Class Initialized
INFO - 2017-02-22 13:30:31 --> Router Class Initialized
INFO - 2017-02-22 13:30:31 --> Output Class Initialized
INFO - 2017-02-22 13:30:31 --> Security Class Initialized
DEBUG - 2017-02-22 13:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 13:30:31 --> Input Class Initialized
INFO - 2017-02-22 13:30:31 --> Language Class Initialized
INFO - 2017-02-22 13:30:31 --> Loader Class Initialized
INFO - 2017-02-22 13:30:31 --> Helper loaded: url_helper
INFO - 2017-02-22 13:30:31 --> Helper loaded: language_helper
INFO - 2017-02-22 13:30:31 --> Helper loaded: html_helper
INFO - 2017-02-22 13:30:31 --> Helper loaded: form_helper
INFO - 2017-02-22 13:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 13:30:31 --> Controller Class Initialized
INFO - 2017-02-22 13:30:32 --> Database Driver Class Initialized
INFO - 2017-02-22 13:30:32 --> Model Class Initialized
INFO - 2017-02-22 13:30:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 13:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-22 13:30:32 --> Severity: Notice --> Undefined variable: limit C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 20
ERROR - 2017-02-22 13:30:32 --> Severity: Notice --> Undefined variable: search C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 20
ERROR - 2017-02-22 13:30:32 --> Severity: Notice --> Undefined variable: search C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 20
ERROR - 2017-02-22 13:30:32 --> Severity: Notice --> Undefined variable: limit C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 21
ERROR - 2017-02-22 13:30:32 --> Severity: Notice --> Undefined variable: search C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 21
ERROR - 2017-02-22 13:30:32 --> Severity: Notice --> Undefined variable: search C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 21
INFO - 2017-02-22 13:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 13:30:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 13:30:32 --> Final output sent to browser
DEBUG - 2017-02-22 13:30:32 --> Total execution time: 0.1407
INFO - 2017-02-22 13:32:03 --> Config Class Initialized
INFO - 2017-02-22 13:32:03 --> Hooks Class Initialized
DEBUG - 2017-02-22 13:32:03 --> UTF-8 Support Enabled
INFO - 2017-02-22 13:32:03 --> Utf8 Class Initialized
INFO - 2017-02-22 13:32:03 --> URI Class Initialized
INFO - 2017-02-22 13:32:03 --> Router Class Initialized
INFO - 2017-02-22 13:32:03 --> Output Class Initialized
INFO - 2017-02-22 13:32:03 --> Security Class Initialized
DEBUG - 2017-02-22 13:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 13:32:03 --> Input Class Initialized
INFO - 2017-02-22 13:32:03 --> Language Class Initialized
INFO - 2017-02-22 13:32:03 --> Loader Class Initialized
INFO - 2017-02-22 13:32:03 --> Helper loaded: url_helper
INFO - 2017-02-22 13:32:03 --> Helper loaded: language_helper
INFO - 2017-02-22 13:32:03 --> Helper loaded: html_helper
INFO - 2017-02-22 13:32:03 --> Helper loaded: form_helper
INFO - 2017-02-22 13:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 13:32:03 --> Controller Class Initialized
INFO - 2017-02-22 13:32:03 --> Database Driver Class Initialized
INFO - 2017-02-22 13:32:03 --> Model Class Initialized
INFO - 2017-02-22 13:32:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 13:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 13:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 13:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 13:32:03 --> Final output sent to browser
DEBUG - 2017-02-22 13:32:03 --> Total execution time: 0.1500
INFO - 2017-02-22 13:34:08 --> Config Class Initialized
INFO - 2017-02-22 13:34:08 --> Hooks Class Initialized
DEBUG - 2017-02-22 13:34:08 --> UTF-8 Support Enabled
INFO - 2017-02-22 13:34:08 --> Utf8 Class Initialized
INFO - 2017-02-22 13:34:08 --> URI Class Initialized
INFO - 2017-02-22 13:34:08 --> Router Class Initialized
INFO - 2017-02-22 13:34:08 --> Output Class Initialized
INFO - 2017-02-22 13:34:08 --> Security Class Initialized
DEBUG - 2017-02-22 13:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 13:34:08 --> Input Class Initialized
INFO - 2017-02-22 13:34:08 --> Language Class Initialized
INFO - 2017-02-22 13:34:08 --> Loader Class Initialized
INFO - 2017-02-22 13:34:08 --> Helper loaded: url_helper
INFO - 2017-02-22 13:34:08 --> Helper loaded: language_helper
INFO - 2017-02-22 13:34:08 --> Helper loaded: html_helper
INFO - 2017-02-22 13:34:08 --> Helper loaded: form_helper
INFO - 2017-02-22 13:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 13:34:08 --> Controller Class Initialized
INFO - 2017-02-22 13:34:08 --> Database Driver Class Initialized
INFO - 2017-02-22 13:34:08 --> Model Class Initialized
INFO - 2017-02-22 13:34:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 13:34:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 13:34:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 13:34:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 13:34:08 --> Final output sent to browser
DEBUG - 2017-02-22 13:34:08 --> Total execution time: 0.1505
INFO - 2017-02-22 14:56:05 --> Config Class Initialized
INFO - 2017-02-22 14:56:05 --> Hooks Class Initialized
DEBUG - 2017-02-22 14:56:05 --> UTF-8 Support Enabled
INFO - 2017-02-22 14:56:05 --> Utf8 Class Initialized
INFO - 2017-02-22 14:56:05 --> URI Class Initialized
INFO - 2017-02-22 14:56:05 --> Router Class Initialized
INFO - 2017-02-22 14:56:05 --> Output Class Initialized
INFO - 2017-02-22 14:56:05 --> Security Class Initialized
DEBUG - 2017-02-22 14:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 14:56:05 --> Input Class Initialized
INFO - 2017-02-22 14:56:05 --> Language Class Initialized
INFO - 2017-02-22 14:56:05 --> Loader Class Initialized
INFO - 2017-02-22 14:56:05 --> Helper loaded: url_helper
INFO - 2017-02-22 14:56:05 --> Helper loaded: language_helper
INFO - 2017-02-22 14:56:05 --> Helper loaded: html_helper
INFO - 2017-02-22 14:56:05 --> Helper loaded: form_helper
INFO - 2017-02-22 14:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 14:56:05 --> Controller Class Initialized
INFO - 2017-02-22 14:56:05 --> Database Driver Class Initialized
INFO - 2017-02-22 14:56:05 --> Model Class Initialized
INFO - 2017-02-22 14:56:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 14:56:05 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 14:56:05 --> Pagination Class Initialized
INFO - 2017-02-22 14:56:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 14:56:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 14:56:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 14:56:05 --> Final output sent to browser
DEBUG - 2017-02-22 14:56:05 --> Total execution time: 0.1727
INFO - 2017-02-22 14:57:04 --> Config Class Initialized
INFO - 2017-02-22 14:57:04 --> Hooks Class Initialized
DEBUG - 2017-02-22 14:57:04 --> UTF-8 Support Enabled
INFO - 2017-02-22 14:57:04 --> Utf8 Class Initialized
INFO - 2017-02-22 14:57:04 --> URI Class Initialized
INFO - 2017-02-22 14:57:04 --> Router Class Initialized
INFO - 2017-02-22 14:57:04 --> Output Class Initialized
INFO - 2017-02-22 14:57:04 --> Security Class Initialized
DEBUG - 2017-02-22 14:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 14:57:04 --> Input Class Initialized
INFO - 2017-02-22 14:57:04 --> Language Class Initialized
INFO - 2017-02-22 14:57:04 --> Loader Class Initialized
INFO - 2017-02-22 14:57:04 --> Helper loaded: url_helper
INFO - 2017-02-22 14:57:04 --> Helper loaded: language_helper
INFO - 2017-02-22 14:57:04 --> Helper loaded: html_helper
INFO - 2017-02-22 14:57:04 --> Helper loaded: form_helper
INFO - 2017-02-22 14:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 14:57:04 --> Controller Class Initialized
INFO - 2017-02-22 14:57:04 --> Database Driver Class Initialized
INFO - 2017-02-22 14:57:04 --> Model Class Initialized
INFO - 2017-02-22 14:57:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 14:57:04 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 14:57:04 --> Pagination Class Initialized
INFO - 2017-02-22 14:57:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 14:57:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 14:57:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 14:57:04 --> Final output sent to browser
DEBUG - 2017-02-22 14:57:04 --> Total execution time: 0.1894
INFO - 2017-02-22 14:58:45 --> Config Class Initialized
INFO - 2017-02-22 14:58:45 --> Hooks Class Initialized
DEBUG - 2017-02-22 14:58:45 --> UTF-8 Support Enabled
INFO - 2017-02-22 14:58:45 --> Utf8 Class Initialized
INFO - 2017-02-22 14:58:45 --> URI Class Initialized
INFO - 2017-02-22 14:58:45 --> Router Class Initialized
INFO - 2017-02-22 14:58:45 --> Output Class Initialized
INFO - 2017-02-22 14:58:45 --> Security Class Initialized
DEBUG - 2017-02-22 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 14:58:45 --> Input Class Initialized
INFO - 2017-02-22 14:58:45 --> Language Class Initialized
INFO - 2017-02-22 14:58:45 --> Loader Class Initialized
INFO - 2017-02-22 14:58:45 --> Helper loaded: url_helper
INFO - 2017-02-22 14:58:45 --> Helper loaded: language_helper
INFO - 2017-02-22 14:58:45 --> Helper loaded: html_helper
INFO - 2017-02-22 14:58:45 --> Helper loaded: form_helper
INFO - 2017-02-22 14:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 14:58:45 --> Controller Class Initialized
INFO - 2017-02-22 14:58:45 --> Database Driver Class Initialized
INFO - 2017-02-22 14:58:45 --> Model Class Initialized
INFO - 2017-02-22 14:58:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 14:58:45 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 14:58:45 --> Pagination Class Initialized
INFO - 2017-02-22 14:58:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 14:58:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 14:58:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 14:58:45 --> Final output sent to browser
DEBUG - 2017-02-22 14:58:45 --> Total execution time: 0.1399
INFO - 2017-02-22 14:59:11 --> Config Class Initialized
INFO - 2017-02-22 14:59:11 --> Hooks Class Initialized
DEBUG - 2017-02-22 14:59:11 --> UTF-8 Support Enabled
INFO - 2017-02-22 14:59:11 --> Utf8 Class Initialized
INFO - 2017-02-22 14:59:11 --> URI Class Initialized
INFO - 2017-02-22 14:59:11 --> Router Class Initialized
INFO - 2017-02-22 14:59:11 --> Output Class Initialized
INFO - 2017-02-22 14:59:11 --> Security Class Initialized
DEBUG - 2017-02-22 14:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 14:59:11 --> Input Class Initialized
INFO - 2017-02-22 14:59:11 --> Language Class Initialized
INFO - 2017-02-22 14:59:11 --> Loader Class Initialized
INFO - 2017-02-22 14:59:11 --> Helper loaded: url_helper
INFO - 2017-02-22 14:59:11 --> Helper loaded: language_helper
INFO - 2017-02-22 14:59:11 --> Helper loaded: html_helper
INFO - 2017-02-22 14:59:11 --> Helper loaded: form_helper
INFO - 2017-02-22 14:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 14:59:11 --> Controller Class Initialized
INFO - 2017-02-22 14:59:11 --> Database Driver Class Initialized
INFO - 2017-02-22 14:59:11 --> Model Class Initialized
INFO - 2017-02-22 14:59:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 14:59:11 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 14:59:11 --> Pagination Class Initialized
INFO - 2017-02-22 14:59:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 14:59:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 14:59:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 14:59:11 --> Final output sent to browser
DEBUG - 2017-02-22 14:59:11 --> Total execution time: 0.1639
INFO - 2017-02-22 15:00:30 --> Config Class Initialized
INFO - 2017-02-22 15:00:30 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:00:30 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:00:30 --> Utf8 Class Initialized
INFO - 2017-02-22 15:00:30 --> URI Class Initialized
INFO - 2017-02-22 15:00:30 --> Router Class Initialized
INFO - 2017-02-22 15:00:30 --> Output Class Initialized
INFO - 2017-02-22 15:00:30 --> Security Class Initialized
DEBUG - 2017-02-22 15:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:00:30 --> Input Class Initialized
INFO - 2017-02-22 15:00:30 --> Language Class Initialized
INFO - 2017-02-22 15:00:30 --> Loader Class Initialized
INFO - 2017-02-22 15:00:30 --> Helper loaded: url_helper
INFO - 2017-02-22 15:00:30 --> Helper loaded: language_helper
INFO - 2017-02-22 15:00:30 --> Helper loaded: html_helper
INFO - 2017-02-22 15:00:30 --> Helper loaded: form_helper
INFO - 2017-02-22 15:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:00:30 --> Controller Class Initialized
INFO - 2017-02-22 15:00:30 --> Database Driver Class Initialized
INFO - 2017-02-22 15:00:30 --> Model Class Initialized
INFO - 2017-02-22 15:00:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:00:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:00:30 --> Pagination Class Initialized
INFO - 2017-02-22 15:00:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:00:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:00:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:00:30 --> Final output sent to browser
DEBUG - 2017-02-22 15:00:30 --> Total execution time: 0.1511
INFO - 2017-02-22 15:03:00 --> Config Class Initialized
INFO - 2017-02-22 15:03:00 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:03:00 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:03:00 --> Utf8 Class Initialized
INFO - 2017-02-22 15:03:00 --> URI Class Initialized
INFO - 2017-02-22 15:03:00 --> Router Class Initialized
INFO - 2017-02-22 15:03:00 --> Output Class Initialized
INFO - 2017-02-22 15:03:00 --> Security Class Initialized
DEBUG - 2017-02-22 15:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:03:00 --> Input Class Initialized
INFO - 2017-02-22 15:03:00 --> Language Class Initialized
INFO - 2017-02-22 15:03:00 --> Loader Class Initialized
INFO - 2017-02-22 15:03:00 --> Helper loaded: url_helper
INFO - 2017-02-22 15:03:00 --> Helper loaded: language_helper
INFO - 2017-02-22 15:03:00 --> Helper loaded: html_helper
INFO - 2017-02-22 15:03:00 --> Helper loaded: form_helper
INFO - 2017-02-22 15:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:03:00 --> Controller Class Initialized
INFO - 2017-02-22 15:03:00 --> Database Driver Class Initialized
INFO - 2017-02-22 15:03:00 --> Model Class Initialized
INFO - 2017-02-22 15:03:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:03:00 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:03:00 --> Pagination Class Initialized
INFO - 2017-02-22 15:03:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:03:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:03:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:03:00 --> Final output sent to browser
DEBUG - 2017-02-22 15:03:00 --> Total execution time: 0.1623
INFO - 2017-02-22 15:03:23 --> Config Class Initialized
INFO - 2017-02-22 15:03:23 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:03:23 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:03:23 --> Utf8 Class Initialized
INFO - 2017-02-22 15:03:23 --> URI Class Initialized
INFO - 2017-02-22 15:03:23 --> Router Class Initialized
INFO - 2017-02-22 15:03:23 --> Output Class Initialized
INFO - 2017-02-22 15:03:23 --> Security Class Initialized
DEBUG - 2017-02-22 15:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:03:23 --> Input Class Initialized
INFO - 2017-02-22 15:03:23 --> Language Class Initialized
INFO - 2017-02-22 15:03:23 --> Loader Class Initialized
INFO - 2017-02-22 15:03:23 --> Helper loaded: url_helper
INFO - 2017-02-22 15:03:23 --> Helper loaded: language_helper
INFO - 2017-02-22 15:03:23 --> Helper loaded: html_helper
INFO - 2017-02-22 15:03:23 --> Helper loaded: form_helper
INFO - 2017-02-22 15:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:03:23 --> Controller Class Initialized
INFO - 2017-02-22 15:03:23 --> Database Driver Class Initialized
INFO - 2017-02-22 15:03:23 --> Model Class Initialized
INFO - 2017-02-22 15:03:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:03:23 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:03:23 --> Pagination Class Initialized
INFO - 2017-02-22 15:03:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:03:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:03:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:03:23 --> Final output sent to browser
DEBUG - 2017-02-22 15:03:23 --> Total execution time: 0.1695
INFO - 2017-02-22 15:03:50 --> Config Class Initialized
INFO - 2017-02-22 15:03:50 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:03:50 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:03:50 --> Utf8 Class Initialized
INFO - 2017-02-22 15:03:50 --> URI Class Initialized
INFO - 2017-02-22 15:03:50 --> Router Class Initialized
INFO - 2017-02-22 15:03:50 --> Output Class Initialized
INFO - 2017-02-22 15:03:50 --> Security Class Initialized
DEBUG - 2017-02-22 15:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:03:50 --> Input Class Initialized
INFO - 2017-02-22 15:03:50 --> Language Class Initialized
INFO - 2017-02-22 15:03:50 --> Loader Class Initialized
INFO - 2017-02-22 15:03:50 --> Helper loaded: url_helper
INFO - 2017-02-22 15:03:50 --> Helper loaded: language_helper
INFO - 2017-02-22 15:03:50 --> Helper loaded: html_helper
INFO - 2017-02-22 15:03:50 --> Helper loaded: form_helper
INFO - 2017-02-22 15:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:03:50 --> Controller Class Initialized
INFO - 2017-02-22 15:03:50 --> Database Driver Class Initialized
INFO - 2017-02-22 15:03:50 --> Model Class Initialized
INFO - 2017-02-22 15:03:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:03:50 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:03:50 --> Pagination Class Initialized
INFO - 2017-02-22 15:03:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:03:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:03:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:03:50 --> Final output sent to browser
DEBUG - 2017-02-22 15:03:50 --> Total execution time: 0.1940
INFO - 2017-02-22 15:17:45 --> Config Class Initialized
INFO - 2017-02-22 15:17:45 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:17:45 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:17:45 --> Utf8 Class Initialized
INFO - 2017-02-22 15:17:45 --> URI Class Initialized
INFO - 2017-02-22 15:17:45 --> Router Class Initialized
INFO - 2017-02-22 15:17:45 --> Output Class Initialized
INFO - 2017-02-22 15:17:45 --> Security Class Initialized
DEBUG - 2017-02-22 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:17:45 --> Input Class Initialized
INFO - 2017-02-22 15:17:45 --> Language Class Initialized
INFO - 2017-02-22 15:17:45 --> Loader Class Initialized
INFO - 2017-02-22 15:17:45 --> Helper loaded: url_helper
INFO - 2017-02-22 15:17:45 --> Helper loaded: language_helper
INFO - 2017-02-22 15:17:45 --> Helper loaded: html_helper
INFO - 2017-02-22 15:17:45 --> Helper loaded: form_helper
INFO - 2017-02-22 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:17:45 --> Controller Class Initialized
INFO - 2017-02-22 15:17:45 --> Database Driver Class Initialized
INFO - 2017-02-22 15:17:45 --> Model Class Initialized
INFO - 2017-02-22 15:17:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:17:45 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:17:45 --> Pagination Class Initialized
INFO - 2017-02-22 15:17:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-22 15:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 36
INFO - 2017-02-22 15:17:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:17:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:17:45 --> Final output sent to browser
DEBUG - 2017-02-22 15:17:45 --> Total execution time: 0.1841
INFO - 2017-02-22 15:18:40 --> Config Class Initialized
INFO - 2017-02-22 15:18:40 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:18:40 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:18:40 --> Utf8 Class Initialized
INFO - 2017-02-22 15:18:40 --> URI Class Initialized
INFO - 2017-02-22 15:18:40 --> Router Class Initialized
INFO - 2017-02-22 15:18:40 --> Output Class Initialized
INFO - 2017-02-22 15:18:40 --> Security Class Initialized
DEBUG - 2017-02-22 15:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:18:40 --> Input Class Initialized
INFO - 2017-02-22 15:18:40 --> Language Class Initialized
INFO - 2017-02-22 15:18:40 --> Loader Class Initialized
INFO - 2017-02-22 15:18:40 --> Helper loaded: url_helper
INFO - 2017-02-22 15:18:40 --> Helper loaded: language_helper
INFO - 2017-02-22 15:18:40 --> Helper loaded: html_helper
INFO - 2017-02-22 15:18:40 --> Helper loaded: form_helper
INFO - 2017-02-22 15:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:18:40 --> Controller Class Initialized
INFO - 2017-02-22 15:18:40 --> Database Driver Class Initialized
INFO - 2017-02-22 15:18:40 --> Model Class Initialized
INFO - 2017-02-22 15:18:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:18:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:18:40 --> Pagination Class Initialized
INFO - 2017-02-22 15:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-22 15:18:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 36
INFO - 2017-02-22 15:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:18:40 --> Final output sent to browser
DEBUG - 2017-02-22 15:18:40 --> Total execution time: 0.2008
INFO - 2017-02-22 15:18:51 --> Config Class Initialized
INFO - 2017-02-22 15:18:51 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:18:51 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:18:51 --> Utf8 Class Initialized
INFO - 2017-02-22 15:18:51 --> URI Class Initialized
INFO - 2017-02-22 15:18:51 --> Router Class Initialized
INFO - 2017-02-22 15:18:51 --> Output Class Initialized
INFO - 2017-02-22 15:18:51 --> Security Class Initialized
DEBUG - 2017-02-22 15:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:18:51 --> Input Class Initialized
INFO - 2017-02-22 15:18:51 --> Language Class Initialized
INFO - 2017-02-22 15:18:51 --> Loader Class Initialized
INFO - 2017-02-22 15:18:51 --> Helper loaded: url_helper
INFO - 2017-02-22 15:18:51 --> Helper loaded: language_helper
INFO - 2017-02-22 15:18:51 --> Helper loaded: html_helper
INFO - 2017-02-22 15:18:51 --> Helper loaded: form_helper
INFO - 2017-02-22 15:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:18:51 --> Controller Class Initialized
INFO - 2017-02-22 15:18:51 --> Database Driver Class Initialized
INFO - 2017-02-22 15:18:51 --> Model Class Initialized
INFO - 2017-02-22 15:18:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:18:51 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:18:51 --> Pagination Class Initialized
INFO - 2017-02-22 15:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-22 15:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 36
INFO - 2017-02-22 15:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:18:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:18:51 --> Final output sent to browser
DEBUG - 2017-02-22 15:18:51 --> Total execution time: 0.1757
INFO - 2017-02-22 15:19:42 --> Config Class Initialized
INFO - 2017-02-22 15:19:42 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:19:42 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:19:42 --> Utf8 Class Initialized
INFO - 2017-02-22 15:19:42 --> URI Class Initialized
INFO - 2017-02-22 15:19:42 --> Router Class Initialized
INFO - 2017-02-22 15:19:42 --> Output Class Initialized
INFO - 2017-02-22 15:19:42 --> Security Class Initialized
DEBUG - 2017-02-22 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:19:42 --> Input Class Initialized
INFO - 2017-02-22 15:19:42 --> Language Class Initialized
INFO - 2017-02-22 15:19:42 --> Loader Class Initialized
INFO - 2017-02-22 15:19:42 --> Helper loaded: url_helper
INFO - 2017-02-22 15:19:42 --> Helper loaded: language_helper
INFO - 2017-02-22 15:19:42 --> Helper loaded: html_helper
INFO - 2017-02-22 15:19:42 --> Helper loaded: form_helper
INFO - 2017-02-22 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:19:42 --> Controller Class Initialized
INFO - 2017-02-22 15:19:42 --> Database Driver Class Initialized
INFO - 2017-02-22 15:19:42 --> Model Class Initialized
INFO - 2017-02-22 15:19:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:19:42 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:19:42 --> Pagination Class Initialized
INFO - 2017-02-22 15:19:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-22 15:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 36
INFO - 2017-02-22 15:19:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:19:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:19:42 --> Final output sent to browser
DEBUG - 2017-02-22 15:19:42 --> Total execution time: 0.1808
INFO - 2017-02-22 15:20:21 --> Config Class Initialized
INFO - 2017-02-22 15:20:21 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:20:21 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:20:21 --> Utf8 Class Initialized
INFO - 2017-02-22 15:20:21 --> URI Class Initialized
INFO - 2017-02-22 15:20:21 --> Router Class Initialized
INFO - 2017-02-22 15:20:21 --> Output Class Initialized
INFO - 2017-02-22 15:20:21 --> Security Class Initialized
DEBUG - 2017-02-22 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:20:21 --> Input Class Initialized
INFO - 2017-02-22 15:20:21 --> Language Class Initialized
INFO - 2017-02-22 15:20:21 --> Loader Class Initialized
INFO - 2017-02-22 15:20:21 --> Helper loaded: url_helper
INFO - 2017-02-22 15:20:21 --> Helper loaded: language_helper
INFO - 2017-02-22 15:20:21 --> Helper loaded: html_helper
INFO - 2017-02-22 15:20:21 --> Helper loaded: form_helper
INFO - 2017-02-22 15:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:20:21 --> Controller Class Initialized
INFO - 2017-02-22 15:20:21 --> Database Driver Class Initialized
INFO - 2017-02-22 15:20:21 --> Model Class Initialized
INFO - 2017-02-22 15:20:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:20:22 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:20:22 --> Pagination Class Initialized
INFO - 2017-02-22 15:20:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-22 15:20:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php 36
INFO - 2017-02-22 15:20:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:20:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:20:22 --> Final output sent to browser
DEBUG - 2017-02-22 15:20:22 --> Total execution time: 0.1589
INFO - 2017-02-22 15:20:43 --> Config Class Initialized
INFO - 2017-02-22 15:20:43 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:20:43 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:20:43 --> Utf8 Class Initialized
INFO - 2017-02-22 15:20:43 --> URI Class Initialized
INFO - 2017-02-22 15:20:43 --> Router Class Initialized
INFO - 2017-02-22 15:20:43 --> Output Class Initialized
INFO - 2017-02-22 15:20:43 --> Security Class Initialized
DEBUG - 2017-02-22 15:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:20:43 --> Input Class Initialized
INFO - 2017-02-22 15:20:43 --> Language Class Initialized
INFO - 2017-02-22 15:20:43 --> Loader Class Initialized
INFO - 2017-02-22 15:20:43 --> Helper loaded: url_helper
INFO - 2017-02-22 15:20:43 --> Helper loaded: language_helper
INFO - 2017-02-22 15:20:43 --> Helper loaded: html_helper
INFO - 2017-02-22 15:20:43 --> Helper loaded: form_helper
INFO - 2017-02-22 15:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:20:43 --> Controller Class Initialized
INFO - 2017-02-22 15:20:43 --> Database Driver Class Initialized
INFO - 2017-02-22 15:20:43 --> Model Class Initialized
INFO - 2017-02-22 15:20:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:20:43 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:20:43 --> Pagination Class Initialized
INFO - 2017-02-22 15:20:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:20:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:20:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:20:43 --> Final output sent to browser
DEBUG - 2017-02-22 15:20:43 --> Total execution time: 0.1692
INFO - 2017-02-22 15:21:09 --> Config Class Initialized
INFO - 2017-02-22 15:21:09 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:21:09 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:21:09 --> Utf8 Class Initialized
INFO - 2017-02-22 15:21:09 --> URI Class Initialized
INFO - 2017-02-22 15:21:09 --> Router Class Initialized
INFO - 2017-02-22 15:21:09 --> Output Class Initialized
INFO - 2017-02-22 15:21:09 --> Security Class Initialized
DEBUG - 2017-02-22 15:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:21:09 --> Input Class Initialized
INFO - 2017-02-22 15:21:09 --> Language Class Initialized
INFO - 2017-02-22 15:21:09 --> Loader Class Initialized
INFO - 2017-02-22 15:21:09 --> Helper loaded: url_helper
INFO - 2017-02-22 15:21:09 --> Helper loaded: language_helper
INFO - 2017-02-22 15:21:09 --> Helper loaded: html_helper
INFO - 2017-02-22 15:21:09 --> Helper loaded: form_helper
INFO - 2017-02-22 15:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:21:09 --> Controller Class Initialized
INFO - 2017-02-22 15:21:09 --> Database Driver Class Initialized
INFO - 2017-02-22 15:21:09 --> Model Class Initialized
INFO - 2017-02-22 15:21:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:21:09 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:21:09 --> Pagination Class Initialized
INFO - 2017-02-22 15:21:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:21:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:21:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:21:09 --> Final output sent to browser
DEBUG - 2017-02-22 15:21:09 --> Total execution time: 0.1657
INFO - 2017-02-22 15:21:22 --> Config Class Initialized
INFO - 2017-02-22 15:21:22 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:21:22 --> Utf8 Class Initialized
INFO - 2017-02-22 15:21:22 --> URI Class Initialized
INFO - 2017-02-22 15:21:22 --> Router Class Initialized
INFO - 2017-02-22 15:21:22 --> Output Class Initialized
INFO - 2017-02-22 15:21:22 --> Security Class Initialized
DEBUG - 2017-02-22 15:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:21:22 --> Input Class Initialized
INFO - 2017-02-22 15:21:22 --> Language Class Initialized
INFO - 2017-02-22 15:21:22 --> Loader Class Initialized
INFO - 2017-02-22 15:21:22 --> Helper loaded: url_helper
INFO - 2017-02-22 15:21:22 --> Helper loaded: language_helper
INFO - 2017-02-22 15:21:22 --> Helper loaded: html_helper
INFO - 2017-02-22 15:21:22 --> Helper loaded: form_helper
INFO - 2017-02-22 15:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:21:22 --> Controller Class Initialized
INFO - 2017-02-22 15:21:22 --> Database Driver Class Initialized
INFO - 2017-02-22 15:21:22 --> Model Class Initialized
INFO - 2017-02-22 15:21:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:21:22 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:21:22 --> Pagination Class Initialized
INFO - 2017-02-22 15:21:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:21:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:21:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:21:22 --> Final output sent to browser
DEBUG - 2017-02-22 15:21:22 --> Total execution time: 0.1422
INFO - 2017-02-22 15:21:32 --> Config Class Initialized
INFO - 2017-02-22 15:21:32 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:21:32 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:21:32 --> Utf8 Class Initialized
INFO - 2017-02-22 15:21:32 --> URI Class Initialized
INFO - 2017-02-22 15:21:32 --> Router Class Initialized
INFO - 2017-02-22 15:21:32 --> Output Class Initialized
INFO - 2017-02-22 15:21:32 --> Security Class Initialized
DEBUG - 2017-02-22 15:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:21:32 --> Input Class Initialized
INFO - 2017-02-22 15:21:32 --> Language Class Initialized
INFO - 2017-02-22 15:21:32 --> Loader Class Initialized
INFO - 2017-02-22 15:21:32 --> Helper loaded: url_helper
INFO - 2017-02-22 15:21:32 --> Helper loaded: language_helper
INFO - 2017-02-22 15:21:32 --> Helper loaded: html_helper
INFO - 2017-02-22 15:21:32 --> Helper loaded: form_helper
INFO - 2017-02-22 15:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:21:32 --> Controller Class Initialized
INFO - 2017-02-22 15:21:32 --> Database Driver Class Initialized
INFO - 2017-02-22 15:21:32 --> Model Class Initialized
INFO - 2017-02-22 15:21:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:21:32 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:21:32 --> Pagination Class Initialized
INFO - 2017-02-22 15:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:21:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:21:32 --> Final output sent to browser
DEBUG - 2017-02-22 15:21:32 --> Total execution time: 0.1568
INFO - 2017-02-22 15:23:59 --> Config Class Initialized
INFO - 2017-02-22 15:23:59 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:23:59 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:23:59 --> Utf8 Class Initialized
INFO - 2017-02-22 15:23:59 --> URI Class Initialized
INFO - 2017-02-22 15:23:59 --> Router Class Initialized
INFO - 2017-02-22 15:23:59 --> Output Class Initialized
INFO - 2017-02-22 15:23:59 --> Security Class Initialized
DEBUG - 2017-02-22 15:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:23:59 --> Input Class Initialized
INFO - 2017-02-22 15:23:59 --> Language Class Initialized
INFO - 2017-02-22 15:23:59 --> Loader Class Initialized
INFO - 2017-02-22 15:23:59 --> Helper loaded: url_helper
INFO - 2017-02-22 15:23:59 --> Helper loaded: language_helper
INFO - 2017-02-22 15:23:59 --> Helper loaded: html_helper
INFO - 2017-02-22 15:23:59 --> Helper loaded: form_helper
INFO - 2017-02-22 15:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:23:59 --> Controller Class Initialized
INFO - 2017-02-22 15:23:59 --> Database Driver Class Initialized
INFO - 2017-02-22 15:23:59 --> Model Class Initialized
INFO - 2017-02-22 15:23:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:23:59 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:23:59 --> Pagination Class Initialized
INFO - 2017-02-22 15:23:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:23:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:23:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:23:59 --> Final output sent to browser
DEBUG - 2017-02-22 15:23:59 --> Total execution time: 0.1354
INFO - 2017-02-22 15:26:03 --> Config Class Initialized
INFO - 2017-02-22 15:26:03 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:26:03 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:26:03 --> Utf8 Class Initialized
INFO - 2017-02-22 15:26:03 --> URI Class Initialized
INFO - 2017-02-22 15:26:03 --> Router Class Initialized
INFO - 2017-02-22 15:26:03 --> Output Class Initialized
INFO - 2017-02-22 15:26:03 --> Security Class Initialized
DEBUG - 2017-02-22 15:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:26:03 --> Input Class Initialized
INFO - 2017-02-22 15:26:03 --> Language Class Initialized
INFO - 2017-02-22 15:26:03 --> Loader Class Initialized
INFO - 2017-02-22 15:26:03 --> Helper loaded: url_helper
INFO - 2017-02-22 15:26:03 --> Helper loaded: language_helper
INFO - 2017-02-22 15:26:03 --> Helper loaded: html_helper
INFO - 2017-02-22 15:26:03 --> Helper loaded: form_helper
INFO - 2017-02-22 15:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:26:03 --> Controller Class Initialized
INFO - 2017-02-22 15:26:03 --> Database Driver Class Initialized
INFO - 2017-02-22 15:26:03 --> Model Class Initialized
INFO - 2017-02-22 15:26:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:26:03 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:26:03 --> Pagination Class Initialized
INFO - 2017-02-22 15:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:26:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:26:03 --> Final output sent to browser
DEBUG - 2017-02-22 15:26:03 --> Total execution time: 0.1864
INFO - 2017-02-22 15:26:08 --> Config Class Initialized
INFO - 2017-02-22 15:26:08 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:26:08 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:26:08 --> Utf8 Class Initialized
INFO - 2017-02-22 15:26:08 --> URI Class Initialized
INFO - 2017-02-22 15:26:08 --> Router Class Initialized
INFO - 2017-02-22 15:26:08 --> Output Class Initialized
INFO - 2017-02-22 15:26:08 --> Security Class Initialized
DEBUG - 2017-02-22 15:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:26:08 --> Input Class Initialized
INFO - 2017-02-22 15:26:08 --> Language Class Initialized
INFO - 2017-02-22 15:26:08 --> Loader Class Initialized
INFO - 2017-02-22 15:26:08 --> Helper loaded: url_helper
INFO - 2017-02-22 15:26:08 --> Helper loaded: language_helper
INFO - 2017-02-22 15:26:08 --> Helper loaded: html_helper
INFO - 2017-02-22 15:26:08 --> Helper loaded: form_helper
INFO - 2017-02-22 15:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:26:08 --> Controller Class Initialized
INFO - 2017-02-22 15:26:08 --> Database Driver Class Initialized
INFO - 2017-02-22 15:26:08 --> Model Class Initialized
INFO - 2017-02-22 15:26:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:26:08 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:26:08 --> Pagination Class Initialized
INFO - 2017-02-22 15:26:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:26:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:26:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:26:08 --> Final output sent to browser
DEBUG - 2017-02-22 15:26:08 --> Total execution time: 0.1362
INFO - 2017-02-22 15:26:16 --> Config Class Initialized
INFO - 2017-02-22 15:26:16 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:26:16 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:26:16 --> Utf8 Class Initialized
INFO - 2017-02-22 15:26:16 --> URI Class Initialized
INFO - 2017-02-22 15:26:16 --> Router Class Initialized
INFO - 2017-02-22 15:26:16 --> Output Class Initialized
INFO - 2017-02-22 15:26:16 --> Security Class Initialized
DEBUG - 2017-02-22 15:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:26:16 --> Input Class Initialized
INFO - 2017-02-22 15:26:16 --> Language Class Initialized
INFO - 2017-02-22 15:26:16 --> Loader Class Initialized
INFO - 2017-02-22 15:26:16 --> Helper loaded: url_helper
INFO - 2017-02-22 15:26:16 --> Helper loaded: language_helper
INFO - 2017-02-22 15:26:16 --> Helper loaded: html_helper
INFO - 2017-02-22 15:26:16 --> Helper loaded: form_helper
INFO - 2017-02-22 15:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:26:17 --> Controller Class Initialized
INFO - 2017-02-22 15:26:17 --> Database Driver Class Initialized
INFO - 2017-02-22 15:26:17 --> Model Class Initialized
INFO - 2017-02-22 15:26:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:26:17 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:26:17 --> Pagination Class Initialized
INFO - 2017-02-22 15:26:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:26:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:26:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:26:17 --> Final output sent to browser
DEBUG - 2017-02-22 15:26:17 --> Total execution time: 0.1473
INFO - 2017-02-22 15:26:20 --> Config Class Initialized
INFO - 2017-02-22 15:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:26:20 --> Utf8 Class Initialized
INFO - 2017-02-22 15:26:20 --> URI Class Initialized
INFO - 2017-02-22 15:26:20 --> Router Class Initialized
INFO - 2017-02-22 15:26:20 --> Output Class Initialized
INFO - 2017-02-22 15:26:20 --> Security Class Initialized
DEBUG - 2017-02-22 15:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:26:20 --> Input Class Initialized
INFO - 2017-02-22 15:26:20 --> Language Class Initialized
INFO - 2017-02-22 15:26:20 --> Loader Class Initialized
INFO - 2017-02-22 15:26:20 --> Helper loaded: url_helper
INFO - 2017-02-22 15:26:20 --> Helper loaded: language_helper
INFO - 2017-02-22 15:26:20 --> Helper loaded: html_helper
INFO - 2017-02-22 15:26:20 --> Helper loaded: form_helper
INFO - 2017-02-22 15:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:26:20 --> Controller Class Initialized
INFO - 2017-02-22 15:26:20 --> Database Driver Class Initialized
INFO - 2017-02-22 15:26:20 --> Model Class Initialized
INFO - 2017-02-22 15:26:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:26:20 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:26:20 --> Pagination Class Initialized
INFO - 2017-02-22 15:26:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:26:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:26:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:26:20 --> Final output sent to browser
DEBUG - 2017-02-22 15:26:20 --> Total execution time: 0.2012
INFO - 2017-02-22 15:26:30 --> Config Class Initialized
INFO - 2017-02-22 15:26:30 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:26:30 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:26:30 --> Utf8 Class Initialized
INFO - 2017-02-22 15:26:30 --> URI Class Initialized
INFO - 2017-02-22 15:26:30 --> Router Class Initialized
INFO - 2017-02-22 15:26:30 --> Output Class Initialized
INFO - 2017-02-22 15:26:30 --> Security Class Initialized
DEBUG - 2017-02-22 15:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:26:30 --> Input Class Initialized
INFO - 2017-02-22 15:26:30 --> Language Class Initialized
INFO - 2017-02-22 15:26:30 --> Loader Class Initialized
INFO - 2017-02-22 15:26:30 --> Helper loaded: url_helper
INFO - 2017-02-22 15:26:30 --> Helper loaded: language_helper
INFO - 2017-02-22 15:26:30 --> Helper loaded: html_helper
INFO - 2017-02-22 15:26:30 --> Helper loaded: form_helper
INFO - 2017-02-22 15:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:26:30 --> Controller Class Initialized
INFO - 2017-02-22 15:26:30 --> Database Driver Class Initialized
INFO - 2017-02-22 15:26:30 --> Model Class Initialized
INFO - 2017-02-22 15:26:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:26:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:26:30 --> Pagination Class Initialized
INFO - 2017-02-22 15:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:26:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:26:30 --> Final output sent to browser
DEBUG - 2017-02-22 15:26:30 --> Total execution time: 0.1172
INFO - 2017-02-22 15:26:34 --> Config Class Initialized
INFO - 2017-02-22 15:26:34 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:26:34 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:26:34 --> Utf8 Class Initialized
INFO - 2017-02-22 15:26:34 --> URI Class Initialized
INFO - 2017-02-22 15:26:34 --> Router Class Initialized
INFO - 2017-02-22 15:26:34 --> Output Class Initialized
INFO - 2017-02-22 15:26:34 --> Security Class Initialized
DEBUG - 2017-02-22 15:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:26:34 --> Input Class Initialized
INFO - 2017-02-22 15:26:34 --> Language Class Initialized
INFO - 2017-02-22 15:26:34 --> Loader Class Initialized
INFO - 2017-02-22 15:26:34 --> Helper loaded: url_helper
INFO - 2017-02-22 15:26:34 --> Helper loaded: language_helper
INFO - 2017-02-22 15:26:34 --> Helper loaded: html_helper
INFO - 2017-02-22 15:26:34 --> Helper loaded: form_helper
INFO - 2017-02-22 15:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:26:34 --> Controller Class Initialized
INFO - 2017-02-22 15:26:34 --> Database Driver Class Initialized
INFO - 2017-02-22 15:26:34 --> Model Class Initialized
INFO - 2017-02-22 15:26:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:26:34 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:26:34 --> Pagination Class Initialized
INFO - 2017-02-22 15:26:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:26:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:26:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:26:34 --> Final output sent to browser
DEBUG - 2017-02-22 15:26:34 --> Total execution time: 0.1312
INFO - 2017-02-22 15:26:49 --> Config Class Initialized
INFO - 2017-02-22 15:26:49 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:26:49 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:26:49 --> Utf8 Class Initialized
INFO - 2017-02-22 15:26:49 --> URI Class Initialized
INFO - 2017-02-22 15:26:49 --> Router Class Initialized
INFO - 2017-02-22 15:26:49 --> Output Class Initialized
INFO - 2017-02-22 15:26:49 --> Security Class Initialized
DEBUG - 2017-02-22 15:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:26:49 --> Input Class Initialized
INFO - 2017-02-22 15:26:49 --> Language Class Initialized
INFO - 2017-02-22 15:26:49 --> Loader Class Initialized
INFO - 2017-02-22 15:26:49 --> Helper loaded: url_helper
INFO - 2017-02-22 15:26:49 --> Helper loaded: language_helper
INFO - 2017-02-22 15:26:49 --> Helper loaded: html_helper
INFO - 2017-02-22 15:26:49 --> Helper loaded: form_helper
INFO - 2017-02-22 15:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:26:49 --> Controller Class Initialized
INFO - 2017-02-22 15:26:49 --> Database Driver Class Initialized
INFO - 2017-02-22 15:26:49 --> Model Class Initialized
INFO - 2017-02-22 15:26:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:26:49 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:26:49 --> Pagination Class Initialized
INFO - 2017-02-22 15:26:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:26:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:26:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:26:49 --> Final output sent to browser
DEBUG - 2017-02-22 15:26:49 --> Total execution time: 0.1605
INFO - 2017-02-22 15:26:55 --> Config Class Initialized
INFO - 2017-02-22 15:26:55 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:26:55 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:26:55 --> Utf8 Class Initialized
INFO - 2017-02-22 15:26:55 --> URI Class Initialized
INFO - 2017-02-22 15:26:55 --> Router Class Initialized
INFO - 2017-02-22 15:26:55 --> Output Class Initialized
INFO - 2017-02-22 15:26:55 --> Security Class Initialized
DEBUG - 2017-02-22 15:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:26:55 --> Input Class Initialized
INFO - 2017-02-22 15:26:55 --> Language Class Initialized
INFO - 2017-02-22 15:26:55 --> Loader Class Initialized
INFO - 2017-02-22 15:26:55 --> Helper loaded: url_helper
INFO - 2017-02-22 15:26:55 --> Helper loaded: language_helper
INFO - 2017-02-22 15:26:55 --> Helper loaded: html_helper
INFO - 2017-02-22 15:26:55 --> Helper loaded: form_helper
INFO - 2017-02-22 15:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:26:55 --> Controller Class Initialized
INFO - 2017-02-22 15:26:55 --> Database Driver Class Initialized
INFO - 2017-02-22 15:26:55 --> Model Class Initialized
INFO - 2017-02-22 15:26:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:26:55 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:26:55 --> Pagination Class Initialized
INFO - 2017-02-22 15:26:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:26:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:26:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:26:55 --> Final output sent to browser
DEBUG - 2017-02-22 15:26:55 --> Total execution time: 0.1443
INFO - 2017-02-22 15:27:02 --> Config Class Initialized
INFO - 2017-02-22 15:27:02 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:27:02 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:27:02 --> Utf8 Class Initialized
INFO - 2017-02-22 15:27:02 --> URI Class Initialized
INFO - 2017-02-22 15:27:02 --> Router Class Initialized
INFO - 2017-02-22 15:27:02 --> Output Class Initialized
INFO - 2017-02-22 15:27:02 --> Security Class Initialized
DEBUG - 2017-02-22 15:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:27:02 --> Input Class Initialized
INFO - 2017-02-22 15:27:02 --> Language Class Initialized
INFO - 2017-02-22 15:27:02 --> Loader Class Initialized
INFO - 2017-02-22 15:27:02 --> Helper loaded: url_helper
INFO - 2017-02-22 15:27:02 --> Helper loaded: language_helper
INFO - 2017-02-22 15:27:02 --> Helper loaded: html_helper
INFO - 2017-02-22 15:27:02 --> Helper loaded: form_helper
INFO - 2017-02-22 15:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:27:03 --> Controller Class Initialized
INFO - 2017-02-22 15:27:03 --> Database Driver Class Initialized
INFO - 2017-02-22 15:27:03 --> Model Class Initialized
INFO - 2017-02-22 15:27:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:27:03 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:27:03 --> Pagination Class Initialized
INFO - 2017-02-22 15:27:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:27:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:27:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:27:03 --> Final output sent to browser
DEBUG - 2017-02-22 15:27:03 --> Total execution time: 0.1200
INFO - 2017-02-22 15:27:08 --> Config Class Initialized
INFO - 2017-02-22 15:27:08 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:27:08 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:27:08 --> Utf8 Class Initialized
INFO - 2017-02-22 15:27:08 --> URI Class Initialized
INFO - 2017-02-22 15:27:08 --> Router Class Initialized
INFO - 2017-02-22 15:27:08 --> Output Class Initialized
INFO - 2017-02-22 15:27:08 --> Security Class Initialized
DEBUG - 2017-02-22 15:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:27:08 --> Input Class Initialized
INFO - 2017-02-22 15:27:08 --> Language Class Initialized
INFO - 2017-02-22 15:27:08 --> Loader Class Initialized
INFO - 2017-02-22 15:27:08 --> Helper loaded: url_helper
INFO - 2017-02-22 15:27:08 --> Helper loaded: language_helper
INFO - 2017-02-22 15:27:08 --> Helper loaded: html_helper
INFO - 2017-02-22 15:27:08 --> Helper loaded: form_helper
INFO - 2017-02-22 15:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:27:08 --> Controller Class Initialized
INFO - 2017-02-22 15:27:08 --> Database Driver Class Initialized
INFO - 2017-02-22 15:27:08 --> Model Class Initialized
INFO - 2017-02-22 15:27:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:27:08 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:27:08 --> Pagination Class Initialized
INFO - 2017-02-22 15:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:27:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:27:08 --> Final output sent to browser
DEBUG - 2017-02-22 15:27:08 --> Total execution time: 0.1254
INFO - 2017-02-22 15:27:12 --> Config Class Initialized
INFO - 2017-02-22 15:27:12 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:27:12 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:27:12 --> Utf8 Class Initialized
INFO - 2017-02-22 15:27:12 --> URI Class Initialized
INFO - 2017-02-22 15:27:12 --> Router Class Initialized
INFO - 2017-02-22 15:27:12 --> Output Class Initialized
INFO - 2017-02-22 15:27:12 --> Security Class Initialized
DEBUG - 2017-02-22 15:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:27:12 --> Input Class Initialized
INFO - 2017-02-22 15:27:12 --> Language Class Initialized
INFO - 2017-02-22 15:27:12 --> Loader Class Initialized
INFO - 2017-02-22 15:27:12 --> Helper loaded: url_helper
INFO - 2017-02-22 15:27:12 --> Helper loaded: language_helper
INFO - 2017-02-22 15:27:12 --> Helper loaded: html_helper
INFO - 2017-02-22 15:27:12 --> Helper loaded: form_helper
INFO - 2017-02-22 15:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:27:12 --> Controller Class Initialized
INFO - 2017-02-22 15:27:12 --> Database Driver Class Initialized
INFO - 2017-02-22 15:27:12 --> Model Class Initialized
INFO - 2017-02-22 15:27:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:27:12 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:27:12 --> Pagination Class Initialized
INFO - 2017-02-22 15:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:27:12 --> Final output sent to browser
DEBUG - 2017-02-22 15:27:12 --> Total execution time: 0.1481
INFO - 2017-02-22 15:27:13 --> Config Class Initialized
INFO - 2017-02-22 15:27:13 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:27:13 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:27:13 --> Utf8 Class Initialized
INFO - 2017-02-22 15:27:13 --> URI Class Initialized
INFO - 2017-02-22 15:27:13 --> Router Class Initialized
INFO - 2017-02-22 15:27:13 --> Output Class Initialized
INFO - 2017-02-22 15:27:13 --> Security Class Initialized
DEBUG - 2017-02-22 15:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:27:13 --> Input Class Initialized
INFO - 2017-02-22 15:27:13 --> Language Class Initialized
INFO - 2017-02-22 15:27:13 --> Loader Class Initialized
INFO - 2017-02-22 15:27:13 --> Helper loaded: url_helper
INFO - 2017-02-22 15:27:13 --> Helper loaded: language_helper
INFO - 2017-02-22 15:27:13 --> Helper loaded: html_helper
INFO - 2017-02-22 15:27:13 --> Helper loaded: form_helper
INFO - 2017-02-22 15:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:27:13 --> Controller Class Initialized
INFO - 2017-02-22 15:27:13 --> Database Driver Class Initialized
INFO - 2017-02-22 15:27:13 --> Model Class Initialized
INFO - 2017-02-22 15:27:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:27:13 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:27:13 --> Pagination Class Initialized
INFO - 2017-02-22 15:27:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:27:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:27:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:27:13 --> Final output sent to browser
DEBUG - 2017-02-22 15:27:13 --> Total execution time: 0.1665
INFO - 2017-02-22 15:27:15 --> Config Class Initialized
INFO - 2017-02-22 15:27:15 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:27:15 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:27:15 --> Utf8 Class Initialized
INFO - 2017-02-22 15:27:15 --> URI Class Initialized
INFO - 2017-02-22 15:27:15 --> Router Class Initialized
INFO - 2017-02-22 15:27:15 --> Output Class Initialized
INFO - 2017-02-22 15:27:15 --> Security Class Initialized
DEBUG - 2017-02-22 15:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:27:15 --> Input Class Initialized
INFO - 2017-02-22 15:27:15 --> Language Class Initialized
INFO - 2017-02-22 15:27:15 --> Loader Class Initialized
INFO - 2017-02-22 15:27:15 --> Helper loaded: url_helper
INFO - 2017-02-22 15:27:15 --> Helper loaded: language_helper
INFO - 2017-02-22 15:27:15 --> Helper loaded: html_helper
INFO - 2017-02-22 15:27:15 --> Helper loaded: form_helper
INFO - 2017-02-22 15:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:27:15 --> Controller Class Initialized
INFO - 2017-02-22 15:27:15 --> Database Driver Class Initialized
INFO - 2017-02-22 15:27:15 --> Model Class Initialized
INFO - 2017-02-22 15:27:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:27:15 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:27:15 --> Pagination Class Initialized
INFO - 2017-02-22 15:27:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:27:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:27:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:27:15 --> Final output sent to browser
DEBUG - 2017-02-22 15:27:15 --> Total execution time: 0.1581
INFO - 2017-02-22 15:27:17 --> Config Class Initialized
INFO - 2017-02-22 15:27:17 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:27:17 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:27:17 --> Utf8 Class Initialized
INFO - 2017-02-22 15:27:17 --> URI Class Initialized
INFO - 2017-02-22 15:27:17 --> Router Class Initialized
INFO - 2017-02-22 15:27:17 --> Output Class Initialized
INFO - 2017-02-22 15:27:17 --> Security Class Initialized
DEBUG - 2017-02-22 15:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:27:17 --> Input Class Initialized
INFO - 2017-02-22 15:27:17 --> Language Class Initialized
INFO - 2017-02-22 15:27:17 --> Loader Class Initialized
INFO - 2017-02-22 15:27:17 --> Helper loaded: url_helper
INFO - 2017-02-22 15:27:17 --> Helper loaded: language_helper
INFO - 2017-02-22 15:27:17 --> Helper loaded: html_helper
INFO - 2017-02-22 15:27:17 --> Helper loaded: form_helper
INFO - 2017-02-22 15:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:27:17 --> Controller Class Initialized
INFO - 2017-02-22 15:27:17 --> Database Driver Class Initialized
INFO - 2017-02-22 15:27:17 --> Model Class Initialized
INFO - 2017-02-22 15:27:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:27:17 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:27:17 --> Pagination Class Initialized
INFO - 2017-02-22 15:27:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:27:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:27:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:27:17 --> Final output sent to browser
DEBUG - 2017-02-22 15:27:17 --> Total execution time: 0.1944
INFO - 2017-02-22 15:29:36 --> Config Class Initialized
INFO - 2017-02-22 15:29:36 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:29:36 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:29:36 --> Utf8 Class Initialized
INFO - 2017-02-22 15:29:36 --> URI Class Initialized
INFO - 2017-02-22 15:29:36 --> Router Class Initialized
INFO - 2017-02-22 15:29:36 --> Output Class Initialized
INFO - 2017-02-22 15:29:36 --> Security Class Initialized
DEBUG - 2017-02-22 15:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:29:36 --> Input Class Initialized
INFO - 2017-02-22 15:29:36 --> Language Class Initialized
INFO - 2017-02-22 15:29:36 --> Loader Class Initialized
INFO - 2017-02-22 15:29:36 --> Helper loaded: url_helper
INFO - 2017-02-22 15:29:36 --> Helper loaded: language_helper
INFO - 2017-02-22 15:29:36 --> Helper loaded: html_helper
INFO - 2017-02-22 15:29:36 --> Helper loaded: form_helper
INFO - 2017-02-22 15:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:29:36 --> Controller Class Initialized
INFO - 2017-02-22 15:29:36 --> Database Driver Class Initialized
INFO - 2017-02-22 15:29:36 --> Model Class Initialized
INFO - 2017-02-22 15:29:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:29:36 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:29:36 --> Pagination Class Initialized
INFO - 2017-02-22 15:29:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:29:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:29:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:29:36 --> Final output sent to browser
DEBUG - 2017-02-22 15:29:36 --> Total execution time: 0.1705
INFO - 2017-02-22 15:29:40 --> Config Class Initialized
INFO - 2017-02-22 15:29:40 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:29:40 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:29:40 --> Utf8 Class Initialized
INFO - 2017-02-22 15:29:40 --> URI Class Initialized
INFO - 2017-02-22 15:29:40 --> Router Class Initialized
INFO - 2017-02-22 15:29:40 --> Output Class Initialized
INFO - 2017-02-22 15:29:40 --> Security Class Initialized
DEBUG - 2017-02-22 15:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:29:40 --> Input Class Initialized
INFO - 2017-02-22 15:29:40 --> Language Class Initialized
INFO - 2017-02-22 15:29:40 --> Loader Class Initialized
INFO - 2017-02-22 15:29:40 --> Helper loaded: url_helper
INFO - 2017-02-22 15:29:40 --> Helper loaded: language_helper
INFO - 2017-02-22 15:29:40 --> Helper loaded: html_helper
INFO - 2017-02-22 15:29:40 --> Helper loaded: form_helper
INFO - 2017-02-22 15:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:29:40 --> Controller Class Initialized
INFO - 2017-02-22 15:29:40 --> Database Driver Class Initialized
INFO - 2017-02-22 15:29:40 --> Model Class Initialized
INFO - 2017-02-22 15:29:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:29:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:29:40 --> Pagination Class Initialized
INFO - 2017-02-22 15:29:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:29:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:29:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:29:40 --> Final output sent to browser
DEBUG - 2017-02-22 15:29:40 --> Total execution time: 0.1224
INFO - 2017-02-22 15:30:04 --> Config Class Initialized
INFO - 2017-02-22 15:30:04 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:30:04 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:30:04 --> Utf8 Class Initialized
INFO - 2017-02-22 15:30:04 --> URI Class Initialized
INFO - 2017-02-22 15:30:04 --> Router Class Initialized
INFO - 2017-02-22 15:30:04 --> Output Class Initialized
INFO - 2017-02-22 15:30:05 --> Security Class Initialized
DEBUG - 2017-02-22 15:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:30:05 --> Input Class Initialized
INFO - 2017-02-22 15:30:05 --> Language Class Initialized
INFO - 2017-02-22 15:30:05 --> Loader Class Initialized
INFO - 2017-02-22 15:30:05 --> Helper loaded: url_helper
INFO - 2017-02-22 15:30:05 --> Helper loaded: language_helper
INFO - 2017-02-22 15:30:05 --> Helper loaded: html_helper
INFO - 2017-02-22 15:30:05 --> Helper loaded: form_helper
INFO - 2017-02-22 15:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:30:05 --> Controller Class Initialized
INFO - 2017-02-22 15:30:05 --> Database Driver Class Initialized
INFO - 2017-02-22 15:30:05 --> Model Class Initialized
INFO - 2017-02-22 15:30:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:30:05 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:30:05 --> Pagination Class Initialized
INFO - 2017-02-22 15:30:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:30:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:30:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:30:05 --> Final output sent to browser
DEBUG - 2017-02-22 15:30:05 --> Total execution time: 0.1831
INFO - 2017-02-22 15:30:07 --> Config Class Initialized
INFO - 2017-02-22 15:30:07 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:30:07 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:30:07 --> Utf8 Class Initialized
INFO - 2017-02-22 15:30:07 --> URI Class Initialized
INFO - 2017-02-22 15:30:07 --> Router Class Initialized
INFO - 2017-02-22 15:30:07 --> Output Class Initialized
INFO - 2017-02-22 15:30:07 --> Security Class Initialized
DEBUG - 2017-02-22 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:30:07 --> Input Class Initialized
INFO - 2017-02-22 15:30:07 --> Language Class Initialized
INFO - 2017-02-22 15:30:07 --> Loader Class Initialized
INFO - 2017-02-22 15:30:07 --> Helper loaded: url_helper
INFO - 2017-02-22 15:30:07 --> Helper loaded: language_helper
INFO - 2017-02-22 15:30:07 --> Helper loaded: html_helper
INFO - 2017-02-22 15:30:07 --> Helper loaded: form_helper
INFO - 2017-02-22 15:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:30:07 --> Controller Class Initialized
INFO - 2017-02-22 15:30:07 --> Database Driver Class Initialized
INFO - 2017-02-22 15:30:07 --> Model Class Initialized
INFO - 2017-02-22 15:30:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:30:07 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:30:07 --> Pagination Class Initialized
INFO - 2017-02-22 15:30:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:30:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:30:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:30:07 --> Final output sent to browser
DEBUG - 2017-02-22 15:30:07 --> Total execution time: 0.1927
INFO - 2017-02-22 15:30:12 --> Config Class Initialized
INFO - 2017-02-22 15:30:12 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:30:12 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:30:12 --> Utf8 Class Initialized
INFO - 2017-02-22 15:30:12 --> URI Class Initialized
INFO - 2017-02-22 15:30:12 --> Router Class Initialized
INFO - 2017-02-22 15:30:12 --> Output Class Initialized
INFO - 2017-02-22 15:30:12 --> Security Class Initialized
DEBUG - 2017-02-22 15:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:30:12 --> Input Class Initialized
INFO - 2017-02-22 15:30:12 --> Language Class Initialized
INFO - 2017-02-22 15:30:12 --> Loader Class Initialized
INFO - 2017-02-22 15:30:12 --> Helper loaded: url_helper
INFO - 2017-02-22 15:30:12 --> Helper loaded: language_helper
INFO - 2017-02-22 15:30:12 --> Helper loaded: html_helper
INFO - 2017-02-22 15:30:12 --> Helper loaded: form_helper
INFO - 2017-02-22 15:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:30:12 --> Controller Class Initialized
INFO - 2017-02-22 15:30:12 --> Database Driver Class Initialized
INFO - 2017-02-22 15:30:12 --> Model Class Initialized
INFO - 2017-02-22 15:30:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:30:12 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:30:12 --> Pagination Class Initialized
INFO - 2017-02-22 15:30:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:30:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:30:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:30:12 --> Final output sent to browser
DEBUG - 2017-02-22 15:30:12 --> Total execution time: 0.1602
INFO - 2017-02-22 15:30:15 --> Config Class Initialized
INFO - 2017-02-22 15:30:15 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:30:15 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:30:15 --> Utf8 Class Initialized
INFO - 2017-02-22 15:30:15 --> URI Class Initialized
INFO - 2017-02-22 15:30:15 --> Router Class Initialized
INFO - 2017-02-22 15:30:15 --> Output Class Initialized
INFO - 2017-02-22 15:30:15 --> Security Class Initialized
DEBUG - 2017-02-22 15:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:30:15 --> Input Class Initialized
INFO - 2017-02-22 15:30:15 --> Language Class Initialized
INFO - 2017-02-22 15:30:15 --> Loader Class Initialized
INFO - 2017-02-22 15:30:15 --> Helper loaded: url_helper
INFO - 2017-02-22 15:30:15 --> Helper loaded: language_helper
INFO - 2017-02-22 15:30:15 --> Helper loaded: html_helper
INFO - 2017-02-22 15:30:15 --> Helper loaded: form_helper
INFO - 2017-02-22 15:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:30:15 --> Controller Class Initialized
INFO - 2017-02-22 15:30:15 --> Database Driver Class Initialized
INFO - 2017-02-22 15:30:15 --> Model Class Initialized
INFO - 2017-02-22 15:30:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:30:15 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:30:15 --> Pagination Class Initialized
INFO - 2017-02-22 15:30:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:30:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:30:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:30:15 --> Final output sent to browser
DEBUG - 2017-02-22 15:30:15 --> Total execution time: 0.1430
INFO - 2017-02-22 15:30:21 --> Config Class Initialized
INFO - 2017-02-22 15:30:21 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:30:21 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:30:21 --> Utf8 Class Initialized
INFO - 2017-02-22 15:30:21 --> URI Class Initialized
INFO - 2017-02-22 15:30:21 --> Router Class Initialized
INFO - 2017-02-22 15:30:21 --> Output Class Initialized
INFO - 2017-02-22 15:30:21 --> Security Class Initialized
DEBUG - 2017-02-22 15:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:30:21 --> Input Class Initialized
INFO - 2017-02-22 15:30:21 --> Language Class Initialized
INFO - 2017-02-22 15:30:21 --> Loader Class Initialized
INFO - 2017-02-22 15:30:21 --> Helper loaded: url_helper
INFO - 2017-02-22 15:30:21 --> Helper loaded: language_helper
INFO - 2017-02-22 15:30:21 --> Helper loaded: html_helper
INFO - 2017-02-22 15:30:21 --> Helper loaded: form_helper
INFO - 2017-02-22 15:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:30:21 --> Controller Class Initialized
INFO - 2017-02-22 15:30:21 --> Database Driver Class Initialized
INFO - 2017-02-22 15:30:21 --> Model Class Initialized
INFO - 2017-02-22 15:30:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:30:21 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:30:21 --> Pagination Class Initialized
INFO - 2017-02-22 15:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:30:21 --> Final output sent to browser
DEBUG - 2017-02-22 15:30:21 --> Total execution time: 0.1421
INFO - 2017-02-22 15:30:24 --> Config Class Initialized
INFO - 2017-02-22 15:30:24 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:30:24 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:30:24 --> Utf8 Class Initialized
INFO - 2017-02-22 15:30:24 --> URI Class Initialized
INFO - 2017-02-22 15:30:24 --> Router Class Initialized
INFO - 2017-02-22 15:30:24 --> Output Class Initialized
INFO - 2017-02-22 15:30:24 --> Security Class Initialized
DEBUG - 2017-02-22 15:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:30:24 --> Input Class Initialized
INFO - 2017-02-22 15:30:24 --> Language Class Initialized
INFO - 2017-02-22 15:30:24 --> Loader Class Initialized
INFO - 2017-02-22 15:30:24 --> Helper loaded: url_helper
INFO - 2017-02-22 15:30:24 --> Helper loaded: language_helper
INFO - 2017-02-22 15:30:24 --> Helper loaded: html_helper
INFO - 2017-02-22 15:30:24 --> Helper loaded: form_helper
INFO - 2017-02-22 15:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:30:24 --> Controller Class Initialized
INFO - 2017-02-22 15:30:24 --> Database Driver Class Initialized
INFO - 2017-02-22 15:30:24 --> Model Class Initialized
INFO - 2017-02-22 15:30:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:30:24 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:30:24 --> Pagination Class Initialized
INFO - 2017-02-22 15:30:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:30:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:30:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:30:24 --> Final output sent to browser
DEBUG - 2017-02-22 15:30:24 --> Total execution time: 0.1890
INFO - 2017-02-22 15:44:56 --> Config Class Initialized
INFO - 2017-02-22 15:44:56 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:44:56 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:44:56 --> Utf8 Class Initialized
INFO - 2017-02-22 15:44:56 --> URI Class Initialized
INFO - 2017-02-22 15:44:56 --> Router Class Initialized
INFO - 2017-02-22 15:44:56 --> Output Class Initialized
INFO - 2017-02-22 15:44:56 --> Security Class Initialized
DEBUG - 2017-02-22 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:44:56 --> Input Class Initialized
INFO - 2017-02-22 15:44:56 --> Language Class Initialized
INFO - 2017-02-22 15:44:56 --> Loader Class Initialized
INFO - 2017-02-22 15:44:56 --> Helper loaded: url_helper
INFO - 2017-02-22 15:44:56 --> Helper loaded: language_helper
INFO - 2017-02-22 15:44:56 --> Helper loaded: html_helper
INFO - 2017-02-22 15:44:56 --> Helper loaded: form_helper
INFO - 2017-02-22 15:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:44:56 --> Controller Class Initialized
INFO - 2017-02-22 15:44:56 --> Database Driver Class Initialized
INFO - 2017-02-22 15:44:56 --> Model Class Initialized
INFO - 2017-02-22 15:44:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:44:56 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:44:56 --> Pagination Class Initialized
INFO - 2017-02-22 15:44:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:44:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:44:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:44:56 --> Final output sent to browser
DEBUG - 2017-02-22 15:44:56 --> Total execution time: 0.1431
INFO - 2017-02-22 15:45:01 --> Config Class Initialized
INFO - 2017-02-22 15:45:01 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:45:01 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:45:01 --> Utf8 Class Initialized
INFO - 2017-02-22 15:45:01 --> URI Class Initialized
INFO - 2017-02-22 15:45:01 --> Router Class Initialized
INFO - 2017-02-22 15:45:01 --> Output Class Initialized
INFO - 2017-02-22 15:45:01 --> Security Class Initialized
DEBUG - 2017-02-22 15:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:45:01 --> Input Class Initialized
INFO - 2017-02-22 15:45:01 --> Language Class Initialized
INFO - 2017-02-22 15:45:01 --> Loader Class Initialized
INFO - 2017-02-22 15:45:01 --> Helper loaded: url_helper
INFO - 2017-02-22 15:45:01 --> Helper loaded: language_helper
INFO - 2017-02-22 15:45:01 --> Helper loaded: html_helper
INFO - 2017-02-22 15:45:01 --> Helper loaded: form_helper
INFO - 2017-02-22 15:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:45:01 --> Controller Class Initialized
INFO - 2017-02-22 15:45:01 --> Database Driver Class Initialized
INFO - 2017-02-22 15:45:01 --> Model Class Initialized
INFO - 2017-02-22 15:45:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:45:01 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:45:01 --> Pagination Class Initialized
INFO - 2017-02-22 15:45:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:45:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:45:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:45:01 --> Final output sent to browser
DEBUG - 2017-02-22 15:45:01 --> Total execution time: 0.1129
INFO - 2017-02-22 15:46:13 --> Config Class Initialized
INFO - 2017-02-22 15:46:13 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:46:13 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:46:13 --> Utf8 Class Initialized
INFO - 2017-02-22 15:46:13 --> URI Class Initialized
INFO - 2017-02-22 15:46:13 --> Router Class Initialized
INFO - 2017-02-22 15:46:13 --> Output Class Initialized
INFO - 2017-02-22 15:46:13 --> Security Class Initialized
DEBUG - 2017-02-22 15:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:46:13 --> Input Class Initialized
INFO - 2017-02-22 15:46:13 --> Language Class Initialized
INFO - 2017-02-22 15:46:13 --> Loader Class Initialized
INFO - 2017-02-22 15:46:13 --> Helper loaded: url_helper
INFO - 2017-02-22 15:46:13 --> Helper loaded: language_helper
INFO - 2017-02-22 15:46:13 --> Helper loaded: html_helper
INFO - 2017-02-22 15:46:13 --> Helper loaded: form_helper
INFO - 2017-02-22 15:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:46:13 --> Controller Class Initialized
INFO - 2017-02-22 15:46:13 --> Database Driver Class Initialized
INFO - 2017-02-22 15:46:13 --> Model Class Initialized
INFO - 2017-02-22 15:46:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:46:13 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:46:13 --> Pagination Class Initialized
INFO - 2017-02-22 15:46:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:46:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:46:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:46:13 --> Final output sent to browser
DEBUG - 2017-02-22 15:46:13 --> Total execution time: 0.1532
INFO - 2017-02-22 15:46:14 --> Config Class Initialized
INFO - 2017-02-22 15:46:14 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:46:14 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:46:14 --> Utf8 Class Initialized
INFO - 2017-02-22 15:46:14 --> URI Class Initialized
INFO - 2017-02-22 15:46:14 --> Router Class Initialized
INFO - 2017-02-22 15:46:14 --> Output Class Initialized
INFO - 2017-02-22 15:46:14 --> Security Class Initialized
DEBUG - 2017-02-22 15:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:46:14 --> Input Class Initialized
INFO - 2017-02-22 15:46:14 --> Language Class Initialized
INFO - 2017-02-22 15:46:14 --> Loader Class Initialized
INFO - 2017-02-22 15:46:14 --> Helper loaded: url_helper
INFO - 2017-02-22 15:46:14 --> Helper loaded: language_helper
INFO - 2017-02-22 15:46:14 --> Helper loaded: html_helper
INFO - 2017-02-22 15:46:14 --> Helper loaded: form_helper
INFO - 2017-02-22 15:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:46:14 --> Controller Class Initialized
INFO - 2017-02-22 15:46:14 --> Database Driver Class Initialized
INFO - 2017-02-22 15:46:14 --> Model Class Initialized
INFO - 2017-02-22 15:46:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:46:14 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:46:14 --> Pagination Class Initialized
INFO - 2017-02-22 15:46:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:46:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:46:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:46:14 --> Final output sent to browser
DEBUG - 2017-02-22 15:46:14 --> Total execution time: 0.1691
INFO - 2017-02-22 15:46:19 --> Config Class Initialized
INFO - 2017-02-22 15:46:19 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:46:19 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:46:19 --> Utf8 Class Initialized
INFO - 2017-02-22 15:46:19 --> URI Class Initialized
INFO - 2017-02-22 15:46:19 --> Router Class Initialized
INFO - 2017-02-22 15:46:19 --> Output Class Initialized
INFO - 2017-02-22 15:46:19 --> Security Class Initialized
DEBUG - 2017-02-22 15:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:46:19 --> Input Class Initialized
INFO - 2017-02-22 15:46:19 --> Language Class Initialized
INFO - 2017-02-22 15:46:19 --> Loader Class Initialized
INFO - 2017-02-22 15:46:19 --> Helper loaded: url_helper
INFO - 2017-02-22 15:46:19 --> Helper loaded: language_helper
INFO - 2017-02-22 15:46:19 --> Helper loaded: html_helper
INFO - 2017-02-22 15:46:19 --> Helper loaded: form_helper
INFO - 2017-02-22 15:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:46:19 --> Controller Class Initialized
INFO - 2017-02-22 15:46:19 --> Database Driver Class Initialized
INFO - 2017-02-22 15:46:19 --> Model Class Initialized
INFO - 2017-02-22 15:46:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:46:19 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:46:19 --> Pagination Class Initialized
INFO - 2017-02-22 15:46:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:46:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:46:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:46:19 --> Final output sent to browser
DEBUG - 2017-02-22 15:46:19 --> Total execution time: 0.1457
INFO - 2017-02-22 15:46:22 --> Config Class Initialized
INFO - 2017-02-22 15:46:22 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:46:22 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:46:22 --> Utf8 Class Initialized
INFO - 2017-02-22 15:46:22 --> URI Class Initialized
INFO - 2017-02-22 15:46:22 --> Router Class Initialized
INFO - 2017-02-22 15:46:22 --> Output Class Initialized
INFO - 2017-02-22 15:46:22 --> Security Class Initialized
DEBUG - 2017-02-22 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:46:22 --> Input Class Initialized
INFO - 2017-02-22 15:46:22 --> Language Class Initialized
INFO - 2017-02-22 15:46:22 --> Loader Class Initialized
INFO - 2017-02-22 15:46:22 --> Helper loaded: url_helper
INFO - 2017-02-22 15:46:22 --> Helper loaded: language_helper
INFO - 2017-02-22 15:46:22 --> Helper loaded: html_helper
INFO - 2017-02-22 15:46:22 --> Helper loaded: form_helper
INFO - 2017-02-22 15:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:46:22 --> Controller Class Initialized
INFO - 2017-02-22 15:46:22 --> Database Driver Class Initialized
INFO - 2017-02-22 15:46:22 --> Model Class Initialized
INFO - 2017-02-22 15:46:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:46:22 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:46:22 --> Pagination Class Initialized
INFO - 2017-02-22 15:46:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:46:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:46:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:46:22 --> Final output sent to browser
DEBUG - 2017-02-22 15:46:22 --> Total execution time: 0.1600
INFO - 2017-02-22 15:46:29 --> Config Class Initialized
INFO - 2017-02-22 15:46:29 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:46:29 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:46:29 --> Utf8 Class Initialized
INFO - 2017-02-22 15:46:29 --> URI Class Initialized
INFO - 2017-02-22 15:46:29 --> Router Class Initialized
INFO - 2017-02-22 15:46:29 --> Output Class Initialized
INFO - 2017-02-22 15:46:29 --> Security Class Initialized
DEBUG - 2017-02-22 15:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:46:29 --> Input Class Initialized
INFO - 2017-02-22 15:46:29 --> Language Class Initialized
INFO - 2017-02-22 15:46:29 --> Loader Class Initialized
INFO - 2017-02-22 15:46:29 --> Helper loaded: url_helper
INFO - 2017-02-22 15:46:29 --> Helper loaded: language_helper
INFO - 2017-02-22 15:46:29 --> Helper loaded: html_helper
INFO - 2017-02-22 15:46:29 --> Helper loaded: form_helper
INFO - 2017-02-22 15:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:46:29 --> Controller Class Initialized
INFO - 2017-02-22 15:46:29 --> Database Driver Class Initialized
INFO - 2017-02-22 15:46:29 --> Model Class Initialized
INFO - 2017-02-22 15:46:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:46:29 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:46:29 --> Pagination Class Initialized
INFO - 2017-02-22 15:46:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:46:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:46:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:46:29 --> Final output sent to browser
DEBUG - 2017-02-22 15:46:29 --> Total execution time: 0.1154
INFO - 2017-02-22 15:46:39 --> Config Class Initialized
INFO - 2017-02-22 15:46:39 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:46:39 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:46:39 --> Utf8 Class Initialized
INFO - 2017-02-22 15:46:39 --> URI Class Initialized
INFO - 2017-02-22 15:46:39 --> Router Class Initialized
INFO - 2017-02-22 15:46:39 --> Output Class Initialized
INFO - 2017-02-22 15:46:39 --> Security Class Initialized
DEBUG - 2017-02-22 15:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:46:39 --> Input Class Initialized
INFO - 2017-02-22 15:46:39 --> Language Class Initialized
INFO - 2017-02-22 15:46:40 --> Loader Class Initialized
INFO - 2017-02-22 15:46:40 --> Helper loaded: url_helper
INFO - 2017-02-22 15:46:40 --> Helper loaded: language_helper
INFO - 2017-02-22 15:46:40 --> Helper loaded: html_helper
INFO - 2017-02-22 15:46:40 --> Helper loaded: form_helper
INFO - 2017-02-22 15:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:46:40 --> Controller Class Initialized
INFO - 2017-02-22 15:46:40 --> Database Driver Class Initialized
INFO - 2017-02-22 15:46:40 --> Model Class Initialized
INFO - 2017-02-22 15:46:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:46:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:46:40 --> Pagination Class Initialized
INFO - 2017-02-22 15:46:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:46:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:46:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:46:40 --> Final output sent to browser
DEBUG - 2017-02-22 15:46:40 --> Total execution time: 0.1442
INFO - 2017-02-22 15:46:48 --> Config Class Initialized
INFO - 2017-02-22 15:46:48 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:46:48 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:46:48 --> Utf8 Class Initialized
INFO - 2017-02-22 15:46:48 --> URI Class Initialized
INFO - 2017-02-22 15:46:48 --> Router Class Initialized
INFO - 2017-02-22 15:46:48 --> Output Class Initialized
INFO - 2017-02-22 15:46:48 --> Security Class Initialized
DEBUG - 2017-02-22 15:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:46:48 --> Input Class Initialized
INFO - 2017-02-22 15:46:48 --> Language Class Initialized
INFO - 2017-02-22 15:46:48 --> Loader Class Initialized
INFO - 2017-02-22 15:46:48 --> Helper loaded: url_helper
INFO - 2017-02-22 15:46:48 --> Helper loaded: language_helper
INFO - 2017-02-22 15:46:48 --> Helper loaded: html_helper
INFO - 2017-02-22 15:46:48 --> Helper loaded: form_helper
INFO - 2017-02-22 15:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:46:48 --> Controller Class Initialized
INFO - 2017-02-22 15:46:48 --> Database Driver Class Initialized
INFO - 2017-02-22 15:46:48 --> Model Class Initialized
INFO - 2017-02-22 15:46:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:46:48 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:46:48 --> Pagination Class Initialized
INFO - 2017-02-22 15:46:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:46:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:46:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:46:48 --> Final output sent to browser
DEBUG - 2017-02-22 15:46:48 --> Total execution time: 0.1126
INFO - 2017-02-22 15:46:56 --> Config Class Initialized
INFO - 2017-02-22 15:46:56 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:46:56 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:46:56 --> Utf8 Class Initialized
INFO - 2017-02-22 15:46:56 --> URI Class Initialized
INFO - 2017-02-22 15:46:56 --> Router Class Initialized
INFO - 2017-02-22 15:46:56 --> Output Class Initialized
INFO - 2017-02-22 15:46:56 --> Security Class Initialized
DEBUG - 2017-02-22 15:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:46:56 --> Input Class Initialized
INFO - 2017-02-22 15:46:56 --> Language Class Initialized
INFO - 2017-02-22 15:46:56 --> Loader Class Initialized
INFO - 2017-02-22 15:46:56 --> Helper loaded: url_helper
INFO - 2017-02-22 15:46:56 --> Helper loaded: language_helper
INFO - 2017-02-22 15:46:56 --> Helper loaded: html_helper
INFO - 2017-02-22 15:46:56 --> Helper loaded: form_helper
INFO - 2017-02-22 15:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:46:56 --> Controller Class Initialized
INFO - 2017-02-22 15:46:56 --> Database Driver Class Initialized
INFO - 2017-02-22 15:46:56 --> Model Class Initialized
INFO - 2017-02-22 15:46:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:46:56 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:46:56 --> Pagination Class Initialized
INFO - 2017-02-22 15:46:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:46:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:46:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:46:56 --> Final output sent to browser
DEBUG - 2017-02-22 15:46:56 --> Total execution time: 0.1941
INFO - 2017-02-22 15:47:46 --> Config Class Initialized
INFO - 2017-02-22 15:47:46 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:47:46 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:47:46 --> Utf8 Class Initialized
INFO - 2017-02-22 15:47:46 --> URI Class Initialized
INFO - 2017-02-22 15:47:46 --> Router Class Initialized
INFO - 2017-02-22 15:47:46 --> Output Class Initialized
INFO - 2017-02-22 15:47:46 --> Security Class Initialized
DEBUG - 2017-02-22 15:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:47:46 --> Input Class Initialized
INFO - 2017-02-22 15:47:46 --> Language Class Initialized
INFO - 2017-02-22 15:47:46 --> Loader Class Initialized
INFO - 2017-02-22 15:47:46 --> Helper loaded: url_helper
INFO - 2017-02-22 15:47:46 --> Helper loaded: language_helper
INFO - 2017-02-22 15:47:46 --> Helper loaded: html_helper
INFO - 2017-02-22 15:47:46 --> Helper loaded: form_helper
INFO - 2017-02-22 15:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:47:46 --> Controller Class Initialized
INFO - 2017-02-22 15:47:46 --> Database Driver Class Initialized
INFO - 2017-02-22 15:47:46 --> Model Class Initialized
INFO - 2017-02-22 15:47:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:47:46 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:47:46 --> Pagination Class Initialized
INFO - 2017-02-22 15:47:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:47:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:47:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:47:46 --> Final output sent to browser
DEBUG - 2017-02-22 15:47:46 --> Total execution time: 0.1245
INFO - 2017-02-22 15:47:58 --> Config Class Initialized
INFO - 2017-02-22 15:47:58 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:47:58 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:47:58 --> Utf8 Class Initialized
INFO - 2017-02-22 15:47:58 --> URI Class Initialized
INFO - 2017-02-22 15:47:58 --> Router Class Initialized
INFO - 2017-02-22 15:47:58 --> Output Class Initialized
INFO - 2017-02-22 15:47:58 --> Security Class Initialized
DEBUG - 2017-02-22 15:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:47:58 --> Input Class Initialized
INFO - 2017-02-22 15:47:58 --> Language Class Initialized
INFO - 2017-02-22 15:47:58 --> Loader Class Initialized
INFO - 2017-02-22 15:47:58 --> Helper loaded: url_helper
INFO - 2017-02-22 15:47:58 --> Helper loaded: language_helper
INFO - 2017-02-22 15:47:58 --> Helper loaded: html_helper
INFO - 2017-02-22 15:47:58 --> Helper loaded: form_helper
INFO - 2017-02-22 15:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:47:58 --> Controller Class Initialized
INFO - 2017-02-22 15:47:58 --> Database Driver Class Initialized
INFO - 2017-02-22 15:47:58 --> Model Class Initialized
INFO - 2017-02-22 15:47:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:47:58 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:47:58 --> Pagination Class Initialized
INFO - 2017-02-22 15:47:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:47:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:47:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:47:58 --> Final output sent to browser
DEBUG - 2017-02-22 15:47:58 --> Total execution time: 0.1191
INFO - 2017-02-22 15:48:07 --> Config Class Initialized
INFO - 2017-02-22 15:48:07 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:48:07 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:48:07 --> Utf8 Class Initialized
INFO - 2017-02-22 15:48:07 --> URI Class Initialized
INFO - 2017-02-22 15:48:07 --> Router Class Initialized
INFO - 2017-02-22 15:48:07 --> Output Class Initialized
INFO - 2017-02-22 15:48:07 --> Security Class Initialized
DEBUG - 2017-02-22 15:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:48:07 --> Input Class Initialized
INFO - 2017-02-22 15:48:07 --> Language Class Initialized
INFO - 2017-02-22 15:48:07 --> Loader Class Initialized
INFO - 2017-02-22 15:48:07 --> Helper loaded: url_helper
INFO - 2017-02-22 15:48:07 --> Helper loaded: language_helper
INFO - 2017-02-22 15:48:07 --> Helper loaded: html_helper
INFO - 2017-02-22 15:48:07 --> Helper loaded: form_helper
INFO - 2017-02-22 15:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:48:07 --> Controller Class Initialized
INFO - 2017-02-22 15:48:07 --> Database Driver Class Initialized
INFO - 2017-02-22 15:48:07 --> Model Class Initialized
INFO - 2017-02-22 15:48:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:48:07 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:48:07 --> Pagination Class Initialized
INFO - 2017-02-22 15:48:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:48:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:48:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:48:07 --> Final output sent to browser
DEBUG - 2017-02-22 15:48:07 --> Total execution time: 0.1271
INFO - 2017-02-22 15:48:34 --> Config Class Initialized
INFO - 2017-02-22 15:48:34 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:48:34 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:48:34 --> Utf8 Class Initialized
INFO - 2017-02-22 15:48:34 --> URI Class Initialized
INFO - 2017-02-22 15:48:34 --> Router Class Initialized
INFO - 2017-02-22 15:48:34 --> Output Class Initialized
INFO - 2017-02-22 15:48:34 --> Security Class Initialized
DEBUG - 2017-02-22 15:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:48:34 --> Input Class Initialized
INFO - 2017-02-22 15:48:34 --> Language Class Initialized
INFO - 2017-02-22 15:48:34 --> Loader Class Initialized
INFO - 2017-02-22 15:48:34 --> Helper loaded: url_helper
INFO - 2017-02-22 15:48:34 --> Helper loaded: language_helper
INFO - 2017-02-22 15:48:34 --> Helper loaded: html_helper
INFO - 2017-02-22 15:48:34 --> Helper loaded: form_helper
INFO - 2017-02-22 15:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:48:34 --> Controller Class Initialized
INFO - 2017-02-22 15:48:34 --> Database Driver Class Initialized
INFO - 2017-02-22 15:48:34 --> Model Class Initialized
INFO - 2017-02-22 15:48:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:48:34 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:48:34 --> Pagination Class Initialized
INFO - 2017-02-22 15:48:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:48:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:48:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:48:34 --> Final output sent to browser
DEBUG - 2017-02-22 15:48:34 --> Total execution time: 0.1723
INFO - 2017-02-22 15:49:00 --> Config Class Initialized
INFO - 2017-02-22 15:49:00 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:49:00 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:49:00 --> Utf8 Class Initialized
INFO - 2017-02-22 15:49:00 --> URI Class Initialized
INFO - 2017-02-22 15:49:00 --> Router Class Initialized
INFO - 2017-02-22 15:49:00 --> Output Class Initialized
INFO - 2017-02-22 15:49:00 --> Security Class Initialized
DEBUG - 2017-02-22 15:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:49:00 --> Input Class Initialized
INFO - 2017-02-22 15:49:00 --> Language Class Initialized
INFO - 2017-02-22 15:49:00 --> Loader Class Initialized
INFO - 2017-02-22 15:49:00 --> Helper loaded: url_helper
INFO - 2017-02-22 15:49:00 --> Helper loaded: language_helper
INFO - 2017-02-22 15:49:00 --> Helper loaded: html_helper
INFO - 2017-02-22 15:49:00 --> Helper loaded: form_helper
INFO - 2017-02-22 15:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:49:01 --> Controller Class Initialized
INFO - 2017-02-22 15:49:01 --> Database Driver Class Initialized
INFO - 2017-02-22 15:49:01 --> Model Class Initialized
INFO - 2017-02-22 15:49:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:49:01 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:49:01 --> Pagination Class Initialized
INFO - 2017-02-22 15:49:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:49:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:49:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:49:01 --> Final output sent to browser
DEBUG - 2017-02-22 15:49:01 --> Total execution time: 0.1688
INFO - 2017-02-22 15:49:16 --> Config Class Initialized
INFO - 2017-02-22 15:49:16 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:49:16 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:49:16 --> Utf8 Class Initialized
INFO - 2017-02-22 15:49:16 --> URI Class Initialized
INFO - 2017-02-22 15:49:16 --> Router Class Initialized
INFO - 2017-02-22 15:49:16 --> Output Class Initialized
INFO - 2017-02-22 15:49:16 --> Security Class Initialized
DEBUG - 2017-02-22 15:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:49:16 --> Input Class Initialized
INFO - 2017-02-22 15:49:16 --> Language Class Initialized
INFO - 2017-02-22 15:49:16 --> Loader Class Initialized
INFO - 2017-02-22 15:49:16 --> Helper loaded: url_helper
INFO - 2017-02-22 15:49:16 --> Helper loaded: language_helper
INFO - 2017-02-22 15:49:16 --> Helper loaded: html_helper
INFO - 2017-02-22 15:49:16 --> Helper loaded: form_helper
INFO - 2017-02-22 15:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:49:16 --> Controller Class Initialized
INFO - 2017-02-22 15:49:16 --> Database Driver Class Initialized
INFO - 2017-02-22 15:49:16 --> Model Class Initialized
INFO - 2017-02-22 15:49:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:49:16 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:49:16 --> Pagination Class Initialized
INFO - 2017-02-22 15:49:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:49:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:49:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:49:16 --> Final output sent to browser
DEBUG - 2017-02-22 15:49:16 --> Total execution time: 0.1549
INFO - 2017-02-22 15:49:28 --> Config Class Initialized
INFO - 2017-02-22 15:49:28 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:49:28 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:49:28 --> Utf8 Class Initialized
INFO - 2017-02-22 15:49:28 --> URI Class Initialized
INFO - 2017-02-22 15:49:28 --> Router Class Initialized
INFO - 2017-02-22 15:49:28 --> Output Class Initialized
INFO - 2017-02-22 15:49:28 --> Security Class Initialized
DEBUG - 2017-02-22 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:49:28 --> Input Class Initialized
INFO - 2017-02-22 15:49:28 --> Language Class Initialized
INFO - 2017-02-22 15:49:28 --> Loader Class Initialized
INFO - 2017-02-22 15:49:28 --> Helper loaded: url_helper
INFO - 2017-02-22 15:49:28 --> Helper loaded: language_helper
INFO - 2017-02-22 15:49:28 --> Helper loaded: html_helper
INFO - 2017-02-22 15:49:28 --> Helper loaded: form_helper
INFO - 2017-02-22 15:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:49:28 --> Controller Class Initialized
INFO - 2017-02-22 15:49:28 --> Database Driver Class Initialized
INFO - 2017-02-22 15:49:28 --> Model Class Initialized
INFO - 2017-02-22 15:49:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:49:28 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:49:28 --> Pagination Class Initialized
INFO - 2017-02-22 15:49:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:49:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:49:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:49:28 --> Final output sent to browser
DEBUG - 2017-02-22 15:49:28 --> Total execution time: 0.1419
INFO - 2017-02-22 15:51:06 --> Config Class Initialized
INFO - 2017-02-22 15:51:06 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:51:06 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:51:06 --> Utf8 Class Initialized
INFO - 2017-02-22 15:51:06 --> URI Class Initialized
INFO - 2017-02-22 15:51:06 --> Router Class Initialized
INFO - 2017-02-22 15:51:06 --> Output Class Initialized
INFO - 2017-02-22 15:51:06 --> Security Class Initialized
DEBUG - 2017-02-22 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:51:06 --> Input Class Initialized
INFO - 2017-02-22 15:51:06 --> Language Class Initialized
INFO - 2017-02-22 15:51:06 --> Loader Class Initialized
INFO - 2017-02-22 15:51:06 --> Helper loaded: url_helper
INFO - 2017-02-22 15:51:06 --> Helper loaded: language_helper
INFO - 2017-02-22 15:51:06 --> Helper loaded: html_helper
INFO - 2017-02-22 15:51:06 --> Helper loaded: form_helper
INFO - 2017-02-22 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:51:06 --> Controller Class Initialized
INFO - 2017-02-22 15:51:06 --> Database Driver Class Initialized
INFO - 2017-02-22 15:51:06 --> Model Class Initialized
INFO - 2017-02-22 15:51:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:51:06 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:51:06 --> Pagination Class Initialized
INFO - 2017-02-22 15:51:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:51:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:51:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:51:06 --> Final output sent to browser
DEBUG - 2017-02-22 15:51:06 --> Total execution time: 0.1506
INFO - 2017-02-22 15:51:30 --> Config Class Initialized
INFO - 2017-02-22 15:51:30 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:51:30 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:51:30 --> Utf8 Class Initialized
INFO - 2017-02-22 15:51:30 --> URI Class Initialized
INFO - 2017-02-22 15:51:30 --> Router Class Initialized
INFO - 2017-02-22 15:51:30 --> Output Class Initialized
INFO - 2017-02-22 15:51:30 --> Security Class Initialized
DEBUG - 2017-02-22 15:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:51:30 --> Input Class Initialized
INFO - 2017-02-22 15:51:30 --> Language Class Initialized
INFO - 2017-02-22 15:51:30 --> Loader Class Initialized
INFO - 2017-02-22 15:51:30 --> Helper loaded: url_helper
INFO - 2017-02-22 15:51:30 --> Helper loaded: language_helper
INFO - 2017-02-22 15:51:30 --> Helper loaded: html_helper
INFO - 2017-02-22 15:51:30 --> Helper loaded: form_helper
INFO - 2017-02-22 15:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:51:30 --> Controller Class Initialized
INFO - 2017-02-22 15:51:30 --> Database Driver Class Initialized
INFO - 2017-02-22 15:51:30 --> Model Class Initialized
INFO - 2017-02-22 15:51:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:51:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:51:30 --> Pagination Class Initialized
INFO - 2017-02-22 15:51:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:51:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:51:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:51:30 --> Final output sent to browser
DEBUG - 2017-02-22 15:51:30 --> Total execution time: 0.1848
INFO - 2017-02-22 15:52:37 --> Config Class Initialized
INFO - 2017-02-22 15:52:37 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:52:37 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:52:37 --> Utf8 Class Initialized
INFO - 2017-02-22 15:52:37 --> URI Class Initialized
INFO - 2017-02-22 15:52:37 --> Router Class Initialized
INFO - 2017-02-22 15:52:37 --> Output Class Initialized
INFO - 2017-02-22 15:52:37 --> Security Class Initialized
DEBUG - 2017-02-22 15:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:52:37 --> Input Class Initialized
INFO - 2017-02-22 15:52:37 --> Language Class Initialized
INFO - 2017-02-22 15:52:37 --> Loader Class Initialized
INFO - 2017-02-22 15:52:37 --> Helper loaded: url_helper
INFO - 2017-02-22 15:52:37 --> Helper loaded: language_helper
INFO - 2017-02-22 15:52:37 --> Helper loaded: html_helper
INFO - 2017-02-22 15:52:37 --> Helper loaded: form_helper
INFO - 2017-02-22 15:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:52:37 --> Controller Class Initialized
INFO - 2017-02-22 15:52:37 --> Database Driver Class Initialized
INFO - 2017-02-22 15:52:37 --> Model Class Initialized
INFO - 2017-02-22 15:52:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:52:37 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:52:37 --> Pagination Class Initialized
INFO - 2017-02-22 15:52:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:52:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:52:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:52:37 --> Final output sent to browser
DEBUG - 2017-02-22 15:52:37 --> Total execution time: 0.1433
INFO - 2017-02-22 15:55:50 --> Config Class Initialized
INFO - 2017-02-22 15:55:50 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:55:50 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:55:50 --> Utf8 Class Initialized
INFO - 2017-02-22 15:55:50 --> URI Class Initialized
INFO - 2017-02-22 15:55:50 --> Router Class Initialized
INFO - 2017-02-22 15:55:50 --> Output Class Initialized
INFO - 2017-02-22 15:55:50 --> Security Class Initialized
DEBUG - 2017-02-22 15:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:55:50 --> Input Class Initialized
INFO - 2017-02-22 15:55:50 --> Language Class Initialized
INFO - 2017-02-22 15:55:50 --> Loader Class Initialized
INFO - 2017-02-22 15:55:50 --> Helper loaded: url_helper
INFO - 2017-02-22 15:55:50 --> Helper loaded: language_helper
INFO - 2017-02-22 15:55:50 --> Helper loaded: html_helper
INFO - 2017-02-22 15:55:50 --> Helper loaded: form_helper
INFO - 2017-02-22 15:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:55:50 --> Controller Class Initialized
INFO - 2017-02-22 15:55:50 --> Database Driver Class Initialized
INFO - 2017-02-22 15:55:50 --> Model Class Initialized
INFO - 2017-02-22 15:55:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:55:50 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:55:50 --> Pagination Class Initialized
INFO - 2017-02-22 15:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:55:50 --> Final output sent to browser
DEBUG - 2017-02-22 15:55:50 --> Total execution time: 0.2570
INFO - 2017-02-22 15:56:10 --> Config Class Initialized
INFO - 2017-02-22 15:56:10 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:56:10 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:56:10 --> Utf8 Class Initialized
INFO - 2017-02-22 15:56:10 --> URI Class Initialized
INFO - 2017-02-22 15:56:10 --> Router Class Initialized
INFO - 2017-02-22 15:56:10 --> Output Class Initialized
INFO - 2017-02-22 15:56:10 --> Security Class Initialized
DEBUG - 2017-02-22 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:56:10 --> Input Class Initialized
INFO - 2017-02-22 15:56:10 --> Language Class Initialized
INFO - 2017-02-22 15:56:10 --> Loader Class Initialized
INFO - 2017-02-22 15:56:10 --> Helper loaded: url_helper
INFO - 2017-02-22 15:56:10 --> Helper loaded: language_helper
INFO - 2017-02-22 15:56:10 --> Helper loaded: html_helper
INFO - 2017-02-22 15:56:10 --> Helper loaded: form_helper
INFO - 2017-02-22 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:56:10 --> Controller Class Initialized
INFO - 2017-02-22 15:56:10 --> Database Driver Class Initialized
INFO - 2017-02-22 15:56:10 --> Model Class Initialized
INFO - 2017-02-22 15:56:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:56:10 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:56:10 --> Pagination Class Initialized
INFO - 2017-02-22 15:56:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:56:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:56:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:56:10 --> Final output sent to browser
DEBUG - 2017-02-22 15:56:10 --> Total execution time: 0.1584
INFO - 2017-02-22 15:56:15 --> Config Class Initialized
INFO - 2017-02-22 15:56:15 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:56:15 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:56:15 --> Utf8 Class Initialized
INFO - 2017-02-22 15:56:15 --> URI Class Initialized
INFO - 2017-02-22 15:56:15 --> Router Class Initialized
INFO - 2017-02-22 15:56:15 --> Output Class Initialized
INFO - 2017-02-22 15:56:15 --> Security Class Initialized
DEBUG - 2017-02-22 15:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:56:15 --> Input Class Initialized
INFO - 2017-02-22 15:56:15 --> Language Class Initialized
INFO - 2017-02-22 15:56:15 --> Loader Class Initialized
INFO - 2017-02-22 15:56:15 --> Helper loaded: url_helper
INFO - 2017-02-22 15:56:15 --> Helper loaded: language_helper
INFO - 2017-02-22 15:56:15 --> Helper loaded: html_helper
INFO - 2017-02-22 15:56:15 --> Helper loaded: form_helper
INFO - 2017-02-22 15:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:56:15 --> Controller Class Initialized
INFO - 2017-02-22 15:56:15 --> Database Driver Class Initialized
INFO - 2017-02-22 15:56:15 --> Model Class Initialized
INFO - 2017-02-22 15:56:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:56:15 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:56:15 --> Pagination Class Initialized
INFO - 2017-02-22 15:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:56:15 --> Final output sent to browser
DEBUG - 2017-02-22 15:56:15 --> Total execution time: 0.1376
INFO - 2017-02-22 15:56:35 --> Config Class Initialized
INFO - 2017-02-22 15:56:35 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:56:35 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:56:35 --> Utf8 Class Initialized
INFO - 2017-02-22 15:56:35 --> URI Class Initialized
INFO - 2017-02-22 15:56:35 --> Router Class Initialized
INFO - 2017-02-22 15:56:35 --> Output Class Initialized
INFO - 2017-02-22 15:56:35 --> Security Class Initialized
DEBUG - 2017-02-22 15:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:56:35 --> Input Class Initialized
INFO - 2017-02-22 15:56:35 --> Language Class Initialized
INFO - 2017-02-22 15:56:35 --> Loader Class Initialized
INFO - 2017-02-22 15:56:35 --> Helper loaded: url_helper
INFO - 2017-02-22 15:56:35 --> Helper loaded: language_helper
INFO - 2017-02-22 15:56:35 --> Helper loaded: html_helper
INFO - 2017-02-22 15:56:35 --> Helper loaded: form_helper
INFO - 2017-02-22 15:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:56:35 --> Controller Class Initialized
INFO - 2017-02-22 15:56:35 --> Database Driver Class Initialized
INFO - 2017-02-22 15:56:35 --> Model Class Initialized
INFO - 2017-02-22 15:56:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:56:35 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:56:35 --> Pagination Class Initialized
INFO - 2017-02-22 15:56:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:56:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:56:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:56:35 --> Final output sent to browser
DEBUG - 2017-02-22 15:56:35 --> Total execution time: 0.1496
INFO - 2017-02-22 15:58:00 --> Config Class Initialized
INFO - 2017-02-22 15:58:00 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:58:00 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:58:00 --> Utf8 Class Initialized
INFO - 2017-02-22 15:58:00 --> URI Class Initialized
INFO - 2017-02-22 15:58:00 --> Router Class Initialized
INFO - 2017-02-22 15:58:00 --> Output Class Initialized
INFO - 2017-02-22 15:58:00 --> Security Class Initialized
DEBUG - 2017-02-22 15:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:58:00 --> Input Class Initialized
INFO - 2017-02-22 15:58:00 --> Language Class Initialized
INFO - 2017-02-22 15:58:00 --> Loader Class Initialized
INFO - 2017-02-22 15:58:00 --> Helper loaded: url_helper
INFO - 2017-02-22 15:58:00 --> Helper loaded: language_helper
INFO - 2017-02-22 15:58:00 --> Helper loaded: html_helper
INFO - 2017-02-22 15:58:00 --> Helper loaded: form_helper
INFO - 2017-02-22 15:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:58:00 --> Controller Class Initialized
INFO - 2017-02-22 15:58:00 --> Database Driver Class Initialized
INFO - 2017-02-22 15:58:00 --> Model Class Initialized
INFO - 2017-02-22 15:58:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:58:00 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:58:00 --> Pagination Class Initialized
INFO - 2017-02-22 15:58:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:58:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:58:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:58:00 --> Final output sent to browser
DEBUG - 2017-02-22 15:58:00 --> Total execution time: 0.1756
INFO - 2017-02-22 15:59:27 --> Config Class Initialized
INFO - 2017-02-22 15:59:27 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:59:27 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:59:27 --> Utf8 Class Initialized
INFO - 2017-02-22 15:59:27 --> URI Class Initialized
INFO - 2017-02-22 15:59:27 --> Router Class Initialized
INFO - 2017-02-22 15:59:27 --> Output Class Initialized
INFO - 2017-02-22 15:59:27 --> Security Class Initialized
DEBUG - 2017-02-22 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:59:27 --> Input Class Initialized
INFO - 2017-02-22 15:59:27 --> Language Class Initialized
INFO - 2017-02-22 15:59:27 --> Loader Class Initialized
INFO - 2017-02-22 15:59:27 --> Helper loaded: url_helper
INFO - 2017-02-22 15:59:27 --> Helper loaded: language_helper
INFO - 2017-02-22 15:59:27 --> Helper loaded: html_helper
INFO - 2017-02-22 15:59:27 --> Helper loaded: form_helper
INFO - 2017-02-22 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:59:27 --> Controller Class Initialized
INFO - 2017-02-22 15:59:27 --> Database Driver Class Initialized
INFO - 2017-02-22 15:59:27 --> Model Class Initialized
INFO - 2017-02-22 15:59:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:59:27 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:59:27 --> Pagination Class Initialized
INFO - 2017-02-22 15:59:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:59:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:59:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:59:27 --> Final output sent to browser
DEBUG - 2017-02-22 15:59:27 --> Total execution time: 0.1666
INFO - 2017-02-22 15:59:29 --> Config Class Initialized
INFO - 2017-02-22 15:59:29 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:59:29 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:59:29 --> Utf8 Class Initialized
INFO - 2017-02-22 15:59:29 --> URI Class Initialized
INFO - 2017-02-22 15:59:29 --> Router Class Initialized
INFO - 2017-02-22 15:59:29 --> Output Class Initialized
INFO - 2017-02-22 15:59:29 --> Security Class Initialized
DEBUG - 2017-02-22 15:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:59:29 --> Input Class Initialized
INFO - 2017-02-22 15:59:29 --> Language Class Initialized
INFO - 2017-02-22 15:59:29 --> Loader Class Initialized
INFO - 2017-02-22 15:59:29 --> Helper loaded: url_helper
INFO - 2017-02-22 15:59:29 --> Helper loaded: language_helper
INFO - 2017-02-22 15:59:29 --> Helper loaded: html_helper
INFO - 2017-02-22 15:59:29 --> Helper loaded: form_helper
INFO - 2017-02-22 15:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:59:29 --> Controller Class Initialized
INFO - 2017-02-22 15:59:29 --> Database Driver Class Initialized
INFO - 2017-02-22 15:59:29 --> Model Class Initialized
INFO - 2017-02-22 15:59:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:59:29 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:59:29 --> Pagination Class Initialized
INFO - 2017-02-22 15:59:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:59:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:59:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:59:29 --> Final output sent to browser
DEBUG - 2017-02-22 15:59:29 --> Total execution time: 0.1568
INFO - 2017-02-22 15:59:30 --> Config Class Initialized
INFO - 2017-02-22 15:59:30 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:59:30 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:59:30 --> Utf8 Class Initialized
INFO - 2017-02-22 15:59:30 --> URI Class Initialized
INFO - 2017-02-22 15:59:30 --> Router Class Initialized
INFO - 2017-02-22 15:59:30 --> Output Class Initialized
INFO - 2017-02-22 15:59:30 --> Security Class Initialized
DEBUG - 2017-02-22 15:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:59:30 --> Input Class Initialized
INFO - 2017-02-22 15:59:30 --> Language Class Initialized
INFO - 2017-02-22 15:59:30 --> Loader Class Initialized
INFO - 2017-02-22 15:59:30 --> Helper loaded: url_helper
INFO - 2017-02-22 15:59:30 --> Helper loaded: language_helper
INFO - 2017-02-22 15:59:30 --> Helper loaded: html_helper
INFO - 2017-02-22 15:59:30 --> Helper loaded: form_helper
INFO - 2017-02-22 15:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:59:30 --> Controller Class Initialized
INFO - 2017-02-22 15:59:30 --> Database Driver Class Initialized
INFO - 2017-02-22 15:59:30 --> Model Class Initialized
INFO - 2017-02-22 15:59:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:59:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:59:30 --> Pagination Class Initialized
INFO - 2017-02-22 15:59:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:59:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:59:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:59:30 --> Final output sent to browser
DEBUG - 2017-02-22 15:59:30 --> Total execution time: 0.1733
INFO - 2017-02-22 15:59:31 --> Config Class Initialized
INFO - 2017-02-22 15:59:31 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:59:31 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:59:31 --> Utf8 Class Initialized
INFO - 2017-02-22 15:59:31 --> URI Class Initialized
INFO - 2017-02-22 15:59:31 --> Router Class Initialized
INFO - 2017-02-22 15:59:31 --> Output Class Initialized
INFO - 2017-02-22 15:59:31 --> Security Class Initialized
DEBUG - 2017-02-22 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:59:31 --> Input Class Initialized
INFO - 2017-02-22 15:59:31 --> Language Class Initialized
INFO - 2017-02-22 15:59:31 --> Loader Class Initialized
INFO - 2017-02-22 15:59:31 --> Helper loaded: url_helper
INFO - 2017-02-22 15:59:31 --> Helper loaded: language_helper
INFO - 2017-02-22 15:59:31 --> Helper loaded: html_helper
INFO - 2017-02-22 15:59:31 --> Helper loaded: form_helper
INFO - 2017-02-22 15:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:59:31 --> Controller Class Initialized
INFO - 2017-02-22 15:59:31 --> Database Driver Class Initialized
INFO - 2017-02-22 15:59:31 --> Model Class Initialized
INFO - 2017-02-22 15:59:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:59:31 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:59:31 --> Pagination Class Initialized
INFO - 2017-02-22 15:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:59:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:59:32 --> Final output sent to browser
DEBUG - 2017-02-22 15:59:32 --> Total execution time: 0.1369
INFO - 2017-02-22 15:59:34 --> Config Class Initialized
INFO - 2017-02-22 15:59:34 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:59:34 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:59:34 --> Utf8 Class Initialized
INFO - 2017-02-22 15:59:34 --> URI Class Initialized
INFO - 2017-02-22 15:59:34 --> Router Class Initialized
INFO - 2017-02-22 15:59:34 --> Output Class Initialized
INFO - 2017-02-22 15:59:34 --> Security Class Initialized
DEBUG - 2017-02-22 15:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:59:34 --> Input Class Initialized
INFO - 2017-02-22 15:59:34 --> Language Class Initialized
INFO - 2017-02-22 15:59:34 --> Loader Class Initialized
INFO - 2017-02-22 15:59:34 --> Helper loaded: url_helper
INFO - 2017-02-22 15:59:34 --> Helper loaded: language_helper
INFO - 2017-02-22 15:59:34 --> Helper loaded: html_helper
INFO - 2017-02-22 15:59:34 --> Helper loaded: form_helper
INFO - 2017-02-22 15:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:59:34 --> Controller Class Initialized
INFO - 2017-02-22 15:59:34 --> Database Driver Class Initialized
INFO - 2017-02-22 15:59:34 --> Model Class Initialized
INFO - 2017-02-22 15:59:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:59:34 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:59:34 --> Pagination Class Initialized
INFO - 2017-02-22 15:59:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:59:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:59:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:59:34 --> Final output sent to browser
DEBUG - 2017-02-22 15:59:34 --> Total execution time: 0.1509
INFO - 2017-02-22 15:59:37 --> Config Class Initialized
INFO - 2017-02-22 15:59:37 --> Hooks Class Initialized
DEBUG - 2017-02-22 15:59:37 --> UTF-8 Support Enabled
INFO - 2017-02-22 15:59:37 --> Utf8 Class Initialized
INFO - 2017-02-22 15:59:37 --> URI Class Initialized
INFO - 2017-02-22 15:59:37 --> Router Class Initialized
INFO - 2017-02-22 15:59:37 --> Output Class Initialized
INFO - 2017-02-22 15:59:37 --> Security Class Initialized
DEBUG - 2017-02-22 15:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 15:59:37 --> Input Class Initialized
INFO - 2017-02-22 15:59:37 --> Language Class Initialized
INFO - 2017-02-22 15:59:37 --> Loader Class Initialized
INFO - 2017-02-22 15:59:37 --> Helper loaded: url_helper
INFO - 2017-02-22 15:59:37 --> Helper loaded: language_helper
INFO - 2017-02-22 15:59:37 --> Helper loaded: html_helper
INFO - 2017-02-22 15:59:37 --> Helper loaded: form_helper
INFO - 2017-02-22 15:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 15:59:37 --> Controller Class Initialized
INFO - 2017-02-22 15:59:37 --> Database Driver Class Initialized
INFO - 2017-02-22 15:59:37 --> Model Class Initialized
INFO - 2017-02-22 15:59:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 15:59:37 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 15:59:37 --> Pagination Class Initialized
INFO - 2017-02-22 15:59:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 15:59:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 15:59:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 15:59:37 --> Final output sent to browser
DEBUG - 2017-02-22 15:59:37 --> Total execution time: 0.1215
INFO - 2017-02-22 16:00:54 --> Config Class Initialized
INFO - 2017-02-22 16:00:54 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:00:54 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:00:54 --> Utf8 Class Initialized
INFO - 2017-02-22 16:00:54 --> URI Class Initialized
INFO - 2017-02-22 16:00:54 --> Router Class Initialized
INFO - 2017-02-22 16:00:54 --> Output Class Initialized
INFO - 2017-02-22 16:00:54 --> Security Class Initialized
DEBUG - 2017-02-22 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:00:54 --> Input Class Initialized
INFO - 2017-02-22 16:00:54 --> Language Class Initialized
INFO - 2017-02-22 16:00:54 --> Loader Class Initialized
INFO - 2017-02-22 16:00:54 --> Helper loaded: url_helper
INFO - 2017-02-22 16:00:54 --> Helper loaded: language_helper
INFO - 2017-02-22 16:00:54 --> Helper loaded: html_helper
INFO - 2017-02-22 16:00:54 --> Helper loaded: form_helper
INFO - 2017-02-22 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:00:54 --> Controller Class Initialized
INFO - 2017-02-22 16:00:54 --> Database Driver Class Initialized
INFO - 2017-02-22 16:00:54 --> Model Class Initialized
INFO - 2017-02-22 16:00:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:00:54 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:00:54 --> Pagination Class Initialized
INFO - 2017-02-22 16:00:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:00:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:00:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:00:54 --> Final output sent to browser
DEBUG - 2017-02-22 16:00:54 --> Total execution time: 0.1313
INFO - 2017-02-22 16:00:56 --> Config Class Initialized
INFO - 2017-02-22 16:00:56 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:00:56 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:00:56 --> Utf8 Class Initialized
INFO - 2017-02-22 16:00:56 --> URI Class Initialized
INFO - 2017-02-22 16:00:56 --> Router Class Initialized
INFO - 2017-02-22 16:00:56 --> Output Class Initialized
INFO - 2017-02-22 16:00:56 --> Security Class Initialized
DEBUG - 2017-02-22 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:00:56 --> Input Class Initialized
INFO - 2017-02-22 16:00:56 --> Language Class Initialized
INFO - 2017-02-22 16:00:56 --> Loader Class Initialized
INFO - 2017-02-22 16:00:56 --> Helper loaded: url_helper
INFO - 2017-02-22 16:00:56 --> Helper loaded: language_helper
INFO - 2017-02-22 16:00:56 --> Helper loaded: html_helper
INFO - 2017-02-22 16:00:56 --> Helper loaded: form_helper
INFO - 2017-02-22 16:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:00:56 --> Controller Class Initialized
INFO - 2017-02-22 16:00:56 --> Database Driver Class Initialized
INFO - 2017-02-22 16:00:56 --> Model Class Initialized
INFO - 2017-02-22 16:00:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:00:56 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:00:56 --> Pagination Class Initialized
INFO - 2017-02-22 16:00:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:00:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:00:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:00:56 --> Final output sent to browser
DEBUG - 2017-02-22 16:00:56 --> Total execution time: 0.1546
INFO - 2017-02-22 16:01:14 --> Config Class Initialized
INFO - 2017-02-22 16:01:14 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:01:14 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:01:14 --> Utf8 Class Initialized
INFO - 2017-02-22 16:01:14 --> URI Class Initialized
INFO - 2017-02-22 16:01:14 --> Router Class Initialized
INFO - 2017-02-22 16:01:14 --> Output Class Initialized
INFO - 2017-02-22 16:01:14 --> Security Class Initialized
DEBUG - 2017-02-22 16:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:01:14 --> Input Class Initialized
INFO - 2017-02-22 16:01:14 --> Language Class Initialized
INFO - 2017-02-22 16:01:14 --> Loader Class Initialized
INFO - 2017-02-22 16:01:14 --> Helper loaded: url_helper
INFO - 2017-02-22 16:01:14 --> Helper loaded: language_helper
INFO - 2017-02-22 16:01:14 --> Helper loaded: html_helper
INFO - 2017-02-22 16:01:14 --> Helper loaded: form_helper
INFO - 2017-02-22 16:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:01:14 --> Controller Class Initialized
INFO - 2017-02-22 16:01:14 --> Database Driver Class Initialized
INFO - 2017-02-22 16:01:14 --> Model Class Initialized
INFO - 2017-02-22 16:01:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:01:14 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:01:14 --> Pagination Class Initialized
INFO - 2017-02-22 16:01:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:01:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:01:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:01:14 --> Final output sent to browser
DEBUG - 2017-02-22 16:01:14 --> Total execution time: 0.1692
INFO - 2017-02-22 16:01:17 --> Config Class Initialized
INFO - 2017-02-22 16:01:17 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:01:17 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:01:17 --> Utf8 Class Initialized
INFO - 2017-02-22 16:01:17 --> URI Class Initialized
INFO - 2017-02-22 16:01:17 --> Router Class Initialized
INFO - 2017-02-22 16:01:17 --> Output Class Initialized
INFO - 2017-02-22 16:01:17 --> Security Class Initialized
DEBUG - 2017-02-22 16:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:01:17 --> Input Class Initialized
INFO - 2017-02-22 16:01:17 --> Language Class Initialized
INFO - 2017-02-22 16:01:17 --> Loader Class Initialized
INFO - 2017-02-22 16:01:17 --> Helper loaded: url_helper
INFO - 2017-02-22 16:01:17 --> Helper loaded: language_helper
INFO - 2017-02-22 16:01:17 --> Helper loaded: html_helper
INFO - 2017-02-22 16:01:17 --> Helper loaded: form_helper
INFO - 2017-02-22 16:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:01:17 --> Controller Class Initialized
INFO - 2017-02-22 16:01:17 --> Database Driver Class Initialized
INFO - 2017-02-22 16:01:17 --> Model Class Initialized
INFO - 2017-02-22 16:01:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:01:17 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:01:17 --> Pagination Class Initialized
INFO - 2017-02-22 16:01:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:01:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:01:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:01:17 --> Final output sent to browser
DEBUG - 2017-02-22 16:01:17 --> Total execution time: 0.1228
INFO - 2017-02-22 16:01:28 --> Config Class Initialized
INFO - 2017-02-22 16:01:28 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:01:28 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:01:28 --> Utf8 Class Initialized
INFO - 2017-02-22 16:01:28 --> URI Class Initialized
INFO - 2017-02-22 16:01:28 --> Router Class Initialized
INFO - 2017-02-22 16:01:28 --> Output Class Initialized
INFO - 2017-02-22 16:01:28 --> Security Class Initialized
DEBUG - 2017-02-22 16:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:01:28 --> Input Class Initialized
INFO - 2017-02-22 16:01:28 --> Language Class Initialized
INFO - 2017-02-22 16:01:28 --> Loader Class Initialized
INFO - 2017-02-22 16:01:28 --> Helper loaded: url_helper
INFO - 2017-02-22 16:01:28 --> Helper loaded: language_helper
INFO - 2017-02-22 16:01:28 --> Helper loaded: html_helper
INFO - 2017-02-22 16:01:28 --> Helper loaded: form_helper
INFO - 2017-02-22 16:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:01:28 --> Controller Class Initialized
INFO - 2017-02-22 16:01:28 --> Database Driver Class Initialized
INFO - 2017-02-22 16:01:28 --> Model Class Initialized
INFO - 2017-02-22 16:01:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:01:28 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:01:28 --> Pagination Class Initialized
INFO - 2017-02-22 16:01:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:01:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:01:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:01:28 --> Final output sent to browser
DEBUG - 2017-02-22 16:01:28 --> Total execution time: 0.1943
INFO - 2017-02-22 16:01:36 --> Config Class Initialized
INFO - 2017-02-22 16:01:36 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:01:36 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:01:36 --> Utf8 Class Initialized
INFO - 2017-02-22 16:01:36 --> URI Class Initialized
INFO - 2017-02-22 16:01:36 --> Router Class Initialized
INFO - 2017-02-22 16:01:36 --> Output Class Initialized
INFO - 2017-02-22 16:01:36 --> Security Class Initialized
DEBUG - 2017-02-22 16:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:01:36 --> Input Class Initialized
INFO - 2017-02-22 16:01:36 --> Language Class Initialized
INFO - 2017-02-22 16:01:36 --> Loader Class Initialized
INFO - 2017-02-22 16:01:36 --> Helper loaded: url_helper
INFO - 2017-02-22 16:01:36 --> Helper loaded: language_helper
INFO - 2017-02-22 16:01:36 --> Helper loaded: html_helper
INFO - 2017-02-22 16:01:36 --> Helper loaded: form_helper
INFO - 2017-02-22 16:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:01:36 --> Controller Class Initialized
INFO - 2017-02-22 16:01:36 --> Database Driver Class Initialized
INFO - 2017-02-22 16:01:36 --> Model Class Initialized
INFO - 2017-02-22 16:01:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:01:36 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:01:36 --> Pagination Class Initialized
INFO - 2017-02-22 16:01:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:01:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:01:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:01:36 --> Final output sent to browser
DEBUG - 2017-02-22 16:01:36 --> Total execution time: 0.1731
INFO - 2017-02-22 16:01:44 --> Config Class Initialized
INFO - 2017-02-22 16:01:44 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:01:44 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:01:44 --> Utf8 Class Initialized
INFO - 2017-02-22 16:01:44 --> URI Class Initialized
INFO - 2017-02-22 16:01:44 --> Router Class Initialized
INFO - 2017-02-22 16:01:44 --> Output Class Initialized
INFO - 2017-02-22 16:01:44 --> Security Class Initialized
DEBUG - 2017-02-22 16:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:01:44 --> Input Class Initialized
INFO - 2017-02-22 16:01:44 --> Language Class Initialized
INFO - 2017-02-22 16:01:44 --> Loader Class Initialized
INFO - 2017-02-22 16:01:44 --> Helper loaded: url_helper
INFO - 2017-02-22 16:01:44 --> Helper loaded: language_helper
INFO - 2017-02-22 16:01:44 --> Helper loaded: html_helper
INFO - 2017-02-22 16:01:44 --> Helper loaded: form_helper
INFO - 2017-02-22 16:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:01:44 --> Controller Class Initialized
INFO - 2017-02-22 16:01:44 --> Database Driver Class Initialized
INFO - 2017-02-22 16:01:44 --> Model Class Initialized
INFO - 2017-02-22 16:01:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:01:44 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:01:44 --> Pagination Class Initialized
INFO - 2017-02-22 16:01:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:01:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:01:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:01:44 --> Final output sent to browser
DEBUG - 2017-02-22 16:01:44 --> Total execution time: 0.1279
INFO - 2017-02-22 16:01:51 --> Config Class Initialized
INFO - 2017-02-22 16:01:51 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:01:51 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:01:51 --> Utf8 Class Initialized
INFO - 2017-02-22 16:01:51 --> URI Class Initialized
INFO - 2017-02-22 16:01:51 --> Router Class Initialized
INFO - 2017-02-22 16:01:51 --> Output Class Initialized
INFO - 2017-02-22 16:01:51 --> Security Class Initialized
DEBUG - 2017-02-22 16:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:01:51 --> Input Class Initialized
INFO - 2017-02-22 16:01:51 --> Language Class Initialized
INFO - 2017-02-22 16:01:51 --> Loader Class Initialized
INFO - 2017-02-22 16:01:51 --> Helper loaded: url_helper
INFO - 2017-02-22 16:01:51 --> Helper loaded: language_helper
INFO - 2017-02-22 16:01:51 --> Helper loaded: html_helper
INFO - 2017-02-22 16:01:51 --> Helper loaded: form_helper
INFO - 2017-02-22 16:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:01:51 --> Controller Class Initialized
INFO - 2017-02-22 16:01:51 --> Database Driver Class Initialized
INFO - 2017-02-22 16:01:51 --> Model Class Initialized
INFO - 2017-02-22 16:01:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:01:51 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:01:51 --> Pagination Class Initialized
INFO - 2017-02-22 16:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:01:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:01:51 --> Final output sent to browser
DEBUG - 2017-02-22 16:01:51 --> Total execution time: 0.2002
INFO - 2017-02-22 16:01:57 --> Config Class Initialized
INFO - 2017-02-22 16:01:57 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:01:57 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:01:57 --> Utf8 Class Initialized
INFO - 2017-02-22 16:01:57 --> URI Class Initialized
INFO - 2017-02-22 16:01:57 --> Router Class Initialized
INFO - 2017-02-22 16:01:57 --> Output Class Initialized
INFO - 2017-02-22 16:01:57 --> Security Class Initialized
DEBUG - 2017-02-22 16:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:01:57 --> Input Class Initialized
INFO - 2017-02-22 16:01:57 --> Language Class Initialized
INFO - 2017-02-22 16:01:57 --> Loader Class Initialized
INFO - 2017-02-22 16:01:57 --> Helper loaded: url_helper
INFO - 2017-02-22 16:01:57 --> Helper loaded: language_helper
INFO - 2017-02-22 16:01:57 --> Helper loaded: html_helper
INFO - 2017-02-22 16:01:57 --> Helper loaded: form_helper
INFO - 2017-02-22 16:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:01:57 --> Controller Class Initialized
INFO - 2017-02-22 16:01:57 --> Database Driver Class Initialized
INFO - 2017-02-22 16:01:57 --> Model Class Initialized
INFO - 2017-02-22 16:01:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:01:57 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:01:57 --> Pagination Class Initialized
INFO - 2017-02-22 16:01:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:01:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:01:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:01:57 --> Final output sent to browser
DEBUG - 2017-02-22 16:01:57 --> Total execution time: 0.1372
INFO - 2017-02-22 16:02:25 --> Config Class Initialized
INFO - 2017-02-22 16:02:25 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:02:25 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:02:25 --> Utf8 Class Initialized
INFO - 2017-02-22 16:02:25 --> URI Class Initialized
INFO - 2017-02-22 16:02:25 --> Router Class Initialized
INFO - 2017-02-22 16:02:25 --> Output Class Initialized
INFO - 2017-02-22 16:02:25 --> Security Class Initialized
DEBUG - 2017-02-22 16:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:02:25 --> Input Class Initialized
INFO - 2017-02-22 16:02:25 --> Language Class Initialized
INFO - 2017-02-22 16:02:25 --> Loader Class Initialized
INFO - 2017-02-22 16:02:25 --> Helper loaded: url_helper
INFO - 2017-02-22 16:02:25 --> Helper loaded: language_helper
INFO - 2017-02-22 16:02:25 --> Helper loaded: html_helper
INFO - 2017-02-22 16:02:25 --> Helper loaded: form_helper
INFO - 2017-02-22 16:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:02:25 --> Controller Class Initialized
INFO - 2017-02-22 16:02:25 --> Database Driver Class Initialized
INFO - 2017-02-22 16:02:25 --> Model Class Initialized
INFO - 2017-02-22 16:02:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:02:25 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:02:25 --> Pagination Class Initialized
INFO - 2017-02-22 16:02:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:02:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:02:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:02:25 --> Final output sent to browser
DEBUG - 2017-02-22 16:02:25 --> Total execution time: 0.1406
INFO - 2017-02-22 16:02:43 --> Config Class Initialized
INFO - 2017-02-22 16:02:43 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:02:43 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:02:43 --> Utf8 Class Initialized
INFO - 2017-02-22 16:02:43 --> URI Class Initialized
INFO - 2017-02-22 16:02:43 --> Router Class Initialized
INFO - 2017-02-22 16:02:43 --> Output Class Initialized
INFO - 2017-02-22 16:02:43 --> Security Class Initialized
DEBUG - 2017-02-22 16:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:02:43 --> Input Class Initialized
INFO - 2017-02-22 16:02:43 --> Language Class Initialized
INFO - 2017-02-22 16:02:43 --> Loader Class Initialized
INFO - 2017-02-22 16:02:43 --> Helper loaded: url_helper
INFO - 2017-02-22 16:02:43 --> Helper loaded: language_helper
INFO - 2017-02-22 16:02:43 --> Helper loaded: html_helper
INFO - 2017-02-22 16:02:43 --> Helper loaded: form_helper
INFO - 2017-02-22 16:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:02:43 --> Controller Class Initialized
INFO - 2017-02-22 16:02:43 --> Database Driver Class Initialized
INFO - 2017-02-22 16:02:43 --> Model Class Initialized
INFO - 2017-02-22 16:02:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:02:43 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:02:43 --> Pagination Class Initialized
INFO - 2017-02-22 16:02:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:02:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:02:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:02:43 --> Final output sent to browser
DEBUG - 2017-02-22 16:02:43 --> Total execution time: 0.1900
INFO - 2017-02-22 16:02:54 --> Config Class Initialized
INFO - 2017-02-22 16:02:54 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:02:54 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:02:54 --> Utf8 Class Initialized
INFO - 2017-02-22 16:02:54 --> URI Class Initialized
INFO - 2017-02-22 16:02:54 --> Router Class Initialized
INFO - 2017-02-22 16:02:54 --> Output Class Initialized
INFO - 2017-02-22 16:02:54 --> Security Class Initialized
DEBUG - 2017-02-22 16:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:02:54 --> Input Class Initialized
INFO - 2017-02-22 16:02:54 --> Language Class Initialized
INFO - 2017-02-22 16:02:54 --> Loader Class Initialized
INFO - 2017-02-22 16:02:54 --> Helper loaded: url_helper
INFO - 2017-02-22 16:02:54 --> Helper loaded: language_helper
INFO - 2017-02-22 16:02:54 --> Helper loaded: html_helper
INFO - 2017-02-22 16:02:54 --> Helper loaded: form_helper
INFO - 2017-02-22 16:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:02:54 --> Controller Class Initialized
INFO - 2017-02-22 16:02:54 --> Database Driver Class Initialized
INFO - 2017-02-22 16:02:54 --> Model Class Initialized
INFO - 2017-02-22 16:02:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:02:54 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:02:54 --> Pagination Class Initialized
INFO - 2017-02-22 16:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:02:54 --> Final output sent to browser
DEBUG - 2017-02-22 16:02:54 --> Total execution time: 0.1549
INFO - 2017-02-22 16:03:10 --> Config Class Initialized
INFO - 2017-02-22 16:03:10 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:03:10 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:03:10 --> Utf8 Class Initialized
INFO - 2017-02-22 16:03:10 --> URI Class Initialized
INFO - 2017-02-22 16:03:10 --> Router Class Initialized
INFO - 2017-02-22 16:03:10 --> Output Class Initialized
INFO - 2017-02-22 16:03:10 --> Security Class Initialized
DEBUG - 2017-02-22 16:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:03:10 --> Input Class Initialized
INFO - 2017-02-22 16:03:10 --> Language Class Initialized
INFO - 2017-02-22 16:03:10 --> Loader Class Initialized
INFO - 2017-02-22 16:03:10 --> Helper loaded: url_helper
INFO - 2017-02-22 16:03:10 --> Helper loaded: language_helper
INFO - 2017-02-22 16:03:10 --> Helper loaded: html_helper
INFO - 2017-02-22 16:03:10 --> Helper loaded: form_helper
INFO - 2017-02-22 16:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:03:10 --> Controller Class Initialized
INFO - 2017-02-22 16:03:10 --> Database Driver Class Initialized
INFO - 2017-02-22 16:03:10 --> Model Class Initialized
INFO - 2017-02-22 16:03:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:03:10 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:03:10 --> Pagination Class Initialized
INFO - 2017-02-22 16:03:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:03:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:03:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:03:10 --> Final output sent to browser
DEBUG - 2017-02-22 16:03:10 --> Total execution time: 0.1600
INFO - 2017-02-22 16:03:17 --> Config Class Initialized
INFO - 2017-02-22 16:03:17 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:03:17 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:03:17 --> Utf8 Class Initialized
INFO - 2017-02-22 16:03:17 --> URI Class Initialized
INFO - 2017-02-22 16:03:17 --> Router Class Initialized
INFO - 2017-02-22 16:03:17 --> Output Class Initialized
INFO - 2017-02-22 16:03:17 --> Security Class Initialized
DEBUG - 2017-02-22 16:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:03:17 --> Input Class Initialized
INFO - 2017-02-22 16:03:17 --> Language Class Initialized
INFO - 2017-02-22 16:03:17 --> Loader Class Initialized
INFO - 2017-02-22 16:03:17 --> Helper loaded: url_helper
INFO - 2017-02-22 16:03:17 --> Helper loaded: language_helper
INFO - 2017-02-22 16:03:17 --> Helper loaded: html_helper
INFO - 2017-02-22 16:03:17 --> Helper loaded: form_helper
INFO - 2017-02-22 16:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:03:17 --> Controller Class Initialized
INFO - 2017-02-22 16:03:17 --> Database Driver Class Initialized
INFO - 2017-02-22 16:03:17 --> Model Class Initialized
INFO - 2017-02-22 16:03:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:03:17 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:03:17 --> Pagination Class Initialized
INFO - 2017-02-22 16:03:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:03:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:03:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:03:17 --> Final output sent to browser
DEBUG - 2017-02-22 16:03:17 --> Total execution time: 0.1330
INFO - 2017-02-22 16:03:20 --> Config Class Initialized
INFO - 2017-02-22 16:03:20 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:03:20 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:03:20 --> Utf8 Class Initialized
INFO - 2017-02-22 16:03:20 --> URI Class Initialized
INFO - 2017-02-22 16:03:20 --> Router Class Initialized
INFO - 2017-02-22 16:03:20 --> Output Class Initialized
INFO - 2017-02-22 16:03:20 --> Security Class Initialized
DEBUG - 2017-02-22 16:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:03:20 --> Input Class Initialized
INFO - 2017-02-22 16:03:20 --> Language Class Initialized
INFO - 2017-02-22 16:03:20 --> Loader Class Initialized
INFO - 2017-02-22 16:03:20 --> Helper loaded: url_helper
INFO - 2017-02-22 16:03:20 --> Helper loaded: language_helper
INFO - 2017-02-22 16:03:20 --> Helper loaded: html_helper
INFO - 2017-02-22 16:03:20 --> Helper loaded: form_helper
INFO - 2017-02-22 16:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:03:20 --> Controller Class Initialized
INFO - 2017-02-22 16:03:20 --> Database Driver Class Initialized
INFO - 2017-02-22 16:03:20 --> Model Class Initialized
INFO - 2017-02-22 16:03:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:03:20 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:03:20 --> Pagination Class Initialized
INFO - 2017-02-22 16:03:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:03:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:03:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:03:20 --> Final output sent to browser
DEBUG - 2017-02-22 16:03:20 --> Total execution time: 0.1304
INFO - 2017-02-22 16:08:27 --> Config Class Initialized
INFO - 2017-02-22 16:08:27 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:08:27 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:08:27 --> Utf8 Class Initialized
INFO - 2017-02-22 16:08:27 --> URI Class Initialized
INFO - 2017-02-22 16:08:27 --> Router Class Initialized
INFO - 2017-02-22 16:08:27 --> Output Class Initialized
INFO - 2017-02-22 16:08:27 --> Security Class Initialized
DEBUG - 2017-02-22 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:08:27 --> Input Class Initialized
INFO - 2017-02-22 16:08:27 --> Language Class Initialized
INFO - 2017-02-22 16:08:27 --> Loader Class Initialized
INFO - 2017-02-22 16:08:27 --> Helper loaded: url_helper
INFO - 2017-02-22 16:08:27 --> Helper loaded: language_helper
INFO - 2017-02-22 16:08:27 --> Helper loaded: html_helper
INFO - 2017-02-22 16:08:27 --> Helper loaded: form_helper
INFO - 2017-02-22 16:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:08:27 --> Controller Class Initialized
INFO - 2017-02-22 16:08:27 --> Database Driver Class Initialized
INFO - 2017-02-22 16:08:27 --> Model Class Initialized
INFO - 2017-02-22 16:08:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:08:27 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:08:27 --> Pagination Class Initialized
INFO - 2017-02-22 16:08:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:08:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:08:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:08:27 --> Final output sent to browser
DEBUG - 2017-02-22 16:08:27 --> Total execution time: 0.1314
INFO - 2017-02-22 16:08:31 --> Config Class Initialized
INFO - 2017-02-22 16:08:31 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:08:31 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:08:31 --> Utf8 Class Initialized
INFO - 2017-02-22 16:08:31 --> URI Class Initialized
INFO - 2017-02-22 16:08:31 --> Router Class Initialized
INFO - 2017-02-22 16:08:31 --> Output Class Initialized
INFO - 2017-02-22 16:08:31 --> Security Class Initialized
DEBUG - 2017-02-22 16:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:08:31 --> Input Class Initialized
INFO - 2017-02-22 16:08:31 --> Language Class Initialized
INFO - 2017-02-22 16:08:31 --> Loader Class Initialized
INFO - 2017-02-22 16:08:31 --> Helper loaded: url_helper
INFO - 2017-02-22 16:08:31 --> Helper loaded: language_helper
INFO - 2017-02-22 16:08:31 --> Helper loaded: html_helper
INFO - 2017-02-22 16:08:31 --> Helper loaded: form_helper
INFO - 2017-02-22 16:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:08:31 --> Controller Class Initialized
INFO - 2017-02-22 16:08:31 --> Database Driver Class Initialized
INFO - 2017-02-22 16:08:31 --> Model Class Initialized
INFO - 2017-02-22 16:08:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:08:31 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:08:31 --> Pagination Class Initialized
INFO - 2017-02-22 16:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:08:31 --> Final output sent to browser
DEBUG - 2017-02-22 16:08:31 --> Total execution time: 0.1486
INFO - 2017-02-22 16:08:38 --> Config Class Initialized
INFO - 2017-02-22 16:08:38 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:08:38 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:08:38 --> Utf8 Class Initialized
INFO - 2017-02-22 16:08:38 --> URI Class Initialized
INFO - 2017-02-22 16:08:38 --> Router Class Initialized
INFO - 2017-02-22 16:08:38 --> Output Class Initialized
INFO - 2017-02-22 16:08:38 --> Security Class Initialized
DEBUG - 2017-02-22 16:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:08:38 --> Input Class Initialized
INFO - 2017-02-22 16:08:38 --> Language Class Initialized
INFO - 2017-02-22 16:08:38 --> Loader Class Initialized
INFO - 2017-02-22 16:08:38 --> Helper loaded: url_helper
INFO - 2017-02-22 16:08:38 --> Helper loaded: language_helper
INFO - 2017-02-22 16:08:38 --> Helper loaded: html_helper
INFO - 2017-02-22 16:08:38 --> Helper loaded: form_helper
INFO - 2017-02-22 16:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:08:38 --> Controller Class Initialized
INFO - 2017-02-22 16:08:38 --> Database Driver Class Initialized
INFO - 2017-02-22 16:08:38 --> Model Class Initialized
INFO - 2017-02-22 16:08:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:08:38 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:08:38 --> Pagination Class Initialized
INFO - 2017-02-22 16:08:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:08:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:08:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:08:38 --> Final output sent to browser
DEBUG - 2017-02-22 16:08:38 --> Total execution time: 0.1143
INFO - 2017-02-22 16:08:40 --> Config Class Initialized
INFO - 2017-02-22 16:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:08:40 --> Utf8 Class Initialized
INFO - 2017-02-22 16:08:40 --> URI Class Initialized
INFO - 2017-02-22 16:08:40 --> Router Class Initialized
INFO - 2017-02-22 16:08:40 --> Output Class Initialized
INFO - 2017-02-22 16:08:40 --> Security Class Initialized
DEBUG - 2017-02-22 16:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:08:40 --> Input Class Initialized
INFO - 2017-02-22 16:08:40 --> Language Class Initialized
INFO - 2017-02-22 16:08:40 --> Loader Class Initialized
INFO - 2017-02-22 16:08:40 --> Helper loaded: url_helper
INFO - 2017-02-22 16:08:40 --> Helper loaded: language_helper
INFO - 2017-02-22 16:08:40 --> Helper loaded: html_helper
INFO - 2017-02-22 16:08:40 --> Helper loaded: form_helper
INFO - 2017-02-22 16:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:08:40 --> Controller Class Initialized
INFO - 2017-02-22 16:08:40 --> Database Driver Class Initialized
INFO - 2017-02-22 16:08:40 --> Model Class Initialized
INFO - 2017-02-22 16:08:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:08:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:08:40 --> Pagination Class Initialized
INFO - 2017-02-22 16:08:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:08:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:08:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:08:40 --> Final output sent to browser
DEBUG - 2017-02-22 16:08:40 --> Total execution time: 0.1482
INFO - 2017-02-22 16:08:42 --> Config Class Initialized
INFO - 2017-02-22 16:08:42 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:08:42 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:08:42 --> Utf8 Class Initialized
INFO - 2017-02-22 16:08:42 --> URI Class Initialized
INFO - 2017-02-22 16:08:42 --> Router Class Initialized
INFO - 2017-02-22 16:08:42 --> Output Class Initialized
INFO - 2017-02-22 16:08:42 --> Security Class Initialized
DEBUG - 2017-02-22 16:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:08:42 --> Input Class Initialized
INFO - 2017-02-22 16:08:42 --> Language Class Initialized
INFO - 2017-02-22 16:08:42 --> Loader Class Initialized
INFO - 2017-02-22 16:08:42 --> Helper loaded: url_helper
INFO - 2017-02-22 16:08:42 --> Helper loaded: language_helper
INFO - 2017-02-22 16:08:42 --> Helper loaded: html_helper
INFO - 2017-02-22 16:08:42 --> Helper loaded: form_helper
INFO - 2017-02-22 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:08:42 --> Controller Class Initialized
INFO - 2017-02-22 16:08:42 --> Database Driver Class Initialized
INFO - 2017-02-22 16:08:42 --> Model Class Initialized
INFO - 2017-02-22 16:08:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:08:42 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:08:42 --> Pagination Class Initialized
INFO - 2017-02-22 16:08:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:08:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:08:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:08:42 --> Final output sent to browser
DEBUG - 2017-02-22 16:08:42 --> Total execution time: 0.1526
INFO - 2017-02-22 16:08:44 --> Config Class Initialized
INFO - 2017-02-22 16:08:44 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:08:44 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:08:44 --> Utf8 Class Initialized
INFO - 2017-02-22 16:08:44 --> URI Class Initialized
INFO - 2017-02-22 16:08:44 --> Router Class Initialized
INFO - 2017-02-22 16:08:44 --> Output Class Initialized
INFO - 2017-02-22 16:08:44 --> Security Class Initialized
DEBUG - 2017-02-22 16:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:08:44 --> Input Class Initialized
INFO - 2017-02-22 16:08:44 --> Language Class Initialized
INFO - 2017-02-22 16:08:44 --> Loader Class Initialized
INFO - 2017-02-22 16:08:44 --> Helper loaded: url_helper
INFO - 2017-02-22 16:08:44 --> Helper loaded: language_helper
INFO - 2017-02-22 16:08:44 --> Helper loaded: html_helper
INFO - 2017-02-22 16:08:44 --> Helper loaded: form_helper
INFO - 2017-02-22 16:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:08:44 --> Controller Class Initialized
INFO - 2017-02-22 16:08:44 --> Database Driver Class Initialized
INFO - 2017-02-22 16:08:44 --> Model Class Initialized
INFO - 2017-02-22 16:08:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:08:44 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:08:44 --> Pagination Class Initialized
INFO - 2017-02-22 16:08:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:08:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:08:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:08:44 --> Final output sent to browser
DEBUG - 2017-02-22 16:08:44 --> Total execution time: 0.1523
INFO - 2017-02-22 16:12:05 --> Config Class Initialized
INFO - 2017-02-22 16:12:05 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:05 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:05 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:05 --> URI Class Initialized
INFO - 2017-02-22 16:12:05 --> Router Class Initialized
INFO - 2017-02-22 16:12:05 --> Output Class Initialized
INFO - 2017-02-22 16:12:05 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:05 --> Input Class Initialized
INFO - 2017-02-22 16:12:05 --> Language Class Initialized
INFO - 2017-02-22 16:12:05 --> Loader Class Initialized
INFO - 2017-02-22 16:12:05 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:05 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:05 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:05 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:05 --> Controller Class Initialized
INFO - 2017-02-22 16:12:05 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:05 --> Model Class Initialized
INFO - 2017-02-22 16:12:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:05 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:12:05 --> Pagination Class Initialized
INFO - 2017-02-22 16:12:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:12:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:12:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:12:05 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:05 --> Total execution time: 0.1771
INFO - 2017-02-22 16:12:09 --> Config Class Initialized
INFO - 2017-02-22 16:12:09 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:09 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:09 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:09 --> URI Class Initialized
INFO - 2017-02-22 16:12:09 --> Router Class Initialized
INFO - 2017-02-22 16:12:09 --> Output Class Initialized
INFO - 2017-02-22 16:12:09 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:09 --> Input Class Initialized
INFO - 2017-02-22 16:12:09 --> Language Class Initialized
INFO - 2017-02-22 16:12:09 --> Loader Class Initialized
INFO - 2017-02-22 16:12:09 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:09 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:09 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:09 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:09 --> Controller Class Initialized
INFO - 2017-02-22 16:12:09 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:09 --> Model Class Initialized
INFO - 2017-02-22 16:12:09 --> Model Class Initialized
INFO - 2017-02-22 16:12:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:09 --> Config Class Initialized
INFO - 2017-02-22 16:12:09 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:09 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:09 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:09 --> URI Class Initialized
INFO - 2017-02-22 16:12:09 --> Router Class Initialized
INFO - 2017-02-22 16:12:09 --> Output Class Initialized
INFO - 2017-02-22 16:12:09 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:09 --> Input Class Initialized
INFO - 2017-02-22 16:12:09 --> Language Class Initialized
INFO - 2017-02-22 16:12:09 --> Loader Class Initialized
INFO - 2017-02-22 16:12:09 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:09 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:09 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:09 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:09 --> Controller Class Initialized
INFO - 2017-02-22 16:12:09 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:09 --> Model Class Initialized
INFO - 2017-02-22 16:12:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-22 16:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-22 16:12:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-22 16:12:09 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:09 --> Total execution time: 0.1344
INFO - 2017-02-22 16:12:16 --> Config Class Initialized
INFO - 2017-02-22 16:12:16 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:16 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:16 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:16 --> URI Class Initialized
INFO - 2017-02-22 16:12:16 --> Router Class Initialized
INFO - 2017-02-22 16:12:16 --> Output Class Initialized
INFO - 2017-02-22 16:12:16 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:16 --> Input Class Initialized
INFO - 2017-02-22 16:12:16 --> Language Class Initialized
INFO - 2017-02-22 16:12:16 --> Loader Class Initialized
INFO - 2017-02-22 16:12:16 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:16 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:16 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:16 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:16 --> Controller Class Initialized
INFO - 2017-02-22 16:12:16 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:16 --> Model Class Initialized
INFO - 2017-02-22 16:12:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:16 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:12:16 --> Pagination Class Initialized
INFO - 2017-02-22 16:12:16 --> Config Class Initialized
INFO - 2017-02-22 16:12:16 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:16 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:16 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:16 --> URI Class Initialized
INFO - 2017-02-22 16:12:16 --> Router Class Initialized
INFO - 2017-02-22 16:12:16 --> Output Class Initialized
INFO - 2017-02-22 16:12:16 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:16 --> Input Class Initialized
INFO - 2017-02-22 16:12:16 --> Language Class Initialized
INFO - 2017-02-22 16:12:16 --> Loader Class Initialized
INFO - 2017-02-22 16:12:16 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:16 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:16 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:16 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:16 --> Controller Class Initialized
INFO - 2017-02-22 16:12:16 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:16 --> Model Class Initialized
INFO - 2017-02-22 16:12:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-22 16:12:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-22 16:12:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-22 16:12:16 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:16 --> Total execution time: 0.1272
INFO - 2017-02-22 16:12:22 --> Config Class Initialized
INFO - 2017-02-22 16:12:22 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:22 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:22 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:22 --> URI Class Initialized
INFO - 2017-02-22 16:12:22 --> Router Class Initialized
INFO - 2017-02-22 16:12:22 --> Output Class Initialized
INFO - 2017-02-22 16:12:22 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:22 --> Input Class Initialized
INFO - 2017-02-22 16:12:22 --> Language Class Initialized
INFO - 2017-02-22 16:12:22 --> Loader Class Initialized
INFO - 2017-02-22 16:12:22 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:22 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:22 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:22 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:22 --> Controller Class Initialized
INFO - 2017-02-22 16:12:22 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:22 --> Model Class Initialized
INFO - 2017-02-22 16:12:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:22 --> Config Class Initialized
INFO - 2017-02-22 16:12:22 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:22 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:22 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:22 --> URI Class Initialized
INFO - 2017-02-22 16:12:22 --> Router Class Initialized
INFO - 2017-02-22 16:12:22 --> Output Class Initialized
INFO - 2017-02-22 16:12:22 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:22 --> Input Class Initialized
INFO - 2017-02-22 16:12:22 --> Language Class Initialized
INFO - 2017-02-22 16:12:22 --> Loader Class Initialized
INFO - 2017-02-22 16:12:22 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:22 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:22 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:22 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:22 --> Controller Class Initialized
INFO - 2017-02-22 16:12:22 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:22 --> Model Class Initialized
INFO - 2017-02-22 16:12:22 --> Model Class Initialized
INFO - 2017-02-22 16:12:22 --> Model Class Initialized
INFO - 2017-02-22 16:12:22 --> Model Class Initialized
INFO - 2017-02-22 16:12:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:12:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-22 16:12:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:12:22 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:22 --> Total execution time: 0.1556
INFO - 2017-02-22 16:12:35 --> Config Class Initialized
INFO - 2017-02-22 16:12:35 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:35 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:35 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:35 --> URI Class Initialized
INFO - 2017-02-22 16:12:35 --> Router Class Initialized
INFO - 2017-02-22 16:12:35 --> Output Class Initialized
INFO - 2017-02-22 16:12:35 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:35 --> Input Class Initialized
INFO - 2017-02-22 16:12:35 --> Language Class Initialized
INFO - 2017-02-22 16:12:35 --> Loader Class Initialized
INFO - 2017-02-22 16:12:35 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:35 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:35 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:35 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:35 --> Controller Class Initialized
INFO - 2017-02-22 16:12:35 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:35 --> Model Class Initialized
INFO - 2017-02-22 16:12:35 --> Model Class Initialized
INFO - 2017-02-22 16:12:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:12:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-22 16:12:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:12:35 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:35 --> Total execution time: 0.1536
INFO - 2017-02-22 16:12:42 --> Config Class Initialized
INFO - 2017-02-22 16:12:42 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:42 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:42 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:42 --> URI Class Initialized
INFO - 2017-02-22 16:12:42 --> Router Class Initialized
INFO - 2017-02-22 16:12:42 --> Output Class Initialized
INFO - 2017-02-22 16:12:42 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:42 --> Input Class Initialized
INFO - 2017-02-22 16:12:42 --> Language Class Initialized
INFO - 2017-02-22 16:12:42 --> Loader Class Initialized
INFO - 2017-02-22 16:12:42 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:42 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:42 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:42 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:42 --> Controller Class Initialized
INFO - 2017-02-22 16:12:42 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:42 --> Model Class Initialized
INFO - 2017-02-22 16:12:42 --> Model Class Initialized
INFO - 2017-02-22 16:12:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:42 --> Config Class Initialized
INFO - 2017-02-22 16:12:42 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:42 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:42 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:42 --> URI Class Initialized
INFO - 2017-02-22 16:12:42 --> Router Class Initialized
INFO - 2017-02-22 16:12:42 --> Output Class Initialized
INFO - 2017-02-22 16:12:42 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:42 --> Input Class Initialized
INFO - 2017-02-22 16:12:42 --> Language Class Initialized
INFO - 2017-02-22 16:12:42 --> Loader Class Initialized
INFO - 2017-02-22 16:12:42 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:42 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:42 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:42 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:42 --> Controller Class Initialized
INFO - 2017-02-22 16:12:42 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:42 --> Model Class Initialized
INFO - 2017-02-22 16:12:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-22 16:12:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-22 16:12:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-22 16:12:42 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:42 --> Total execution time: 0.1067
INFO - 2017-02-22 16:12:47 --> Config Class Initialized
INFO - 2017-02-22 16:12:47 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:47 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:47 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:47 --> URI Class Initialized
INFO - 2017-02-22 16:12:47 --> Router Class Initialized
INFO - 2017-02-22 16:12:47 --> Output Class Initialized
INFO - 2017-02-22 16:12:47 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:47 --> Input Class Initialized
INFO - 2017-02-22 16:12:47 --> Language Class Initialized
INFO - 2017-02-22 16:12:47 --> Loader Class Initialized
INFO - 2017-02-22 16:12:47 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:47 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:47 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:47 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:47 --> Controller Class Initialized
INFO - 2017-02-22 16:12:47 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:47 --> Model Class Initialized
INFO - 2017-02-22 16:12:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:47 --> Config Class Initialized
INFO - 2017-02-22 16:12:47 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:47 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:47 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:47 --> URI Class Initialized
INFO - 2017-02-22 16:12:47 --> Router Class Initialized
INFO - 2017-02-22 16:12:47 --> Output Class Initialized
INFO - 2017-02-22 16:12:47 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:47 --> Input Class Initialized
INFO - 2017-02-22 16:12:47 --> Language Class Initialized
INFO - 2017-02-22 16:12:47 --> Loader Class Initialized
INFO - 2017-02-22 16:12:47 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:47 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:47 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:47 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:47 --> Controller Class Initialized
INFO - 2017-02-22 16:12:47 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:47 --> Model Class Initialized
INFO - 2017-02-22 16:12:47 --> Model Class Initialized
INFO - 2017-02-22 16:12:47 --> Model Class Initialized
INFO - 2017-02-22 16:12:47 --> Model Class Initialized
INFO - 2017-02-22 16:12:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:12:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-22 16:12:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:12:47 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:47 --> Total execution time: 0.1454
INFO - 2017-02-22 16:12:51 --> Config Class Initialized
INFO - 2017-02-22 16:12:51 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:51 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:51 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:51 --> URI Class Initialized
INFO - 2017-02-22 16:12:51 --> Router Class Initialized
INFO - 2017-02-22 16:12:51 --> Output Class Initialized
INFO - 2017-02-22 16:12:51 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:51 --> Input Class Initialized
INFO - 2017-02-22 16:12:51 --> Language Class Initialized
INFO - 2017-02-22 16:12:51 --> Loader Class Initialized
INFO - 2017-02-22 16:12:51 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:51 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:51 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:51 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:51 --> Controller Class Initialized
INFO - 2017-02-22 16:12:51 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:51 --> Model Class Initialized
INFO - 2017-02-22 16:12:51 --> Model Class Initialized
INFO - 2017-02-22 16:12:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:51 --> Config Class Initialized
INFO - 2017-02-22 16:12:51 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:51 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:51 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:51 --> URI Class Initialized
INFO - 2017-02-22 16:12:51 --> Router Class Initialized
INFO - 2017-02-22 16:12:51 --> Output Class Initialized
INFO - 2017-02-22 16:12:51 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:51 --> Input Class Initialized
INFO - 2017-02-22 16:12:51 --> Language Class Initialized
INFO - 2017-02-22 16:12:51 --> Loader Class Initialized
INFO - 2017-02-22 16:12:51 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:51 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:51 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:51 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:51 --> Controller Class Initialized
INFO - 2017-02-22 16:12:51 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:51 --> Model Class Initialized
INFO - 2017-02-22 16:12:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-22 16:12:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-22 16:12:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-22 16:12:51 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:51 --> Total execution time: 0.1352
INFO - 2017-02-22 16:12:57 --> Config Class Initialized
INFO - 2017-02-22 16:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:57 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:57 --> URI Class Initialized
INFO - 2017-02-22 16:12:57 --> Router Class Initialized
INFO - 2017-02-22 16:12:57 --> Output Class Initialized
INFO - 2017-02-22 16:12:57 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:57 --> Input Class Initialized
INFO - 2017-02-22 16:12:57 --> Language Class Initialized
INFO - 2017-02-22 16:12:57 --> Loader Class Initialized
INFO - 2017-02-22 16:12:57 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:57 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:57 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:57 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:57 --> Controller Class Initialized
INFO - 2017-02-22 16:12:57 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:57 --> Model Class Initialized
INFO - 2017-02-22 16:12:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:57 --> Config Class Initialized
INFO - 2017-02-22 16:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:12:57 --> Utf8 Class Initialized
INFO - 2017-02-22 16:12:57 --> URI Class Initialized
INFO - 2017-02-22 16:12:57 --> Router Class Initialized
INFO - 2017-02-22 16:12:57 --> Output Class Initialized
INFO - 2017-02-22 16:12:57 --> Security Class Initialized
DEBUG - 2017-02-22 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:12:57 --> Input Class Initialized
INFO - 2017-02-22 16:12:57 --> Language Class Initialized
INFO - 2017-02-22 16:12:57 --> Loader Class Initialized
INFO - 2017-02-22 16:12:57 --> Helper loaded: url_helper
INFO - 2017-02-22 16:12:57 --> Helper loaded: language_helper
INFO - 2017-02-22 16:12:57 --> Helper loaded: html_helper
INFO - 2017-02-22 16:12:57 --> Helper loaded: form_helper
INFO - 2017-02-22 16:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:12:57 --> Controller Class Initialized
INFO - 2017-02-22 16:12:57 --> Database Driver Class Initialized
INFO - 2017-02-22 16:12:57 --> Model Class Initialized
INFO - 2017-02-22 16:12:57 --> Model Class Initialized
INFO - 2017-02-22 16:12:57 --> Model Class Initialized
INFO - 2017-02-22 16:12:57 --> Model Class Initialized
INFO - 2017-02-22 16:12:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:12:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:12:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-22 16:12:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:12:57 --> Final output sent to browser
DEBUG - 2017-02-22 16:12:57 --> Total execution time: 0.1636
INFO - 2017-02-22 16:13:01 --> Config Class Initialized
INFO - 2017-02-22 16:13:01 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:13:01 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:13:01 --> Utf8 Class Initialized
INFO - 2017-02-22 16:13:01 --> URI Class Initialized
INFO - 2017-02-22 16:13:01 --> Router Class Initialized
INFO - 2017-02-22 16:13:01 --> Output Class Initialized
INFO - 2017-02-22 16:13:01 --> Security Class Initialized
DEBUG - 2017-02-22 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:13:01 --> Input Class Initialized
INFO - 2017-02-22 16:13:01 --> Language Class Initialized
INFO - 2017-02-22 16:13:01 --> Loader Class Initialized
INFO - 2017-02-22 16:13:01 --> Helper loaded: url_helper
INFO - 2017-02-22 16:13:01 --> Helper loaded: language_helper
INFO - 2017-02-22 16:13:01 --> Helper loaded: html_helper
INFO - 2017-02-22 16:13:01 --> Helper loaded: form_helper
INFO - 2017-02-22 16:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:13:01 --> Controller Class Initialized
INFO - 2017-02-22 16:13:01 --> Database Driver Class Initialized
INFO - 2017-02-22 16:13:01 --> Model Class Initialized
INFO - 2017-02-22 16:13:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:13:01 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:13:01 --> Pagination Class Initialized
INFO - 2017-02-22 16:13:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:13:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:13:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:13:01 --> Final output sent to browser
DEBUG - 2017-02-22 16:13:01 --> Total execution time: 0.1455
INFO - 2017-02-22 16:13:19 --> Config Class Initialized
INFO - 2017-02-22 16:13:19 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:13:19 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:13:19 --> Utf8 Class Initialized
INFO - 2017-02-22 16:13:19 --> URI Class Initialized
INFO - 2017-02-22 16:13:19 --> Router Class Initialized
INFO - 2017-02-22 16:13:19 --> Output Class Initialized
INFO - 2017-02-22 16:13:19 --> Security Class Initialized
DEBUG - 2017-02-22 16:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:13:19 --> Input Class Initialized
INFO - 2017-02-22 16:13:19 --> Language Class Initialized
INFO - 2017-02-22 16:13:19 --> Loader Class Initialized
INFO - 2017-02-22 16:13:19 --> Helper loaded: url_helper
INFO - 2017-02-22 16:13:19 --> Helper loaded: language_helper
INFO - 2017-02-22 16:13:19 --> Helper loaded: html_helper
INFO - 2017-02-22 16:13:19 --> Helper loaded: form_helper
INFO - 2017-02-22 16:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:13:19 --> Controller Class Initialized
INFO - 2017-02-22 16:13:19 --> Database Driver Class Initialized
INFO - 2017-02-22 16:13:19 --> Model Class Initialized
INFO - 2017-02-22 16:13:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:13:19 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:13:19 --> Pagination Class Initialized
INFO - 2017-02-22 16:13:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:13:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:13:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:13:19 --> Final output sent to browser
DEBUG - 2017-02-22 16:13:19 --> Total execution time: 0.1549
INFO - 2017-02-22 16:13:52 --> Config Class Initialized
INFO - 2017-02-22 16:13:52 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:13:52 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:13:52 --> Utf8 Class Initialized
INFO - 2017-02-22 16:13:52 --> URI Class Initialized
INFO - 2017-02-22 16:13:52 --> Router Class Initialized
INFO - 2017-02-22 16:13:52 --> Output Class Initialized
INFO - 2017-02-22 16:13:52 --> Security Class Initialized
DEBUG - 2017-02-22 16:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:13:52 --> Input Class Initialized
INFO - 2017-02-22 16:13:52 --> Language Class Initialized
INFO - 2017-02-22 16:13:52 --> Loader Class Initialized
INFO - 2017-02-22 16:13:52 --> Helper loaded: url_helper
INFO - 2017-02-22 16:13:52 --> Helper loaded: language_helper
INFO - 2017-02-22 16:13:52 --> Helper loaded: html_helper
INFO - 2017-02-22 16:13:52 --> Helper loaded: form_helper
INFO - 2017-02-22 16:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:13:52 --> Controller Class Initialized
INFO - 2017-02-22 16:13:52 --> Database Driver Class Initialized
INFO - 2017-02-22 16:13:52 --> Model Class Initialized
INFO - 2017-02-22 16:13:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:13:52 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-02-22 16:13:52 --> Pagination Class Initialized
INFO - 2017-02-22 16:13:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:13:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-02-22 16:13:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:13:52 --> Final output sent to browser
DEBUG - 2017-02-22 16:13:52 --> Total execution time: 0.1795
INFO - 2017-02-22 16:13:57 --> Config Class Initialized
INFO - 2017-02-22 16:13:57 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:13:57 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:13:57 --> Utf8 Class Initialized
INFO - 2017-02-22 16:13:57 --> URI Class Initialized
INFO - 2017-02-22 16:13:57 --> Router Class Initialized
INFO - 2017-02-22 16:13:57 --> Output Class Initialized
INFO - 2017-02-22 16:13:57 --> Security Class Initialized
DEBUG - 2017-02-22 16:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:13:57 --> Input Class Initialized
INFO - 2017-02-22 16:13:57 --> Language Class Initialized
INFO - 2017-02-22 16:13:57 --> Loader Class Initialized
INFO - 2017-02-22 16:13:57 --> Helper loaded: url_helper
INFO - 2017-02-22 16:13:57 --> Helper loaded: language_helper
INFO - 2017-02-22 16:13:57 --> Helper loaded: html_helper
INFO - 2017-02-22 16:13:57 --> Helper loaded: form_helper
INFO - 2017-02-22 16:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:13:57 --> Controller Class Initialized
INFO - 2017-02-22 16:13:57 --> Database Driver Class Initialized
INFO - 2017-02-22 16:13:57 --> Model Class Initialized
INFO - 2017-02-22 16:13:57 --> Model Class Initialized
INFO - 2017-02-22 16:13:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:13:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-22 16:13:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-22 16:13:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:13:57 --> Final output sent to browser
DEBUG - 2017-02-22 16:13:57 --> Total execution time: 0.1255
INFO - 2017-02-22 16:14:05 --> Config Class Initialized
INFO - 2017-02-22 16:14:05 --> Hooks Class Initialized
DEBUG - 2017-02-22 16:14:05 --> UTF-8 Support Enabled
INFO - 2017-02-22 16:14:05 --> Utf8 Class Initialized
INFO - 2017-02-22 16:14:05 --> URI Class Initialized
INFO - 2017-02-22 16:14:05 --> Router Class Initialized
INFO - 2017-02-22 16:14:05 --> Output Class Initialized
INFO - 2017-02-22 16:14:05 --> Security Class Initialized
DEBUG - 2017-02-22 16:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-22 16:14:05 --> Input Class Initialized
INFO - 2017-02-22 16:14:05 --> Language Class Initialized
INFO - 2017-02-22 16:14:05 --> Loader Class Initialized
INFO - 2017-02-22 16:14:05 --> Helper loaded: url_helper
INFO - 2017-02-22 16:14:05 --> Helper loaded: language_helper
INFO - 2017-02-22 16:14:05 --> Helper loaded: html_helper
INFO - 2017-02-22 16:14:05 --> Helper loaded: form_helper
INFO - 2017-02-22 16:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-22 16:14:05 --> Controller Class Initialized
INFO - 2017-02-22 16:14:05 --> Database Driver Class Initialized
INFO - 2017-02-22 16:14:05 --> Model Class Initialized
INFO - 2017-02-22 16:14:05 --> Model Class Initialized
INFO - 2017-02-22 16:14:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-22 16:14:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-22 16:14:05 --> Could not find the language line "import_user"
INFO - 2017-02-22 16:14:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-22 16:14:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-22 16:14:05 --> Final output sent to browser
DEBUG - 2017-02-22 16:14:05 --> Total execution time: 0.1604
