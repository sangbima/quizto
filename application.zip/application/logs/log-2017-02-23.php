<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-23 09:58:01 --> Config Class Initialized
INFO - 2017-02-23 09:58:01 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:01 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:01 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:01 --> URI Class Initialized
INFO - 2017-02-23 09:58:01 --> Router Class Initialized
INFO - 2017-02-23 09:58:01 --> Output Class Initialized
INFO - 2017-02-23 09:58:01 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:01 --> Input Class Initialized
INFO - 2017-02-23 09:58:01 --> Language Class Initialized
INFO - 2017-02-23 09:58:01 --> Loader Class Initialized
INFO - 2017-02-23 09:58:01 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:01 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:01 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:01 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:01 --> Controller Class Initialized
INFO - 2017-02-23 09:58:01 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:02 --> Model Class Initialized
INFO - 2017-02-23 09:58:02 --> Model Class Initialized
INFO - 2017-02-23 09:58:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:02 --> Config Class Initialized
INFO - 2017-02-23 09:58:02 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:02 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:02 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:02 --> URI Class Initialized
INFO - 2017-02-23 09:58:02 --> Router Class Initialized
INFO - 2017-02-23 09:58:02 --> Output Class Initialized
INFO - 2017-02-23 09:58:02 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:02 --> Input Class Initialized
INFO - 2017-02-23 09:58:02 --> Language Class Initialized
INFO - 2017-02-23 09:58:02 --> Loader Class Initialized
INFO - 2017-02-23 09:58:02 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:02 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:02 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:02 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:02 --> Controller Class Initialized
INFO - 2017-02-23 09:58:02 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:02 --> Model Class Initialized
INFO - 2017-02-23 09:58:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-23 09:58:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-23 09:58:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-23 09:58:02 --> Final output sent to browser
DEBUG - 2017-02-23 09:58:02 --> Total execution time: 0.0947
INFO - 2017-02-23 09:58:07 --> Config Class Initialized
INFO - 2017-02-23 09:58:07 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:07 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:07 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:07 --> URI Class Initialized
INFO - 2017-02-23 09:58:07 --> Router Class Initialized
INFO - 2017-02-23 09:58:07 --> Output Class Initialized
INFO - 2017-02-23 09:58:07 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:07 --> Input Class Initialized
INFO - 2017-02-23 09:58:07 --> Language Class Initialized
INFO - 2017-02-23 09:58:07 --> Loader Class Initialized
INFO - 2017-02-23 09:58:07 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:07 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:07 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:07 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:07 --> Controller Class Initialized
INFO - 2017-02-23 09:58:07 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:07 --> Model Class Initialized
INFO - 2017-02-23 09:58:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:07 --> Config Class Initialized
INFO - 2017-02-23 09:58:07 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:07 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:07 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:07 --> URI Class Initialized
INFO - 2017-02-23 09:58:07 --> Router Class Initialized
INFO - 2017-02-23 09:58:07 --> Output Class Initialized
INFO - 2017-02-23 09:58:07 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:07 --> Input Class Initialized
INFO - 2017-02-23 09:58:07 --> Language Class Initialized
INFO - 2017-02-23 09:58:07 --> Loader Class Initialized
INFO - 2017-02-23 09:58:07 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:07 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:07 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:07 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:07 --> Controller Class Initialized
INFO - 2017-02-23 09:58:07 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:07 --> Model Class Initialized
INFO - 2017-02-23 09:58:07 --> Model Class Initialized
INFO - 2017-02-23 09:58:07 --> Model Class Initialized
INFO - 2017-02-23 09:58:07 --> Model Class Initialized
INFO - 2017-02-23 09:58:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 09:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-23 09:58:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 09:58:07 --> Final output sent to browser
DEBUG - 2017-02-23 09:58:07 --> Total execution time: 0.1646
INFO - 2017-02-23 09:58:18 --> Config Class Initialized
INFO - 2017-02-23 09:58:18 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:18 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:18 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:18 --> URI Class Initialized
INFO - 2017-02-23 09:58:18 --> Router Class Initialized
INFO - 2017-02-23 09:58:18 --> Output Class Initialized
INFO - 2017-02-23 09:58:18 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:18 --> Input Class Initialized
INFO - 2017-02-23 09:58:18 --> Language Class Initialized
INFO - 2017-02-23 09:58:18 --> Loader Class Initialized
INFO - 2017-02-23 09:58:18 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:18 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:18 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:18 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:18 --> Controller Class Initialized
INFO - 2017-02-23 09:58:18 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:18 --> Model Class Initialized
INFO - 2017-02-23 09:58:18 --> Model Class Initialized
INFO - 2017-02-23 09:58:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-23 09:58:18 --> Could not find the language line "import_user"
INFO - 2017-02-23 09:58:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-23 09:58:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 09:58:18 --> Final output sent to browser
DEBUG - 2017-02-23 09:58:18 --> Total execution time: 0.1110
INFO - 2017-02-23 09:58:20 --> Config Class Initialized
INFO - 2017-02-23 09:58:20 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:21 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:21 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:21 --> URI Class Initialized
INFO - 2017-02-23 09:58:21 --> Router Class Initialized
INFO - 2017-02-23 09:58:21 --> Output Class Initialized
INFO - 2017-02-23 09:58:21 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:21 --> Input Class Initialized
INFO - 2017-02-23 09:58:21 --> Language Class Initialized
INFO - 2017-02-23 09:58:21 --> Loader Class Initialized
INFO - 2017-02-23 09:58:21 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:21 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:21 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:21 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:21 --> Controller Class Initialized
INFO - 2017-02-23 09:58:21 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:21 --> Model Class Initialized
INFO - 2017-02-23 09:58:21 --> Model Class Initialized
INFO - 2017-02-23 09:58:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 09:58:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-23 09:58:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 09:58:21 --> Final output sent to browser
DEBUG - 2017-02-23 09:58:21 --> Total execution time: 0.1038
INFO - 2017-02-23 09:58:26 --> Config Class Initialized
INFO - 2017-02-23 09:58:26 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:26 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:26 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:26 --> URI Class Initialized
INFO - 2017-02-23 09:58:26 --> Router Class Initialized
INFO - 2017-02-23 09:58:26 --> Output Class Initialized
INFO - 2017-02-23 09:58:26 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:26 --> Input Class Initialized
INFO - 2017-02-23 09:58:26 --> Language Class Initialized
INFO - 2017-02-23 09:58:26 --> Loader Class Initialized
INFO - 2017-02-23 09:58:26 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:26 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:26 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:26 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:26 --> Controller Class Initialized
INFO - 2017-02-23 09:58:26 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:26 --> Model Class Initialized
INFO - 2017-02-23 09:58:26 --> Model Class Initialized
INFO - 2017-02-23 09:58:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:26 --> Config Class Initialized
INFO - 2017-02-23 09:58:26 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:26 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:26 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:26 --> URI Class Initialized
INFO - 2017-02-23 09:58:26 --> Router Class Initialized
INFO - 2017-02-23 09:58:26 --> Output Class Initialized
INFO - 2017-02-23 09:58:26 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:26 --> Input Class Initialized
INFO - 2017-02-23 09:58:26 --> Language Class Initialized
INFO - 2017-02-23 09:58:26 --> Loader Class Initialized
INFO - 2017-02-23 09:58:26 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:26 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:26 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:26 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:26 --> Controller Class Initialized
INFO - 2017-02-23 09:58:26 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:26 --> Model Class Initialized
INFO - 2017-02-23 09:58:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-23 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-23 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-23 09:58:26 --> Final output sent to browser
DEBUG - 2017-02-23 09:58:26 --> Total execution time: 0.0808
INFO - 2017-02-23 09:58:31 --> Config Class Initialized
INFO - 2017-02-23 09:58:31 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:31 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:31 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:31 --> URI Class Initialized
INFO - 2017-02-23 09:58:31 --> Router Class Initialized
INFO - 2017-02-23 09:58:31 --> Output Class Initialized
INFO - 2017-02-23 09:58:31 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:31 --> Input Class Initialized
INFO - 2017-02-23 09:58:31 --> Language Class Initialized
INFO - 2017-02-23 09:58:31 --> Loader Class Initialized
INFO - 2017-02-23 09:58:31 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:31 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:31 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:31 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:31 --> Controller Class Initialized
INFO - 2017-02-23 09:58:31 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:31 --> Model Class Initialized
INFO - 2017-02-23 09:58:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:31 --> Config Class Initialized
INFO - 2017-02-23 09:58:31 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:31 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:31 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:31 --> URI Class Initialized
INFO - 2017-02-23 09:58:31 --> Router Class Initialized
INFO - 2017-02-23 09:58:31 --> Output Class Initialized
INFO - 2017-02-23 09:58:31 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:31 --> Input Class Initialized
INFO - 2017-02-23 09:58:31 --> Language Class Initialized
INFO - 2017-02-23 09:58:31 --> Loader Class Initialized
INFO - 2017-02-23 09:58:31 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:31 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:31 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:31 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:31 --> Controller Class Initialized
INFO - 2017-02-23 09:58:31 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:31 --> Model Class Initialized
INFO - 2017-02-23 09:58:31 --> Model Class Initialized
INFO - 2017-02-23 09:58:31 --> Model Class Initialized
INFO - 2017-02-23 09:58:31 --> Model Class Initialized
INFO - 2017-02-23 09:58:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 09:58:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-23 09:58:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 09:58:31 --> Final output sent to browser
DEBUG - 2017-02-23 09:58:31 --> Total execution time: 0.1142
INFO - 2017-02-23 09:58:36 --> Config Class Initialized
INFO - 2017-02-23 09:58:36 --> Hooks Class Initialized
DEBUG - 2017-02-23 09:58:36 --> UTF-8 Support Enabled
INFO - 2017-02-23 09:58:36 --> Utf8 Class Initialized
INFO - 2017-02-23 09:58:36 --> URI Class Initialized
INFO - 2017-02-23 09:58:36 --> Router Class Initialized
INFO - 2017-02-23 09:58:36 --> Output Class Initialized
INFO - 2017-02-23 09:58:36 --> Security Class Initialized
DEBUG - 2017-02-23 09:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 09:58:36 --> Input Class Initialized
INFO - 2017-02-23 09:58:36 --> Language Class Initialized
INFO - 2017-02-23 09:58:36 --> Loader Class Initialized
INFO - 2017-02-23 09:58:36 --> Helper loaded: url_helper
INFO - 2017-02-23 09:58:36 --> Helper loaded: language_helper
INFO - 2017-02-23 09:58:36 --> Helper loaded: html_helper
INFO - 2017-02-23 09:58:36 --> Helper loaded: form_helper
INFO - 2017-02-23 09:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 09:58:36 --> Controller Class Initialized
INFO - 2017-02-23 09:58:36 --> Database Driver Class Initialized
INFO - 2017-02-23 09:58:36 --> Model Class Initialized
INFO - 2017-02-23 09:58:36 --> Model Class Initialized
INFO - 2017-02-23 09:58:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 09:58:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-23 09:58:36 --> Could not find the language line "import_user"
INFO - 2017-02-23 09:58:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-23 09:58:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 09:58:36 --> Final output sent to browser
DEBUG - 2017-02-23 09:58:36 --> Total execution time: 0.1000
INFO - 2017-02-23 10:03:34 --> Config Class Initialized
INFO - 2017-02-23 10:03:34 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:03:34 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:03:34 --> Utf8 Class Initialized
INFO - 2017-02-23 10:03:34 --> URI Class Initialized
INFO - 2017-02-23 10:03:34 --> Router Class Initialized
INFO - 2017-02-23 10:03:34 --> Output Class Initialized
INFO - 2017-02-23 10:03:34 --> Security Class Initialized
DEBUG - 2017-02-23 10:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:03:34 --> Input Class Initialized
INFO - 2017-02-23 10:03:34 --> Language Class Initialized
INFO - 2017-02-23 10:03:34 --> Loader Class Initialized
INFO - 2017-02-23 10:03:34 --> Helper loaded: url_helper
INFO - 2017-02-23 10:03:34 --> Helper loaded: language_helper
INFO - 2017-02-23 10:03:34 --> Helper loaded: html_helper
INFO - 2017-02-23 10:03:34 --> Helper loaded: form_helper
INFO - 2017-02-23 10:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:03:34 --> Controller Class Initialized
INFO - 2017-02-23 10:03:34 --> Database Driver Class Initialized
INFO - 2017-02-23 10:03:34 --> Model Class Initialized
INFO - 2017-02-23 10:03:34 --> Model Class Initialized
INFO - 2017-02-23 10:03:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:03:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:03:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:03:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:03:35 --> Final output sent to browser
DEBUG - 2017-02-23 10:03:35 --> Total execution time: 0.3507
INFO - 2017-02-23 10:08:24 --> Config Class Initialized
INFO - 2017-02-23 10:08:24 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:08:24 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:08:24 --> Utf8 Class Initialized
INFO - 2017-02-23 10:08:24 --> URI Class Initialized
INFO - 2017-02-23 10:08:24 --> Router Class Initialized
INFO - 2017-02-23 10:08:24 --> Output Class Initialized
INFO - 2017-02-23 10:08:24 --> Security Class Initialized
DEBUG - 2017-02-23 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:08:24 --> Input Class Initialized
INFO - 2017-02-23 10:08:24 --> Language Class Initialized
INFO - 2017-02-23 10:08:24 --> Loader Class Initialized
INFO - 2017-02-23 10:08:24 --> Helper loaded: url_helper
INFO - 2017-02-23 10:08:24 --> Helper loaded: language_helper
INFO - 2017-02-23 10:08:24 --> Helper loaded: html_helper
INFO - 2017-02-23 10:08:24 --> Helper loaded: form_helper
INFO - 2017-02-23 10:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:08:24 --> Controller Class Initialized
INFO - 2017-02-23 10:08:24 --> Database Driver Class Initialized
INFO - 2017-02-23 10:08:24 --> Model Class Initialized
INFO - 2017-02-23 10:08:24 --> Model Class Initialized
INFO - 2017-02-23 10:08:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:08:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:08:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:08:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:08:24 --> Final output sent to browser
DEBUG - 2017-02-23 10:08:24 --> Total execution time: 0.2153
INFO - 2017-02-23 10:08:36 --> Config Class Initialized
INFO - 2017-02-23 10:08:36 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:08:36 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:08:36 --> Utf8 Class Initialized
INFO - 2017-02-23 10:08:36 --> URI Class Initialized
INFO - 2017-02-23 10:08:36 --> Router Class Initialized
INFO - 2017-02-23 10:08:36 --> Output Class Initialized
INFO - 2017-02-23 10:08:36 --> Security Class Initialized
DEBUG - 2017-02-23 10:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:08:36 --> Input Class Initialized
INFO - 2017-02-23 10:08:36 --> Language Class Initialized
INFO - 2017-02-23 10:08:36 --> Loader Class Initialized
INFO - 2017-02-23 10:08:36 --> Helper loaded: url_helper
INFO - 2017-02-23 10:08:36 --> Helper loaded: language_helper
INFO - 2017-02-23 10:08:36 --> Helper loaded: html_helper
INFO - 2017-02-23 10:08:36 --> Helper loaded: form_helper
INFO - 2017-02-23 10:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:08:36 --> Controller Class Initialized
INFO - 2017-02-23 10:08:36 --> Database Driver Class Initialized
INFO - 2017-02-23 10:08:36 --> Model Class Initialized
INFO - 2017-02-23 10:08:36 --> Model Class Initialized
INFO - 2017-02-23 10:08:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:08:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:08:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:08:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:08:36 --> Final output sent to browser
DEBUG - 2017-02-23 10:08:36 --> Total execution time: 0.2866
INFO - 2017-02-23 10:16:17 --> Config Class Initialized
INFO - 2017-02-23 10:16:17 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:16:17 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:16:17 --> Utf8 Class Initialized
INFO - 2017-02-23 10:16:17 --> URI Class Initialized
INFO - 2017-02-23 10:16:17 --> Router Class Initialized
INFO - 2017-02-23 10:16:17 --> Output Class Initialized
INFO - 2017-02-23 10:16:17 --> Security Class Initialized
DEBUG - 2017-02-23 10:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:16:17 --> Input Class Initialized
INFO - 2017-02-23 10:16:17 --> Language Class Initialized
INFO - 2017-02-23 10:16:17 --> Loader Class Initialized
INFO - 2017-02-23 10:16:17 --> Helper loaded: url_helper
INFO - 2017-02-23 10:16:17 --> Helper loaded: language_helper
INFO - 2017-02-23 10:16:17 --> Helper loaded: html_helper
INFO - 2017-02-23 10:16:17 --> Helper loaded: form_helper
INFO - 2017-02-23 10:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:16:17 --> Controller Class Initialized
INFO - 2017-02-23 10:16:17 --> Database Driver Class Initialized
INFO - 2017-02-23 10:16:17 --> Model Class Initialized
INFO - 2017-02-23 10:16:17 --> Model Class Initialized
INFO - 2017-02-23 10:16:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:16:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:16:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:16:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:16:18 --> Final output sent to browser
DEBUG - 2017-02-23 10:16:18 --> Total execution time: 0.3632
INFO - 2017-02-23 10:21:21 --> Config Class Initialized
INFO - 2017-02-23 10:21:21 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:21 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:21 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:21 --> URI Class Initialized
INFO - 2017-02-23 10:21:21 --> Router Class Initialized
INFO - 2017-02-23 10:21:21 --> Output Class Initialized
INFO - 2017-02-23 10:21:21 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:21 --> Input Class Initialized
INFO - 2017-02-23 10:21:21 --> Language Class Initialized
INFO - 2017-02-23 10:21:21 --> Loader Class Initialized
INFO - 2017-02-23 10:21:21 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:21 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:21 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:21 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:21 --> Controller Class Initialized
INFO - 2017-02-23 10:21:21 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:21 --> Model Class Initialized
INFO - 2017-02-23 10:21:21 --> Model Class Initialized
INFO - 2017-02-23 10:21:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:21:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:21:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:21:21 --> Final output sent to browser
DEBUG - 2017-02-23 10:21:21 --> Total execution time: 0.1144
INFO - 2017-02-23 10:21:31 --> Config Class Initialized
INFO - 2017-02-23 10:21:31 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:31 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:31 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:31 --> URI Class Initialized
INFO - 2017-02-23 10:21:31 --> Router Class Initialized
INFO - 2017-02-23 10:21:31 --> Output Class Initialized
INFO - 2017-02-23 10:21:31 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:31 --> Input Class Initialized
INFO - 2017-02-23 10:21:31 --> Language Class Initialized
INFO - 2017-02-23 10:21:31 --> Loader Class Initialized
INFO - 2017-02-23 10:21:31 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:31 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:31 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:31 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:31 --> Controller Class Initialized
INFO - 2017-02-23 10:21:31 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:31 --> Model Class Initialized
INFO - 2017-02-23 10:21:31 --> Model Class Initialized
INFO - 2017-02-23 10:21:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-02-23 10:21:31 --> Could not find the language line "import_user"
INFO - 2017-02-23 10:21:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-02-23 10:21:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:21:31 --> Final output sent to browser
DEBUG - 2017-02-23 10:21:31 --> Total execution time: 0.0888
INFO - 2017-02-23 10:21:34 --> Config Class Initialized
INFO - 2017-02-23 10:21:34 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:34 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:34 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:34 --> URI Class Initialized
INFO - 2017-02-23 10:21:34 --> Router Class Initialized
INFO - 2017-02-23 10:21:34 --> Output Class Initialized
INFO - 2017-02-23 10:21:34 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:34 --> Input Class Initialized
INFO - 2017-02-23 10:21:34 --> Language Class Initialized
INFO - 2017-02-23 10:21:34 --> Loader Class Initialized
INFO - 2017-02-23 10:21:34 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:34 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:34 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:34 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:34 --> Controller Class Initialized
INFO - 2017-02-23 10:21:34 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:34 --> Model Class Initialized
INFO - 2017-02-23 10:21:34 --> Model Class Initialized
INFO - 2017-02-23 10:21:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:35 --> Config Class Initialized
INFO - 2017-02-23 10:21:35 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:35 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:35 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:35 --> URI Class Initialized
INFO - 2017-02-23 10:21:35 --> Router Class Initialized
INFO - 2017-02-23 10:21:35 --> Output Class Initialized
INFO - 2017-02-23 10:21:35 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:35 --> Input Class Initialized
INFO - 2017-02-23 10:21:35 --> Language Class Initialized
INFO - 2017-02-23 10:21:35 --> Loader Class Initialized
INFO - 2017-02-23 10:21:35 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:35 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:35 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:35 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:35 --> Controller Class Initialized
INFO - 2017-02-23 10:21:35 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:35 --> Model Class Initialized
INFO - 2017-02-23 10:21:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-23 10:21:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-23 10:21:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-23 10:21:35 --> Final output sent to browser
DEBUG - 2017-02-23 10:21:35 --> Total execution time: 0.0721
INFO - 2017-02-23 10:21:40 --> Config Class Initialized
INFO - 2017-02-23 10:21:40 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:40 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:40 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:40 --> URI Class Initialized
INFO - 2017-02-23 10:21:40 --> Router Class Initialized
INFO - 2017-02-23 10:21:40 --> Output Class Initialized
INFO - 2017-02-23 10:21:40 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:40 --> Input Class Initialized
INFO - 2017-02-23 10:21:40 --> Language Class Initialized
INFO - 2017-02-23 10:21:40 --> Loader Class Initialized
INFO - 2017-02-23 10:21:40 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:40 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:40 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:40 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:40 --> Controller Class Initialized
INFO - 2017-02-23 10:21:40 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:40 --> Model Class Initialized
INFO - 2017-02-23 10:21:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:40 --> Config Class Initialized
INFO - 2017-02-23 10:21:40 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:40 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:40 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:40 --> URI Class Initialized
INFO - 2017-02-23 10:21:40 --> Router Class Initialized
INFO - 2017-02-23 10:21:40 --> Output Class Initialized
INFO - 2017-02-23 10:21:40 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:40 --> Input Class Initialized
INFO - 2017-02-23 10:21:40 --> Language Class Initialized
INFO - 2017-02-23 10:21:40 --> Loader Class Initialized
INFO - 2017-02-23 10:21:40 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:40 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:40 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:40 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:40 --> Controller Class Initialized
INFO - 2017-02-23 10:21:40 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:40 --> Model Class Initialized
INFO - 2017-02-23 10:21:40 --> Model Class Initialized
INFO - 2017-02-23 10:21:40 --> Model Class Initialized
INFO - 2017-02-23 10:21:40 --> Model Class Initialized
INFO - 2017-02-23 10:21:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:21:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-23 10:21:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:21:40 --> Final output sent to browser
DEBUG - 2017-02-23 10:21:40 --> Total execution time: 0.1010
INFO - 2017-02-23 10:21:46 --> Config Class Initialized
INFO - 2017-02-23 10:21:46 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:46 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:46 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:46 --> URI Class Initialized
INFO - 2017-02-23 10:21:46 --> Router Class Initialized
INFO - 2017-02-23 10:21:46 --> Output Class Initialized
INFO - 2017-02-23 10:21:46 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:46 --> Input Class Initialized
INFO - 2017-02-23 10:21:46 --> Language Class Initialized
INFO - 2017-02-23 10:21:46 --> Loader Class Initialized
INFO - 2017-02-23 10:21:46 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:46 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:46 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:46 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:46 --> Controller Class Initialized
INFO - 2017-02-23 10:21:46 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:46 --> Model Class Initialized
INFO - 2017-02-23 10:21:46 --> Model Class Initialized
INFO - 2017-02-23 10:21:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:21:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:21:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:21:46 --> Final output sent to browser
DEBUG - 2017-02-23 10:21:46 --> Total execution time: 0.2073
INFO - 2017-02-23 10:21:53 --> Config Class Initialized
INFO - 2017-02-23 10:21:53 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:53 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:53 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:53 --> URI Class Initialized
INFO - 2017-02-23 10:21:53 --> Router Class Initialized
INFO - 2017-02-23 10:21:53 --> Output Class Initialized
INFO - 2017-02-23 10:21:53 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:53 --> Input Class Initialized
INFO - 2017-02-23 10:21:53 --> Language Class Initialized
INFO - 2017-02-23 10:21:53 --> Loader Class Initialized
INFO - 2017-02-23 10:21:53 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:53 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:53 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:53 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:53 --> Controller Class Initialized
INFO - 2017-02-23 10:21:53 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:53 --> Model Class Initialized
INFO - 2017-02-23 10:21:53 --> Model Class Initialized
INFO - 2017-02-23 10:21:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:21:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:21:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:21:53 --> Final output sent to browser
DEBUG - 2017-02-23 10:21:53 --> Total execution time: 0.1147
INFO - 2017-02-23 10:21:58 --> Config Class Initialized
INFO - 2017-02-23 10:21:58 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:21:58 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:21:58 --> Utf8 Class Initialized
INFO - 2017-02-23 10:21:58 --> URI Class Initialized
INFO - 2017-02-23 10:21:58 --> Router Class Initialized
INFO - 2017-02-23 10:21:58 --> Output Class Initialized
INFO - 2017-02-23 10:21:58 --> Security Class Initialized
DEBUG - 2017-02-23 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:21:58 --> Input Class Initialized
INFO - 2017-02-23 10:21:58 --> Language Class Initialized
INFO - 2017-02-23 10:21:58 --> Loader Class Initialized
INFO - 2017-02-23 10:21:58 --> Helper loaded: url_helper
INFO - 2017-02-23 10:21:58 --> Helper loaded: language_helper
INFO - 2017-02-23 10:21:58 --> Helper loaded: html_helper
INFO - 2017-02-23 10:21:58 --> Helper loaded: form_helper
INFO - 2017-02-23 10:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:21:58 --> Controller Class Initialized
INFO - 2017-02-23 10:21:58 --> Database Driver Class Initialized
INFO - 2017-02-23 10:21:58 --> Model Class Initialized
INFO - 2017-02-23 10:21:58 --> Model Class Initialized
INFO - 2017-02-23 10:21:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:21:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:21:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:21:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:21:58 --> Final output sent to browser
DEBUG - 2017-02-23 10:21:58 --> Total execution time: 0.1094
INFO - 2017-02-23 10:22:05 --> Config Class Initialized
INFO - 2017-02-23 10:22:05 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:22:05 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:22:05 --> Utf8 Class Initialized
INFO - 2017-02-23 10:22:05 --> URI Class Initialized
INFO - 2017-02-23 10:22:05 --> Router Class Initialized
INFO - 2017-02-23 10:22:05 --> Output Class Initialized
INFO - 2017-02-23 10:22:05 --> Security Class Initialized
DEBUG - 2017-02-23 10:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:22:05 --> Input Class Initialized
INFO - 2017-02-23 10:22:05 --> Language Class Initialized
INFO - 2017-02-23 10:22:05 --> Loader Class Initialized
INFO - 2017-02-23 10:22:05 --> Helper loaded: url_helper
INFO - 2017-02-23 10:22:05 --> Helper loaded: language_helper
INFO - 2017-02-23 10:22:05 --> Helper loaded: html_helper
INFO - 2017-02-23 10:22:05 --> Helper loaded: form_helper
INFO - 2017-02-23 10:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:22:05 --> Controller Class Initialized
INFO - 2017-02-23 10:22:05 --> Database Driver Class Initialized
INFO - 2017-02-23 10:22:05 --> Model Class Initialized
INFO - 2017-02-23 10:22:05 --> Model Class Initialized
INFO - 2017-02-23 10:22:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:22:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:22:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:22:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:22:05 --> Final output sent to browser
DEBUG - 2017-02-23 10:22:05 --> Total execution time: 0.1310
INFO - 2017-02-23 10:22:12 --> Config Class Initialized
INFO - 2017-02-23 10:22:12 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:22:12 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:22:12 --> Utf8 Class Initialized
INFO - 2017-02-23 10:22:12 --> URI Class Initialized
INFO - 2017-02-23 10:22:12 --> Router Class Initialized
INFO - 2017-02-23 10:22:12 --> Output Class Initialized
INFO - 2017-02-23 10:22:12 --> Security Class Initialized
DEBUG - 2017-02-23 10:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:22:12 --> Input Class Initialized
INFO - 2017-02-23 10:22:12 --> Language Class Initialized
INFO - 2017-02-23 10:22:12 --> Loader Class Initialized
INFO - 2017-02-23 10:22:12 --> Helper loaded: url_helper
INFO - 2017-02-23 10:22:12 --> Helper loaded: language_helper
INFO - 2017-02-23 10:22:12 --> Helper loaded: html_helper
INFO - 2017-02-23 10:22:12 --> Helper loaded: form_helper
INFO - 2017-02-23 10:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:22:12 --> Controller Class Initialized
INFO - 2017-02-23 10:22:12 --> Database Driver Class Initialized
INFO - 2017-02-23 10:22:12 --> Model Class Initialized
INFO - 2017-02-23 10:22:12 --> Model Class Initialized
INFO - 2017-02-23 10:22:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:22:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:22:12 --> Final output sent to browser
DEBUG - 2017-02-23 10:22:12 --> Total execution time: 0.1418
INFO - 2017-02-23 10:22:19 --> Config Class Initialized
INFO - 2017-02-23 10:22:19 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:22:19 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:22:19 --> Utf8 Class Initialized
INFO - 2017-02-23 10:22:19 --> URI Class Initialized
INFO - 2017-02-23 10:22:19 --> Router Class Initialized
INFO - 2017-02-23 10:22:19 --> Output Class Initialized
INFO - 2017-02-23 10:22:19 --> Security Class Initialized
DEBUG - 2017-02-23 10:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:22:19 --> Input Class Initialized
INFO - 2017-02-23 10:22:19 --> Language Class Initialized
INFO - 2017-02-23 10:22:19 --> Loader Class Initialized
INFO - 2017-02-23 10:22:19 --> Helper loaded: url_helper
INFO - 2017-02-23 10:22:19 --> Helper loaded: language_helper
INFO - 2017-02-23 10:22:19 --> Helper loaded: html_helper
INFO - 2017-02-23 10:22:19 --> Helper loaded: form_helper
INFO - 2017-02-23 10:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:22:19 --> Controller Class Initialized
INFO - 2017-02-23 10:22:19 --> Database Driver Class Initialized
INFO - 2017-02-23 10:22:19 --> Model Class Initialized
INFO - 2017-02-23 10:22:19 --> Model Class Initialized
INFO - 2017-02-23 10:22:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:22:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:22:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:22:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:22:19 --> Final output sent to browser
DEBUG - 2017-02-23 10:22:19 --> Total execution time: 0.1502
INFO - 2017-02-23 10:22:24 --> Config Class Initialized
INFO - 2017-02-23 10:22:24 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:22:24 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:22:24 --> Utf8 Class Initialized
INFO - 2017-02-23 10:22:24 --> URI Class Initialized
INFO - 2017-02-23 10:22:24 --> Router Class Initialized
INFO - 2017-02-23 10:22:24 --> Output Class Initialized
INFO - 2017-02-23 10:22:24 --> Security Class Initialized
DEBUG - 2017-02-23 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:22:24 --> Input Class Initialized
INFO - 2017-02-23 10:22:24 --> Language Class Initialized
INFO - 2017-02-23 10:22:24 --> Loader Class Initialized
INFO - 2017-02-23 10:22:24 --> Helper loaded: url_helper
INFO - 2017-02-23 10:22:24 --> Helper loaded: language_helper
INFO - 2017-02-23 10:22:24 --> Helper loaded: html_helper
INFO - 2017-02-23 10:22:24 --> Helper loaded: form_helper
INFO - 2017-02-23 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:22:24 --> Controller Class Initialized
INFO - 2017-02-23 10:22:24 --> Database Driver Class Initialized
INFO - 2017-02-23 10:22:24 --> Model Class Initialized
INFO - 2017-02-23 10:22:24 --> Model Class Initialized
INFO - 2017-02-23 10:22:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:22:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:22:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:22:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:22:24 --> Final output sent to browser
DEBUG - 2017-02-23 10:22:24 --> Total execution time: 0.1993
INFO - 2017-02-23 10:22:27 --> Config Class Initialized
INFO - 2017-02-23 10:22:27 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:22:27 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:22:27 --> Utf8 Class Initialized
INFO - 2017-02-23 10:22:27 --> URI Class Initialized
INFO - 2017-02-23 10:22:27 --> Router Class Initialized
INFO - 2017-02-23 10:22:27 --> Output Class Initialized
INFO - 2017-02-23 10:22:27 --> Security Class Initialized
DEBUG - 2017-02-23 10:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:22:27 --> Input Class Initialized
INFO - 2017-02-23 10:22:27 --> Language Class Initialized
INFO - 2017-02-23 10:22:27 --> Loader Class Initialized
INFO - 2017-02-23 10:22:27 --> Helper loaded: url_helper
INFO - 2017-02-23 10:22:27 --> Helper loaded: language_helper
INFO - 2017-02-23 10:22:27 --> Helper loaded: html_helper
INFO - 2017-02-23 10:22:27 --> Helper loaded: form_helper
INFO - 2017-02-23 10:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:22:27 --> Controller Class Initialized
INFO - 2017-02-23 10:22:27 --> Database Driver Class Initialized
INFO - 2017-02-23 10:22:27 --> Model Class Initialized
INFO - 2017-02-23 10:22:27 --> Model Class Initialized
INFO - 2017-02-23 10:22:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:22:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:22:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:22:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:22:27 --> Final output sent to browser
DEBUG - 2017-02-23 10:22:27 --> Total execution time: 0.2991
INFO - 2017-02-23 10:33:13 --> Config Class Initialized
INFO - 2017-02-23 10:33:13 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:13 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:13 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:13 --> URI Class Initialized
INFO - 2017-02-23 10:33:13 --> Router Class Initialized
INFO - 2017-02-23 10:33:13 --> Output Class Initialized
INFO - 2017-02-23 10:33:13 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:13 --> Input Class Initialized
INFO - 2017-02-23 10:33:13 --> Language Class Initialized
INFO - 2017-02-23 10:33:13 --> Loader Class Initialized
INFO - 2017-02-23 10:33:13 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:13 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:13 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:13 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:13 --> Controller Class Initialized
INFO - 2017-02-23 10:33:13 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:13 --> Model Class Initialized
INFO - 2017-02-23 10:33:13 --> Model Class Initialized
INFO - 2017-02-23 10:33:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:33:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:33:13 --> Final output sent to browser
DEBUG - 2017-02-23 10:33:13 --> Total execution time: 0.6458
INFO - 2017-02-23 10:33:18 --> Config Class Initialized
INFO - 2017-02-23 10:33:18 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:18 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:18 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:18 --> URI Class Initialized
INFO - 2017-02-23 10:33:18 --> Router Class Initialized
INFO - 2017-02-23 10:33:18 --> Output Class Initialized
INFO - 2017-02-23 10:33:18 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:18 --> Input Class Initialized
INFO - 2017-02-23 10:33:18 --> Language Class Initialized
INFO - 2017-02-23 10:33:18 --> Loader Class Initialized
INFO - 2017-02-23 10:33:18 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:18 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:18 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:18 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:18 --> Controller Class Initialized
INFO - 2017-02-23 10:33:18 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:18 --> Model Class Initialized
INFO - 2017-02-23 10:33:18 --> Model Class Initialized
INFO - 2017-02-23 10:33:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:33:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:33:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:33:18 --> Final output sent to browser
DEBUG - 2017-02-23 10:33:18 --> Total execution time: 0.6279
INFO - 2017-02-23 10:33:21 --> Config Class Initialized
INFO - 2017-02-23 10:33:21 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:21 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:21 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:21 --> URI Class Initialized
INFO - 2017-02-23 10:33:21 --> Router Class Initialized
INFO - 2017-02-23 10:33:21 --> Output Class Initialized
INFO - 2017-02-23 10:33:21 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:21 --> Input Class Initialized
INFO - 2017-02-23 10:33:21 --> Language Class Initialized
INFO - 2017-02-23 10:33:21 --> Loader Class Initialized
INFO - 2017-02-23 10:33:21 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:21 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:21 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:21 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:21 --> Controller Class Initialized
INFO - 2017-02-23 10:33:21 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:21 --> Model Class Initialized
INFO - 2017-02-23 10:33:21 --> Model Class Initialized
INFO - 2017-02-23 10:33:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:33:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:33:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:33:21 --> Final output sent to browser
DEBUG - 2017-02-23 10:33:21 --> Total execution time: 0.6226
INFO - 2017-02-23 10:33:36 --> Config Class Initialized
INFO - 2017-02-23 10:33:36 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:36 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:36 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:36 --> URI Class Initialized
INFO - 2017-02-23 10:33:36 --> Router Class Initialized
INFO - 2017-02-23 10:33:36 --> Output Class Initialized
INFO - 2017-02-23 10:33:36 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:36 --> Input Class Initialized
INFO - 2017-02-23 10:33:36 --> Language Class Initialized
INFO - 2017-02-23 10:33:36 --> Loader Class Initialized
INFO - 2017-02-23 10:33:36 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:36 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:36 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:36 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:36 --> Controller Class Initialized
INFO - 2017-02-23 10:33:36 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:36 --> Model Class Initialized
INFO - 2017-02-23 10:33:36 --> Model Class Initialized
INFO - 2017-02-23 10:33:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:33:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\operator.php
INFO - 2017-02-23 10:33:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:33:36 --> Final output sent to browser
DEBUG - 2017-02-23 10:33:36 --> Total execution time: 0.3054
INFO - 2017-02-23 10:33:42 --> Config Class Initialized
INFO - 2017-02-23 10:33:42 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:42 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:42 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:42 --> URI Class Initialized
INFO - 2017-02-23 10:33:42 --> Router Class Initialized
INFO - 2017-02-23 10:33:42 --> Output Class Initialized
INFO - 2017-02-23 10:33:42 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:42 --> Input Class Initialized
INFO - 2017-02-23 10:33:42 --> Language Class Initialized
INFO - 2017-02-23 10:33:42 --> Loader Class Initialized
INFO - 2017-02-23 10:33:42 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:42 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:42 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:42 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:42 --> Controller Class Initialized
INFO - 2017-02-23 10:33:42 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:42 --> Model Class Initialized
INFO - 2017-02-23 10:33:42 --> Model Class Initialized
INFO - 2017-02-23 10:33:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:42 --> Model Class Initialized
INFO - 2017-02-23 10:33:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:33:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_user.php
INFO - 2017-02-23 10:33:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:33:42 --> Final output sent to browser
DEBUG - 2017-02-23 10:33:42 --> Total execution time: 0.4277
INFO - 2017-02-23 10:33:46 --> Config Class Initialized
INFO - 2017-02-23 10:33:46 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:46 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:46 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:46 --> URI Class Initialized
INFO - 2017-02-23 10:33:46 --> Router Class Initialized
INFO - 2017-02-23 10:33:46 --> Output Class Initialized
INFO - 2017-02-23 10:33:46 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:46 --> Input Class Initialized
INFO - 2017-02-23 10:33:46 --> Language Class Initialized
INFO - 2017-02-23 10:33:46 --> Loader Class Initialized
INFO - 2017-02-23 10:33:46 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:46 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:46 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:46 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:46 --> Controller Class Initialized
INFO - 2017-02-23 10:33:46 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:46 --> Model Class Initialized
INFO - 2017-02-23 10:33:46 --> Model Class Initialized
INFO - 2017-02-23 10:33:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:46 --> Config Class Initialized
INFO - 2017-02-23 10:33:46 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:46 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:46 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:47 --> URI Class Initialized
INFO - 2017-02-23 10:33:47 --> Router Class Initialized
INFO - 2017-02-23 10:33:47 --> Output Class Initialized
INFO - 2017-02-23 10:33:47 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:47 --> Input Class Initialized
INFO - 2017-02-23 10:33:47 --> Language Class Initialized
INFO - 2017-02-23 10:33:47 --> Loader Class Initialized
INFO - 2017-02-23 10:33:47 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:47 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:47 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:47 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:47 --> Controller Class Initialized
INFO - 2017-02-23 10:33:47 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:47 --> Model Class Initialized
INFO - 2017-02-23 10:33:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-23 10:33:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-23 10:33:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-23 10:33:47 --> Final output sent to browser
DEBUG - 2017-02-23 10:33:47 --> Total execution time: 0.3657
INFO - 2017-02-23 10:33:55 --> Config Class Initialized
INFO - 2017-02-23 10:33:55 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:55 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:55 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:55 --> URI Class Initialized
INFO - 2017-02-23 10:33:55 --> Router Class Initialized
INFO - 2017-02-23 10:33:55 --> Output Class Initialized
INFO - 2017-02-23 10:33:55 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:55 --> Input Class Initialized
INFO - 2017-02-23 10:33:55 --> Language Class Initialized
INFO - 2017-02-23 10:33:55 --> Loader Class Initialized
INFO - 2017-02-23 10:33:55 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:55 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:55 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:55 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:55 --> Controller Class Initialized
INFO - 2017-02-23 10:33:55 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:55 --> Model Class Initialized
INFO - 2017-02-23 10:33:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:56 --> Config Class Initialized
INFO - 2017-02-23 10:33:56 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:33:56 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:33:56 --> Utf8 Class Initialized
INFO - 2017-02-23 10:33:56 --> URI Class Initialized
INFO - 2017-02-23 10:33:56 --> Router Class Initialized
INFO - 2017-02-23 10:33:56 --> Output Class Initialized
INFO - 2017-02-23 10:33:56 --> Security Class Initialized
DEBUG - 2017-02-23 10:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:33:56 --> Input Class Initialized
INFO - 2017-02-23 10:33:56 --> Language Class Initialized
INFO - 2017-02-23 10:33:56 --> Loader Class Initialized
INFO - 2017-02-23 10:33:56 --> Helper loaded: url_helper
INFO - 2017-02-23 10:33:56 --> Helper loaded: language_helper
INFO - 2017-02-23 10:33:56 --> Helper loaded: html_helper
INFO - 2017-02-23 10:33:56 --> Helper loaded: form_helper
INFO - 2017-02-23 10:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:33:56 --> Controller Class Initialized
INFO - 2017-02-23 10:33:56 --> Database Driver Class Initialized
INFO - 2017-02-23 10:33:56 --> Model Class Initialized
INFO - 2017-02-23 10:33:56 --> Model Class Initialized
INFO - 2017-02-23 10:33:56 --> Model Class Initialized
INFO - 2017-02-23 10:33:56 --> Model Class Initialized
INFO - 2017-02-23 10:33:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:33:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:33:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-23 10:33:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:33:56 --> Final output sent to browser
DEBUG - 2017-02-23 10:33:56 --> Total execution time: 0.3622
INFO - 2017-02-23 10:34:01 --> Config Class Initialized
INFO - 2017-02-23 10:34:01 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:34:01 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:34:01 --> Utf8 Class Initialized
INFO - 2017-02-23 10:34:01 --> URI Class Initialized
INFO - 2017-02-23 10:34:01 --> Router Class Initialized
INFO - 2017-02-23 10:34:01 --> Output Class Initialized
INFO - 2017-02-23 10:34:01 --> Security Class Initialized
DEBUG - 2017-02-23 10:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:34:01 --> Input Class Initialized
INFO - 2017-02-23 10:34:01 --> Language Class Initialized
INFO - 2017-02-23 10:34:01 --> Loader Class Initialized
INFO - 2017-02-23 10:34:01 --> Helper loaded: url_helper
INFO - 2017-02-23 10:34:01 --> Helper loaded: language_helper
INFO - 2017-02-23 10:34:01 --> Helper loaded: html_helper
INFO - 2017-02-23 10:34:01 --> Helper loaded: form_helper
INFO - 2017-02-23 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:34:01 --> Controller Class Initialized
INFO - 2017-02-23 10:34:01 --> Database Driver Class Initialized
INFO - 2017-02-23 10:34:01 --> Model Class Initialized
INFO - 2017-02-23 10:34:01 --> Model Class Initialized
INFO - 2017-02-23 10:34:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:34:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:34:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:34:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:34:01 --> Final output sent to browser
DEBUG - 2017-02-23 10:34:01 --> Total execution time: 0.5394
INFO - 2017-02-23 10:34:04 --> Config Class Initialized
INFO - 2017-02-23 10:34:04 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:34:04 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:34:04 --> Utf8 Class Initialized
INFO - 2017-02-23 10:34:04 --> URI Class Initialized
INFO - 2017-02-23 10:34:04 --> Router Class Initialized
INFO - 2017-02-23 10:34:04 --> Output Class Initialized
INFO - 2017-02-23 10:34:04 --> Security Class Initialized
DEBUG - 2017-02-23 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:34:05 --> Input Class Initialized
INFO - 2017-02-23 10:34:05 --> Language Class Initialized
INFO - 2017-02-23 10:34:05 --> Loader Class Initialized
INFO - 2017-02-23 10:34:05 --> Helper loaded: url_helper
INFO - 2017-02-23 10:34:05 --> Helper loaded: language_helper
INFO - 2017-02-23 10:34:05 --> Helper loaded: html_helper
INFO - 2017-02-23 10:34:05 --> Helper loaded: form_helper
INFO - 2017-02-23 10:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:34:05 --> Controller Class Initialized
INFO - 2017-02-23 10:34:05 --> Database Driver Class Initialized
INFO - 2017-02-23 10:34:05 --> Model Class Initialized
INFO - 2017-02-23 10:34:05 --> Model Class Initialized
INFO - 2017-02-23 10:34:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:34:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:34:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:34:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:34:05 --> Final output sent to browser
DEBUG - 2017-02-23 10:34:05 --> Total execution time: 0.6853
INFO - 2017-02-23 10:34:07 --> Config Class Initialized
INFO - 2017-02-23 10:34:07 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:34:07 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:34:07 --> Utf8 Class Initialized
INFO - 2017-02-23 10:34:07 --> URI Class Initialized
INFO - 2017-02-23 10:34:07 --> Router Class Initialized
INFO - 2017-02-23 10:34:07 --> Output Class Initialized
INFO - 2017-02-23 10:34:07 --> Security Class Initialized
DEBUG - 2017-02-23 10:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:34:07 --> Input Class Initialized
INFO - 2017-02-23 10:34:07 --> Language Class Initialized
INFO - 2017-02-23 10:34:07 --> Loader Class Initialized
INFO - 2017-02-23 10:34:07 --> Helper loaded: url_helper
INFO - 2017-02-23 10:34:07 --> Helper loaded: language_helper
INFO - 2017-02-23 10:34:07 --> Helper loaded: html_helper
INFO - 2017-02-23 10:34:07 --> Helper loaded: form_helper
INFO - 2017-02-23 10:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:34:07 --> Controller Class Initialized
INFO - 2017-02-23 10:34:07 --> Database Driver Class Initialized
INFO - 2017-02-23 10:34:07 --> Model Class Initialized
INFO - 2017-02-23 10:34:07 --> Model Class Initialized
INFO - 2017-02-23 10:34:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:34:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:34:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_list.php
INFO - 2017-02-23 10:34:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:34:08 --> Final output sent to browser
DEBUG - 2017-02-23 10:34:08 --> Total execution time: 0.6856
INFO - 2017-02-23 10:34:11 --> Config Class Initialized
INFO - 2017-02-23 10:34:11 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:34:11 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:34:11 --> Utf8 Class Initialized
INFO - 2017-02-23 10:34:11 --> URI Class Initialized
INFO - 2017-02-23 10:34:11 --> Router Class Initialized
INFO - 2017-02-23 10:34:11 --> Output Class Initialized
INFO - 2017-02-23 10:34:11 --> Security Class Initialized
DEBUG - 2017-02-23 10:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:34:11 --> Input Class Initialized
INFO - 2017-02-23 10:34:11 --> Language Class Initialized
INFO - 2017-02-23 10:34:11 --> Loader Class Initialized
INFO - 2017-02-23 10:34:11 --> Helper loaded: url_helper
INFO - 2017-02-23 10:34:11 --> Helper loaded: language_helper
INFO - 2017-02-23 10:34:11 --> Helper loaded: html_helper
INFO - 2017-02-23 10:34:11 --> Helper loaded: form_helper
INFO - 2017-02-23 10:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:34:11 --> Controller Class Initialized
INFO - 2017-02-23 10:34:11 --> Database Driver Class Initialized
INFO - 2017-02-23 10:34:11 --> Model Class Initialized
INFO - 2017-02-23 10:34:11 --> Model Class Initialized
INFO - 2017-02-23 10:34:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:34:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:34:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-23 10:34:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:34:12 --> Final output sent to browser
DEBUG - 2017-02-23 10:34:12 --> Total execution time: 1.1198
INFO - 2017-02-23 10:34:15 --> Config Class Initialized
INFO - 2017-02-23 10:34:15 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:34:15 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:34:15 --> Utf8 Class Initialized
INFO - 2017-02-23 10:34:15 --> URI Class Initialized
INFO - 2017-02-23 10:34:15 --> Router Class Initialized
INFO - 2017-02-23 10:34:15 --> Output Class Initialized
INFO - 2017-02-23 10:34:15 --> Security Class Initialized
DEBUG - 2017-02-23 10:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:34:15 --> Input Class Initialized
INFO - 2017-02-23 10:34:15 --> Language Class Initialized
INFO - 2017-02-23 10:34:15 --> Loader Class Initialized
INFO - 2017-02-23 10:34:15 --> Helper loaded: url_helper
INFO - 2017-02-23 10:34:15 --> Helper loaded: language_helper
INFO - 2017-02-23 10:34:15 --> Helper loaded: html_helper
INFO - 2017-02-23 10:34:15 --> Helper loaded: form_helper
INFO - 2017-02-23 10:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:34:16 --> Controller Class Initialized
INFO - 2017-02-23 10:34:16 --> Database Driver Class Initialized
INFO - 2017-02-23 10:34:16 --> Model Class Initialized
INFO - 2017-02-23 10:34:16 --> Model Class Initialized
INFO - 2017-02-23 10:34:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:34:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:34:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-23 10:34:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:34:16 --> Final output sent to browser
DEBUG - 2017-02-23 10:34:16 --> Total execution time: 1.1934
INFO - 2017-02-23 10:34:24 --> Config Class Initialized
INFO - 2017-02-23 10:34:24 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:34:24 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:34:24 --> Utf8 Class Initialized
INFO - 2017-02-23 10:34:24 --> URI Class Initialized
INFO - 2017-02-23 10:34:24 --> Router Class Initialized
INFO - 2017-02-23 10:34:24 --> Output Class Initialized
INFO - 2017-02-23 10:34:24 --> Security Class Initialized
DEBUG - 2017-02-23 10:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:34:24 --> Input Class Initialized
INFO - 2017-02-23 10:34:24 --> Language Class Initialized
INFO - 2017-02-23 10:34:24 --> Loader Class Initialized
INFO - 2017-02-23 10:34:24 --> Helper loaded: url_helper
INFO - 2017-02-23 10:34:24 --> Helper loaded: language_helper
INFO - 2017-02-23 10:34:24 --> Helper loaded: html_helper
INFO - 2017-02-23 10:34:24 --> Helper loaded: form_helper
INFO - 2017-02-23 10:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:34:24 --> Controller Class Initialized
INFO - 2017-02-23 10:34:24 --> Database Driver Class Initialized
INFO - 2017-02-23 10:34:24 --> Model Class Initialized
INFO - 2017-02-23 10:34:24 --> Model Class Initialized
INFO - 2017-02-23 10:34:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:34:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:34:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-23 10:34:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:34:25 --> Final output sent to browser
DEBUG - 2017-02-23 10:34:25 --> Total execution time: 0.7903
INFO - 2017-02-23 10:35:21 --> Config Class Initialized
INFO - 2017-02-23 10:35:21 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:35:21 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:35:21 --> Utf8 Class Initialized
INFO - 2017-02-23 10:35:21 --> URI Class Initialized
INFO - 2017-02-23 10:35:21 --> Router Class Initialized
INFO - 2017-02-23 10:35:21 --> Output Class Initialized
INFO - 2017-02-23 10:35:21 --> Security Class Initialized
DEBUG - 2017-02-23 10:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:35:21 --> Input Class Initialized
INFO - 2017-02-23 10:35:21 --> Language Class Initialized
INFO - 2017-02-23 10:35:21 --> Loader Class Initialized
INFO - 2017-02-23 10:35:21 --> Helper loaded: url_helper
INFO - 2017-02-23 10:35:21 --> Helper loaded: language_helper
INFO - 2017-02-23 10:35:21 --> Helper loaded: html_helper
INFO - 2017-02-23 10:35:21 --> Helper loaded: form_helper
INFO - 2017-02-23 10:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:35:21 --> Controller Class Initialized
INFO - 2017-02-23 10:35:21 --> Database Driver Class Initialized
INFO - 2017-02-23 10:35:21 --> Model Class Initialized
INFO - 2017-02-23 10:35:21 --> Model Class Initialized
INFO - 2017-02-23 10:35:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:35:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:35:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-23 10:35:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:35:22 --> Final output sent to browser
DEBUG - 2017-02-23 10:35:22 --> Total execution time: 0.6109
INFO - 2017-02-23 10:35:24 --> Config Class Initialized
INFO - 2017-02-23 10:35:24 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:35:24 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:35:24 --> Utf8 Class Initialized
INFO - 2017-02-23 10:35:24 --> URI Class Initialized
INFO - 2017-02-23 10:35:24 --> Router Class Initialized
INFO - 2017-02-23 10:35:24 --> Output Class Initialized
INFO - 2017-02-23 10:35:24 --> Security Class Initialized
DEBUG - 2017-02-23 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:35:24 --> Input Class Initialized
INFO - 2017-02-23 10:35:24 --> Language Class Initialized
INFO - 2017-02-23 10:35:24 --> Loader Class Initialized
INFO - 2017-02-23 10:35:24 --> Helper loaded: url_helper
INFO - 2017-02-23 10:35:24 --> Helper loaded: language_helper
INFO - 2017-02-23 10:35:24 --> Helper loaded: html_helper
INFO - 2017-02-23 10:35:24 --> Helper loaded: form_helper
INFO - 2017-02-23 10:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:35:24 --> Controller Class Initialized
INFO - 2017-02-23 10:35:24 --> Database Driver Class Initialized
INFO - 2017-02-23 10:35:24 --> Model Class Initialized
INFO - 2017-02-23 10:35:24 --> Model Class Initialized
INFO - 2017-02-23 10:35:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-23 10:35:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:35:24 --> Final output sent to browser
DEBUG - 2017-02-23 10:35:24 --> Total execution time: 0.5907
INFO - 2017-02-23 10:35:27 --> Config Class Initialized
INFO - 2017-02-23 10:35:27 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:35:27 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:35:27 --> Utf8 Class Initialized
INFO - 2017-02-23 10:35:27 --> URI Class Initialized
INFO - 2017-02-23 10:35:27 --> Router Class Initialized
INFO - 2017-02-23 10:35:27 --> Output Class Initialized
INFO - 2017-02-23 10:35:27 --> Security Class Initialized
DEBUG - 2017-02-23 10:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:35:27 --> Input Class Initialized
INFO - 2017-02-23 10:35:27 --> Language Class Initialized
INFO - 2017-02-23 10:35:27 --> Loader Class Initialized
INFO - 2017-02-23 10:35:27 --> Helper loaded: url_helper
INFO - 2017-02-23 10:35:27 --> Helper loaded: language_helper
INFO - 2017-02-23 10:35:27 --> Helper loaded: html_helper
INFO - 2017-02-23 10:35:27 --> Helper loaded: form_helper
INFO - 2017-02-23 10:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:35:27 --> Controller Class Initialized
INFO - 2017-02-23 10:35:27 --> Database Driver Class Initialized
INFO - 2017-02-23 10:35:27 --> Model Class Initialized
INFO - 2017-02-23 10:35:28 --> Model Class Initialized
INFO - 2017-02-23 10:35:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:35:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:35:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_tpu_tpa.php
INFO - 2017-02-23 10:35:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:35:28 --> Final output sent to browser
DEBUG - 2017-02-23 10:35:28 --> Total execution time: 0.7619
INFO - 2017-02-23 10:35:34 --> Config Class Initialized
INFO - 2017-02-23 10:35:34 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:35:34 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:35:34 --> Utf8 Class Initialized
INFO - 2017-02-23 10:35:34 --> URI Class Initialized
INFO - 2017-02-23 10:35:34 --> Router Class Initialized
INFO - 2017-02-23 10:35:34 --> Output Class Initialized
INFO - 2017-02-23 10:35:34 --> Security Class Initialized
DEBUG - 2017-02-23 10:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:35:34 --> Input Class Initialized
INFO - 2017-02-23 10:35:34 --> Language Class Initialized
INFO - 2017-02-23 10:35:34 --> Loader Class Initialized
INFO - 2017-02-23 10:35:34 --> Helper loaded: url_helper
INFO - 2017-02-23 10:35:34 --> Helper loaded: language_helper
INFO - 2017-02-23 10:35:34 --> Helper loaded: html_helper
INFO - 2017-02-23 10:35:34 --> Helper loaded: form_helper
INFO - 2017-02-23 10:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:35:34 --> Controller Class Initialized
INFO - 2017-02-23 10:35:35 --> Database Driver Class Initialized
INFO - 2017-02-23 10:35:35 --> Model Class Initialized
INFO - 2017-02-23 10:35:35 --> Model Class Initialized
INFO - 2017-02-23 10:35:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:35:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:35:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-23 10:35:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:35:35 --> Final output sent to browser
DEBUG - 2017-02-23 10:35:35 --> Total execution time: 1.2442
INFO - 2017-02-23 10:35:38 --> Config Class Initialized
INFO - 2017-02-23 10:35:38 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:35:38 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:35:38 --> Utf8 Class Initialized
INFO - 2017-02-23 10:35:38 --> URI Class Initialized
INFO - 2017-02-23 10:35:38 --> Router Class Initialized
INFO - 2017-02-23 10:35:38 --> Output Class Initialized
INFO - 2017-02-23 10:35:38 --> Security Class Initialized
DEBUG - 2017-02-23 10:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:35:38 --> Input Class Initialized
INFO - 2017-02-23 10:35:38 --> Language Class Initialized
INFO - 2017-02-23 10:35:38 --> Loader Class Initialized
INFO - 2017-02-23 10:35:38 --> Helper loaded: url_helper
INFO - 2017-02-23 10:35:38 --> Helper loaded: language_helper
INFO - 2017-02-23 10:35:38 --> Helper loaded: html_helper
INFO - 2017-02-23 10:35:38 --> Helper loaded: form_helper
INFO - 2017-02-23 10:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:35:38 --> Controller Class Initialized
INFO - 2017-02-23 10:35:38 --> Database Driver Class Initialized
INFO - 2017-02-23 10:35:38 --> Model Class Initialized
INFO - 2017-02-23 10:35:38 --> Model Class Initialized
INFO - 2017-02-23 10:35:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-23 10:35:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:35:39 --> Final output sent to browser
DEBUG - 2017-02-23 10:35:39 --> Total execution time: 1.2649
INFO - 2017-02-23 10:35:52 --> Config Class Initialized
INFO - 2017-02-23 10:35:52 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:35:52 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:35:52 --> Utf8 Class Initialized
INFO - 2017-02-23 10:35:52 --> URI Class Initialized
INFO - 2017-02-23 10:35:52 --> Router Class Initialized
INFO - 2017-02-23 10:35:52 --> Output Class Initialized
INFO - 2017-02-23 10:35:52 --> Security Class Initialized
DEBUG - 2017-02-23 10:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:35:52 --> Input Class Initialized
INFO - 2017-02-23 10:35:52 --> Language Class Initialized
INFO - 2017-02-23 10:35:52 --> Loader Class Initialized
INFO - 2017-02-23 10:35:52 --> Helper loaded: url_helper
INFO - 2017-02-23 10:35:52 --> Helper loaded: language_helper
INFO - 2017-02-23 10:35:52 --> Helper loaded: html_helper
INFO - 2017-02-23 10:35:52 --> Helper loaded: form_helper
INFO - 2017-02-23 10:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:35:52 --> Controller Class Initialized
INFO - 2017-02-23 10:35:52 --> Database Driver Class Initialized
INFO - 2017-02-23 10:35:52 --> Model Class Initialized
INFO - 2017-02-23 10:35:52 --> Model Class Initialized
INFO - 2017-02-23 10:35:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:35:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:35:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_ist.php
INFO - 2017-02-23 10:35:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:35:53 --> Final output sent to browser
DEBUG - 2017-02-23 10:35:53 --> Total execution time: 0.6834
INFO - 2017-02-23 10:36:02 --> Config Class Initialized
INFO - 2017-02-23 10:36:02 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:36:02 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:36:02 --> Utf8 Class Initialized
INFO - 2017-02-23 10:36:02 --> URI Class Initialized
INFO - 2017-02-23 10:36:02 --> Router Class Initialized
INFO - 2017-02-23 10:36:02 --> Output Class Initialized
INFO - 2017-02-23 10:36:02 --> Security Class Initialized
DEBUG - 2017-02-23 10:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:36:02 --> Input Class Initialized
INFO - 2017-02-23 10:36:02 --> Language Class Initialized
INFO - 2017-02-23 10:36:02 --> Loader Class Initialized
INFO - 2017-02-23 10:36:02 --> Helper loaded: url_helper
INFO - 2017-02-23 10:36:02 --> Helper loaded: language_helper
INFO - 2017-02-23 10:36:02 --> Helper loaded: html_helper
INFO - 2017-02-23 10:36:02 --> Helper loaded: form_helper
INFO - 2017-02-23 10:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:36:02 --> Controller Class Initialized
INFO - 2017-02-23 10:36:02 --> Database Driver Class Initialized
INFO - 2017-02-23 10:36:02 --> Model Class Initialized
INFO - 2017-02-23 10:36:02 --> Model Class Initialized
INFO - 2017-02-23 10:36:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:36:02 --> Model Class Initialized
INFO - 2017-02-23 10:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-23 10:36:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:36:04 --> Final output sent to browser
DEBUG - 2017-02-23 10:36:04 --> Total execution time: 1.8687
INFO - 2017-02-23 10:36:07 --> Config Class Initialized
INFO - 2017-02-23 10:36:07 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:36:07 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:36:07 --> Utf8 Class Initialized
INFO - 2017-02-23 10:36:07 --> URI Class Initialized
INFO - 2017-02-23 10:36:07 --> Router Class Initialized
INFO - 2017-02-23 10:36:08 --> Output Class Initialized
INFO - 2017-02-23 10:36:08 --> Security Class Initialized
DEBUG - 2017-02-23 10:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:36:08 --> Input Class Initialized
INFO - 2017-02-23 10:36:08 --> Language Class Initialized
INFO - 2017-02-23 10:36:08 --> Loader Class Initialized
INFO - 2017-02-23 10:36:08 --> Helper loaded: url_helper
INFO - 2017-02-23 10:36:08 --> Helper loaded: language_helper
INFO - 2017-02-23 10:36:08 --> Helper loaded: html_helper
INFO - 2017-02-23 10:36:08 --> Helper loaded: form_helper
INFO - 2017-02-23 10:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:36:08 --> Controller Class Initialized
INFO - 2017-02-23 10:36:08 --> Database Driver Class Initialized
INFO - 2017-02-23 10:36:08 --> Model Class Initialized
INFO - 2017-02-23 10:36:08 --> Model Class Initialized
INFO - 2017-02-23 10:36:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:36:08 --> Model Class Initialized
INFO - 2017-02-23 10:36:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:36:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-23 10:36:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:36:09 --> Final output sent to browser
DEBUG - 2017-02-23 10:36:09 --> Total execution time: 1.9760
INFO - 2017-02-23 10:54:29 --> Config Class Initialized
INFO - 2017-02-23 10:54:29 --> Hooks Class Initialized
DEBUG - 2017-02-23 10:54:29 --> UTF-8 Support Enabled
INFO - 2017-02-23 10:54:29 --> Utf8 Class Initialized
INFO - 2017-02-23 10:54:29 --> URI Class Initialized
INFO - 2017-02-23 10:54:29 --> Router Class Initialized
INFO - 2017-02-23 10:54:29 --> Output Class Initialized
INFO - 2017-02-23 10:54:29 --> Security Class Initialized
DEBUG - 2017-02-23 10:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-23 10:54:29 --> Input Class Initialized
INFO - 2017-02-23 10:54:29 --> Language Class Initialized
INFO - 2017-02-23 10:54:29 --> Loader Class Initialized
INFO - 2017-02-23 10:54:29 --> Helper loaded: url_helper
INFO - 2017-02-23 10:54:29 --> Helper loaded: language_helper
INFO - 2017-02-23 10:54:29 --> Helper loaded: html_helper
INFO - 2017-02-23 10:54:29 --> Helper loaded: form_helper
INFO - 2017-02-23 10:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-23 10:54:29 --> Controller Class Initialized
INFO - 2017-02-23 10:54:29 --> Database Driver Class Initialized
INFO - 2017-02-23 10:54:29 --> Model Class Initialized
INFO - 2017-02-23 10:54:29 --> Model Class Initialized
INFO - 2017-02-23 10:54:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-23 10:54:29 --> Model Class Initialized
INFO - 2017-02-23 10:54:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-23 10:54:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\hasil_disc.php
INFO - 2017-02-23 10:54:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-23 10:54:29 --> Final output sent to browser
DEBUG - 2017-02-23 10:54:29 --> Total execution time: 0.3018
