<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-24 11:42:27 --> Config Class Initialized
INFO - 2017-02-24 11:42:27 --> Hooks Class Initialized
DEBUG - 2017-02-24 11:42:27 --> UTF-8 Support Enabled
INFO - 2017-02-24 11:42:27 --> Utf8 Class Initialized
INFO - 2017-02-24 11:42:27 --> URI Class Initialized
DEBUG - 2017-02-24 11:42:27 --> No URI present. Default controller set.
INFO - 2017-02-24 11:42:27 --> Router Class Initialized
INFO - 2017-02-24 11:42:27 --> Output Class Initialized
INFO - 2017-02-24 11:42:27 --> Security Class Initialized
DEBUG - 2017-02-24 11:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 11:42:27 --> Input Class Initialized
INFO - 2017-02-24 11:42:27 --> Language Class Initialized
INFO - 2017-02-24 11:42:27 --> Loader Class Initialized
INFO - 2017-02-24 11:42:27 --> Helper loaded: url_helper
INFO - 2017-02-24 11:42:27 --> Helper loaded: language_helper
INFO - 2017-02-24 11:42:27 --> Helper loaded: html_helper
INFO - 2017-02-24 11:42:27 --> Helper loaded: form_helper
INFO - 2017-02-24 11:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 11:42:27 --> Controller Class Initialized
INFO - 2017-02-24 11:42:27 --> Database Driver Class Initialized
INFO - 2017-02-24 11:42:27 --> Model Class Initialized
INFO - 2017-02-24 11:42:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-24 11:42:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-24 11:42:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-24 11:42:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-24 11:42:27 --> Final output sent to browser
DEBUG - 2017-02-24 11:42:27 --> Total execution time: 0.2587
