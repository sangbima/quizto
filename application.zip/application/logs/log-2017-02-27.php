<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-27 13:54:30 --> Config Class Initialized
INFO - 2017-02-27 13:54:30 --> Hooks Class Initialized
DEBUG - 2017-02-27 13:54:30 --> UTF-8 Support Enabled
INFO - 2017-02-27 13:54:30 --> Utf8 Class Initialized
INFO - 2017-02-27 13:54:30 --> URI Class Initialized
INFO - 2017-02-27 13:54:30 --> Router Class Initialized
INFO - 2017-02-27 13:54:30 --> Output Class Initialized
INFO - 2017-02-27 13:54:30 --> Security Class Initialized
DEBUG - 2017-02-27 13:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 13:54:30 --> Input Class Initialized
INFO - 2017-02-27 13:54:30 --> Language Class Initialized
INFO - 2017-02-27 13:54:30 --> Loader Class Initialized
INFO - 2017-02-27 13:54:30 --> Helper loaded: url_helper
INFO - 2017-02-27 13:54:30 --> Helper loaded: language_helper
INFO - 2017-02-27 13:54:30 --> Helper loaded: html_helper
INFO - 2017-02-27 13:54:30 --> Helper loaded: form_helper
INFO - 2017-02-27 13:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 13:54:30 --> Controller Class Initialized
INFO - 2017-02-27 13:54:30 --> Database Driver Class Initialized
INFO - 2017-02-27 13:54:30 --> Model Class Initialized
INFO - 2017-02-27 13:54:30 --> Model Class Initialized
INFO - 2017-02-27 13:54:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 13:54:30 --> Config Class Initialized
INFO - 2017-02-27 13:54:30 --> Hooks Class Initialized
DEBUG - 2017-02-27 13:54:30 --> UTF-8 Support Enabled
INFO - 2017-02-27 13:54:30 --> Utf8 Class Initialized
INFO - 2017-02-27 13:54:30 --> URI Class Initialized
INFO - 2017-02-27 13:54:30 --> Router Class Initialized
INFO - 2017-02-27 13:54:30 --> Output Class Initialized
INFO - 2017-02-27 13:54:30 --> Security Class Initialized
DEBUG - 2017-02-27 13:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 13:54:30 --> Input Class Initialized
INFO - 2017-02-27 13:54:30 --> Language Class Initialized
INFO - 2017-02-27 13:54:30 --> Loader Class Initialized
INFO - 2017-02-27 13:54:30 --> Helper loaded: url_helper
INFO - 2017-02-27 13:54:30 --> Helper loaded: language_helper
INFO - 2017-02-27 13:54:30 --> Helper loaded: html_helper
INFO - 2017-02-27 13:54:30 --> Helper loaded: form_helper
INFO - 2017-02-27 13:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 13:54:30 --> Controller Class Initialized
INFO - 2017-02-27 13:54:30 --> Database Driver Class Initialized
INFO - 2017-02-27 13:54:30 --> Model Class Initialized
INFO - 2017-02-27 13:54:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 13:54:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-27 13:54:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-27 13:54:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-27 13:54:30 --> Final output sent to browser
DEBUG - 2017-02-27 13:54:30 --> Total execution time: 0.1608
INFO - 2017-02-27 13:54:35 --> Config Class Initialized
INFO - 2017-02-27 13:54:35 --> Hooks Class Initialized
DEBUG - 2017-02-27 13:54:35 --> UTF-8 Support Enabled
INFO - 2017-02-27 13:54:35 --> Utf8 Class Initialized
INFO - 2017-02-27 13:54:35 --> URI Class Initialized
INFO - 2017-02-27 13:54:35 --> Router Class Initialized
INFO - 2017-02-27 13:54:35 --> Output Class Initialized
INFO - 2017-02-27 13:54:35 --> Security Class Initialized
DEBUG - 2017-02-27 13:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 13:54:35 --> Input Class Initialized
INFO - 2017-02-27 13:54:35 --> Language Class Initialized
INFO - 2017-02-27 13:54:35 --> Loader Class Initialized
INFO - 2017-02-27 13:54:35 --> Helper loaded: url_helper
INFO - 2017-02-27 13:54:35 --> Helper loaded: language_helper
INFO - 2017-02-27 13:54:35 --> Helper loaded: html_helper
INFO - 2017-02-27 13:54:35 --> Helper loaded: form_helper
INFO - 2017-02-27 13:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 13:54:35 --> Controller Class Initialized
INFO - 2017-02-27 13:54:35 --> Database Driver Class Initialized
INFO - 2017-02-27 13:54:35 --> Model Class Initialized
INFO - 2017-02-27 13:54:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 13:54:36 --> Config Class Initialized
INFO - 2017-02-27 13:54:36 --> Hooks Class Initialized
DEBUG - 2017-02-27 13:54:36 --> UTF-8 Support Enabled
INFO - 2017-02-27 13:54:36 --> Utf8 Class Initialized
INFO - 2017-02-27 13:54:36 --> URI Class Initialized
INFO - 2017-02-27 13:54:36 --> Router Class Initialized
INFO - 2017-02-27 13:54:36 --> Output Class Initialized
INFO - 2017-02-27 13:54:36 --> Security Class Initialized
DEBUG - 2017-02-27 13:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 13:54:36 --> Input Class Initialized
INFO - 2017-02-27 13:54:36 --> Language Class Initialized
INFO - 2017-02-27 13:54:36 --> Loader Class Initialized
INFO - 2017-02-27 13:54:36 --> Helper loaded: url_helper
INFO - 2017-02-27 13:54:36 --> Helper loaded: language_helper
INFO - 2017-02-27 13:54:36 --> Helper loaded: html_helper
INFO - 2017-02-27 13:54:36 --> Helper loaded: form_helper
INFO - 2017-02-27 13:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 13:54:36 --> Controller Class Initialized
INFO - 2017-02-27 13:54:36 --> Database Driver Class Initialized
INFO - 2017-02-27 13:54:36 --> Model Class Initialized
INFO - 2017-02-27 13:54:36 --> Model Class Initialized
INFO - 2017-02-27 13:54:36 --> Model Class Initialized
INFO - 2017-02-27 13:54:36 --> Model Class Initialized
INFO - 2017-02-27 13:54:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 13:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-27 13:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-27 13:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-27 13:54:36 --> Final output sent to browser
DEBUG - 2017-02-27 13:54:36 --> Total execution time: 0.2077
INFO - 2017-02-27 13:54:39 --> Config Class Initialized
INFO - 2017-02-27 13:54:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 13:54:39 --> UTF-8 Support Enabled
INFO - 2017-02-27 13:54:39 --> Utf8 Class Initialized
INFO - 2017-02-27 13:54:39 --> URI Class Initialized
INFO - 2017-02-27 13:54:39 --> Router Class Initialized
INFO - 2017-02-27 13:54:39 --> Output Class Initialized
INFO - 2017-02-27 13:54:39 --> Security Class Initialized
DEBUG - 2017-02-27 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 13:54:39 --> Input Class Initialized
INFO - 2017-02-27 13:54:39 --> Language Class Initialized
INFO - 2017-02-27 13:54:39 --> Loader Class Initialized
INFO - 2017-02-27 13:54:39 --> Helper loaded: url_helper
INFO - 2017-02-27 13:54:39 --> Helper loaded: language_helper
INFO - 2017-02-27 13:54:39 --> Helper loaded: html_helper
INFO - 2017-02-27 13:54:39 --> Helper loaded: form_helper
INFO - 2017-02-27 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 13:54:39 --> Controller Class Initialized
INFO - 2017-02-27 13:54:39 --> Database Driver Class Initialized
INFO - 2017-02-27 13:54:39 --> Model Class Initialized
INFO - 2017-02-27 13:54:39 --> Model Class Initialized
INFO - 2017-02-27 13:54:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 13:54:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-27 13:54:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\new_user.php
INFO - 2017-02-27 13:54:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-27 13:54:39 --> Final output sent to browser
DEBUG - 2017-02-27 13:54:39 --> Total execution time: 0.1898
INFO - 2017-02-27 13:54:39 --> Config Class Initialized
INFO - 2017-02-27 13:54:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 13:54:39 --> UTF-8 Support Enabled
INFO - 2017-02-27 13:54:39 --> Utf8 Class Initialized
INFO - 2017-02-27 13:54:39 --> URI Class Initialized
INFO - 2017-02-27 13:54:39 --> Router Class Initialized
INFO - 2017-02-27 13:54:39 --> Output Class Initialized
INFO - 2017-02-27 13:54:39 --> Security Class Initialized
DEBUG - 2017-02-27 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 13:54:39 --> Input Class Initialized
INFO - 2017-02-27 13:54:39 --> Language Class Initialized
INFO - 2017-02-27 13:54:39 --> Loader Class Initialized
INFO - 2017-02-27 13:54:39 --> Helper loaded: url_helper
INFO - 2017-02-27 13:54:39 --> Helper loaded: language_helper
INFO - 2017-02-27 13:54:39 --> Helper loaded: html_helper
INFO - 2017-02-27 13:54:39 --> Helper loaded: form_helper
INFO - 2017-02-27 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 13:54:39 --> Controller Class Initialized
INFO - 2017-02-27 13:54:39 --> Database Driver Class Initialized
INFO - 2017-02-27 13:54:39 --> Model Class Initialized
INFO - 2017-02-27 13:54:39 --> Model Class Initialized
INFO - 2017-02-27 13:54:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 13:54:39 --> Final output sent to browser
DEBUG - 2017-02-27 13:54:39 --> Total execution time: 0.2093
INFO - 2017-02-27 14:33:05 --> Config Class Initialized
INFO - 2017-02-27 14:33:05 --> Hooks Class Initialized
DEBUG - 2017-02-27 14:33:05 --> UTF-8 Support Enabled
INFO - 2017-02-27 14:33:05 --> Utf8 Class Initialized
INFO - 2017-02-27 14:33:05 --> URI Class Initialized
INFO - 2017-02-27 14:33:05 --> Router Class Initialized
INFO - 2017-02-27 14:33:05 --> Output Class Initialized
INFO - 2017-02-27 14:33:05 --> Security Class Initialized
DEBUG - 2017-02-27 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 14:33:05 --> Input Class Initialized
INFO - 2017-02-27 14:33:05 --> Language Class Initialized
INFO - 2017-02-27 14:33:05 --> Loader Class Initialized
INFO - 2017-02-27 14:33:05 --> Helper loaded: url_helper
INFO - 2017-02-27 14:33:05 --> Helper loaded: language_helper
INFO - 2017-02-27 14:33:05 --> Helper loaded: html_helper
INFO - 2017-02-27 14:33:05 --> Helper loaded: form_helper
INFO - 2017-02-27 14:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 14:33:05 --> Controller Class Initialized
INFO - 2017-02-27 14:33:05 --> Database Driver Class Initialized
INFO - 2017-02-27 14:33:05 --> Model Class Initialized
INFO - 2017-02-27 14:33:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 14:33:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-27 14:33:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-02-27 14:33:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-27 14:33:05 --> Final output sent to browser
DEBUG - 2017-02-27 14:33:05 --> Total execution time: 0.2385
INFO - 2017-02-27 22:06:22 --> Config Class Initialized
INFO - 2017-02-27 22:06:22 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:06:22 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:06:22 --> Utf8 Class Initialized
INFO - 2017-02-27 22:06:22 --> URI Class Initialized
INFO - 2017-02-27 22:06:22 --> Router Class Initialized
INFO - 2017-02-27 22:06:22 --> Output Class Initialized
INFO - 2017-02-27 22:06:22 --> Security Class Initialized
DEBUG - 2017-02-27 22:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:06:22 --> Input Class Initialized
INFO - 2017-02-27 22:06:22 --> Language Class Initialized
INFO - 2017-02-27 22:06:22 --> Loader Class Initialized
INFO - 2017-02-27 22:06:22 --> Helper loaded: url_helper
INFO - 2017-02-27 22:06:22 --> Helper loaded: language_helper
INFO - 2017-02-27 22:06:22 --> Helper loaded: html_helper
INFO - 2017-02-27 22:06:22 --> Helper loaded: form_helper
INFO - 2017-02-27 22:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:06:22 --> Controller Class Initialized
INFO - 2017-02-27 22:06:22 --> Database Driver Class Initialized
INFO - 2017-02-27 22:06:22 --> Model Class Initialized
INFO - 2017-02-27 22:06:23 --> Model Class Initialized
INFO - 2017-02-27 22:06:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 22:06:23 --> Config Class Initialized
INFO - 2017-02-27 22:06:23 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:06:23 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:06:23 --> Utf8 Class Initialized
INFO - 2017-02-27 22:06:23 --> URI Class Initialized
INFO - 2017-02-27 22:06:23 --> Router Class Initialized
INFO - 2017-02-27 22:06:23 --> Output Class Initialized
INFO - 2017-02-27 22:06:23 --> Security Class Initialized
DEBUG - 2017-02-27 22:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:06:23 --> Input Class Initialized
INFO - 2017-02-27 22:06:23 --> Language Class Initialized
INFO - 2017-02-27 22:06:23 --> Loader Class Initialized
INFO - 2017-02-27 22:06:23 --> Helper loaded: url_helper
INFO - 2017-02-27 22:06:23 --> Helper loaded: language_helper
INFO - 2017-02-27 22:06:23 --> Helper loaded: html_helper
INFO - 2017-02-27 22:06:23 --> Helper loaded: form_helper
INFO - 2017-02-27 22:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:06:23 --> Controller Class Initialized
INFO - 2017-02-27 22:06:23 --> Database Driver Class Initialized
INFO - 2017-02-27 22:06:23 --> Model Class Initialized
INFO - 2017-02-27 22:06:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 22:06:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-02-27 22:06:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-02-27 22:06:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-02-27 22:06:23 --> Final output sent to browser
DEBUG - 2017-02-27 22:06:23 --> Total execution time: 0.0701
INFO - 2017-02-27 22:06:27 --> Config Class Initialized
INFO - 2017-02-27 22:06:27 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:06:27 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:06:27 --> Utf8 Class Initialized
INFO - 2017-02-27 22:06:27 --> URI Class Initialized
INFO - 2017-02-27 22:06:27 --> Router Class Initialized
INFO - 2017-02-27 22:06:27 --> Output Class Initialized
INFO - 2017-02-27 22:06:27 --> Security Class Initialized
DEBUG - 2017-02-27 22:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:06:27 --> Input Class Initialized
INFO - 2017-02-27 22:06:27 --> Language Class Initialized
INFO - 2017-02-27 22:06:27 --> Loader Class Initialized
INFO - 2017-02-27 22:06:27 --> Helper loaded: url_helper
INFO - 2017-02-27 22:06:27 --> Helper loaded: language_helper
INFO - 2017-02-27 22:06:27 --> Helper loaded: html_helper
INFO - 2017-02-27 22:06:27 --> Helper loaded: form_helper
INFO - 2017-02-27 22:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:06:27 --> Controller Class Initialized
INFO - 2017-02-27 22:06:27 --> Database Driver Class Initialized
INFO - 2017-02-27 22:06:27 --> Model Class Initialized
INFO - 2017-02-27 22:06:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 22:06:27 --> Config Class Initialized
INFO - 2017-02-27 22:06:27 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:06:27 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:06:27 --> Utf8 Class Initialized
INFO - 2017-02-27 22:06:27 --> URI Class Initialized
INFO - 2017-02-27 22:06:27 --> Router Class Initialized
INFO - 2017-02-27 22:06:27 --> Output Class Initialized
INFO - 2017-02-27 22:06:27 --> Security Class Initialized
DEBUG - 2017-02-27 22:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:06:27 --> Input Class Initialized
INFO - 2017-02-27 22:06:27 --> Language Class Initialized
INFO - 2017-02-27 22:06:27 --> Loader Class Initialized
INFO - 2017-02-27 22:06:27 --> Helper loaded: url_helper
INFO - 2017-02-27 22:06:27 --> Helper loaded: language_helper
INFO - 2017-02-27 22:06:27 --> Helper loaded: html_helper
INFO - 2017-02-27 22:06:27 --> Helper loaded: form_helper
INFO - 2017-02-27 22:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:06:27 --> Controller Class Initialized
INFO - 2017-02-27 22:06:27 --> Database Driver Class Initialized
INFO - 2017-02-27 22:06:27 --> Model Class Initialized
INFO - 2017-02-27 22:06:27 --> Model Class Initialized
INFO - 2017-02-27 22:06:28 --> Model Class Initialized
INFO - 2017-02-27 22:06:28 --> Model Class Initialized
INFO - 2017-02-27 22:06:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 22:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-27 22:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-02-27 22:06:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-27 22:06:28 --> Final output sent to browser
DEBUG - 2017-02-27 22:06:28 --> Total execution time: 0.1094
INFO - 2017-02-27 22:06:30 --> Config Class Initialized
INFO - 2017-02-27 22:06:30 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:06:30 --> Utf8 Class Initialized
INFO - 2017-02-27 22:06:30 --> URI Class Initialized
INFO - 2017-02-27 22:06:30 --> Router Class Initialized
INFO - 2017-02-27 22:06:30 --> Output Class Initialized
INFO - 2017-02-27 22:06:30 --> Security Class Initialized
DEBUG - 2017-02-27 22:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:06:30 --> Input Class Initialized
INFO - 2017-02-27 22:06:30 --> Language Class Initialized
INFO - 2017-02-27 22:06:30 --> Loader Class Initialized
INFO - 2017-02-27 22:06:30 --> Helper loaded: url_helper
INFO - 2017-02-27 22:06:30 --> Helper loaded: language_helper
INFO - 2017-02-27 22:06:30 --> Helper loaded: html_helper
INFO - 2017-02-27 22:06:30 --> Helper loaded: form_helper
INFO - 2017-02-27 22:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:06:30 --> Controller Class Initialized
INFO - 2017-02-27 22:06:30 --> Database Driver Class Initialized
INFO - 2017-02-27 22:06:30 --> Model Class Initialized
INFO - 2017-02-27 22:06:30 --> Model Class Initialized
INFO - 2017-02-27 22:06:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 22:06:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-27 22:06:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\quiz_list.php
INFO - 2017-02-27 22:06:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-27 22:06:30 --> Final output sent to browser
DEBUG - 2017-02-27 22:06:30 --> Total execution time: 0.0807
INFO - 2017-02-27 22:06:36 --> Config Class Initialized
INFO - 2017-02-27 22:06:36 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:06:36 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:06:36 --> Utf8 Class Initialized
INFO - 2017-02-27 22:06:36 --> URI Class Initialized
INFO - 2017-02-27 22:06:36 --> Router Class Initialized
INFO - 2017-02-27 22:06:36 --> Output Class Initialized
INFO - 2017-02-27 22:06:36 --> Security Class Initialized
DEBUG - 2017-02-27 22:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:06:36 --> Input Class Initialized
INFO - 2017-02-27 22:06:36 --> Language Class Initialized
INFO - 2017-02-27 22:06:36 --> Loader Class Initialized
INFO - 2017-02-27 22:06:36 --> Helper loaded: url_helper
INFO - 2017-02-27 22:06:36 --> Helper loaded: language_helper
INFO - 2017-02-27 22:06:36 --> Helper loaded: html_helper
INFO - 2017-02-27 22:06:36 --> Helper loaded: form_helper
INFO - 2017-02-27 22:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:06:36 --> Controller Class Initialized
INFO - 2017-02-27 22:06:36 --> Database Driver Class Initialized
INFO - 2017-02-27 22:06:36 --> Model Class Initialized
INFO - 2017-02-27 22:06:36 --> Model Class Initialized
INFO - 2017-02-27 22:06:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-02-27 22:06:36 --> Model Class Initialized
INFO - 2017-02-27 22:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-02-27 22:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_quiz.php
INFO - 2017-02-27 22:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-02-27 22:06:36 --> Final output sent to browser
DEBUG - 2017-02-27 22:06:36 --> Total execution time: 0.1468
