<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-01 11:56:30 --> Config Class Initialized
INFO - 2017-03-01 11:56:30 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:56:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:56:30 --> Utf8 Class Initialized
INFO - 2017-03-01 11:56:31 --> URI Class Initialized
INFO - 2017-03-01 11:56:31 --> Router Class Initialized
INFO - 2017-03-01 11:56:31 --> Output Class Initialized
INFO - 2017-03-01 11:56:31 --> Security Class Initialized
DEBUG - 2017-03-01 11:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:56:31 --> Input Class Initialized
INFO - 2017-03-01 11:56:31 --> Language Class Initialized
INFO - 2017-03-01 11:56:31 --> Loader Class Initialized
INFO - 2017-03-01 11:56:31 --> Helper loaded: url_helper
INFO - 2017-03-01 11:56:31 --> Helper loaded: language_helper
INFO - 2017-03-01 11:56:31 --> Helper loaded: html_helper
INFO - 2017-03-01 11:56:31 --> Helper loaded: form_helper
INFO - 2017-03-01 11:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:56:31 --> Controller Class Initialized
INFO - 2017-03-01 11:56:31 --> Database Driver Class Initialized
INFO - 2017-03-01 11:56:31 --> Model Class Initialized
INFO - 2017-03-01 11:56:31 --> Model Class Initialized
INFO - 2017-03-01 11:56:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 11:56:31 --> Config Class Initialized
INFO - 2017-03-01 11:56:31 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:56:31 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:56:31 --> Utf8 Class Initialized
INFO - 2017-03-01 11:56:31 --> URI Class Initialized
INFO - 2017-03-01 11:56:31 --> Router Class Initialized
INFO - 2017-03-01 11:56:31 --> Output Class Initialized
INFO - 2017-03-01 11:56:31 --> Security Class Initialized
DEBUG - 2017-03-01 11:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:56:31 --> Input Class Initialized
INFO - 2017-03-01 11:56:31 --> Language Class Initialized
INFO - 2017-03-01 11:56:31 --> Loader Class Initialized
INFO - 2017-03-01 11:56:31 --> Helper loaded: url_helper
INFO - 2017-03-01 11:56:31 --> Helper loaded: language_helper
INFO - 2017-03-01 11:56:31 --> Helper loaded: html_helper
INFO - 2017-03-01 11:56:31 --> Helper loaded: form_helper
INFO - 2017-03-01 11:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:56:31 --> Controller Class Initialized
INFO - 2017-03-01 11:56:31 --> Database Driver Class Initialized
INFO - 2017-03-01 11:56:31 --> Model Class Initialized
INFO - 2017-03-01 11:56:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 11:56:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-01 11:56:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-01 11:56:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-01 11:56:31 --> Final output sent to browser
DEBUG - 2017-03-01 11:56:31 --> Total execution time: 0.1746
INFO - 2017-03-01 11:56:33 --> Config Class Initialized
INFO - 2017-03-01 11:56:33 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:56:33 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:56:33 --> Utf8 Class Initialized
INFO - 2017-03-01 11:56:33 --> URI Class Initialized
INFO - 2017-03-01 11:56:33 --> Router Class Initialized
INFO - 2017-03-01 11:56:33 --> Output Class Initialized
INFO - 2017-03-01 11:56:33 --> Security Class Initialized
DEBUG - 2017-03-01 11:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:56:33 --> Input Class Initialized
INFO - 2017-03-01 11:56:33 --> Language Class Initialized
INFO - 2017-03-01 11:56:33 --> Loader Class Initialized
INFO - 2017-03-01 11:56:33 --> Helper loaded: url_helper
INFO - 2017-03-01 11:56:33 --> Helper loaded: language_helper
INFO - 2017-03-01 11:56:33 --> Helper loaded: html_helper
INFO - 2017-03-01 11:56:33 --> Helper loaded: form_helper
INFO - 2017-03-01 11:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:56:33 --> Controller Class Initialized
INFO - 2017-03-01 11:56:33 --> Database Driver Class Initialized
INFO - 2017-03-01 11:56:33 --> Model Class Initialized
INFO - 2017-03-01 11:56:33 --> Email Class Initialized
INFO - 2017-03-01 11:56:33 --> Form Validation Class Initialized
INFO - 2017-03-01 11:56:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 11:56:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 11:56:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 11:56:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 11:56:33 --> Final output sent to browser
DEBUG - 2017-03-01 11:56:33 --> Total execution time: 0.2152
INFO - 2017-03-01 11:57:02 --> Config Class Initialized
INFO - 2017-03-01 11:57:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:57:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:57:02 --> Utf8 Class Initialized
INFO - 2017-03-01 11:57:02 --> URI Class Initialized
INFO - 2017-03-01 11:57:02 --> Router Class Initialized
INFO - 2017-03-01 11:57:02 --> Output Class Initialized
INFO - 2017-03-01 11:57:02 --> Security Class Initialized
DEBUG - 2017-03-01 11:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:57:02 --> Input Class Initialized
INFO - 2017-03-01 11:57:02 --> Language Class Initialized
INFO - 2017-03-01 11:57:02 --> Loader Class Initialized
INFO - 2017-03-01 11:57:02 --> Helper loaded: url_helper
INFO - 2017-03-01 11:57:02 --> Helper loaded: language_helper
INFO - 2017-03-01 11:57:02 --> Helper loaded: html_helper
INFO - 2017-03-01 11:57:02 --> Helper loaded: form_helper
INFO - 2017-03-01 11:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:57:02 --> Controller Class Initialized
INFO - 2017-03-01 11:57:02 --> Database Driver Class Initialized
INFO - 2017-03-01 11:57:02 --> Model Class Initialized
INFO - 2017-03-01 11:57:02 --> Email Class Initialized
INFO - 2017-03-01 11:57:02 --> Form Validation Class Initialized
INFO - 2017-03-01 11:57:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 11:57:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 11:57:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 11:57:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 11:57:02 --> Final output sent to browser
DEBUG - 2017-03-01 11:57:02 --> Total execution time: 0.1956
INFO - 2017-03-01 12:09:19 --> Config Class Initialized
INFO - 2017-03-01 12:09:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:09:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:09:19 --> Utf8 Class Initialized
INFO - 2017-03-01 12:09:19 --> URI Class Initialized
INFO - 2017-03-01 12:09:19 --> Router Class Initialized
INFO - 2017-03-01 12:09:19 --> Output Class Initialized
INFO - 2017-03-01 12:09:19 --> Security Class Initialized
DEBUG - 2017-03-01 12:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:09:19 --> Input Class Initialized
INFO - 2017-03-01 12:09:19 --> Language Class Initialized
INFO - 2017-03-01 12:09:19 --> Loader Class Initialized
INFO - 2017-03-01 12:09:19 --> Helper loaded: url_helper
INFO - 2017-03-01 12:09:19 --> Helper loaded: language_helper
INFO - 2017-03-01 12:09:19 --> Helper loaded: html_helper
INFO - 2017-03-01 12:09:19 --> Helper loaded: form_helper
INFO - 2017-03-01 12:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:09:19 --> Controller Class Initialized
INFO - 2017-03-01 12:09:19 --> Database Driver Class Initialized
INFO - 2017-03-01 12:09:19 --> Model Class Initialized
INFO - 2017-03-01 12:09:19 --> Email Class Initialized
INFO - 2017-03-01 12:09:19 --> Form Validation Class Initialized
INFO - 2017-03-01 12:09:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:09:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:09:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:09:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:09:19 --> Final output sent to browser
DEBUG - 2017-03-01 12:09:19 --> Total execution time: 0.1482
INFO - 2017-03-01 12:10:37 --> Config Class Initialized
INFO - 2017-03-01 12:10:37 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:10:37 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:10:37 --> Utf8 Class Initialized
INFO - 2017-03-01 12:10:37 --> URI Class Initialized
INFO - 2017-03-01 12:10:37 --> Router Class Initialized
INFO - 2017-03-01 12:10:37 --> Output Class Initialized
INFO - 2017-03-01 12:10:37 --> Security Class Initialized
DEBUG - 2017-03-01 12:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:10:37 --> Input Class Initialized
INFO - 2017-03-01 12:10:37 --> Language Class Initialized
INFO - 2017-03-01 12:10:37 --> Loader Class Initialized
INFO - 2017-03-01 12:10:37 --> Helper loaded: url_helper
INFO - 2017-03-01 12:10:37 --> Helper loaded: language_helper
INFO - 2017-03-01 12:10:37 --> Helper loaded: html_helper
INFO - 2017-03-01 12:10:37 --> Helper loaded: form_helper
INFO - 2017-03-01 12:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:10:37 --> Controller Class Initialized
INFO - 2017-03-01 12:10:37 --> Database Driver Class Initialized
INFO - 2017-03-01 12:10:37 --> Model Class Initialized
INFO - 2017-03-01 12:10:37 --> Email Class Initialized
INFO - 2017-03-01 12:10:37 --> Form Validation Class Initialized
INFO - 2017-03-01 12:10:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:10:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:10:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:10:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:10:37 --> Final output sent to browser
DEBUG - 2017-03-01 12:10:37 --> Total execution time: 0.1598
INFO - 2017-03-01 12:11:12 --> Config Class Initialized
INFO - 2017-03-01 12:11:12 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:11:12 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:11:12 --> Utf8 Class Initialized
INFO - 2017-03-01 12:11:12 --> URI Class Initialized
INFO - 2017-03-01 12:11:12 --> Router Class Initialized
INFO - 2017-03-01 12:11:12 --> Output Class Initialized
INFO - 2017-03-01 12:11:12 --> Security Class Initialized
DEBUG - 2017-03-01 12:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:11:12 --> Input Class Initialized
INFO - 2017-03-01 12:11:12 --> Language Class Initialized
INFO - 2017-03-01 12:11:12 --> Loader Class Initialized
INFO - 2017-03-01 12:11:12 --> Helper loaded: url_helper
INFO - 2017-03-01 12:11:12 --> Helper loaded: language_helper
INFO - 2017-03-01 12:11:12 --> Helper loaded: html_helper
INFO - 2017-03-01 12:11:12 --> Helper loaded: form_helper
INFO - 2017-03-01 12:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:11:12 --> Controller Class Initialized
INFO - 2017-03-01 12:11:12 --> Database Driver Class Initialized
INFO - 2017-03-01 12:11:12 --> Model Class Initialized
INFO - 2017-03-01 12:11:12 --> Email Class Initialized
INFO - 2017-03-01 12:11:12 --> Form Validation Class Initialized
INFO - 2017-03-01 12:11:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:11:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:11:20 --> Config Class Initialized
INFO - 2017-03-01 12:11:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:11:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:11:20 --> Utf8 Class Initialized
INFO - 2017-03-01 12:11:20 --> URI Class Initialized
INFO - 2017-03-01 12:11:20 --> Router Class Initialized
INFO - 2017-03-01 12:11:21 --> Output Class Initialized
INFO - 2017-03-01 12:11:21 --> Security Class Initialized
DEBUG - 2017-03-01 12:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:11:21 --> Input Class Initialized
INFO - 2017-03-01 12:11:21 --> Language Class Initialized
INFO - 2017-03-01 12:11:21 --> Loader Class Initialized
INFO - 2017-03-01 12:11:21 --> Helper loaded: url_helper
INFO - 2017-03-01 12:11:21 --> Helper loaded: language_helper
INFO - 2017-03-01 12:11:21 --> Helper loaded: html_helper
INFO - 2017-03-01 12:11:21 --> Helper loaded: form_helper
INFO - 2017-03-01 12:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:11:21 --> Controller Class Initialized
INFO - 2017-03-01 12:11:21 --> Database Driver Class Initialized
INFO - 2017-03-01 12:11:21 --> Model Class Initialized
INFO - 2017-03-01 12:11:21 --> Email Class Initialized
INFO - 2017-03-01 12:11:21 --> Form Validation Class Initialized
INFO - 2017-03-01 12:11:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:11:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:11:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:11:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:11:21 --> Final output sent to browser
DEBUG - 2017-03-01 12:11:21 --> Total execution time: 0.1679
INFO - 2017-03-01 12:11:27 --> Config Class Initialized
INFO - 2017-03-01 12:11:27 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:11:27 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:11:27 --> Utf8 Class Initialized
INFO - 2017-03-01 12:11:27 --> URI Class Initialized
INFO - 2017-03-01 12:11:27 --> Router Class Initialized
INFO - 2017-03-01 12:11:27 --> Output Class Initialized
INFO - 2017-03-01 12:11:27 --> Security Class Initialized
DEBUG - 2017-03-01 12:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:11:27 --> Input Class Initialized
INFO - 2017-03-01 12:11:27 --> Language Class Initialized
INFO - 2017-03-01 12:11:27 --> Loader Class Initialized
INFO - 2017-03-01 12:11:27 --> Helper loaded: url_helper
INFO - 2017-03-01 12:11:27 --> Helper loaded: language_helper
INFO - 2017-03-01 12:11:27 --> Helper loaded: html_helper
INFO - 2017-03-01 12:11:27 --> Helper loaded: form_helper
INFO - 2017-03-01 12:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:11:27 --> Controller Class Initialized
INFO - 2017-03-01 12:11:27 --> Database Driver Class Initialized
INFO - 2017-03-01 12:11:27 --> Model Class Initialized
INFO - 2017-03-01 12:11:27 --> Email Class Initialized
INFO - 2017-03-01 12:11:27 --> Form Validation Class Initialized
INFO - 2017-03-01 12:11:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:11:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:11:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:11:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:11:27 --> Final output sent to browser
DEBUG - 2017-03-01 12:11:27 --> Total execution time: 0.2003
INFO - 2017-03-01 12:11:35 --> Config Class Initialized
INFO - 2017-03-01 12:11:35 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:11:35 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:11:35 --> Utf8 Class Initialized
INFO - 2017-03-01 12:11:35 --> URI Class Initialized
INFO - 2017-03-01 12:11:35 --> Router Class Initialized
INFO - 2017-03-01 12:11:35 --> Output Class Initialized
INFO - 2017-03-01 12:11:35 --> Security Class Initialized
DEBUG - 2017-03-01 12:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:11:35 --> Input Class Initialized
INFO - 2017-03-01 12:11:35 --> Language Class Initialized
INFO - 2017-03-01 12:11:35 --> Loader Class Initialized
INFO - 2017-03-01 12:11:35 --> Helper loaded: url_helper
INFO - 2017-03-01 12:11:35 --> Helper loaded: language_helper
INFO - 2017-03-01 12:11:35 --> Helper loaded: html_helper
INFO - 2017-03-01 12:11:35 --> Helper loaded: form_helper
INFO - 2017-03-01 12:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:11:35 --> Controller Class Initialized
INFO - 2017-03-01 12:11:35 --> Database Driver Class Initialized
INFO - 2017-03-01 12:11:35 --> Model Class Initialized
INFO - 2017-03-01 12:11:35 --> Email Class Initialized
INFO - 2017-03-01 12:11:35 --> Form Validation Class Initialized
INFO - 2017-03-01 12:11:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:11:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:11:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:11:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:11:35 --> Final output sent to browser
DEBUG - 2017-03-01 12:11:35 --> Total execution time: 0.1664
INFO - 2017-03-01 12:12:49 --> Config Class Initialized
INFO - 2017-03-01 12:12:49 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:12:49 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:12:49 --> Utf8 Class Initialized
INFO - 2017-03-01 12:12:49 --> URI Class Initialized
INFO - 2017-03-01 12:12:49 --> Router Class Initialized
INFO - 2017-03-01 12:12:49 --> Output Class Initialized
INFO - 2017-03-01 12:12:49 --> Security Class Initialized
DEBUG - 2017-03-01 12:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:12:49 --> Input Class Initialized
INFO - 2017-03-01 12:12:49 --> Language Class Initialized
INFO - 2017-03-01 12:12:49 --> Loader Class Initialized
INFO - 2017-03-01 12:12:49 --> Helper loaded: url_helper
INFO - 2017-03-01 12:12:49 --> Helper loaded: language_helper
INFO - 2017-03-01 12:12:49 --> Helper loaded: html_helper
INFO - 2017-03-01 12:12:49 --> Helper loaded: form_helper
INFO - 2017-03-01 12:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:12:49 --> Controller Class Initialized
INFO - 2017-03-01 12:12:49 --> Database Driver Class Initialized
INFO - 2017-03-01 12:12:49 --> Model Class Initialized
INFO - 2017-03-01 12:12:49 --> Email Class Initialized
INFO - 2017-03-01 12:12:49 --> Form Validation Class Initialized
INFO - 2017-03-01 12:12:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:12:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:12:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:12:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:12:49 --> Final output sent to browser
DEBUG - 2017-03-01 12:12:49 --> Total execution time: 0.1599
INFO - 2017-03-01 12:13:21 --> Config Class Initialized
INFO - 2017-03-01 12:13:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:13:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:13:21 --> Utf8 Class Initialized
INFO - 2017-03-01 12:13:21 --> URI Class Initialized
INFO - 2017-03-01 12:13:21 --> Router Class Initialized
INFO - 2017-03-01 12:13:21 --> Output Class Initialized
INFO - 2017-03-01 12:13:21 --> Security Class Initialized
DEBUG - 2017-03-01 12:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:13:21 --> Input Class Initialized
INFO - 2017-03-01 12:13:21 --> Language Class Initialized
INFO - 2017-03-01 12:13:21 --> Loader Class Initialized
INFO - 2017-03-01 12:13:21 --> Helper loaded: url_helper
INFO - 2017-03-01 12:13:21 --> Helper loaded: language_helper
INFO - 2017-03-01 12:13:21 --> Helper loaded: html_helper
INFO - 2017-03-01 12:13:21 --> Helper loaded: form_helper
INFO - 2017-03-01 12:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:13:21 --> Controller Class Initialized
INFO - 2017-03-01 12:13:21 --> Database Driver Class Initialized
INFO - 2017-03-01 12:13:21 --> Model Class Initialized
INFO - 2017-03-01 12:13:21 --> Email Class Initialized
INFO - 2017-03-01 12:13:21 --> Form Validation Class Initialized
INFO - 2017-03-01 12:13:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:13:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:13:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:13:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:13:21 --> Final output sent to browser
DEBUG - 2017-03-01 12:13:21 --> Total execution time: 0.1733
INFO - 2017-03-01 12:15:15 --> Config Class Initialized
INFO - 2017-03-01 12:15:15 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:15:15 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:15:15 --> Utf8 Class Initialized
INFO - 2017-03-01 12:15:15 --> URI Class Initialized
INFO - 2017-03-01 12:15:15 --> Router Class Initialized
INFO - 2017-03-01 12:15:15 --> Output Class Initialized
INFO - 2017-03-01 12:15:15 --> Security Class Initialized
DEBUG - 2017-03-01 12:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:15:15 --> Input Class Initialized
INFO - 2017-03-01 12:15:15 --> Language Class Initialized
INFO - 2017-03-01 12:15:15 --> Loader Class Initialized
INFO - 2017-03-01 12:15:15 --> Helper loaded: url_helper
INFO - 2017-03-01 12:15:15 --> Helper loaded: language_helper
INFO - 2017-03-01 12:15:15 --> Helper loaded: html_helper
INFO - 2017-03-01 12:15:15 --> Helper loaded: form_helper
INFO - 2017-03-01 12:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:15:15 --> Controller Class Initialized
INFO - 2017-03-01 12:15:15 --> Database Driver Class Initialized
INFO - 2017-03-01 12:15:15 --> Model Class Initialized
INFO - 2017-03-01 12:15:15 --> Email Class Initialized
INFO - 2017-03-01 12:15:15 --> Form Validation Class Initialized
INFO - 2017-03-01 12:15:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:15:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:15:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:15:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:15:15 --> Final output sent to browser
DEBUG - 2017-03-01 12:15:15 --> Total execution time: 0.1822
INFO - 2017-03-01 12:20:27 --> Config Class Initialized
INFO - 2017-03-01 12:20:27 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:20:27 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:20:27 --> Utf8 Class Initialized
INFO - 2017-03-01 12:20:27 --> URI Class Initialized
INFO - 2017-03-01 12:20:27 --> Router Class Initialized
INFO - 2017-03-01 12:20:27 --> Output Class Initialized
INFO - 2017-03-01 12:20:27 --> Security Class Initialized
DEBUG - 2017-03-01 12:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:20:27 --> Input Class Initialized
INFO - 2017-03-01 12:20:27 --> Language Class Initialized
INFO - 2017-03-01 12:20:27 --> Loader Class Initialized
INFO - 2017-03-01 12:20:27 --> Helper loaded: url_helper
INFO - 2017-03-01 12:20:27 --> Helper loaded: language_helper
INFO - 2017-03-01 12:20:27 --> Helper loaded: html_helper
INFO - 2017-03-01 12:20:27 --> Helper loaded: form_helper
INFO - 2017-03-01 12:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:20:27 --> Controller Class Initialized
INFO - 2017-03-01 12:20:27 --> Database Driver Class Initialized
INFO - 2017-03-01 12:20:27 --> Model Class Initialized
INFO - 2017-03-01 12:20:27 --> Email Class Initialized
INFO - 2017-03-01 12:20:27 --> Form Validation Class Initialized
INFO - 2017-03-01 12:20:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:20:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:20:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:20:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:20:27 --> Final output sent to browser
DEBUG - 2017-03-01 12:20:27 --> Total execution time: 0.1905
INFO - 2017-03-01 12:21:43 --> Config Class Initialized
INFO - 2017-03-01 12:21:43 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:21:43 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:21:43 --> Utf8 Class Initialized
INFO - 2017-03-01 12:21:43 --> URI Class Initialized
INFO - 2017-03-01 12:21:43 --> Router Class Initialized
INFO - 2017-03-01 12:21:43 --> Output Class Initialized
INFO - 2017-03-01 12:21:43 --> Security Class Initialized
DEBUG - 2017-03-01 12:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:21:43 --> Input Class Initialized
INFO - 2017-03-01 12:21:43 --> Language Class Initialized
INFO - 2017-03-01 12:21:43 --> Loader Class Initialized
INFO - 2017-03-01 12:21:43 --> Helper loaded: url_helper
INFO - 2017-03-01 12:21:43 --> Helper loaded: language_helper
INFO - 2017-03-01 12:21:43 --> Helper loaded: html_helper
INFO - 2017-03-01 12:21:43 --> Helper loaded: form_helper
INFO - 2017-03-01 12:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:21:43 --> Controller Class Initialized
INFO - 2017-03-01 12:21:43 --> Database Driver Class Initialized
INFO - 2017-03-01 12:21:43 --> Model Class Initialized
INFO - 2017-03-01 12:21:43 --> Email Class Initialized
INFO - 2017-03-01 12:21:43 --> Form Validation Class Initialized
INFO - 2017-03-01 12:21:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:21:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:21:43 --> Final output sent to browser
DEBUG - 2017-03-01 12:21:43 --> Total execution time: 0.2485
INFO - 2017-03-01 12:21:55 --> Config Class Initialized
INFO - 2017-03-01 12:21:55 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:21:55 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:21:55 --> Utf8 Class Initialized
INFO - 2017-03-01 12:21:55 --> URI Class Initialized
INFO - 2017-03-01 12:21:55 --> Router Class Initialized
INFO - 2017-03-01 12:21:55 --> Output Class Initialized
INFO - 2017-03-01 12:21:55 --> Security Class Initialized
DEBUG - 2017-03-01 12:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:21:55 --> Input Class Initialized
INFO - 2017-03-01 12:21:55 --> Language Class Initialized
INFO - 2017-03-01 12:21:55 --> Loader Class Initialized
INFO - 2017-03-01 12:21:55 --> Helper loaded: url_helper
INFO - 2017-03-01 12:21:55 --> Helper loaded: language_helper
INFO - 2017-03-01 12:21:55 --> Helper loaded: html_helper
INFO - 2017-03-01 12:21:55 --> Helper loaded: form_helper
INFO - 2017-03-01 12:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:21:55 --> Controller Class Initialized
INFO - 2017-03-01 12:21:55 --> Database Driver Class Initialized
INFO - 2017-03-01 12:21:55 --> Model Class Initialized
INFO - 2017-03-01 12:21:55 --> Email Class Initialized
INFO - 2017-03-01 12:21:55 --> Form Validation Class Initialized
INFO - 2017-03-01 12:21:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:21:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:21:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:21:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:21:55 --> Final output sent to browser
DEBUG - 2017-03-01 12:21:55 --> Total execution time: 0.2027
INFO - 2017-03-01 12:22:18 --> Config Class Initialized
INFO - 2017-03-01 12:22:18 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:22:18 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:22:18 --> Utf8 Class Initialized
INFO - 2017-03-01 12:22:18 --> URI Class Initialized
INFO - 2017-03-01 12:22:18 --> Router Class Initialized
INFO - 2017-03-01 12:22:18 --> Output Class Initialized
INFO - 2017-03-01 12:22:18 --> Security Class Initialized
DEBUG - 2017-03-01 12:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:22:18 --> Input Class Initialized
INFO - 2017-03-01 12:22:18 --> Language Class Initialized
INFO - 2017-03-01 12:22:18 --> Loader Class Initialized
INFO - 2017-03-01 12:22:18 --> Helper loaded: url_helper
INFO - 2017-03-01 12:22:18 --> Helper loaded: language_helper
INFO - 2017-03-01 12:22:18 --> Helper loaded: html_helper
INFO - 2017-03-01 12:22:18 --> Helper loaded: form_helper
INFO - 2017-03-01 12:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:22:18 --> Controller Class Initialized
INFO - 2017-03-01 12:22:18 --> Database Driver Class Initialized
INFO - 2017-03-01 12:22:18 --> Model Class Initialized
INFO - 2017-03-01 12:22:18 --> Email Class Initialized
INFO - 2017-03-01 12:22:18 --> Form Validation Class Initialized
INFO - 2017-03-01 12:22:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:22:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:22:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:22:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:22:18 --> Final output sent to browser
DEBUG - 2017-03-01 12:22:18 --> Total execution time: 0.1676
INFO - 2017-03-01 12:22:56 --> Config Class Initialized
INFO - 2017-03-01 12:22:56 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:22:56 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:22:56 --> Utf8 Class Initialized
INFO - 2017-03-01 12:22:56 --> URI Class Initialized
INFO - 2017-03-01 12:22:56 --> Router Class Initialized
INFO - 2017-03-01 12:22:56 --> Output Class Initialized
INFO - 2017-03-01 12:22:56 --> Security Class Initialized
DEBUG - 2017-03-01 12:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:22:56 --> Input Class Initialized
INFO - 2017-03-01 12:22:56 --> Language Class Initialized
INFO - 2017-03-01 12:22:56 --> Loader Class Initialized
INFO - 2017-03-01 12:22:56 --> Helper loaded: url_helper
INFO - 2017-03-01 12:22:56 --> Helper loaded: language_helper
INFO - 2017-03-01 12:22:56 --> Helper loaded: html_helper
INFO - 2017-03-01 12:22:56 --> Helper loaded: form_helper
INFO - 2017-03-01 12:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:22:56 --> Controller Class Initialized
INFO - 2017-03-01 12:22:56 --> Database Driver Class Initialized
INFO - 2017-03-01 12:22:56 --> Model Class Initialized
INFO - 2017-03-01 12:22:56 --> Email Class Initialized
INFO - 2017-03-01 12:22:56 --> Form Validation Class Initialized
INFO - 2017-03-01 12:22:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:22:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:22:56 --> Final output sent to browser
DEBUG - 2017-03-01 12:22:56 --> Total execution time: 0.2382
INFO - 2017-03-01 12:23:18 --> Config Class Initialized
INFO - 2017-03-01 12:23:18 --> Hooks Class Initialized
DEBUG - 2017-03-01 12:23:18 --> UTF-8 Support Enabled
INFO - 2017-03-01 12:23:18 --> Utf8 Class Initialized
INFO - 2017-03-01 12:23:18 --> URI Class Initialized
INFO - 2017-03-01 12:23:18 --> Router Class Initialized
INFO - 2017-03-01 12:23:18 --> Output Class Initialized
INFO - 2017-03-01 12:23:18 --> Security Class Initialized
DEBUG - 2017-03-01 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 12:23:18 --> Input Class Initialized
INFO - 2017-03-01 12:23:18 --> Language Class Initialized
INFO - 2017-03-01 12:23:18 --> Loader Class Initialized
INFO - 2017-03-01 12:23:18 --> Helper loaded: url_helper
INFO - 2017-03-01 12:23:18 --> Helper loaded: language_helper
INFO - 2017-03-01 12:23:18 --> Helper loaded: html_helper
INFO - 2017-03-01 12:23:18 --> Helper loaded: form_helper
INFO - 2017-03-01 12:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 12:23:18 --> Controller Class Initialized
INFO - 2017-03-01 12:23:18 --> Database Driver Class Initialized
INFO - 2017-03-01 12:23:18 --> Model Class Initialized
INFO - 2017-03-01 12:23:18 --> Email Class Initialized
INFO - 2017-03-01 12:23:18 --> Form Validation Class Initialized
INFO - 2017-03-01 12:23:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 12:23:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 12:23:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 12:23:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 12:23:18 --> Final output sent to browser
DEBUG - 2017-03-01 12:23:18 --> Total execution time: 0.1794
INFO - 2017-03-01 13:31:31 --> Config Class Initialized
INFO - 2017-03-01 13:31:31 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:31:31 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:31:31 --> Utf8 Class Initialized
INFO - 2017-03-01 13:31:31 --> URI Class Initialized
INFO - 2017-03-01 13:31:31 --> Router Class Initialized
INFO - 2017-03-01 13:31:31 --> Output Class Initialized
INFO - 2017-03-01 13:31:31 --> Security Class Initialized
DEBUG - 2017-03-01 13:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:31:31 --> Input Class Initialized
INFO - 2017-03-01 13:31:31 --> Language Class Initialized
INFO - 2017-03-01 13:31:31 --> Loader Class Initialized
INFO - 2017-03-01 13:31:31 --> Helper loaded: url_helper
INFO - 2017-03-01 13:31:31 --> Helper loaded: language_helper
INFO - 2017-03-01 13:31:31 --> Helper loaded: html_helper
INFO - 2017-03-01 13:31:31 --> Helper loaded: form_helper
INFO - 2017-03-01 13:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:31:31 --> Controller Class Initialized
INFO - 2017-03-01 13:31:31 --> Database Driver Class Initialized
INFO - 2017-03-01 13:31:31 --> Model Class Initialized
INFO - 2017-03-01 13:31:31 --> Email Class Initialized
INFO - 2017-03-01 13:31:31 --> Form Validation Class Initialized
INFO - 2017-03-01 13:31:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:31:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 13:31:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 13:31:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 13:31:31 --> Final output sent to browser
DEBUG - 2017-03-01 13:31:31 --> Total execution time: 0.1744
INFO - 2017-03-01 13:37:16 --> Config Class Initialized
INFO - 2017-03-01 13:37:16 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:37:16 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:37:16 --> Utf8 Class Initialized
INFO - 2017-03-01 13:37:16 --> URI Class Initialized
INFO - 2017-03-01 13:37:16 --> Router Class Initialized
INFO - 2017-03-01 13:37:16 --> Output Class Initialized
INFO - 2017-03-01 13:37:16 --> Security Class Initialized
DEBUG - 2017-03-01 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:37:16 --> Input Class Initialized
INFO - 2017-03-01 13:37:16 --> Language Class Initialized
INFO - 2017-03-01 13:37:16 --> Loader Class Initialized
INFO - 2017-03-01 13:37:16 --> Helper loaded: url_helper
INFO - 2017-03-01 13:37:16 --> Helper loaded: language_helper
INFO - 2017-03-01 13:37:16 --> Helper loaded: html_helper
INFO - 2017-03-01 13:37:16 --> Helper loaded: form_helper
INFO - 2017-03-01 13:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:37:16 --> Controller Class Initialized
INFO - 2017-03-01 13:37:16 --> Database Driver Class Initialized
INFO - 2017-03-01 13:37:16 --> Model Class Initialized
INFO - 2017-03-01 13:37:16 --> Email Class Initialized
INFO - 2017-03-01 13:37:16 --> Form Validation Class Initialized
INFO - 2017-03-01 13:37:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:37:16 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-01 13:37:16 --> Final output sent to browser
DEBUG - 2017-03-01 13:37:16 --> Total execution time: 0.2337
INFO - 2017-03-01 13:38:00 --> Config Class Initialized
INFO - 2017-03-01 13:38:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:38:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:38:00 --> Utf8 Class Initialized
INFO - 2017-03-01 13:38:00 --> URI Class Initialized
INFO - 2017-03-01 13:38:00 --> Router Class Initialized
INFO - 2017-03-01 13:38:00 --> Output Class Initialized
INFO - 2017-03-01 13:38:00 --> Security Class Initialized
DEBUG - 2017-03-01 13:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:38:00 --> Input Class Initialized
INFO - 2017-03-01 13:38:00 --> Language Class Initialized
INFO - 2017-03-01 13:38:00 --> Loader Class Initialized
INFO - 2017-03-01 13:38:00 --> Helper loaded: url_helper
INFO - 2017-03-01 13:38:00 --> Helper loaded: language_helper
INFO - 2017-03-01 13:38:00 --> Helper loaded: html_helper
INFO - 2017-03-01 13:38:00 --> Helper loaded: form_helper
INFO - 2017-03-01 13:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:38:00 --> Controller Class Initialized
INFO - 2017-03-01 13:38:00 --> Database Driver Class Initialized
INFO - 2017-03-01 13:38:00 --> Model Class Initialized
INFO - 2017-03-01 13:38:00 --> Email Class Initialized
INFO - 2017-03-01 13:38:00 --> Form Validation Class Initialized
INFO - 2017-03-01 13:38:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:38:00 --> Language file loaded: language/indonesia/form_validation_lang.php
DEBUG - 2017-03-01 13:38:00 --> Unable to find validation rule: xss_clean
ERROR - 2017-03-01 13:38:00 --> Could not find the language line "form_validation_xss_clean"
INFO - 2017-03-01 13:38:00 --> Final output sent to browser
DEBUG - 2017-03-01 13:38:00 --> Total execution time: 0.2326
INFO - 2017-03-01 13:38:36 --> Config Class Initialized
INFO - 2017-03-01 13:38:36 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:38:36 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:38:36 --> Utf8 Class Initialized
INFO - 2017-03-01 13:38:36 --> URI Class Initialized
INFO - 2017-03-01 13:38:36 --> Router Class Initialized
INFO - 2017-03-01 13:38:36 --> Output Class Initialized
INFO - 2017-03-01 13:38:36 --> Security Class Initialized
DEBUG - 2017-03-01 13:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:38:36 --> Input Class Initialized
INFO - 2017-03-01 13:38:36 --> Language Class Initialized
INFO - 2017-03-01 13:38:36 --> Loader Class Initialized
INFO - 2017-03-01 13:38:36 --> Helper loaded: url_helper
INFO - 2017-03-01 13:38:36 --> Helper loaded: language_helper
INFO - 2017-03-01 13:38:36 --> Helper loaded: html_helper
INFO - 2017-03-01 13:38:36 --> Helper loaded: form_helper
INFO - 2017-03-01 13:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:38:36 --> Controller Class Initialized
INFO - 2017-03-01 13:38:36 --> Database Driver Class Initialized
INFO - 2017-03-01 13:38:36 --> Model Class Initialized
INFO - 2017-03-01 13:38:36 --> Email Class Initialized
INFO - 2017-03-01 13:38:36 --> Form Validation Class Initialized
INFO - 2017-03-01 13:38:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:38:36 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-01 13:38:36 --> Final output sent to browser
DEBUG - 2017-03-01 13:38:36 --> Total execution time: 0.1716
INFO - 2017-03-01 13:39:45 --> Config Class Initialized
INFO - 2017-03-01 13:39:45 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:39:45 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:39:45 --> Utf8 Class Initialized
INFO - 2017-03-01 13:39:45 --> URI Class Initialized
INFO - 2017-03-01 13:39:45 --> Router Class Initialized
INFO - 2017-03-01 13:39:45 --> Output Class Initialized
INFO - 2017-03-01 13:39:45 --> Security Class Initialized
DEBUG - 2017-03-01 13:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:39:45 --> Input Class Initialized
INFO - 2017-03-01 13:39:45 --> Language Class Initialized
INFO - 2017-03-01 13:39:45 --> Loader Class Initialized
INFO - 2017-03-01 13:39:45 --> Helper loaded: url_helper
INFO - 2017-03-01 13:39:45 --> Helper loaded: language_helper
INFO - 2017-03-01 13:39:45 --> Helper loaded: html_helper
INFO - 2017-03-01 13:39:45 --> Helper loaded: form_helper
INFO - 2017-03-01 13:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:39:46 --> Controller Class Initialized
INFO - 2017-03-01 13:39:46 --> Database Driver Class Initialized
INFO - 2017-03-01 13:39:46 --> Model Class Initialized
INFO - 2017-03-01 13:39:46 --> Email Class Initialized
INFO - 2017-03-01 13:39:46 --> Form Validation Class Initialized
INFO - 2017-03-01 13:39:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:39:46 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-03-01 13:39:47 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-01 13:39:47 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-01 13:39:47 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-03-01 13:39:47 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-01 13:40:09 --> Config Class Initialized
INFO - 2017-03-01 13:40:09 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:40:09 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:40:09 --> Utf8 Class Initialized
INFO - 2017-03-01 13:40:09 --> URI Class Initialized
INFO - 2017-03-01 13:40:09 --> Router Class Initialized
INFO - 2017-03-01 13:40:09 --> Output Class Initialized
INFO - 2017-03-01 13:40:09 --> Security Class Initialized
DEBUG - 2017-03-01 13:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:40:09 --> Input Class Initialized
INFO - 2017-03-01 13:40:09 --> Language Class Initialized
INFO - 2017-03-01 13:40:09 --> Loader Class Initialized
INFO - 2017-03-01 13:40:09 --> Helper loaded: url_helper
INFO - 2017-03-01 13:40:09 --> Helper loaded: language_helper
INFO - 2017-03-01 13:40:09 --> Helper loaded: html_helper
INFO - 2017-03-01 13:40:09 --> Helper loaded: form_helper
INFO - 2017-03-01 13:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:40:09 --> Controller Class Initialized
INFO - 2017-03-01 13:40:09 --> Database Driver Class Initialized
INFO - 2017-03-01 13:40:09 --> Model Class Initialized
INFO - 2017-03-01 13:40:09 --> Email Class Initialized
INFO - 2017-03-01 13:40:09 --> Form Validation Class Initialized
INFO - 2017-03-01 13:40:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:40:09 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-01 13:40:11 --> Language file loaded: language/indonesia/email_lang.php
ERROR - 2017-03-01 13:40:15 --> Severity: Error --> Call to undefined function save_lampiran() C:\wamp64\www\savsoftquiz\application\models\Register_model.php 65
INFO - 2017-03-01 13:43:18 --> Config Class Initialized
INFO - 2017-03-01 13:43:18 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:43:18 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:43:18 --> Utf8 Class Initialized
INFO - 2017-03-01 13:43:18 --> URI Class Initialized
INFO - 2017-03-01 13:43:18 --> Router Class Initialized
INFO - 2017-03-01 13:43:18 --> Output Class Initialized
INFO - 2017-03-01 13:43:18 --> Security Class Initialized
DEBUG - 2017-03-01 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:43:18 --> Input Class Initialized
INFO - 2017-03-01 13:43:18 --> Language Class Initialized
INFO - 2017-03-01 13:43:18 --> Loader Class Initialized
INFO - 2017-03-01 13:43:18 --> Helper loaded: url_helper
INFO - 2017-03-01 13:43:18 --> Helper loaded: language_helper
INFO - 2017-03-01 13:43:18 --> Helper loaded: html_helper
INFO - 2017-03-01 13:43:18 --> Helper loaded: form_helper
INFO - 2017-03-01 13:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:43:18 --> Controller Class Initialized
INFO - 2017-03-01 13:43:18 --> Database Driver Class Initialized
INFO - 2017-03-01 13:43:18 --> Model Class Initialized
INFO - 2017-03-01 13:43:18 --> Email Class Initialized
INFO - 2017-03-01 13:43:18 --> Form Validation Class Initialized
INFO - 2017-03-01 13:43:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:43:18 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-01 13:43:19 --> Final output sent to browser
DEBUG - 2017-03-01 13:43:19 --> Total execution time: 0.9744
INFO - 2017-03-01 13:43:21 --> Config Class Initialized
INFO - 2017-03-01 13:43:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:43:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:43:21 --> Utf8 Class Initialized
INFO - 2017-03-01 13:43:21 --> URI Class Initialized
INFO - 2017-03-01 13:43:21 --> Router Class Initialized
INFO - 2017-03-01 13:43:21 --> Output Class Initialized
INFO - 2017-03-01 13:43:21 --> Security Class Initialized
DEBUG - 2017-03-01 13:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:43:21 --> Input Class Initialized
INFO - 2017-03-01 13:43:21 --> Language Class Initialized
INFO - 2017-03-01 13:43:21 --> Loader Class Initialized
INFO - 2017-03-01 13:43:21 --> Helper loaded: url_helper
INFO - 2017-03-01 13:43:21 --> Helper loaded: language_helper
INFO - 2017-03-01 13:43:21 --> Helper loaded: html_helper
INFO - 2017-03-01 13:43:21 --> Helper loaded: form_helper
INFO - 2017-03-01 13:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:43:21 --> Controller Class Initialized
INFO - 2017-03-01 13:43:21 --> Database Driver Class Initialized
INFO - 2017-03-01 13:43:21 --> Model Class Initialized
INFO - 2017-03-01 13:43:21 --> Email Class Initialized
INFO - 2017-03-01 13:43:21 --> Form Validation Class Initialized
INFO - 2017-03-01 13:43:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 13:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-03-01 13:43:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 13:43:21 --> Final output sent to browser
DEBUG - 2017-03-01 13:43:21 --> Total execution time: 0.1506
INFO - 2017-03-01 13:43:23 --> Config Class Initialized
INFO - 2017-03-01 13:43:23 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:43:23 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:43:23 --> Utf8 Class Initialized
INFO - 2017-03-01 13:43:23 --> URI Class Initialized
DEBUG - 2017-03-01 13:43:23 --> No URI present. Default controller set.
INFO - 2017-03-01 13:43:23 --> Router Class Initialized
INFO - 2017-03-01 13:43:23 --> Output Class Initialized
INFO - 2017-03-01 13:43:23 --> Security Class Initialized
DEBUG - 2017-03-01 13:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:43:23 --> Input Class Initialized
INFO - 2017-03-01 13:43:23 --> Language Class Initialized
INFO - 2017-03-01 13:43:23 --> Loader Class Initialized
INFO - 2017-03-01 13:43:23 --> Helper loaded: url_helper
INFO - 2017-03-01 13:43:23 --> Helper loaded: language_helper
INFO - 2017-03-01 13:43:23 --> Helper loaded: html_helper
INFO - 2017-03-01 13:43:23 --> Helper loaded: form_helper
INFO - 2017-03-01 13:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:43:23 --> Controller Class Initialized
INFO - 2017-03-01 13:43:23 --> Database Driver Class Initialized
INFO - 2017-03-01 13:43:23 --> Model Class Initialized
INFO - 2017-03-01 13:43:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:43:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-01 13:43:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-01 13:43:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-01 13:43:23 --> Final output sent to browser
DEBUG - 2017-03-01 13:43:23 --> Total execution time: 0.1599
INFO - 2017-03-01 13:50:18 --> Config Class Initialized
INFO - 2017-03-01 13:50:18 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:50:18 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:50:18 --> Utf8 Class Initialized
INFO - 2017-03-01 13:50:18 --> URI Class Initialized
INFO - 2017-03-01 13:50:18 --> Router Class Initialized
INFO - 2017-03-01 13:50:18 --> Output Class Initialized
INFO - 2017-03-01 13:50:18 --> Security Class Initialized
DEBUG - 2017-03-01 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:50:18 --> Input Class Initialized
INFO - 2017-03-01 13:50:18 --> Language Class Initialized
INFO - 2017-03-01 13:50:18 --> Loader Class Initialized
INFO - 2017-03-01 13:50:18 --> Helper loaded: url_helper
INFO - 2017-03-01 13:50:18 --> Helper loaded: language_helper
INFO - 2017-03-01 13:50:18 --> Helper loaded: html_helper
INFO - 2017-03-01 13:50:18 --> Helper loaded: form_helper
INFO - 2017-03-01 13:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:50:18 --> Controller Class Initialized
INFO - 2017-03-01 13:50:18 --> Database Driver Class Initialized
INFO - 2017-03-01 13:50:18 --> Model Class Initialized
INFO - 2017-03-01 13:50:18 --> Email Class Initialized
INFO - 2017-03-01 13:50:18 --> Form Validation Class Initialized
INFO - 2017-03-01 13:50:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:50:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 13:50:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 13:50:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 13:50:18 --> Final output sent to browser
DEBUG - 2017-03-01 13:50:18 --> Total execution time: 0.1917
INFO - 2017-03-01 13:52:43 --> Config Class Initialized
INFO - 2017-03-01 13:52:43 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:52:43 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:52:43 --> Utf8 Class Initialized
INFO - 2017-03-01 13:52:43 --> URI Class Initialized
INFO - 2017-03-01 13:52:43 --> Router Class Initialized
INFO - 2017-03-01 13:52:43 --> Output Class Initialized
INFO - 2017-03-01 13:52:43 --> Security Class Initialized
DEBUG - 2017-03-01 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:52:43 --> Input Class Initialized
INFO - 2017-03-01 13:52:43 --> Language Class Initialized
INFO - 2017-03-01 13:52:43 --> Loader Class Initialized
INFO - 2017-03-01 13:52:43 --> Helper loaded: url_helper
INFO - 2017-03-01 13:52:43 --> Helper loaded: language_helper
INFO - 2017-03-01 13:52:43 --> Helper loaded: html_helper
INFO - 2017-03-01 13:52:43 --> Helper loaded: form_helper
INFO - 2017-03-01 13:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:52:43 --> Controller Class Initialized
INFO - 2017-03-01 13:52:43 --> Database Driver Class Initialized
INFO - 2017-03-01 13:52:43 --> Model Class Initialized
INFO - 2017-03-01 13:52:43 --> Email Class Initialized
INFO - 2017-03-01 13:52:43 --> Form Validation Class Initialized
INFO - 2017-03-01 13:52:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:52:43 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-03-01 13:52:43 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-01 13:52:43 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-01 13:52:43 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-03-01 13:52:43 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-01 13:52:57 --> Config Class Initialized
INFO - 2017-03-01 13:52:57 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:52:57 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:52:57 --> Utf8 Class Initialized
INFO - 2017-03-01 13:52:57 --> URI Class Initialized
INFO - 2017-03-01 13:52:57 --> Router Class Initialized
INFO - 2017-03-01 13:52:57 --> Output Class Initialized
INFO - 2017-03-01 13:52:57 --> Security Class Initialized
DEBUG - 2017-03-01 13:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:52:57 --> Input Class Initialized
INFO - 2017-03-01 13:52:57 --> Language Class Initialized
INFO - 2017-03-01 13:52:57 --> Loader Class Initialized
INFO - 2017-03-01 13:52:57 --> Helper loaded: url_helper
INFO - 2017-03-01 13:52:57 --> Helper loaded: language_helper
INFO - 2017-03-01 13:52:57 --> Helper loaded: html_helper
INFO - 2017-03-01 13:52:57 --> Helper loaded: form_helper
INFO - 2017-03-01 13:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:52:57 --> Controller Class Initialized
INFO - 2017-03-01 13:52:57 --> Database Driver Class Initialized
INFO - 2017-03-01 13:52:57 --> Model Class Initialized
INFO - 2017-03-01 13:52:57 --> Email Class Initialized
INFO - 2017-03-01 13:52:57 --> Form Validation Class Initialized
INFO - 2017-03-01 13:52:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:52:57 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-01 13:52:58 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-01 13:53:02 --> Final output sent to browser
DEBUG - 2017-03-01 13:53:02 --> Total execution time: 4.7828
INFO - 2017-03-01 13:53:05 --> Config Class Initialized
INFO - 2017-03-01 13:53:05 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:53:05 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:53:05 --> Utf8 Class Initialized
INFO - 2017-03-01 13:53:05 --> URI Class Initialized
INFO - 2017-03-01 13:53:05 --> Router Class Initialized
INFO - 2017-03-01 13:53:05 --> Output Class Initialized
INFO - 2017-03-01 13:53:05 --> Security Class Initialized
DEBUG - 2017-03-01 13:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:53:05 --> Input Class Initialized
INFO - 2017-03-01 13:53:05 --> Language Class Initialized
INFO - 2017-03-01 13:53:05 --> Loader Class Initialized
INFO - 2017-03-01 13:53:05 --> Helper loaded: url_helper
INFO - 2017-03-01 13:53:05 --> Helper loaded: language_helper
INFO - 2017-03-01 13:53:05 --> Helper loaded: html_helper
INFO - 2017-03-01 13:53:05 --> Helper loaded: form_helper
INFO - 2017-03-01 13:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:53:05 --> Controller Class Initialized
INFO - 2017-03-01 13:53:05 --> Database Driver Class Initialized
INFO - 2017-03-01 13:53:05 --> Model Class Initialized
INFO - 2017-03-01 13:53:05 --> Email Class Initialized
INFO - 2017-03-01 13:53:05 --> Form Validation Class Initialized
INFO - 2017-03-01 13:53:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:53:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 13:53:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-03-01 13:53:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 13:53:05 --> Final output sent to browser
DEBUG - 2017-03-01 13:53:05 --> Total execution time: 0.1648
INFO - 2017-03-01 13:54:14 --> Config Class Initialized
INFO - 2017-03-01 13:54:14 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:54:14 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:54:14 --> Utf8 Class Initialized
INFO - 2017-03-01 13:54:14 --> URI Class Initialized
DEBUG - 2017-03-01 13:54:14 --> No URI present. Default controller set.
INFO - 2017-03-01 13:54:14 --> Router Class Initialized
INFO - 2017-03-01 13:54:14 --> Output Class Initialized
INFO - 2017-03-01 13:54:14 --> Security Class Initialized
DEBUG - 2017-03-01 13:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:54:14 --> Input Class Initialized
INFO - 2017-03-01 13:54:14 --> Language Class Initialized
INFO - 2017-03-01 13:54:14 --> Loader Class Initialized
INFO - 2017-03-01 13:54:14 --> Helper loaded: url_helper
INFO - 2017-03-01 13:54:14 --> Helper loaded: language_helper
INFO - 2017-03-01 13:54:14 --> Helper loaded: html_helper
INFO - 2017-03-01 13:54:14 --> Helper loaded: form_helper
INFO - 2017-03-01 13:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:54:14 --> Controller Class Initialized
INFO - 2017-03-01 13:54:14 --> Database Driver Class Initialized
INFO - 2017-03-01 13:54:14 --> Model Class Initialized
INFO - 2017-03-01 13:54:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-01 13:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-01 13:54:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-01 13:54:14 --> Final output sent to browser
DEBUG - 2017-03-01 13:54:14 --> Total execution time: 0.1146
INFO - 2017-03-01 13:54:23 --> Config Class Initialized
INFO - 2017-03-01 13:54:23 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:54:23 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:54:23 --> Utf8 Class Initialized
INFO - 2017-03-01 13:54:23 --> URI Class Initialized
INFO - 2017-03-01 13:54:23 --> Router Class Initialized
INFO - 2017-03-01 13:54:23 --> Output Class Initialized
INFO - 2017-03-01 13:54:23 --> Security Class Initialized
DEBUG - 2017-03-01 13:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:54:23 --> Input Class Initialized
INFO - 2017-03-01 13:54:23 --> Language Class Initialized
INFO - 2017-03-01 13:54:23 --> Loader Class Initialized
INFO - 2017-03-01 13:54:23 --> Helper loaded: url_helper
INFO - 2017-03-01 13:54:23 --> Helper loaded: language_helper
INFO - 2017-03-01 13:54:23 --> Helper loaded: html_helper
INFO - 2017-03-01 13:54:23 --> Helper loaded: form_helper
INFO - 2017-03-01 13:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:54:23 --> Controller Class Initialized
INFO - 2017-03-01 13:54:23 --> Database Driver Class Initialized
INFO - 2017-03-01 13:54:23 --> Model Class Initialized
INFO - 2017-03-01 13:54:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:54:23 --> Config Class Initialized
INFO - 2017-03-01 13:54:23 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:54:23 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:54:23 --> Utf8 Class Initialized
INFO - 2017-03-01 13:54:23 --> URI Class Initialized
INFO - 2017-03-01 13:54:23 --> Router Class Initialized
INFO - 2017-03-01 13:54:23 --> Output Class Initialized
INFO - 2017-03-01 13:54:23 --> Security Class Initialized
DEBUG - 2017-03-01 13:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:54:23 --> Input Class Initialized
INFO - 2017-03-01 13:54:23 --> Language Class Initialized
INFO - 2017-03-01 13:54:23 --> Loader Class Initialized
INFO - 2017-03-01 13:54:23 --> Helper loaded: url_helper
INFO - 2017-03-01 13:54:23 --> Helper loaded: language_helper
INFO - 2017-03-01 13:54:23 --> Helper loaded: html_helper
INFO - 2017-03-01 13:54:23 --> Helper loaded: form_helper
INFO - 2017-03-01 13:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:54:23 --> Controller Class Initialized
INFO - 2017-03-01 13:54:23 --> Database Driver Class Initialized
INFO - 2017-03-01 13:54:23 --> Model Class Initialized
INFO - 2017-03-01 13:54:23 --> Model Class Initialized
INFO - 2017-03-01 13:54:23 --> Model Class Initialized
INFO - 2017-03-01 13:54:23 --> Model Class Initialized
INFO - 2017-03-01 13:54:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:54:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 13:54:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-03-01 13:54:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 13:54:23 --> Final output sent to browser
DEBUG - 2017-03-01 13:54:23 --> Total execution time: 0.2005
INFO - 2017-03-01 13:54:26 --> Config Class Initialized
INFO - 2017-03-01 13:54:26 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:54:26 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:54:26 --> Utf8 Class Initialized
INFO - 2017-03-01 13:54:26 --> URI Class Initialized
INFO - 2017-03-01 13:54:26 --> Router Class Initialized
INFO - 2017-03-01 13:54:26 --> Output Class Initialized
INFO - 2017-03-01 13:54:26 --> Security Class Initialized
DEBUG - 2017-03-01 13:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:54:26 --> Input Class Initialized
INFO - 2017-03-01 13:54:26 --> Language Class Initialized
INFO - 2017-03-01 13:54:26 --> Loader Class Initialized
INFO - 2017-03-01 13:54:26 --> Helper loaded: url_helper
INFO - 2017-03-01 13:54:26 --> Helper loaded: language_helper
INFO - 2017-03-01 13:54:26 --> Helper loaded: html_helper
INFO - 2017-03-01 13:54:26 --> Helper loaded: form_helper
INFO - 2017-03-01 13:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:54:26 --> Controller Class Initialized
INFO - 2017-03-01 13:54:26 --> Database Driver Class Initialized
INFO - 2017-03-01 13:54:26 --> Model Class Initialized
INFO - 2017-03-01 13:54:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:54:26 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 13:54:26 --> Pagination Class Initialized
INFO - 2017-03-01 13:54:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 13:54:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 13:54:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 13:54:26 --> Final output sent to browser
DEBUG - 2017-03-01 13:54:26 --> Total execution time: 0.1399
INFO - 2017-03-01 13:55:01 --> Config Class Initialized
INFO - 2017-03-01 13:55:01 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:55:01 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:55:01 --> Utf8 Class Initialized
INFO - 2017-03-01 13:55:01 --> URI Class Initialized
INFO - 2017-03-01 13:55:01 --> Router Class Initialized
INFO - 2017-03-01 13:55:01 --> Output Class Initialized
INFO - 2017-03-01 13:55:01 --> Security Class Initialized
DEBUG - 2017-03-01 13:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:55:01 --> Input Class Initialized
INFO - 2017-03-01 13:55:01 --> Language Class Initialized
INFO - 2017-03-01 13:55:01 --> Loader Class Initialized
INFO - 2017-03-01 13:55:01 --> Helper loaded: url_helper
INFO - 2017-03-01 13:55:01 --> Helper loaded: language_helper
INFO - 2017-03-01 13:55:01 --> Helper loaded: html_helper
INFO - 2017-03-01 13:55:01 --> Helper loaded: form_helper
INFO - 2017-03-01 13:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:55:01 --> Controller Class Initialized
INFO - 2017-03-01 13:55:01 --> Database Driver Class Initialized
INFO - 2017-03-01 13:55:01 --> Model Class Initialized
INFO - 2017-03-01 13:55:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:55:01 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 13:55:01 --> Pagination Class Initialized
INFO - 2017-03-01 13:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 13:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 13:55:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 13:55:01 --> Final output sent to browser
DEBUG - 2017-03-01 13:55:01 --> Total execution time: 0.1535
INFO - 2017-03-01 13:55:05 --> Config Class Initialized
INFO - 2017-03-01 13:55:05 --> Hooks Class Initialized
DEBUG - 2017-03-01 13:55:05 --> UTF-8 Support Enabled
INFO - 2017-03-01 13:55:05 --> Utf8 Class Initialized
INFO - 2017-03-01 13:55:05 --> URI Class Initialized
INFO - 2017-03-01 13:55:05 --> Router Class Initialized
INFO - 2017-03-01 13:55:05 --> Output Class Initialized
INFO - 2017-03-01 13:55:05 --> Security Class Initialized
DEBUG - 2017-03-01 13:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 13:55:05 --> Input Class Initialized
INFO - 2017-03-01 13:55:05 --> Language Class Initialized
INFO - 2017-03-01 13:55:05 --> Loader Class Initialized
INFO - 2017-03-01 13:55:05 --> Helper loaded: url_helper
INFO - 2017-03-01 13:55:05 --> Helper loaded: language_helper
INFO - 2017-03-01 13:55:05 --> Helper loaded: html_helper
INFO - 2017-03-01 13:55:05 --> Helper loaded: form_helper
INFO - 2017-03-01 13:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 13:55:05 --> Controller Class Initialized
INFO - 2017-03-01 13:55:05 --> Database Driver Class Initialized
INFO - 2017-03-01 13:55:05 --> Model Class Initialized
INFO - 2017-03-01 13:55:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 13:55:05 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 13:55:05 --> Pagination Class Initialized
INFO - 2017-03-01 13:55:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 13:55:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 13:55:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 13:55:05 --> Final output sent to browser
DEBUG - 2017-03-01 13:55:05 --> Total execution time: 0.1115
INFO - 2017-03-01 14:01:29 --> Config Class Initialized
INFO - 2017-03-01 14:01:29 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:01:29 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:01:29 --> Utf8 Class Initialized
INFO - 2017-03-01 14:01:29 --> URI Class Initialized
INFO - 2017-03-01 14:01:29 --> Router Class Initialized
INFO - 2017-03-01 14:01:29 --> Output Class Initialized
INFO - 2017-03-01 14:01:29 --> Security Class Initialized
DEBUG - 2017-03-01 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:01:29 --> Input Class Initialized
INFO - 2017-03-01 14:01:29 --> Language Class Initialized
INFO - 2017-03-01 14:01:29 --> Loader Class Initialized
INFO - 2017-03-01 14:01:29 --> Helper loaded: url_helper
INFO - 2017-03-01 14:01:29 --> Helper loaded: language_helper
INFO - 2017-03-01 14:01:29 --> Helper loaded: html_helper
INFO - 2017-03-01 14:01:29 --> Helper loaded: form_helper
INFO - 2017-03-01 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:01:29 --> Controller Class Initialized
INFO - 2017-03-01 14:01:29 --> Database Driver Class Initialized
INFO - 2017-03-01 14:01:29 --> Model Class Initialized
INFO - 2017-03-01 14:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:01:29 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:01:29 --> Pagination Class Initialized
INFO - 2017-03-01 14:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta_detail.php
INFO - 2017-03-01 14:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:01:29 --> Final output sent to browser
DEBUG - 2017-03-01 14:01:29 --> Total execution time: 0.1383
INFO - 2017-03-01 14:01:29 --> Config Class Initialized
INFO - 2017-03-01 14:01:29 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:01:29 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:01:29 --> Utf8 Class Initialized
INFO - 2017-03-01 14:01:29 --> URI Class Initialized
INFO - 2017-03-01 14:01:29 --> Router Class Initialized
INFO - 2017-03-01 14:01:29 --> Output Class Initialized
INFO - 2017-03-01 14:01:29 --> Security Class Initialized
DEBUG - 2017-03-01 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:01:29 --> Input Class Initialized
INFO - 2017-03-01 14:01:29 --> Language Class Initialized
INFO - 2017-03-01 14:01:29 --> Loader Class Initialized
INFO - 2017-03-01 14:01:29 --> Helper loaded: url_helper
INFO - 2017-03-01 14:01:29 --> Helper loaded: language_helper
INFO - 2017-03-01 14:01:29 --> Helper loaded: html_helper
INFO - 2017-03-01 14:01:29 --> Helper loaded: form_helper
INFO - 2017-03-01 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:01:29 --> Controller Class Initialized
INFO - 2017-03-01 14:01:30 --> Database Driver Class Initialized
INFO - 2017-03-01 14:01:30 --> Model Class Initialized
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:01:30 --> Pagination Class Initialized
INFO - 2017-03-01 14:01:30 --> Config Class Initialized
INFO - 2017-03-01 14:01:30 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:01:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:01:30 --> URI Class Initialized
INFO - 2017-03-01 14:01:30 --> Config Class Initialized
INFO - 2017-03-01 14:01:30 --> Router Class Initialized
INFO - 2017-03-01 14:01:30 --> Hooks Class Initialized
INFO - 2017-03-01 14:01:30 --> Output Class Initialized
INFO - 2017-03-01 14:01:30 --> Security Class Initialized
DEBUG - 2017-03-01 14:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:01:30 --> Config Class Initialized
INFO - 2017-03-01 14:01:30 --> Config Class Initialized
INFO - 2017-03-01 14:01:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:01:30 --> Hooks Class Initialized
INFO - 2017-03-01 14:01:30 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:01:30 --> URI Class Initialized
INFO - 2017-03-01 14:01:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:01:30 --> URI Class Initialized
INFO - 2017-03-01 14:01:30 --> Router Class Initialized
INFO - 2017-03-01 14:01:30 --> Config Class Initialized
INFO - 2017-03-01 14:01:30 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:01:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:01:30 --> URI Class Initialized
DEBUG - 2017-03-01 14:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:01:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:01:30 --> Router Class Initialized
DEBUG - 2017-03-01 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:01:30 --> Input Class Initialized
INFO - 2017-03-01 14:01:30 --> URI Class Initialized
INFO - 2017-03-01 14:01:30 --> Language Class Initialized
INFO - 2017-03-01 14:01:30 --> Output Class Initialized
INFO - 2017-03-01 14:01:30 --> Router Class Initialized
INFO - 2017-03-01 14:01:30 --> Config Class Initialized
INFO - 2017-03-01 14:01:30 --> Hooks Class Initialized
INFO - 2017-03-01 14:01:30 --> Security Class Initialized
INFO - 2017-03-01 14:01:30 --> Loader Class Initialized
INFO - 2017-03-01 14:01:30 --> Output Class Initialized
DEBUG - 2017-03-01 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:01:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:01:30 --> Input Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: language_helper
INFO - 2017-03-01 14:01:30 --> Language Class Initialized
DEBUG - 2017-03-01 14:01:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:01:30 --> Security Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: html_helper
INFO - 2017-03-01 14:01:30 --> Loader Class Initialized
INFO - 2017-03-01 14:01:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: form_helper
DEBUG - 2017-03-01 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:01:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:01:30 --> Input Class Initialized
INFO - 2017-03-01 14:01:30 --> URI Class Initialized
INFO - 2017-03-01 14:01:30 --> Language Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: language_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: html_helper
INFO - 2017-03-01 14:01:30 --> Router Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: form_helper
INFO - 2017-03-01 14:01:30 --> Loader Class Initialized
INFO - 2017-03-01 14:01:30 --> Output Class Initialized
INFO - 2017-03-01 14:01:30 --> Router Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:01:30 --> Output Class Initialized
INFO - 2017-03-01 14:01:30 --> Output Class Initialized
INFO - 2017-03-01 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:01:30 --> Controller Class Initialized
INFO - 2017-03-01 14:01:30 --> Security Class Initialized
INFO - 2017-03-01 14:01:30 --> Security Class Initialized
DEBUG - 2017-03-01 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:01:30 --> Input Class Initialized
DEBUG - 2017-03-01 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:01:30 --> Security Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: language_helper
INFO - 2017-03-01 14:01:30 --> Input Class Initialized
INFO - 2017-03-01 14:01:30 --> Language Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: html_helper
INFO - 2017-03-01 14:01:30 --> Language Class Initialized
DEBUG - 2017-03-01 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:01:30 --> Input Class Initialized
INFO - 2017-03-01 14:01:30 --> Language Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: form_helper
INFO - 2017-03-01 14:01:30 --> Loader Class Initialized
INFO - 2017-03-01 14:01:30 --> Loader Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: language_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: html_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: language_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: html_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: form_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: form_helper
INFO - 2017-03-01 14:01:30 --> Loader Class Initialized
INFO - 2017-03-01 14:01:30 --> Database Driver Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: language_helper
INFO - 2017-03-01 14:01:30 --> Helper loaded: html_helper
INFO - 2017-03-01 14:01:30 --> Model Class Initialized
INFO - 2017-03-01 14:01:30 --> Helper loaded: form_helper
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:01:30 --> Pagination Class Initialized
INFO - 2017-03-01 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:01:30 --> Controller Class Initialized
INFO - 2017-03-01 14:01:30 --> Database Driver Class Initialized
INFO - 2017-03-01 14:01:30 --> Model Class Initialized
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:01:30 --> Pagination Class Initialized
INFO - 2017-03-01 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:01:30 --> Controller Class Initialized
INFO - 2017-03-01 14:01:30 --> Database Driver Class Initialized
INFO - 2017-03-01 14:01:30 --> Model Class Initialized
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:01:30 --> Pagination Class Initialized
INFO - 2017-03-01 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:01:30 --> Controller Class Initialized
INFO - 2017-03-01 14:01:30 --> Database Driver Class Initialized
INFO - 2017-03-01 14:01:30 --> Model Class Initialized
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:01:30 --> Pagination Class Initialized
INFO - 2017-03-01 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:01:30 --> Controller Class Initialized
INFO - 2017-03-01 14:01:30 --> Database Driver Class Initialized
INFO - 2017-03-01 14:01:30 --> Model Class Initialized
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:01:30 --> Pagination Class Initialized
INFO - 2017-03-01 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:01:30 --> Controller Class Initialized
INFO - 2017-03-01 14:01:30 --> Database Driver Class Initialized
INFO - 2017-03-01 14:01:30 --> Model Class Initialized
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:01:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:01:30 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:39 --> Config Class Initialized
INFO - 2017-03-01 14:03:39 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:03:39 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:39 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:39 --> URI Class Initialized
INFO - 2017-03-01 14:03:39 --> Router Class Initialized
INFO - 2017-03-01 14:03:39 --> Output Class Initialized
INFO - 2017-03-01 14:03:39 --> Security Class Initialized
DEBUG - 2017-03-01 14:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:39 --> Input Class Initialized
INFO - 2017-03-01 14:03:39 --> Language Class Initialized
INFO - 2017-03-01 14:03:39 --> Loader Class Initialized
INFO - 2017-03-01 14:03:39 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:39 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:39 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:39 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:40 --> Controller Class Initialized
INFO - 2017-03-01 14:03:40 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:40 --> Model Class Initialized
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:40 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:03:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta_detail.php
INFO - 2017-03-01 14:03:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:03:40 --> Final output sent to browser
DEBUG - 2017-03-01 14:03:40 --> Total execution time: 0.1697
INFO - 2017-03-01 14:03:40 --> Config Class Initialized
INFO - 2017-03-01 14:03:40 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:40 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:40 --> URI Class Initialized
INFO - 2017-03-01 14:03:40 --> Router Class Initialized
INFO - 2017-03-01 14:03:40 --> Output Class Initialized
INFO - 2017-03-01 14:03:40 --> Security Class Initialized
DEBUG - 2017-03-01 14:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:40 --> Input Class Initialized
INFO - 2017-03-01 14:03:40 --> Language Class Initialized
INFO - 2017-03-01 14:03:40 --> Loader Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:40 --> Controller Class Initialized
INFO - 2017-03-01 14:03:40 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:40 --> Config Class Initialized
INFO - 2017-03-01 14:03:40 --> Hooks Class Initialized
INFO - 2017-03-01 14:03:40 --> Config Class Initialized
INFO - 2017-03-01 14:03:40 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:40 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:40 --> URI Class Initialized
DEBUG - 2017-03-01 14:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:40 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:40 --> Router Class Initialized
INFO - 2017-03-01 14:03:40 --> URI Class Initialized
INFO - 2017-03-01 14:03:40 --> Model Class Initialized
INFO - 2017-03-01 14:03:40 --> Config Class Initialized
INFO - 2017-03-01 14:03:40 --> Output Class Initialized
INFO - 2017-03-01 14:03:40 --> Hooks Class Initialized
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:40 --> Security Class Initialized
DEBUG - 2017-03-01 14:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-01 14:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:40 --> Input Class Initialized
INFO - 2017-03-01 14:03:40 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:40 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:40 --> Language Class Initialized
INFO - 2017-03-01 14:03:40 --> URI Class Initialized
INFO - 2017-03-01 14:03:40 --> Loader Class Initialized
INFO - 2017-03-01 14:03:40 --> Router Class Initialized
INFO - 2017-03-01 14:03:40 --> Config Class Initialized
INFO - 2017-03-01 14:03:40 --> Hooks Class Initialized
INFO - 2017-03-01 14:03:40 --> Output Class Initialized
INFO - 2017-03-01 14:03:40 --> Security Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: url_helper
DEBUG - 2017-03-01 14:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:40 --> Input Class Initialized
INFO - 2017-03-01 14:03:40 --> Language Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:40 --> Config Class Initialized
INFO - 2017-03-01 14:03:40 --> Hooks Class Initialized
INFO - 2017-03-01 14:03:40 --> Loader Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: form_helper
DEBUG - 2017-03-01 14:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:40 --> Router Class Initialized
INFO - 2017-03-01 14:03:40 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:40 --> Config Class Initialized
INFO - 2017-03-01 14:03:40 --> Hooks Class Initialized
INFO - 2017-03-01 14:03:40 --> URI Class Initialized
INFO - 2017-03-01 14:03:40 --> Output Class Initialized
INFO - 2017-03-01 14:03:40 --> Security Class Initialized
INFO - 2017-03-01 14:03:40 --> Router Class Initialized
DEBUG - 2017-03-01 14:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:40 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-01 14:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:40 --> Controller Class Initialized
INFO - 2017-03-01 14:03:40 --> Output Class Initialized
INFO - 2017-03-01 14:03:40 --> Input Class Initialized
INFO - 2017-03-01 14:03:40 --> URI Class Initialized
INFO - 2017-03-01 14:03:40 --> Language Class Initialized
INFO - 2017-03-01 14:03:40 --> Security Class Initialized
INFO - 2017-03-01 14:03:40 --> Loader Class Initialized
DEBUG - 2017-03-01 14:03:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:40 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:40 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:40 --> URI Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:40 --> Router Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: html_helper
DEBUG - 2017-03-01 14:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:40 --> Router Class Initialized
INFO - 2017-03-01 14:03:40 --> Input Class Initialized
INFO - 2017-03-01 14:03:40 --> Output Class Initialized
INFO - 2017-03-01 14:03:40 --> Language Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:40 --> Output Class Initialized
INFO - 2017-03-01 14:03:40 --> Security Class Initialized
INFO - 2017-03-01 14:03:40 --> Database Driver Class Initialized
DEBUG - 2017-03-01 14:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:40 --> Input Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:40 --> Model Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:40 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:40 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:40 --> Language Class Initialized
INFO - 2017-03-01 14:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:40 --> Controller Class Initialized
INFO - 2017-03-01 14:03:40 --> Security Class Initialized
INFO - 2017-03-01 14:03:40 --> Loader Class Initialized
INFO - 2017-03-01 14:03:40 --> Loader Class Initialized
DEBUG - 2017-03-01 14:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:40 --> Input Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:40 --> Language Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:40 --> Loader Class Initialized
INFO - 2017-03-01 14:03:40 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:40 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:40 --> Model Class Initialized
INFO - 2017-03-01 14:03:40 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:40 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:40 --> Controller Class Initialized
INFO - 2017-03-01 14:03:40 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:40 --> Model Class Initialized
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:40 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:40 --> Controller Class Initialized
INFO - 2017-03-01 14:03:40 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:40 --> Model Class Initialized
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:40 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:40 --> Controller Class Initialized
INFO - 2017-03-01 14:03:40 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:40 --> Model Class Initialized
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:40 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:40 --> Controller Class Initialized
INFO - 2017-03-01 14:03:40 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:40 --> Model Class Initialized
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:40 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:53 --> Config Class Initialized
INFO - 2017-03-01 14:03:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:03:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:53 --> URI Class Initialized
INFO - 2017-03-01 14:03:53 --> Router Class Initialized
INFO - 2017-03-01 14:03:53 --> Output Class Initialized
INFO - 2017-03-01 14:03:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:53 --> Input Class Initialized
INFO - 2017-03-01 14:03:53 --> Language Class Initialized
INFO - 2017-03-01 14:03:53 --> Loader Class Initialized
INFO - 2017-03-01 14:03:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:53 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:53 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:53 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:53 --> Controller Class Initialized
INFO - 2017-03-01 14:03:53 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:53 --> Model Class Initialized
INFO - 2017-03-01 14:03:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:53 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:53 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:56 --> Config Class Initialized
INFO - 2017-03-01 14:03:56 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:03:56 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:03:56 --> Utf8 Class Initialized
INFO - 2017-03-01 14:03:56 --> URI Class Initialized
INFO - 2017-03-01 14:03:56 --> Router Class Initialized
INFO - 2017-03-01 14:03:56 --> Output Class Initialized
INFO - 2017-03-01 14:03:56 --> Security Class Initialized
DEBUG - 2017-03-01 14:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:03:56 --> Input Class Initialized
INFO - 2017-03-01 14:03:56 --> Language Class Initialized
INFO - 2017-03-01 14:03:56 --> Loader Class Initialized
INFO - 2017-03-01 14:03:56 --> Helper loaded: url_helper
INFO - 2017-03-01 14:03:56 --> Helper loaded: language_helper
INFO - 2017-03-01 14:03:56 --> Helper loaded: html_helper
INFO - 2017-03-01 14:03:56 --> Helper loaded: form_helper
INFO - 2017-03-01 14:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:03:56 --> Controller Class Initialized
INFO - 2017-03-01 14:03:56 --> Database Driver Class Initialized
INFO - 2017-03-01 14:03:56 --> Model Class Initialized
INFO - 2017-03-01 14:03:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:03:56 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:03:56 --> Pagination Class Initialized
INFO - 2017-03-01 14:03:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:03:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta_detail.php
INFO - 2017-03-01 14:03:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:03:57 --> Final output sent to browser
DEBUG - 2017-03-01 14:03:57 --> Total execution time: 0.1626
INFO - 2017-03-01 14:04:02 --> Config Class Initialized
INFO - 2017-03-01 14:04:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:04:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:02 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:02 --> URI Class Initialized
INFO - 2017-03-01 14:04:02 --> Router Class Initialized
INFO - 2017-03-01 14:04:02 --> Output Class Initialized
INFO - 2017-03-01 14:04:02 --> Security Class Initialized
DEBUG - 2017-03-01 14:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:02 --> Input Class Initialized
INFO - 2017-03-01 14:04:02 --> Language Class Initialized
INFO - 2017-03-01 14:04:02 --> Loader Class Initialized
INFO - 2017-03-01 14:04:02 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:02 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:02 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:02 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:02 --> Controller Class Initialized
INFO - 2017-03-01 14:04:02 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:02 --> Model Class Initialized
INFO - 2017-03-01 14:04:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:02 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:02 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:42 --> Config Class Initialized
INFO - 2017-03-01 14:04:42 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:04:42 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:42 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:42 --> URI Class Initialized
INFO - 2017-03-01 14:04:42 --> Router Class Initialized
INFO - 2017-03-01 14:04:42 --> Output Class Initialized
INFO - 2017-03-01 14:04:42 --> Security Class Initialized
DEBUG - 2017-03-01 14:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:42 --> Input Class Initialized
INFO - 2017-03-01 14:04:42 --> Language Class Initialized
INFO - 2017-03-01 14:04:42 --> Loader Class Initialized
INFO - 2017-03-01 14:04:42 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:42 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:42 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:42 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:42 --> Controller Class Initialized
INFO - 2017-03-01 14:04:42 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:42 --> Model Class Initialized
INFO - 2017-03-01 14:04:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:42 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:42 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:04:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:04:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:04:42 --> Final output sent to browser
DEBUG - 2017-03-01 14:04:42 --> Total execution time: 0.1237
INFO - 2017-03-01 14:04:52 --> Config Class Initialized
INFO - 2017-03-01 14:04:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:04:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:52 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:52 --> URI Class Initialized
INFO - 2017-03-01 14:04:52 --> Router Class Initialized
INFO - 2017-03-01 14:04:52 --> Output Class Initialized
INFO - 2017-03-01 14:04:52 --> Security Class Initialized
DEBUG - 2017-03-01 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:52 --> Input Class Initialized
INFO - 2017-03-01 14:04:52 --> Language Class Initialized
INFO - 2017-03-01 14:04:52 --> Loader Class Initialized
INFO - 2017-03-01 14:04:52 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:52 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:52 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:52 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:53 --> Controller Class Initialized
INFO - 2017-03-01 14:04:53 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:53 --> Model Class Initialized
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:53 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:04:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta_detail.php
INFO - 2017-03-01 14:04:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:04:53 --> Final output sent to browser
DEBUG - 2017-03-01 14:04:53 --> Total execution time: 0.1382
INFO - 2017-03-01 14:04:53 --> Config Class Initialized
INFO - 2017-03-01 14:04:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:04:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:53 --> URI Class Initialized
INFO - 2017-03-01 14:04:53 --> Router Class Initialized
INFO - 2017-03-01 14:04:53 --> Output Class Initialized
INFO - 2017-03-01 14:04:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:53 --> Input Class Initialized
INFO - 2017-03-01 14:04:53 --> Language Class Initialized
INFO - 2017-03-01 14:04:53 --> Loader Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:53 --> Config Class Initialized
INFO - 2017-03-01 14:04:53 --> Hooks Class Initialized
INFO - 2017-03-01 14:04:53 --> Config Class Initialized
INFO - 2017-03-01 14:04:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:04:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:53 --> URI Class Initialized
INFO - 2017-03-01 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:53 --> Controller Class Initialized
INFO - 2017-03-01 14:04:53 --> Router Class Initialized
INFO - 2017-03-01 14:04:53 --> Config Class Initialized
INFO - 2017-03-01 14:04:53 --> Hooks Class Initialized
INFO - 2017-03-01 14:04:53 --> Output Class Initialized
DEBUG - 2017-03-01 14:04:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:53 --> Config Class Initialized
INFO - 2017-03-01 14:04:53 --> Hooks Class Initialized
INFO - 2017-03-01 14:04:53 --> Security Class Initialized
INFO - 2017-03-01 14:04:53 --> URI Class Initialized
DEBUG - 2017-03-01 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:53 --> Input Class Initialized
INFO - 2017-03-01 14:04:53 --> Language Class Initialized
DEBUG - 2017-03-01 14:04:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:53 --> URI Class Initialized
INFO - 2017-03-01 14:04:53 --> Loader Class Initialized
INFO - 2017-03-01 14:04:53 --> Router Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: url_helper
DEBUG - 2017-03-01 14:04:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:53 --> Output Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:53 --> URI Class Initialized
INFO - 2017-03-01 14:04:53 --> Config Class Initialized
INFO - 2017-03-01 14:04:53 --> Hooks Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:53 --> Router Class Initialized
INFO - 2017-03-01 14:04:53 --> Output Class Initialized
DEBUG - 2017-03-01 14:04:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:53 --> Security Class Initialized
INFO - 2017-03-01 14:04:53 --> URI Class Initialized
DEBUG - 2017-03-01 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:53 --> Input Class Initialized
INFO - 2017-03-01 14:04:53 --> Router Class Initialized
INFO - 2017-03-01 14:04:53 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:53 --> Output Class Initialized
INFO - 2017-03-01 14:04:53 --> Model Class Initialized
INFO - 2017-03-01 14:04:53 --> Security Class Initialized
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/basic_lang.php
DEBUG - 2017-03-01 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:53 --> Input Class Initialized
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:53 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:53 --> Language Class Initialized
INFO - 2017-03-01 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:53 --> Controller Class Initialized
INFO - 2017-03-01 14:04:53 --> Loader Class Initialized
INFO - 2017-03-01 14:04:53 --> Security Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: language_helper
DEBUG - 2017-03-01 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:53 --> Input Class Initialized
INFO - 2017-03-01 14:04:53 --> Language Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:53 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:53 --> Loader Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:53 --> Language Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:53 --> Model Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:53 --> Router Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:53 --> Output Class Initialized
INFO - 2017-03-01 14:04:53 --> Loader Class Initialized
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:53 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:53 --> Security Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:53 --> Helper loaded: language_helper
DEBUG - 2017-03-01 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:53 --> Controller Class Initialized
INFO - 2017-03-01 14:04:53 --> Input Class Initialized
INFO - 2017-03-01 14:04:53 --> Language Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:53 --> Loader Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:53 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:53 --> Model Class Initialized
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:53 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:53 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:53 --> Controller Class Initialized
INFO - 2017-03-01 14:04:53 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:53 --> Model Class Initialized
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:53 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:53 --> Controller Class Initialized
INFO - 2017-03-01 14:04:53 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:53 --> Model Class Initialized
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:53 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:53 --> Controller Class Initialized
INFO - 2017-03-01 14:04:53 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:53 --> Model Class Initialized
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:53 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:53 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:53 --> Config Class Initialized
INFO - 2017-03-01 14:04:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:04:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:53 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:53 --> URI Class Initialized
INFO - 2017-03-01 14:04:53 --> Router Class Initialized
INFO - 2017-03-01 14:04:53 --> Output Class Initialized
INFO - 2017-03-01 14:04:53 --> Security Class Initialized
DEBUG - 2017-03-01 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:53 --> Input Class Initialized
INFO - 2017-03-01 14:04:53 --> Language Class Initialized
INFO - 2017-03-01 14:04:53 --> Loader Class Initialized
INFO - 2017-03-01 14:04:53 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:53 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:53 --> Controller Class Initialized
INFO - 2017-03-01 14:04:54 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:54 --> Model Class Initialized
INFO - 2017-03-01 14:04:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:54 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:54 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:55 --> Config Class Initialized
INFO - 2017-03-01 14:04:55 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:04:55 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:04:55 --> Utf8 Class Initialized
INFO - 2017-03-01 14:04:55 --> URI Class Initialized
INFO - 2017-03-01 14:04:55 --> Router Class Initialized
INFO - 2017-03-01 14:04:55 --> Output Class Initialized
INFO - 2017-03-01 14:04:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:04:55 --> Input Class Initialized
INFO - 2017-03-01 14:04:55 --> Language Class Initialized
INFO - 2017-03-01 14:04:55 --> Loader Class Initialized
INFO - 2017-03-01 14:04:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:04:55 --> Helper loaded: language_helper
INFO - 2017-03-01 14:04:55 --> Helper loaded: html_helper
INFO - 2017-03-01 14:04:55 --> Helper loaded: form_helper
INFO - 2017-03-01 14:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:04:55 --> Controller Class Initialized
INFO - 2017-03-01 14:04:55 --> Database Driver Class Initialized
INFO - 2017-03-01 14:04:55 --> Model Class Initialized
INFO - 2017-03-01 14:04:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:04:55 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:04:55 --> Pagination Class Initialized
INFO - 2017-03-01 14:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:04:55 --> Final output sent to browser
DEBUG - 2017-03-01 14:04:55 --> Total execution time: 0.1917
INFO - 2017-03-01 14:08:11 --> Config Class Initialized
INFO - 2017-03-01 14:08:11 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:08:11 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:08:11 --> Utf8 Class Initialized
INFO - 2017-03-01 14:08:11 --> URI Class Initialized
INFO - 2017-03-01 14:08:11 --> Router Class Initialized
INFO - 2017-03-01 14:08:11 --> Output Class Initialized
INFO - 2017-03-01 14:08:11 --> Security Class Initialized
DEBUG - 2017-03-01 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:08:11 --> Input Class Initialized
INFO - 2017-03-01 14:08:11 --> Language Class Initialized
INFO - 2017-03-01 14:08:11 --> Loader Class Initialized
INFO - 2017-03-01 14:08:11 --> Helper loaded: url_helper
INFO - 2017-03-01 14:08:11 --> Helper loaded: language_helper
INFO - 2017-03-01 14:08:11 --> Helper loaded: html_helper
INFO - 2017-03-01 14:08:11 --> Helper loaded: form_helper
INFO - 2017-03-01 14:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:08:11 --> Controller Class Initialized
INFO - 2017-03-01 14:08:11 --> Database Driver Class Initialized
INFO - 2017-03-01 14:08:11 --> Model Class Initialized
INFO - 2017-03-01 14:08:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:08:11 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:08:11 --> Pagination Class Initialized
INFO - 2017-03-01 14:08:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:08:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:08:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:08:11 --> Final output sent to browser
DEBUG - 2017-03-01 14:08:11 --> Total execution time: 0.1895
INFO - 2017-03-01 14:08:17 --> Config Class Initialized
INFO - 2017-03-01 14:08:17 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:08:17 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:08:17 --> Utf8 Class Initialized
INFO - 2017-03-01 14:08:17 --> URI Class Initialized
INFO - 2017-03-01 14:08:17 --> Router Class Initialized
INFO - 2017-03-01 14:08:17 --> Output Class Initialized
INFO - 2017-03-01 14:08:17 --> Security Class Initialized
DEBUG - 2017-03-01 14:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:08:17 --> Input Class Initialized
INFO - 2017-03-01 14:08:17 --> Language Class Initialized
INFO - 2017-03-01 14:08:17 --> Loader Class Initialized
INFO - 2017-03-01 14:08:17 --> Helper loaded: url_helper
INFO - 2017-03-01 14:08:17 --> Helper loaded: language_helper
INFO - 2017-03-01 14:08:17 --> Helper loaded: html_helper
INFO - 2017-03-01 14:08:17 --> Helper loaded: form_helper
INFO - 2017-03-01 14:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:08:17 --> Controller Class Initialized
INFO - 2017-03-01 14:08:17 --> Database Driver Class Initialized
INFO - 2017-03-01 14:08:17 --> Model Class Initialized
INFO - 2017-03-01 14:08:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:08:17 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:08:17 --> Pagination Class Initialized
ERROR - 2017-03-01 14:08:17 --> Severity: Warning --> filesize(): stat failed for /170200000000_lampiran.zip C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 145
ERROR - 2017-03-01 14:08:17 --> Severity: Warning --> readfile(/170200000000_lampiran.zip): failed to open stream: No such file or directory C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 147
INFO - 2017-03-01 14:08:25 --> Config Class Initialized
INFO - 2017-03-01 14:08:25 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:08:25 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:08:25 --> Utf8 Class Initialized
INFO - 2017-03-01 14:08:25 --> URI Class Initialized
INFO - 2017-03-01 14:08:25 --> Router Class Initialized
INFO - 2017-03-01 14:08:25 --> Output Class Initialized
INFO - 2017-03-01 14:08:25 --> Security Class Initialized
DEBUG - 2017-03-01 14:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:08:25 --> Input Class Initialized
INFO - 2017-03-01 14:08:25 --> Language Class Initialized
INFO - 2017-03-01 14:08:25 --> Loader Class Initialized
INFO - 2017-03-01 14:08:25 --> Helper loaded: url_helper
INFO - 2017-03-01 14:08:25 --> Helper loaded: language_helper
INFO - 2017-03-01 14:08:25 --> Helper loaded: html_helper
INFO - 2017-03-01 14:08:25 --> Helper loaded: form_helper
INFO - 2017-03-01 14:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:08:25 --> Controller Class Initialized
INFO - 2017-03-01 14:08:25 --> Database Driver Class Initialized
INFO - 2017-03-01 14:08:25 --> Model Class Initialized
INFO - 2017-03-01 14:08:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:08:25 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:08:25 --> Pagination Class Initialized
ERROR - 2017-03-01 14:08:25 --> Severity: Warning --> filesize(): stat failed for /170200000001_lampiran.zip C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 145
ERROR - 2017-03-01 14:08:25 --> Severity: Warning --> readfile(/170200000001_lampiran.zip): failed to open stream: No such file or directory C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 147
INFO - 2017-03-01 14:09:16 --> Config Class Initialized
INFO - 2017-03-01 14:09:16 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:09:16 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:09:16 --> Utf8 Class Initialized
INFO - 2017-03-01 14:09:16 --> URI Class Initialized
INFO - 2017-03-01 14:09:16 --> Router Class Initialized
INFO - 2017-03-01 14:09:16 --> Output Class Initialized
INFO - 2017-03-01 14:09:16 --> Security Class Initialized
DEBUG - 2017-03-01 14:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:09:16 --> Input Class Initialized
INFO - 2017-03-01 14:09:16 --> Language Class Initialized
INFO - 2017-03-01 14:09:16 --> Loader Class Initialized
INFO - 2017-03-01 14:09:16 --> Helper loaded: url_helper
INFO - 2017-03-01 14:09:16 --> Helper loaded: language_helper
INFO - 2017-03-01 14:09:16 --> Helper loaded: html_helper
INFO - 2017-03-01 14:09:16 --> Helper loaded: form_helper
INFO - 2017-03-01 14:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:09:16 --> Controller Class Initialized
INFO - 2017-03-01 14:09:16 --> Database Driver Class Initialized
INFO - 2017-03-01 14:09:16 --> Model Class Initialized
INFO - 2017-03-01 14:09:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:09:16 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:09:16 --> Pagination Class Initialized
INFO - 2017-03-01 14:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:09:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:09:16 --> Final output sent to browser
DEBUG - 2017-03-01 14:09:16 --> Total execution time: 0.1312
INFO - 2017-03-01 14:09:19 --> Config Class Initialized
INFO - 2017-03-01 14:09:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:09:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:09:19 --> Utf8 Class Initialized
INFO - 2017-03-01 14:09:19 --> URI Class Initialized
INFO - 2017-03-01 14:09:19 --> Router Class Initialized
INFO - 2017-03-01 14:09:19 --> Output Class Initialized
INFO - 2017-03-01 14:09:19 --> Security Class Initialized
DEBUG - 2017-03-01 14:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:09:19 --> Input Class Initialized
INFO - 2017-03-01 14:09:19 --> Language Class Initialized
INFO - 2017-03-01 14:09:19 --> Loader Class Initialized
INFO - 2017-03-01 14:09:19 --> Helper loaded: url_helper
INFO - 2017-03-01 14:09:19 --> Helper loaded: language_helper
INFO - 2017-03-01 14:09:19 --> Helper loaded: html_helper
INFO - 2017-03-01 14:09:19 --> Helper loaded: form_helper
INFO - 2017-03-01 14:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:09:19 --> Controller Class Initialized
INFO - 2017-03-01 14:09:19 --> Database Driver Class Initialized
INFO - 2017-03-01 14:09:19 --> Model Class Initialized
INFO - 2017-03-01 14:09:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:09:19 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:09:19 --> Pagination Class Initialized
INFO - 2017-03-01 14:09:54 --> Config Class Initialized
INFO - 2017-03-01 14:09:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:09:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:09:54 --> Utf8 Class Initialized
INFO - 2017-03-01 14:09:54 --> URI Class Initialized
INFO - 2017-03-01 14:09:54 --> Router Class Initialized
INFO - 2017-03-01 14:09:54 --> Output Class Initialized
INFO - 2017-03-01 14:09:54 --> Security Class Initialized
DEBUG - 2017-03-01 14:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:09:54 --> Input Class Initialized
INFO - 2017-03-01 14:09:54 --> Language Class Initialized
INFO - 2017-03-01 14:09:54 --> Loader Class Initialized
INFO - 2017-03-01 14:09:54 --> Helper loaded: url_helper
INFO - 2017-03-01 14:09:54 --> Helper loaded: language_helper
INFO - 2017-03-01 14:09:54 --> Helper loaded: html_helper
INFO - 2017-03-01 14:09:54 --> Helper loaded: form_helper
INFO - 2017-03-01 14:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:09:54 --> Controller Class Initialized
INFO - 2017-03-01 14:09:54 --> Database Driver Class Initialized
INFO - 2017-03-01 14:09:54 --> Model Class Initialized
INFO - 2017-03-01 14:09:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:09:54 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:09:54 --> Pagination Class Initialized
INFO - 2017-03-01 14:15:59 --> Config Class Initialized
INFO - 2017-03-01 14:15:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:15:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:15:59 --> Utf8 Class Initialized
INFO - 2017-03-01 14:15:59 --> URI Class Initialized
INFO - 2017-03-01 14:15:59 --> Router Class Initialized
INFO - 2017-03-01 14:15:59 --> Output Class Initialized
INFO - 2017-03-01 14:15:59 --> Security Class Initialized
DEBUG - 2017-03-01 14:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:15:59 --> Input Class Initialized
INFO - 2017-03-01 14:15:59 --> Language Class Initialized
INFO - 2017-03-01 14:15:59 --> Loader Class Initialized
INFO - 2017-03-01 14:15:59 --> Helper loaded: url_helper
INFO - 2017-03-01 14:15:59 --> Helper loaded: language_helper
INFO - 2017-03-01 14:15:59 --> Helper loaded: html_helper
INFO - 2017-03-01 14:15:59 --> Helper loaded: form_helper
INFO - 2017-03-01 14:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:15:59 --> Controller Class Initialized
INFO - 2017-03-01 14:15:59 --> Database Driver Class Initialized
INFO - 2017-03-01 14:15:59 --> Model Class Initialized
INFO - 2017-03-01 14:15:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:15:59 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:15:59 --> Pagination Class Initialized
INFO - 2017-03-01 14:15:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:15:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:15:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:15:59 --> Final output sent to browser
DEBUG - 2017-03-01 14:15:59 --> Total execution time: 0.1508
INFO - 2017-03-01 14:16:07 --> Config Class Initialized
INFO - 2017-03-01 14:16:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:16:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:16:07 --> Utf8 Class Initialized
INFO - 2017-03-01 14:16:07 --> URI Class Initialized
INFO - 2017-03-01 14:16:07 --> Router Class Initialized
INFO - 2017-03-01 14:16:07 --> Output Class Initialized
INFO - 2017-03-01 14:16:07 --> Security Class Initialized
DEBUG - 2017-03-01 14:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:16:07 --> Input Class Initialized
INFO - 2017-03-01 14:16:07 --> Language Class Initialized
INFO - 2017-03-01 14:16:07 --> Loader Class Initialized
INFO - 2017-03-01 14:16:07 --> Helper loaded: url_helper
INFO - 2017-03-01 14:16:07 --> Helper loaded: language_helper
INFO - 2017-03-01 14:16:07 --> Helper loaded: html_helper
INFO - 2017-03-01 14:16:07 --> Helper loaded: form_helper
INFO - 2017-03-01 14:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:16:07 --> Controller Class Initialized
INFO - 2017-03-01 14:16:07 --> Database Driver Class Initialized
INFO - 2017-03-01 14:16:07 --> Model Class Initialized
INFO - 2017-03-01 14:16:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:16:07 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:16:07 --> Pagination Class Initialized
INFO - 2017-03-01 14:26:00 --> Config Class Initialized
INFO - 2017-03-01 14:26:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:26:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:26:00 --> Utf8 Class Initialized
INFO - 2017-03-01 14:26:00 --> URI Class Initialized
INFO - 2017-03-01 14:26:00 --> Router Class Initialized
INFO - 2017-03-01 14:26:00 --> Output Class Initialized
INFO - 2017-03-01 14:26:00 --> Security Class Initialized
DEBUG - 2017-03-01 14:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:26:00 --> Input Class Initialized
INFO - 2017-03-01 14:26:00 --> Language Class Initialized
INFO - 2017-03-01 14:26:01 --> Loader Class Initialized
INFO - 2017-03-01 14:26:01 --> Helper loaded: url_helper
INFO - 2017-03-01 14:26:01 --> Helper loaded: language_helper
INFO - 2017-03-01 14:26:01 --> Helper loaded: html_helper
INFO - 2017-03-01 14:26:01 --> Helper loaded: form_helper
INFO - 2017-03-01 14:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:26:01 --> Controller Class Initialized
INFO - 2017-03-01 14:26:01 --> Database Driver Class Initialized
ERROR - 2017-03-01 14:26:01 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) C:\wamp64\www\savsoftquiz\application\models\Register_model.php 362
INFO - 2017-03-01 14:26:22 --> Config Class Initialized
INFO - 2017-03-01 14:26:22 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:26:22 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:26:22 --> Utf8 Class Initialized
INFO - 2017-03-01 14:26:22 --> URI Class Initialized
INFO - 2017-03-01 14:26:22 --> Router Class Initialized
INFO - 2017-03-01 14:26:22 --> Output Class Initialized
INFO - 2017-03-01 14:26:22 --> Security Class Initialized
DEBUG - 2017-03-01 14:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:26:22 --> Input Class Initialized
INFO - 2017-03-01 14:26:22 --> Language Class Initialized
INFO - 2017-03-01 14:26:22 --> Loader Class Initialized
INFO - 2017-03-01 14:26:22 --> Helper loaded: url_helper
INFO - 2017-03-01 14:26:22 --> Helper loaded: language_helper
INFO - 2017-03-01 14:26:22 --> Helper loaded: html_helper
INFO - 2017-03-01 14:26:22 --> Helper loaded: form_helper
INFO - 2017-03-01 14:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:26:22 --> Controller Class Initialized
INFO - 2017-03-01 14:26:22 --> Database Driver Class Initialized
INFO - 2017-03-01 14:26:22 --> Model Class Initialized
INFO - 2017-03-01 14:26:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:26:22 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:26:22 --> Pagination Class Initialized
INFO - 2017-03-01 14:26:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:26:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:26:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:26:22 --> Final output sent to browser
DEBUG - 2017-03-01 14:26:22 --> Total execution time: 0.1805
INFO - 2017-03-01 14:26:25 --> Config Class Initialized
INFO - 2017-03-01 14:26:25 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:26:25 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:26:25 --> Utf8 Class Initialized
INFO - 2017-03-01 14:26:25 --> URI Class Initialized
INFO - 2017-03-01 14:26:25 --> Router Class Initialized
INFO - 2017-03-01 14:26:25 --> Output Class Initialized
INFO - 2017-03-01 14:26:25 --> Security Class Initialized
DEBUG - 2017-03-01 14:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:26:25 --> Input Class Initialized
INFO - 2017-03-01 14:26:25 --> Language Class Initialized
INFO - 2017-03-01 14:26:25 --> Loader Class Initialized
INFO - 2017-03-01 14:26:25 --> Helper loaded: url_helper
INFO - 2017-03-01 14:26:25 --> Helper loaded: language_helper
INFO - 2017-03-01 14:26:25 --> Helper loaded: html_helper
INFO - 2017-03-01 14:26:25 --> Helper loaded: form_helper
INFO - 2017-03-01 14:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:26:25 --> Controller Class Initialized
INFO - 2017-03-01 14:26:25 --> Database Driver Class Initialized
INFO - 2017-03-01 14:26:25 --> Model Class Initialized
INFO - 2017-03-01 14:26:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:26:25 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:26:25 --> Pagination Class Initialized
INFO - 2017-03-01 14:27:11 --> Config Class Initialized
INFO - 2017-03-01 14:27:11 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:27:11 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:27:11 --> Utf8 Class Initialized
INFO - 2017-03-01 14:27:11 --> URI Class Initialized
INFO - 2017-03-01 14:27:11 --> Router Class Initialized
INFO - 2017-03-01 14:27:11 --> Output Class Initialized
INFO - 2017-03-01 14:27:11 --> Security Class Initialized
DEBUG - 2017-03-01 14:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:27:12 --> Input Class Initialized
INFO - 2017-03-01 14:27:12 --> Language Class Initialized
INFO - 2017-03-01 14:27:12 --> Loader Class Initialized
INFO - 2017-03-01 14:27:12 --> Helper loaded: url_helper
INFO - 2017-03-01 14:27:12 --> Helper loaded: language_helper
INFO - 2017-03-01 14:27:12 --> Helper loaded: html_helper
INFO - 2017-03-01 14:27:12 --> Helper loaded: form_helper
INFO - 2017-03-01 14:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:27:12 --> Controller Class Initialized
INFO - 2017-03-01 14:27:12 --> Database Driver Class Initialized
INFO - 2017-03-01 14:27:12 --> Model Class Initialized
INFO - 2017-03-01 14:27:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:27:12 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:27:12 --> Pagination Class Initialized
INFO - 2017-03-01 14:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:27:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:27:12 --> Final output sent to browser
DEBUG - 2017-03-01 14:27:12 --> Total execution time: 0.2182
INFO - 2017-03-01 14:27:14 --> Config Class Initialized
INFO - 2017-03-01 14:27:14 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:27:14 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:27:14 --> Utf8 Class Initialized
INFO - 2017-03-01 14:27:14 --> URI Class Initialized
INFO - 2017-03-01 14:27:14 --> Router Class Initialized
INFO - 2017-03-01 14:27:14 --> Output Class Initialized
INFO - 2017-03-01 14:27:14 --> Security Class Initialized
DEBUG - 2017-03-01 14:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:27:14 --> Input Class Initialized
INFO - 2017-03-01 14:27:14 --> Language Class Initialized
INFO - 2017-03-01 14:27:14 --> Loader Class Initialized
INFO - 2017-03-01 14:27:14 --> Helper loaded: url_helper
INFO - 2017-03-01 14:27:14 --> Helper loaded: language_helper
INFO - 2017-03-01 14:27:14 --> Helper loaded: html_helper
INFO - 2017-03-01 14:27:14 --> Helper loaded: form_helper
INFO - 2017-03-01 14:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:27:14 --> Controller Class Initialized
INFO - 2017-03-01 14:27:14 --> Database Driver Class Initialized
INFO - 2017-03-01 14:27:14 --> Model Class Initialized
INFO - 2017-03-01 14:27:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:27:14 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:27:14 --> Pagination Class Initialized
INFO - 2017-03-01 14:32:03 --> Config Class Initialized
INFO - 2017-03-01 14:32:03 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:32:03 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:32:03 --> Utf8 Class Initialized
INFO - 2017-03-01 14:32:03 --> URI Class Initialized
INFO - 2017-03-01 14:32:03 --> Router Class Initialized
INFO - 2017-03-01 14:32:03 --> Output Class Initialized
INFO - 2017-03-01 14:32:03 --> Security Class Initialized
DEBUG - 2017-03-01 14:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:32:03 --> Input Class Initialized
INFO - 2017-03-01 14:32:03 --> Language Class Initialized
INFO - 2017-03-01 14:32:03 --> Loader Class Initialized
INFO - 2017-03-01 14:32:03 --> Helper loaded: url_helper
INFO - 2017-03-01 14:32:03 --> Helper loaded: language_helper
INFO - 2017-03-01 14:32:03 --> Helper loaded: html_helper
INFO - 2017-03-01 14:32:03 --> Helper loaded: form_helper
INFO - 2017-03-01 14:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:32:03 --> Controller Class Initialized
INFO - 2017-03-01 14:32:03 --> Database Driver Class Initialized
INFO - 2017-03-01 14:32:03 --> Model Class Initialized
INFO - 2017-03-01 14:32:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:32:03 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:32:03 --> Pagination Class Initialized
INFO - 2017-03-01 14:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:32:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:32:03 --> Final output sent to browser
DEBUG - 2017-03-01 14:32:03 --> Total execution time: 0.1987
INFO - 2017-03-01 14:42:30 --> Config Class Initialized
INFO - 2017-03-01 14:42:30 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:30 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:30 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:30 --> URI Class Initialized
INFO - 2017-03-01 14:42:30 --> Router Class Initialized
INFO - 2017-03-01 14:42:30 --> Output Class Initialized
INFO - 2017-03-01 14:42:30 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:30 --> Input Class Initialized
INFO - 2017-03-01 14:42:30 --> Language Class Initialized
INFO - 2017-03-01 14:42:30 --> Loader Class Initialized
INFO - 2017-03-01 14:42:30 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:30 --> Helper loaded: language_helper
INFO - 2017-03-01 14:42:30 --> Helper loaded: html_helper
INFO - 2017-03-01 14:42:30 --> Helper loaded: form_helper
INFO - 2017-03-01 14:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:30 --> Controller Class Initialized
INFO - 2017-03-01 14:42:30 --> Database Driver Class Initialized
INFO - 2017-03-01 14:42:30 --> Model Class Initialized
INFO - 2017-03-01 14:42:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:42:30 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:42:30 --> Pagination Class Initialized
INFO - 2017-03-01 14:42:30 --> Zip Compression Class Initialized
INFO - 2017-03-01 14:42:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:42:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:42:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:42:30 --> Final output sent to browser
DEBUG - 2017-03-01 14:42:30 --> Total execution time: 0.2561
INFO - 2017-03-01 14:42:34 --> Config Class Initialized
INFO - 2017-03-01 14:42:34 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:42:34 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:42:34 --> Utf8 Class Initialized
INFO - 2017-03-01 14:42:34 --> URI Class Initialized
INFO - 2017-03-01 14:42:34 --> Router Class Initialized
INFO - 2017-03-01 14:42:34 --> Output Class Initialized
INFO - 2017-03-01 14:42:34 --> Security Class Initialized
DEBUG - 2017-03-01 14:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:42:34 --> Input Class Initialized
INFO - 2017-03-01 14:42:34 --> Language Class Initialized
INFO - 2017-03-01 14:42:34 --> Loader Class Initialized
INFO - 2017-03-01 14:42:34 --> Helper loaded: url_helper
INFO - 2017-03-01 14:42:34 --> Helper loaded: language_helper
INFO - 2017-03-01 14:42:34 --> Helper loaded: html_helper
INFO - 2017-03-01 14:42:34 --> Helper loaded: form_helper
INFO - 2017-03-01 14:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:42:34 --> Controller Class Initialized
INFO - 2017-03-01 14:42:34 --> Database Driver Class Initialized
INFO - 2017-03-01 14:42:34 --> Model Class Initialized
INFO - 2017-03-01 14:42:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:42:34 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:42:34 --> Pagination Class Initialized
INFO - 2017-03-01 14:42:34 --> Zip Compression Class Initialized
ERROR - 2017-03-01 14:42:34 --> Severity: Warning --> filesize(): stat failed for C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 158
ERROR - 2017-03-01 14:42:34 --> Severity: Warning --> readfile(C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip): failed to open stream: No such file or directory C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 160
INFO - 2017-03-01 14:46:42 --> Config Class Initialized
INFO - 2017-03-01 14:46:42 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:46:42 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:46:42 --> Utf8 Class Initialized
INFO - 2017-03-01 14:46:42 --> URI Class Initialized
INFO - 2017-03-01 14:46:42 --> Router Class Initialized
INFO - 2017-03-01 14:46:42 --> Output Class Initialized
INFO - 2017-03-01 14:46:42 --> Security Class Initialized
DEBUG - 2017-03-01 14:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:46:42 --> Input Class Initialized
INFO - 2017-03-01 14:46:42 --> Language Class Initialized
INFO - 2017-03-01 14:46:42 --> Loader Class Initialized
INFO - 2017-03-01 14:46:42 --> Helper loaded: url_helper
INFO - 2017-03-01 14:46:42 --> Helper loaded: language_helper
INFO - 2017-03-01 14:46:42 --> Helper loaded: html_helper
INFO - 2017-03-01 14:46:42 --> Helper loaded: form_helper
INFO - 2017-03-01 14:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:46:42 --> Controller Class Initialized
INFO - 2017-03-01 14:46:42 --> Database Driver Class Initialized
INFO - 2017-03-01 14:46:42 --> Model Class Initialized
INFO - 2017-03-01 14:46:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:46:42 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:46:42 --> Pagination Class Initialized
INFO - 2017-03-01 14:46:42 --> Zip Compression Class Initialized
INFO - 2017-03-01 14:46:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:46:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:46:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:46:42 --> Final output sent to browser
DEBUG - 2017-03-01 14:46:42 --> Total execution time: 0.1711
INFO - 2017-03-01 14:46:45 --> Config Class Initialized
INFO - 2017-03-01 14:46:45 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:46:45 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:46:45 --> Utf8 Class Initialized
INFO - 2017-03-01 14:46:45 --> URI Class Initialized
INFO - 2017-03-01 14:46:45 --> Router Class Initialized
INFO - 2017-03-01 14:46:45 --> Output Class Initialized
INFO - 2017-03-01 14:46:45 --> Security Class Initialized
DEBUG - 2017-03-01 14:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:46:45 --> Input Class Initialized
INFO - 2017-03-01 14:46:45 --> Language Class Initialized
INFO - 2017-03-01 14:46:45 --> Loader Class Initialized
INFO - 2017-03-01 14:46:45 --> Helper loaded: url_helper
INFO - 2017-03-01 14:46:45 --> Helper loaded: language_helper
INFO - 2017-03-01 14:46:45 --> Helper loaded: html_helper
INFO - 2017-03-01 14:46:45 --> Helper loaded: form_helper
INFO - 2017-03-01 14:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:46:45 --> Controller Class Initialized
INFO - 2017-03-01 14:46:45 --> Database Driver Class Initialized
INFO - 2017-03-01 14:46:45 --> Model Class Initialized
INFO - 2017-03-01 14:46:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:46:45 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:46:45 --> Pagination Class Initialized
INFO - 2017-03-01 14:46:45 --> Zip Compression Class Initialized
ERROR - 2017-03-01 14:46:45 --> Severity: Warning --> filesize(): stat failed for C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 159
ERROR - 2017-03-01 14:46:45 --> Severity: Warning --> readfile(C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip): failed to open stream: No such file or directory C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 161
INFO - 2017-03-01 14:53:07 --> Config Class Initialized
INFO - 2017-03-01 14:53:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:53:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:53:07 --> Utf8 Class Initialized
INFO - 2017-03-01 14:53:07 --> URI Class Initialized
INFO - 2017-03-01 14:53:07 --> Router Class Initialized
INFO - 2017-03-01 14:53:07 --> Output Class Initialized
INFO - 2017-03-01 14:53:07 --> Security Class Initialized
DEBUG - 2017-03-01 14:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:53:07 --> Input Class Initialized
INFO - 2017-03-01 14:53:07 --> Language Class Initialized
INFO - 2017-03-01 14:53:07 --> Loader Class Initialized
INFO - 2017-03-01 14:53:07 --> Helper loaded: url_helper
INFO - 2017-03-01 14:53:07 --> Helper loaded: language_helper
INFO - 2017-03-01 14:53:07 --> Helper loaded: html_helper
INFO - 2017-03-01 14:53:07 --> Helper loaded: form_helper
INFO - 2017-03-01 14:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:53:07 --> Controller Class Initialized
INFO - 2017-03-01 14:53:07 --> Database Driver Class Initialized
INFO - 2017-03-01 14:53:07 --> Model Class Initialized
INFO - 2017-03-01 14:53:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:53:07 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:53:07 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:53:07 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:53:07 --> Pagination Class Initialized
INFO - 2017-03-01 14:53:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:53:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:53:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:53:07 --> Final output sent to browser
DEBUG - 2017-03-01 14:53:07 --> Total execution time: 0.2121
INFO - 2017-03-01 14:53:09 --> Config Class Initialized
INFO - 2017-03-01 14:53:09 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:53:09 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:53:09 --> Utf8 Class Initialized
INFO - 2017-03-01 14:53:09 --> URI Class Initialized
INFO - 2017-03-01 14:53:09 --> Router Class Initialized
INFO - 2017-03-01 14:53:09 --> Output Class Initialized
INFO - 2017-03-01 14:53:09 --> Security Class Initialized
DEBUG - 2017-03-01 14:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:53:09 --> Input Class Initialized
INFO - 2017-03-01 14:53:09 --> Language Class Initialized
INFO - 2017-03-01 14:53:09 --> Loader Class Initialized
INFO - 2017-03-01 14:53:09 --> Helper loaded: url_helper
INFO - 2017-03-01 14:53:09 --> Helper loaded: language_helper
INFO - 2017-03-01 14:53:09 --> Helper loaded: html_helper
INFO - 2017-03-01 14:53:09 --> Helper loaded: form_helper
INFO - 2017-03-01 14:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:53:09 --> Controller Class Initialized
INFO - 2017-03-01 14:53:09 --> Database Driver Class Initialized
INFO - 2017-03-01 14:53:09 --> Model Class Initialized
INFO - 2017-03-01 14:53:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:53:09 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:53:09 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:53:09 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:53:09 --> Pagination Class Initialized
INFO - 2017-03-01 14:53:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:53:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:53:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:53:10 --> Final output sent to browser
DEBUG - 2017-03-01 14:53:10 --> Total execution time: 0.1836
INFO - 2017-03-01 14:55:37 --> Config Class Initialized
INFO - 2017-03-01 14:55:37 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:55:37 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:55:37 --> Utf8 Class Initialized
INFO - 2017-03-01 14:55:37 --> URI Class Initialized
INFO - 2017-03-01 14:55:37 --> Router Class Initialized
INFO - 2017-03-01 14:55:37 --> Output Class Initialized
INFO - 2017-03-01 14:55:37 --> Security Class Initialized
DEBUG - 2017-03-01 14:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:55:37 --> Input Class Initialized
INFO - 2017-03-01 14:55:37 --> Language Class Initialized
INFO - 2017-03-01 14:55:37 --> Loader Class Initialized
INFO - 2017-03-01 14:55:37 --> Helper loaded: url_helper
INFO - 2017-03-01 14:55:37 --> Helper loaded: language_helper
INFO - 2017-03-01 14:55:37 --> Helper loaded: html_helper
INFO - 2017-03-01 14:55:37 --> Helper loaded: form_helper
INFO - 2017-03-01 14:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:55:37 --> Controller Class Initialized
INFO - 2017-03-01 14:55:37 --> Database Driver Class Initialized
INFO - 2017-03-01 14:55:37 --> Model Class Initialized
INFO - 2017-03-01 14:55:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:55:37 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:55:37 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:55:37 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:55:37 --> Pagination Class Initialized
INFO - 2017-03-01 14:55:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:55:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:55:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:55:37 --> Final output sent to browser
DEBUG - 2017-03-01 14:55:37 --> Total execution time: 0.1583
INFO - 2017-03-01 14:55:39 --> Config Class Initialized
INFO - 2017-03-01 14:55:39 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:55:39 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:55:39 --> Utf8 Class Initialized
INFO - 2017-03-01 14:55:39 --> URI Class Initialized
INFO - 2017-03-01 14:55:39 --> Router Class Initialized
INFO - 2017-03-01 14:55:39 --> Output Class Initialized
INFO - 2017-03-01 14:55:39 --> Security Class Initialized
DEBUG - 2017-03-01 14:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:55:39 --> Input Class Initialized
INFO - 2017-03-01 14:55:39 --> Language Class Initialized
INFO - 2017-03-01 14:55:39 --> Loader Class Initialized
INFO - 2017-03-01 14:55:39 --> Helper loaded: url_helper
INFO - 2017-03-01 14:55:39 --> Helper loaded: language_helper
INFO - 2017-03-01 14:55:39 --> Helper loaded: html_helper
INFO - 2017-03-01 14:55:39 --> Helper loaded: form_helper
INFO - 2017-03-01 14:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:55:40 --> Controller Class Initialized
INFO - 2017-03-01 14:55:40 --> Database Driver Class Initialized
INFO - 2017-03-01 14:55:40 --> Model Class Initialized
INFO - 2017-03-01 14:55:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:55:40 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:55:40 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:55:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:55:40 --> Pagination Class Initialized
ERROR - 2017-03-01 14:55:40 --> Severity: Warning --> filesize(): stat failed for C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 161
ERROR - 2017-03-01 14:55:40 --> Severity: Warning --> readfile(C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip): failed to open stream: No such file or directory C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 163
INFO - 2017-03-01 14:56:55 --> Config Class Initialized
INFO - 2017-03-01 14:56:55 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:56:55 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:56:55 --> Utf8 Class Initialized
INFO - 2017-03-01 14:56:55 --> URI Class Initialized
INFO - 2017-03-01 14:56:55 --> Router Class Initialized
INFO - 2017-03-01 14:56:55 --> Output Class Initialized
INFO - 2017-03-01 14:56:55 --> Security Class Initialized
DEBUG - 2017-03-01 14:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:56:55 --> Input Class Initialized
INFO - 2017-03-01 14:56:55 --> Language Class Initialized
INFO - 2017-03-01 14:56:55 --> Loader Class Initialized
INFO - 2017-03-01 14:56:55 --> Helper loaded: url_helper
INFO - 2017-03-01 14:56:55 --> Helper loaded: language_helper
INFO - 2017-03-01 14:56:55 --> Helper loaded: html_helper
INFO - 2017-03-01 14:56:55 --> Helper loaded: form_helper
INFO - 2017-03-01 14:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:56:55 --> Controller Class Initialized
INFO - 2017-03-01 14:56:55 --> Database Driver Class Initialized
INFO - 2017-03-01 14:56:55 --> Model Class Initialized
INFO - 2017-03-01 14:56:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:56:55 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:56:55 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:56:55 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:56:55 --> Pagination Class Initialized
INFO - 2017-03-01 14:56:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:56:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:56:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:56:55 --> Final output sent to browser
DEBUG - 2017-03-01 14:56:55 --> Total execution time: 0.1609
INFO - 2017-03-01 14:56:58 --> Config Class Initialized
INFO - 2017-03-01 14:56:58 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:56:58 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:56:58 --> Utf8 Class Initialized
INFO - 2017-03-01 14:56:58 --> URI Class Initialized
INFO - 2017-03-01 14:56:58 --> Router Class Initialized
INFO - 2017-03-01 14:56:58 --> Output Class Initialized
INFO - 2017-03-01 14:56:58 --> Security Class Initialized
DEBUG - 2017-03-01 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:56:58 --> Input Class Initialized
INFO - 2017-03-01 14:56:58 --> Language Class Initialized
INFO - 2017-03-01 14:56:58 --> Loader Class Initialized
INFO - 2017-03-01 14:56:58 --> Helper loaded: url_helper
INFO - 2017-03-01 14:56:58 --> Helper loaded: language_helper
INFO - 2017-03-01 14:56:58 --> Helper loaded: html_helper
INFO - 2017-03-01 14:56:58 --> Helper loaded: form_helper
INFO - 2017-03-01 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:56:58 --> Controller Class Initialized
INFO - 2017-03-01 14:56:58 --> Database Driver Class Initialized
INFO - 2017-03-01 14:56:58 --> Model Class Initialized
INFO - 2017-03-01 14:56:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:56:58 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:56:58 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:56:58 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:56:58 --> Pagination Class Initialized
ERROR - 2017-03-01 14:56:58 --> Severity: Warning --> filesize(): stat failed for C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 161
ERROR - 2017-03-01 14:56:58 --> Severity: Warning --> readfile(C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip): failed to open stream: No such file or directory C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 163
INFO - 2017-03-01 14:58:08 --> Config Class Initialized
INFO - 2017-03-01 14:58:08 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:58:08 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:58:08 --> Utf8 Class Initialized
INFO - 2017-03-01 14:58:08 --> URI Class Initialized
INFO - 2017-03-01 14:58:08 --> Router Class Initialized
INFO - 2017-03-01 14:58:08 --> Output Class Initialized
INFO - 2017-03-01 14:58:08 --> Security Class Initialized
DEBUG - 2017-03-01 14:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:58:08 --> Input Class Initialized
INFO - 2017-03-01 14:58:08 --> Language Class Initialized
INFO - 2017-03-01 14:58:08 --> Loader Class Initialized
INFO - 2017-03-01 14:58:08 --> Helper loaded: url_helper
INFO - 2017-03-01 14:58:08 --> Helper loaded: language_helper
INFO - 2017-03-01 14:58:08 --> Helper loaded: html_helper
INFO - 2017-03-01 14:58:08 --> Helper loaded: form_helper
INFO - 2017-03-01 14:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:58:08 --> Controller Class Initialized
INFO - 2017-03-01 14:58:08 --> Database Driver Class Initialized
INFO - 2017-03-01 14:58:08 --> Model Class Initialized
INFO - 2017-03-01 14:58:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:58:08 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:58:08 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:58:08 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:58:08 --> Pagination Class Initialized
INFO - 2017-03-01 14:58:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:58:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:58:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:58:08 --> Final output sent to browser
DEBUG - 2017-03-01 14:58:08 --> Total execution time: 0.1963
INFO - 2017-03-01 14:58:11 --> Config Class Initialized
INFO - 2017-03-01 14:58:11 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:58:11 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:58:11 --> Utf8 Class Initialized
INFO - 2017-03-01 14:58:11 --> URI Class Initialized
INFO - 2017-03-01 14:58:11 --> Router Class Initialized
INFO - 2017-03-01 14:58:11 --> Output Class Initialized
INFO - 2017-03-01 14:58:11 --> Security Class Initialized
DEBUG - 2017-03-01 14:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:58:11 --> Input Class Initialized
INFO - 2017-03-01 14:58:11 --> Language Class Initialized
INFO - 2017-03-01 14:58:11 --> Loader Class Initialized
INFO - 2017-03-01 14:58:11 --> Helper loaded: url_helper
INFO - 2017-03-01 14:58:11 --> Helper loaded: language_helper
INFO - 2017-03-01 14:58:11 --> Helper loaded: html_helper
INFO - 2017-03-01 14:58:11 --> Helper loaded: form_helper
INFO - 2017-03-01 14:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:58:11 --> Controller Class Initialized
INFO - 2017-03-01 14:58:11 --> Database Driver Class Initialized
INFO - 2017-03-01 14:58:11 --> Model Class Initialized
INFO - 2017-03-01 14:58:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:58:11 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:58:11 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:58:11 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:58:11 --> Pagination Class Initialized
ERROR - 2017-03-01 14:58:11 --> Severity: Warning --> filesize(): stat failed for C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 161
ERROR - 2017-03-01 14:58:11 --> Severity: Warning --> readfile(C:\wamp64\www\savsoftquiz\upload\data/_lampiran.zip): failed to open stream: No such file or directory C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 163
INFO - 2017-03-01 14:59:17 --> Config Class Initialized
INFO - 2017-03-01 14:59:17 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:59:17 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:59:17 --> Utf8 Class Initialized
INFO - 2017-03-01 14:59:17 --> URI Class Initialized
INFO - 2017-03-01 14:59:17 --> Router Class Initialized
INFO - 2017-03-01 14:59:17 --> Output Class Initialized
INFO - 2017-03-01 14:59:17 --> Security Class Initialized
DEBUG - 2017-03-01 14:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:59:17 --> Input Class Initialized
INFO - 2017-03-01 14:59:17 --> Language Class Initialized
ERROR - 2017-03-01 14:59:17 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\wamp64\www\savsoftquiz\application\controllers\Calonpeserta.php 87
INFO - 2017-03-01 14:59:36 --> Config Class Initialized
INFO - 2017-03-01 14:59:36 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:59:36 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:59:36 --> Utf8 Class Initialized
INFO - 2017-03-01 14:59:36 --> URI Class Initialized
INFO - 2017-03-01 14:59:36 --> Router Class Initialized
INFO - 2017-03-01 14:59:36 --> Output Class Initialized
INFO - 2017-03-01 14:59:36 --> Security Class Initialized
DEBUG - 2017-03-01 14:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:59:36 --> Input Class Initialized
INFO - 2017-03-01 14:59:36 --> Language Class Initialized
INFO - 2017-03-01 14:59:36 --> Loader Class Initialized
INFO - 2017-03-01 14:59:36 --> Helper loaded: url_helper
INFO - 2017-03-01 14:59:36 --> Helper loaded: language_helper
INFO - 2017-03-01 14:59:36 --> Helper loaded: html_helper
INFO - 2017-03-01 14:59:36 --> Helper loaded: form_helper
INFO - 2017-03-01 14:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:59:36 --> Controller Class Initialized
INFO - 2017-03-01 14:59:36 --> Database Driver Class Initialized
INFO - 2017-03-01 14:59:36 --> Model Class Initialized
INFO - 2017-03-01 14:59:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:59:36 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:59:36 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:59:36 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:59:36 --> Pagination Class Initialized
INFO - 2017-03-01 14:59:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 14:59:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 14:59:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 14:59:36 --> Final output sent to browser
DEBUG - 2017-03-01 14:59:36 --> Total execution time: 0.1789
INFO - 2017-03-01 14:59:40 --> Config Class Initialized
INFO - 2017-03-01 14:59:40 --> Hooks Class Initialized
DEBUG - 2017-03-01 14:59:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 14:59:40 --> Utf8 Class Initialized
INFO - 2017-03-01 14:59:40 --> URI Class Initialized
INFO - 2017-03-01 14:59:40 --> Router Class Initialized
INFO - 2017-03-01 14:59:40 --> Output Class Initialized
INFO - 2017-03-01 14:59:40 --> Security Class Initialized
DEBUG - 2017-03-01 14:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 14:59:40 --> Input Class Initialized
INFO - 2017-03-01 14:59:40 --> Language Class Initialized
INFO - 2017-03-01 14:59:40 --> Loader Class Initialized
INFO - 2017-03-01 14:59:40 --> Helper loaded: url_helper
INFO - 2017-03-01 14:59:40 --> Helper loaded: language_helper
INFO - 2017-03-01 14:59:41 --> Helper loaded: html_helper
INFO - 2017-03-01 14:59:41 --> Helper loaded: form_helper
INFO - 2017-03-01 14:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 14:59:41 --> Controller Class Initialized
INFO - 2017-03-01 14:59:41 --> Database Driver Class Initialized
INFO - 2017-03-01 14:59:41 --> Model Class Initialized
INFO - 2017-03-01 14:59:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 14:59:41 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 14:59:41 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 14:59:41 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 14:59:41 --> Pagination Class Initialized
INFO - 2017-03-01 14:59:41 --> Helper loaded: download_helper
INFO - 2017-03-01 15:00:21 --> Config Class Initialized
INFO - 2017-03-01 15:00:21 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:00:21 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:00:21 --> Utf8 Class Initialized
INFO - 2017-03-01 15:00:21 --> URI Class Initialized
INFO - 2017-03-01 15:00:21 --> Router Class Initialized
INFO - 2017-03-01 15:00:21 --> Output Class Initialized
INFO - 2017-03-01 15:00:21 --> Security Class Initialized
DEBUG - 2017-03-01 15:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:00:21 --> Input Class Initialized
INFO - 2017-03-01 15:00:21 --> Language Class Initialized
INFO - 2017-03-01 15:00:21 --> Loader Class Initialized
INFO - 2017-03-01 15:00:21 --> Helper loaded: url_helper
INFO - 2017-03-01 15:00:21 --> Helper loaded: language_helper
INFO - 2017-03-01 15:00:21 --> Helper loaded: html_helper
INFO - 2017-03-01 15:00:21 --> Helper loaded: form_helper
INFO - 2017-03-01 15:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:00:21 --> Controller Class Initialized
INFO - 2017-03-01 15:00:21 --> Database Driver Class Initialized
INFO - 2017-03-01 15:00:21 --> Model Class Initialized
INFO - 2017-03-01 15:00:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:00:21 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 15:00:21 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 15:00:21 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:00:21 --> Pagination Class Initialized
INFO - 2017-03-01 15:00:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:00:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:00:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:00:21 --> Final output sent to browser
DEBUG - 2017-03-01 15:00:21 --> Total execution time: 0.1917
INFO - 2017-03-01 15:00:26 --> Config Class Initialized
INFO - 2017-03-01 15:00:26 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:00:26 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:00:26 --> Utf8 Class Initialized
INFO - 2017-03-01 15:00:26 --> URI Class Initialized
INFO - 2017-03-01 15:00:26 --> Router Class Initialized
INFO - 2017-03-01 15:00:26 --> Output Class Initialized
INFO - 2017-03-01 15:00:26 --> Security Class Initialized
DEBUG - 2017-03-01 15:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:00:26 --> Input Class Initialized
INFO - 2017-03-01 15:00:26 --> Language Class Initialized
INFO - 2017-03-01 15:00:26 --> Loader Class Initialized
INFO - 2017-03-01 15:00:26 --> Helper loaded: url_helper
INFO - 2017-03-01 15:00:26 --> Helper loaded: language_helper
INFO - 2017-03-01 15:00:26 --> Helper loaded: html_helper
INFO - 2017-03-01 15:00:26 --> Helper loaded: form_helper
INFO - 2017-03-01 15:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:00:26 --> Controller Class Initialized
INFO - 2017-03-01 15:00:26 --> Database Driver Class Initialized
INFO - 2017-03-01 15:00:26 --> Model Class Initialized
INFO - 2017-03-01 15:00:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:00:26 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 15:00:26 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 15:00:26 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:00:26 --> Pagination Class Initialized
INFO - 2017-03-01 15:00:26 --> Helper loaded: download_helper
INFO - 2017-03-01 15:02:54 --> Config Class Initialized
INFO - 2017-03-01 15:02:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:02:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:02:54 --> Utf8 Class Initialized
INFO - 2017-03-01 15:02:54 --> URI Class Initialized
INFO - 2017-03-01 15:02:54 --> Router Class Initialized
INFO - 2017-03-01 15:02:54 --> Output Class Initialized
INFO - 2017-03-01 15:02:54 --> Security Class Initialized
DEBUG - 2017-03-01 15:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:02:54 --> Input Class Initialized
INFO - 2017-03-01 15:02:54 --> Language Class Initialized
INFO - 2017-03-01 15:02:54 --> Loader Class Initialized
INFO - 2017-03-01 15:02:54 --> Helper loaded: url_helper
INFO - 2017-03-01 15:02:54 --> Helper loaded: language_helper
INFO - 2017-03-01 15:02:54 --> Helper loaded: html_helper
INFO - 2017-03-01 15:02:54 --> Helper loaded: form_helper
INFO - 2017-03-01 15:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:02:54 --> Controller Class Initialized
INFO - 2017-03-01 15:02:54 --> Database Driver Class Initialized
INFO - 2017-03-01 15:02:54 --> Model Class Initialized
INFO - 2017-03-01 15:02:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:02:54 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 15:02:54 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 15:02:54 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:02:54 --> Pagination Class Initialized
INFO - 2017-03-01 15:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:02:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:02:54 --> Final output sent to browser
DEBUG - 2017-03-01 15:02:54 --> Total execution time: 0.2047
INFO - 2017-03-01 15:02:56 --> Config Class Initialized
INFO - 2017-03-01 15:02:56 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:02:56 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:02:56 --> Utf8 Class Initialized
INFO - 2017-03-01 15:02:56 --> URI Class Initialized
INFO - 2017-03-01 15:02:56 --> Router Class Initialized
INFO - 2017-03-01 15:02:56 --> Output Class Initialized
INFO - 2017-03-01 15:02:56 --> Security Class Initialized
DEBUG - 2017-03-01 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:02:56 --> Input Class Initialized
INFO - 2017-03-01 15:02:56 --> Language Class Initialized
INFO - 2017-03-01 15:02:56 --> Loader Class Initialized
INFO - 2017-03-01 15:02:56 --> Helper loaded: url_helper
INFO - 2017-03-01 15:02:56 --> Helper loaded: language_helper
INFO - 2017-03-01 15:02:56 --> Helper loaded: html_helper
INFO - 2017-03-01 15:02:56 --> Helper loaded: form_helper
INFO - 2017-03-01 15:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:02:56 --> Controller Class Initialized
INFO - 2017-03-01 15:02:56 --> Database Driver Class Initialized
INFO - 2017-03-01 15:02:56 --> Model Class Initialized
INFO - 2017-03-01 15:02:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:02:56 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 15:02:56 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 15:02:56 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:02:56 --> Pagination Class Initialized
INFO - 2017-03-01 15:03:24 --> Config Class Initialized
INFO - 2017-03-01 15:03:24 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:03:24 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:03:24 --> Utf8 Class Initialized
INFO - 2017-03-01 15:03:24 --> URI Class Initialized
INFO - 2017-03-01 15:03:24 --> Router Class Initialized
INFO - 2017-03-01 15:03:24 --> Output Class Initialized
INFO - 2017-03-01 15:03:24 --> Security Class Initialized
DEBUG - 2017-03-01 15:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:03:24 --> Input Class Initialized
INFO - 2017-03-01 15:03:24 --> Language Class Initialized
INFO - 2017-03-01 15:03:24 --> Loader Class Initialized
INFO - 2017-03-01 15:03:25 --> Helper loaded: url_helper
INFO - 2017-03-01 15:03:25 --> Helper loaded: language_helper
INFO - 2017-03-01 15:03:25 --> Helper loaded: html_helper
INFO - 2017-03-01 15:03:25 --> Helper loaded: form_helper
INFO - 2017-03-01 15:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:03:25 --> Controller Class Initialized
INFO - 2017-03-01 15:03:25 --> Database Driver Class Initialized
INFO - 2017-03-01 15:03:25 --> Model Class Initialized
INFO - 2017-03-01 15:03:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:03:25 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 15:03:25 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 15:03:25 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:03:25 --> Pagination Class Initialized
INFO - 2017-03-01 15:03:39 --> Config Class Initialized
INFO - 2017-03-01 15:03:39 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:03:39 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:03:39 --> Utf8 Class Initialized
INFO - 2017-03-01 15:03:39 --> URI Class Initialized
INFO - 2017-03-01 15:03:39 --> Router Class Initialized
INFO - 2017-03-01 15:03:39 --> Output Class Initialized
INFO - 2017-03-01 15:03:39 --> Security Class Initialized
DEBUG - 2017-03-01 15:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:03:39 --> Input Class Initialized
INFO - 2017-03-01 15:03:39 --> Language Class Initialized
INFO - 2017-03-01 15:03:39 --> Loader Class Initialized
INFO - 2017-03-01 15:03:39 --> Helper loaded: url_helper
INFO - 2017-03-01 15:03:39 --> Helper loaded: language_helper
INFO - 2017-03-01 15:03:39 --> Helper loaded: html_helper
INFO - 2017-03-01 15:03:39 --> Helper loaded: form_helper
INFO - 2017-03-01 15:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:03:39 --> Controller Class Initialized
INFO - 2017-03-01 15:03:39 --> Database Driver Class Initialized
INFO - 2017-03-01 15:03:39 --> Model Class Initialized
INFO - 2017-03-01 15:03:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:03:39 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 15:03:39 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 15:03:39 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:03:39 --> Pagination Class Initialized
INFO - 2017-03-01 15:04:37 --> Config Class Initialized
INFO - 2017-03-01 15:04:37 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:04:37 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:04:37 --> Utf8 Class Initialized
INFO - 2017-03-01 15:04:37 --> URI Class Initialized
INFO - 2017-03-01 15:04:37 --> Router Class Initialized
INFO - 2017-03-01 15:04:37 --> Output Class Initialized
INFO - 2017-03-01 15:04:37 --> Security Class Initialized
DEBUG - 2017-03-01 15:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:04:37 --> Input Class Initialized
INFO - 2017-03-01 15:04:37 --> Language Class Initialized
INFO - 2017-03-01 15:04:37 --> Loader Class Initialized
INFO - 2017-03-01 15:04:37 --> Helper loaded: url_helper
INFO - 2017-03-01 15:04:37 --> Helper loaded: language_helper
INFO - 2017-03-01 15:04:37 --> Helper loaded: html_helper
INFO - 2017-03-01 15:04:37 --> Helper loaded: form_helper
INFO - 2017-03-01 15:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:04:37 --> Controller Class Initialized
INFO - 2017-03-01 15:04:37 --> Database Driver Class Initialized
INFO - 2017-03-01 15:04:37 --> Model Class Initialized
INFO - 2017-03-01 15:04:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:04:37 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 15:04:37 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 15:04:37 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:04:37 --> Pagination Class Initialized
INFO - 2017-03-01 15:06:14 --> Config Class Initialized
INFO - 2017-03-01 15:06:14 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:06:14 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:06:14 --> Utf8 Class Initialized
INFO - 2017-03-01 15:06:14 --> URI Class Initialized
INFO - 2017-03-01 15:06:14 --> Router Class Initialized
INFO - 2017-03-01 15:06:14 --> Output Class Initialized
INFO - 2017-03-01 15:06:14 --> Security Class Initialized
DEBUG - 2017-03-01 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:06:14 --> Input Class Initialized
INFO - 2017-03-01 15:06:14 --> Language Class Initialized
INFO - 2017-03-01 15:06:14 --> Loader Class Initialized
INFO - 2017-03-01 15:06:14 --> Helper loaded: url_helper
INFO - 2017-03-01 15:06:14 --> Helper loaded: language_helper
INFO - 2017-03-01 15:06:15 --> Helper loaded: html_helper
INFO - 2017-03-01 15:06:15 --> Helper loaded: form_helper
INFO - 2017-03-01 15:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:06:15 --> Controller Class Initialized
INFO - 2017-03-01 15:06:15 --> Database Driver Class Initialized
INFO - 2017-03-01 15:06:15 --> Model Class Initialized
INFO - 2017-03-01 15:06:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:06:15 --> Zip Compression Class Initialized
DEBUG - 2017-03-01 15:06:15 --> My_Zip class already loaded. Second attempt ignored.
INFO - 2017-03-01 15:06:15 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:06:15 --> Pagination Class Initialized
INFO - 2017-03-01 15:06:15 --> Helper loaded: download_helper
INFO - 2017-03-01 15:07:49 --> Config Class Initialized
INFO - 2017-03-01 15:07:49 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:07:49 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:07:49 --> Utf8 Class Initialized
INFO - 2017-03-01 15:07:49 --> URI Class Initialized
INFO - 2017-03-01 15:07:49 --> Router Class Initialized
INFO - 2017-03-01 15:07:49 --> Output Class Initialized
INFO - 2017-03-01 15:07:49 --> Security Class Initialized
DEBUG - 2017-03-01 15:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:07:49 --> Input Class Initialized
INFO - 2017-03-01 15:07:49 --> Language Class Initialized
INFO - 2017-03-01 15:07:49 --> Loader Class Initialized
INFO - 2017-03-01 15:07:49 --> Helper loaded: url_helper
INFO - 2017-03-01 15:07:49 --> Helper loaded: language_helper
INFO - 2017-03-01 15:07:49 --> Helper loaded: html_helper
INFO - 2017-03-01 15:07:49 --> Helper loaded: form_helper
INFO - 2017-03-01 15:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:07:49 --> Controller Class Initialized
INFO - 2017-03-01 15:07:49 --> Database Driver Class Initialized
INFO - 2017-03-01 15:07:49 --> Model Class Initialized
INFO - 2017-03-01 15:07:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:07:49 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:07:49 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:07:49 --> Pagination Class Initialized
INFO - 2017-03-01 15:07:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:07:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:07:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:07:49 --> Final output sent to browser
DEBUG - 2017-03-01 15:07:49 --> Total execution time: 0.1376
INFO - 2017-03-01 15:08:03 --> Config Class Initialized
INFO - 2017-03-01 15:08:03 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:08:03 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:08:03 --> Utf8 Class Initialized
INFO - 2017-03-01 15:08:04 --> URI Class Initialized
INFO - 2017-03-01 15:08:04 --> Router Class Initialized
INFO - 2017-03-01 15:08:04 --> Output Class Initialized
INFO - 2017-03-01 15:08:04 --> Security Class Initialized
DEBUG - 2017-03-01 15:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:08:04 --> Input Class Initialized
INFO - 2017-03-01 15:08:04 --> Language Class Initialized
INFO - 2017-03-01 15:08:04 --> Loader Class Initialized
INFO - 2017-03-01 15:08:04 --> Helper loaded: url_helper
INFO - 2017-03-01 15:08:04 --> Helper loaded: language_helper
INFO - 2017-03-01 15:08:04 --> Helper loaded: html_helper
INFO - 2017-03-01 15:08:04 --> Helper loaded: form_helper
INFO - 2017-03-01 15:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:08:04 --> Controller Class Initialized
INFO - 2017-03-01 15:08:04 --> Database Driver Class Initialized
INFO - 2017-03-01 15:08:04 --> Model Class Initialized
INFO - 2017-03-01 15:08:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:08:04 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:08:04 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:08:04 --> Pagination Class Initialized
INFO - 2017-03-01 15:08:04 --> Helper loaded: download_helper
INFO - 2017-03-01 15:15:28 --> Config Class Initialized
INFO - 2017-03-01 15:15:28 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:15:28 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:15:28 --> Utf8 Class Initialized
INFO - 2017-03-01 15:15:28 --> URI Class Initialized
INFO - 2017-03-01 15:15:28 --> Router Class Initialized
INFO - 2017-03-01 15:15:28 --> Output Class Initialized
INFO - 2017-03-01 15:15:28 --> Security Class Initialized
DEBUG - 2017-03-01 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:15:28 --> Input Class Initialized
INFO - 2017-03-01 15:15:28 --> Language Class Initialized
INFO - 2017-03-01 15:15:28 --> Loader Class Initialized
INFO - 2017-03-01 15:15:28 --> Helper loaded: url_helper
INFO - 2017-03-01 15:15:28 --> Helper loaded: language_helper
INFO - 2017-03-01 15:15:28 --> Helper loaded: html_helper
INFO - 2017-03-01 15:15:28 --> Helper loaded: form_helper
INFO - 2017-03-01 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:15:28 --> Controller Class Initialized
INFO - 2017-03-01 15:15:28 --> Database Driver Class Initialized
INFO - 2017-03-01 15:15:28 --> Model Class Initialized
INFO - 2017-03-01 15:15:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:15:28 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:15:28 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:15:28 --> Pagination Class Initialized
INFO - 2017-03-01 15:15:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:15:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:15:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:15:28 --> Final output sent to browser
DEBUG - 2017-03-01 15:15:28 --> Total execution time: 0.2503
INFO - 2017-03-01 15:16:02 --> Config Class Initialized
INFO - 2017-03-01 15:16:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:16:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:16:02 --> Utf8 Class Initialized
INFO - 2017-03-01 15:16:02 --> URI Class Initialized
INFO - 2017-03-01 15:16:02 --> Router Class Initialized
INFO - 2017-03-01 15:16:02 --> Output Class Initialized
INFO - 2017-03-01 15:16:02 --> Security Class Initialized
DEBUG - 2017-03-01 15:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:16:02 --> Input Class Initialized
INFO - 2017-03-01 15:16:02 --> Language Class Initialized
INFO - 2017-03-01 15:16:02 --> Loader Class Initialized
INFO - 2017-03-01 15:16:02 --> Helper loaded: url_helper
INFO - 2017-03-01 15:16:02 --> Helper loaded: language_helper
INFO - 2017-03-01 15:16:02 --> Helper loaded: html_helper
INFO - 2017-03-01 15:16:02 --> Helper loaded: form_helper
INFO - 2017-03-01 15:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:16:02 --> Controller Class Initialized
INFO - 2017-03-01 15:16:02 --> Database Driver Class Initialized
INFO - 2017-03-01 15:16:02 --> Model Class Initialized
INFO - 2017-03-01 15:16:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:16:02 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:16:02 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:16:02 --> Pagination Class Initialized
INFO - 2017-03-01 15:16:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:16:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:16:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:16:02 --> Final output sent to browser
DEBUG - 2017-03-01 15:16:02 --> Total execution time: 0.2773
INFO - 2017-03-01 15:16:44 --> Config Class Initialized
INFO - 2017-03-01 15:16:44 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:16:44 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:16:44 --> Utf8 Class Initialized
INFO - 2017-03-01 15:16:44 --> URI Class Initialized
INFO - 2017-03-01 15:16:44 --> Router Class Initialized
INFO - 2017-03-01 15:16:44 --> Output Class Initialized
INFO - 2017-03-01 15:16:44 --> Security Class Initialized
DEBUG - 2017-03-01 15:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:16:44 --> Input Class Initialized
INFO - 2017-03-01 15:16:44 --> Language Class Initialized
INFO - 2017-03-01 15:16:44 --> Loader Class Initialized
INFO - 2017-03-01 15:16:44 --> Helper loaded: url_helper
INFO - 2017-03-01 15:16:44 --> Helper loaded: language_helper
INFO - 2017-03-01 15:16:44 --> Helper loaded: html_helper
INFO - 2017-03-01 15:16:44 --> Helper loaded: form_helper
INFO - 2017-03-01 15:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:16:44 --> Controller Class Initialized
INFO - 2017-03-01 15:16:44 --> Database Driver Class Initialized
INFO - 2017-03-01 15:16:44 --> Model Class Initialized
INFO - 2017-03-01 15:16:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:16:44 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:16:44 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:16:44 --> Pagination Class Initialized
INFO - 2017-03-01 15:16:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:16:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:16:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:16:44 --> Final output sent to browser
DEBUG - 2017-03-01 15:16:44 --> Total execution time: 0.1840
INFO - 2017-03-01 15:18:02 --> Config Class Initialized
INFO - 2017-03-01 15:18:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:18:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:18:02 --> Utf8 Class Initialized
INFO - 2017-03-01 15:18:02 --> URI Class Initialized
INFO - 2017-03-01 15:18:02 --> Router Class Initialized
INFO - 2017-03-01 15:18:02 --> Output Class Initialized
INFO - 2017-03-01 15:18:02 --> Security Class Initialized
DEBUG - 2017-03-01 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:18:02 --> Input Class Initialized
INFO - 2017-03-01 15:18:02 --> Language Class Initialized
INFO - 2017-03-01 15:18:02 --> Loader Class Initialized
INFO - 2017-03-01 15:18:02 --> Helper loaded: url_helper
INFO - 2017-03-01 15:18:02 --> Helper loaded: language_helper
INFO - 2017-03-01 15:18:02 --> Helper loaded: html_helper
INFO - 2017-03-01 15:18:02 --> Helper loaded: form_helper
INFO - 2017-03-01 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:18:02 --> Controller Class Initialized
INFO - 2017-03-01 15:18:02 --> Database Driver Class Initialized
INFO - 2017-03-01 15:18:02 --> Model Class Initialized
INFO - 2017-03-01 15:18:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:18:02 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:18:02 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:18:02 --> Pagination Class Initialized
INFO - 2017-03-01 15:18:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:18:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:18:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:18:02 --> Final output sent to browser
DEBUG - 2017-03-01 15:18:02 --> Total execution time: 0.1768
INFO - 2017-03-01 15:18:07 --> Config Class Initialized
INFO - 2017-03-01 15:18:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:18:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:18:07 --> Utf8 Class Initialized
INFO - 2017-03-01 15:18:07 --> URI Class Initialized
INFO - 2017-03-01 15:18:07 --> Router Class Initialized
INFO - 2017-03-01 15:18:07 --> Output Class Initialized
INFO - 2017-03-01 15:18:07 --> Security Class Initialized
DEBUG - 2017-03-01 15:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:18:07 --> Input Class Initialized
INFO - 2017-03-01 15:18:07 --> Language Class Initialized
INFO - 2017-03-01 15:18:07 --> Loader Class Initialized
INFO - 2017-03-01 15:18:07 --> Helper loaded: url_helper
INFO - 2017-03-01 15:18:07 --> Helper loaded: language_helper
INFO - 2017-03-01 15:18:07 --> Helper loaded: html_helper
INFO - 2017-03-01 15:18:07 --> Helper loaded: form_helper
INFO - 2017-03-01 15:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:18:07 --> Controller Class Initialized
INFO - 2017-03-01 15:18:07 --> Database Driver Class Initialized
INFO - 2017-03-01 15:18:07 --> Model Class Initialized
INFO - 2017-03-01 15:18:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:18:07 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:18:07 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:18:07 --> Pagination Class Initialized
INFO - 2017-03-01 15:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:18:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:18:07 --> Final output sent to browser
DEBUG - 2017-03-01 15:18:07 --> Total execution time: 0.1965
INFO - 2017-03-01 15:18:10 --> Config Class Initialized
INFO - 2017-03-01 15:18:10 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:18:10 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:18:10 --> Utf8 Class Initialized
INFO - 2017-03-01 15:18:10 --> URI Class Initialized
INFO - 2017-03-01 15:18:10 --> Router Class Initialized
INFO - 2017-03-01 15:18:10 --> Output Class Initialized
INFO - 2017-03-01 15:18:10 --> Security Class Initialized
DEBUG - 2017-03-01 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:18:10 --> Input Class Initialized
INFO - 2017-03-01 15:18:10 --> Language Class Initialized
INFO - 2017-03-01 15:18:10 --> Loader Class Initialized
INFO - 2017-03-01 15:18:10 --> Helper loaded: url_helper
INFO - 2017-03-01 15:18:10 --> Helper loaded: language_helper
INFO - 2017-03-01 15:18:10 --> Helper loaded: html_helper
INFO - 2017-03-01 15:18:10 --> Helper loaded: form_helper
INFO - 2017-03-01 15:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:18:10 --> Controller Class Initialized
INFO - 2017-03-01 15:18:10 --> Database Driver Class Initialized
INFO - 2017-03-01 15:18:10 --> Model Class Initialized
INFO - 2017-03-01 15:18:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:18:10 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:18:10 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:18:10 --> Pagination Class Initialized
INFO - 2017-03-01 15:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:18:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:18:11 --> Final output sent to browser
DEBUG - 2017-03-01 15:18:11 --> Total execution time: 0.1764
INFO - 2017-03-01 15:19:39 --> Config Class Initialized
INFO - 2017-03-01 15:19:39 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:19:39 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:19:39 --> Utf8 Class Initialized
INFO - 2017-03-01 15:19:39 --> URI Class Initialized
INFO - 2017-03-01 15:19:39 --> Router Class Initialized
INFO - 2017-03-01 15:19:39 --> Output Class Initialized
INFO - 2017-03-01 15:19:39 --> Security Class Initialized
DEBUG - 2017-03-01 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:19:39 --> Input Class Initialized
INFO - 2017-03-01 15:19:39 --> Language Class Initialized
INFO - 2017-03-01 15:19:39 --> Loader Class Initialized
INFO - 2017-03-01 15:19:39 --> Helper loaded: url_helper
INFO - 2017-03-01 15:19:39 --> Helper loaded: language_helper
INFO - 2017-03-01 15:19:39 --> Helper loaded: html_helper
INFO - 2017-03-01 15:19:39 --> Helper loaded: form_helper
INFO - 2017-03-01 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:19:39 --> Controller Class Initialized
INFO - 2017-03-01 15:19:39 --> Database Driver Class Initialized
INFO - 2017-03-01 15:19:39 --> Model Class Initialized
INFO - 2017-03-01 15:19:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:19:39 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:19:39 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:19:39 --> Pagination Class Initialized
INFO - 2017-03-01 15:19:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:19:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:19:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:19:39 --> Final output sent to browser
DEBUG - 2017-03-01 15:19:39 --> Total execution time: 0.1917
INFO - 2017-03-01 15:19:59 --> Config Class Initialized
INFO - 2017-03-01 15:19:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:19:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:19:59 --> Utf8 Class Initialized
INFO - 2017-03-01 15:19:59 --> URI Class Initialized
INFO - 2017-03-01 15:19:59 --> Router Class Initialized
INFO - 2017-03-01 15:19:59 --> Output Class Initialized
INFO - 2017-03-01 15:19:59 --> Security Class Initialized
DEBUG - 2017-03-01 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:19:59 --> Input Class Initialized
INFO - 2017-03-01 15:19:59 --> Language Class Initialized
INFO - 2017-03-01 15:19:59 --> Loader Class Initialized
INFO - 2017-03-01 15:19:59 --> Helper loaded: url_helper
INFO - 2017-03-01 15:19:59 --> Helper loaded: language_helper
INFO - 2017-03-01 15:19:59 --> Helper loaded: html_helper
INFO - 2017-03-01 15:19:59 --> Helper loaded: form_helper
INFO - 2017-03-01 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:19:59 --> Controller Class Initialized
INFO - 2017-03-01 15:19:59 --> Database Driver Class Initialized
INFO - 2017-03-01 15:19:59 --> Model Class Initialized
INFO - 2017-03-01 15:19:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:19:59 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:19:59 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:19:59 --> Pagination Class Initialized
INFO - 2017-03-01 15:19:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:19:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:19:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:19:59 --> Final output sent to browser
DEBUG - 2017-03-01 15:19:59 --> Total execution time: 0.2110
INFO - 2017-03-01 15:20:40 --> Config Class Initialized
INFO - 2017-03-01 15:20:40 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:20:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:20:40 --> Utf8 Class Initialized
INFO - 2017-03-01 15:20:40 --> URI Class Initialized
INFO - 2017-03-01 15:20:40 --> Router Class Initialized
INFO - 2017-03-01 15:20:40 --> Output Class Initialized
INFO - 2017-03-01 15:20:40 --> Security Class Initialized
DEBUG - 2017-03-01 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:20:40 --> Input Class Initialized
INFO - 2017-03-01 15:20:40 --> Language Class Initialized
INFO - 2017-03-01 15:20:40 --> Loader Class Initialized
INFO - 2017-03-01 15:20:40 --> Helper loaded: url_helper
INFO - 2017-03-01 15:20:40 --> Helper loaded: language_helper
INFO - 2017-03-01 15:20:40 --> Helper loaded: html_helper
INFO - 2017-03-01 15:20:40 --> Helper loaded: form_helper
INFO - 2017-03-01 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:20:40 --> Controller Class Initialized
INFO - 2017-03-01 15:20:40 --> Database Driver Class Initialized
INFO - 2017-03-01 15:20:40 --> Model Class Initialized
INFO - 2017-03-01 15:20:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:20:40 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:20:40 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:20:40 --> Pagination Class Initialized
INFO - 2017-03-01 15:20:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:20:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:20:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:20:40 --> Final output sent to browser
DEBUG - 2017-03-01 15:20:40 --> Total execution time: 0.2251
INFO - 2017-03-01 15:21:19 --> Config Class Initialized
INFO - 2017-03-01 15:21:19 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:21:19 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:21:19 --> Utf8 Class Initialized
INFO - 2017-03-01 15:21:19 --> URI Class Initialized
INFO - 2017-03-01 15:21:19 --> Router Class Initialized
INFO - 2017-03-01 15:21:19 --> Output Class Initialized
INFO - 2017-03-01 15:21:19 --> Security Class Initialized
DEBUG - 2017-03-01 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:21:19 --> Input Class Initialized
INFO - 2017-03-01 15:21:19 --> Language Class Initialized
INFO - 2017-03-01 15:21:19 --> Loader Class Initialized
INFO - 2017-03-01 15:21:19 --> Helper loaded: url_helper
INFO - 2017-03-01 15:21:19 --> Helper loaded: language_helper
INFO - 2017-03-01 15:21:19 --> Helper loaded: html_helper
INFO - 2017-03-01 15:21:19 --> Helper loaded: form_helper
INFO - 2017-03-01 15:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:21:19 --> Controller Class Initialized
INFO - 2017-03-01 15:21:19 --> Database Driver Class Initialized
INFO - 2017-03-01 15:21:19 --> Model Class Initialized
INFO - 2017-03-01 15:21:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:21:19 --> Zip Compression Class Initialized
INFO - 2017-03-01 15:21:19 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-01 15:21:19 --> Pagination Class Initialized
INFO - 2017-03-01 15:21:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:21:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-01 15:21:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:21:19 --> Final output sent to browser
DEBUG - 2017-03-01 15:21:19 --> Total execution time: 0.1998
INFO - 2017-03-01 15:35:51 --> Config Class Initialized
INFO - 2017-03-01 15:35:51 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:35:51 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:35:51 --> Utf8 Class Initialized
INFO - 2017-03-01 15:35:51 --> URI Class Initialized
INFO - 2017-03-01 15:35:51 --> Router Class Initialized
INFO - 2017-03-01 15:35:51 --> Output Class Initialized
INFO - 2017-03-01 15:35:51 --> Security Class Initialized
DEBUG - 2017-03-01 15:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:35:51 --> Input Class Initialized
INFO - 2017-03-01 15:35:51 --> Language Class Initialized
INFO - 2017-03-01 15:35:51 --> Loader Class Initialized
INFO - 2017-03-01 15:35:51 --> Helper loaded: url_helper
INFO - 2017-03-01 15:35:51 --> Helper loaded: language_helper
INFO - 2017-03-01 15:35:51 --> Helper loaded: html_helper
INFO - 2017-03-01 15:35:51 --> Helper loaded: form_helper
INFO - 2017-03-01 15:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:35:51 --> Controller Class Initialized
INFO - 2017-03-01 15:35:51 --> Database Driver Class Initialized
INFO - 2017-03-01 15:35:51 --> Model Class Initialized
INFO - 2017-03-01 15:35:51 --> Model Class Initialized
INFO - 2017-03-01 15:35:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:35:51 --> Config Class Initialized
INFO - 2017-03-01 15:35:51 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:35:51 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:35:51 --> Utf8 Class Initialized
INFO - 2017-03-01 15:35:51 --> URI Class Initialized
INFO - 2017-03-01 15:35:51 --> Router Class Initialized
INFO - 2017-03-01 15:35:51 --> Output Class Initialized
INFO - 2017-03-01 15:35:51 --> Security Class Initialized
DEBUG - 2017-03-01 15:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:35:51 --> Input Class Initialized
INFO - 2017-03-01 15:35:51 --> Language Class Initialized
INFO - 2017-03-01 15:35:51 --> Loader Class Initialized
INFO - 2017-03-01 15:35:51 --> Helper loaded: url_helper
INFO - 2017-03-01 15:35:51 --> Helper loaded: language_helper
INFO - 2017-03-01 15:35:51 --> Helper loaded: html_helper
INFO - 2017-03-01 15:35:51 --> Helper loaded: form_helper
INFO - 2017-03-01 15:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:35:51 --> Controller Class Initialized
INFO - 2017-03-01 15:35:51 --> Database Driver Class Initialized
INFO - 2017-03-01 15:35:51 --> Model Class Initialized
INFO - 2017-03-01 15:35:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:35:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-01 15:35:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-01 15:35:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-01 15:35:51 --> Final output sent to browser
DEBUG - 2017-03-01 15:35:51 --> Total execution time: 0.1499
INFO - 2017-03-01 15:35:54 --> Config Class Initialized
INFO - 2017-03-01 15:35:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:35:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:35:54 --> Utf8 Class Initialized
INFO - 2017-03-01 15:35:54 --> URI Class Initialized
INFO - 2017-03-01 15:35:54 --> Router Class Initialized
INFO - 2017-03-01 15:35:54 --> Output Class Initialized
INFO - 2017-03-01 15:35:54 --> Security Class Initialized
DEBUG - 2017-03-01 15:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:35:54 --> Input Class Initialized
INFO - 2017-03-01 15:35:54 --> Language Class Initialized
INFO - 2017-03-01 15:35:54 --> Loader Class Initialized
INFO - 2017-03-01 15:35:54 --> Helper loaded: url_helper
INFO - 2017-03-01 15:35:54 --> Helper loaded: language_helper
INFO - 2017-03-01 15:35:54 --> Helper loaded: html_helper
INFO - 2017-03-01 15:35:54 --> Helper loaded: form_helper
INFO - 2017-03-01 15:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:35:54 --> Controller Class Initialized
INFO - 2017-03-01 15:35:54 --> Database Driver Class Initialized
INFO - 2017-03-01 15:35:54 --> Model Class Initialized
INFO - 2017-03-01 15:35:54 --> Email Class Initialized
INFO - 2017-03-01 15:35:54 --> Form Validation Class Initialized
INFO - 2017-03-01 15:35:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:35:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:35:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 15:35:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:35:54 --> Final output sent to browser
DEBUG - 2017-03-01 15:35:54 --> Total execution time: 0.1876
INFO - 2017-03-01 15:37:18 --> Config Class Initialized
INFO - 2017-03-01 15:37:18 --> Hooks Class Initialized
DEBUG - 2017-03-01 15:37:18 --> UTF-8 Support Enabled
INFO - 2017-03-01 15:37:18 --> Utf8 Class Initialized
INFO - 2017-03-01 15:37:18 --> URI Class Initialized
INFO - 2017-03-01 15:37:18 --> Router Class Initialized
INFO - 2017-03-01 15:37:18 --> Output Class Initialized
INFO - 2017-03-01 15:37:18 --> Security Class Initialized
DEBUG - 2017-03-01 15:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 15:37:18 --> Input Class Initialized
INFO - 2017-03-01 15:37:18 --> Language Class Initialized
INFO - 2017-03-01 15:37:18 --> Loader Class Initialized
INFO - 2017-03-01 15:37:18 --> Helper loaded: url_helper
INFO - 2017-03-01 15:37:18 --> Helper loaded: language_helper
INFO - 2017-03-01 15:37:18 --> Helper loaded: html_helper
INFO - 2017-03-01 15:37:18 --> Helper loaded: form_helper
INFO - 2017-03-01 15:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 15:37:18 --> Controller Class Initialized
INFO - 2017-03-01 15:37:18 --> Database Driver Class Initialized
INFO - 2017-03-01 15:37:18 --> Model Class Initialized
INFO - 2017-03-01 15:37:18 --> Email Class Initialized
INFO - 2017-03-01 15:37:19 --> Form Validation Class Initialized
INFO - 2017-03-01 15:37:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 15:37:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 15:37:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 15:37:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 15:37:19 --> Final output sent to browser
DEBUG - 2017-03-01 15:37:19 --> Total execution time: 0.1472
INFO - 2017-03-01 17:53:46 --> Config Class Initialized
INFO - 2017-03-01 17:53:46 --> Hooks Class Initialized
DEBUG - 2017-03-01 17:53:46 --> UTF-8 Support Enabled
INFO - 2017-03-01 17:53:46 --> Utf8 Class Initialized
INFO - 2017-03-01 17:53:46 --> URI Class Initialized
INFO - 2017-03-01 17:53:46 --> Router Class Initialized
INFO - 2017-03-01 17:53:46 --> Output Class Initialized
INFO - 2017-03-01 17:53:46 --> Security Class Initialized
DEBUG - 2017-03-01 17:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 17:53:46 --> Input Class Initialized
INFO - 2017-03-01 17:53:46 --> Language Class Initialized
INFO - 2017-03-01 17:53:46 --> Loader Class Initialized
INFO - 2017-03-01 17:53:46 --> Helper loaded: url_helper
INFO - 2017-03-01 17:53:46 --> Helper loaded: language_helper
INFO - 2017-03-01 17:53:46 --> Helper loaded: html_helper
INFO - 2017-03-01 17:53:46 --> Helper loaded: form_helper
INFO - 2017-03-01 17:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 17:53:46 --> Controller Class Initialized
INFO - 2017-03-01 17:53:46 --> Database Driver Class Initialized
INFO - 2017-03-01 17:53:46 --> Model Class Initialized
INFO - 2017-03-01 17:53:46 --> Email Class Initialized
INFO - 2017-03-01 17:53:46 --> Form Validation Class Initialized
INFO - 2017-03-01 17:53:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 17:53:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 17:53:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 17:53:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 17:53:46 --> Final output sent to browser
DEBUG - 2017-03-01 17:53:46 --> Total execution time: 0.2780
INFO - 2017-03-01 17:55:06 --> Config Class Initialized
INFO - 2017-03-01 17:55:06 --> Hooks Class Initialized
DEBUG - 2017-03-01 17:55:06 --> UTF-8 Support Enabled
INFO - 2017-03-01 17:55:06 --> Utf8 Class Initialized
INFO - 2017-03-01 17:55:06 --> URI Class Initialized
INFO - 2017-03-01 17:55:06 --> Router Class Initialized
INFO - 2017-03-01 17:55:06 --> Output Class Initialized
INFO - 2017-03-01 17:55:06 --> Security Class Initialized
DEBUG - 2017-03-01 17:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 17:55:06 --> Input Class Initialized
INFO - 2017-03-01 17:55:06 --> Language Class Initialized
INFO - 2017-03-01 17:55:06 --> Loader Class Initialized
INFO - 2017-03-01 17:55:06 --> Helper loaded: url_helper
INFO - 2017-03-01 17:55:06 --> Helper loaded: language_helper
INFO - 2017-03-01 17:55:06 --> Helper loaded: html_helper
INFO - 2017-03-01 17:55:06 --> Helper loaded: form_helper
INFO - 2017-03-01 17:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 17:55:07 --> Controller Class Initialized
INFO - 2017-03-01 17:55:07 --> Database Driver Class Initialized
INFO - 2017-03-01 17:55:07 --> Model Class Initialized
INFO - 2017-03-01 17:55:07 --> Email Class Initialized
INFO - 2017-03-01 17:55:07 --> Form Validation Class Initialized
INFO - 2017-03-01 17:55:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 17:55:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 17:55:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 17:55:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 17:55:07 --> Final output sent to browser
DEBUG - 2017-03-01 17:55:07 --> Total execution time: 0.1894
INFO - 2017-03-01 17:55:24 --> Config Class Initialized
INFO - 2017-03-01 17:55:24 --> Hooks Class Initialized
DEBUG - 2017-03-01 17:55:24 --> UTF-8 Support Enabled
INFO - 2017-03-01 17:55:24 --> Utf8 Class Initialized
INFO - 2017-03-01 17:55:24 --> URI Class Initialized
INFO - 2017-03-01 17:55:24 --> Router Class Initialized
INFO - 2017-03-01 17:55:24 --> Output Class Initialized
INFO - 2017-03-01 17:55:24 --> Security Class Initialized
DEBUG - 2017-03-01 17:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 17:55:24 --> Input Class Initialized
INFO - 2017-03-01 17:55:24 --> Language Class Initialized
INFO - 2017-03-01 17:55:24 --> Loader Class Initialized
INFO - 2017-03-01 17:55:24 --> Helper loaded: url_helper
INFO - 2017-03-01 17:55:24 --> Helper loaded: language_helper
INFO - 2017-03-01 17:55:24 --> Helper loaded: html_helper
INFO - 2017-03-01 17:55:24 --> Helper loaded: form_helper
INFO - 2017-03-01 17:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 17:55:24 --> Controller Class Initialized
INFO - 2017-03-01 17:55:24 --> Database Driver Class Initialized
INFO - 2017-03-01 17:55:24 --> Model Class Initialized
INFO - 2017-03-01 17:55:24 --> Email Class Initialized
INFO - 2017-03-01 17:55:24 --> Form Validation Class Initialized
INFO - 2017-03-01 17:55:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-01 17:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-01 17:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-01 17:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-01 17:55:24 --> Final output sent to browser
DEBUG - 2017-03-01 17:55:24 --> Total execution time: 0.1339
