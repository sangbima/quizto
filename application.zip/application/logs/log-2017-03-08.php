<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-08 14:52:50 --> Config Class Initialized
INFO - 2017-03-08 14:52:50 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:52:50 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:52:50 --> Utf8 Class Initialized
INFO - 2017-03-08 14:52:50 --> URI Class Initialized
DEBUG - 2017-03-08 14:52:50 --> No URI present. Default controller set.
INFO - 2017-03-08 14:52:50 --> Router Class Initialized
INFO - 2017-03-08 14:52:50 --> Output Class Initialized
INFO - 2017-03-08 14:52:50 --> Security Class Initialized
DEBUG - 2017-03-08 14:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:52:50 --> Input Class Initialized
INFO - 2017-03-08 14:52:50 --> Language Class Initialized
INFO - 2017-03-08 14:52:50 --> Loader Class Initialized
INFO - 2017-03-08 14:52:50 --> Helper loaded: url_helper
INFO - 2017-03-08 14:52:50 --> Helper loaded: language_helper
INFO - 2017-03-08 14:52:50 --> Helper loaded: html_helper
INFO - 2017-03-08 14:52:50 --> Helper loaded: form_helper
INFO - 2017-03-08 14:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 14:52:50 --> Controller Class Initialized
INFO - 2017-03-08 14:52:50 --> Database Driver Class Initialized
INFO - 2017-03-08 14:52:50 --> Model Class Initialized
INFO - 2017-03-08 14:52:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 14:52:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-08 14:52:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-08 14:52:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-08 14:52:50 --> Final output sent to browser
DEBUG - 2017-03-08 14:52:50 --> Total execution time: 0.2469
INFO - 2017-03-08 14:52:51 --> Config Class Initialized
INFO - 2017-03-08 14:52:51 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:52:51 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:52:51 --> Utf8 Class Initialized
INFO - 2017-03-08 14:52:51 --> URI Class Initialized
INFO - 2017-03-08 14:52:51 --> Router Class Initialized
INFO - 2017-03-08 14:52:51 --> Output Class Initialized
INFO - 2017-03-08 14:52:51 --> Security Class Initialized
DEBUG - 2017-03-08 14:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:52:51 --> Input Class Initialized
INFO - 2017-03-08 14:52:51 --> Language Class Initialized
ERROR - 2017-03-08 14:52:51 --> 404 Page Not Found: Faviconico/index
INFO - 2017-03-08 14:52:58 --> Config Class Initialized
INFO - 2017-03-08 14:52:58 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:52:58 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:52:58 --> Utf8 Class Initialized
INFO - 2017-03-08 14:52:58 --> URI Class Initialized
INFO - 2017-03-08 14:52:58 --> Router Class Initialized
INFO - 2017-03-08 14:52:58 --> Output Class Initialized
INFO - 2017-03-08 14:52:58 --> Security Class Initialized
DEBUG - 2017-03-08 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:52:58 --> Input Class Initialized
INFO - 2017-03-08 14:52:58 --> Language Class Initialized
INFO - 2017-03-08 14:52:58 --> Loader Class Initialized
INFO - 2017-03-08 14:52:58 --> Helper loaded: url_helper
INFO - 2017-03-08 14:52:58 --> Helper loaded: language_helper
INFO - 2017-03-08 14:52:58 --> Helper loaded: html_helper
INFO - 2017-03-08 14:52:58 --> Helper loaded: form_helper
INFO - 2017-03-08 14:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 14:52:58 --> Controller Class Initialized
INFO - 2017-03-08 14:52:58 --> Database Driver Class Initialized
INFO - 2017-03-08 14:52:58 --> Model Class Initialized
INFO - 2017-03-08 14:52:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 14:52:58 --> Config Class Initialized
INFO - 2017-03-08 14:52:58 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:52:58 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:52:58 --> Utf8 Class Initialized
INFO - 2017-03-08 14:52:58 --> URI Class Initialized
INFO - 2017-03-08 14:52:58 --> Router Class Initialized
INFO - 2017-03-08 14:52:58 --> Output Class Initialized
INFO - 2017-03-08 14:52:58 --> Security Class Initialized
DEBUG - 2017-03-08 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:52:58 --> Input Class Initialized
INFO - 2017-03-08 14:52:58 --> Language Class Initialized
INFO - 2017-03-08 14:52:58 --> Loader Class Initialized
INFO - 2017-03-08 14:52:58 --> Helper loaded: url_helper
INFO - 2017-03-08 14:52:58 --> Helper loaded: language_helper
INFO - 2017-03-08 14:52:58 --> Helper loaded: html_helper
INFO - 2017-03-08 14:52:58 --> Helper loaded: form_helper
INFO - 2017-03-08 14:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 14:52:58 --> Controller Class Initialized
INFO - 2017-03-08 14:52:58 --> Database Driver Class Initialized
INFO - 2017-03-08 14:52:58 --> Model Class Initialized
INFO - 2017-03-08 14:52:58 --> Model Class Initialized
INFO - 2017-03-08 14:52:58 --> Model Class Initialized
INFO - 2017-03-08 14:52:58 --> Model Class Initialized
INFO - 2017-03-08 14:52:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 14:52:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-08 14:52:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-03-08 14:52:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-08 14:52:58 --> Final output sent to browser
DEBUG - 2017-03-08 14:52:58 --> Total execution time: 0.1953
INFO - 2017-03-08 14:53:01 --> Config Class Initialized
INFO - 2017-03-08 14:53:01 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:53:01 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:53:01 --> Utf8 Class Initialized
INFO - 2017-03-08 14:53:01 --> URI Class Initialized
INFO - 2017-03-08 14:53:01 --> Router Class Initialized
INFO - 2017-03-08 14:53:01 --> Output Class Initialized
INFO - 2017-03-08 14:53:01 --> Security Class Initialized
DEBUG - 2017-03-08 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:53:01 --> Input Class Initialized
INFO - 2017-03-08 14:53:01 --> Language Class Initialized
INFO - 2017-03-08 14:53:01 --> Loader Class Initialized
INFO - 2017-03-08 14:53:01 --> Helper loaded: url_helper
INFO - 2017-03-08 14:53:01 --> Helper loaded: language_helper
INFO - 2017-03-08 14:53:01 --> Helper loaded: html_helper
INFO - 2017-03-08 14:53:01 --> Helper loaded: form_helper
INFO - 2017-03-08 14:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 14:53:01 --> Controller Class Initialized
INFO - 2017-03-08 14:53:01 --> Database Driver Class Initialized
INFO - 2017-03-08 14:53:01 --> Model Class Initialized
INFO - 2017-03-08 14:53:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 14:53:01 --> Zip Compression Class Initialized
INFO - 2017-03-08 14:53:01 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-08 14:53:01 --> Pagination Class Initialized
INFO - 2017-03-08 14:53:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-08 14:53:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-08 14:53:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-08 14:53:01 --> Final output sent to browser
DEBUG - 2017-03-08 14:53:01 --> Total execution time: 0.1497
INFO - 2017-03-08 14:53:08 --> Config Class Initialized
INFO - 2017-03-08 14:53:08 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:53:08 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:53:08 --> Utf8 Class Initialized
INFO - 2017-03-08 14:53:08 --> URI Class Initialized
INFO - 2017-03-08 14:53:08 --> Router Class Initialized
INFO - 2017-03-08 14:53:08 --> Output Class Initialized
INFO - 2017-03-08 14:53:08 --> Security Class Initialized
DEBUG - 2017-03-08 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:53:08 --> Input Class Initialized
INFO - 2017-03-08 14:53:08 --> Language Class Initialized
INFO - 2017-03-08 14:53:08 --> Loader Class Initialized
INFO - 2017-03-08 14:53:08 --> Helper loaded: url_helper
INFO - 2017-03-08 14:53:08 --> Helper loaded: language_helper
INFO - 2017-03-08 14:53:08 --> Helper loaded: html_helper
INFO - 2017-03-08 14:53:09 --> Helper loaded: form_helper
INFO - 2017-03-08 14:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 14:53:09 --> Controller Class Initialized
INFO - 2017-03-08 14:53:09 --> Database Driver Class Initialized
INFO - 2017-03-08 14:53:09 --> Model Class Initialized
INFO - 2017-03-08 14:53:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 14:53:09 --> Zip Compression Class Initialized
INFO - 2017-03-08 14:53:09 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-08 14:53:09 --> Pagination Class Initialized
INFO - 2017-03-08 14:54:33 --> Config Class Initialized
INFO - 2017-03-08 14:54:33 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:54:33 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:54:33 --> Utf8 Class Initialized
INFO - 2017-03-08 14:54:33 --> URI Class Initialized
INFO - 2017-03-08 14:54:33 --> Router Class Initialized
INFO - 2017-03-08 14:54:33 --> Output Class Initialized
INFO - 2017-03-08 14:54:33 --> Security Class Initialized
DEBUG - 2017-03-08 14:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:54:34 --> Input Class Initialized
INFO - 2017-03-08 14:54:34 --> Language Class Initialized
INFO - 2017-03-08 14:54:34 --> Loader Class Initialized
INFO - 2017-03-08 14:54:34 --> Helper loaded: url_helper
INFO - 2017-03-08 14:54:34 --> Helper loaded: language_helper
INFO - 2017-03-08 14:54:34 --> Helper loaded: html_helper
INFO - 2017-03-08 14:54:34 --> Helper loaded: form_helper
INFO - 2017-03-08 14:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 14:54:34 --> Controller Class Initialized
INFO - 2017-03-08 14:54:34 --> Database Driver Class Initialized
INFO - 2017-03-08 14:54:34 --> Model Class Initialized
INFO - 2017-03-08 14:54:34 --> Model Class Initialized
INFO - 2017-03-08 14:54:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 14:54:34 --> Config Class Initialized
INFO - 2017-03-08 14:54:34 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:54:34 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:54:34 --> Utf8 Class Initialized
INFO - 2017-03-08 14:54:34 --> URI Class Initialized
INFO - 2017-03-08 14:54:34 --> Router Class Initialized
INFO - 2017-03-08 14:54:34 --> Output Class Initialized
INFO - 2017-03-08 14:54:34 --> Security Class Initialized
DEBUG - 2017-03-08 14:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:54:34 --> Input Class Initialized
INFO - 2017-03-08 14:54:34 --> Language Class Initialized
INFO - 2017-03-08 14:54:34 --> Loader Class Initialized
INFO - 2017-03-08 14:54:34 --> Helper loaded: url_helper
INFO - 2017-03-08 14:54:34 --> Helper loaded: language_helper
INFO - 2017-03-08 14:54:34 --> Helper loaded: html_helper
INFO - 2017-03-08 14:54:34 --> Helper loaded: form_helper
INFO - 2017-03-08 14:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 14:54:34 --> Controller Class Initialized
INFO - 2017-03-08 14:54:34 --> Database Driver Class Initialized
INFO - 2017-03-08 14:54:34 --> Model Class Initialized
INFO - 2017-03-08 14:54:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 14:54:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-08 14:54:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-08 14:54:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-08 14:54:34 --> Final output sent to browser
DEBUG - 2017-03-08 14:54:34 --> Total execution time: 0.0891
INFO - 2017-03-08 14:54:36 --> Config Class Initialized
INFO - 2017-03-08 14:54:36 --> Hooks Class Initialized
DEBUG - 2017-03-08 14:54:36 --> UTF-8 Support Enabled
INFO - 2017-03-08 14:54:36 --> Utf8 Class Initialized
INFO - 2017-03-08 14:54:36 --> URI Class Initialized
INFO - 2017-03-08 14:54:36 --> Router Class Initialized
INFO - 2017-03-08 14:54:36 --> Output Class Initialized
INFO - 2017-03-08 14:54:36 --> Security Class Initialized
DEBUG - 2017-03-08 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 14:54:36 --> Input Class Initialized
INFO - 2017-03-08 14:54:36 --> Language Class Initialized
INFO - 2017-03-08 14:54:36 --> Loader Class Initialized
INFO - 2017-03-08 14:54:36 --> Helper loaded: url_helper
INFO - 2017-03-08 14:54:36 --> Helper loaded: language_helper
INFO - 2017-03-08 14:54:36 --> Helper loaded: html_helper
INFO - 2017-03-08 14:54:36 --> Helper loaded: form_helper
INFO - 2017-03-08 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 14:54:36 --> Controller Class Initialized
INFO - 2017-03-08 14:54:36 --> Database Driver Class Initialized
INFO - 2017-03-08 14:54:36 --> Model Class Initialized
INFO - 2017-03-08 14:54:36 --> Email Class Initialized
INFO - 2017-03-08 14:54:36 --> Form Validation Class Initialized
INFO - 2017-03-08 14:54:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 14:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-08 14:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-08 14:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-08 14:54:36 --> Final output sent to browser
DEBUG - 2017-03-08 14:54:36 --> Total execution time: 0.1646
INFO - 2017-03-08 15:06:39 --> Config Class Initialized
INFO - 2017-03-08 15:06:39 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:06:39 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:06:39 --> Utf8 Class Initialized
INFO - 2017-03-08 15:06:39 --> URI Class Initialized
DEBUG - 2017-03-08 15:06:39 --> No URI present. Default controller set.
INFO - 2017-03-08 15:06:39 --> Router Class Initialized
INFO - 2017-03-08 15:06:39 --> Output Class Initialized
INFO - 2017-03-08 15:06:39 --> Security Class Initialized
DEBUG - 2017-03-08 15:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:06:39 --> Input Class Initialized
INFO - 2017-03-08 15:06:39 --> Language Class Initialized
INFO - 2017-03-08 15:06:39 --> Loader Class Initialized
INFO - 2017-03-08 15:06:39 --> Helper loaded: url_helper
INFO - 2017-03-08 15:06:39 --> Helper loaded: language_helper
INFO - 2017-03-08 15:06:39 --> Helper loaded: html_helper
INFO - 2017-03-08 15:06:39 --> Helper loaded: form_helper
INFO - 2017-03-08 15:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:06:39 --> Controller Class Initialized
INFO - 2017-03-08 15:06:39 --> Database Driver Class Initialized
INFO - 2017-03-08 15:06:39 --> Model Class Initialized
INFO - 2017-03-08 15:06:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 15:06:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-08 15:06:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-08 15:06:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-08 15:06:39 --> Final output sent to browser
DEBUG - 2017-03-08 15:06:39 --> Total execution time: 0.0948
INFO - 2017-03-08 15:06:45 --> Config Class Initialized
INFO - 2017-03-08 15:06:45 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:06:45 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:06:45 --> Utf8 Class Initialized
INFO - 2017-03-08 15:06:45 --> URI Class Initialized
INFO - 2017-03-08 15:06:45 --> Router Class Initialized
INFO - 2017-03-08 15:06:45 --> Output Class Initialized
INFO - 2017-03-08 15:06:45 --> Security Class Initialized
DEBUG - 2017-03-08 15:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:06:45 --> Input Class Initialized
INFO - 2017-03-08 15:06:45 --> Language Class Initialized
INFO - 2017-03-08 15:06:45 --> Loader Class Initialized
INFO - 2017-03-08 15:06:45 --> Helper loaded: url_helper
INFO - 2017-03-08 15:06:45 --> Helper loaded: language_helper
INFO - 2017-03-08 15:06:45 --> Helper loaded: html_helper
INFO - 2017-03-08 15:06:45 --> Helper loaded: form_helper
INFO - 2017-03-08 15:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:06:45 --> Controller Class Initialized
INFO - 2017-03-08 15:06:45 --> Database Driver Class Initialized
INFO - 2017-03-08 15:06:45 --> Model Class Initialized
INFO - 2017-03-08 15:06:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 15:06:45 --> Config Class Initialized
INFO - 2017-03-08 15:06:45 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:06:45 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:06:45 --> Utf8 Class Initialized
INFO - 2017-03-08 15:06:45 --> URI Class Initialized
INFO - 2017-03-08 15:06:45 --> Router Class Initialized
INFO - 2017-03-08 15:06:45 --> Output Class Initialized
INFO - 2017-03-08 15:06:45 --> Security Class Initialized
DEBUG - 2017-03-08 15:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:06:45 --> Input Class Initialized
INFO - 2017-03-08 15:06:45 --> Language Class Initialized
INFO - 2017-03-08 15:06:45 --> Loader Class Initialized
INFO - 2017-03-08 15:06:45 --> Helper loaded: url_helper
INFO - 2017-03-08 15:06:45 --> Helper loaded: language_helper
INFO - 2017-03-08 15:06:45 --> Helper loaded: html_helper
INFO - 2017-03-08 15:06:45 --> Helper loaded: form_helper
INFO - 2017-03-08 15:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:06:45 --> Controller Class Initialized
INFO - 2017-03-08 15:06:45 --> Database Driver Class Initialized
INFO - 2017-03-08 15:06:45 --> Model Class Initialized
INFO - 2017-03-08 15:06:45 --> Model Class Initialized
INFO - 2017-03-08 15:06:45 --> Model Class Initialized
INFO - 2017-03-08 15:06:45 --> Model Class Initialized
INFO - 2017-03-08 15:06:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 15:06:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-08 15:06:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-03-08 15:06:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-08 15:06:45 --> Final output sent to browser
DEBUG - 2017-03-08 15:06:45 --> Total execution time: 0.1696
INFO - 2017-03-08 15:06:47 --> Config Class Initialized
INFO - 2017-03-08 15:06:47 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:06:47 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:06:47 --> Utf8 Class Initialized
INFO - 2017-03-08 15:06:47 --> URI Class Initialized
INFO - 2017-03-08 15:06:47 --> Router Class Initialized
INFO - 2017-03-08 15:06:47 --> Output Class Initialized
INFO - 2017-03-08 15:06:47 --> Security Class Initialized
DEBUG - 2017-03-08 15:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:06:47 --> Input Class Initialized
INFO - 2017-03-08 15:06:47 --> Language Class Initialized
INFO - 2017-03-08 15:06:47 --> Loader Class Initialized
INFO - 2017-03-08 15:06:47 --> Helper loaded: url_helper
INFO - 2017-03-08 15:06:47 --> Helper loaded: language_helper
INFO - 2017-03-08 15:06:47 --> Helper loaded: html_helper
INFO - 2017-03-08 15:06:47 --> Helper loaded: form_helper
INFO - 2017-03-08 15:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:06:47 --> Controller Class Initialized
INFO - 2017-03-08 15:06:47 --> Database Driver Class Initialized
INFO - 2017-03-08 15:06:47 --> Model Class Initialized
INFO - 2017-03-08 15:06:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 15:06:47 --> Zip Compression Class Initialized
INFO - 2017-03-08 15:06:47 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-08 15:06:47 --> Pagination Class Initialized
INFO - 2017-03-08 15:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-08 15:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-08 15:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-08 15:06:47 --> Final output sent to browser
DEBUG - 2017-03-08 15:06:47 --> Total execution time: 0.1689
INFO - 2017-03-08 15:06:51 --> Config Class Initialized
INFO - 2017-03-08 15:06:51 --> Hooks Class Initialized
DEBUG - 2017-03-08 15:06:51 --> UTF-8 Support Enabled
INFO - 2017-03-08 15:06:51 --> Utf8 Class Initialized
INFO - 2017-03-08 15:06:51 --> URI Class Initialized
INFO - 2017-03-08 15:06:51 --> Router Class Initialized
INFO - 2017-03-08 15:06:51 --> Output Class Initialized
INFO - 2017-03-08 15:06:51 --> Security Class Initialized
DEBUG - 2017-03-08 15:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-08 15:06:51 --> Input Class Initialized
INFO - 2017-03-08 15:06:51 --> Language Class Initialized
INFO - 2017-03-08 15:06:51 --> Loader Class Initialized
INFO - 2017-03-08 15:06:51 --> Helper loaded: url_helper
INFO - 2017-03-08 15:06:51 --> Helper loaded: language_helper
INFO - 2017-03-08 15:06:51 --> Helper loaded: html_helper
INFO - 2017-03-08 15:06:51 --> Helper loaded: form_helper
INFO - 2017-03-08 15:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-08 15:06:51 --> Controller Class Initialized
INFO - 2017-03-08 15:06:51 --> Database Driver Class Initialized
INFO - 2017-03-08 15:06:51 --> Model Class Initialized
INFO - 2017-03-08 15:06:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-08 15:06:51 --> Zip Compression Class Initialized
INFO - 2017-03-08 15:06:51 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-08 15:06:51 --> Pagination Class Initialized
