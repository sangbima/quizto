<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-10 19:06:47 --> Config Class Initialized
INFO - 2017-03-10 19:06:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:06:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:06:47 --> Utf8 Class Initialized
INFO - 2017-03-10 19:06:47 --> URI Class Initialized
DEBUG - 2017-03-10 19:06:47 --> No URI present. Default controller set.
INFO - 2017-03-10 19:06:47 --> Router Class Initialized
INFO - 2017-03-10 19:06:47 --> Output Class Initialized
INFO - 2017-03-10 19:06:47 --> Security Class Initialized
DEBUG - 2017-03-10 19:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:06:47 --> Input Class Initialized
INFO - 2017-03-10 19:06:47 --> Language Class Initialized
INFO - 2017-03-10 19:06:47 --> Loader Class Initialized
INFO - 2017-03-10 19:06:47 --> Helper loaded: url_helper
INFO - 2017-03-10 19:06:47 --> Helper loaded: language_helper
INFO - 2017-03-10 19:06:47 --> Helper loaded: html_helper
INFO - 2017-03-10 19:06:47 --> Helper loaded: form_helper
INFO - 2017-03-10 19:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:06:47 --> Controller Class Initialized
INFO - 2017-03-10 19:06:47 --> Database Driver Class Initialized
INFO - 2017-03-10 19:06:47 --> Model Class Initialized
INFO - 2017-03-10 19:06:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-10 19:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-10 19:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-10 19:06:47 --> Final output sent to browser
DEBUG - 2017-03-10 19:06:47 --> Total execution time: 0.1547
INFO - 2017-03-10 19:06:47 --> Config Class Initialized
INFO - 2017-03-10 19:06:47 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:06:47 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:06:47 --> Utf8 Class Initialized
INFO - 2017-03-10 19:06:47 --> URI Class Initialized
INFO - 2017-03-10 19:06:47 --> Router Class Initialized
INFO - 2017-03-10 19:06:48 --> Output Class Initialized
INFO - 2017-03-10 19:06:48 --> Security Class Initialized
DEBUG - 2017-03-10 19:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:06:48 --> Input Class Initialized
INFO - 2017-03-10 19:06:48 --> Language Class Initialized
ERROR - 2017-03-10 19:06:48 --> 404 Page Not Found: Faviconico/index
INFO - 2017-03-10 19:06:49 --> Config Class Initialized
INFO - 2017-03-10 19:06:49 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:06:49 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:06:49 --> Utf8 Class Initialized
INFO - 2017-03-10 19:06:49 --> URI Class Initialized
INFO - 2017-03-10 19:06:49 --> Router Class Initialized
INFO - 2017-03-10 19:06:49 --> Output Class Initialized
INFO - 2017-03-10 19:06:49 --> Security Class Initialized
DEBUG - 2017-03-10 19:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:06:49 --> Input Class Initialized
INFO - 2017-03-10 19:06:49 --> Language Class Initialized
INFO - 2017-03-10 19:06:49 --> Loader Class Initialized
INFO - 2017-03-10 19:06:49 --> Helper loaded: url_helper
INFO - 2017-03-10 19:06:49 --> Helper loaded: language_helper
INFO - 2017-03-10 19:06:49 --> Helper loaded: html_helper
INFO - 2017-03-10 19:06:49 --> Helper loaded: form_helper
INFO - 2017-03-10 19:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:06:49 --> Controller Class Initialized
INFO - 2017-03-10 19:06:49 --> Database Driver Class Initialized
INFO - 2017-03-10 19:06:49 --> Model Class Initialized
INFO - 2017-03-10 19:06:49 --> Email Class Initialized
INFO - 2017-03-10 19:06:49 --> Form Validation Class Initialized
INFO - 2017-03-10 19:06:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:06:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:06:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:06:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:06:49 --> Final output sent to browser
DEBUG - 2017-03-10 19:06:49 --> Total execution time: 0.2661
INFO - 2017-03-10 19:07:54 --> Config Class Initialized
INFO - 2017-03-10 19:07:54 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:07:54 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:07:54 --> Utf8 Class Initialized
INFO - 2017-03-10 19:07:54 --> URI Class Initialized
INFO - 2017-03-10 19:07:54 --> Router Class Initialized
INFO - 2017-03-10 19:07:54 --> Output Class Initialized
INFO - 2017-03-10 19:07:54 --> Security Class Initialized
DEBUG - 2017-03-10 19:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:07:54 --> Input Class Initialized
INFO - 2017-03-10 19:07:54 --> Language Class Initialized
INFO - 2017-03-10 19:07:54 --> Loader Class Initialized
INFO - 2017-03-10 19:07:54 --> Helper loaded: url_helper
INFO - 2017-03-10 19:07:54 --> Helper loaded: language_helper
INFO - 2017-03-10 19:07:54 --> Helper loaded: html_helper
INFO - 2017-03-10 19:07:54 --> Helper loaded: form_helper
INFO - 2017-03-10 19:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:07:54 --> Controller Class Initialized
INFO - 2017-03-10 19:07:54 --> Database Driver Class Initialized
INFO - 2017-03-10 19:07:54 --> Model Class Initialized
INFO - 2017-03-10 19:07:54 --> Email Class Initialized
INFO - 2017-03-10 19:07:54 --> Form Validation Class Initialized
INFO - 2017-03-10 19:07:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:07:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:07:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:07:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:07:54 --> Final output sent to browser
DEBUG - 2017-03-10 19:07:54 --> Total execution time: 0.1573
INFO - 2017-03-10 19:10:31 --> Config Class Initialized
INFO - 2017-03-10 19:10:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:10:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:10:31 --> Utf8 Class Initialized
INFO - 2017-03-10 19:10:31 --> URI Class Initialized
INFO - 2017-03-10 19:10:32 --> Router Class Initialized
INFO - 2017-03-10 19:10:32 --> Output Class Initialized
INFO - 2017-03-10 19:10:32 --> Security Class Initialized
DEBUG - 2017-03-10 19:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:10:32 --> Input Class Initialized
INFO - 2017-03-10 19:10:32 --> Language Class Initialized
INFO - 2017-03-10 19:10:32 --> Loader Class Initialized
INFO - 2017-03-10 19:10:32 --> Helper loaded: url_helper
INFO - 2017-03-10 19:10:32 --> Helper loaded: language_helper
INFO - 2017-03-10 19:10:32 --> Helper loaded: html_helper
INFO - 2017-03-10 19:10:32 --> Helper loaded: form_helper
INFO - 2017-03-10 19:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:10:32 --> Controller Class Initialized
INFO - 2017-03-10 19:10:32 --> Database Driver Class Initialized
INFO - 2017-03-10 19:10:32 --> Model Class Initialized
INFO - 2017-03-10 19:10:32 --> Email Class Initialized
INFO - 2017-03-10 19:10:32 --> Form Validation Class Initialized
INFO - 2017-03-10 19:10:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:10:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:10:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:10:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:10:32 --> Final output sent to browser
DEBUG - 2017-03-10 19:10:32 --> Total execution time: 0.1370
INFO - 2017-03-10 19:13:40 --> Config Class Initialized
INFO - 2017-03-10 19:13:40 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:13:40 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:13:40 --> Utf8 Class Initialized
INFO - 2017-03-10 19:13:40 --> URI Class Initialized
INFO - 2017-03-10 19:13:40 --> Router Class Initialized
INFO - 2017-03-10 19:13:40 --> Output Class Initialized
INFO - 2017-03-10 19:13:40 --> Security Class Initialized
DEBUG - 2017-03-10 19:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:13:40 --> Input Class Initialized
INFO - 2017-03-10 19:13:40 --> Language Class Initialized
INFO - 2017-03-10 19:13:40 --> Loader Class Initialized
INFO - 2017-03-10 19:13:40 --> Helper loaded: url_helper
INFO - 2017-03-10 19:13:40 --> Helper loaded: language_helper
INFO - 2017-03-10 19:13:40 --> Helper loaded: html_helper
INFO - 2017-03-10 19:13:40 --> Helper loaded: form_helper
INFO - 2017-03-10 19:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:13:40 --> Controller Class Initialized
INFO - 2017-03-10 19:13:40 --> Database Driver Class Initialized
INFO - 2017-03-10 19:13:40 --> Model Class Initialized
INFO - 2017-03-10 19:13:40 --> Email Class Initialized
INFO - 2017-03-10 19:13:40 --> Form Validation Class Initialized
INFO - 2017-03-10 19:13:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:13:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:13:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:13:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:13:40 --> Final output sent to browser
DEBUG - 2017-03-10 19:13:40 --> Total execution time: 0.1742
INFO - 2017-03-10 19:14:10 --> Config Class Initialized
INFO - 2017-03-10 19:14:10 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:14:10 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:14:10 --> Utf8 Class Initialized
INFO - 2017-03-10 19:14:10 --> URI Class Initialized
INFO - 2017-03-10 19:14:10 --> Router Class Initialized
INFO - 2017-03-10 19:14:10 --> Output Class Initialized
INFO - 2017-03-10 19:14:10 --> Security Class Initialized
DEBUG - 2017-03-10 19:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:14:10 --> Input Class Initialized
INFO - 2017-03-10 19:14:10 --> Language Class Initialized
INFO - 2017-03-10 19:14:10 --> Loader Class Initialized
INFO - 2017-03-10 19:14:10 --> Helper loaded: url_helper
INFO - 2017-03-10 19:14:10 --> Helper loaded: language_helper
INFO - 2017-03-10 19:14:10 --> Helper loaded: html_helper
INFO - 2017-03-10 19:14:10 --> Helper loaded: form_helper
INFO - 2017-03-10 19:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:14:10 --> Controller Class Initialized
INFO - 2017-03-10 19:14:10 --> Database Driver Class Initialized
INFO - 2017-03-10 19:14:10 --> Model Class Initialized
INFO - 2017-03-10 19:14:10 --> Email Class Initialized
INFO - 2017-03-10 19:14:10 --> Form Validation Class Initialized
INFO - 2017-03-10 19:14:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:14:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:14:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:14:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:14:10 --> Final output sent to browser
DEBUG - 2017-03-10 19:14:10 --> Total execution time: 0.1644
INFO - 2017-03-10 19:15:18 --> Config Class Initialized
INFO - 2017-03-10 19:15:18 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:15:18 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:15:18 --> Utf8 Class Initialized
INFO - 2017-03-10 19:15:18 --> URI Class Initialized
INFO - 2017-03-10 19:15:18 --> Router Class Initialized
INFO - 2017-03-10 19:15:18 --> Output Class Initialized
INFO - 2017-03-10 19:15:18 --> Security Class Initialized
DEBUG - 2017-03-10 19:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:15:18 --> Input Class Initialized
INFO - 2017-03-10 19:15:18 --> Language Class Initialized
INFO - 2017-03-10 19:15:18 --> Loader Class Initialized
INFO - 2017-03-10 19:15:18 --> Helper loaded: url_helper
INFO - 2017-03-10 19:15:18 --> Helper loaded: language_helper
INFO - 2017-03-10 19:15:18 --> Helper loaded: html_helper
INFO - 2017-03-10 19:15:18 --> Helper loaded: form_helper
INFO - 2017-03-10 19:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:15:18 --> Controller Class Initialized
INFO - 2017-03-10 19:15:18 --> Database Driver Class Initialized
INFO - 2017-03-10 19:15:18 --> Model Class Initialized
INFO - 2017-03-10 19:15:18 --> Email Class Initialized
INFO - 2017-03-10 19:15:18 --> Form Validation Class Initialized
INFO - 2017-03-10 19:15:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:15:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:15:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:15:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:15:18 --> Final output sent to browser
DEBUG - 2017-03-10 19:15:18 --> Total execution time: 0.1707
INFO - 2017-03-10 19:16:55 --> Config Class Initialized
INFO - 2017-03-10 19:16:55 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:16:55 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:16:55 --> Utf8 Class Initialized
INFO - 2017-03-10 19:16:55 --> URI Class Initialized
INFO - 2017-03-10 19:16:55 --> Router Class Initialized
INFO - 2017-03-10 19:16:55 --> Output Class Initialized
INFO - 2017-03-10 19:16:55 --> Security Class Initialized
DEBUG - 2017-03-10 19:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:16:55 --> Input Class Initialized
INFO - 2017-03-10 19:16:55 --> Language Class Initialized
INFO - 2017-03-10 19:16:55 --> Loader Class Initialized
INFO - 2017-03-10 19:16:55 --> Helper loaded: url_helper
INFO - 2017-03-10 19:16:55 --> Helper loaded: language_helper
INFO - 2017-03-10 19:16:55 --> Helper loaded: html_helper
INFO - 2017-03-10 19:16:55 --> Helper loaded: form_helper
INFO - 2017-03-10 19:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:16:55 --> Controller Class Initialized
INFO - 2017-03-10 19:16:55 --> Database Driver Class Initialized
INFO - 2017-03-10 19:16:55 --> Model Class Initialized
INFO - 2017-03-10 19:16:55 --> Email Class Initialized
INFO - 2017-03-10 19:16:55 --> Form Validation Class Initialized
INFO - 2017-03-10 19:16:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:16:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:16:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:16:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:16:55 --> Final output sent to browser
DEBUG - 2017-03-10 19:16:55 --> Total execution time: 0.1434
INFO - 2017-03-10 19:18:40 --> Config Class Initialized
INFO - 2017-03-10 19:18:40 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:18:40 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:18:40 --> Utf8 Class Initialized
INFO - 2017-03-10 19:18:40 --> URI Class Initialized
INFO - 2017-03-10 19:18:40 --> Router Class Initialized
INFO - 2017-03-10 19:18:40 --> Output Class Initialized
INFO - 2017-03-10 19:18:40 --> Security Class Initialized
DEBUG - 2017-03-10 19:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:18:40 --> Input Class Initialized
INFO - 2017-03-10 19:18:40 --> Language Class Initialized
INFO - 2017-03-10 19:18:40 --> Loader Class Initialized
INFO - 2017-03-10 19:18:40 --> Helper loaded: url_helper
INFO - 2017-03-10 19:18:40 --> Helper loaded: language_helper
INFO - 2017-03-10 19:18:40 --> Helper loaded: html_helper
INFO - 2017-03-10 19:18:40 --> Helper loaded: form_helper
INFO - 2017-03-10 19:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:18:40 --> Controller Class Initialized
INFO - 2017-03-10 19:18:40 --> Database Driver Class Initialized
INFO - 2017-03-10 19:18:40 --> Model Class Initialized
INFO - 2017-03-10 19:18:40 --> Email Class Initialized
INFO - 2017-03-10 19:18:40 --> Form Validation Class Initialized
INFO - 2017-03-10 19:18:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:18:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:18:40 --> Final output sent to browser
DEBUG - 2017-03-10 19:18:40 --> Total execution time: 0.1547
INFO - 2017-03-10 19:22:34 --> Config Class Initialized
INFO - 2017-03-10 19:22:34 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:22:34 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:22:34 --> Utf8 Class Initialized
INFO - 2017-03-10 19:22:34 --> URI Class Initialized
INFO - 2017-03-10 19:22:35 --> Router Class Initialized
INFO - 2017-03-10 19:22:35 --> Output Class Initialized
INFO - 2017-03-10 19:22:35 --> Security Class Initialized
DEBUG - 2017-03-10 19:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:22:35 --> Input Class Initialized
INFO - 2017-03-10 19:22:35 --> Language Class Initialized
INFO - 2017-03-10 19:22:35 --> Loader Class Initialized
INFO - 2017-03-10 19:22:35 --> Helper loaded: url_helper
INFO - 2017-03-10 19:22:35 --> Helper loaded: language_helper
INFO - 2017-03-10 19:22:35 --> Helper loaded: html_helper
INFO - 2017-03-10 19:22:35 --> Helper loaded: form_helper
INFO - 2017-03-10 19:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:22:35 --> Controller Class Initialized
INFO - 2017-03-10 19:22:35 --> Database Driver Class Initialized
INFO - 2017-03-10 19:22:35 --> Model Class Initialized
INFO - 2017-03-10 19:22:35 --> Email Class Initialized
INFO - 2017-03-10 19:22:35 --> Form Validation Class Initialized
INFO - 2017-03-10 19:22:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:22:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:22:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:22:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:22:35 --> Final output sent to browser
DEBUG - 2017-03-10 19:22:35 --> Total execution time: 0.1917
INFO - 2017-03-10 19:23:04 --> Config Class Initialized
INFO - 2017-03-10 19:23:04 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:23:04 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:23:04 --> Utf8 Class Initialized
INFO - 2017-03-10 19:23:04 --> URI Class Initialized
INFO - 2017-03-10 19:23:04 --> Router Class Initialized
INFO - 2017-03-10 19:23:04 --> Output Class Initialized
INFO - 2017-03-10 19:23:04 --> Security Class Initialized
DEBUG - 2017-03-10 19:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:23:04 --> Input Class Initialized
INFO - 2017-03-10 19:23:04 --> Language Class Initialized
INFO - 2017-03-10 19:23:04 --> Loader Class Initialized
INFO - 2017-03-10 19:23:04 --> Helper loaded: url_helper
INFO - 2017-03-10 19:23:04 --> Helper loaded: language_helper
INFO - 2017-03-10 19:23:04 --> Helper loaded: html_helper
INFO - 2017-03-10 19:23:04 --> Helper loaded: form_helper
INFO - 2017-03-10 19:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:23:04 --> Controller Class Initialized
INFO - 2017-03-10 19:23:04 --> Database Driver Class Initialized
INFO - 2017-03-10 19:23:04 --> Model Class Initialized
INFO - 2017-03-10 19:23:04 --> Email Class Initialized
INFO - 2017-03-10 19:23:04 --> Form Validation Class Initialized
INFO - 2017-03-10 19:23:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:23:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:23:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:23:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:23:04 --> Final output sent to browser
DEBUG - 2017-03-10 19:23:04 --> Total execution time: 0.1851
INFO - 2017-03-10 19:54:34 --> Config Class Initialized
INFO - 2017-03-10 19:54:34 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:54:34 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:54:34 --> Utf8 Class Initialized
INFO - 2017-03-10 19:54:34 --> URI Class Initialized
INFO - 2017-03-10 19:54:34 --> Router Class Initialized
INFO - 2017-03-10 19:54:34 --> Output Class Initialized
INFO - 2017-03-10 19:54:34 --> Security Class Initialized
DEBUG - 2017-03-10 19:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:54:34 --> Input Class Initialized
INFO - 2017-03-10 19:54:34 --> Language Class Initialized
INFO - 2017-03-10 19:54:34 --> Loader Class Initialized
INFO - 2017-03-10 19:54:34 --> Helper loaded: url_helper
INFO - 2017-03-10 19:54:34 --> Helper loaded: language_helper
INFO - 2017-03-10 19:54:34 --> Helper loaded: html_helper
INFO - 2017-03-10 19:54:34 --> Helper loaded: form_helper
INFO - 2017-03-10 19:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:54:34 --> Controller Class Initialized
INFO - 2017-03-10 19:54:34 --> Database Driver Class Initialized
INFO - 2017-03-10 19:54:34 --> Model Class Initialized
INFO - 2017-03-10 19:54:34 --> Email Class Initialized
INFO - 2017-03-10 19:54:34 --> Form Validation Class Initialized
INFO - 2017-03-10 19:54:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:54:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:54:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:54:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:54:34 --> Final output sent to browser
DEBUG - 2017-03-10 19:54:34 --> Total execution time: 0.1786
INFO - 2017-03-10 19:55:14 --> Config Class Initialized
INFO - 2017-03-10 19:55:14 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:55:14 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:55:14 --> Utf8 Class Initialized
INFO - 2017-03-10 19:55:14 --> URI Class Initialized
INFO - 2017-03-10 19:55:14 --> Router Class Initialized
INFO - 2017-03-10 19:55:14 --> Output Class Initialized
INFO - 2017-03-10 19:55:14 --> Security Class Initialized
DEBUG - 2017-03-10 19:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:55:14 --> Input Class Initialized
INFO - 2017-03-10 19:55:14 --> Language Class Initialized
INFO - 2017-03-10 19:55:14 --> Loader Class Initialized
INFO - 2017-03-10 19:55:14 --> Helper loaded: url_helper
INFO - 2017-03-10 19:55:14 --> Helper loaded: language_helper
INFO - 2017-03-10 19:55:14 --> Helper loaded: html_helper
INFO - 2017-03-10 19:55:14 --> Helper loaded: form_helper
INFO - 2017-03-10 19:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:55:14 --> Controller Class Initialized
INFO - 2017-03-10 19:55:14 --> Database Driver Class Initialized
INFO - 2017-03-10 19:55:14 --> Model Class Initialized
INFO - 2017-03-10 19:55:14 --> Email Class Initialized
INFO - 2017-03-10 19:55:14 --> Form Validation Class Initialized
INFO - 2017-03-10 19:55:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:55:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:55:14 --> Final output sent to browser
DEBUG - 2017-03-10 19:55:14 --> Total execution time: 0.2012
INFO - 2017-03-10 19:55:50 --> Config Class Initialized
INFO - 2017-03-10 19:55:50 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:55:50 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:55:50 --> Utf8 Class Initialized
INFO - 2017-03-10 19:55:50 --> URI Class Initialized
INFO - 2017-03-10 19:55:50 --> Router Class Initialized
INFO - 2017-03-10 19:55:50 --> Output Class Initialized
INFO - 2017-03-10 19:55:50 --> Security Class Initialized
DEBUG - 2017-03-10 19:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:55:50 --> Input Class Initialized
INFO - 2017-03-10 19:55:50 --> Language Class Initialized
INFO - 2017-03-10 19:55:50 --> Loader Class Initialized
INFO - 2017-03-10 19:55:50 --> Helper loaded: url_helper
INFO - 2017-03-10 19:55:50 --> Helper loaded: language_helper
INFO - 2017-03-10 19:55:50 --> Helper loaded: html_helper
INFO - 2017-03-10 19:55:50 --> Helper loaded: form_helper
INFO - 2017-03-10 19:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:55:50 --> Controller Class Initialized
INFO - 2017-03-10 19:55:50 --> Database Driver Class Initialized
INFO - 2017-03-10 19:55:50 --> Model Class Initialized
INFO - 2017-03-10 19:55:50 --> Email Class Initialized
INFO - 2017-03-10 19:55:50 --> Form Validation Class Initialized
INFO - 2017-03-10 19:55:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:55:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:55:50 --> Final output sent to browser
DEBUG - 2017-03-10 19:55:50 --> Total execution time: 0.1614
INFO - 2017-03-10 19:58:08 --> Config Class Initialized
INFO - 2017-03-10 19:58:08 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:58:08 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:58:08 --> Utf8 Class Initialized
INFO - 2017-03-10 19:58:08 --> URI Class Initialized
INFO - 2017-03-10 19:58:08 --> Router Class Initialized
INFO - 2017-03-10 19:58:08 --> Output Class Initialized
INFO - 2017-03-10 19:58:08 --> Security Class Initialized
DEBUG - 2017-03-10 19:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:58:08 --> Input Class Initialized
INFO - 2017-03-10 19:58:08 --> Language Class Initialized
INFO - 2017-03-10 19:58:08 --> Loader Class Initialized
INFO - 2017-03-10 19:58:08 --> Helper loaded: url_helper
INFO - 2017-03-10 19:58:08 --> Helper loaded: language_helper
INFO - 2017-03-10 19:58:08 --> Helper loaded: html_helper
INFO - 2017-03-10 19:58:08 --> Helper loaded: form_helper
INFO - 2017-03-10 19:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:58:08 --> Controller Class Initialized
INFO - 2017-03-10 19:58:08 --> Database Driver Class Initialized
INFO - 2017-03-10 19:58:08 --> Model Class Initialized
INFO - 2017-03-10 19:58:08 --> Email Class Initialized
INFO - 2017-03-10 19:58:08 --> Form Validation Class Initialized
INFO - 2017-03-10 19:58:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:58:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:58:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:58:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:58:08 --> Final output sent to browser
DEBUG - 2017-03-10 19:58:08 --> Total execution time: 0.1676
INFO - 2017-03-10 19:58:38 --> Config Class Initialized
INFO - 2017-03-10 19:58:38 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:58:38 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:58:38 --> Utf8 Class Initialized
INFO - 2017-03-10 19:58:38 --> URI Class Initialized
INFO - 2017-03-10 19:58:38 --> Router Class Initialized
INFO - 2017-03-10 19:58:38 --> Output Class Initialized
INFO - 2017-03-10 19:58:38 --> Security Class Initialized
DEBUG - 2017-03-10 19:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:58:38 --> Input Class Initialized
INFO - 2017-03-10 19:58:38 --> Language Class Initialized
INFO - 2017-03-10 19:58:38 --> Loader Class Initialized
INFO - 2017-03-10 19:58:38 --> Helper loaded: url_helper
INFO - 2017-03-10 19:58:38 --> Helper loaded: language_helper
INFO - 2017-03-10 19:58:38 --> Helper loaded: html_helper
INFO - 2017-03-10 19:58:38 --> Helper loaded: form_helper
INFO - 2017-03-10 19:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:58:38 --> Controller Class Initialized
INFO - 2017-03-10 19:58:38 --> Database Driver Class Initialized
INFO - 2017-03-10 19:58:38 --> Model Class Initialized
INFO - 2017-03-10 19:58:38 --> Email Class Initialized
INFO - 2017-03-10 19:58:38 --> Form Validation Class Initialized
INFO - 2017-03-10 19:58:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:58:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:58:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:58:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:58:38 --> Final output sent to browser
DEBUG - 2017-03-10 19:58:38 --> Total execution time: 0.1389
INFO - 2017-03-10 19:59:31 --> Config Class Initialized
INFO - 2017-03-10 19:59:31 --> Hooks Class Initialized
DEBUG - 2017-03-10 19:59:31 --> UTF-8 Support Enabled
INFO - 2017-03-10 19:59:31 --> Utf8 Class Initialized
INFO - 2017-03-10 19:59:31 --> URI Class Initialized
INFO - 2017-03-10 19:59:31 --> Router Class Initialized
INFO - 2017-03-10 19:59:31 --> Output Class Initialized
INFO - 2017-03-10 19:59:31 --> Security Class Initialized
DEBUG - 2017-03-10 19:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 19:59:31 --> Input Class Initialized
INFO - 2017-03-10 19:59:31 --> Language Class Initialized
INFO - 2017-03-10 19:59:31 --> Loader Class Initialized
INFO - 2017-03-10 19:59:31 --> Helper loaded: url_helper
INFO - 2017-03-10 19:59:31 --> Helper loaded: language_helper
INFO - 2017-03-10 19:59:31 --> Helper loaded: html_helper
INFO - 2017-03-10 19:59:31 --> Helper loaded: form_helper
INFO - 2017-03-10 19:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 19:59:31 --> Controller Class Initialized
INFO - 2017-03-10 19:59:31 --> Database Driver Class Initialized
INFO - 2017-03-10 19:59:31 --> Model Class Initialized
INFO - 2017-03-10 19:59:31 --> Email Class Initialized
INFO - 2017-03-10 19:59:31 --> Form Validation Class Initialized
INFO - 2017-03-10 19:59:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 19:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 19:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 19:59:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 19:59:31 --> Final output sent to browser
DEBUG - 2017-03-10 19:59:31 --> Total execution time: 0.1545
INFO - 2017-03-10 20:00:00 --> Config Class Initialized
INFO - 2017-03-10 20:00:00 --> Hooks Class Initialized
DEBUG - 2017-03-10 20:00:00 --> UTF-8 Support Enabled
INFO - 2017-03-10 20:00:00 --> Utf8 Class Initialized
INFO - 2017-03-10 20:00:00 --> URI Class Initialized
INFO - 2017-03-10 20:00:00 --> Router Class Initialized
INFO - 2017-03-10 20:00:00 --> Output Class Initialized
INFO - 2017-03-10 20:00:00 --> Security Class Initialized
DEBUG - 2017-03-10 20:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-10 20:00:00 --> Input Class Initialized
INFO - 2017-03-10 20:00:00 --> Language Class Initialized
INFO - 2017-03-10 20:00:00 --> Loader Class Initialized
INFO - 2017-03-10 20:00:00 --> Helper loaded: url_helper
INFO - 2017-03-10 20:00:00 --> Helper loaded: language_helper
INFO - 2017-03-10 20:00:00 --> Helper loaded: html_helper
INFO - 2017-03-10 20:00:00 --> Helper loaded: form_helper
INFO - 2017-03-10 20:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-10 20:00:00 --> Controller Class Initialized
INFO - 2017-03-10 20:00:00 --> Database Driver Class Initialized
INFO - 2017-03-10 20:00:00 --> Model Class Initialized
INFO - 2017-03-10 20:00:00 --> Email Class Initialized
INFO - 2017-03-10 20:00:00 --> Form Validation Class Initialized
INFO - 2017-03-10 20:00:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-10 20:00:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-10 20:00:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-10 20:00:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-10 20:00:00 --> Final output sent to browser
DEBUG - 2017-03-10 20:00:00 --> Total execution time: 0.1619
