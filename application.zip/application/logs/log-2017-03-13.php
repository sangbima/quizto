<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-13 14:09:30 --> Config Class Initialized
INFO - 2017-03-13 14:09:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:09:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:09:30 --> Utf8 Class Initialized
INFO - 2017-03-13 14:09:30 --> URI Class Initialized
DEBUG - 2017-03-13 14:09:30 --> No URI present. Default controller set.
INFO - 2017-03-13 14:09:30 --> Router Class Initialized
INFO - 2017-03-13 14:09:30 --> Output Class Initialized
INFO - 2017-03-13 14:09:30 --> Security Class Initialized
DEBUG - 2017-03-13 14:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:09:30 --> Input Class Initialized
INFO - 2017-03-13 14:09:30 --> Language Class Initialized
INFO - 2017-03-13 14:09:30 --> Loader Class Initialized
INFO - 2017-03-13 14:09:30 --> Helper loaded: url_helper
INFO - 2017-03-13 14:09:30 --> Helper loaded: language_helper
INFO - 2017-03-13 14:09:30 --> Helper loaded: html_helper
INFO - 2017-03-13 14:09:30 --> Helper loaded: form_helper
INFO - 2017-03-13 14:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:09:30 --> Controller Class Initialized
INFO - 2017-03-13 14:09:30 --> Database Driver Class Initialized
INFO - 2017-03-13 14:09:30 --> Model Class Initialized
INFO - 2017-03-13 14:09:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:09:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-13 14:09:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-13 14:09:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-13 14:09:30 --> Final output sent to browser
DEBUG - 2017-03-13 14:09:30 --> Total execution time: 0.2200
INFO - 2017-03-13 14:09:31 --> Config Class Initialized
INFO - 2017-03-13 14:09:31 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:09:31 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:09:31 --> Utf8 Class Initialized
INFO - 2017-03-13 14:09:31 --> URI Class Initialized
INFO - 2017-03-13 14:09:31 --> Router Class Initialized
INFO - 2017-03-13 14:09:31 --> Output Class Initialized
INFO - 2017-03-13 14:09:31 --> Security Class Initialized
DEBUG - 2017-03-13 14:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:09:31 --> Input Class Initialized
INFO - 2017-03-13 14:09:31 --> Language Class Initialized
ERROR - 2017-03-13 14:09:31 --> 404 Page Not Found: Faviconico/index
INFO - 2017-03-13 14:09:36 --> Config Class Initialized
INFO - 2017-03-13 14:09:36 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:09:36 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:09:36 --> Utf8 Class Initialized
INFO - 2017-03-13 14:09:36 --> URI Class Initialized
INFO - 2017-03-13 14:09:36 --> Router Class Initialized
INFO - 2017-03-13 14:09:36 --> Output Class Initialized
INFO - 2017-03-13 14:09:36 --> Security Class Initialized
DEBUG - 2017-03-13 14:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:09:36 --> Input Class Initialized
INFO - 2017-03-13 14:09:36 --> Language Class Initialized
INFO - 2017-03-13 14:09:36 --> Loader Class Initialized
INFO - 2017-03-13 14:09:36 --> Helper loaded: url_helper
INFO - 2017-03-13 14:09:36 --> Helper loaded: language_helper
INFO - 2017-03-13 14:09:36 --> Helper loaded: html_helper
INFO - 2017-03-13 14:09:36 --> Helper loaded: form_helper
INFO - 2017-03-13 14:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:09:36 --> Controller Class Initialized
INFO - 2017-03-13 14:09:36 --> Database Driver Class Initialized
INFO - 2017-03-13 14:09:36 --> Model Class Initialized
INFO - 2017-03-13 14:09:36 --> Email Class Initialized
INFO - 2017-03-13 14:09:36 --> Form Validation Class Initialized
INFO - 2017-03-13 14:09:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:09:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 14:09:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-13 14:09:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 14:09:36 --> Final output sent to browser
DEBUG - 2017-03-13 14:09:36 --> Total execution time: 0.1498
INFO - 2017-03-13 14:11:33 --> Config Class Initialized
INFO - 2017-03-13 14:11:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:11:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:11:33 --> Utf8 Class Initialized
INFO - 2017-03-13 14:11:33 --> URI Class Initialized
INFO - 2017-03-13 14:11:33 --> Router Class Initialized
INFO - 2017-03-13 14:11:33 --> Output Class Initialized
INFO - 2017-03-13 14:11:33 --> Security Class Initialized
DEBUG - 2017-03-13 14:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:11:33 --> Input Class Initialized
INFO - 2017-03-13 14:11:33 --> Language Class Initialized
INFO - 2017-03-13 14:11:33 --> Loader Class Initialized
INFO - 2017-03-13 14:11:33 --> Helper loaded: url_helper
INFO - 2017-03-13 14:11:33 --> Helper loaded: language_helper
INFO - 2017-03-13 14:11:33 --> Helper loaded: html_helper
INFO - 2017-03-13 14:11:33 --> Helper loaded: form_helper
INFO - 2017-03-13 14:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:11:33 --> Controller Class Initialized
INFO - 2017-03-13 14:11:33 --> Database Driver Class Initialized
INFO - 2017-03-13 14:11:33 --> Model Class Initialized
INFO - 2017-03-13 14:11:33 --> Email Class Initialized
INFO - 2017-03-13 14:11:33 --> Form Validation Class Initialized
INFO - 2017-03-13 14:11:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:11:33 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-03-13 14:11:35 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-13 14:11:35 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-13 14:11:35 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-03-13 14:11:35 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-13 14:11:48 --> Config Class Initialized
INFO - 2017-03-13 14:11:48 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:11:48 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:11:48 --> Utf8 Class Initialized
INFO - 2017-03-13 14:11:48 --> URI Class Initialized
INFO - 2017-03-13 14:11:48 --> Router Class Initialized
INFO - 2017-03-13 14:11:48 --> Output Class Initialized
INFO - 2017-03-13 14:11:48 --> Security Class Initialized
DEBUG - 2017-03-13 14:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:11:48 --> Input Class Initialized
INFO - 2017-03-13 14:11:48 --> Language Class Initialized
INFO - 2017-03-13 14:11:48 --> Loader Class Initialized
INFO - 2017-03-13 14:11:48 --> Helper loaded: url_helper
INFO - 2017-03-13 14:11:48 --> Helper loaded: language_helper
INFO - 2017-03-13 14:11:48 --> Helper loaded: html_helper
INFO - 2017-03-13 14:11:48 --> Helper loaded: form_helper
INFO - 2017-03-13 14:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:11:48 --> Controller Class Initialized
INFO - 2017-03-13 14:11:49 --> Database Driver Class Initialized
INFO - 2017-03-13 14:11:49 --> Model Class Initialized
INFO - 2017-03-13 14:11:49 --> Email Class Initialized
INFO - 2017-03-13 14:11:49 --> Form Validation Class Initialized
INFO - 2017-03-13 14:11:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:11:49 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-13 14:11:49 --> Language file loaded: language/indonesia/email_lang.php
ERROR - 2017-03-13 14:11:53 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error:  C:\wamp64\www\savsoftquiz\application\models\Register_model.php 241
ERROR - 2017-03-13 14:11:53 --> Severity: Warning --> imagecreatefromjpeg(): 'upload/data/170300000045/lampiran/170300000045_foto.jpg' is not a valid JPEG file C:\wamp64\www\savsoftquiz\application\models\Register_model.php 241
ERROR - 2017-03-13 14:11:53 --> Severity: Warning --> imagecopyresized() expects parameter 2 to be resource, boolean given C:\wamp64\www\savsoftquiz\application\models\Register_model.php 243
ERROR - 2017-03-13 14:11:53 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error:  C:\wamp64\www\savsoftquiz\application\models\Register_model.php 241
ERROR - 2017-03-13 14:11:53 --> Severity: Warning --> imagecreatefromjpeg(): 'upload/data/170300000045/lampiran/170300000045_ijazah.jpg' is not a valid JPEG file C:\wamp64\www\savsoftquiz\application\models\Register_model.php 241
ERROR - 2017-03-13 14:11:53 --> Severity: Warning --> imagecopyresized() expects parameter 2 to be resource, boolean given C:\wamp64\www\savsoftquiz\application\models\Register_model.php 243
INFO - 2017-03-13 14:11:55 --> Final output sent to browser
DEBUG - 2017-03-13 14:11:55 --> Total execution time: 6.0952
INFO - 2017-03-13 14:13:25 --> Config Class Initialized
INFO - 2017-03-13 14:13:25 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:13:25 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:13:25 --> Utf8 Class Initialized
INFO - 2017-03-13 14:13:25 --> URI Class Initialized
INFO - 2017-03-13 14:13:25 --> Router Class Initialized
INFO - 2017-03-13 14:13:25 --> Output Class Initialized
INFO - 2017-03-13 14:13:25 --> Security Class Initialized
DEBUG - 2017-03-13 14:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:13:25 --> Input Class Initialized
INFO - 2017-03-13 14:13:25 --> Language Class Initialized
INFO - 2017-03-13 14:13:25 --> Loader Class Initialized
INFO - 2017-03-13 14:13:25 --> Helper loaded: url_helper
INFO - 2017-03-13 14:13:25 --> Helper loaded: language_helper
INFO - 2017-03-13 14:13:25 --> Helper loaded: html_helper
INFO - 2017-03-13 14:13:25 --> Helper loaded: form_helper
INFO - 2017-03-13 14:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:13:25 --> Controller Class Initialized
INFO - 2017-03-13 14:13:25 --> Database Driver Class Initialized
INFO - 2017-03-13 14:13:25 --> Model Class Initialized
INFO - 2017-03-13 14:13:25 --> Email Class Initialized
INFO - 2017-03-13 14:13:25 --> Form Validation Class Initialized
INFO - 2017-03-13 14:13:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:13:25 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-13 14:13:25 --> Final output sent to browser
DEBUG - 2017-03-13 14:13:25 --> Total execution time: 0.1445
INFO - 2017-03-13 14:20:15 --> Config Class Initialized
INFO - 2017-03-13 14:20:15 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:20:15 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:20:15 --> Utf8 Class Initialized
INFO - 2017-03-13 14:20:15 --> URI Class Initialized
INFO - 2017-03-13 14:20:15 --> Router Class Initialized
INFO - 2017-03-13 14:20:15 --> Output Class Initialized
INFO - 2017-03-13 14:20:15 --> Security Class Initialized
DEBUG - 2017-03-13 14:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:20:15 --> Input Class Initialized
INFO - 2017-03-13 14:20:15 --> Language Class Initialized
INFO - 2017-03-13 14:20:15 --> Loader Class Initialized
INFO - 2017-03-13 14:20:15 --> Helper loaded: url_helper
INFO - 2017-03-13 14:20:15 --> Helper loaded: language_helper
INFO - 2017-03-13 14:20:15 --> Helper loaded: html_helper
INFO - 2017-03-13 14:20:15 --> Helper loaded: form_helper
INFO - 2017-03-13 14:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:20:15 --> Controller Class Initialized
INFO - 2017-03-13 14:20:15 --> Database Driver Class Initialized
INFO - 2017-03-13 14:20:15 --> Model Class Initialized
INFO - 2017-03-13 14:20:15 --> Email Class Initialized
INFO - 2017-03-13 14:20:15 --> Form Validation Class Initialized
INFO - 2017-03-13 14:20:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:20:15 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-03-13 14:20:15 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error:  C:\wamp64\www\savsoftquiz\application\models\Register_model.php 240
ERROR - 2017-03-13 14:20:15 --> Severity: Warning --> imagecreatefromjpeg(): 'upload/data/170300000045/lampiran/170300000045_foto.jpg' is not a valid JPEG file C:\wamp64\www\savsoftquiz\application\models\Register_model.php 240
ERROR - 2017-03-13 14:20:15 --> Severity: Warning --> imagecopyresized() expects parameter 2 to be resource, boolean given C:\wamp64\www\savsoftquiz\application\models\Register_model.php 242
ERROR - 2017-03-13 14:20:15 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error:  C:\wamp64\www\savsoftquiz\application\models\Register_model.php 240
ERROR - 2017-03-13 14:20:15 --> Severity: Warning --> imagecreatefromjpeg(): 'upload/data/170300000045/lampiran/170300000045_ijazah.jpg' is not a valid JPEG file C:\wamp64\www\savsoftquiz\application\models\Register_model.php 240
ERROR - 2017-03-13 14:20:15 --> Severity: Warning --> imagecopyresized() expects parameter 2 to be resource, boolean given C:\wamp64\www\savsoftquiz\application\models\Register_model.php 242
INFO - 2017-03-13 14:20:16 --> Final output sent to browser
DEBUG - 2017-03-13 14:20:16 --> Total execution time: 1.0431
INFO - 2017-03-13 14:31:30 --> Config Class Initialized
INFO - 2017-03-13 14:31:30 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:31:30 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:31:30 --> Utf8 Class Initialized
INFO - 2017-03-13 14:31:30 --> URI Class Initialized
INFO - 2017-03-13 14:31:30 --> Router Class Initialized
INFO - 2017-03-13 14:31:30 --> Output Class Initialized
INFO - 2017-03-13 14:31:30 --> Security Class Initialized
DEBUG - 2017-03-13 14:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:31:30 --> Input Class Initialized
INFO - 2017-03-13 14:31:30 --> Language Class Initialized
INFO - 2017-03-13 14:31:30 --> Loader Class Initialized
INFO - 2017-03-13 14:31:30 --> Helper loaded: url_helper
INFO - 2017-03-13 14:31:30 --> Helper loaded: language_helper
INFO - 2017-03-13 14:31:30 --> Helper loaded: html_helper
INFO - 2017-03-13 14:31:30 --> Helper loaded: form_helper
INFO - 2017-03-13 14:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:31:30 --> Controller Class Initialized
INFO - 2017-03-13 14:31:30 --> Database Driver Class Initialized
INFO - 2017-03-13 14:31:30 --> Model Class Initialized
INFO - 2017-03-13 14:31:30 --> Email Class Initialized
INFO - 2017-03-13 14:31:30 --> Form Validation Class Initialized
INFO - 2017-03-13 14:31:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:31:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 14:31:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-13 14:31:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 14:31:30 --> Final output sent to browser
DEBUG - 2017-03-13 14:31:30 --> Total execution time: 0.1260
INFO - 2017-03-13 14:33:27 --> Config Class Initialized
INFO - 2017-03-13 14:33:27 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:33:27 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:33:27 --> Utf8 Class Initialized
INFO - 2017-03-13 14:33:27 --> URI Class Initialized
INFO - 2017-03-13 14:33:27 --> Router Class Initialized
INFO - 2017-03-13 14:33:27 --> Output Class Initialized
INFO - 2017-03-13 14:33:27 --> Security Class Initialized
DEBUG - 2017-03-13 14:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:33:27 --> Input Class Initialized
INFO - 2017-03-13 14:33:27 --> Language Class Initialized
INFO - 2017-03-13 14:33:27 --> Loader Class Initialized
INFO - 2017-03-13 14:33:27 --> Helper loaded: url_helper
INFO - 2017-03-13 14:33:27 --> Helper loaded: language_helper
INFO - 2017-03-13 14:33:27 --> Helper loaded: html_helper
INFO - 2017-03-13 14:33:27 --> Helper loaded: form_helper
INFO - 2017-03-13 14:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:33:27 --> Controller Class Initialized
INFO - 2017-03-13 14:33:27 --> Database Driver Class Initialized
INFO - 2017-03-13 14:33:27 --> Model Class Initialized
INFO - 2017-03-13 14:33:27 --> Email Class Initialized
INFO - 2017-03-13 14:33:27 --> Form Validation Class Initialized
INFO - 2017-03-13 14:33:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 14:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-13 14:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 14:33:27 --> Final output sent to browser
DEBUG - 2017-03-13 14:33:27 --> Total execution time: 0.1483
INFO - 2017-03-13 14:34:45 --> Config Class Initialized
INFO - 2017-03-13 14:34:45 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:34:45 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:34:45 --> Utf8 Class Initialized
INFO - 2017-03-13 14:34:45 --> URI Class Initialized
INFO - 2017-03-13 14:34:45 --> Router Class Initialized
INFO - 2017-03-13 14:34:45 --> Output Class Initialized
INFO - 2017-03-13 14:34:45 --> Security Class Initialized
DEBUG - 2017-03-13 14:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:34:45 --> Input Class Initialized
INFO - 2017-03-13 14:34:45 --> Language Class Initialized
INFO - 2017-03-13 14:34:45 --> Loader Class Initialized
INFO - 2017-03-13 14:34:45 --> Helper loaded: url_helper
INFO - 2017-03-13 14:34:45 --> Helper loaded: language_helper
INFO - 2017-03-13 14:34:45 --> Helper loaded: html_helper
INFO - 2017-03-13 14:34:45 --> Helper loaded: form_helper
INFO - 2017-03-13 14:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:34:45 --> Controller Class Initialized
INFO - 2017-03-13 14:34:45 --> Database Driver Class Initialized
INFO - 2017-03-13 14:34:45 --> Model Class Initialized
INFO - 2017-03-13 14:34:45 --> Email Class Initialized
INFO - 2017-03-13 14:34:45 --> Form Validation Class Initialized
INFO - 2017-03-13 14:34:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:34:45 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-13 14:34:45 --> Final output sent to browser
DEBUG - 2017-03-13 14:34:45 --> Total execution time: 0.1473
INFO - 2017-03-13 14:34:56 --> Config Class Initialized
INFO - 2017-03-13 14:34:56 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:34:56 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:34:56 --> Utf8 Class Initialized
INFO - 2017-03-13 14:34:56 --> URI Class Initialized
INFO - 2017-03-13 14:34:56 --> Router Class Initialized
INFO - 2017-03-13 14:34:56 --> Output Class Initialized
INFO - 2017-03-13 14:34:56 --> Security Class Initialized
DEBUG - 2017-03-13 14:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:34:56 --> Input Class Initialized
INFO - 2017-03-13 14:34:56 --> Language Class Initialized
INFO - 2017-03-13 14:34:56 --> Loader Class Initialized
INFO - 2017-03-13 14:34:56 --> Helper loaded: url_helper
INFO - 2017-03-13 14:34:56 --> Helper loaded: language_helper
INFO - 2017-03-13 14:34:56 --> Helper loaded: html_helper
INFO - 2017-03-13 14:34:56 --> Helper loaded: form_helper
INFO - 2017-03-13 14:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:34:56 --> Controller Class Initialized
INFO - 2017-03-13 14:34:56 --> Database Driver Class Initialized
INFO - 2017-03-13 14:34:57 --> Model Class Initialized
INFO - 2017-03-13 14:34:57 --> Email Class Initialized
INFO - 2017-03-13 14:34:57 --> Form Validation Class Initialized
INFO - 2017-03-13 14:34:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:34:57 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-13 14:34:58 --> Final output sent to browser
DEBUG - 2017-03-13 14:34:58 --> Total execution time: 1.4631
INFO - 2017-03-13 14:35:00 --> Config Class Initialized
INFO - 2017-03-13 14:35:00 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:35:00 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:35:00 --> Utf8 Class Initialized
INFO - 2017-03-13 14:35:00 --> URI Class Initialized
INFO - 2017-03-13 14:35:00 --> Router Class Initialized
INFO - 2017-03-13 14:35:00 --> Output Class Initialized
INFO - 2017-03-13 14:35:00 --> Security Class Initialized
DEBUG - 2017-03-13 14:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:35:00 --> Input Class Initialized
INFO - 2017-03-13 14:35:00 --> Language Class Initialized
INFO - 2017-03-13 14:35:00 --> Loader Class Initialized
INFO - 2017-03-13 14:35:00 --> Helper loaded: url_helper
INFO - 2017-03-13 14:35:00 --> Helper loaded: language_helper
INFO - 2017-03-13 14:35:00 --> Helper loaded: html_helper
INFO - 2017-03-13 14:35:00 --> Helper loaded: form_helper
INFO - 2017-03-13 14:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:35:00 --> Controller Class Initialized
INFO - 2017-03-13 14:35:00 --> Database Driver Class Initialized
INFO - 2017-03-13 14:35:00 --> Model Class Initialized
INFO - 2017-03-13 14:35:01 --> Email Class Initialized
INFO - 2017-03-13 14:35:01 --> Form Validation Class Initialized
INFO - 2017-03-13 14:35:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:35:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 14:35:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-03-13 14:35:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 14:35:01 --> Final output sent to browser
DEBUG - 2017-03-13 14:35:01 --> Total execution time: 0.1405
INFO - 2017-03-13 14:35:05 --> Config Class Initialized
INFO - 2017-03-13 14:35:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:35:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:35:05 --> Utf8 Class Initialized
INFO - 2017-03-13 14:35:05 --> URI Class Initialized
DEBUG - 2017-03-13 14:35:05 --> No URI present. Default controller set.
INFO - 2017-03-13 14:35:05 --> Router Class Initialized
INFO - 2017-03-13 14:35:05 --> Output Class Initialized
INFO - 2017-03-13 14:35:05 --> Security Class Initialized
DEBUG - 2017-03-13 14:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:35:05 --> Input Class Initialized
INFO - 2017-03-13 14:35:05 --> Language Class Initialized
INFO - 2017-03-13 14:35:05 --> Loader Class Initialized
INFO - 2017-03-13 14:35:05 --> Helper loaded: url_helper
INFO - 2017-03-13 14:35:05 --> Helper loaded: language_helper
INFO - 2017-03-13 14:35:05 --> Helper loaded: html_helper
INFO - 2017-03-13 14:35:05 --> Helper loaded: form_helper
INFO - 2017-03-13 14:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:35:05 --> Controller Class Initialized
INFO - 2017-03-13 14:35:05 --> Database Driver Class Initialized
INFO - 2017-03-13 14:35:05 --> Model Class Initialized
INFO - 2017-03-13 14:35:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:35:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-13 14:35:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-13 14:35:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-13 14:35:05 --> Final output sent to browser
DEBUG - 2017-03-13 14:35:05 --> Total execution time: 0.1664
INFO - 2017-03-13 14:36:29 --> Config Class Initialized
INFO - 2017-03-13 14:36:29 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:36:29 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:36:29 --> Utf8 Class Initialized
INFO - 2017-03-13 14:36:29 --> URI Class Initialized
INFO - 2017-03-13 14:36:29 --> Router Class Initialized
INFO - 2017-03-13 14:36:29 --> Output Class Initialized
INFO - 2017-03-13 14:36:29 --> Security Class Initialized
DEBUG - 2017-03-13 14:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:36:29 --> Input Class Initialized
INFO - 2017-03-13 14:36:29 --> Language Class Initialized
INFO - 2017-03-13 14:36:29 --> Loader Class Initialized
INFO - 2017-03-13 14:36:29 --> Helper loaded: url_helper
INFO - 2017-03-13 14:36:29 --> Helper loaded: language_helper
INFO - 2017-03-13 14:36:30 --> Helper loaded: html_helper
INFO - 2017-03-13 14:36:30 --> Helper loaded: form_helper
INFO - 2017-03-13 14:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:36:30 --> Controller Class Initialized
INFO - 2017-03-13 14:36:30 --> Database Driver Class Initialized
INFO - 2017-03-13 14:36:30 --> Model Class Initialized
INFO - 2017-03-13 14:36:30 --> Email Class Initialized
INFO - 2017-03-13 14:36:30 --> Form Validation Class Initialized
INFO - 2017-03-13 14:36:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:36:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 14:36:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-13 14:36:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 14:36:30 --> Final output sent to browser
DEBUG - 2017-03-13 14:36:30 --> Total execution time: 0.2053
INFO - 2017-03-13 14:37:41 --> Config Class Initialized
INFO - 2017-03-13 14:37:41 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:37:41 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:37:41 --> Utf8 Class Initialized
INFO - 2017-03-13 14:37:41 --> URI Class Initialized
INFO - 2017-03-13 14:37:41 --> Router Class Initialized
INFO - 2017-03-13 14:37:41 --> Output Class Initialized
INFO - 2017-03-13 14:37:41 --> Security Class Initialized
DEBUG - 2017-03-13 14:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:37:41 --> Input Class Initialized
INFO - 2017-03-13 14:37:41 --> Language Class Initialized
INFO - 2017-03-13 14:37:41 --> Loader Class Initialized
INFO - 2017-03-13 14:37:41 --> Helper loaded: url_helper
INFO - 2017-03-13 14:37:41 --> Helper loaded: language_helper
INFO - 2017-03-13 14:37:41 --> Helper loaded: html_helper
INFO - 2017-03-13 14:37:41 --> Helper loaded: form_helper
INFO - 2017-03-13 14:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:37:41 --> Controller Class Initialized
INFO - 2017-03-13 14:37:41 --> Database Driver Class Initialized
INFO - 2017-03-13 14:37:41 --> Model Class Initialized
INFO - 2017-03-13 14:37:41 --> Email Class Initialized
INFO - 2017-03-13 14:37:41 --> Form Validation Class Initialized
INFO - 2017-03-13 14:37:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:37:41 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-03-13 14:37:41 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-13 14:37:41 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-13 14:37:41 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-03-13 14:37:42 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-13 14:37:54 --> Config Class Initialized
INFO - 2017-03-13 14:37:54 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:37:54 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:37:54 --> Utf8 Class Initialized
INFO - 2017-03-13 14:37:54 --> URI Class Initialized
INFO - 2017-03-13 14:37:54 --> Router Class Initialized
INFO - 2017-03-13 14:37:54 --> Output Class Initialized
INFO - 2017-03-13 14:37:54 --> Security Class Initialized
DEBUG - 2017-03-13 14:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:37:54 --> Input Class Initialized
INFO - 2017-03-13 14:37:54 --> Language Class Initialized
INFO - 2017-03-13 14:37:54 --> Loader Class Initialized
INFO - 2017-03-13 14:37:54 --> Helper loaded: url_helper
INFO - 2017-03-13 14:37:54 --> Helper loaded: language_helper
INFO - 2017-03-13 14:37:54 --> Helper loaded: html_helper
INFO - 2017-03-13 14:37:54 --> Helper loaded: form_helper
INFO - 2017-03-13 14:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:37:54 --> Controller Class Initialized
INFO - 2017-03-13 14:37:54 --> Database Driver Class Initialized
INFO - 2017-03-13 14:37:54 --> Model Class Initialized
INFO - 2017-03-13 14:37:54 --> Email Class Initialized
INFO - 2017-03-13 14:37:54 --> Form Validation Class Initialized
INFO - 2017-03-13 14:37:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:37:54 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-13 14:37:56 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-13 14:38:01 --> Final output sent to browser
DEBUG - 2017-03-13 14:38:01 --> Total execution time: 6.2382
INFO - 2017-03-13 14:38:02 --> Config Class Initialized
INFO - 2017-03-13 14:38:02 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:38:02 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:38:02 --> Utf8 Class Initialized
INFO - 2017-03-13 14:38:02 --> URI Class Initialized
INFO - 2017-03-13 14:38:02 --> Router Class Initialized
INFO - 2017-03-13 14:38:02 --> Output Class Initialized
INFO - 2017-03-13 14:38:02 --> Security Class Initialized
DEBUG - 2017-03-13 14:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:38:02 --> Input Class Initialized
INFO - 2017-03-13 14:38:02 --> Language Class Initialized
INFO - 2017-03-13 14:38:02 --> Loader Class Initialized
INFO - 2017-03-13 14:38:02 --> Helper loaded: url_helper
INFO - 2017-03-13 14:38:02 --> Helper loaded: language_helper
INFO - 2017-03-13 14:38:02 --> Helper loaded: html_helper
INFO - 2017-03-13 14:38:02 --> Helper loaded: form_helper
INFO - 2017-03-13 14:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:38:02 --> Controller Class Initialized
INFO - 2017-03-13 14:38:02 --> Database Driver Class Initialized
INFO - 2017-03-13 14:38:02 --> Model Class Initialized
INFO - 2017-03-13 14:38:02 --> Email Class Initialized
INFO - 2017-03-13 14:38:02 --> Form Validation Class Initialized
INFO - 2017-03-13 14:38:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:38:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 14:38:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-03-13 14:38:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 14:38:02 --> Final output sent to browser
DEBUG - 2017-03-13 14:38:02 --> Total execution time: 0.1356
INFO - 2017-03-13 14:38:05 --> Config Class Initialized
INFO - 2017-03-13 14:38:05 --> Hooks Class Initialized
DEBUG - 2017-03-13 14:38:05 --> UTF-8 Support Enabled
INFO - 2017-03-13 14:38:05 --> Utf8 Class Initialized
INFO - 2017-03-13 14:38:05 --> URI Class Initialized
DEBUG - 2017-03-13 14:38:05 --> No URI present. Default controller set.
INFO - 2017-03-13 14:38:05 --> Router Class Initialized
INFO - 2017-03-13 14:38:05 --> Output Class Initialized
INFO - 2017-03-13 14:38:05 --> Security Class Initialized
DEBUG - 2017-03-13 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 14:38:05 --> Input Class Initialized
INFO - 2017-03-13 14:38:05 --> Language Class Initialized
INFO - 2017-03-13 14:38:05 --> Loader Class Initialized
INFO - 2017-03-13 14:38:05 --> Helper loaded: url_helper
INFO - 2017-03-13 14:38:05 --> Helper loaded: language_helper
INFO - 2017-03-13 14:38:05 --> Helper loaded: html_helper
INFO - 2017-03-13 14:38:05 --> Helper loaded: form_helper
INFO - 2017-03-13 14:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 14:38:05 --> Controller Class Initialized
INFO - 2017-03-13 14:38:05 --> Database Driver Class Initialized
INFO - 2017-03-13 14:38:05 --> Model Class Initialized
INFO - 2017-03-13 14:38:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 14:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-13 14:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-13 14:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-13 14:38:05 --> Final output sent to browser
DEBUG - 2017-03-13 14:38:05 --> Total execution time: 0.1116
INFO - 2017-03-13 19:59:53 --> Config Class Initialized
INFO - 2017-03-13 19:59:53 --> Hooks Class Initialized
DEBUG - 2017-03-13 19:59:53 --> UTF-8 Support Enabled
INFO - 2017-03-13 19:59:53 --> Utf8 Class Initialized
INFO - 2017-03-13 19:59:53 --> URI Class Initialized
INFO - 2017-03-13 19:59:53 --> Router Class Initialized
INFO - 2017-03-13 19:59:53 --> Output Class Initialized
INFO - 2017-03-13 19:59:53 --> Security Class Initialized
DEBUG - 2017-03-13 19:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 19:59:53 --> Input Class Initialized
INFO - 2017-03-13 19:59:53 --> Language Class Initialized
INFO - 2017-03-13 19:59:53 --> Loader Class Initialized
INFO - 2017-03-13 19:59:53 --> Helper loaded: url_helper
INFO - 2017-03-13 19:59:53 --> Helper loaded: language_helper
INFO - 2017-03-13 19:59:53 --> Helper loaded: html_helper
INFO - 2017-03-13 19:59:53 --> Helper loaded: form_helper
INFO - 2017-03-13 19:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 19:59:53 --> Controller Class Initialized
INFO - 2017-03-13 19:59:53 --> Database Driver Class Initialized
INFO - 2017-03-13 19:59:53 --> Model Class Initialized
INFO - 2017-03-13 19:59:53 --> Email Class Initialized
INFO - 2017-03-13 19:59:53 --> Form Validation Class Initialized
INFO - 2017-03-13 19:59:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 19:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 19:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-13 19:59:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 19:59:53 --> Final output sent to browser
DEBUG - 2017-03-13 19:59:53 --> Total execution time: 0.1590
INFO - 2017-03-13 20:01:04 --> Config Class Initialized
INFO - 2017-03-13 20:01:04 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:01:04 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:01:04 --> Utf8 Class Initialized
INFO - 2017-03-13 20:01:04 --> URI Class Initialized
INFO - 2017-03-13 20:01:04 --> Router Class Initialized
INFO - 2017-03-13 20:01:04 --> Output Class Initialized
INFO - 2017-03-13 20:01:04 --> Security Class Initialized
DEBUG - 2017-03-13 20:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:01:04 --> Input Class Initialized
INFO - 2017-03-13 20:01:04 --> Language Class Initialized
INFO - 2017-03-13 20:01:04 --> Loader Class Initialized
INFO - 2017-03-13 20:01:04 --> Helper loaded: url_helper
INFO - 2017-03-13 20:01:04 --> Helper loaded: language_helper
INFO - 2017-03-13 20:01:04 --> Helper loaded: html_helper
INFO - 2017-03-13 20:01:04 --> Helper loaded: form_helper
INFO - 2017-03-13 20:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:01:04 --> Controller Class Initialized
INFO - 2017-03-13 20:01:04 --> Database Driver Class Initialized
INFO - 2017-03-13 20:01:04 --> Model Class Initialized
INFO - 2017-03-13 20:01:04 --> Email Class Initialized
INFO - 2017-03-13 20:01:04 --> Form Validation Class Initialized
INFO - 2017-03-13 20:01:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:01:04 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-03-13 20:01:05 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-13 20:01:05 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-03-13 20:01:05 --> Severity: Warning --> fsockopen(): unable to connect to ssl://mail.kemdikbud.go.id:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-03-13 20:01:05 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-13 20:01:16 --> Config Class Initialized
INFO - 2017-03-13 20:01:16 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:01:16 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:01:16 --> Utf8 Class Initialized
INFO - 2017-03-13 20:01:16 --> URI Class Initialized
INFO - 2017-03-13 20:01:16 --> Router Class Initialized
INFO - 2017-03-13 20:01:16 --> Output Class Initialized
INFO - 2017-03-13 20:01:16 --> Security Class Initialized
DEBUG - 2017-03-13 20:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:01:16 --> Input Class Initialized
INFO - 2017-03-13 20:01:16 --> Language Class Initialized
INFO - 2017-03-13 20:01:16 --> Loader Class Initialized
INFO - 2017-03-13 20:01:16 --> Helper loaded: url_helper
INFO - 2017-03-13 20:01:16 --> Helper loaded: language_helper
INFO - 2017-03-13 20:01:16 --> Helper loaded: html_helper
INFO - 2017-03-13 20:01:16 --> Helper loaded: form_helper
INFO - 2017-03-13 20:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:01:16 --> Controller Class Initialized
INFO - 2017-03-13 20:01:16 --> Database Driver Class Initialized
INFO - 2017-03-13 20:01:16 --> Model Class Initialized
INFO - 2017-03-13 20:01:16 --> Email Class Initialized
INFO - 2017-03-13 20:01:16 --> Form Validation Class Initialized
INFO - 2017-03-13 20:01:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:01:16 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-13 20:01:17 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-13 20:01:55 --> Config Class Initialized
INFO - 2017-03-13 20:01:55 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:01:55 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:01:55 --> Utf8 Class Initialized
INFO - 2017-03-13 20:01:55 --> URI Class Initialized
INFO - 2017-03-13 20:01:55 --> Router Class Initialized
INFO - 2017-03-13 20:01:55 --> Output Class Initialized
INFO - 2017-03-13 20:01:55 --> Security Class Initialized
DEBUG - 2017-03-13 20:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:01:55 --> Input Class Initialized
INFO - 2017-03-13 20:01:55 --> Language Class Initialized
INFO - 2017-03-13 20:01:55 --> Loader Class Initialized
INFO - 2017-03-13 20:01:55 --> Helper loaded: url_helper
INFO - 2017-03-13 20:01:55 --> Helper loaded: language_helper
INFO - 2017-03-13 20:01:55 --> Helper loaded: html_helper
INFO - 2017-03-13 20:01:55 --> Helper loaded: form_helper
INFO - 2017-03-13 20:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:01:55 --> Controller Class Initialized
INFO - 2017-03-13 20:01:55 --> Database Driver Class Initialized
INFO - 2017-03-13 20:01:55 --> Model Class Initialized
INFO - 2017-03-13 20:01:55 --> Email Class Initialized
INFO - 2017-03-13 20:01:55 --> Form Validation Class Initialized
INFO - 2017-03-13 20:01:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:01:55 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-03-13 20:01:55 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-03-13 20:01:56 --> Final output sent to browser
DEBUG - 2017-03-13 20:01:56 --> Total execution time: 1.6817
INFO - 2017-03-13 20:01:58 --> Config Class Initialized
INFO - 2017-03-13 20:01:58 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:01:58 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:01:58 --> Utf8 Class Initialized
INFO - 2017-03-13 20:01:58 --> URI Class Initialized
INFO - 2017-03-13 20:01:58 --> Router Class Initialized
INFO - 2017-03-13 20:01:58 --> Output Class Initialized
INFO - 2017-03-13 20:01:58 --> Security Class Initialized
DEBUG - 2017-03-13 20:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:01:58 --> Input Class Initialized
INFO - 2017-03-13 20:01:58 --> Language Class Initialized
INFO - 2017-03-13 20:01:58 --> Loader Class Initialized
INFO - 2017-03-13 20:01:58 --> Helper loaded: url_helper
INFO - 2017-03-13 20:01:58 --> Helper loaded: language_helper
INFO - 2017-03-13 20:01:58 --> Helper loaded: html_helper
INFO - 2017-03-13 20:01:58 --> Helper loaded: form_helper
INFO - 2017-03-13 20:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:01:58 --> Controller Class Initialized
INFO - 2017-03-13 20:01:58 --> Database Driver Class Initialized
INFO - 2017-03-13 20:01:58 --> Model Class Initialized
INFO - 2017-03-13 20:01:58 --> Email Class Initialized
INFO - 2017-03-13 20:01:58 --> Form Validation Class Initialized
INFO - 2017-03-13 20:01:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 20:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-03-13 20:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 20:01:58 --> Final output sent to browser
DEBUG - 2017-03-13 20:01:58 --> Total execution time: 0.1415
INFO - 2017-03-13 20:02:26 --> Config Class Initialized
INFO - 2017-03-13 20:02:26 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:02:26 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:02:26 --> Utf8 Class Initialized
INFO - 2017-03-13 20:02:26 --> URI Class Initialized
DEBUG - 2017-03-13 20:02:26 --> No URI present. Default controller set.
INFO - 2017-03-13 20:02:26 --> Router Class Initialized
INFO - 2017-03-13 20:02:26 --> Output Class Initialized
INFO - 2017-03-13 20:02:26 --> Security Class Initialized
DEBUG - 2017-03-13 20:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:02:26 --> Input Class Initialized
INFO - 2017-03-13 20:02:26 --> Language Class Initialized
INFO - 2017-03-13 20:02:26 --> Loader Class Initialized
INFO - 2017-03-13 20:02:26 --> Helper loaded: url_helper
INFO - 2017-03-13 20:02:26 --> Helper loaded: language_helper
INFO - 2017-03-13 20:02:26 --> Helper loaded: html_helper
INFO - 2017-03-13 20:02:26 --> Helper loaded: form_helper
INFO - 2017-03-13 20:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:02:26 --> Controller Class Initialized
INFO - 2017-03-13 20:02:26 --> Database Driver Class Initialized
INFO - 2017-03-13 20:02:26 --> Model Class Initialized
INFO - 2017-03-13 20:02:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:02:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-13 20:02:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-13 20:02:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-13 20:02:26 --> Final output sent to browser
DEBUG - 2017-03-13 20:02:26 --> Total execution time: 0.0936
INFO - 2017-03-13 20:02:31 --> Config Class Initialized
INFO - 2017-03-13 20:02:31 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:02:31 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:02:31 --> Utf8 Class Initialized
INFO - 2017-03-13 20:02:31 --> URI Class Initialized
INFO - 2017-03-13 20:02:31 --> Router Class Initialized
INFO - 2017-03-13 20:02:31 --> Output Class Initialized
INFO - 2017-03-13 20:02:31 --> Security Class Initialized
DEBUG - 2017-03-13 20:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:02:31 --> Input Class Initialized
INFO - 2017-03-13 20:02:31 --> Language Class Initialized
INFO - 2017-03-13 20:02:31 --> Loader Class Initialized
INFO - 2017-03-13 20:02:31 --> Helper loaded: url_helper
INFO - 2017-03-13 20:02:31 --> Helper loaded: language_helper
INFO - 2017-03-13 20:02:31 --> Helper loaded: html_helper
INFO - 2017-03-13 20:02:31 --> Helper loaded: form_helper
INFO - 2017-03-13 20:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:02:31 --> Controller Class Initialized
INFO - 2017-03-13 20:02:31 --> Database Driver Class Initialized
INFO - 2017-03-13 20:02:31 --> Model Class Initialized
INFO - 2017-03-13 20:02:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:02:31 --> Config Class Initialized
INFO - 2017-03-13 20:02:31 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:02:31 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:02:31 --> Utf8 Class Initialized
INFO - 2017-03-13 20:02:31 --> URI Class Initialized
INFO - 2017-03-13 20:02:31 --> Router Class Initialized
INFO - 2017-03-13 20:02:31 --> Output Class Initialized
INFO - 2017-03-13 20:02:31 --> Security Class Initialized
DEBUG - 2017-03-13 20:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:02:31 --> Input Class Initialized
INFO - 2017-03-13 20:02:31 --> Language Class Initialized
INFO - 2017-03-13 20:02:31 --> Loader Class Initialized
INFO - 2017-03-13 20:02:31 --> Helper loaded: url_helper
INFO - 2017-03-13 20:02:31 --> Helper loaded: language_helper
INFO - 2017-03-13 20:02:31 --> Helper loaded: html_helper
INFO - 2017-03-13 20:02:31 --> Helper loaded: form_helper
INFO - 2017-03-13 20:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:02:31 --> Controller Class Initialized
INFO - 2017-03-13 20:02:31 --> Database Driver Class Initialized
INFO - 2017-03-13 20:02:31 --> Model Class Initialized
INFO - 2017-03-13 20:02:31 --> Model Class Initialized
INFO - 2017-03-13 20:02:31 --> Model Class Initialized
INFO - 2017-03-13 20:02:31 --> Model Class Initialized
INFO - 2017-03-13 20:02:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:02:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 20:02:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-03-13 20:02:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 20:02:31 --> Final output sent to browser
DEBUG - 2017-03-13 20:02:31 --> Total execution time: 0.1803
INFO - 2017-03-13 20:02:33 --> Config Class Initialized
INFO - 2017-03-13 20:02:33 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:02:33 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:02:33 --> Utf8 Class Initialized
INFO - 2017-03-13 20:02:33 --> URI Class Initialized
INFO - 2017-03-13 20:02:33 --> Router Class Initialized
INFO - 2017-03-13 20:02:33 --> Output Class Initialized
INFO - 2017-03-13 20:02:33 --> Security Class Initialized
DEBUG - 2017-03-13 20:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:02:33 --> Input Class Initialized
INFO - 2017-03-13 20:02:33 --> Language Class Initialized
INFO - 2017-03-13 20:02:33 --> Loader Class Initialized
INFO - 2017-03-13 20:02:33 --> Helper loaded: url_helper
INFO - 2017-03-13 20:02:33 --> Helper loaded: language_helper
INFO - 2017-03-13 20:02:33 --> Helper loaded: html_helper
INFO - 2017-03-13 20:02:33 --> Helper loaded: form_helper
INFO - 2017-03-13 20:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:02:33 --> Controller Class Initialized
INFO - 2017-03-13 20:02:33 --> Database Driver Class Initialized
INFO - 2017-03-13 20:02:33 --> Model Class Initialized
INFO - 2017-03-13 20:02:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:02:33 --> Zip Compression Class Initialized
INFO - 2017-03-13 20:02:33 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-13 20:02:33 --> Pagination Class Initialized
INFO - 2017-03-13 20:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 20:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-13 20:02:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 20:02:33 --> Final output sent to browser
DEBUG - 2017-03-13 20:02:33 --> Total execution time: 0.1636
INFO - 2017-03-13 20:02:39 --> Config Class Initialized
INFO - 2017-03-13 20:02:39 --> Hooks Class Initialized
DEBUG - 2017-03-13 20:02:39 --> UTF-8 Support Enabled
INFO - 2017-03-13 20:02:39 --> Utf8 Class Initialized
INFO - 2017-03-13 20:02:39 --> URI Class Initialized
INFO - 2017-03-13 20:02:39 --> Router Class Initialized
INFO - 2017-03-13 20:02:39 --> Output Class Initialized
INFO - 2017-03-13 20:02:39 --> Security Class Initialized
DEBUG - 2017-03-13 20:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-13 20:02:39 --> Input Class Initialized
INFO - 2017-03-13 20:02:39 --> Language Class Initialized
INFO - 2017-03-13 20:02:39 --> Loader Class Initialized
INFO - 2017-03-13 20:02:39 --> Helper loaded: url_helper
INFO - 2017-03-13 20:02:39 --> Helper loaded: language_helper
INFO - 2017-03-13 20:02:39 --> Helper loaded: html_helper
INFO - 2017-03-13 20:02:39 --> Helper loaded: form_helper
INFO - 2017-03-13 20:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-13 20:02:39 --> Controller Class Initialized
INFO - 2017-03-13 20:02:39 --> Database Driver Class Initialized
INFO - 2017-03-13 20:02:39 --> Model Class Initialized
INFO - 2017-03-13 20:02:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-13 20:02:39 --> Zip Compression Class Initialized
INFO - 2017-03-13 20:02:39 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-03-13 20:02:39 --> Pagination Class Initialized
INFO - 2017-03-13 20:02:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-13 20:02:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-03-13 20:02:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-13 20:02:39 --> Final output sent to browser
DEBUG - 2017-03-13 20:02:39 --> Total execution time: 0.1096
