<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-31 16:08:37 --> Config Class Initialized
INFO - 2017-03-31 16:08:37 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:08:37 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:08:37 --> Utf8 Class Initialized
INFO - 2017-03-31 16:08:37 --> URI Class Initialized
DEBUG - 2017-03-31 16:08:37 --> No URI present. Default controller set.
INFO - 2017-03-31 16:08:37 --> Router Class Initialized
INFO - 2017-03-31 16:08:37 --> Output Class Initialized
INFO - 2017-03-31 16:08:37 --> Security Class Initialized
DEBUG - 2017-03-31 16:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:08:37 --> Input Class Initialized
INFO - 2017-03-31 16:08:37 --> Language Class Initialized
INFO - 2017-03-31 16:08:37 --> Loader Class Initialized
INFO - 2017-03-31 16:08:37 --> Helper loaded: url_helper
INFO - 2017-03-31 16:08:37 --> Helper loaded: language_helper
INFO - 2017-03-31 16:08:37 --> Helper loaded: html_helper
INFO - 2017-03-31 16:08:37 --> Helper loaded: form_helper
INFO - 2017-03-31 16:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:08:37 --> Controller Class Initialized
INFO - 2017-03-31 16:08:37 --> Database Driver Class Initialized
INFO - 2017-03-31 16:08:37 --> Model Class Initialized
INFO - 2017-03-31 16:08:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:08:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-03-31 16:08:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-03-31 16:08:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-03-31 16:08:37 --> Final output sent to browser
DEBUG - 2017-03-31 16:08:37 --> Total execution time: 0.1149
INFO - 2017-03-31 16:08:37 --> Config Class Initialized
INFO - 2017-03-31 16:08:37 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:08:37 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:08:37 --> Utf8 Class Initialized
INFO - 2017-03-31 16:08:37 --> URI Class Initialized
INFO - 2017-03-31 16:08:37 --> Router Class Initialized
INFO - 2017-03-31 16:08:37 --> Output Class Initialized
INFO - 2017-03-31 16:08:37 --> Security Class Initialized
DEBUG - 2017-03-31 16:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:08:37 --> Input Class Initialized
INFO - 2017-03-31 16:08:37 --> Language Class Initialized
ERROR - 2017-03-31 16:08:37 --> 404 Page Not Found: Faviconico/index
INFO - 2017-03-31 16:08:40 --> Config Class Initialized
INFO - 2017-03-31 16:08:40 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:08:40 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:08:40 --> Utf8 Class Initialized
INFO - 2017-03-31 16:08:40 --> URI Class Initialized
INFO - 2017-03-31 16:08:40 --> Router Class Initialized
INFO - 2017-03-31 16:08:40 --> Output Class Initialized
INFO - 2017-03-31 16:08:40 --> Security Class Initialized
DEBUG - 2017-03-31 16:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:08:40 --> Input Class Initialized
INFO - 2017-03-31 16:08:40 --> Language Class Initialized
INFO - 2017-03-31 16:08:40 --> Loader Class Initialized
INFO - 2017-03-31 16:08:40 --> Helper loaded: url_helper
INFO - 2017-03-31 16:08:40 --> Helper loaded: language_helper
INFO - 2017-03-31 16:08:40 --> Helper loaded: html_helper
INFO - 2017-03-31 16:08:40 --> Helper loaded: form_helper
INFO - 2017-03-31 16:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:08:40 --> Controller Class Initialized
INFO - 2017-03-31 16:08:40 --> Database Driver Class Initialized
INFO - 2017-03-31 16:08:40 --> Model Class Initialized
INFO - 2017-03-31 16:08:40 --> Email Class Initialized
INFO - 2017-03-31 16:08:40 --> Form Validation Class Initialized
INFO - 2017-03-31 16:08:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:08:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-31 16:08:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-31 16:08:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-31 16:08:40 --> Final output sent to browser
DEBUG - 2017-03-31 16:08:40 --> Total execution time: 0.0966
INFO - 2017-03-31 16:12:53 --> Config Class Initialized
INFO - 2017-03-31 16:12:53 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:12:53 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:12:53 --> Utf8 Class Initialized
INFO - 2017-03-31 16:12:53 --> URI Class Initialized
INFO - 2017-03-31 16:12:53 --> Router Class Initialized
INFO - 2017-03-31 16:12:53 --> Output Class Initialized
INFO - 2017-03-31 16:12:53 --> Security Class Initialized
DEBUG - 2017-03-31 16:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:12:53 --> Input Class Initialized
INFO - 2017-03-31 16:12:53 --> Language Class Initialized
INFO - 2017-03-31 16:12:53 --> Loader Class Initialized
INFO - 2017-03-31 16:12:53 --> Helper loaded: url_helper
INFO - 2017-03-31 16:12:53 --> Helper loaded: language_helper
INFO - 2017-03-31 16:12:53 --> Helper loaded: html_helper
INFO - 2017-03-31 16:12:53 --> Helper loaded: form_helper
INFO - 2017-03-31 16:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:12:53 --> Controller Class Initialized
INFO - 2017-03-31 16:12:53 --> Database Driver Class Initialized
INFO - 2017-03-31 16:12:53 --> Model Class Initialized
INFO - 2017-03-31 16:12:53 --> Email Class Initialized
INFO - 2017-03-31 16:12:53 --> Form Validation Class Initialized
INFO - 2017-03-31 16:12:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:12:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-03-31 16:12:53 --> Could not find the language line "alamat"
INFO - 2017-03-31 16:12:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-31 16:12:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-31 16:12:53 --> Final output sent to browser
DEBUG - 2017-03-31 16:12:53 --> Total execution time: 0.0936
INFO - 2017-03-31 16:13:11 --> Config Class Initialized
INFO - 2017-03-31 16:13:11 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:13:11 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:13:11 --> Utf8 Class Initialized
INFO - 2017-03-31 16:13:11 --> URI Class Initialized
INFO - 2017-03-31 16:13:11 --> Router Class Initialized
INFO - 2017-03-31 16:13:11 --> Output Class Initialized
INFO - 2017-03-31 16:13:11 --> Security Class Initialized
DEBUG - 2017-03-31 16:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:13:11 --> Input Class Initialized
INFO - 2017-03-31 16:13:11 --> Language Class Initialized
INFO - 2017-03-31 16:13:11 --> Loader Class Initialized
INFO - 2017-03-31 16:13:11 --> Helper loaded: url_helper
INFO - 2017-03-31 16:13:11 --> Helper loaded: language_helper
INFO - 2017-03-31 16:13:11 --> Helper loaded: html_helper
INFO - 2017-03-31 16:13:11 --> Helper loaded: form_helper
INFO - 2017-03-31 16:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:13:11 --> Controller Class Initialized
INFO - 2017-03-31 16:13:11 --> Database Driver Class Initialized
INFO - 2017-03-31 16:13:11 --> Model Class Initialized
INFO - 2017-03-31 16:13:11 --> Email Class Initialized
INFO - 2017-03-31 16:13:11 --> Form Validation Class Initialized
INFO - 2017-03-31 16:13:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:13:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-03-31 16:13:11 --> Could not find the language line "alamat"
INFO - 2017-03-31 16:13:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-31 16:13:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-31 16:13:11 --> Final output sent to browser
DEBUG - 2017-03-31 16:13:11 --> Total execution time: 0.0828
INFO - 2017-03-31 16:16:39 --> Config Class Initialized
INFO - 2017-03-31 16:16:39 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:16:39 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:16:39 --> Utf8 Class Initialized
INFO - 2017-03-31 16:16:39 --> URI Class Initialized
INFO - 2017-03-31 16:16:39 --> Router Class Initialized
INFO - 2017-03-31 16:16:39 --> Output Class Initialized
INFO - 2017-03-31 16:16:39 --> Security Class Initialized
DEBUG - 2017-03-31 16:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:16:39 --> Input Class Initialized
INFO - 2017-03-31 16:16:39 --> Language Class Initialized
INFO - 2017-03-31 16:16:39 --> Loader Class Initialized
INFO - 2017-03-31 16:16:39 --> Helper loaded: url_helper
INFO - 2017-03-31 16:16:39 --> Helper loaded: language_helper
INFO - 2017-03-31 16:16:39 --> Helper loaded: html_helper
INFO - 2017-03-31 16:16:39 --> Helper loaded: form_helper
INFO - 2017-03-31 16:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:16:39 --> Controller Class Initialized
INFO - 2017-03-31 16:16:39 --> Database Driver Class Initialized
INFO - 2017-03-31 16:16:39 --> Model Class Initialized
INFO - 2017-03-31 16:16:39 --> Email Class Initialized
INFO - 2017-03-31 16:16:39 --> Form Validation Class Initialized
INFO - 2017-03-31 16:16:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-31 16:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-31 16:16:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-31 16:16:39 --> Final output sent to browser
DEBUG - 2017-03-31 16:16:39 --> Total execution time: 0.1400
INFO - 2017-03-31 16:18:54 --> Config Class Initialized
INFO - 2017-03-31 16:18:54 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:18:54 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:18:54 --> Utf8 Class Initialized
INFO - 2017-03-31 16:18:54 --> URI Class Initialized
INFO - 2017-03-31 16:18:54 --> Router Class Initialized
INFO - 2017-03-31 16:18:54 --> Output Class Initialized
INFO - 2017-03-31 16:18:54 --> Security Class Initialized
DEBUG - 2017-03-31 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:18:54 --> Input Class Initialized
INFO - 2017-03-31 16:18:54 --> Language Class Initialized
INFO - 2017-03-31 16:18:54 --> Loader Class Initialized
INFO - 2017-03-31 16:18:54 --> Helper loaded: url_helper
INFO - 2017-03-31 16:18:54 --> Helper loaded: language_helper
INFO - 2017-03-31 16:18:54 --> Helper loaded: html_helper
INFO - 2017-03-31 16:18:54 --> Helper loaded: form_helper
INFO - 2017-03-31 16:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:18:54 --> Controller Class Initialized
INFO - 2017-03-31 16:18:54 --> Database Driver Class Initialized
INFO - 2017-03-31 16:18:54 --> Model Class Initialized
INFO - 2017-03-31 16:18:54 --> Email Class Initialized
INFO - 2017-03-31 16:18:54 --> Form Validation Class Initialized
INFO - 2017-03-31 16:18:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-31 16:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-31 16:18:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-31 16:18:54 --> Final output sent to browser
DEBUG - 2017-03-31 16:18:54 --> Total execution time: 0.1082
INFO - 2017-03-31 16:20:25 --> Config Class Initialized
INFO - 2017-03-31 16:20:25 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:20:25 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:20:25 --> Utf8 Class Initialized
INFO - 2017-03-31 16:20:25 --> URI Class Initialized
INFO - 2017-03-31 16:20:25 --> Router Class Initialized
INFO - 2017-03-31 16:20:26 --> Output Class Initialized
INFO - 2017-03-31 16:20:26 --> Security Class Initialized
DEBUG - 2017-03-31 16:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:20:26 --> Input Class Initialized
INFO - 2017-03-31 16:20:26 --> Language Class Initialized
INFO - 2017-03-31 16:20:26 --> Loader Class Initialized
INFO - 2017-03-31 16:20:26 --> Helper loaded: url_helper
INFO - 2017-03-31 16:20:26 --> Helper loaded: language_helper
INFO - 2017-03-31 16:20:26 --> Helper loaded: html_helper
INFO - 2017-03-31 16:20:26 --> Helper loaded: form_helper
INFO - 2017-03-31 16:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:20:26 --> Controller Class Initialized
INFO - 2017-03-31 16:20:26 --> Database Driver Class Initialized
INFO - 2017-03-31 16:20:26 --> Model Class Initialized
INFO - 2017-03-31 16:20:26 --> Email Class Initialized
INFO - 2017-03-31 16:20:26 --> Form Validation Class Initialized
INFO - 2017-03-31 16:20:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:20:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-31 16:20:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-31 16:20:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-31 16:20:26 --> Final output sent to browser
DEBUG - 2017-03-31 16:20:26 --> Total execution time: 0.0975
INFO - 2017-03-31 16:25:40 --> Config Class Initialized
INFO - 2017-03-31 16:25:40 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:25:40 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:25:40 --> Utf8 Class Initialized
INFO - 2017-03-31 16:25:40 --> URI Class Initialized
INFO - 2017-03-31 16:25:40 --> Router Class Initialized
INFO - 2017-03-31 16:25:40 --> Output Class Initialized
INFO - 2017-03-31 16:25:40 --> Security Class Initialized
DEBUG - 2017-03-31 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:25:40 --> Input Class Initialized
INFO - 2017-03-31 16:25:40 --> Language Class Initialized
INFO - 2017-03-31 16:25:40 --> Loader Class Initialized
INFO - 2017-03-31 16:25:40 --> Helper loaded: url_helper
INFO - 2017-03-31 16:25:40 --> Helper loaded: language_helper
INFO - 2017-03-31 16:25:40 --> Helper loaded: html_helper
INFO - 2017-03-31 16:25:40 --> Helper loaded: form_helper
INFO - 2017-03-31 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:25:40 --> Controller Class Initialized
INFO - 2017-03-31 16:25:40 --> Database Driver Class Initialized
INFO - 2017-03-31 16:25:40 --> Model Class Initialized
INFO - 2017-03-31 16:25:40 --> Email Class Initialized
INFO - 2017-03-31 16:25:40 --> Form Validation Class Initialized
INFO - 2017-03-31 16:25:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:25:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-31 16:25:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-31 16:25:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-31 16:25:40 --> Final output sent to browser
DEBUG - 2017-03-31 16:25:40 --> Total execution time: 0.0858
INFO - 2017-03-31 16:52:06 --> Config Class Initialized
INFO - 2017-03-31 16:52:06 --> Hooks Class Initialized
DEBUG - 2017-03-31 16:52:06 --> UTF-8 Support Enabled
INFO - 2017-03-31 16:52:06 --> Utf8 Class Initialized
INFO - 2017-03-31 16:52:06 --> URI Class Initialized
INFO - 2017-03-31 16:52:06 --> Router Class Initialized
INFO - 2017-03-31 16:52:06 --> Output Class Initialized
INFO - 2017-03-31 16:52:06 --> Security Class Initialized
DEBUG - 2017-03-31 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-31 16:52:06 --> Input Class Initialized
INFO - 2017-03-31 16:52:06 --> Language Class Initialized
INFO - 2017-03-31 16:52:06 --> Loader Class Initialized
INFO - 2017-03-31 16:52:06 --> Helper loaded: url_helper
INFO - 2017-03-31 16:52:06 --> Helper loaded: language_helper
INFO - 2017-03-31 16:52:06 --> Helper loaded: html_helper
INFO - 2017-03-31 16:52:06 --> Helper loaded: form_helper
INFO - 2017-03-31 16:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-31 16:52:06 --> Controller Class Initialized
INFO - 2017-03-31 16:52:06 --> Database Driver Class Initialized
INFO - 2017-03-31 16:52:06 --> Model Class Initialized
INFO - 2017-03-31 16:52:06 --> Email Class Initialized
INFO - 2017-03-31 16:52:06 --> Form Validation Class Initialized
INFO - 2017-03-31 16:52:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-03-31 16:52:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-03-31 16:52:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-03-31 16:52:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-03-31 16:52:06 --> Final output sent to browser
DEBUG - 2017-03-31 16:52:06 --> Total execution time: 0.0860
