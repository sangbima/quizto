<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-04 09:38:38 --> Config Class Initialized
INFO - 2017-04-04 09:38:38 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:38:38 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:38:38 --> Utf8 Class Initialized
INFO - 2017-04-04 09:38:38 --> URI Class Initialized
DEBUG - 2017-04-04 09:38:38 --> No URI present. Default controller set.
INFO - 2017-04-04 09:38:38 --> Router Class Initialized
INFO - 2017-04-04 09:38:38 --> Output Class Initialized
INFO - 2017-04-04 09:38:38 --> Security Class Initialized
DEBUG - 2017-04-04 09:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:38:38 --> Input Class Initialized
INFO - 2017-04-04 09:38:38 --> Language Class Initialized
INFO - 2017-04-04 09:38:38 --> Loader Class Initialized
INFO - 2017-04-04 09:38:38 --> Helper loaded: url_helper
INFO - 2017-04-04 09:38:38 --> Helper loaded: language_helper
INFO - 2017-04-04 09:38:38 --> Helper loaded: html_helper
INFO - 2017-04-04 09:38:38 --> Helper loaded: form_helper
INFO - 2017-04-04 09:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:38:38 --> Controller Class Initialized
INFO - 2017-04-04 09:38:38 --> Database Driver Class Initialized
INFO - 2017-04-04 09:38:38 --> Model Class Initialized
INFO - 2017-04-04 09:38:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:38:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-04 09:38:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-04 09:38:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-04 09:38:38 --> Final output sent to browser
DEBUG - 2017-04-04 09:38:38 --> Total execution time: 0.1396
INFO - 2017-04-04 09:38:39 --> Config Class Initialized
INFO - 2017-04-04 09:38:39 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:38:39 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:38:39 --> Utf8 Class Initialized
INFO - 2017-04-04 09:38:39 --> URI Class Initialized
INFO - 2017-04-04 09:38:39 --> Router Class Initialized
INFO - 2017-04-04 09:38:39 --> Output Class Initialized
INFO - 2017-04-04 09:38:39 --> Security Class Initialized
DEBUG - 2017-04-04 09:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:38:39 --> Input Class Initialized
INFO - 2017-04-04 09:38:39 --> Language Class Initialized
ERROR - 2017-04-04 09:38:39 --> 404 Page Not Found: Faviconico/index
INFO - 2017-04-04 09:38:44 --> Config Class Initialized
INFO - 2017-04-04 09:38:44 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:38:44 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:38:44 --> Utf8 Class Initialized
INFO - 2017-04-04 09:38:44 --> URI Class Initialized
INFO - 2017-04-04 09:38:44 --> Router Class Initialized
INFO - 2017-04-04 09:38:44 --> Output Class Initialized
INFO - 2017-04-04 09:38:44 --> Security Class Initialized
DEBUG - 2017-04-04 09:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:38:44 --> Input Class Initialized
INFO - 2017-04-04 09:38:44 --> Language Class Initialized
INFO - 2017-04-04 09:38:44 --> Loader Class Initialized
INFO - 2017-04-04 09:38:44 --> Helper loaded: url_helper
INFO - 2017-04-04 09:38:44 --> Helper loaded: language_helper
INFO - 2017-04-04 09:38:44 --> Helper loaded: html_helper
INFO - 2017-04-04 09:38:44 --> Helper loaded: form_helper
INFO - 2017-04-04 09:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:38:44 --> Controller Class Initialized
INFO - 2017-04-04 09:38:44 --> Database Driver Class Initialized
INFO - 2017-04-04 09:38:44 --> Model Class Initialized
INFO - 2017-04-04 09:38:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:38:44 --> Config Class Initialized
INFO - 2017-04-04 09:38:44 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:38:44 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:38:44 --> Utf8 Class Initialized
INFO - 2017-04-04 09:38:44 --> URI Class Initialized
INFO - 2017-04-04 09:38:44 --> Router Class Initialized
INFO - 2017-04-04 09:38:44 --> Output Class Initialized
INFO - 2017-04-04 09:38:44 --> Security Class Initialized
DEBUG - 2017-04-04 09:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:38:44 --> Input Class Initialized
INFO - 2017-04-04 09:38:44 --> Language Class Initialized
INFO - 2017-04-04 09:38:44 --> Loader Class Initialized
INFO - 2017-04-04 09:38:44 --> Helper loaded: url_helper
INFO - 2017-04-04 09:38:44 --> Helper loaded: language_helper
INFO - 2017-04-04 09:38:44 --> Helper loaded: html_helper
INFO - 2017-04-04 09:38:44 --> Helper loaded: form_helper
INFO - 2017-04-04 09:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:38:44 --> Controller Class Initialized
INFO - 2017-04-04 09:38:44 --> Database Driver Class Initialized
INFO - 2017-04-04 09:38:44 --> Model Class Initialized
INFO - 2017-04-04 09:38:44 --> Model Class Initialized
INFO - 2017-04-04 09:38:44 --> Model Class Initialized
INFO - 2017-04-04 09:38:44 --> Model Class Initialized
INFO - 2017-04-04 09:38:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:38:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:38:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-04-04 09:38:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:38:44 --> Final output sent to browser
DEBUG - 2017-04-04 09:38:44 --> Total execution time: 0.1405
INFO - 2017-04-04 09:38:49 --> Config Class Initialized
INFO - 2017-04-04 09:38:49 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:38:49 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:38:49 --> Utf8 Class Initialized
INFO - 2017-04-04 09:38:49 --> URI Class Initialized
INFO - 2017-04-04 09:38:49 --> Router Class Initialized
INFO - 2017-04-04 09:38:49 --> Output Class Initialized
INFO - 2017-04-04 09:38:49 --> Security Class Initialized
DEBUG - 2017-04-04 09:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:38:49 --> Input Class Initialized
INFO - 2017-04-04 09:38:49 --> Language Class Initialized
INFO - 2017-04-04 09:38:49 --> Loader Class Initialized
INFO - 2017-04-04 09:38:49 --> Helper loaded: url_helper
INFO - 2017-04-04 09:38:49 --> Helper loaded: language_helper
INFO - 2017-04-04 09:38:49 --> Helper loaded: html_helper
INFO - 2017-04-04 09:38:49 --> Helper loaded: form_helper
INFO - 2017-04-04 09:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:38:49 --> Controller Class Initialized
INFO - 2017-04-04 09:38:49 --> Database Driver Class Initialized
INFO - 2017-04-04 09:38:49 --> Model Class Initialized
INFO - 2017-04-04 09:38:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:38:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:38:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:38:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:38:49 --> Final output sent to browser
DEBUG - 2017-04-04 09:38:49 --> Total execution time: 0.1069
INFO - 2017-04-04 09:39:08 --> Config Class Initialized
INFO - 2017-04-04 09:39:08 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:39:08 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:39:08 --> Utf8 Class Initialized
INFO - 2017-04-04 09:39:08 --> URI Class Initialized
INFO - 2017-04-04 09:39:08 --> Router Class Initialized
INFO - 2017-04-04 09:39:08 --> Output Class Initialized
INFO - 2017-04-04 09:39:08 --> Security Class Initialized
DEBUG - 2017-04-04 09:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:39:08 --> Input Class Initialized
INFO - 2017-04-04 09:39:08 --> Language Class Initialized
INFO - 2017-04-04 09:39:08 --> Loader Class Initialized
INFO - 2017-04-04 09:39:08 --> Helper loaded: url_helper
INFO - 2017-04-04 09:39:08 --> Helper loaded: language_helper
INFO - 2017-04-04 09:39:08 --> Helper loaded: html_helper
INFO - 2017-04-04 09:39:08 --> Helper loaded: form_helper
INFO - 2017-04-04 09:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:39:08 --> Controller Class Initialized
INFO - 2017-04-04 09:39:08 --> Database Driver Class Initialized
INFO - 2017-04-04 09:39:08 --> Model Class Initialized
INFO - 2017-04-04 09:39:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:39:08 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-04-04 09:39:08 --> Helper loaded: xlsimport/spreadsheetreader_helper
INFO - 2017-04-04 09:39:10 --> Config Class Initialized
INFO - 2017-04-04 09:39:10 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:39:10 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:39:10 --> Utf8 Class Initialized
INFO - 2017-04-04 09:39:10 --> URI Class Initialized
INFO - 2017-04-04 09:39:10 --> Router Class Initialized
INFO - 2017-04-04 09:39:10 --> Output Class Initialized
INFO - 2017-04-04 09:39:10 --> Security Class Initialized
DEBUG - 2017-04-04 09:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:39:10 --> Input Class Initialized
INFO - 2017-04-04 09:39:10 --> Language Class Initialized
INFO - 2017-04-04 09:39:10 --> Loader Class Initialized
INFO - 2017-04-04 09:39:10 --> Helper loaded: url_helper
INFO - 2017-04-04 09:39:10 --> Helper loaded: language_helper
INFO - 2017-04-04 09:39:10 --> Helper loaded: html_helper
INFO - 2017-04-04 09:39:10 --> Helper loaded: form_helper
INFO - 2017-04-04 09:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:39:10 --> Controller Class Initialized
INFO - 2017-04-04 09:39:10 --> Database Driver Class Initialized
INFO - 2017-04-04 09:39:10 --> Model Class Initialized
INFO - 2017-04-04 09:39:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:39:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:39:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:39:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:39:10 --> Final output sent to browser
DEBUG - 2017-04-04 09:39:10 --> Total execution time: 0.1283
INFO - 2017-04-04 09:39:15 --> Config Class Initialized
INFO - 2017-04-04 09:39:15 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:39:15 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:39:15 --> Utf8 Class Initialized
INFO - 2017-04-04 09:39:15 --> URI Class Initialized
INFO - 2017-04-04 09:39:15 --> Router Class Initialized
INFO - 2017-04-04 09:39:15 --> Output Class Initialized
INFO - 2017-04-04 09:39:15 --> Security Class Initialized
DEBUG - 2017-04-04 09:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:39:15 --> Input Class Initialized
INFO - 2017-04-04 09:39:15 --> Language Class Initialized
INFO - 2017-04-04 09:39:15 --> Loader Class Initialized
INFO - 2017-04-04 09:39:15 --> Helper loaded: url_helper
INFO - 2017-04-04 09:39:15 --> Helper loaded: language_helper
INFO - 2017-04-04 09:39:15 --> Helper loaded: html_helper
INFO - 2017-04-04 09:39:15 --> Helper loaded: form_helper
INFO - 2017-04-04 09:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:39:15 --> Controller Class Initialized
INFO - 2017-04-04 09:39:15 --> Database Driver Class Initialized
INFO - 2017-04-04 09:39:15 --> Model Class Initialized
INFO - 2017-04-04 09:39:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:39:15 --> Config Class Initialized
INFO - 2017-04-04 09:39:15 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:39:15 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:39:15 --> Utf8 Class Initialized
INFO - 2017-04-04 09:39:15 --> URI Class Initialized
INFO - 2017-04-04 09:39:15 --> Router Class Initialized
INFO - 2017-04-04 09:39:15 --> Output Class Initialized
INFO - 2017-04-04 09:39:15 --> Security Class Initialized
DEBUG - 2017-04-04 09:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:39:15 --> Input Class Initialized
INFO - 2017-04-04 09:39:15 --> Language Class Initialized
INFO - 2017-04-04 09:39:15 --> Loader Class Initialized
INFO - 2017-04-04 09:39:15 --> Helper loaded: url_helper
INFO - 2017-04-04 09:39:15 --> Helper loaded: language_helper
INFO - 2017-04-04 09:39:15 --> Helper loaded: html_helper
INFO - 2017-04-04 09:39:15 --> Helper loaded: form_helper
INFO - 2017-04-04 09:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:39:15 --> Controller Class Initialized
INFO - 2017-04-04 09:39:15 --> Database Driver Class Initialized
INFO - 2017-04-04 09:39:15 --> Model Class Initialized
INFO - 2017-04-04 09:39:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:39:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:39:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:39:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:39:15 --> Final output sent to browser
DEBUG - 2017-04-04 09:39:15 --> Total execution time: 0.1017
INFO - 2017-04-04 09:40:26 --> Config Class Initialized
INFO - 2017-04-04 09:40:26 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:40:26 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:40:26 --> Utf8 Class Initialized
INFO - 2017-04-04 09:40:26 --> URI Class Initialized
INFO - 2017-04-04 09:40:26 --> Router Class Initialized
INFO - 2017-04-04 09:40:26 --> Output Class Initialized
INFO - 2017-04-04 09:40:26 --> Security Class Initialized
DEBUG - 2017-04-04 09:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:40:26 --> Input Class Initialized
INFO - 2017-04-04 09:40:26 --> Language Class Initialized
INFO - 2017-04-04 09:40:26 --> Loader Class Initialized
INFO - 2017-04-04 09:40:26 --> Helper loaded: url_helper
INFO - 2017-04-04 09:40:26 --> Helper loaded: language_helper
INFO - 2017-04-04 09:40:26 --> Helper loaded: html_helper
INFO - 2017-04-04 09:40:26 --> Helper loaded: form_helper
INFO - 2017-04-04 09:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:40:26 --> Controller Class Initialized
INFO - 2017-04-04 09:40:26 --> Database Driver Class Initialized
INFO - 2017-04-04 09:40:26 --> Model Class Initialized
INFO - 2017-04-04 09:40:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:40:26 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-04-04 09:40:26 --> Helper loaded: xlsimport/spreadsheetreader_helper
INFO - 2017-04-04 09:40:27 --> Config Class Initialized
INFO - 2017-04-04 09:40:27 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:40:27 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:40:27 --> Utf8 Class Initialized
INFO - 2017-04-04 09:40:27 --> URI Class Initialized
INFO - 2017-04-04 09:40:27 --> Router Class Initialized
INFO - 2017-04-04 09:40:27 --> Output Class Initialized
INFO - 2017-04-04 09:40:27 --> Security Class Initialized
DEBUG - 2017-04-04 09:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:40:27 --> Input Class Initialized
INFO - 2017-04-04 09:40:27 --> Language Class Initialized
INFO - 2017-04-04 09:40:27 --> Loader Class Initialized
INFO - 2017-04-04 09:40:27 --> Helper loaded: url_helper
INFO - 2017-04-04 09:40:27 --> Helper loaded: language_helper
INFO - 2017-04-04 09:40:27 --> Helper loaded: html_helper
INFO - 2017-04-04 09:40:27 --> Helper loaded: form_helper
INFO - 2017-04-04 09:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:40:27 --> Controller Class Initialized
INFO - 2017-04-04 09:40:27 --> Database Driver Class Initialized
INFO - 2017-04-04 09:40:27 --> Model Class Initialized
INFO - 2017-04-04 09:40:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:40:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:40:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:40:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:40:27 --> Final output sent to browser
DEBUG - 2017-04-04 09:40:27 --> Total execution time: 0.0915
INFO - 2017-04-04 09:40:34 --> Config Class Initialized
INFO - 2017-04-04 09:40:34 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:40:34 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:40:34 --> Utf8 Class Initialized
INFO - 2017-04-04 09:40:34 --> URI Class Initialized
INFO - 2017-04-04 09:40:34 --> Router Class Initialized
INFO - 2017-04-04 09:40:34 --> Output Class Initialized
INFO - 2017-04-04 09:40:34 --> Security Class Initialized
DEBUG - 2017-04-04 09:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:40:34 --> Input Class Initialized
INFO - 2017-04-04 09:40:34 --> Language Class Initialized
INFO - 2017-04-04 09:40:34 --> Loader Class Initialized
INFO - 2017-04-04 09:40:34 --> Helper loaded: url_helper
INFO - 2017-04-04 09:40:34 --> Helper loaded: language_helper
INFO - 2017-04-04 09:40:34 --> Helper loaded: html_helper
INFO - 2017-04-04 09:40:34 --> Helper loaded: form_helper
INFO - 2017-04-04 09:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:40:34 --> Controller Class Initialized
INFO - 2017-04-04 09:40:34 --> Database Driver Class Initialized
INFO - 2017-04-04 09:40:34 --> Model Class Initialized
INFO - 2017-04-04 09:40:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:40:34 --> Config Class Initialized
INFO - 2017-04-04 09:40:34 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:40:34 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:40:34 --> Utf8 Class Initialized
INFO - 2017-04-04 09:40:34 --> URI Class Initialized
INFO - 2017-04-04 09:40:34 --> Router Class Initialized
INFO - 2017-04-04 09:40:34 --> Output Class Initialized
INFO - 2017-04-04 09:40:34 --> Security Class Initialized
DEBUG - 2017-04-04 09:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:40:34 --> Input Class Initialized
INFO - 2017-04-04 09:40:34 --> Language Class Initialized
INFO - 2017-04-04 09:40:34 --> Loader Class Initialized
INFO - 2017-04-04 09:40:34 --> Helper loaded: url_helper
INFO - 2017-04-04 09:40:34 --> Helper loaded: language_helper
INFO - 2017-04-04 09:40:34 --> Helper loaded: html_helper
INFO - 2017-04-04 09:40:34 --> Helper loaded: form_helper
INFO - 2017-04-04 09:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:40:34 --> Controller Class Initialized
INFO - 2017-04-04 09:40:34 --> Database Driver Class Initialized
INFO - 2017-04-04 09:40:34 --> Model Class Initialized
INFO - 2017-04-04 09:40:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:40:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:40:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:40:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:40:34 --> Final output sent to browser
DEBUG - 2017-04-04 09:40:34 --> Total execution time: 0.0996
INFO - 2017-04-04 09:40:56 --> Config Class Initialized
INFO - 2017-04-04 09:40:56 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:40:56 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:40:56 --> Utf8 Class Initialized
INFO - 2017-04-04 09:40:56 --> URI Class Initialized
INFO - 2017-04-04 09:40:56 --> Router Class Initialized
INFO - 2017-04-04 09:40:56 --> Output Class Initialized
INFO - 2017-04-04 09:40:56 --> Security Class Initialized
DEBUG - 2017-04-04 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:40:56 --> Input Class Initialized
INFO - 2017-04-04 09:40:56 --> Language Class Initialized
INFO - 2017-04-04 09:40:56 --> Loader Class Initialized
INFO - 2017-04-04 09:40:56 --> Helper loaded: url_helper
INFO - 2017-04-04 09:40:56 --> Helper loaded: language_helper
INFO - 2017-04-04 09:40:56 --> Helper loaded: html_helper
INFO - 2017-04-04 09:40:56 --> Helper loaded: form_helper
INFO - 2017-04-04 09:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:40:56 --> Controller Class Initialized
INFO - 2017-04-04 09:40:56 --> Database Driver Class Initialized
INFO - 2017-04-04 09:40:56 --> Model Class Initialized
INFO - 2017-04-04 09:40:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:40:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:40:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2017-04-04 09:40:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:40:56 --> Final output sent to browser
DEBUG - 2017-04-04 09:40:56 --> Total execution time: 0.0877
INFO - 2017-04-04 09:41:03 --> Config Class Initialized
INFO - 2017-04-04 09:41:03 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:41:03 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:41:03 --> Utf8 Class Initialized
INFO - 2017-04-04 09:41:03 --> URI Class Initialized
INFO - 2017-04-04 09:41:03 --> Router Class Initialized
INFO - 2017-04-04 09:41:03 --> Output Class Initialized
INFO - 2017-04-04 09:41:03 --> Security Class Initialized
DEBUG - 2017-04-04 09:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:41:03 --> Input Class Initialized
INFO - 2017-04-04 09:41:03 --> Language Class Initialized
INFO - 2017-04-04 09:41:03 --> Loader Class Initialized
INFO - 2017-04-04 09:41:03 --> Helper loaded: url_helper
INFO - 2017-04-04 09:41:03 --> Helper loaded: language_helper
INFO - 2017-04-04 09:41:03 --> Helper loaded: html_helper
INFO - 2017-04-04 09:41:03 --> Helper loaded: form_helper
INFO - 2017-04-04 09:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:41:03 --> Controller Class Initialized
INFO - 2017-04-04 09:41:03 --> Database Driver Class Initialized
INFO - 2017-04-04 09:41:03 --> Model Class Initialized
INFO - 2017-04-04 09:41:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:41:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:41:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:41:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:41:03 --> Final output sent to browser
DEBUG - 2017-04-04 09:41:03 --> Total execution time: 0.0828
INFO - 2017-04-04 09:41:13 --> Config Class Initialized
INFO - 2017-04-04 09:41:13 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:41:13 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:41:13 --> Utf8 Class Initialized
INFO - 2017-04-04 09:41:13 --> URI Class Initialized
INFO - 2017-04-04 09:41:13 --> Router Class Initialized
INFO - 2017-04-04 09:41:13 --> Output Class Initialized
INFO - 2017-04-04 09:41:13 --> Security Class Initialized
DEBUG - 2017-04-04 09:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:41:13 --> Input Class Initialized
INFO - 2017-04-04 09:41:13 --> Language Class Initialized
INFO - 2017-04-04 09:41:13 --> Loader Class Initialized
INFO - 2017-04-04 09:41:13 --> Helper loaded: url_helper
INFO - 2017-04-04 09:41:13 --> Helper loaded: language_helper
INFO - 2017-04-04 09:41:13 --> Helper loaded: html_helper
INFO - 2017-04-04 09:41:13 --> Helper loaded: form_helper
INFO - 2017-04-04 09:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:41:13 --> Controller Class Initialized
INFO - 2017-04-04 09:41:13 --> Database Driver Class Initialized
INFO - 2017-04-04 09:41:13 --> Model Class Initialized
INFO - 2017-04-04 09:41:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:41:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:41:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2017-04-04 09:41:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:41:13 --> Final output sent to browser
DEBUG - 2017-04-04 09:41:13 --> Total execution time: 0.0881
INFO - 2017-04-04 09:42:25 --> Config Class Initialized
INFO - 2017-04-04 09:42:25 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:42:25 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:42:25 --> Utf8 Class Initialized
INFO - 2017-04-04 09:42:25 --> URI Class Initialized
INFO - 2017-04-04 09:42:25 --> Router Class Initialized
INFO - 2017-04-04 09:42:25 --> Output Class Initialized
INFO - 2017-04-04 09:42:25 --> Security Class Initialized
DEBUG - 2017-04-04 09:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:42:25 --> Input Class Initialized
INFO - 2017-04-04 09:42:25 --> Language Class Initialized
INFO - 2017-04-04 09:42:25 --> Loader Class Initialized
INFO - 2017-04-04 09:42:25 --> Helper loaded: url_helper
INFO - 2017-04-04 09:42:25 --> Helper loaded: language_helper
INFO - 2017-04-04 09:42:25 --> Helper loaded: html_helper
INFO - 2017-04-04 09:42:25 --> Helper loaded: form_helper
INFO - 2017-04-04 09:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:42:25 --> Controller Class Initialized
INFO - 2017-04-04 09:42:25 --> Database Driver Class Initialized
INFO - 2017-04-04 09:42:25 --> Model Class Initialized
INFO - 2017-04-04 09:42:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:42:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:42:25 --> Final output sent to browser
DEBUG - 2017-04-04 09:42:25 --> Total execution time: 0.0876
INFO - 2017-04-04 09:57:01 --> Config Class Initialized
INFO - 2017-04-04 09:57:01 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:57:01 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:57:01 --> Utf8 Class Initialized
INFO - 2017-04-04 09:57:01 --> URI Class Initialized
DEBUG - 2017-04-04 09:57:01 --> No URI present. Default controller set.
INFO - 2017-04-04 09:57:01 --> Router Class Initialized
INFO - 2017-04-04 09:57:01 --> Output Class Initialized
INFO - 2017-04-04 09:57:01 --> Security Class Initialized
DEBUG - 2017-04-04 09:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:57:01 --> Input Class Initialized
INFO - 2017-04-04 09:57:01 --> Language Class Initialized
INFO - 2017-04-04 09:57:01 --> Loader Class Initialized
INFO - 2017-04-04 09:57:01 --> Helper loaded: url_helper
INFO - 2017-04-04 09:57:01 --> Helper loaded: language_helper
INFO - 2017-04-04 09:57:01 --> Helper loaded: html_helper
INFO - 2017-04-04 09:57:01 --> Helper loaded: form_helper
INFO - 2017-04-04 09:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:57:01 --> Controller Class Initialized
INFO - 2017-04-04 09:57:01 --> Database Driver Class Initialized
INFO - 2017-04-04 09:57:01 --> Model Class Initialized
INFO - 2017-04-04 09:57:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:57:01 --> Config Class Initialized
INFO - 2017-04-04 09:57:01 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:57:01 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:57:01 --> Utf8 Class Initialized
INFO - 2017-04-04 09:57:01 --> URI Class Initialized
INFO - 2017-04-04 09:57:01 --> Router Class Initialized
INFO - 2017-04-04 09:57:01 --> Output Class Initialized
INFO - 2017-04-04 09:57:01 --> Security Class Initialized
DEBUG - 2017-04-04 09:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:57:01 --> Input Class Initialized
INFO - 2017-04-04 09:57:01 --> Language Class Initialized
INFO - 2017-04-04 09:57:01 --> Loader Class Initialized
INFO - 2017-04-04 09:57:01 --> Helper loaded: url_helper
INFO - 2017-04-04 09:57:01 --> Helper loaded: language_helper
INFO - 2017-04-04 09:57:01 --> Helper loaded: html_helper
INFO - 2017-04-04 09:57:01 --> Helper loaded: form_helper
INFO - 2017-04-04 09:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:57:01 --> Controller Class Initialized
INFO - 2017-04-04 09:57:01 --> Database Driver Class Initialized
INFO - 2017-04-04 09:57:01 --> Model Class Initialized
INFO - 2017-04-04 09:57:01 --> Model Class Initialized
INFO - 2017-04-04 09:57:01 --> Model Class Initialized
INFO - 2017-04-04 09:57:01 --> Model Class Initialized
INFO - 2017-04-04 09:57:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:57:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:57:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-04-04 09:57:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:57:01 --> Final output sent to browser
DEBUG - 2017-04-04 09:57:01 --> Total execution time: 0.1210
INFO - 2017-04-04 09:57:05 --> Config Class Initialized
INFO - 2017-04-04 09:57:05 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:57:05 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:57:05 --> Utf8 Class Initialized
INFO - 2017-04-04 09:57:05 --> URI Class Initialized
INFO - 2017-04-04 09:57:05 --> Router Class Initialized
INFO - 2017-04-04 09:57:05 --> Output Class Initialized
INFO - 2017-04-04 09:57:05 --> Security Class Initialized
DEBUG - 2017-04-04 09:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:57:05 --> Input Class Initialized
INFO - 2017-04-04 09:57:05 --> Language Class Initialized
INFO - 2017-04-04 09:57:05 --> Loader Class Initialized
INFO - 2017-04-04 09:57:05 --> Helper loaded: url_helper
INFO - 2017-04-04 09:57:05 --> Helper loaded: language_helper
INFO - 2017-04-04 09:57:05 --> Helper loaded: html_helper
INFO - 2017-04-04 09:57:05 --> Helper loaded: form_helper
INFO - 2017-04-04 09:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:57:05 --> Controller Class Initialized
INFO - 2017-04-04 09:57:05 --> Database Driver Class Initialized
INFO - 2017-04-04 09:57:05 --> Model Class Initialized
INFO - 2017-04-04 09:57:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:57:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:57:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:57:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:57:05 --> Final output sent to browser
DEBUG - 2017-04-04 09:57:05 --> Total execution time: 0.0895
INFO - 2017-04-04 09:58:06 --> Config Class Initialized
INFO - 2017-04-04 09:58:06 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:58:06 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:58:06 --> Utf8 Class Initialized
INFO - 2017-04-04 09:58:06 --> URI Class Initialized
INFO - 2017-04-04 09:58:06 --> Router Class Initialized
INFO - 2017-04-04 09:58:06 --> Output Class Initialized
INFO - 2017-04-04 09:58:06 --> Security Class Initialized
DEBUG - 2017-04-04 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:58:06 --> Input Class Initialized
INFO - 2017-04-04 09:58:06 --> Language Class Initialized
INFO - 2017-04-04 09:58:06 --> Loader Class Initialized
INFO - 2017-04-04 09:58:06 --> Helper loaded: url_helper
INFO - 2017-04-04 09:58:06 --> Helper loaded: language_helper
INFO - 2017-04-04 09:58:06 --> Helper loaded: html_helper
INFO - 2017-04-04 09:58:06 --> Helper loaded: form_helper
INFO - 2017-04-04 09:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:58:06 --> Controller Class Initialized
INFO - 2017-04-04 09:58:06 --> Database Driver Class Initialized
INFO - 2017-04-04 09:58:06 --> Model Class Initialized
INFO - 2017-04-04 09:58:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:58:06 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-04-04 09:58:06 --> Helper loaded: xlsimport/spreadsheetreader_helper
INFO - 2017-04-04 09:58:06 --> Config Class Initialized
INFO - 2017-04-04 09:58:06 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:58:06 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:58:06 --> Utf8 Class Initialized
INFO - 2017-04-04 09:58:06 --> URI Class Initialized
INFO - 2017-04-04 09:58:06 --> Router Class Initialized
INFO - 2017-04-04 09:58:06 --> Output Class Initialized
INFO - 2017-04-04 09:58:06 --> Security Class Initialized
DEBUG - 2017-04-04 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:58:06 --> Input Class Initialized
INFO - 2017-04-04 09:58:06 --> Language Class Initialized
INFO - 2017-04-04 09:58:06 --> Loader Class Initialized
INFO - 2017-04-04 09:58:06 --> Helper loaded: url_helper
INFO - 2017-04-04 09:58:06 --> Helper loaded: language_helper
INFO - 2017-04-04 09:58:06 --> Helper loaded: html_helper
INFO - 2017-04-04 09:58:06 --> Helper loaded: form_helper
INFO - 2017-04-04 09:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:58:06 --> Controller Class Initialized
INFO - 2017-04-04 09:58:06 --> Database Driver Class Initialized
INFO - 2017-04-04 09:58:06 --> Model Class Initialized
INFO - 2017-04-04 09:58:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:58:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:58:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:58:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:58:06 --> Final output sent to browser
DEBUG - 2017-04-04 09:58:06 --> Total execution time: 0.1215
INFO - 2017-04-04 09:58:12 --> Config Class Initialized
INFO - 2017-04-04 09:58:12 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:58:12 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:58:12 --> Utf8 Class Initialized
INFO - 2017-04-04 09:58:12 --> URI Class Initialized
INFO - 2017-04-04 09:58:12 --> Router Class Initialized
INFO - 2017-04-04 09:58:12 --> Output Class Initialized
INFO - 2017-04-04 09:58:12 --> Security Class Initialized
DEBUG - 2017-04-04 09:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:58:12 --> Input Class Initialized
INFO - 2017-04-04 09:58:12 --> Language Class Initialized
INFO - 2017-04-04 09:58:12 --> Loader Class Initialized
INFO - 2017-04-04 09:58:12 --> Helper loaded: url_helper
INFO - 2017-04-04 09:58:12 --> Helper loaded: language_helper
INFO - 2017-04-04 09:58:12 --> Helper loaded: html_helper
INFO - 2017-04-04 09:58:12 --> Helper loaded: form_helper
INFO - 2017-04-04 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:58:12 --> Controller Class Initialized
INFO - 2017-04-04 09:58:12 --> Database Driver Class Initialized
INFO - 2017-04-04 09:58:12 --> Model Class Initialized
INFO - 2017-04-04 09:58:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:58:12 --> Config Class Initialized
INFO - 2017-04-04 09:58:12 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:58:12 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:58:12 --> Utf8 Class Initialized
INFO - 2017-04-04 09:58:12 --> URI Class Initialized
INFO - 2017-04-04 09:58:12 --> Router Class Initialized
INFO - 2017-04-04 09:58:12 --> Output Class Initialized
INFO - 2017-04-04 09:58:12 --> Security Class Initialized
DEBUG - 2017-04-04 09:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:58:12 --> Input Class Initialized
INFO - 2017-04-04 09:58:12 --> Language Class Initialized
INFO - 2017-04-04 09:58:12 --> Loader Class Initialized
INFO - 2017-04-04 09:58:12 --> Helper loaded: url_helper
INFO - 2017-04-04 09:58:12 --> Helper loaded: language_helper
INFO - 2017-04-04 09:58:12 --> Helper loaded: html_helper
INFO - 2017-04-04 09:58:12 --> Helper loaded: form_helper
INFO - 2017-04-04 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:58:12 --> Controller Class Initialized
INFO - 2017-04-04 09:58:12 --> Database Driver Class Initialized
INFO - 2017-04-04 09:58:12 --> Model Class Initialized
INFO - 2017-04-04 09:58:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:58:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:58:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:58:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:58:13 --> Final output sent to browser
DEBUG - 2017-04-04 09:58:13 --> Total execution time: 0.0841
INFO - 2017-04-04 09:58:17 --> Config Class Initialized
INFO - 2017-04-04 09:58:17 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:58:17 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:58:17 --> Utf8 Class Initialized
INFO - 2017-04-04 09:58:17 --> URI Class Initialized
INFO - 2017-04-04 09:58:17 --> Router Class Initialized
INFO - 2017-04-04 09:58:17 --> Output Class Initialized
INFO - 2017-04-04 09:58:17 --> Security Class Initialized
DEBUG - 2017-04-04 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:58:17 --> Input Class Initialized
INFO - 2017-04-04 09:58:17 --> Language Class Initialized
INFO - 2017-04-04 09:58:17 --> Loader Class Initialized
INFO - 2017-04-04 09:58:17 --> Helper loaded: url_helper
INFO - 2017-04-04 09:58:17 --> Helper loaded: language_helper
INFO - 2017-04-04 09:58:17 --> Helper loaded: html_helper
INFO - 2017-04-04 09:58:17 --> Helper loaded: form_helper
INFO - 2017-04-04 09:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:58:17 --> Controller Class Initialized
INFO - 2017-04-04 09:58:17 --> Database Driver Class Initialized
INFO - 2017-04-04 09:58:17 --> Model Class Initialized
INFO - 2017-04-04 09:58:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:58:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:58:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:58:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:58:17 --> Final output sent to browser
DEBUG - 2017-04-04 09:58:17 --> Total execution time: 0.0781
INFO - 2017-04-04 09:58:20 --> Config Class Initialized
INFO - 2017-04-04 09:58:20 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:58:20 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:58:20 --> Utf8 Class Initialized
INFO - 2017-04-04 09:58:20 --> URI Class Initialized
INFO - 2017-04-04 09:58:20 --> Router Class Initialized
INFO - 2017-04-04 09:58:20 --> Output Class Initialized
INFO - 2017-04-04 09:58:20 --> Security Class Initialized
DEBUG - 2017-04-04 09:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:58:20 --> Input Class Initialized
INFO - 2017-04-04 09:58:20 --> Language Class Initialized
INFO - 2017-04-04 09:58:20 --> Loader Class Initialized
INFO - 2017-04-04 09:58:20 --> Helper loaded: url_helper
INFO - 2017-04-04 09:58:20 --> Helper loaded: language_helper
INFO - 2017-04-04 09:58:20 --> Helper loaded: html_helper
INFO - 2017-04-04 09:58:20 --> Helper loaded: form_helper
INFO - 2017-04-04 09:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:58:20 --> Controller Class Initialized
INFO - 2017-04-04 09:58:20 --> Database Driver Class Initialized
INFO - 2017-04-04 09:58:20 --> Model Class Initialized
INFO - 2017-04-04 09:58:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:58:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:58:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:58:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:58:20 --> Final output sent to browser
DEBUG - 2017-04-04 09:58:20 --> Total execution time: 0.0883
INFO - 2017-04-04 09:58:26 --> Config Class Initialized
INFO - 2017-04-04 09:58:26 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:58:26 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:58:26 --> Utf8 Class Initialized
INFO - 2017-04-04 09:58:26 --> URI Class Initialized
INFO - 2017-04-04 09:58:26 --> Router Class Initialized
INFO - 2017-04-04 09:58:26 --> Output Class Initialized
INFO - 2017-04-04 09:58:26 --> Security Class Initialized
DEBUG - 2017-04-04 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:58:26 --> Input Class Initialized
INFO - 2017-04-04 09:58:26 --> Language Class Initialized
INFO - 2017-04-04 09:58:26 --> Loader Class Initialized
INFO - 2017-04-04 09:58:26 --> Helper loaded: url_helper
INFO - 2017-04-04 09:58:26 --> Helper loaded: language_helper
INFO - 2017-04-04 09:58:26 --> Helper loaded: html_helper
INFO - 2017-04-04 09:58:26 --> Helper loaded: form_helper
INFO - 2017-04-04 09:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:58:26 --> Controller Class Initialized
INFO - 2017-04-04 09:58:26 --> Database Driver Class Initialized
INFO - 2017-04-04 09:58:26 --> Model Class Initialized
INFO - 2017-04-04 09:58:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:58:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:58:26 --> Final output sent to browser
DEBUG - 2017-04-04 09:58:26 --> Total execution time: 0.0785
INFO - 2017-04-04 09:58:31 --> Config Class Initialized
INFO - 2017-04-04 09:58:31 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:58:31 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:58:31 --> Utf8 Class Initialized
INFO - 2017-04-04 09:58:31 --> URI Class Initialized
INFO - 2017-04-04 09:58:31 --> Router Class Initialized
INFO - 2017-04-04 09:58:31 --> Output Class Initialized
INFO - 2017-04-04 09:58:31 --> Security Class Initialized
DEBUG - 2017-04-04 09:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:58:31 --> Input Class Initialized
INFO - 2017-04-04 09:58:31 --> Language Class Initialized
INFO - 2017-04-04 09:58:31 --> Loader Class Initialized
INFO - 2017-04-04 09:58:31 --> Helper loaded: url_helper
INFO - 2017-04-04 09:58:31 --> Helper loaded: language_helper
INFO - 2017-04-04 09:58:31 --> Helper loaded: html_helper
INFO - 2017-04-04 09:58:31 --> Helper loaded: form_helper
INFO - 2017-04-04 09:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:58:32 --> Controller Class Initialized
INFO - 2017-04-04 09:58:32 --> Database Driver Class Initialized
INFO - 2017-04-04 09:58:32 --> Model Class Initialized
INFO - 2017-04-04 09:58:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:58:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:58:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2017-04-04 09:58:32 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:58:32 --> Final output sent to browser
DEBUG - 2017-04-04 09:58:32 --> Total execution time: 0.1315
INFO - 2017-04-04 09:59:02 --> Config Class Initialized
INFO - 2017-04-04 09:59:02 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:59:02 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:59:02 --> Utf8 Class Initialized
INFO - 2017-04-04 09:59:02 --> URI Class Initialized
INFO - 2017-04-04 09:59:02 --> Router Class Initialized
INFO - 2017-04-04 09:59:02 --> Output Class Initialized
INFO - 2017-04-04 09:59:02 --> Security Class Initialized
DEBUG - 2017-04-04 09:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:59:02 --> Input Class Initialized
INFO - 2017-04-04 09:59:02 --> Language Class Initialized
INFO - 2017-04-04 09:59:02 --> Loader Class Initialized
INFO - 2017-04-04 09:59:02 --> Helper loaded: url_helper
INFO - 2017-04-04 09:59:02 --> Helper loaded: language_helper
INFO - 2017-04-04 09:59:02 --> Helper loaded: html_helper
INFO - 2017-04-04 09:59:02 --> Helper loaded: form_helper
INFO - 2017-04-04 09:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:59:02 --> Controller Class Initialized
INFO - 2017-04-04 09:59:02 --> Database Driver Class Initialized
INFO - 2017-04-04 09:59:02 --> Model Class Initialized
INFO - 2017-04-04 09:59:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:59:02 --> Final output sent to browser
DEBUG - 2017-04-04 09:59:02 --> Total execution time: 0.0832
INFO - 2017-04-04 09:59:06 --> Config Class Initialized
INFO - 2017-04-04 09:59:06 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:59:06 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:59:06 --> Utf8 Class Initialized
INFO - 2017-04-04 09:59:06 --> URI Class Initialized
INFO - 2017-04-04 09:59:06 --> Router Class Initialized
INFO - 2017-04-04 09:59:06 --> Output Class Initialized
INFO - 2017-04-04 09:59:06 --> Security Class Initialized
DEBUG - 2017-04-04 09:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:59:06 --> Input Class Initialized
INFO - 2017-04-04 09:59:06 --> Language Class Initialized
INFO - 2017-04-04 09:59:06 --> Loader Class Initialized
INFO - 2017-04-04 09:59:06 --> Helper loaded: url_helper
INFO - 2017-04-04 09:59:06 --> Helper loaded: language_helper
INFO - 2017-04-04 09:59:06 --> Helper loaded: html_helper
INFO - 2017-04-04 09:59:06 --> Helper loaded: form_helper
INFO - 2017-04-04 09:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:59:06 --> Controller Class Initialized
INFO - 2017-04-04 09:59:06 --> Database Driver Class Initialized
INFO - 2017-04-04 09:59:06 --> Model Class Initialized
INFO - 2017-04-04 09:59:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:59:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:59:06 --> Final output sent to browser
DEBUG - 2017-04-04 09:59:06 --> Total execution time: 0.0792
INFO - 2017-04-04 09:59:09 --> Config Class Initialized
INFO - 2017-04-04 09:59:09 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:59:09 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:59:09 --> Utf8 Class Initialized
INFO - 2017-04-04 09:59:09 --> URI Class Initialized
INFO - 2017-04-04 09:59:09 --> Router Class Initialized
INFO - 2017-04-04 09:59:09 --> Output Class Initialized
INFO - 2017-04-04 09:59:09 --> Security Class Initialized
DEBUG - 2017-04-04 09:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:59:09 --> Input Class Initialized
INFO - 2017-04-04 09:59:09 --> Language Class Initialized
INFO - 2017-04-04 09:59:09 --> Loader Class Initialized
INFO - 2017-04-04 09:59:09 --> Helper loaded: url_helper
INFO - 2017-04-04 09:59:09 --> Helper loaded: language_helper
INFO - 2017-04-04 09:59:09 --> Helper loaded: html_helper
INFO - 2017-04-04 09:59:09 --> Helper loaded: form_helper
INFO - 2017-04-04 09:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:59:09 --> Controller Class Initialized
INFO - 2017-04-04 09:59:09 --> Database Driver Class Initialized
INFO - 2017-04-04 09:59:09 --> Model Class Initialized
INFO - 2017-04-04 09:59:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:59:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:59:09 --> Final output sent to browser
DEBUG - 2017-04-04 09:59:09 --> Total execution time: 0.0987
INFO - 2017-04-04 09:59:13 --> Config Class Initialized
INFO - 2017-04-04 09:59:13 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:59:13 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:59:13 --> Utf8 Class Initialized
INFO - 2017-04-04 09:59:13 --> URI Class Initialized
INFO - 2017-04-04 09:59:13 --> Router Class Initialized
INFO - 2017-04-04 09:59:13 --> Output Class Initialized
INFO - 2017-04-04 09:59:13 --> Security Class Initialized
DEBUG - 2017-04-04 09:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:59:13 --> Input Class Initialized
INFO - 2017-04-04 09:59:13 --> Language Class Initialized
INFO - 2017-04-04 09:59:14 --> Loader Class Initialized
INFO - 2017-04-04 09:59:14 --> Helper loaded: url_helper
INFO - 2017-04-04 09:59:14 --> Helper loaded: language_helper
INFO - 2017-04-04 09:59:14 --> Helper loaded: html_helper
INFO - 2017-04-04 09:59:14 --> Helper loaded: form_helper
INFO - 2017-04-04 09:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:59:14 --> Controller Class Initialized
INFO - 2017-04-04 09:59:14 --> Database Driver Class Initialized
INFO - 2017-04-04 09:59:14 --> Model Class Initialized
INFO - 2017-04-04 09:59:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:59:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:59:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2017-04-04 09:59:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:59:14 --> Final output sent to browser
DEBUG - 2017-04-04 09:59:14 --> Total execution time: 0.1333
INFO - 2017-04-04 09:59:50 --> Config Class Initialized
INFO - 2017-04-04 09:59:50 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:59:50 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:59:50 --> Utf8 Class Initialized
INFO - 2017-04-04 09:59:50 --> URI Class Initialized
INFO - 2017-04-04 09:59:50 --> Router Class Initialized
INFO - 2017-04-04 09:59:50 --> Output Class Initialized
INFO - 2017-04-04 09:59:50 --> Security Class Initialized
DEBUG - 2017-04-04 09:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:59:50 --> Input Class Initialized
INFO - 2017-04-04 09:59:50 --> Language Class Initialized
INFO - 2017-04-04 09:59:50 --> Loader Class Initialized
INFO - 2017-04-04 09:59:50 --> Helper loaded: url_helper
INFO - 2017-04-04 09:59:50 --> Helper loaded: language_helper
INFO - 2017-04-04 09:59:50 --> Helper loaded: html_helper
INFO - 2017-04-04 09:59:50 --> Helper loaded: form_helper
INFO - 2017-04-04 09:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:59:50 --> Controller Class Initialized
INFO - 2017-04-04 09:59:50 --> Database Driver Class Initialized
INFO - 2017-04-04 09:59:50 --> Model Class Initialized
INFO - 2017-04-04 09:59:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:59:50 --> Helper loaded: xlsimport/php-excel-reader/excel_reader2_helper
INFO - 2017-04-04 09:59:50 --> Helper loaded: xlsimport/spreadsheetreader_helper
INFO - 2017-04-04 09:59:50 --> Config Class Initialized
INFO - 2017-04-04 09:59:50 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:59:50 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:59:50 --> Utf8 Class Initialized
INFO - 2017-04-04 09:59:50 --> URI Class Initialized
INFO - 2017-04-04 09:59:50 --> Router Class Initialized
INFO - 2017-04-04 09:59:50 --> Output Class Initialized
INFO - 2017-04-04 09:59:50 --> Security Class Initialized
DEBUG - 2017-04-04 09:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:59:50 --> Input Class Initialized
INFO - 2017-04-04 09:59:50 --> Language Class Initialized
INFO - 2017-04-04 09:59:50 --> Loader Class Initialized
INFO - 2017-04-04 09:59:50 --> Helper loaded: url_helper
INFO - 2017-04-04 09:59:50 --> Helper loaded: language_helper
INFO - 2017-04-04 09:59:50 --> Helper loaded: html_helper
INFO - 2017-04-04 09:59:50 --> Helper loaded: form_helper
INFO - 2017-04-04 09:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:59:50 --> Controller Class Initialized
INFO - 2017-04-04 09:59:50 --> Database Driver Class Initialized
INFO - 2017-04-04 09:59:50 --> Model Class Initialized
INFO - 2017-04-04 09:59:50 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:59:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:59:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:59:50 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:59:50 --> Final output sent to browser
DEBUG - 2017-04-04 09:59:50 --> Total execution time: 0.1186
INFO - 2017-04-04 09:59:55 --> Config Class Initialized
INFO - 2017-04-04 09:59:55 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:59:55 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:59:55 --> Utf8 Class Initialized
INFO - 2017-04-04 09:59:55 --> URI Class Initialized
INFO - 2017-04-04 09:59:55 --> Router Class Initialized
INFO - 2017-04-04 09:59:55 --> Output Class Initialized
INFO - 2017-04-04 09:59:55 --> Security Class Initialized
DEBUG - 2017-04-04 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:59:55 --> Input Class Initialized
INFO - 2017-04-04 09:59:55 --> Language Class Initialized
INFO - 2017-04-04 09:59:55 --> Loader Class Initialized
INFO - 2017-04-04 09:59:55 --> Helper loaded: url_helper
INFO - 2017-04-04 09:59:55 --> Helper loaded: language_helper
INFO - 2017-04-04 09:59:55 --> Helper loaded: html_helper
INFO - 2017-04-04 09:59:55 --> Helper loaded: form_helper
INFO - 2017-04-04 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:59:55 --> Controller Class Initialized
INFO - 2017-04-04 09:59:55 --> Database Driver Class Initialized
INFO - 2017-04-04 09:59:55 --> Model Class Initialized
INFO - 2017-04-04 09:59:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:59:55 --> Config Class Initialized
INFO - 2017-04-04 09:59:55 --> Hooks Class Initialized
DEBUG - 2017-04-04 09:59:55 --> UTF-8 Support Enabled
INFO - 2017-04-04 09:59:55 --> Utf8 Class Initialized
INFO - 2017-04-04 09:59:55 --> URI Class Initialized
INFO - 2017-04-04 09:59:55 --> Router Class Initialized
INFO - 2017-04-04 09:59:55 --> Output Class Initialized
INFO - 2017-04-04 09:59:55 --> Security Class Initialized
DEBUG - 2017-04-04 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 09:59:55 --> Input Class Initialized
INFO - 2017-04-04 09:59:55 --> Language Class Initialized
INFO - 2017-04-04 09:59:55 --> Loader Class Initialized
INFO - 2017-04-04 09:59:55 --> Helper loaded: url_helper
INFO - 2017-04-04 09:59:55 --> Helper loaded: language_helper
INFO - 2017-04-04 09:59:55 --> Helper loaded: html_helper
INFO - 2017-04-04 09:59:55 --> Helper loaded: form_helper
INFO - 2017-04-04 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 09:59:55 --> Controller Class Initialized
INFO - 2017-04-04 09:59:55 --> Database Driver Class Initialized
INFO - 2017-04-04 09:59:55 --> Model Class Initialized
INFO - 2017-04-04 09:59:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 09:59:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 09:59:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-04 09:59:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 09:59:55 --> Final output sent to browser
DEBUG - 2017-04-04 09:59:55 --> Total execution time: 0.0769
INFO - 2017-04-04 10:00:03 --> Config Class Initialized
INFO - 2017-04-04 10:00:03 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:00:03 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:00:03 --> Utf8 Class Initialized
INFO - 2017-04-04 10:00:03 --> URI Class Initialized
INFO - 2017-04-04 10:00:03 --> Router Class Initialized
INFO - 2017-04-04 10:00:03 --> Output Class Initialized
INFO - 2017-04-04 10:00:03 --> Security Class Initialized
DEBUG - 2017-04-04 10:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:00:03 --> Input Class Initialized
INFO - 2017-04-04 10:00:03 --> Language Class Initialized
INFO - 2017-04-04 10:00:03 --> Loader Class Initialized
INFO - 2017-04-04 10:00:03 --> Helper loaded: url_helper
INFO - 2017-04-04 10:00:03 --> Helper loaded: language_helper
INFO - 2017-04-04 10:00:03 --> Helper loaded: html_helper
INFO - 2017-04-04 10:00:03 --> Helper loaded: form_helper
INFO - 2017-04-04 10:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:00:03 --> Controller Class Initialized
INFO - 2017-04-04 10:00:03 --> Database Driver Class Initialized
INFO - 2017-04-04 10:00:03 --> Model Class Initialized
INFO - 2017-04-04 10:00:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2017-04-04 10:00:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:00:03 --> Final output sent to browser
DEBUG - 2017-04-04 10:00:03 --> Total execution time: 0.1197
INFO - 2017-04-04 10:00:12 --> Config Class Initialized
INFO - 2017-04-04 10:00:12 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:00:12 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:00:12 --> Utf8 Class Initialized
INFO - 2017-04-04 10:00:12 --> URI Class Initialized
INFO - 2017-04-04 10:00:12 --> Router Class Initialized
INFO - 2017-04-04 10:00:12 --> Output Class Initialized
INFO - 2017-04-04 10:00:12 --> Security Class Initialized
DEBUG - 2017-04-04 10:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:00:12 --> Input Class Initialized
INFO - 2017-04-04 10:00:12 --> Language Class Initialized
INFO - 2017-04-04 10:00:12 --> Loader Class Initialized
INFO - 2017-04-04 10:00:12 --> Helper loaded: url_helper
INFO - 2017-04-04 10:00:12 --> Helper loaded: language_helper
INFO - 2017-04-04 10:00:12 --> Helper loaded: html_helper
INFO - 2017-04-04 10:00:12 --> Helper loaded: form_helper
INFO - 2017-04-04 10:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:00:12 --> Controller Class Initialized
INFO - 2017-04-04 10:00:12 --> Database Driver Class Initialized
INFO - 2017-04-04 10:00:13 --> Model Class Initialized
INFO - 2017-04-04 10:00:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2017-04-04 10:00:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:00:13 --> Final output sent to browser
DEBUG - 2017-04-04 10:00:13 --> Total execution time: 0.0923
INFO - 2017-04-04 10:00:25 --> Config Class Initialized
INFO - 2017-04-04 10:00:25 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:00:25 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:00:25 --> Utf8 Class Initialized
INFO - 2017-04-04 10:00:25 --> URI Class Initialized
INFO - 2017-04-04 10:00:25 --> Router Class Initialized
INFO - 2017-04-04 10:00:25 --> Output Class Initialized
INFO - 2017-04-04 10:00:25 --> Security Class Initialized
DEBUG - 2017-04-04 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:00:25 --> Input Class Initialized
INFO - 2017-04-04 10:00:25 --> Language Class Initialized
INFO - 2017-04-04 10:00:25 --> Loader Class Initialized
INFO - 2017-04-04 10:00:25 --> Helper loaded: url_helper
INFO - 2017-04-04 10:00:25 --> Helper loaded: language_helper
INFO - 2017-04-04 10:00:25 --> Helper loaded: html_helper
INFO - 2017-04-04 10:00:25 --> Helper loaded: form_helper
INFO - 2017-04-04 10:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:00:25 --> Controller Class Initialized
INFO - 2017-04-04 10:00:25 --> Database Driver Class Initialized
INFO - 2017-04-04 10:00:25 --> Model Class Initialized
INFO - 2017-04-04 10:00:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2017-04-04 10:00:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:00:25 --> Final output sent to browser
DEBUG - 2017-04-04 10:00:25 --> Total execution time: 0.1289
INFO - 2017-04-04 10:01:27 --> Config Class Initialized
INFO - 2017-04-04 10:01:27 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:01:27 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:01:27 --> Utf8 Class Initialized
INFO - 2017-04-04 10:01:27 --> URI Class Initialized
INFO - 2017-04-04 10:01:27 --> Router Class Initialized
INFO - 2017-04-04 10:01:27 --> Output Class Initialized
INFO - 2017-04-04 10:01:27 --> Security Class Initialized
DEBUG - 2017-04-04 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:01:27 --> Input Class Initialized
INFO - 2017-04-04 10:01:27 --> Language Class Initialized
INFO - 2017-04-04 10:01:27 --> Loader Class Initialized
INFO - 2017-04-04 10:01:27 --> Helper loaded: url_helper
INFO - 2017-04-04 10:01:27 --> Helper loaded: language_helper
INFO - 2017-04-04 10:01:27 --> Helper loaded: html_helper
INFO - 2017-04-04 10:01:27 --> Helper loaded: form_helper
INFO - 2017-04-04 10:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:01:27 --> Controller Class Initialized
INFO - 2017-04-04 10:01:27 --> Database Driver Class Initialized
INFO - 2017-04-04 10:01:27 --> Model Class Initialized
INFO - 2017-04-04 10:01:27 --> Model Class Initialized
INFO - 2017-04-04 10:01:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:01:27 --> Config Class Initialized
INFO - 2017-04-04 10:01:27 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:01:27 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:01:27 --> Utf8 Class Initialized
INFO - 2017-04-04 10:01:27 --> URI Class Initialized
INFO - 2017-04-04 10:01:27 --> Router Class Initialized
INFO - 2017-04-04 10:01:27 --> Output Class Initialized
INFO - 2017-04-04 10:01:27 --> Security Class Initialized
DEBUG - 2017-04-04 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:01:27 --> Input Class Initialized
INFO - 2017-04-04 10:01:27 --> Language Class Initialized
INFO - 2017-04-04 10:01:27 --> Loader Class Initialized
INFO - 2017-04-04 10:01:27 --> Helper loaded: url_helper
INFO - 2017-04-04 10:01:27 --> Helper loaded: language_helper
INFO - 2017-04-04 10:01:27 --> Helper loaded: html_helper
INFO - 2017-04-04 10:01:27 --> Helper loaded: form_helper
INFO - 2017-04-04 10:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:01:27 --> Controller Class Initialized
INFO - 2017-04-04 10:01:27 --> Database Driver Class Initialized
INFO - 2017-04-04 10:01:27 --> Model Class Initialized
INFO - 2017-04-04 10:01:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:01:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-04 10:01:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-04 10:01:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-04 10:01:27 --> Final output sent to browser
DEBUG - 2017-04-04 10:01:27 --> Total execution time: 0.0661
INFO - 2017-04-04 10:01:29 --> Config Class Initialized
INFO - 2017-04-04 10:01:29 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:01:29 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:01:29 --> Utf8 Class Initialized
INFO - 2017-04-04 10:01:29 --> URI Class Initialized
INFO - 2017-04-04 10:01:29 --> Router Class Initialized
INFO - 2017-04-04 10:01:29 --> Output Class Initialized
INFO - 2017-04-04 10:01:29 --> Security Class Initialized
DEBUG - 2017-04-04 10:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:01:29 --> Input Class Initialized
INFO - 2017-04-04 10:01:29 --> Language Class Initialized
INFO - 2017-04-04 10:01:29 --> Loader Class Initialized
INFO - 2017-04-04 10:01:29 --> Helper loaded: url_helper
INFO - 2017-04-04 10:01:29 --> Helper loaded: language_helper
INFO - 2017-04-04 10:01:29 --> Helper loaded: html_helper
INFO - 2017-04-04 10:01:29 --> Helper loaded: form_helper
INFO - 2017-04-04 10:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:01:29 --> Controller Class Initialized
INFO - 2017-04-04 10:01:29 --> Database Driver Class Initialized
INFO - 2017-04-04 10:01:29 --> Model Class Initialized
INFO - 2017-04-04 10:01:29 --> Email Class Initialized
INFO - 2017-04-04 10:01:29 --> Form Validation Class Initialized
INFO - 2017-04-04 10:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:01:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:01:29 --> Final output sent to browser
DEBUG - 2017-04-04 10:01:29 --> Total execution time: 0.1024
INFO - 2017-04-04 10:02:08 --> Config Class Initialized
INFO - 2017-04-04 10:02:08 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:02:08 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:02:08 --> Utf8 Class Initialized
INFO - 2017-04-04 10:02:08 --> URI Class Initialized
INFO - 2017-04-04 10:02:08 --> Router Class Initialized
INFO - 2017-04-04 10:02:08 --> Output Class Initialized
INFO - 2017-04-04 10:02:08 --> Security Class Initialized
DEBUG - 2017-04-04 10:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:02:08 --> Input Class Initialized
INFO - 2017-04-04 10:02:08 --> Language Class Initialized
INFO - 2017-04-04 10:02:08 --> Loader Class Initialized
INFO - 2017-04-04 10:02:08 --> Helper loaded: url_helper
INFO - 2017-04-04 10:02:08 --> Helper loaded: language_helper
INFO - 2017-04-04 10:02:08 --> Helper loaded: html_helper
INFO - 2017-04-04 10:02:08 --> Helper loaded: form_helper
INFO - 2017-04-04 10:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:02:08 --> Controller Class Initialized
INFO - 2017-04-04 10:02:08 --> Database Driver Class Initialized
INFO - 2017-04-04 10:02:08 --> Model Class Initialized
INFO - 2017-04-04 10:02:08 --> Email Class Initialized
INFO - 2017-04-04 10:02:08 --> Form Validation Class Initialized
INFO - 2017-04-04 10:02:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:02:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-04 10:02:08 --> Could not find the language line "first_name<sup>*</sup>"
INFO - 2017-04-04 10:02:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:02:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:02:08 --> Final output sent to browser
DEBUG - 2017-04-04 10:02:08 --> Total execution time: 0.0809
INFO - 2017-04-04 10:02:38 --> Config Class Initialized
INFO - 2017-04-04 10:02:38 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:02:38 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:02:38 --> Utf8 Class Initialized
INFO - 2017-04-04 10:02:38 --> URI Class Initialized
INFO - 2017-04-04 10:02:38 --> Router Class Initialized
INFO - 2017-04-04 10:02:38 --> Output Class Initialized
INFO - 2017-04-04 10:02:38 --> Security Class Initialized
DEBUG - 2017-04-04 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:02:38 --> Input Class Initialized
INFO - 2017-04-04 10:02:38 --> Language Class Initialized
INFO - 2017-04-04 10:02:38 --> Loader Class Initialized
INFO - 2017-04-04 10:02:38 --> Helper loaded: url_helper
INFO - 2017-04-04 10:02:38 --> Helper loaded: language_helper
INFO - 2017-04-04 10:02:38 --> Helper loaded: html_helper
INFO - 2017-04-04 10:02:38 --> Helper loaded: form_helper
INFO - 2017-04-04 10:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:02:38 --> Controller Class Initialized
INFO - 2017-04-04 10:02:38 --> Database Driver Class Initialized
INFO - 2017-04-04 10:02:38 --> Model Class Initialized
INFO - 2017-04-04 10:02:38 --> Email Class Initialized
INFO - 2017-04-04 10:02:38 --> Form Validation Class Initialized
INFO - 2017-04-04 10:02:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:02:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:02:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:02:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:02:38 --> Final output sent to browser
DEBUG - 2017-04-04 10:02:38 --> Total execution time: 0.0804
INFO - 2017-04-04 10:02:58 --> Config Class Initialized
INFO - 2017-04-04 10:02:58 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:02:58 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:02:58 --> Utf8 Class Initialized
INFO - 2017-04-04 10:02:58 --> URI Class Initialized
INFO - 2017-04-04 10:02:58 --> Router Class Initialized
INFO - 2017-04-04 10:02:58 --> Output Class Initialized
INFO - 2017-04-04 10:02:58 --> Security Class Initialized
DEBUG - 2017-04-04 10:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:02:58 --> Input Class Initialized
INFO - 2017-04-04 10:02:58 --> Language Class Initialized
INFO - 2017-04-04 10:02:58 --> Loader Class Initialized
INFO - 2017-04-04 10:02:58 --> Helper loaded: url_helper
INFO - 2017-04-04 10:02:58 --> Helper loaded: language_helper
INFO - 2017-04-04 10:02:58 --> Helper loaded: html_helper
INFO - 2017-04-04 10:02:58 --> Helper loaded: form_helper
INFO - 2017-04-04 10:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:02:58 --> Controller Class Initialized
INFO - 2017-04-04 10:02:58 --> Database Driver Class Initialized
INFO - 2017-04-04 10:02:58 --> Model Class Initialized
INFO - 2017-04-04 10:02:58 --> Email Class Initialized
INFO - 2017-04-04 10:02:58 --> Form Validation Class Initialized
INFO - 2017-04-04 10:02:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:02:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:02:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:02:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:02:58 --> Final output sent to browser
DEBUG - 2017-04-04 10:02:58 --> Total execution time: 0.0898
INFO - 2017-04-04 10:03:22 --> Config Class Initialized
INFO - 2017-04-04 10:03:22 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:03:22 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:03:22 --> Utf8 Class Initialized
INFO - 2017-04-04 10:03:22 --> URI Class Initialized
INFO - 2017-04-04 10:03:22 --> Router Class Initialized
INFO - 2017-04-04 10:03:22 --> Output Class Initialized
INFO - 2017-04-04 10:03:22 --> Security Class Initialized
DEBUG - 2017-04-04 10:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:03:22 --> Input Class Initialized
INFO - 2017-04-04 10:03:22 --> Language Class Initialized
INFO - 2017-04-04 10:03:22 --> Loader Class Initialized
INFO - 2017-04-04 10:03:22 --> Helper loaded: url_helper
INFO - 2017-04-04 10:03:22 --> Helper loaded: language_helper
INFO - 2017-04-04 10:03:22 --> Helper loaded: html_helper
INFO - 2017-04-04 10:03:22 --> Helper loaded: form_helper
INFO - 2017-04-04 10:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:03:22 --> Controller Class Initialized
INFO - 2017-04-04 10:03:22 --> Database Driver Class Initialized
INFO - 2017-04-04 10:03:22 --> Model Class Initialized
INFO - 2017-04-04 10:03:22 --> Email Class Initialized
INFO - 2017-04-04 10:03:22 --> Form Validation Class Initialized
INFO - 2017-04-04 10:03:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:03:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:03:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:03:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:03:22 --> Final output sent to browser
DEBUG - 2017-04-04 10:03:22 --> Total execution time: 0.0979
INFO - 2017-04-04 10:04:06 --> Config Class Initialized
INFO - 2017-04-04 10:04:06 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:04:06 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:04:06 --> Utf8 Class Initialized
INFO - 2017-04-04 10:04:06 --> URI Class Initialized
INFO - 2017-04-04 10:04:06 --> Router Class Initialized
INFO - 2017-04-04 10:04:06 --> Output Class Initialized
INFO - 2017-04-04 10:04:06 --> Security Class Initialized
DEBUG - 2017-04-04 10:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:04:06 --> Input Class Initialized
INFO - 2017-04-04 10:04:06 --> Language Class Initialized
INFO - 2017-04-04 10:04:06 --> Loader Class Initialized
INFO - 2017-04-04 10:04:06 --> Helper loaded: url_helper
INFO - 2017-04-04 10:04:06 --> Helper loaded: language_helper
INFO - 2017-04-04 10:04:06 --> Helper loaded: html_helper
INFO - 2017-04-04 10:04:06 --> Helper loaded: form_helper
INFO - 2017-04-04 10:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:04:06 --> Controller Class Initialized
INFO - 2017-04-04 10:04:06 --> Database Driver Class Initialized
INFO - 2017-04-04 10:04:06 --> Model Class Initialized
INFO - 2017-04-04 10:04:06 --> Email Class Initialized
INFO - 2017-04-04 10:04:06 --> Form Validation Class Initialized
INFO - 2017-04-04 10:04:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:04:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:04:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:04:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:04:06 --> Final output sent to browser
DEBUG - 2017-04-04 10:04:06 --> Total execution time: 0.0848
INFO - 2017-04-04 10:04:33 --> Config Class Initialized
INFO - 2017-04-04 10:04:33 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:04:33 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:04:33 --> Utf8 Class Initialized
INFO - 2017-04-04 10:04:33 --> URI Class Initialized
INFO - 2017-04-04 10:04:33 --> Router Class Initialized
INFO - 2017-04-04 10:04:33 --> Output Class Initialized
INFO - 2017-04-04 10:04:33 --> Security Class Initialized
DEBUG - 2017-04-04 10:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:04:33 --> Input Class Initialized
INFO - 2017-04-04 10:04:33 --> Language Class Initialized
INFO - 2017-04-04 10:04:33 --> Loader Class Initialized
INFO - 2017-04-04 10:04:33 --> Helper loaded: url_helper
INFO - 2017-04-04 10:04:33 --> Helper loaded: language_helper
INFO - 2017-04-04 10:04:33 --> Helper loaded: html_helper
INFO - 2017-04-04 10:04:33 --> Helper loaded: form_helper
INFO - 2017-04-04 10:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:04:33 --> Controller Class Initialized
INFO - 2017-04-04 10:04:33 --> Database Driver Class Initialized
INFO - 2017-04-04 10:04:33 --> Model Class Initialized
INFO - 2017-04-04 10:04:33 --> Email Class Initialized
INFO - 2017-04-04 10:04:33 --> Form Validation Class Initialized
INFO - 2017-04-04 10:04:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:04:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:04:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:04:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:04:33 --> Final output sent to browser
DEBUG - 2017-04-04 10:04:33 --> Total execution time: 0.0921
INFO - 2017-04-04 10:05:13 --> Config Class Initialized
INFO - 2017-04-04 10:05:13 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:05:13 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:05:13 --> Utf8 Class Initialized
INFO - 2017-04-04 10:05:13 --> URI Class Initialized
INFO - 2017-04-04 10:05:13 --> Router Class Initialized
INFO - 2017-04-04 10:05:13 --> Output Class Initialized
INFO - 2017-04-04 10:05:13 --> Security Class Initialized
DEBUG - 2017-04-04 10:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:05:13 --> Input Class Initialized
INFO - 2017-04-04 10:05:13 --> Language Class Initialized
INFO - 2017-04-04 10:05:13 --> Loader Class Initialized
INFO - 2017-04-04 10:05:13 --> Helper loaded: url_helper
INFO - 2017-04-04 10:05:14 --> Helper loaded: language_helper
INFO - 2017-04-04 10:05:14 --> Helper loaded: html_helper
INFO - 2017-04-04 10:05:14 --> Helper loaded: form_helper
INFO - 2017-04-04 10:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:05:14 --> Controller Class Initialized
INFO - 2017-04-04 10:05:14 --> Database Driver Class Initialized
INFO - 2017-04-04 10:05:14 --> Model Class Initialized
INFO - 2017-04-04 10:05:14 --> Email Class Initialized
INFO - 2017-04-04 10:05:14 --> Form Validation Class Initialized
INFO - 2017-04-04 10:05:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:05:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:05:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:05:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:05:14 --> Final output sent to browser
DEBUG - 2017-04-04 10:05:14 --> Total execution time: 0.1359
INFO - 2017-04-04 10:05:26 --> Config Class Initialized
INFO - 2017-04-04 10:05:26 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:05:26 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:05:26 --> Utf8 Class Initialized
INFO - 2017-04-04 10:05:26 --> URI Class Initialized
INFO - 2017-04-04 10:05:26 --> Router Class Initialized
INFO - 2017-04-04 10:05:26 --> Output Class Initialized
INFO - 2017-04-04 10:05:26 --> Security Class Initialized
DEBUG - 2017-04-04 10:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:05:26 --> Input Class Initialized
INFO - 2017-04-04 10:05:26 --> Language Class Initialized
INFO - 2017-04-04 10:05:26 --> Loader Class Initialized
INFO - 2017-04-04 10:05:26 --> Helper loaded: url_helper
INFO - 2017-04-04 10:05:26 --> Helper loaded: language_helper
INFO - 2017-04-04 10:05:26 --> Helper loaded: html_helper
INFO - 2017-04-04 10:05:26 --> Helper loaded: form_helper
INFO - 2017-04-04 10:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:05:26 --> Controller Class Initialized
INFO - 2017-04-04 10:05:26 --> Database Driver Class Initialized
INFO - 2017-04-04 10:05:26 --> Model Class Initialized
INFO - 2017-04-04 10:05:26 --> Email Class Initialized
INFO - 2017-04-04 10:05:27 --> Form Validation Class Initialized
INFO - 2017-04-04 10:05:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:05:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:05:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:05:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:05:27 --> Final output sent to browser
DEBUG - 2017-04-04 10:05:27 --> Total execution time: 0.0806
INFO - 2017-04-04 10:12:29 --> Config Class Initialized
INFO - 2017-04-04 10:12:29 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:12:29 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:12:29 --> Utf8 Class Initialized
INFO - 2017-04-04 10:12:29 --> URI Class Initialized
INFO - 2017-04-04 10:12:29 --> Router Class Initialized
INFO - 2017-04-04 10:12:29 --> Output Class Initialized
INFO - 2017-04-04 10:12:29 --> Security Class Initialized
DEBUG - 2017-04-04 10:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:12:29 --> Input Class Initialized
INFO - 2017-04-04 10:12:29 --> Language Class Initialized
INFO - 2017-04-04 10:12:29 --> Loader Class Initialized
INFO - 2017-04-04 10:12:29 --> Helper loaded: url_helper
INFO - 2017-04-04 10:12:29 --> Helper loaded: language_helper
INFO - 2017-04-04 10:12:29 --> Helper loaded: html_helper
INFO - 2017-04-04 10:12:29 --> Helper loaded: form_helper
INFO - 2017-04-04 10:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:12:29 --> Controller Class Initialized
INFO - 2017-04-04 10:12:29 --> Database Driver Class Initialized
INFO - 2017-04-04 10:12:29 --> Model Class Initialized
INFO - 2017-04-04 10:12:29 --> Email Class Initialized
INFO - 2017-04-04 10:12:29 --> Form Validation Class Initialized
INFO - 2017-04-04 10:12:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:12:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:12:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:12:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:12:29 --> Final output sent to browser
DEBUG - 2017-04-04 10:12:29 --> Total execution time: 0.0825
INFO - 2017-04-04 10:13:14 --> Config Class Initialized
INFO - 2017-04-04 10:13:14 --> Hooks Class Initialized
DEBUG - 2017-04-04 10:13:14 --> UTF-8 Support Enabled
INFO - 2017-04-04 10:13:14 --> Utf8 Class Initialized
INFO - 2017-04-04 10:13:14 --> URI Class Initialized
INFO - 2017-04-04 10:13:14 --> Router Class Initialized
INFO - 2017-04-04 10:13:14 --> Output Class Initialized
INFO - 2017-04-04 10:13:14 --> Security Class Initialized
DEBUG - 2017-04-04 10:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-04 10:13:14 --> Input Class Initialized
INFO - 2017-04-04 10:13:14 --> Language Class Initialized
INFO - 2017-04-04 10:13:14 --> Loader Class Initialized
INFO - 2017-04-04 10:13:14 --> Helper loaded: url_helper
INFO - 2017-04-04 10:13:14 --> Helper loaded: language_helper
INFO - 2017-04-04 10:13:14 --> Helper loaded: html_helper
INFO - 2017-04-04 10:13:14 --> Helper loaded: form_helper
INFO - 2017-04-04 10:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-04 10:13:14 --> Controller Class Initialized
INFO - 2017-04-04 10:13:14 --> Database Driver Class Initialized
INFO - 2017-04-04 10:13:14 --> Model Class Initialized
INFO - 2017-04-04 10:13:14 --> Email Class Initialized
INFO - 2017-04-04 10:13:14 --> Form Validation Class Initialized
INFO - 2017-04-04 10:13:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-04 10:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-04 10:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-04 10:13:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-04 10:13:14 --> Final output sent to browser
DEBUG - 2017-04-04 10:13:14 --> Total execution time: 0.0780
