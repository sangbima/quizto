<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-06 14:38:05 --> Config Class Initialized
INFO - 2017-04-06 14:38:05 --> Hooks Class Initialized
DEBUG - 2017-04-06 14:38:05 --> UTF-8 Support Enabled
INFO - 2017-04-06 14:38:05 --> Utf8 Class Initialized
INFO - 2017-04-06 14:38:05 --> URI Class Initialized
INFO - 2017-04-06 14:38:05 --> Router Class Initialized
INFO - 2017-04-06 14:38:05 --> Output Class Initialized
INFO - 2017-04-06 14:38:05 --> Security Class Initialized
DEBUG - 2017-04-06 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-06 14:38:05 --> Input Class Initialized
INFO - 2017-04-06 14:38:05 --> Language Class Initialized
INFO - 2017-04-06 14:38:05 --> Loader Class Initialized
INFO - 2017-04-06 14:38:05 --> Helper loaded: url_helper
INFO - 2017-04-06 14:38:05 --> Helper loaded: language_helper
INFO - 2017-04-06 14:38:05 --> Helper loaded: html_helper
INFO - 2017-04-06 14:38:05 --> Helper loaded: form_helper
INFO - 2017-04-06 14:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-06 14:38:05 --> Controller Class Initialized
INFO - 2017-04-06 14:38:05 --> Database Driver Class Initialized
INFO - 2017-04-06 14:38:05 --> Model Class Initialized
INFO - 2017-04-06 14:38:05 --> Model Class Initialized
INFO - 2017-04-06 14:38:05 --> Model Class Initialized
INFO - 2017-04-06 14:38:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-06 14:38:05 --> Config Class Initialized
INFO - 2017-04-06 14:38:05 --> Hooks Class Initialized
DEBUG - 2017-04-06 14:38:05 --> UTF-8 Support Enabled
INFO - 2017-04-06 14:38:05 --> Utf8 Class Initialized
INFO - 2017-04-06 14:38:05 --> URI Class Initialized
INFO - 2017-04-06 14:38:05 --> Router Class Initialized
INFO - 2017-04-06 14:38:05 --> Output Class Initialized
INFO - 2017-04-06 14:38:05 --> Security Class Initialized
DEBUG - 2017-04-06 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-06 14:38:05 --> Input Class Initialized
INFO - 2017-04-06 14:38:05 --> Language Class Initialized
INFO - 2017-04-06 14:38:05 --> Loader Class Initialized
INFO - 2017-04-06 14:38:05 --> Helper loaded: url_helper
INFO - 2017-04-06 14:38:05 --> Helper loaded: language_helper
INFO - 2017-04-06 14:38:05 --> Helper loaded: html_helper
INFO - 2017-04-06 14:38:05 --> Helper loaded: form_helper
INFO - 2017-04-06 14:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-06 14:38:05 --> Controller Class Initialized
INFO - 2017-04-06 14:38:05 --> Database Driver Class Initialized
INFO - 2017-04-06 14:38:05 --> Model Class Initialized
INFO - 2017-04-06 14:38:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-06 14:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-06 14:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-06 14:38:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-06 14:38:05 --> Final output sent to browser
DEBUG - 2017-04-06 14:38:05 --> Total execution time: 0.1225
