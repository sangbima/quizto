<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-07 17:01:54 --> Config Class Initialized
INFO - 2017-04-07 17:01:54 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:01:54 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:01:54 --> Utf8 Class Initialized
INFO - 2017-04-07 17:01:54 --> URI Class Initialized
DEBUG - 2017-04-07 17:01:54 --> No URI present. Default controller set.
INFO - 2017-04-07 17:01:54 --> Router Class Initialized
INFO - 2017-04-07 17:01:54 --> Output Class Initialized
INFO - 2017-04-07 17:01:54 --> Security Class Initialized
DEBUG - 2017-04-07 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:01:54 --> Input Class Initialized
INFO - 2017-04-07 17:01:54 --> Language Class Initialized
INFO - 2017-04-07 17:01:54 --> Loader Class Initialized
INFO - 2017-04-07 17:01:54 --> Helper loaded: url_helper
INFO - 2017-04-07 17:01:54 --> Helper loaded: language_helper
INFO - 2017-04-07 17:01:54 --> Helper loaded: html_helper
INFO - 2017-04-07 17:01:54 --> Helper loaded: form_helper
INFO - 2017-04-07 17:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:01:54 --> Controller Class Initialized
INFO - 2017-04-07 17:01:54 --> Database Driver Class Initialized
INFO - 2017-04-07 17:01:54 --> Model Class Initialized
INFO - 2017-04-07 17:01:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:01:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-07 17:01:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-07 17:01:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-07 17:01:54 --> Final output sent to browser
DEBUG - 2017-04-07 17:01:54 --> Total execution time: 0.1170
INFO - 2017-04-07 17:08:47 --> Config Class Initialized
INFO - 2017-04-07 17:08:47 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:08:47 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:08:47 --> Utf8 Class Initialized
INFO - 2017-04-07 17:08:47 --> URI Class Initialized
INFO - 2017-04-07 17:08:47 --> Router Class Initialized
INFO - 2017-04-07 17:08:47 --> Output Class Initialized
INFO - 2017-04-07 17:08:47 --> Security Class Initialized
DEBUG - 2017-04-07 17:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:08:47 --> Input Class Initialized
INFO - 2017-04-07 17:08:47 --> Language Class Initialized
INFO - 2017-04-07 17:08:47 --> Loader Class Initialized
INFO - 2017-04-07 17:08:47 --> Helper loaded: url_helper
INFO - 2017-04-07 17:08:47 --> Helper loaded: language_helper
INFO - 2017-04-07 17:08:47 --> Helper loaded: html_helper
INFO - 2017-04-07 17:08:47 --> Helper loaded: form_helper
INFO - 2017-04-07 17:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:08:47 --> Controller Class Initialized
INFO - 2017-04-07 17:08:47 --> Database Driver Class Initialized
INFO - 2017-04-07 17:08:47 --> Model Class Initialized
INFO - 2017-04-07 17:08:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:08:47 --> Config Class Initialized
INFO - 2017-04-07 17:08:47 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:08:48 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:08:48 --> Utf8 Class Initialized
INFO - 2017-04-07 17:08:48 --> URI Class Initialized
INFO - 2017-04-07 17:08:48 --> Router Class Initialized
INFO - 2017-04-07 17:08:48 --> Output Class Initialized
INFO - 2017-04-07 17:08:48 --> Security Class Initialized
DEBUG - 2017-04-07 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:08:48 --> Input Class Initialized
INFO - 2017-04-07 17:08:48 --> Language Class Initialized
INFO - 2017-04-07 17:08:48 --> Loader Class Initialized
INFO - 2017-04-07 17:08:48 --> Helper loaded: url_helper
INFO - 2017-04-07 17:08:48 --> Helper loaded: language_helper
INFO - 2017-04-07 17:08:48 --> Helper loaded: html_helper
INFO - 2017-04-07 17:08:48 --> Helper loaded: form_helper
INFO - 2017-04-07 17:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:08:48 --> Controller Class Initialized
INFO - 2017-04-07 17:08:48 --> Database Driver Class Initialized
INFO - 2017-04-07 17:08:48 --> Model Class Initialized
INFO - 2017-04-07 17:08:48 --> Model Class Initialized
INFO - 2017-04-07 17:08:48 --> Model Class Initialized
INFO - 2017-04-07 17:08:48 --> Model Class Initialized
INFO - 2017-04-07 17:08:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:08:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:08:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-04-07 17:08:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:08:48 --> Final output sent to browser
DEBUG - 2017-04-07 17:08:48 --> Total execution time: 0.1258
INFO - 2017-04-07 17:08:51 --> Config Class Initialized
INFO - 2017-04-07 17:08:51 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:08:51 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:08:51 --> Utf8 Class Initialized
INFO - 2017-04-07 17:08:51 --> URI Class Initialized
INFO - 2017-04-07 17:08:51 --> Router Class Initialized
INFO - 2017-04-07 17:08:51 --> Output Class Initialized
INFO - 2017-04-07 17:08:51 --> Security Class Initialized
DEBUG - 2017-04-07 17:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:08:51 --> Input Class Initialized
INFO - 2017-04-07 17:08:51 --> Language Class Initialized
INFO - 2017-04-07 17:08:51 --> Loader Class Initialized
INFO - 2017-04-07 17:08:51 --> Helper loaded: url_helper
INFO - 2017-04-07 17:08:51 --> Helper loaded: language_helper
INFO - 2017-04-07 17:08:51 --> Helper loaded: html_helper
INFO - 2017-04-07 17:08:51 --> Helper loaded: form_helper
INFO - 2017-04-07 17:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:08:51 --> Controller Class Initialized
INFO - 2017-04-07 17:08:51 --> Database Driver Class Initialized
INFO - 2017-04-07 17:08:51 --> Model Class Initialized
INFO - 2017-04-07 17:08:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:08:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:08:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-07 17:08:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:08:51 --> Final output sent to browser
DEBUG - 2017-04-07 17:08:51 --> Total execution time: 0.1004
INFO - 2017-04-07 17:08:59 --> Config Class Initialized
INFO - 2017-04-07 17:08:59 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:08:59 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:08:59 --> Utf8 Class Initialized
INFO - 2017-04-07 17:08:59 --> URI Class Initialized
INFO - 2017-04-07 17:08:59 --> Router Class Initialized
INFO - 2017-04-07 17:08:59 --> Output Class Initialized
INFO - 2017-04-07 17:08:59 --> Security Class Initialized
DEBUG - 2017-04-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:08:59 --> Input Class Initialized
INFO - 2017-04-07 17:08:59 --> Language Class Initialized
INFO - 2017-04-07 17:08:59 --> Loader Class Initialized
INFO - 2017-04-07 17:08:59 --> Helper loaded: url_helper
INFO - 2017-04-07 17:08:59 --> Helper loaded: language_helper
INFO - 2017-04-07 17:08:59 --> Helper loaded: html_helper
INFO - 2017-04-07 17:08:59 --> Helper loaded: form_helper
INFO - 2017-04-07 17:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:08:59 --> Controller Class Initialized
INFO - 2017-04-07 17:08:59 --> Database Driver Class Initialized
INFO - 2017-04-07 17:08:59 --> Model Class Initialized
INFO - 2017-04-07 17:08:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:08:59 --> Config Class Initialized
INFO - 2017-04-07 17:08:59 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:08:59 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:08:59 --> Utf8 Class Initialized
INFO - 2017-04-07 17:08:59 --> URI Class Initialized
INFO - 2017-04-07 17:08:59 --> Router Class Initialized
INFO - 2017-04-07 17:08:59 --> Output Class Initialized
INFO - 2017-04-07 17:08:59 --> Security Class Initialized
DEBUG - 2017-04-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:08:59 --> Input Class Initialized
INFO - 2017-04-07 17:08:59 --> Language Class Initialized
INFO - 2017-04-07 17:08:59 --> Loader Class Initialized
INFO - 2017-04-07 17:08:59 --> Helper loaded: url_helper
INFO - 2017-04-07 17:08:59 --> Helper loaded: language_helper
INFO - 2017-04-07 17:08:59 --> Helper loaded: html_helper
INFO - 2017-04-07 17:08:59 --> Helper loaded: form_helper
INFO - 2017-04-07 17:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:08:59 --> Controller Class Initialized
INFO - 2017-04-07 17:08:59 --> Database Driver Class Initialized
INFO - 2017-04-07 17:08:59 --> Model Class Initialized
INFO - 2017-04-07 17:08:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:08:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:08:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\question_list.php
INFO - 2017-04-07 17:08:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:08:59 --> Final output sent to browser
DEBUG - 2017-04-07 17:08:59 --> Total execution time: 0.0927
INFO - 2017-04-07 17:09:02 --> Config Class Initialized
INFO - 2017-04-07 17:09:02 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:09:02 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:09:02 --> Utf8 Class Initialized
INFO - 2017-04-07 17:09:02 --> URI Class Initialized
INFO - 2017-04-07 17:09:02 --> Router Class Initialized
INFO - 2017-04-07 17:09:02 --> Output Class Initialized
INFO - 2017-04-07 17:09:02 --> Security Class Initialized
DEBUG - 2017-04-07 17:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:09:02 --> Input Class Initialized
INFO - 2017-04-07 17:09:02 --> Language Class Initialized
INFO - 2017-04-07 17:09:02 --> Loader Class Initialized
INFO - 2017-04-07 17:09:02 --> Helper loaded: url_helper
INFO - 2017-04-07 17:09:02 --> Helper loaded: language_helper
INFO - 2017-04-07 17:09:02 --> Helper loaded: html_helper
INFO - 2017-04-07 17:09:02 --> Helper loaded: form_helper
INFO - 2017-04-07 17:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:09:02 --> Controller Class Initialized
INFO - 2017-04-07 17:09:02 --> Database Driver Class Initialized
INFO - 2017-04-07 17:09:02 --> Model Class Initialized
INFO - 2017-04-07 17:09:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:09:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:09:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\edit_question_1.php
INFO - 2017-04-07 17:09:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:09:02 --> Final output sent to browser
DEBUG - 2017-04-07 17:09:02 --> Total execution time: 0.1528
INFO - 2017-04-07 17:20:33 --> Config Class Initialized
INFO - 2017-04-07 17:20:33 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:20:33 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:20:33 --> Utf8 Class Initialized
INFO - 2017-04-07 17:20:33 --> URI Class Initialized
INFO - 2017-04-07 17:20:33 --> Router Class Initialized
INFO - 2017-04-07 17:20:33 --> Output Class Initialized
INFO - 2017-04-07 17:20:33 --> Security Class Initialized
DEBUG - 2017-04-07 17:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:20:33 --> Input Class Initialized
INFO - 2017-04-07 17:20:33 --> Language Class Initialized
INFO - 2017-04-07 17:20:33 --> Loader Class Initialized
INFO - 2017-04-07 17:20:33 --> Helper loaded: url_helper
INFO - 2017-04-07 17:20:33 --> Helper loaded: language_helper
INFO - 2017-04-07 17:20:33 --> Helper loaded: html_helper
INFO - 2017-04-07 17:20:33 --> Helper loaded: form_helper
INFO - 2017-04-07 17:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:20:33 --> Controller Class Initialized
INFO - 2017-04-07 17:20:33 --> Database Driver Class Initialized
INFO - 2017-04-07 17:20:33 --> Model Class Initialized
INFO - 2017-04-07 17:20:33 --> Model Class Initialized
INFO - 2017-04-07 17:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:20:33 --> Config Class Initialized
INFO - 2017-04-07 17:20:33 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:20:33 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:20:33 --> Utf8 Class Initialized
INFO - 2017-04-07 17:20:33 --> URI Class Initialized
INFO - 2017-04-07 17:20:33 --> Router Class Initialized
INFO - 2017-04-07 17:20:33 --> Output Class Initialized
INFO - 2017-04-07 17:20:33 --> Security Class Initialized
DEBUG - 2017-04-07 17:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:20:33 --> Input Class Initialized
INFO - 2017-04-07 17:20:33 --> Language Class Initialized
INFO - 2017-04-07 17:20:33 --> Loader Class Initialized
INFO - 2017-04-07 17:20:33 --> Helper loaded: url_helper
INFO - 2017-04-07 17:20:33 --> Helper loaded: language_helper
INFO - 2017-04-07 17:20:33 --> Helper loaded: html_helper
INFO - 2017-04-07 17:20:33 --> Helper loaded: form_helper
INFO - 2017-04-07 17:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:20:33 --> Controller Class Initialized
INFO - 2017-04-07 17:20:33 --> Database Driver Class Initialized
INFO - 2017-04-07 17:20:33 --> Model Class Initialized
INFO - 2017-04-07 17:20:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-07 17:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-07 17:20:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-07 17:20:33 --> Final output sent to browser
DEBUG - 2017-04-07 17:20:33 --> Total execution time: 0.0715
INFO - 2017-04-07 17:23:36 --> Config Class Initialized
INFO - 2017-04-07 17:23:36 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:23:36 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:23:36 --> Utf8 Class Initialized
INFO - 2017-04-07 17:23:36 --> URI Class Initialized
INFO - 2017-04-07 17:23:36 --> Router Class Initialized
INFO - 2017-04-07 17:23:36 --> Output Class Initialized
INFO - 2017-04-07 17:23:36 --> Security Class Initialized
DEBUG - 2017-04-07 17:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:23:36 --> Input Class Initialized
INFO - 2017-04-07 17:23:36 --> Language Class Initialized
INFO - 2017-04-07 17:23:36 --> Loader Class Initialized
INFO - 2017-04-07 17:23:36 --> Helper loaded: url_helper
INFO - 2017-04-07 17:23:36 --> Helper loaded: language_helper
INFO - 2017-04-07 17:23:36 --> Helper loaded: html_helper
INFO - 2017-04-07 17:23:36 --> Helper loaded: form_helper
INFO - 2017-04-07 17:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:23:36 --> Controller Class Initialized
INFO - 2017-04-07 17:23:36 --> Database Driver Class Initialized
INFO - 2017-04-07 17:23:36 --> Model Class Initialized
INFO - 2017-04-07 17:23:36 --> Email Class Initialized
INFO - 2017-04-07 17:23:36 --> Form Validation Class Initialized
INFO - 2017-04-07 17:23:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:23:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:23:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 17:23:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:23:36 --> Final output sent to browser
DEBUG - 2017-04-07 17:23:36 --> Total execution time: 0.0925
INFO - 2017-04-07 17:25:58 --> Config Class Initialized
INFO - 2017-04-07 17:25:58 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:25:58 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:25:58 --> Utf8 Class Initialized
INFO - 2017-04-07 17:25:58 --> URI Class Initialized
INFO - 2017-04-07 17:25:58 --> Router Class Initialized
INFO - 2017-04-07 17:25:58 --> Output Class Initialized
INFO - 2017-04-07 17:25:58 --> Security Class Initialized
DEBUG - 2017-04-07 17:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:25:58 --> Input Class Initialized
INFO - 2017-04-07 17:25:58 --> Language Class Initialized
INFO - 2017-04-07 17:25:58 --> Loader Class Initialized
INFO - 2017-04-07 17:25:58 --> Helper loaded: url_helper
INFO - 2017-04-07 17:25:58 --> Helper loaded: language_helper
INFO - 2017-04-07 17:25:58 --> Helper loaded: html_helper
INFO - 2017-04-07 17:25:58 --> Helper loaded: form_helper
INFO - 2017-04-07 17:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:25:58 --> Controller Class Initialized
INFO - 2017-04-07 17:25:58 --> Database Driver Class Initialized
INFO - 2017-04-07 17:25:58 --> Model Class Initialized
INFO - 2017-04-07 17:25:58 --> Email Class Initialized
INFO - 2017-04-07 17:25:58 --> Form Validation Class Initialized
INFO - 2017-04-07 17:25:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:25:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:25:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 17:25:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:25:58 --> Final output sent to browser
DEBUG - 2017-04-07 17:25:58 --> Total execution time: 0.0813
INFO - 2017-04-07 17:29:20 --> Config Class Initialized
INFO - 2017-04-07 17:29:20 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:29:20 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:29:20 --> Utf8 Class Initialized
INFO - 2017-04-07 17:29:20 --> URI Class Initialized
INFO - 2017-04-07 17:29:20 --> Router Class Initialized
INFO - 2017-04-07 17:29:20 --> Output Class Initialized
INFO - 2017-04-07 17:29:20 --> Security Class Initialized
DEBUG - 2017-04-07 17:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:29:20 --> Input Class Initialized
INFO - 2017-04-07 17:29:20 --> Language Class Initialized
INFO - 2017-04-07 17:29:20 --> Loader Class Initialized
INFO - 2017-04-07 17:29:20 --> Helper loaded: url_helper
INFO - 2017-04-07 17:29:20 --> Helper loaded: language_helper
INFO - 2017-04-07 17:29:20 --> Helper loaded: html_helper
INFO - 2017-04-07 17:29:20 --> Helper loaded: form_helper
INFO - 2017-04-07 17:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:29:20 --> Controller Class Initialized
INFO - 2017-04-07 17:29:20 --> Database Driver Class Initialized
INFO - 2017-04-07 17:29:20 --> Model Class Initialized
INFO - 2017-04-07 17:29:20 --> Email Class Initialized
INFO - 2017-04-07 17:29:20 --> Form Validation Class Initialized
INFO - 2017-04-07 17:29:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:29:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:29:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 17:29:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:29:20 --> Final output sent to browser
DEBUG - 2017-04-07 17:29:20 --> Total execution time: 0.0983
INFO - 2017-04-07 17:32:40 --> Config Class Initialized
INFO - 2017-04-07 17:32:40 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:32:40 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:32:40 --> Utf8 Class Initialized
INFO - 2017-04-07 17:32:40 --> URI Class Initialized
INFO - 2017-04-07 17:32:40 --> Router Class Initialized
INFO - 2017-04-07 17:32:40 --> Output Class Initialized
INFO - 2017-04-07 17:32:40 --> Security Class Initialized
DEBUG - 2017-04-07 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:32:40 --> Input Class Initialized
INFO - 2017-04-07 17:32:40 --> Language Class Initialized
INFO - 2017-04-07 17:32:40 --> Loader Class Initialized
INFO - 2017-04-07 17:32:40 --> Helper loaded: url_helper
INFO - 2017-04-07 17:32:40 --> Helper loaded: language_helper
INFO - 2017-04-07 17:32:40 --> Helper loaded: html_helper
INFO - 2017-04-07 17:32:40 --> Helper loaded: form_helper
INFO - 2017-04-07 17:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:32:40 --> Controller Class Initialized
INFO - 2017-04-07 17:32:40 --> Database Driver Class Initialized
INFO - 2017-04-07 17:32:40 --> Model Class Initialized
INFO - 2017-04-07 17:32:40 --> Email Class Initialized
INFO - 2017-04-07 17:32:40 --> Form Validation Class Initialized
INFO - 2017-04-07 17:32:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 17:32:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:32:40 --> Final output sent to browser
DEBUG - 2017-04-07 17:32:40 --> Total execution time: 0.0866
INFO - 2017-04-07 17:43:27 --> Config Class Initialized
INFO - 2017-04-07 17:43:27 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:43:27 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:43:27 --> Utf8 Class Initialized
INFO - 2017-04-07 17:43:27 --> URI Class Initialized
INFO - 2017-04-07 17:43:27 --> Router Class Initialized
INFO - 2017-04-07 17:43:27 --> Output Class Initialized
INFO - 2017-04-07 17:43:27 --> Security Class Initialized
DEBUG - 2017-04-07 17:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:43:27 --> Input Class Initialized
INFO - 2017-04-07 17:43:27 --> Language Class Initialized
INFO - 2017-04-07 17:43:27 --> Loader Class Initialized
INFO - 2017-04-07 17:43:27 --> Helper loaded: url_helper
INFO - 2017-04-07 17:43:27 --> Helper loaded: language_helper
INFO - 2017-04-07 17:43:27 --> Helper loaded: html_helper
INFO - 2017-04-07 17:43:27 --> Helper loaded: form_helper
INFO - 2017-04-07 17:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:43:27 --> Controller Class Initialized
INFO - 2017-04-07 17:43:27 --> Database Driver Class Initialized
INFO - 2017-04-07 17:43:27 --> Model Class Initialized
INFO - 2017-04-07 17:43:27 --> Email Class Initialized
INFO - 2017-04-07 17:43:27 --> Form Validation Class Initialized
INFO - 2017-04-07 17:43:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:43:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:43:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 17:43:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:43:27 --> Final output sent to browser
DEBUG - 2017-04-07 17:43:27 --> Total execution time: 0.0927
INFO - 2017-04-07 17:46:07 --> Config Class Initialized
INFO - 2017-04-07 17:46:07 --> Hooks Class Initialized
DEBUG - 2017-04-07 17:46:07 --> UTF-8 Support Enabled
INFO - 2017-04-07 17:46:07 --> Utf8 Class Initialized
INFO - 2017-04-07 17:46:07 --> URI Class Initialized
INFO - 2017-04-07 17:46:07 --> Router Class Initialized
INFO - 2017-04-07 17:46:07 --> Output Class Initialized
INFO - 2017-04-07 17:46:07 --> Security Class Initialized
DEBUG - 2017-04-07 17:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 17:46:07 --> Input Class Initialized
INFO - 2017-04-07 17:46:07 --> Language Class Initialized
INFO - 2017-04-07 17:46:07 --> Loader Class Initialized
INFO - 2017-04-07 17:46:07 --> Helper loaded: url_helper
INFO - 2017-04-07 17:46:07 --> Helper loaded: language_helper
INFO - 2017-04-07 17:46:07 --> Helper loaded: html_helper
INFO - 2017-04-07 17:46:07 --> Helper loaded: form_helper
INFO - 2017-04-07 17:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 17:46:07 --> Controller Class Initialized
INFO - 2017-04-07 17:46:07 --> Database Driver Class Initialized
INFO - 2017-04-07 17:46:07 --> Model Class Initialized
INFO - 2017-04-07 17:46:07 --> Email Class Initialized
INFO - 2017-04-07 17:46:07 --> Form Validation Class Initialized
INFO - 2017-04-07 17:46:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 17:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 17:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 17:46:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 17:46:07 --> Final output sent to browser
DEBUG - 2017-04-07 17:46:07 --> Total execution time: 0.0875
INFO - 2017-04-07 21:54:07 --> Config Class Initialized
INFO - 2017-04-07 21:54:07 --> Hooks Class Initialized
DEBUG - 2017-04-07 21:54:07 --> UTF-8 Support Enabled
INFO - 2017-04-07 21:54:07 --> Utf8 Class Initialized
INFO - 2017-04-07 21:54:07 --> URI Class Initialized
INFO - 2017-04-07 21:54:07 --> Router Class Initialized
INFO - 2017-04-07 21:54:07 --> Output Class Initialized
INFO - 2017-04-07 21:54:07 --> Security Class Initialized
DEBUG - 2017-04-07 21:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 21:54:07 --> Input Class Initialized
INFO - 2017-04-07 21:54:07 --> Language Class Initialized
INFO - 2017-04-07 21:54:07 --> Loader Class Initialized
INFO - 2017-04-07 21:54:07 --> Helper loaded: url_helper
INFO - 2017-04-07 21:54:07 --> Helper loaded: language_helper
INFO - 2017-04-07 21:54:07 --> Helper loaded: html_helper
INFO - 2017-04-07 21:54:07 --> Helper loaded: form_helper
INFO - 2017-04-07 21:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 21:54:07 --> Controller Class Initialized
INFO - 2017-04-07 21:54:08 --> Database Driver Class Initialized
INFO - 2017-04-07 21:54:08 --> Model Class Initialized
INFO - 2017-04-07 21:54:08 --> Email Class Initialized
INFO - 2017-04-07 21:54:08 --> Form Validation Class Initialized
INFO - 2017-04-07 21:54:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 21:54:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 21:54:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 21:54:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 21:54:08 --> Final output sent to browser
DEBUG - 2017-04-07 21:54:08 --> Total execution time: 0.1146
INFO - 2017-04-07 21:54:45 --> Config Class Initialized
INFO - 2017-04-07 21:54:45 --> Hooks Class Initialized
DEBUG - 2017-04-07 21:54:45 --> UTF-8 Support Enabled
INFO - 2017-04-07 21:54:45 --> Utf8 Class Initialized
INFO - 2017-04-07 21:54:45 --> URI Class Initialized
INFO - 2017-04-07 21:54:45 --> Router Class Initialized
INFO - 2017-04-07 21:54:45 --> Output Class Initialized
INFO - 2017-04-07 21:54:45 --> Security Class Initialized
DEBUG - 2017-04-07 21:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 21:54:45 --> Input Class Initialized
INFO - 2017-04-07 21:54:45 --> Language Class Initialized
INFO - 2017-04-07 21:54:45 --> Loader Class Initialized
INFO - 2017-04-07 21:54:45 --> Helper loaded: url_helper
INFO - 2017-04-07 21:54:45 --> Helper loaded: language_helper
INFO - 2017-04-07 21:54:45 --> Helper loaded: html_helper
INFO - 2017-04-07 21:54:45 --> Helper loaded: form_helper
INFO - 2017-04-07 21:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 21:54:45 --> Controller Class Initialized
INFO - 2017-04-07 21:54:45 --> Database Driver Class Initialized
INFO - 2017-04-07 21:54:45 --> Model Class Initialized
INFO - 2017-04-07 21:54:45 --> Email Class Initialized
INFO - 2017-04-07 21:54:45 --> Form Validation Class Initialized
INFO - 2017-04-07 21:54:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 21:54:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 21:54:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 21:54:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 21:54:45 --> Final output sent to browser
DEBUG - 2017-04-07 21:54:45 --> Total execution time: 0.1010
INFO - 2017-04-07 21:55:36 --> Config Class Initialized
INFO - 2017-04-07 21:55:36 --> Hooks Class Initialized
DEBUG - 2017-04-07 21:55:36 --> UTF-8 Support Enabled
INFO - 2017-04-07 21:55:36 --> Utf8 Class Initialized
INFO - 2017-04-07 21:55:36 --> URI Class Initialized
INFO - 2017-04-07 21:55:36 --> Router Class Initialized
INFO - 2017-04-07 21:55:36 --> Output Class Initialized
INFO - 2017-04-07 21:55:36 --> Security Class Initialized
DEBUG - 2017-04-07 21:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 21:55:36 --> Input Class Initialized
INFO - 2017-04-07 21:55:36 --> Language Class Initialized
INFO - 2017-04-07 21:55:36 --> Loader Class Initialized
INFO - 2017-04-07 21:55:36 --> Helper loaded: url_helper
INFO - 2017-04-07 21:55:36 --> Helper loaded: language_helper
INFO - 2017-04-07 21:55:36 --> Helper loaded: html_helper
INFO - 2017-04-07 21:55:36 --> Helper loaded: form_helper
INFO - 2017-04-07 21:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 21:55:36 --> Controller Class Initialized
INFO - 2017-04-07 21:55:36 --> Database Driver Class Initialized
INFO - 2017-04-07 21:55:36 --> Model Class Initialized
INFO - 2017-04-07 21:55:36 --> Email Class Initialized
INFO - 2017-04-07 21:55:36 --> Form Validation Class Initialized
INFO - 2017-04-07 21:55:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 21:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 21:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 21:55:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 21:55:36 --> Final output sent to browser
DEBUG - 2017-04-07 21:55:36 --> Total execution time: 0.0920
INFO - 2017-04-07 21:56:15 --> Config Class Initialized
INFO - 2017-04-07 21:56:15 --> Hooks Class Initialized
DEBUG - 2017-04-07 21:56:15 --> UTF-8 Support Enabled
INFO - 2017-04-07 21:56:15 --> Utf8 Class Initialized
INFO - 2017-04-07 21:56:15 --> URI Class Initialized
INFO - 2017-04-07 21:56:15 --> Router Class Initialized
INFO - 2017-04-07 21:56:15 --> Output Class Initialized
INFO - 2017-04-07 21:56:15 --> Security Class Initialized
DEBUG - 2017-04-07 21:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 21:56:15 --> Input Class Initialized
INFO - 2017-04-07 21:56:15 --> Language Class Initialized
INFO - 2017-04-07 21:56:15 --> Loader Class Initialized
INFO - 2017-04-07 21:56:15 --> Helper loaded: url_helper
INFO - 2017-04-07 21:56:15 --> Helper loaded: language_helper
INFO - 2017-04-07 21:56:15 --> Helper loaded: html_helper
INFO - 2017-04-07 21:56:15 --> Helper loaded: form_helper
INFO - 2017-04-07 21:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 21:56:15 --> Controller Class Initialized
INFO - 2017-04-07 21:56:15 --> Database Driver Class Initialized
INFO - 2017-04-07 21:56:15 --> Model Class Initialized
INFO - 2017-04-07 21:56:15 --> Email Class Initialized
INFO - 2017-04-07 21:56:15 --> Form Validation Class Initialized
INFO - 2017-04-07 21:56:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 21:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 21:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 21:56:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 21:56:15 --> Final output sent to browser
DEBUG - 2017-04-07 21:56:15 --> Total execution time: 0.0895
INFO - 2017-04-07 22:00:46 --> Config Class Initialized
INFO - 2017-04-07 22:00:46 --> Hooks Class Initialized
DEBUG - 2017-04-07 22:00:46 --> UTF-8 Support Enabled
INFO - 2017-04-07 22:00:46 --> Utf8 Class Initialized
INFO - 2017-04-07 22:00:46 --> URI Class Initialized
INFO - 2017-04-07 22:00:46 --> Router Class Initialized
INFO - 2017-04-07 22:00:46 --> Output Class Initialized
INFO - 2017-04-07 22:00:46 --> Security Class Initialized
DEBUG - 2017-04-07 22:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 22:00:46 --> Input Class Initialized
INFO - 2017-04-07 22:00:46 --> Language Class Initialized
INFO - 2017-04-07 22:00:46 --> Loader Class Initialized
INFO - 2017-04-07 22:00:46 --> Helper loaded: url_helper
INFO - 2017-04-07 22:00:46 --> Helper loaded: language_helper
INFO - 2017-04-07 22:00:46 --> Helper loaded: html_helper
INFO - 2017-04-07 22:00:46 --> Helper loaded: form_helper
INFO - 2017-04-07 22:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 22:00:46 --> Controller Class Initialized
INFO - 2017-04-07 22:00:46 --> Database Driver Class Initialized
INFO - 2017-04-07 22:00:46 --> Model Class Initialized
INFO - 2017-04-07 22:00:46 --> Email Class Initialized
INFO - 2017-04-07 22:00:46 --> Form Validation Class Initialized
INFO - 2017-04-07 22:00:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 22:00:46 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-04-07 22:00:46 --> Final output sent to browser
DEBUG - 2017-04-07 22:00:46 --> Total execution time: 0.1438
INFO - 2017-04-07 22:04:52 --> Config Class Initialized
INFO - 2017-04-07 22:04:52 --> Hooks Class Initialized
DEBUG - 2017-04-07 22:04:52 --> UTF-8 Support Enabled
INFO - 2017-04-07 22:04:52 --> Utf8 Class Initialized
INFO - 2017-04-07 22:04:52 --> URI Class Initialized
INFO - 2017-04-07 22:04:52 --> Router Class Initialized
INFO - 2017-04-07 22:04:52 --> Output Class Initialized
INFO - 2017-04-07 22:04:52 --> Security Class Initialized
DEBUG - 2017-04-07 22:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 22:04:52 --> Input Class Initialized
INFO - 2017-04-07 22:04:52 --> Language Class Initialized
INFO - 2017-04-07 22:04:52 --> Loader Class Initialized
INFO - 2017-04-07 22:04:52 --> Helper loaded: url_helper
INFO - 2017-04-07 22:04:52 --> Helper loaded: language_helper
INFO - 2017-04-07 22:04:52 --> Helper loaded: html_helper
INFO - 2017-04-07 22:04:52 --> Helper loaded: form_helper
INFO - 2017-04-07 22:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 22:04:52 --> Controller Class Initialized
INFO - 2017-04-07 22:04:52 --> Database Driver Class Initialized
INFO - 2017-04-07 22:04:52 --> Model Class Initialized
INFO - 2017-04-07 22:04:52 --> Email Class Initialized
INFO - 2017-04-07 22:04:52 --> Form Validation Class Initialized
INFO - 2017-04-07 22:04:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 22:04:52 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-04-07 22:04:52 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-04-07 22:04:53 --> Final output sent to browser
DEBUG - 2017-04-07 22:04:53 --> Total execution time: 1.5129
INFO - 2017-04-07 22:04:55 --> Config Class Initialized
INFO - 2017-04-07 22:04:55 --> Hooks Class Initialized
DEBUG - 2017-04-07 22:04:55 --> UTF-8 Support Enabled
INFO - 2017-04-07 22:04:55 --> Utf8 Class Initialized
INFO - 2017-04-07 22:04:55 --> URI Class Initialized
INFO - 2017-04-07 22:04:55 --> Router Class Initialized
INFO - 2017-04-07 22:04:55 --> Output Class Initialized
INFO - 2017-04-07 22:04:55 --> Security Class Initialized
DEBUG - 2017-04-07 22:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 22:04:55 --> Input Class Initialized
INFO - 2017-04-07 22:04:55 --> Language Class Initialized
INFO - 2017-04-07 22:04:55 --> Loader Class Initialized
INFO - 2017-04-07 22:04:55 --> Helper loaded: url_helper
INFO - 2017-04-07 22:04:55 --> Helper loaded: language_helper
INFO - 2017-04-07 22:04:55 --> Helper loaded: html_helper
INFO - 2017-04-07 22:04:55 --> Helper loaded: form_helper
INFO - 2017-04-07 22:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 22:04:55 --> Controller Class Initialized
INFO - 2017-04-07 22:04:55 --> Database Driver Class Initialized
INFO - 2017-04-07 22:04:55 --> Model Class Initialized
INFO - 2017-04-07 22:04:55 --> Email Class Initialized
INFO - 2017-04-07 22:04:55 --> Form Validation Class Initialized
INFO - 2017-04-07 22:04:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 22:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 22:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-04-07 22:04:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 22:04:55 --> Final output sent to browser
DEBUG - 2017-04-07 22:04:55 --> Total execution time: 0.1006
INFO - 2017-04-07 22:04:57 --> Config Class Initialized
INFO - 2017-04-07 22:04:57 --> Hooks Class Initialized
DEBUG - 2017-04-07 22:04:57 --> UTF-8 Support Enabled
INFO - 2017-04-07 22:04:57 --> Utf8 Class Initialized
INFO - 2017-04-07 22:04:57 --> URI Class Initialized
DEBUG - 2017-04-07 22:04:57 --> No URI present. Default controller set.
INFO - 2017-04-07 22:04:57 --> Router Class Initialized
INFO - 2017-04-07 22:04:57 --> Output Class Initialized
INFO - 2017-04-07 22:04:57 --> Security Class Initialized
DEBUG - 2017-04-07 22:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 22:04:57 --> Input Class Initialized
INFO - 2017-04-07 22:04:57 --> Language Class Initialized
INFO - 2017-04-07 22:04:57 --> Loader Class Initialized
INFO - 2017-04-07 22:04:57 --> Helper loaded: url_helper
INFO - 2017-04-07 22:04:57 --> Helper loaded: language_helper
INFO - 2017-04-07 22:04:57 --> Helper loaded: html_helper
INFO - 2017-04-07 22:04:57 --> Helper loaded: form_helper
INFO - 2017-04-07 22:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 22:04:57 --> Controller Class Initialized
INFO - 2017-04-07 22:04:57 --> Database Driver Class Initialized
INFO - 2017-04-07 22:04:57 --> Model Class Initialized
INFO - 2017-04-07 22:04:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 22:04:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-07 22:04:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-07 22:04:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-07 22:04:57 --> Final output sent to browser
DEBUG - 2017-04-07 22:04:57 --> Total execution time: 0.0711
INFO - 2017-04-07 22:05:33 --> Config Class Initialized
INFO - 2017-04-07 22:05:33 --> Hooks Class Initialized
DEBUG - 2017-04-07 22:05:33 --> UTF-8 Support Enabled
INFO - 2017-04-07 22:05:33 --> Utf8 Class Initialized
INFO - 2017-04-07 22:05:33 --> URI Class Initialized
INFO - 2017-04-07 22:05:33 --> Router Class Initialized
INFO - 2017-04-07 22:05:33 --> Output Class Initialized
INFO - 2017-04-07 22:05:33 --> Security Class Initialized
DEBUG - 2017-04-07 22:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 22:05:33 --> Input Class Initialized
INFO - 2017-04-07 22:05:33 --> Language Class Initialized
INFO - 2017-04-07 22:05:33 --> Loader Class Initialized
INFO - 2017-04-07 22:05:33 --> Helper loaded: url_helper
INFO - 2017-04-07 22:05:33 --> Helper loaded: language_helper
INFO - 2017-04-07 22:05:33 --> Helper loaded: html_helper
INFO - 2017-04-07 22:05:33 --> Helper loaded: form_helper
INFO - 2017-04-07 22:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 22:05:33 --> Controller Class Initialized
INFO - 2017-04-07 22:05:33 --> Database Driver Class Initialized
INFO - 2017-04-07 22:05:33 --> Model Class Initialized
INFO - 2017-04-07 22:05:33 --> Email Class Initialized
INFO - 2017-04-07 22:05:33 --> Form Validation Class Initialized
INFO - 2017-04-07 22:05:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 22:05:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 22:05:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 22:05:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 22:05:33 --> Final output sent to browser
DEBUG - 2017-04-07 22:05:33 --> Total execution time: 0.1005
INFO - 2017-04-07 22:07:30 --> Config Class Initialized
INFO - 2017-04-07 22:07:30 --> Hooks Class Initialized
DEBUG - 2017-04-07 22:07:30 --> UTF-8 Support Enabled
INFO - 2017-04-07 22:07:30 --> Utf8 Class Initialized
INFO - 2017-04-07 22:07:30 --> URI Class Initialized
DEBUG - 2017-04-07 22:07:30 --> No URI present. Default controller set.
INFO - 2017-04-07 22:07:30 --> Router Class Initialized
INFO - 2017-04-07 22:07:30 --> Output Class Initialized
INFO - 2017-04-07 22:07:30 --> Security Class Initialized
DEBUG - 2017-04-07 22:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 22:07:30 --> Input Class Initialized
INFO - 2017-04-07 22:07:30 --> Language Class Initialized
INFO - 2017-04-07 22:07:30 --> Loader Class Initialized
INFO - 2017-04-07 22:07:30 --> Helper loaded: url_helper
INFO - 2017-04-07 22:07:30 --> Helper loaded: language_helper
INFO - 2017-04-07 22:07:30 --> Helper loaded: html_helper
INFO - 2017-04-07 22:07:30 --> Helper loaded: form_helper
INFO - 2017-04-07 22:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 22:07:30 --> Controller Class Initialized
INFO - 2017-04-07 22:07:30 --> Database Driver Class Initialized
INFO - 2017-04-07 22:07:30 --> Model Class Initialized
INFO - 2017-04-07 22:07:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 22:07:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-07 22:07:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-07 22:07:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-07 22:07:30 --> Final output sent to browser
DEBUG - 2017-04-07 22:07:30 --> Total execution time: 0.0694
INFO - 2017-04-07 23:05:52 --> Config Class Initialized
INFO - 2017-04-07 23:05:52 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:05:52 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:05:52 --> Utf8 Class Initialized
INFO - 2017-04-07 23:05:52 --> URI Class Initialized
DEBUG - 2017-04-07 23:05:52 --> No URI present. Default controller set.
INFO - 2017-04-07 23:05:52 --> Router Class Initialized
INFO - 2017-04-07 23:05:52 --> Output Class Initialized
INFO - 2017-04-07 23:05:52 --> Security Class Initialized
DEBUG - 2017-04-07 23:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:05:52 --> Input Class Initialized
INFO - 2017-04-07 23:05:52 --> Language Class Initialized
INFO - 2017-04-07 23:05:52 --> Loader Class Initialized
INFO - 2017-04-07 23:05:52 --> Helper loaded: url_helper
INFO - 2017-04-07 23:05:52 --> Helper loaded: language_helper
INFO - 2017-04-07 23:05:52 --> Helper loaded: html_helper
INFO - 2017-04-07 23:05:52 --> Helper loaded: form_helper
INFO - 2017-04-07 23:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:05:52 --> Controller Class Initialized
INFO - 2017-04-07 23:05:52 --> Database Driver Class Initialized
INFO - 2017-04-07 23:05:52 --> Model Class Initialized
INFO - 2017-04-07 23:05:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:05:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-07 23:05:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-07 23:05:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-07 23:05:52 --> Final output sent to browser
DEBUG - 2017-04-07 23:05:52 --> Total execution time: 0.0844
INFO - 2017-04-07 23:05:53 --> Config Class Initialized
INFO - 2017-04-07 23:05:53 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:05:53 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:05:53 --> Utf8 Class Initialized
INFO - 2017-04-07 23:05:53 --> URI Class Initialized
INFO - 2017-04-07 23:05:53 --> Router Class Initialized
INFO - 2017-04-07 23:05:53 --> Output Class Initialized
INFO - 2017-04-07 23:05:53 --> Security Class Initialized
DEBUG - 2017-04-07 23:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:05:53 --> Input Class Initialized
INFO - 2017-04-07 23:05:53 --> Language Class Initialized
INFO - 2017-04-07 23:05:53 --> Loader Class Initialized
INFO - 2017-04-07 23:05:53 --> Helper loaded: url_helper
INFO - 2017-04-07 23:05:53 --> Helper loaded: language_helper
INFO - 2017-04-07 23:05:53 --> Helper loaded: html_helper
INFO - 2017-04-07 23:05:53 --> Helper loaded: form_helper
INFO - 2017-04-07 23:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:05:53 --> Controller Class Initialized
INFO - 2017-04-07 23:05:53 --> Database Driver Class Initialized
INFO - 2017-04-07 23:05:53 --> Model Class Initialized
INFO - 2017-04-07 23:05:53 --> Model Class Initialized
INFO - 2017-04-07 23:05:53 --> Model Class Initialized
INFO - 2017-04-07 23:05:53 --> Email Class Initialized
INFO - 2017-04-07 23:05:53 --> Form Validation Class Initialized
INFO - 2017-04-07 23:05:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:05:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:05:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:05:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:05:53 --> Final output sent to browser
DEBUG - 2017-04-07 23:05:53 --> Total execution time: 0.1141
INFO - 2017-04-07 23:08:31 --> Config Class Initialized
INFO - 2017-04-07 23:08:31 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:08:31 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:08:31 --> Utf8 Class Initialized
INFO - 2017-04-07 23:08:31 --> URI Class Initialized
INFO - 2017-04-07 23:08:31 --> Router Class Initialized
INFO - 2017-04-07 23:08:31 --> Output Class Initialized
INFO - 2017-04-07 23:08:31 --> Security Class Initialized
DEBUG - 2017-04-07 23:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:08:31 --> Input Class Initialized
INFO - 2017-04-07 23:08:31 --> Language Class Initialized
INFO - 2017-04-07 23:08:31 --> Loader Class Initialized
INFO - 2017-04-07 23:08:31 --> Helper loaded: url_helper
INFO - 2017-04-07 23:08:31 --> Helper loaded: language_helper
INFO - 2017-04-07 23:08:31 --> Helper loaded: html_helper
INFO - 2017-04-07 23:08:31 --> Helper loaded: form_helper
INFO - 2017-04-07 23:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:08:31 --> Controller Class Initialized
INFO - 2017-04-07 23:08:31 --> Database Driver Class Initialized
INFO - 2017-04-07 23:08:31 --> Model Class Initialized
INFO - 2017-04-07 23:08:31 --> Model Class Initialized
INFO - 2017-04-07 23:08:31 --> Model Class Initialized
INFO - 2017-04-07 23:08:31 --> Email Class Initialized
INFO - 2017-04-07 23:08:31 --> Form Validation Class Initialized
INFO - 2017-04-07 23:08:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-07 23:08:31 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\wamp64\www\savsoftquiz\system\helpers\form_helper.php 409
INFO - 2017-04-07 23:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:08:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:08:31 --> Final output sent to browser
DEBUG - 2017-04-07 23:08:31 --> Total execution time: 0.0925
INFO - 2017-04-07 23:09:47 --> Config Class Initialized
INFO - 2017-04-07 23:09:47 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:09:47 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:09:47 --> Utf8 Class Initialized
INFO - 2017-04-07 23:09:47 --> URI Class Initialized
INFO - 2017-04-07 23:09:47 --> Router Class Initialized
INFO - 2017-04-07 23:09:47 --> Output Class Initialized
INFO - 2017-04-07 23:09:47 --> Security Class Initialized
DEBUG - 2017-04-07 23:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:09:47 --> Input Class Initialized
INFO - 2017-04-07 23:09:47 --> Language Class Initialized
INFO - 2017-04-07 23:09:47 --> Loader Class Initialized
INFO - 2017-04-07 23:09:47 --> Helper loaded: url_helper
INFO - 2017-04-07 23:09:47 --> Helper loaded: language_helper
INFO - 2017-04-07 23:09:47 --> Helper loaded: html_helper
INFO - 2017-04-07 23:09:47 --> Helper loaded: form_helper
INFO - 2017-04-07 23:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:09:47 --> Controller Class Initialized
INFO - 2017-04-07 23:09:47 --> Database Driver Class Initialized
INFO - 2017-04-07 23:09:47 --> Model Class Initialized
INFO - 2017-04-07 23:09:47 --> Model Class Initialized
INFO - 2017-04-07 23:09:47 --> Model Class Initialized
INFO - 2017-04-07 23:09:47 --> Email Class Initialized
INFO - 2017-04-07 23:09:47 --> Form Validation Class Initialized
INFO - 2017-04-07 23:09:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:11:01 --> Config Class Initialized
INFO - 2017-04-07 23:11:01 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:11:01 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:11:01 --> Utf8 Class Initialized
INFO - 2017-04-07 23:11:01 --> URI Class Initialized
INFO - 2017-04-07 23:11:01 --> Router Class Initialized
INFO - 2017-04-07 23:11:01 --> Output Class Initialized
INFO - 2017-04-07 23:11:01 --> Security Class Initialized
DEBUG - 2017-04-07 23:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:11:01 --> Input Class Initialized
INFO - 2017-04-07 23:11:01 --> Language Class Initialized
INFO - 2017-04-07 23:11:01 --> Loader Class Initialized
INFO - 2017-04-07 23:11:01 --> Helper loaded: url_helper
INFO - 2017-04-07 23:11:01 --> Helper loaded: language_helper
INFO - 2017-04-07 23:11:01 --> Helper loaded: html_helper
INFO - 2017-04-07 23:11:01 --> Helper loaded: form_helper
INFO - 2017-04-07 23:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:11:01 --> Controller Class Initialized
INFO - 2017-04-07 23:11:01 --> Database Driver Class Initialized
INFO - 2017-04-07 23:11:01 --> Model Class Initialized
INFO - 2017-04-07 23:11:01 --> Model Class Initialized
INFO - 2017-04-07 23:11:01 --> Model Class Initialized
INFO - 2017-04-07 23:11:01 --> Email Class Initialized
INFO - 2017-04-07 23:11:01 --> Form Validation Class Initialized
INFO - 2017-04-07 23:11:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:11:02 --> Config Class Initialized
INFO - 2017-04-07 23:11:02 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:11:02 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:11:02 --> Utf8 Class Initialized
INFO - 2017-04-07 23:11:02 --> URI Class Initialized
INFO - 2017-04-07 23:11:02 --> Router Class Initialized
INFO - 2017-04-07 23:11:02 --> Output Class Initialized
INFO - 2017-04-07 23:11:02 --> Security Class Initialized
DEBUG - 2017-04-07 23:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:11:02 --> Input Class Initialized
INFO - 2017-04-07 23:11:02 --> Language Class Initialized
INFO - 2017-04-07 23:11:02 --> Loader Class Initialized
INFO - 2017-04-07 23:11:02 --> Helper loaded: url_helper
INFO - 2017-04-07 23:11:02 --> Helper loaded: language_helper
INFO - 2017-04-07 23:11:02 --> Helper loaded: html_helper
INFO - 2017-04-07 23:11:02 --> Helper loaded: form_helper
INFO - 2017-04-07 23:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:11:02 --> Controller Class Initialized
INFO - 2017-04-07 23:11:02 --> Database Driver Class Initialized
INFO - 2017-04-07 23:11:02 --> Model Class Initialized
INFO - 2017-04-07 23:11:02 --> Model Class Initialized
INFO - 2017-04-07 23:11:02 --> Model Class Initialized
INFO - 2017-04-07 23:11:02 --> Email Class Initialized
INFO - 2017-04-07 23:11:02 --> Form Validation Class Initialized
INFO - 2017-04-07 23:11:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:11:29 --> Config Class Initialized
INFO - 2017-04-07 23:11:29 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:11:29 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:11:29 --> Utf8 Class Initialized
INFO - 2017-04-07 23:11:29 --> URI Class Initialized
INFO - 2017-04-07 23:11:29 --> Router Class Initialized
INFO - 2017-04-07 23:11:29 --> Output Class Initialized
INFO - 2017-04-07 23:11:29 --> Security Class Initialized
DEBUG - 2017-04-07 23:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:11:29 --> Input Class Initialized
INFO - 2017-04-07 23:11:29 --> Language Class Initialized
INFO - 2017-04-07 23:11:29 --> Loader Class Initialized
INFO - 2017-04-07 23:11:29 --> Helper loaded: url_helper
INFO - 2017-04-07 23:11:29 --> Helper loaded: language_helper
INFO - 2017-04-07 23:11:29 --> Helper loaded: html_helper
INFO - 2017-04-07 23:11:29 --> Helper loaded: form_helper
INFO - 2017-04-07 23:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:11:29 --> Controller Class Initialized
INFO - 2017-04-07 23:11:29 --> Database Driver Class Initialized
INFO - 2017-04-07 23:11:29 --> Model Class Initialized
INFO - 2017-04-07 23:11:29 --> Model Class Initialized
INFO - 2017-04-07 23:11:29 --> Model Class Initialized
INFO - 2017-04-07 23:11:29 --> Email Class Initialized
INFO - 2017-04-07 23:11:29 --> Form Validation Class Initialized
INFO - 2017-04-07 23:11:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:11:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-07 23:11:29 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\wamp64\www\savsoftquiz\system\helpers\form_helper.php 409
INFO - 2017-04-07 23:11:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:11:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:11:29 --> Final output sent to browser
DEBUG - 2017-04-07 23:11:29 --> Total execution time: 0.1043
INFO - 2017-04-07 23:14:38 --> Config Class Initialized
INFO - 2017-04-07 23:14:38 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:14:38 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:14:38 --> Utf8 Class Initialized
INFO - 2017-04-07 23:14:38 --> URI Class Initialized
INFO - 2017-04-07 23:14:38 --> Router Class Initialized
INFO - 2017-04-07 23:14:38 --> Output Class Initialized
INFO - 2017-04-07 23:14:38 --> Security Class Initialized
DEBUG - 2017-04-07 23:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:14:38 --> Input Class Initialized
INFO - 2017-04-07 23:14:38 --> Language Class Initialized
INFO - 2017-04-07 23:14:38 --> Loader Class Initialized
INFO - 2017-04-07 23:14:38 --> Helper loaded: url_helper
INFO - 2017-04-07 23:14:38 --> Helper loaded: language_helper
INFO - 2017-04-07 23:14:38 --> Helper loaded: html_helper
INFO - 2017-04-07 23:14:38 --> Helper loaded: form_helper
INFO - 2017-04-07 23:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:14:38 --> Controller Class Initialized
INFO - 2017-04-07 23:14:38 --> Database Driver Class Initialized
INFO - 2017-04-07 23:14:38 --> Model Class Initialized
INFO - 2017-04-07 23:14:38 --> Model Class Initialized
INFO - 2017-04-07 23:14:38 --> Model Class Initialized
INFO - 2017-04-07 23:14:38 --> Email Class Initialized
INFO - 2017-04-07 23:14:38 --> Form Validation Class Initialized
INFO - 2017-04-07 23:14:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:15:40 --> Config Class Initialized
INFO - 2017-04-07 23:15:40 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:15:40 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:15:40 --> Utf8 Class Initialized
INFO - 2017-04-07 23:15:40 --> URI Class Initialized
INFO - 2017-04-07 23:15:40 --> Router Class Initialized
INFO - 2017-04-07 23:15:40 --> Output Class Initialized
INFO - 2017-04-07 23:15:40 --> Security Class Initialized
DEBUG - 2017-04-07 23:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:15:40 --> Input Class Initialized
INFO - 2017-04-07 23:15:40 --> Language Class Initialized
INFO - 2017-04-07 23:15:40 --> Loader Class Initialized
INFO - 2017-04-07 23:15:40 --> Helper loaded: url_helper
INFO - 2017-04-07 23:15:40 --> Helper loaded: language_helper
INFO - 2017-04-07 23:15:40 --> Helper loaded: html_helper
INFO - 2017-04-07 23:15:40 --> Helper loaded: form_helper
INFO - 2017-04-07 23:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:15:40 --> Controller Class Initialized
INFO - 2017-04-07 23:15:40 --> Database Driver Class Initialized
INFO - 2017-04-07 23:15:40 --> Model Class Initialized
INFO - 2017-04-07 23:15:40 --> Model Class Initialized
INFO - 2017-04-07 23:15:40 --> Model Class Initialized
INFO - 2017-04-07 23:15:40 --> Email Class Initialized
INFO - 2017-04-07 23:15:40 --> Form Validation Class Initialized
INFO - 2017-04-07 23:15:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:15:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:15:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:15:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:15:40 --> Final output sent to browser
DEBUG - 2017-04-07 23:15:40 --> Total execution time: 0.0932
INFO - 2017-04-07 23:17:40 --> Config Class Initialized
INFO - 2017-04-07 23:17:40 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:17:40 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:17:40 --> Utf8 Class Initialized
INFO - 2017-04-07 23:17:40 --> URI Class Initialized
INFO - 2017-04-07 23:17:40 --> Router Class Initialized
INFO - 2017-04-07 23:17:40 --> Output Class Initialized
INFO - 2017-04-07 23:17:40 --> Security Class Initialized
DEBUG - 2017-04-07 23:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:17:40 --> Input Class Initialized
INFO - 2017-04-07 23:17:40 --> Language Class Initialized
INFO - 2017-04-07 23:17:40 --> Loader Class Initialized
INFO - 2017-04-07 23:17:40 --> Helper loaded: url_helper
INFO - 2017-04-07 23:17:40 --> Helper loaded: language_helper
INFO - 2017-04-07 23:17:40 --> Helper loaded: html_helper
INFO - 2017-04-07 23:17:40 --> Helper loaded: form_helper
INFO - 2017-04-07 23:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:17:40 --> Controller Class Initialized
INFO - 2017-04-07 23:17:40 --> Database Driver Class Initialized
INFO - 2017-04-07 23:17:40 --> Model Class Initialized
INFO - 2017-04-07 23:17:40 --> Model Class Initialized
INFO - 2017-04-07 23:17:40 --> Model Class Initialized
INFO - 2017-04-07 23:17:40 --> Email Class Initialized
INFO - 2017-04-07 23:17:40 --> Form Validation Class Initialized
INFO - 2017-04-07 23:17:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:17:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:17:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:17:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:17:40 --> Final output sent to browser
DEBUG - 2017-04-07 23:17:40 --> Total execution time: 0.0968
INFO - 2017-04-07 23:17:54 --> Config Class Initialized
INFO - 2017-04-07 23:17:54 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:17:54 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:17:54 --> Utf8 Class Initialized
INFO - 2017-04-07 23:17:54 --> URI Class Initialized
INFO - 2017-04-07 23:17:54 --> Router Class Initialized
INFO - 2017-04-07 23:17:54 --> Output Class Initialized
INFO - 2017-04-07 23:17:54 --> Security Class Initialized
DEBUG - 2017-04-07 23:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:17:54 --> Input Class Initialized
INFO - 2017-04-07 23:17:54 --> Language Class Initialized
INFO - 2017-04-07 23:17:54 --> Loader Class Initialized
INFO - 2017-04-07 23:17:54 --> Helper loaded: url_helper
INFO - 2017-04-07 23:17:54 --> Helper loaded: language_helper
INFO - 2017-04-07 23:17:54 --> Helper loaded: html_helper
INFO - 2017-04-07 23:17:54 --> Helper loaded: form_helper
INFO - 2017-04-07 23:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:17:54 --> Controller Class Initialized
INFO - 2017-04-07 23:17:55 --> Database Driver Class Initialized
INFO - 2017-04-07 23:17:55 --> Model Class Initialized
INFO - 2017-04-07 23:17:55 --> Model Class Initialized
INFO - 2017-04-07 23:17:55 --> Model Class Initialized
INFO - 2017-04-07 23:17:55 --> Email Class Initialized
INFO - 2017-04-07 23:17:55 --> Form Validation Class Initialized
INFO - 2017-04-07 23:17:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:17:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:17:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:17:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:17:55 --> Final output sent to browser
DEBUG - 2017-04-07 23:17:55 --> Total execution time: 0.1108
INFO - 2017-04-07 23:19:00 --> Config Class Initialized
INFO - 2017-04-07 23:19:00 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:19:01 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:19:01 --> Utf8 Class Initialized
INFO - 2017-04-07 23:19:01 --> URI Class Initialized
INFO - 2017-04-07 23:19:01 --> Router Class Initialized
INFO - 2017-04-07 23:19:01 --> Output Class Initialized
INFO - 2017-04-07 23:19:01 --> Security Class Initialized
DEBUG - 2017-04-07 23:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:19:01 --> Input Class Initialized
INFO - 2017-04-07 23:19:01 --> Language Class Initialized
INFO - 2017-04-07 23:19:01 --> Loader Class Initialized
INFO - 2017-04-07 23:19:01 --> Helper loaded: url_helper
INFO - 2017-04-07 23:19:01 --> Helper loaded: language_helper
INFO - 2017-04-07 23:19:01 --> Helper loaded: html_helper
INFO - 2017-04-07 23:19:01 --> Helper loaded: form_helper
INFO - 2017-04-07 23:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:19:01 --> Controller Class Initialized
INFO - 2017-04-07 23:19:01 --> Database Driver Class Initialized
INFO - 2017-04-07 23:19:01 --> Model Class Initialized
INFO - 2017-04-07 23:19:01 --> Model Class Initialized
INFO - 2017-04-07 23:19:01 --> Model Class Initialized
INFO - 2017-04-07 23:19:01 --> Email Class Initialized
INFO - 2017-04-07 23:19:01 --> Form Validation Class Initialized
INFO - 2017-04-07 23:19:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:19:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:19:01 --> Final output sent to browser
DEBUG - 2017-04-07 23:19:01 --> Total execution time: 0.0929
INFO - 2017-04-07 23:20:24 --> Config Class Initialized
INFO - 2017-04-07 23:20:24 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:20:24 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:20:24 --> Utf8 Class Initialized
INFO - 2017-04-07 23:20:24 --> URI Class Initialized
INFO - 2017-04-07 23:20:24 --> Router Class Initialized
INFO - 2017-04-07 23:20:24 --> Output Class Initialized
INFO - 2017-04-07 23:20:24 --> Security Class Initialized
DEBUG - 2017-04-07 23:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:20:24 --> Input Class Initialized
INFO - 2017-04-07 23:20:24 --> Language Class Initialized
INFO - 2017-04-07 23:20:24 --> Loader Class Initialized
INFO - 2017-04-07 23:20:24 --> Helper loaded: url_helper
INFO - 2017-04-07 23:20:24 --> Helper loaded: language_helper
INFO - 2017-04-07 23:20:24 --> Helper loaded: html_helper
INFO - 2017-04-07 23:20:24 --> Helper loaded: form_helper
INFO - 2017-04-07 23:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:20:24 --> Controller Class Initialized
INFO - 2017-04-07 23:20:24 --> Database Driver Class Initialized
INFO - 2017-04-07 23:20:24 --> Model Class Initialized
INFO - 2017-04-07 23:20:24 --> Model Class Initialized
INFO - 2017-04-07 23:20:24 --> Model Class Initialized
INFO - 2017-04-07 23:20:24 --> Email Class Initialized
INFO - 2017-04-07 23:20:24 --> Form Validation Class Initialized
INFO - 2017-04-07 23:20:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:20:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:20:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:20:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:20:24 --> Final output sent to browser
DEBUG - 2017-04-07 23:20:24 --> Total execution time: 0.0891
INFO - 2017-04-07 23:21:11 --> Config Class Initialized
INFO - 2017-04-07 23:21:11 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:21:11 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:21:11 --> Utf8 Class Initialized
INFO - 2017-04-07 23:21:11 --> URI Class Initialized
INFO - 2017-04-07 23:21:11 --> Router Class Initialized
INFO - 2017-04-07 23:21:11 --> Output Class Initialized
INFO - 2017-04-07 23:21:11 --> Security Class Initialized
DEBUG - 2017-04-07 23:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:21:11 --> Input Class Initialized
INFO - 2017-04-07 23:21:11 --> Language Class Initialized
INFO - 2017-04-07 23:21:11 --> Loader Class Initialized
INFO - 2017-04-07 23:21:11 --> Helper loaded: url_helper
INFO - 2017-04-07 23:21:11 --> Helper loaded: language_helper
INFO - 2017-04-07 23:21:12 --> Helper loaded: html_helper
INFO - 2017-04-07 23:21:12 --> Helper loaded: form_helper
INFO - 2017-04-07 23:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:21:12 --> Controller Class Initialized
INFO - 2017-04-07 23:21:12 --> Database Driver Class Initialized
INFO - 2017-04-07 23:21:12 --> Model Class Initialized
INFO - 2017-04-07 23:21:12 --> Model Class Initialized
INFO - 2017-04-07 23:21:12 --> Model Class Initialized
INFO - 2017-04-07 23:21:12 --> Email Class Initialized
INFO - 2017-04-07 23:21:12 --> Form Validation Class Initialized
INFO - 2017-04-07 23:21:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:21:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:21:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:21:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:21:12 --> Final output sent to browser
DEBUG - 2017-04-07 23:21:12 --> Total execution time: 0.1139
INFO - 2017-04-07 23:25:37 --> Config Class Initialized
INFO - 2017-04-07 23:25:37 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:25:37 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:25:37 --> Utf8 Class Initialized
INFO - 2017-04-07 23:25:37 --> URI Class Initialized
INFO - 2017-04-07 23:25:37 --> Router Class Initialized
INFO - 2017-04-07 23:25:37 --> Output Class Initialized
INFO - 2017-04-07 23:25:37 --> Security Class Initialized
DEBUG - 2017-04-07 23:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:25:37 --> Input Class Initialized
INFO - 2017-04-07 23:25:37 --> Language Class Initialized
INFO - 2017-04-07 23:25:37 --> Loader Class Initialized
INFO - 2017-04-07 23:25:37 --> Helper loaded: url_helper
INFO - 2017-04-07 23:25:37 --> Helper loaded: language_helper
INFO - 2017-04-07 23:25:37 --> Helper loaded: html_helper
INFO - 2017-04-07 23:25:37 --> Helper loaded: form_helper
INFO - 2017-04-07 23:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:25:37 --> Controller Class Initialized
INFO - 2017-04-07 23:25:37 --> Database Driver Class Initialized
INFO - 2017-04-07 23:25:37 --> Model Class Initialized
INFO - 2017-04-07 23:25:37 --> Model Class Initialized
INFO - 2017-04-07 23:25:37 --> Model Class Initialized
INFO - 2017-04-07 23:25:37 --> Email Class Initialized
INFO - 2017-04-07 23:25:37 --> Form Validation Class Initialized
INFO - 2017-04-07 23:25:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:25:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:25:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:25:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:25:37 --> Final output sent to browser
DEBUG - 2017-04-07 23:25:37 --> Total execution time: 0.1052
INFO - 2017-04-07 23:26:14 --> Config Class Initialized
INFO - 2017-04-07 23:26:14 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:26:14 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:26:14 --> Utf8 Class Initialized
INFO - 2017-04-07 23:26:14 --> URI Class Initialized
INFO - 2017-04-07 23:26:14 --> Router Class Initialized
INFO - 2017-04-07 23:26:14 --> Output Class Initialized
INFO - 2017-04-07 23:26:14 --> Security Class Initialized
DEBUG - 2017-04-07 23:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:26:14 --> Input Class Initialized
INFO - 2017-04-07 23:26:14 --> Language Class Initialized
INFO - 2017-04-07 23:26:14 --> Loader Class Initialized
INFO - 2017-04-07 23:26:14 --> Helper loaded: url_helper
INFO - 2017-04-07 23:26:14 --> Helper loaded: language_helper
INFO - 2017-04-07 23:26:14 --> Helper loaded: html_helper
INFO - 2017-04-07 23:26:14 --> Helper loaded: form_helper
INFO - 2017-04-07 23:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:26:14 --> Controller Class Initialized
INFO - 2017-04-07 23:26:14 --> Database Driver Class Initialized
INFO - 2017-04-07 23:26:14 --> Model Class Initialized
INFO - 2017-04-07 23:26:14 --> Model Class Initialized
INFO - 2017-04-07 23:26:14 --> Model Class Initialized
INFO - 2017-04-07 23:26:14 --> Email Class Initialized
INFO - 2017-04-07 23:26:14 --> Form Validation Class Initialized
INFO - 2017-04-07 23:26:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:26:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:26:14 --> Final output sent to browser
DEBUG - 2017-04-07 23:26:14 --> Total execution time: 0.1127
INFO - 2017-04-07 23:26:27 --> Config Class Initialized
INFO - 2017-04-07 23:26:27 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:26:27 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:26:27 --> Utf8 Class Initialized
INFO - 2017-04-07 23:26:27 --> URI Class Initialized
INFO - 2017-04-07 23:26:27 --> Router Class Initialized
INFO - 2017-04-07 23:26:27 --> Output Class Initialized
INFO - 2017-04-07 23:26:27 --> Security Class Initialized
DEBUG - 2017-04-07 23:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:26:27 --> Input Class Initialized
INFO - 2017-04-07 23:26:27 --> Language Class Initialized
INFO - 2017-04-07 23:26:27 --> Loader Class Initialized
INFO - 2017-04-07 23:26:27 --> Helper loaded: url_helper
INFO - 2017-04-07 23:26:27 --> Helper loaded: language_helper
INFO - 2017-04-07 23:26:27 --> Helper loaded: html_helper
INFO - 2017-04-07 23:26:27 --> Helper loaded: form_helper
INFO - 2017-04-07 23:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:26:27 --> Controller Class Initialized
INFO - 2017-04-07 23:26:27 --> Database Driver Class Initialized
INFO - 2017-04-07 23:26:27 --> Model Class Initialized
INFO - 2017-04-07 23:26:27 --> Model Class Initialized
INFO - 2017-04-07 23:26:27 --> Model Class Initialized
INFO - 2017-04-07 23:26:27 --> Email Class Initialized
INFO - 2017-04-07 23:26:27 --> Form Validation Class Initialized
INFO - 2017-04-07 23:26:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:26:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:26:27 --> Final output sent to browser
DEBUG - 2017-04-07 23:26:27 --> Total execution time: 0.1302
INFO - 2017-04-07 23:27:41 --> Config Class Initialized
INFO - 2017-04-07 23:27:41 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:27:41 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:27:41 --> Utf8 Class Initialized
INFO - 2017-04-07 23:27:41 --> URI Class Initialized
INFO - 2017-04-07 23:27:41 --> Router Class Initialized
INFO - 2017-04-07 23:27:41 --> Output Class Initialized
INFO - 2017-04-07 23:27:41 --> Security Class Initialized
DEBUG - 2017-04-07 23:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:27:41 --> Input Class Initialized
INFO - 2017-04-07 23:27:41 --> Language Class Initialized
INFO - 2017-04-07 23:27:41 --> Loader Class Initialized
INFO - 2017-04-07 23:27:41 --> Helper loaded: url_helper
INFO - 2017-04-07 23:27:41 --> Helper loaded: language_helper
INFO - 2017-04-07 23:27:41 --> Helper loaded: html_helper
INFO - 2017-04-07 23:27:41 --> Helper loaded: form_helper
INFO - 2017-04-07 23:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:27:41 --> Controller Class Initialized
INFO - 2017-04-07 23:27:41 --> Database Driver Class Initialized
INFO - 2017-04-07 23:27:41 --> Model Class Initialized
INFO - 2017-04-07 23:27:41 --> Model Class Initialized
INFO - 2017-04-07 23:27:41 --> Model Class Initialized
INFO - 2017-04-07 23:27:41 --> Email Class Initialized
INFO - 2017-04-07 23:27:41 --> Form Validation Class Initialized
INFO - 2017-04-07 23:27:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:27:44 --> Config Class Initialized
INFO - 2017-04-07 23:27:44 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:27:44 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:27:44 --> Utf8 Class Initialized
INFO - 2017-04-07 23:27:44 --> URI Class Initialized
INFO - 2017-04-07 23:27:44 --> Router Class Initialized
INFO - 2017-04-07 23:27:44 --> Output Class Initialized
INFO - 2017-04-07 23:27:44 --> Security Class Initialized
DEBUG - 2017-04-07 23:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:27:44 --> Input Class Initialized
INFO - 2017-04-07 23:27:44 --> Language Class Initialized
INFO - 2017-04-07 23:27:44 --> Loader Class Initialized
INFO - 2017-04-07 23:27:44 --> Helper loaded: url_helper
INFO - 2017-04-07 23:27:44 --> Helper loaded: language_helper
INFO - 2017-04-07 23:27:44 --> Helper loaded: html_helper
INFO - 2017-04-07 23:27:44 --> Helper loaded: form_helper
INFO - 2017-04-07 23:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:27:44 --> Controller Class Initialized
INFO - 2017-04-07 23:27:44 --> Database Driver Class Initialized
INFO - 2017-04-07 23:27:44 --> Model Class Initialized
INFO - 2017-04-07 23:27:44 --> Model Class Initialized
INFO - 2017-04-07 23:27:44 --> Model Class Initialized
INFO - 2017-04-07 23:27:44 --> Email Class Initialized
INFO - 2017-04-07 23:27:44 --> Form Validation Class Initialized
INFO - 2017-04-07 23:27:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:28:32 --> Config Class Initialized
INFO - 2017-04-07 23:28:32 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:28:32 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:28:32 --> Utf8 Class Initialized
INFO - 2017-04-07 23:28:32 --> URI Class Initialized
INFO - 2017-04-07 23:28:32 --> Router Class Initialized
INFO - 2017-04-07 23:28:32 --> Output Class Initialized
INFO - 2017-04-07 23:28:32 --> Security Class Initialized
DEBUG - 2017-04-07 23:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:28:32 --> Input Class Initialized
INFO - 2017-04-07 23:28:32 --> Language Class Initialized
INFO - 2017-04-07 23:28:32 --> Loader Class Initialized
INFO - 2017-04-07 23:28:32 --> Helper loaded: url_helper
INFO - 2017-04-07 23:28:32 --> Helper loaded: language_helper
INFO - 2017-04-07 23:28:32 --> Helper loaded: html_helper
INFO - 2017-04-07 23:28:32 --> Helper loaded: form_helper
INFO - 2017-04-07 23:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:28:32 --> Controller Class Initialized
INFO - 2017-04-07 23:28:32 --> Database Driver Class Initialized
INFO - 2017-04-07 23:28:32 --> Model Class Initialized
INFO - 2017-04-07 23:28:32 --> Model Class Initialized
INFO - 2017-04-07 23:28:32 --> Model Class Initialized
INFO - 2017-04-07 23:28:32 --> Email Class Initialized
INFO - 2017-04-07 23:28:32 --> Form Validation Class Initialized
INFO - 2017-04-07 23:28:32 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-04-07 23:28:32 --> Severity: Notice --> Undefined index: nama_provinsi C:\wamp64\www\savsoftquiz\application\models\Provinsi_model.php 9
INFO - 2017-04-07 23:28:53 --> Config Class Initialized
INFO - 2017-04-07 23:28:53 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:28:53 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:28:53 --> Utf8 Class Initialized
INFO - 2017-04-07 23:28:53 --> URI Class Initialized
INFO - 2017-04-07 23:28:53 --> Router Class Initialized
INFO - 2017-04-07 23:28:53 --> Output Class Initialized
INFO - 2017-04-07 23:28:53 --> Security Class Initialized
DEBUG - 2017-04-07 23:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:28:53 --> Input Class Initialized
INFO - 2017-04-07 23:28:53 --> Language Class Initialized
INFO - 2017-04-07 23:28:53 --> Loader Class Initialized
INFO - 2017-04-07 23:28:53 --> Helper loaded: url_helper
INFO - 2017-04-07 23:28:53 --> Helper loaded: language_helper
INFO - 2017-04-07 23:28:53 --> Helper loaded: html_helper
INFO - 2017-04-07 23:28:53 --> Helper loaded: form_helper
INFO - 2017-04-07 23:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:28:53 --> Controller Class Initialized
INFO - 2017-04-07 23:28:54 --> Database Driver Class Initialized
INFO - 2017-04-07 23:28:54 --> Model Class Initialized
INFO - 2017-04-07 23:28:54 --> Model Class Initialized
INFO - 2017-04-07 23:28:54 --> Model Class Initialized
INFO - 2017-04-07 23:28:54 --> Email Class Initialized
INFO - 2017-04-07 23:28:54 --> Form Validation Class Initialized
INFO - 2017-04-07 23:28:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:30:11 --> Config Class Initialized
INFO - 2017-04-07 23:30:11 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:30:11 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:30:11 --> Utf8 Class Initialized
INFO - 2017-04-07 23:30:11 --> URI Class Initialized
INFO - 2017-04-07 23:30:11 --> Router Class Initialized
INFO - 2017-04-07 23:30:11 --> Output Class Initialized
INFO - 2017-04-07 23:30:11 --> Security Class Initialized
DEBUG - 2017-04-07 23:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:30:11 --> Input Class Initialized
INFO - 2017-04-07 23:30:11 --> Language Class Initialized
INFO - 2017-04-07 23:30:11 --> Loader Class Initialized
INFO - 2017-04-07 23:30:11 --> Helper loaded: url_helper
INFO - 2017-04-07 23:30:11 --> Helper loaded: language_helper
INFO - 2017-04-07 23:30:11 --> Helper loaded: html_helper
INFO - 2017-04-07 23:30:11 --> Helper loaded: form_helper
INFO - 2017-04-07 23:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:30:11 --> Controller Class Initialized
INFO - 2017-04-07 23:30:11 --> Database Driver Class Initialized
INFO - 2017-04-07 23:30:11 --> Model Class Initialized
INFO - 2017-04-07 23:30:11 --> Model Class Initialized
INFO - 2017-04-07 23:30:11 --> Model Class Initialized
INFO - 2017-04-07 23:30:11 --> Email Class Initialized
INFO - 2017-04-07 23:30:11 --> Form Validation Class Initialized
INFO - 2017-04-07 23:30:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:30:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:30:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:30:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:30:11 --> Final output sent to browser
DEBUG - 2017-04-07 23:30:11 --> Total execution time: 0.1015
INFO - 2017-04-07 23:30:21 --> Config Class Initialized
INFO - 2017-04-07 23:30:21 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:30:21 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:30:21 --> Utf8 Class Initialized
INFO - 2017-04-07 23:30:21 --> URI Class Initialized
INFO - 2017-04-07 23:30:21 --> Router Class Initialized
INFO - 2017-04-07 23:30:21 --> Output Class Initialized
INFO - 2017-04-07 23:30:21 --> Security Class Initialized
DEBUG - 2017-04-07 23:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:30:21 --> Input Class Initialized
INFO - 2017-04-07 23:30:21 --> Language Class Initialized
INFO - 2017-04-07 23:30:21 --> Loader Class Initialized
INFO - 2017-04-07 23:30:21 --> Helper loaded: url_helper
INFO - 2017-04-07 23:30:21 --> Helper loaded: language_helper
INFO - 2017-04-07 23:30:21 --> Helper loaded: html_helper
INFO - 2017-04-07 23:30:21 --> Helper loaded: form_helper
INFO - 2017-04-07 23:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:30:21 --> Controller Class Initialized
INFO - 2017-04-07 23:30:21 --> Database Driver Class Initialized
INFO - 2017-04-07 23:30:21 --> Model Class Initialized
INFO - 2017-04-07 23:30:21 --> Model Class Initialized
INFO - 2017-04-07 23:30:21 --> Model Class Initialized
INFO - 2017-04-07 23:30:21 --> Email Class Initialized
INFO - 2017-04-07 23:30:21 --> Form Validation Class Initialized
INFO - 2017-04-07 23:30:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:30:21 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:30:21 --> Final output sent to browser
DEBUG - 2017-04-07 23:30:21 --> Total execution time: 0.1149
INFO - 2017-04-07 23:31:18 --> Config Class Initialized
INFO - 2017-04-07 23:31:18 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:31:18 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:31:18 --> Utf8 Class Initialized
INFO - 2017-04-07 23:31:18 --> URI Class Initialized
INFO - 2017-04-07 23:31:18 --> Router Class Initialized
INFO - 2017-04-07 23:31:18 --> Output Class Initialized
INFO - 2017-04-07 23:31:18 --> Security Class Initialized
DEBUG - 2017-04-07 23:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:31:18 --> Input Class Initialized
INFO - 2017-04-07 23:31:18 --> Language Class Initialized
INFO - 2017-04-07 23:31:18 --> Loader Class Initialized
INFO - 2017-04-07 23:31:18 --> Helper loaded: url_helper
INFO - 2017-04-07 23:31:18 --> Helper loaded: language_helper
INFO - 2017-04-07 23:31:18 --> Helper loaded: html_helper
INFO - 2017-04-07 23:31:18 --> Helper loaded: form_helper
INFO - 2017-04-07 23:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:31:18 --> Controller Class Initialized
INFO - 2017-04-07 23:31:18 --> Database Driver Class Initialized
INFO - 2017-04-07 23:31:18 --> Model Class Initialized
INFO - 2017-04-07 23:31:18 --> Model Class Initialized
INFO - 2017-04-07 23:31:18 --> Model Class Initialized
INFO - 2017-04-07 23:31:18 --> Email Class Initialized
INFO - 2017-04-07 23:31:18 --> Form Validation Class Initialized
INFO - 2017-04-07 23:31:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:31:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:31:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:31:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:31:18 --> Final output sent to browser
DEBUG - 2017-04-07 23:31:18 --> Total execution time: 0.1032
INFO - 2017-04-07 23:31:43 --> Config Class Initialized
INFO - 2017-04-07 23:31:43 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:31:43 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:31:43 --> Utf8 Class Initialized
INFO - 2017-04-07 23:31:43 --> URI Class Initialized
INFO - 2017-04-07 23:31:43 --> Router Class Initialized
INFO - 2017-04-07 23:31:43 --> Output Class Initialized
INFO - 2017-04-07 23:31:43 --> Security Class Initialized
DEBUG - 2017-04-07 23:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:31:43 --> Input Class Initialized
INFO - 2017-04-07 23:31:43 --> Language Class Initialized
INFO - 2017-04-07 23:31:43 --> Loader Class Initialized
INFO - 2017-04-07 23:31:43 --> Helper loaded: url_helper
INFO - 2017-04-07 23:31:43 --> Helper loaded: language_helper
INFO - 2017-04-07 23:31:43 --> Helper loaded: html_helper
INFO - 2017-04-07 23:31:43 --> Helper loaded: form_helper
INFO - 2017-04-07 23:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:31:43 --> Controller Class Initialized
INFO - 2017-04-07 23:31:43 --> Database Driver Class Initialized
INFO - 2017-04-07 23:31:43 --> Model Class Initialized
INFO - 2017-04-07 23:31:43 --> Model Class Initialized
INFO - 2017-04-07 23:31:43 --> Model Class Initialized
INFO - 2017-04-07 23:31:43 --> Email Class Initialized
INFO - 2017-04-07 23:31:43 --> Form Validation Class Initialized
INFO - 2017-04-07 23:31:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:31:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:31:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:31:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:31:43 --> Final output sent to browser
DEBUG - 2017-04-07 23:31:43 --> Total execution time: 0.0878
INFO - 2017-04-07 23:32:17 --> Config Class Initialized
INFO - 2017-04-07 23:32:17 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:32:17 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:32:17 --> Utf8 Class Initialized
INFO - 2017-04-07 23:32:17 --> URI Class Initialized
INFO - 2017-04-07 23:32:17 --> Router Class Initialized
INFO - 2017-04-07 23:32:17 --> Output Class Initialized
INFO - 2017-04-07 23:32:17 --> Security Class Initialized
DEBUG - 2017-04-07 23:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:32:17 --> Input Class Initialized
INFO - 2017-04-07 23:32:17 --> Language Class Initialized
INFO - 2017-04-07 23:32:17 --> Loader Class Initialized
INFO - 2017-04-07 23:32:17 --> Helper loaded: url_helper
INFO - 2017-04-07 23:32:17 --> Helper loaded: language_helper
INFO - 2017-04-07 23:32:17 --> Helper loaded: html_helper
INFO - 2017-04-07 23:32:17 --> Helper loaded: form_helper
INFO - 2017-04-07 23:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:32:17 --> Controller Class Initialized
INFO - 2017-04-07 23:32:17 --> Database Driver Class Initialized
INFO - 2017-04-07 23:32:17 --> Model Class Initialized
INFO - 2017-04-07 23:32:17 --> Model Class Initialized
INFO - 2017-04-07 23:32:17 --> Model Class Initialized
INFO - 2017-04-07 23:32:17 --> Email Class Initialized
INFO - 2017-04-07 23:32:17 --> Form Validation Class Initialized
INFO - 2017-04-07 23:32:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:32:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:32:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:32:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:32:17 --> Final output sent to browser
DEBUG - 2017-04-07 23:32:17 --> Total execution time: 0.1048
INFO - 2017-04-07 23:34:53 --> Config Class Initialized
INFO - 2017-04-07 23:34:53 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:34:53 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:34:53 --> Utf8 Class Initialized
INFO - 2017-04-07 23:34:53 --> URI Class Initialized
INFO - 2017-04-07 23:34:53 --> Router Class Initialized
INFO - 2017-04-07 23:34:53 --> Output Class Initialized
INFO - 2017-04-07 23:34:53 --> Security Class Initialized
DEBUG - 2017-04-07 23:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:34:53 --> Input Class Initialized
INFO - 2017-04-07 23:34:53 --> Language Class Initialized
INFO - 2017-04-07 23:34:53 --> Loader Class Initialized
INFO - 2017-04-07 23:34:53 --> Helper loaded: url_helper
INFO - 2017-04-07 23:34:53 --> Helper loaded: language_helper
INFO - 2017-04-07 23:34:53 --> Helper loaded: html_helper
INFO - 2017-04-07 23:34:53 --> Helper loaded: form_helper
INFO - 2017-04-07 23:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:34:53 --> Controller Class Initialized
INFO - 2017-04-07 23:34:53 --> Database Driver Class Initialized
INFO - 2017-04-07 23:34:53 --> Model Class Initialized
INFO - 2017-04-07 23:34:53 --> Model Class Initialized
INFO - 2017-04-07 23:34:53 --> Model Class Initialized
INFO - 2017-04-07 23:34:53 --> Email Class Initialized
INFO - 2017-04-07 23:34:53 --> Form Validation Class Initialized
INFO - 2017-04-07 23:34:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:34:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:34:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:34:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:34:53 --> Final output sent to browser
DEBUG - 2017-04-07 23:34:53 --> Total execution time: 0.0880
INFO - 2017-04-07 23:36:06 --> Config Class Initialized
INFO - 2017-04-07 23:36:06 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:36:06 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:36:06 --> Utf8 Class Initialized
INFO - 2017-04-07 23:36:06 --> URI Class Initialized
INFO - 2017-04-07 23:36:06 --> Router Class Initialized
INFO - 2017-04-07 23:36:06 --> Output Class Initialized
INFO - 2017-04-07 23:36:06 --> Security Class Initialized
DEBUG - 2017-04-07 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:36:06 --> Input Class Initialized
INFO - 2017-04-07 23:36:06 --> Language Class Initialized
INFO - 2017-04-07 23:36:06 --> Loader Class Initialized
INFO - 2017-04-07 23:36:06 --> Helper loaded: url_helper
INFO - 2017-04-07 23:36:06 --> Helper loaded: language_helper
INFO - 2017-04-07 23:36:06 --> Helper loaded: html_helper
INFO - 2017-04-07 23:36:06 --> Helper loaded: form_helper
INFO - 2017-04-07 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:36:06 --> Controller Class Initialized
INFO - 2017-04-07 23:36:06 --> Database Driver Class Initialized
INFO - 2017-04-07 23:36:06 --> Model Class Initialized
INFO - 2017-04-07 23:36:06 --> Model Class Initialized
INFO - 2017-04-07 23:36:06 --> Model Class Initialized
INFO - 2017-04-07 23:36:06 --> Email Class Initialized
INFO - 2017-04-07 23:36:06 --> Form Validation Class Initialized
INFO - 2017-04-07 23:36:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:36:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:36:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:36:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:36:06 --> Final output sent to browser
DEBUG - 2017-04-07 23:36:06 --> Total execution time: 0.0884
INFO - 2017-04-07 23:36:41 --> Config Class Initialized
INFO - 2017-04-07 23:36:41 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:36:41 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:36:41 --> Utf8 Class Initialized
INFO - 2017-04-07 23:36:41 --> URI Class Initialized
INFO - 2017-04-07 23:36:41 --> Router Class Initialized
INFO - 2017-04-07 23:36:41 --> Output Class Initialized
INFO - 2017-04-07 23:36:41 --> Security Class Initialized
DEBUG - 2017-04-07 23:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:36:41 --> Input Class Initialized
INFO - 2017-04-07 23:36:41 --> Language Class Initialized
INFO - 2017-04-07 23:36:41 --> Loader Class Initialized
INFO - 2017-04-07 23:36:41 --> Helper loaded: url_helper
INFO - 2017-04-07 23:36:41 --> Helper loaded: language_helper
INFO - 2017-04-07 23:36:41 --> Helper loaded: html_helper
INFO - 2017-04-07 23:36:41 --> Helper loaded: form_helper
INFO - 2017-04-07 23:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:36:41 --> Controller Class Initialized
INFO - 2017-04-07 23:36:41 --> Database Driver Class Initialized
INFO - 2017-04-07 23:36:41 --> Model Class Initialized
INFO - 2017-04-07 23:36:41 --> Model Class Initialized
INFO - 2017-04-07 23:36:41 --> Model Class Initialized
INFO - 2017-04-07 23:36:41 --> Email Class Initialized
INFO - 2017-04-07 23:36:41 --> Form Validation Class Initialized
INFO - 2017-04-07 23:36:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:36:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:36:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:36:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:36:41 --> Final output sent to browser
DEBUG - 2017-04-07 23:36:41 --> Total execution time: 0.1148
INFO - 2017-04-07 23:38:01 --> Config Class Initialized
INFO - 2017-04-07 23:38:01 --> Hooks Class Initialized
DEBUG - 2017-04-07 23:38:01 --> UTF-8 Support Enabled
INFO - 2017-04-07 23:38:01 --> Utf8 Class Initialized
INFO - 2017-04-07 23:38:01 --> URI Class Initialized
INFO - 2017-04-07 23:38:01 --> Router Class Initialized
INFO - 2017-04-07 23:38:01 --> Output Class Initialized
INFO - 2017-04-07 23:38:01 --> Security Class Initialized
DEBUG - 2017-04-07 23:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-07 23:38:01 --> Input Class Initialized
INFO - 2017-04-07 23:38:01 --> Language Class Initialized
INFO - 2017-04-07 23:38:01 --> Loader Class Initialized
INFO - 2017-04-07 23:38:01 --> Helper loaded: url_helper
INFO - 2017-04-07 23:38:01 --> Helper loaded: language_helper
INFO - 2017-04-07 23:38:01 --> Helper loaded: html_helper
INFO - 2017-04-07 23:38:01 --> Helper loaded: form_helper
INFO - 2017-04-07 23:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-07 23:38:01 --> Controller Class Initialized
INFO - 2017-04-07 23:38:01 --> Database Driver Class Initialized
INFO - 2017-04-07 23:38:01 --> Model Class Initialized
INFO - 2017-04-07 23:38:01 --> Model Class Initialized
INFO - 2017-04-07 23:38:01 --> Model Class Initialized
INFO - 2017-04-07 23:38:01 --> Email Class Initialized
INFO - 2017-04-07 23:38:01 --> Form Validation Class Initialized
INFO - 2017-04-07 23:38:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-07 23:38:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-07 23:38:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-07 23:38:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-07 23:38:01 --> Final output sent to browser
DEBUG - 2017-04-07 23:38:01 --> Total execution time: 0.1165
