<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-08 00:10:22 --> Config Class Initialized
INFO - 2017-04-08 00:10:22 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:10:22 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:10:22 --> Utf8 Class Initialized
INFO - 2017-04-08 00:10:22 --> URI Class Initialized
INFO - 2017-04-08 00:10:22 --> Router Class Initialized
INFO - 2017-04-08 00:10:22 --> Output Class Initialized
INFO - 2017-04-08 00:10:22 --> Security Class Initialized
DEBUG - 2017-04-08 00:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:10:22 --> Input Class Initialized
INFO - 2017-04-08 00:10:22 --> Language Class Initialized
INFO - 2017-04-08 00:10:22 --> Loader Class Initialized
INFO - 2017-04-08 00:10:22 --> Helper loaded: url_helper
INFO - 2017-04-08 00:10:22 --> Helper loaded: language_helper
INFO - 2017-04-08 00:10:22 --> Helper loaded: html_helper
INFO - 2017-04-08 00:10:22 --> Helper loaded: form_helper
INFO - 2017-04-08 00:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:10:22 --> Controller Class Initialized
INFO - 2017-04-08 00:10:22 --> Database Driver Class Initialized
INFO - 2017-04-08 00:10:22 --> Model Class Initialized
INFO - 2017-04-08 00:10:22 --> Model Class Initialized
INFO - 2017-04-08 00:10:22 --> Email Class Initialized
INFO - 2017-04-08 00:10:22 --> Form Validation Class Initialized
INFO - 2017-04-08 00:10:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:10:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:10:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:10:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:10:22 --> Final output sent to browser
DEBUG - 2017-04-08 00:10:22 --> Total execution time: 0.1076
INFO - 2017-04-08 00:11:05 --> Config Class Initialized
INFO - 2017-04-08 00:11:05 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:11:05 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:11:05 --> Utf8 Class Initialized
INFO - 2017-04-08 00:11:05 --> URI Class Initialized
INFO - 2017-04-08 00:11:05 --> Router Class Initialized
INFO - 2017-04-08 00:11:05 --> Output Class Initialized
INFO - 2017-04-08 00:11:05 --> Security Class Initialized
DEBUG - 2017-04-08 00:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:11:05 --> Input Class Initialized
INFO - 2017-04-08 00:11:05 --> Language Class Initialized
INFO - 2017-04-08 00:11:05 --> Loader Class Initialized
INFO - 2017-04-08 00:11:05 --> Helper loaded: url_helper
INFO - 2017-04-08 00:11:05 --> Helper loaded: language_helper
INFO - 2017-04-08 00:11:05 --> Helper loaded: html_helper
INFO - 2017-04-08 00:11:05 --> Helper loaded: form_helper
INFO - 2017-04-08 00:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:11:05 --> Controller Class Initialized
INFO - 2017-04-08 00:11:05 --> Database Driver Class Initialized
INFO - 2017-04-08 00:11:05 --> Model Class Initialized
INFO - 2017-04-08 00:11:05 --> Model Class Initialized
INFO - 2017-04-08 00:11:05 --> Email Class Initialized
INFO - 2017-04-08 00:11:05 --> Form Validation Class Initialized
INFO - 2017-04-08 00:11:05 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:11:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:11:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:11:05 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:11:05 --> Final output sent to browser
DEBUG - 2017-04-08 00:11:05 --> Total execution time: 0.1300
INFO - 2017-04-08 00:14:35 --> Config Class Initialized
INFO - 2017-04-08 00:14:35 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:14:35 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:14:35 --> Utf8 Class Initialized
INFO - 2017-04-08 00:14:35 --> URI Class Initialized
INFO - 2017-04-08 00:14:35 --> Router Class Initialized
INFO - 2017-04-08 00:14:35 --> Output Class Initialized
INFO - 2017-04-08 00:14:35 --> Security Class Initialized
DEBUG - 2017-04-08 00:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:14:35 --> Input Class Initialized
INFO - 2017-04-08 00:14:35 --> Language Class Initialized
INFO - 2017-04-08 00:14:35 --> Loader Class Initialized
INFO - 2017-04-08 00:14:35 --> Helper loaded: url_helper
INFO - 2017-04-08 00:14:35 --> Helper loaded: language_helper
INFO - 2017-04-08 00:14:35 --> Helper loaded: html_helper
INFO - 2017-04-08 00:14:35 --> Helper loaded: form_helper
INFO - 2017-04-08 00:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:14:35 --> Controller Class Initialized
INFO - 2017-04-08 00:14:35 --> Database Driver Class Initialized
INFO - 2017-04-08 00:14:35 --> Model Class Initialized
INFO - 2017-04-08 00:14:35 --> Model Class Initialized
INFO - 2017-04-08 00:14:35 --> Email Class Initialized
INFO - 2017-04-08 00:14:35 --> Form Validation Class Initialized
INFO - 2017-04-08 00:14:35 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-04-08 00:14:35 --> Severity: Notice --> Undefined variable: data C:\wamp64\www\savsoftquiz\application\models\Provinsi_model.php 12
ERROR - 2017-04-08 00:14:35 --> Severity: Notice --> Undefined variable: result C:\wamp64\www\savsoftquiz\application\models\Provinsi_model.php 16
INFO - 2017-04-08 00:14:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-08 00:14:35 --> Severity: Warning --> array_merge(): Argument #2 is not an array C:\wamp64\www\savsoftquiz\application\views\register_new.php 154
INFO - 2017-04-08 00:14:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:14:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:14:35 --> Final output sent to browser
DEBUG - 2017-04-08 00:14:35 --> Total execution time: 0.0996
INFO - 2017-04-08 00:14:55 --> Config Class Initialized
INFO - 2017-04-08 00:14:55 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:14:55 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:14:55 --> Utf8 Class Initialized
INFO - 2017-04-08 00:14:55 --> URI Class Initialized
INFO - 2017-04-08 00:14:55 --> Router Class Initialized
INFO - 2017-04-08 00:14:55 --> Output Class Initialized
INFO - 2017-04-08 00:14:55 --> Security Class Initialized
DEBUG - 2017-04-08 00:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:14:55 --> Input Class Initialized
INFO - 2017-04-08 00:14:55 --> Language Class Initialized
INFO - 2017-04-08 00:14:55 --> Loader Class Initialized
INFO - 2017-04-08 00:14:55 --> Helper loaded: url_helper
INFO - 2017-04-08 00:14:55 --> Helper loaded: language_helper
INFO - 2017-04-08 00:14:55 --> Helper loaded: html_helper
INFO - 2017-04-08 00:14:55 --> Helper loaded: form_helper
INFO - 2017-04-08 00:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:14:55 --> Controller Class Initialized
INFO - 2017-04-08 00:14:55 --> Database Driver Class Initialized
INFO - 2017-04-08 00:14:55 --> Model Class Initialized
INFO - 2017-04-08 00:14:55 --> Model Class Initialized
INFO - 2017-04-08 00:14:55 --> Email Class Initialized
INFO - 2017-04-08 00:14:55 --> Form Validation Class Initialized
INFO - 2017-04-08 00:14:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:14:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:14:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:14:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:14:55 --> Final output sent to browser
DEBUG - 2017-04-08 00:14:55 --> Total execution time: 0.1000
INFO - 2017-04-08 00:16:13 --> Config Class Initialized
INFO - 2017-04-08 00:16:13 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:16:13 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:16:13 --> Utf8 Class Initialized
INFO - 2017-04-08 00:16:13 --> URI Class Initialized
INFO - 2017-04-08 00:16:13 --> Router Class Initialized
INFO - 2017-04-08 00:16:13 --> Output Class Initialized
INFO - 2017-04-08 00:16:13 --> Security Class Initialized
DEBUG - 2017-04-08 00:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:16:13 --> Input Class Initialized
INFO - 2017-04-08 00:16:13 --> Language Class Initialized
INFO - 2017-04-08 00:16:13 --> Loader Class Initialized
INFO - 2017-04-08 00:16:13 --> Helper loaded: url_helper
INFO - 2017-04-08 00:16:13 --> Helper loaded: language_helper
INFO - 2017-04-08 00:16:13 --> Helper loaded: html_helper
INFO - 2017-04-08 00:16:13 --> Helper loaded: form_helper
INFO - 2017-04-08 00:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:16:13 --> Controller Class Initialized
INFO - 2017-04-08 00:16:13 --> Database Driver Class Initialized
INFO - 2017-04-08 00:16:13 --> Model Class Initialized
INFO - 2017-04-08 00:16:13 --> Model Class Initialized
INFO - 2017-04-08 00:16:13 --> Email Class Initialized
INFO - 2017-04-08 00:16:13 --> Form Validation Class Initialized
INFO - 2017-04-08 00:16:13 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-04-08 00:16:13 --> Severity: Notice --> Undefined variable: provinsi C:\wamp64\www\savsoftquiz\application\models\Provinsi_model.php 16
INFO - 2017-04-08 00:16:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-08 00:16:13 --> Severity: Warning --> array_merge(): Argument #2 is not an array C:\wamp64\www\savsoftquiz\application\views\register_new.php 154
INFO - 2017-04-08 00:16:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:16:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:16:13 --> Final output sent to browser
DEBUG - 2017-04-08 00:16:13 --> Total execution time: 0.0933
INFO - 2017-04-08 00:16:36 --> Config Class Initialized
INFO - 2017-04-08 00:16:36 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:16:36 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:16:36 --> Utf8 Class Initialized
INFO - 2017-04-08 00:16:36 --> URI Class Initialized
INFO - 2017-04-08 00:16:36 --> Router Class Initialized
INFO - 2017-04-08 00:16:36 --> Output Class Initialized
INFO - 2017-04-08 00:16:36 --> Security Class Initialized
DEBUG - 2017-04-08 00:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:16:36 --> Input Class Initialized
INFO - 2017-04-08 00:16:36 --> Language Class Initialized
INFO - 2017-04-08 00:16:36 --> Loader Class Initialized
INFO - 2017-04-08 00:16:36 --> Helper loaded: url_helper
INFO - 2017-04-08 00:16:36 --> Helper loaded: language_helper
INFO - 2017-04-08 00:16:36 --> Helper loaded: html_helper
INFO - 2017-04-08 00:16:36 --> Helper loaded: form_helper
INFO - 2017-04-08 00:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:16:36 --> Controller Class Initialized
INFO - 2017-04-08 00:16:36 --> Database Driver Class Initialized
INFO - 2017-04-08 00:16:36 --> Model Class Initialized
INFO - 2017-04-08 00:16:36 --> Model Class Initialized
INFO - 2017-04-08 00:16:36 --> Email Class Initialized
INFO - 2017-04-08 00:16:36 --> Form Validation Class Initialized
INFO - 2017-04-08 00:16:36 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-04-08 00:16:36 --> Severity: Notice --> Undefined variable: provinsi C:\wamp64\www\savsoftquiz\application\models\Provinsi_model.php 16
INFO - 2017-04-08 00:16:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-08 00:16:36 --> Severity: Warning --> array_merge(): Argument #2 is not an array C:\wamp64\www\savsoftquiz\application\views\register_new.php 154
INFO - 2017-04-08 00:16:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:16:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:16:36 --> Final output sent to browser
DEBUG - 2017-04-08 00:16:36 --> Total execution time: 0.0942
INFO - 2017-04-08 00:17:42 --> Config Class Initialized
INFO - 2017-04-08 00:17:42 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:17:42 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:17:42 --> Utf8 Class Initialized
INFO - 2017-04-08 00:17:42 --> URI Class Initialized
INFO - 2017-04-08 00:17:42 --> Router Class Initialized
INFO - 2017-04-08 00:17:42 --> Output Class Initialized
INFO - 2017-04-08 00:17:42 --> Security Class Initialized
DEBUG - 2017-04-08 00:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:17:42 --> Input Class Initialized
INFO - 2017-04-08 00:17:42 --> Language Class Initialized
INFO - 2017-04-08 00:17:42 --> Loader Class Initialized
INFO - 2017-04-08 00:17:42 --> Helper loaded: url_helper
INFO - 2017-04-08 00:17:42 --> Helper loaded: language_helper
INFO - 2017-04-08 00:17:42 --> Helper loaded: html_helper
INFO - 2017-04-08 00:17:43 --> Helper loaded: form_helper
INFO - 2017-04-08 00:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:17:43 --> Controller Class Initialized
INFO - 2017-04-08 00:17:43 --> Database Driver Class Initialized
INFO - 2017-04-08 00:17:43 --> Model Class Initialized
INFO - 2017-04-08 00:17:43 --> Model Class Initialized
INFO - 2017-04-08 00:17:43 --> Email Class Initialized
INFO - 2017-04-08 00:17:43 --> Form Validation Class Initialized
INFO - 2017-04-08 00:17:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:17:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:17:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:17:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:17:43 --> Final output sent to browser
DEBUG - 2017-04-08 00:17:43 --> Total execution time: 0.1016
INFO - 2017-04-08 00:24:57 --> Config Class Initialized
INFO - 2017-04-08 00:24:57 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:24:57 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:24:57 --> Utf8 Class Initialized
INFO - 2017-04-08 00:24:57 --> URI Class Initialized
INFO - 2017-04-08 00:24:57 --> Router Class Initialized
INFO - 2017-04-08 00:24:57 --> Output Class Initialized
INFO - 2017-04-08 00:24:57 --> Security Class Initialized
DEBUG - 2017-04-08 00:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:24:57 --> Input Class Initialized
INFO - 2017-04-08 00:24:57 --> Language Class Initialized
INFO - 2017-04-08 00:24:57 --> Loader Class Initialized
INFO - 2017-04-08 00:24:57 --> Helper loaded: url_helper
INFO - 2017-04-08 00:24:57 --> Helper loaded: language_helper
INFO - 2017-04-08 00:24:57 --> Helper loaded: html_helper
INFO - 2017-04-08 00:24:57 --> Helper loaded: form_helper
INFO - 2017-04-08 00:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:24:57 --> Controller Class Initialized
INFO - 2017-04-08 00:24:57 --> Database Driver Class Initialized
INFO - 2017-04-08 00:24:57 --> Model Class Initialized
INFO - 2017-04-08 00:24:57 --> Model Class Initialized
INFO - 2017-04-08 00:24:57 --> Email Class Initialized
INFO - 2017-04-08 00:24:57 --> Form Validation Class Initialized
INFO - 2017-04-08 00:24:57 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-04-08 00:24:57 --> Severity: Warning --> Missing argument 1 for Register::getkotabyprovinsi() C:\wamp64\www\savsoftquiz\application\controllers\Register.php 121
INFO - 2017-04-08 00:24:57 --> Final output sent to browser
DEBUG - 2017-04-08 00:24:57 --> Total execution time: 0.0778
INFO - 2017-04-08 00:25:06 --> Config Class Initialized
INFO - 2017-04-08 00:25:06 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:25:06 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:25:06 --> Utf8 Class Initialized
INFO - 2017-04-08 00:25:06 --> URI Class Initialized
INFO - 2017-04-08 00:25:06 --> Router Class Initialized
INFO - 2017-04-08 00:25:06 --> Output Class Initialized
INFO - 2017-04-08 00:25:06 --> Security Class Initialized
DEBUG - 2017-04-08 00:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:25:06 --> Input Class Initialized
INFO - 2017-04-08 00:25:06 --> Language Class Initialized
INFO - 2017-04-08 00:25:06 --> Loader Class Initialized
INFO - 2017-04-08 00:25:06 --> Helper loaded: url_helper
INFO - 2017-04-08 00:25:06 --> Helper loaded: language_helper
INFO - 2017-04-08 00:25:06 --> Helper loaded: html_helper
INFO - 2017-04-08 00:25:06 --> Helper loaded: form_helper
INFO - 2017-04-08 00:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:25:06 --> Controller Class Initialized
INFO - 2017-04-08 00:25:06 --> Database Driver Class Initialized
INFO - 2017-04-08 00:25:06 --> Model Class Initialized
INFO - 2017-04-08 00:25:06 --> Model Class Initialized
INFO - 2017-04-08 00:25:06 --> Email Class Initialized
INFO - 2017-04-08 00:25:06 --> Form Validation Class Initialized
INFO - 2017-04-08 00:25:06 --> Language file loaded: language/indonesia/basic_lang.php
ERROR - 2017-04-08 00:25:06 --> Severity: Warning --> Missing argument 1 for Register::getkotabyprovinsi() C:\wamp64\www\savsoftquiz\application\controllers\Register.php 121
INFO - 2017-04-08 00:25:06 --> Final output sent to browser
DEBUG - 2017-04-08 00:25:06 --> Total execution time: 0.0773
INFO - 2017-04-08 00:26:12 --> Config Class Initialized
INFO - 2017-04-08 00:26:12 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:26:12 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:26:12 --> Utf8 Class Initialized
INFO - 2017-04-08 00:26:12 --> URI Class Initialized
INFO - 2017-04-08 00:26:12 --> Router Class Initialized
INFO - 2017-04-08 00:26:12 --> Output Class Initialized
INFO - 2017-04-08 00:26:12 --> Security Class Initialized
DEBUG - 2017-04-08 00:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:26:12 --> Input Class Initialized
INFO - 2017-04-08 00:26:12 --> Language Class Initialized
INFO - 2017-04-08 00:26:12 --> Loader Class Initialized
INFO - 2017-04-08 00:26:12 --> Helper loaded: url_helper
INFO - 2017-04-08 00:26:12 --> Helper loaded: language_helper
INFO - 2017-04-08 00:26:12 --> Helper loaded: html_helper
INFO - 2017-04-08 00:26:12 --> Helper loaded: form_helper
INFO - 2017-04-08 00:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:26:12 --> Controller Class Initialized
INFO - 2017-04-08 00:26:12 --> Database Driver Class Initialized
INFO - 2017-04-08 00:26:12 --> Model Class Initialized
INFO - 2017-04-08 00:26:12 --> Model Class Initialized
INFO - 2017-04-08 00:26:12 --> Email Class Initialized
INFO - 2017-04-08 00:26:12 --> Form Validation Class Initialized
INFO - 2017-04-08 00:26:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:26:12 --> Final output sent to browser
DEBUG - 2017-04-08 00:26:12 --> Total execution time: 0.0757
INFO - 2017-04-08 00:32:28 --> Config Class Initialized
INFO - 2017-04-08 00:32:28 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:32:28 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:32:28 --> Utf8 Class Initialized
INFO - 2017-04-08 00:32:28 --> URI Class Initialized
INFO - 2017-04-08 00:32:28 --> Router Class Initialized
INFO - 2017-04-08 00:32:28 --> Output Class Initialized
INFO - 2017-04-08 00:32:28 --> Security Class Initialized
DEBUG - 2017-04-08 00:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:32:28 --> Input Class Initialized
INFO - 2017-04-08 00:32:28 --> Language Class Initialized
INFO - 2017-04-08 00:32:28 --> Loader Class Initialized
INFO - 2017-04-08 00:32:28 --> Helper loaded: url_helper
INFO - 2017-04-08 00:32:28 --> Helper loaded: language_helper
INFO - 2017-04-08 00:32:28 --> Helper loaded: html_helper
INFO - 2017-04-08 00:32:28 --> Helper loaded: form_helper
INFO - 2017-04-08 00:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:32:28 --> Controller Class Initialized
INFO - 2017-04-08 00:32:28 --> Database Driver Class Initialized
INFO - 2017-04-08 00:32:28 --> Model Class Initialized
INFO - 2017-04-08 00:32:28 --> Model Class Initialized
INFO - 2017-04-08 00:32:28 --> Email Class Initialized
INFO - 2017-04-08 00:32:28 --> Form Validation Class Initialized
INFO - 2017-04-08 00:32:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:32:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:32:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:32:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:32:28 --> Final output sent to browser
DEBUG - 2017-04-08 00:32:28 --> Total execution time: 0.0938
INFO - 2017-04-08 00:34:42 --> Config Class Initialized
INFO - 2017-04-08 00:34:42 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:34:42 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:34:42 --> Utf8 Class Initialized
INFO - 2017-04-08 00:34:42 --> URI Class Initialized
INFO - 2017-04-08 00:34:42 --> Router Class Initialized
INFO - 2017-04-08 00:34:42 --> Output Class Initialized
INFO - 2017-04-08 00:34:42 --> Security Class Initialized
DEBUG - 2017-04-08 00:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:34:42 --> Input Class Initialized
INFO - 2017-04-08 00:34:42 --> Language Class Initialized
INFO - 2017-04-08 00:34:42 --> Loader Class Initialized
INFO - 2017-04-08 00:34:42 --> Helper loaded: url_helper
INFO - 2017-04-08 00:34:42 --> Helper loaded: language_helper
INFO - 2017-04-08 00:34:42 --> Helper loaded: html_helper
INFO - 2017-04-08 00:34:42 --> Helper loaded: form_helper
INFO - 2017-04-08 00:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:34:42 --> Controller Class Initialized
INFO - 2017-04-08 00:34:42 --> Database Driver Class Initialized
INFO - 2017-04-08 00:34:42 --> Model Class Initialized
INFO - 2017-04-08 00:34:42 --> Model Class Initialized
INFO - 2017-04-08 00:34:42 --> Email Class Initialized
INFO - 2017-04-08 00:34:42 --> Form Validation Class Initialized
INFO - 2017-04-08 00:34:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:34:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:34:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:34:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:34:42 --> Final output sent to browser
DEBUG - 2017-04-08 00:34:42 --> Total execution time: 0.0959
INFO - 2017-04-08 00:35:02 --> Config Class Initialized
INFO - 2017-04-08 00:35:02 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:35:02 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:35:02 --> Utf8 Class Initialized
INFO - 2017-04-08 00:35:02 --> URI Class Initialized
INFO - 2017-04-08 00:35:02 --> Router Class Initialized
INFO - 2017-04-08 00:35:02 --> Output Class Initialized
INFO - 2017-04-08 00:35:02 --> Security Class Initialized
DEBUG - 2017-04-08 00:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:35:02 --> Input Class Initialized
INFO - 2017-04-08 00:35:02 --> Language Class Initialized
INFO - 2017-04-08 00:35:02 --> Loader Class Initialized
INFO - 2017-04-08 00:35:02 --> Helper loaded: url_helper
INFO - 2017-04-08 00:35:02 --> Helper loaded: language_helper
INFO - 2017-04-08 00:35:02 --> Helper loaded: html_helper
INFO - 2017-04-08 00:35:02 --> Helper loaded: form_helper
INFO - 2017-04-08 00:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:35:02 --> Controller Class Initialized
INFO - 2017-04-08 00:35:02 --> Database Driver Class Initialized
INFO - 2017-04-08 00:35:02 --> Model Class Initialized
INFO - 2017-04-08 00:35:02 --> Model Class Initialized
INFO - 2017-04-08 00:35:02 --> Email Class Initialized
INFO - 2017-04-08 00:35:02 --> Form Validation Class Initialized
INFO - 2017-04-08 00:35:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:35:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:35:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:35:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:35:02 --> Final output sent to browser
DEBUG - 2017-04-08 00:35:02 --> Total execution time: 0.1057
INFO - 2017-04-08 00:40:04 --> Config Class Initialized
INFO - 2017-04-08 00:40:04 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:40:04 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:40:04 --> Utf8 Class Initialized
INFO - 2017-04-08 00:40:04 --> URI Class Initialized
INFO - 2017-04-08 00:40:04 --> Router Class Initialized
INFO - 2017-04-08 00:40:04 --> Output Class Initialized
INFO - 2017-04-08 00:40:04 --> Security Class Initialized
DEBUG - 2017-04-08 00:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:40:04 --> Input Class Initialized
INFO - 2017-04-08 00:40:04 --> Language Class Initialized
INFO - 2017-04-08 00:40:04 --> Loader Class Initialized
INFO - 2017-04-08 00:40:04 --> Helper loaded: url_helper
INFO - 2017-04-08 00:40:04 --> Helper loaded: language_helper
INFO - 2017-04-08 00:40:04 --> Helper loaded: html_helper
INFO - 2017-04-08 00:40:04 --> Helper loaded: form_helper
INFO - 2017-04-08 00:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:40:04 --> Controller Class Initialized
INFO - 2017-04-08 00:40:04 --> Database Driver Class Initialized
INFO - 2017-04-08 00:40:04 --> Model Class Initialized
INFO - 2017-04-08 00:40:04 --> Model Class Initialized
INFO - 2017-04-08 00:40:04 --> Email Class Initialized
INFO - 2017-04-08 00:40:04 --> Form Validation Class Initialized
INFO - 2017-04-08 00:40:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:40:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:40:04 --> Final output sent to browser
DEBUG - 2017-04-08 00:40:04 --> Total execution time: 0.0900
INFO - 2017-04-08 00:40:46 --> Config Class Initialized
INFO - 2017-04-08 00:40:46 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:40:46 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:40:46 --> Utf8 Class Initialized
INFO - 2017-04-08 00:40:46 --> URI Class Initialized
INFO - 2017-04-08 00:40:46 --> Router Class Initialized
INFO - 2017-04-08 00:40:46 --> Output Class Initialized
INFO - 2017-04-08 00:40:46 --> Security Class Initialized
DEBUG - 2017-04-08 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:40:46 --> Input Class Initialized
INFO - 2017-04-08 00:40:46 --> Language Class Initialized
INFO - 2017-04-08 00:40:46 --> Loader Class Initialized
INFO - 2017-04-08 00:40:46 --> Helper loaded: url_helper
INFO - 2017-04-08 00:40:46 --> Helper loaded: language_helper
INFO - 2017-04-08 00:40:46 --> Helper loaded: html_helper
INFO - 2017-04-08 00:40:46 --> Helper loaded: form_helper
INFO - 2017-04-08 00:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:40:46 --> Controller Class Initialized
INFO - 2017-04-08 00:40:46 --> Database Driver Class Initialized
INFO - 2017-04-08 00:40:46 --> Model Class Initialized
INFO - 2017-04-08 00:40:46 --> Model Class Initialized
INFO - 2017-04-08 00:40:46 --> Email Class Initialized
INFO - 2017-04-08 00:40:46 --> Form Validation Class Initialized
INFO - 2017-04-08 00:40:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:40:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:40:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:40:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:40:46 --> Final output sent to browser
DEBUG - 2017-04-08 00:40:46 --> Total execution time: 0.0863
INFO - 2017-04-08 00:41:24 --> Config Class Initialized
INFO - 2017-04-08 00:41:24 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:41:24 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:41:24 --> Utf8 Class Initialized
INFO - 2017-04-08 00:41:24 --> URI Class Initialized
INFO - 2017-04-08 00:41:24 --> Router Class Initialized
INFO - 2017-04-08 00:41:24 --> Output Class Initialized
INFO - 2017-04-08 00:41:24 --> Security Class Initialized
DEBUG - 2017-04-08 00:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:41:24 --> Input Class Initialized
INFO - 2017-04-08 00:41:24 --> Language Class Initialized
INFO - 2017-04-08 00:41:24 --> Loader Class Initialized
INFO - 2017-04-08 00:41:24 --> Helper loaded: url_helper
INFO - 2017-04-08 00:41:24 --> Helper loaded: language_helper
INFO - 2017-04-08 00:41:24 --> Helper loaded: html_helper
INFO - 2017-04-08 00:41:24 --> Helper loaded: form_helper
INFO - 2017-04-08 00:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:41:24 --> Controller Class Initialized
INFO - 2017-04-08 00:41:24 --> Database Driver Class Initialized
INFO - 2017-04-08 00:41:24 --> Model Class Initialized
INFO - 2017-04-08 00:41:24 --> Model Class Initialized
INFO - 2017-04-08 00:41:24 --> Email Class Initialized
INFO - 2017-04-08 00:41:24 --> Form Validation Class Initialized
INFO - 2017-04-08 00:41:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:41:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:41:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:41:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:41:24 --> Final output sent to browser
DEBUG - 2017-04-08 00:41:24 --> Total execution time: 0.0899
INFO - 2017-04-08 00:42:35 --> Config Class Initialized
INFO - 2017-04-08 00:42:35 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:42:35 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:42:35 --> Utf8 Class Initialized
INFO - 2017-04-08 00:42:35 --> URI Class Initialized
INFO - 2017-04-08 00:42:35 --> Router Class Initialized
INFO - 2017-04-08 00:42:35 --> Output Class Initialized
INFO - 2017-04-08 00:42:35 --> Security Class Initialized
DEBUG - 2017-04-08 00:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:42:35 --> Input Class Initialized
INFO - 2017-04-08 00:42:35 --> Language Class Initialized
INFO - 2017-04-08 00:42:35 --> Loader Class Initialized
INFO - 2017-04-08 00:42:35 --> Helper loaded: url_helper
INFO - 2017-04-08 00:42:35 --> Helper loaded: language_helper
INFO - 2017-04-08 00:42:35 --> Helper loaded: html_helper
INFO - 2017-04-08 00:42:35 --> Helper loaded: form_helper
INFO - 2017-04-08 00:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:42:35 --> Controller Class Initialized
INFO - 2017-04-08 00:42:35 --> Database Driver Class Initialized
INFO - 2017-04-08 00:42:35 --> Model Class Initialized
INFO - 2017-04-08 00:42:35 --> Model Class Initialized
INFO - 2017-04-08 00:42:35 --> Email Class Initialized
INFO - 2017-04-08 00:42:35 --> Form Validation Class Initialized
INFO - 2017-04-08 00:42:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:42:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:42:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:42:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:42:35 --> Final output sent to browser
DEBUG - 2017-04-08 00:42:35 --> Total execution time: 0.1091
INFO - 2017-04-08 00:43:40 --> Config Class Initialized
INFO - 2017-04-08 00:43:40 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:43:40 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:43:40 --> Utf8 Class Initialized
INFO - 2017-04-08 00:43:40 --> URI Class Initialized
INFO - 2017-04-08 00:43:40 --> Router Class Initialized
INFO - 2017-04-08 00:43:40 --> Output Class Initialized
INFO - 2017-04-08 00:43:40 --> Security Class Initialized
DEBUG - 2017-04-08 00:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:43:40 --> Input Class Initialized
INFO - 2017-04-08 00:43:40 --> Language Class Initialized
INFO - 2017-04-08 00:43:40 --> Loader Class Initialized
INFO - 2017-04-08 00:43:40 --> Helper loaded: url_helper
INFO - 2017-04-08 00:43:40 --> Helper loaded: language_helper
INFO - 2017-04-08 00:43:40 --> Helper loaded: html_helper
INFO - 2017-04-08 00:43:40 --> Helper loaded: form_helper
INFO - 2017-04-08 00:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:43:40 --> Controller Class Initialized
INFO - 2017-04-08 00:43:40 --> Database Driver Class Initialized
INFO - 2017-04-08 00:43:40 --> Model Class Initialized
INFO - 2017-04-08 00:43:40 --> Model Class Initialized
INFO - 2017-04-08 00:43:40 --> Email Class Initialized
INFO - 2017-04-08 00:43:40 --> Form Validation Class Initialized
INFO - 2017-04-08 00:43:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:43:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:43:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:43:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:43:40 --> Final output sent to browser
DEBUG - 2017-04-08 00:43:40 --> Total execution time: 0.1119
INFO - 2017-04-08 00:44:56 --> Config Class Initialized
INFO - 2017-04-08 00:44:56 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:44:56 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:44:56 --> Utf8 Class Initialized
INFO - 2017-04-08 00:44:56 --> URI Class Initialized
INFO - 2017-04-08 00:44:56 --> Router Class Initialized
INFO - 2017-04-08 00:44:56 --> Output Class Initialized
INFO - 2017-04-08 00:44:56 --> Security Class Initialized
DEBUG - 2017-04-08 00:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:44:56 --> Input Class Initialized
INFO - 2017-04-08 00:44:56 --> Language Class Initialized
INFO - 2017-04-08 00:44:56 --> Loader Class Initialized
INFO - 2017-04-08 00:44:56 --> Helper loaded: url_helper
INFO - 2017-04-08 00:44:56 --> Helper loaded: language_helper
INFO - 2017-04-08 00:44:56 --> Helper loaded: html_helper
INFO - 2017-04-08 00:44:56 --> Helper loaded: form_helper
INFO - 2017-04-08 00:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:44:56 --> Controller Class Initialized
INFO - 2017-04-08 00:44:56 --> Database Driver Class Initialized
INFO - 2017-04-08 00:44:56 --> Model Class Initialized
INFO - 2017-04-08 00:44:56 --> Model Class Initialized
INFO - 2017-04-08 00:44:56 --> Email Class Initialized
INFO - 2017-04-08 00:44:56 --> Form Validation Class Initialized
INFO - 2017-04-08 00:44:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:44:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:44:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:44:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:44:56 --> Final output sent to browser
DEBUG - 2017-04-08 00:44:56 --> Total execution time: 0.0873
INFO - 2017-04-08 00:49:19 --> Config Class Initialized
INFO - 2017-04-08 00:49:19 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:49:19 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:49:19 --> Utf8 Class Initialized
INFO - 2017-04-08 00:49:19 --> URI Class Initialized
INFO - 2017-04-08 00:49:19 --> Router Class Initialized
INFO - 2017-04-08 00:49:19 --> Output Class Initialized
INFO - 2017-04-08 00:49:19 --> Security Class Initialized
DEBUG - 2017-04-08 00:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:49:19 --> Input Class Initialized
INFO - 2017-04-08 00:49:19 --> Language Class Initialized
INFO - 2017-04-08 00:49:19 --> Loader Class Initialized
INFO - 2017-04-08 00:49:19 --> Helper loaded: url_helper
INFO - 2017-04-08 00:49:19 --> Helper loaded: language_helper
INFO - 2017-04-08 00:49:19 --> Helper loaded: html_helper
INFO - 2017-04-08 00:49:19 --> Helper loaded: form_helper
INFO - 2017-04-08 00:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:49:19 --> Controller Class Initialized
INFO - 2017-04-08 00:49:19 --> Database Driver Class Initialized
INFO - 2017-04-08 00:49:19 --> Model Class Initialized
INFO - 2017-04-08 00:49:19 --> Model Class Initialized
INFO - 2017-04-08 00:49:19 --> Email Class Initialized
INFO - 2017-04-08 00:49:19 --> Form Validation Class Initialized
INFO - 2017-04-08 00:49:19 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:49:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:49:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:49:19 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:49:19 --> Final output sent to browser
DEBUG - 2017-04-08 00:49:19 --> Total execution time: 0.1005
INFO - 2017-04-08 00:50:16 --> Config Class Initialized
INFO - 2017-04-08 00:50:16 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:50:16 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:50:16 --> Utf8 Class Initialized
INFO - 2017-04-08 00:50:16 --> URI Class Initialized
INFO - 2017-04-08 00:50:16 --> Router Class Initialized
INFO - 2017-04-08 00:50:16 --> Output Class Initialized
INFO - 2017-04-08 00:50:16 --> Security Class Initialized
DEBUG - 2017-04-08 00:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:50:16 --> Input Class Initialized
INFO - 2017-04-08 00:50:16 --> Language Class Initialized
INFO - 2017-04-08 00:50:16 --> Loader Class Initialized
INFO - 2017-04-08 00:50:16 --> Helper loaded: url_helper
INFO - 2017-04-08 00:50:16 --> Helper loaded: language_helper
INFO - 2017-04-08 00:50:16 --> Helper loaded: html_helper
INFO - 2017-04-08 00:50:16 --> Helper loaded: form_helper
INFO - 2017-04-08 00:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:50:16 --> Controller Class Initialized
INFO - 2017-04-08 00:50:16 --> Database Driver Class Initialized
INFO - 2017-04-08 00:50:16 --> Model Class Initialized
INFO - 2017-04-08 00:50:16 --> Model Class Initialized
INFO - 2017-04-08 00:50:16 --> Email Class Initialized
INFO - 2017-04-08 00:50:16 --> Form Validation Class Initialized
INFO - 2017-04-08 00:50:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:50:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:50:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:50:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:50:16 --> Final output sent to browser
DEBUG - 2017-04-08 00:50:16 --> Total execution time: 0.1035
INFO - 2017-04-08 00:51:00 --> Config Class Initialized
INFO - 2017-04-08 00:51:00 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:51:00 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:51:00 --> Utf8 Class Initialized
INFO - 2017-04-08 00:51:00 --> URI Class Initialized
INFO - 2017-04-08 00:51:00 --> Router Class Initialized
INFO - 2017-04-08 00:51:00 --> Output Class Initialized
INFO - 2017-04-08 00:51:00 --> Security Class Initialized
DEBUG - 2017-04-08 00:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:51:00 --> Input Class Initialized
INFO - 2017-04-08 00:51:00 --> Language Class Initialized
INFO - 2017-04-08 00:51:00 --> Loader Class Initialized
INFO - 2017-04-08 00:51:00 --> Helper loaded: url_helper
INFO - 2017-04-08 00:51:00 --> Helper loaded: language_helper
INFO - 2017-04-08 00:51:00 --> Helper loaded: html_helper
INFO - 2017-04-08 00:51:00 --> Helper loaded: form_helper
INFO - 2017-04-08 00:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:51:00 --> Controller Class Initialized
INFO - 2017-04-08 00:51:00 --> Database Driver Class Initialized
INFO - 2017-04-08 00:51:00 --> Model Class Initialized
INFO - 2017-04-08 00:51:00 --> Model Class Initialized
INFO - 2017-04-08 00:51:00 --> Email Class Initialized
INFO - 2017-04-08 00:51:00 --> Form Validation Class Initialized
INFO - 2017-04-08 00:51:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:51:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:51:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:51:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:51:00 --> Final output sent to browser
DEBUG - 2017-04-08 00:51:00 --> Total execution time: 0.0896
INFO - 2017-04-08 00:55:26 --> Config Class Initialized
INFO - 2017-04-08 00:55:26 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:55:26 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:55:26 --> Utf8 Class Initialized
INFO - 2017-04-08 00:55:26 --> URI Class Initialized
INFO - 2017-04-08 00:55:26 --> Router Class Initialized
INFO - 2017-04-08 00:55:26 --> Output Class Initialized
INFO - 2017-04-08 00:55:26 --> Security Class Initialized
DEBUG - 2017-04-08 00:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:55:26 --> Input Class Initialized
INFO - 2017-04-08 00:55:26 --> Language Class Initialized
INFO - 2017-04-08 00:55:26 --> Loader Class Initialized
INFO - 2017-04-08 00:55:26 --> Helper loaded: url_helper
INFO - 2017-04-08 00:55:26 --> Helper loaded: language_helper
INFO - 2017-04-08 00:55:26 --> Helper loaded: html_helper
INFO - 2017-04-08 00:55:26 --> Helper loaded: form_helper
INFO - 2017-04-08 00:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:55:26 --> Controller Class Initialized
INFO - 2017-04-08 00:55:26 --> Database Driver Class Initialized
INFO - 2017-04-08 00:55:26 --> Model Class Initialized
INFO - 2017-04-08 00:55:26 --> Model Class Initialized
INFO - 2017-04-08 00:55:26 --> Email Class Initialized
INFO - 2017-04-08 00:55:26 --> Form Validation Class Initialized
INFO - 2017-04-08 00:55:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:55:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:55:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:55:26 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:55:26 --> Final output sent to browser
DEBUG - 2017-04-08 00:55:26 --> Total execution time: 0.0994
INFO - 2017-04-08 00:55:43 --> Config Class Initialized
INFO - 2017-04-08 00:55:43 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:55:43 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:55:43 --> Utf8 Class Initialized
INFO - 2017-04-08 00:55:43 --> URI Class Initialized
INFO - 2017-04-08 00:55:43 --> Router Class Initialized
INFO - 2017-04-08 00:55:43 --> Output Class Initialized
INFO - 2017-04-08 00:55:43 --> Security Class Initialized
DEBUG - 2017-04-08 00:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:55:43 --> Input Class Initialized
INFO - 2017-04-08 00:55:43 --> Language Class Initialized
INFO - 2017-04-08 00:55:43 --> Loader Class Initialized
INFO - 2017-04-08 00:55:43 --> Helper loaded: url_helper
INFO - 2017-04-08 00:55:43 --> Helper loaded: language_helper
INFO - 2017-04-08 00:55:43 --> Helper loaded: html_helper
INFO - 2017-04-08 00:55:43 --> Helper loaded: form_helper
INFO - 2017-04-08 00:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:55:43 --> Controller Class Initialized
INFO - 2017-04-08 00:55:43 --> Database Driver Class Initialized
INFO - 2017-04-08 00:55:43 --> Model Class Initialized
INFO - 2017-04-08 00:55:43 --> Model Class Initialized
INFO - 2017-04-08 00:55:43 --> Email Class Initialized
INFO - 2017-04-08 00:55:43 --> Form Validation Class Initialized
INFO - 2017-04-08 00:55:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:55:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:55:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:55:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:55:43 --> Final output sent to browser
DEBUG - 2017-04-08 00:55:43 --> Total execution time: 0.1141
INFO - 2017-04-08 00:55:55 --> Config Class Initialized
INFO - 2017-04-08 00:55:55 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:55:55 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:55:55 --> Utf8 Class Initialized
INFO - 2017-04-08 00:55:55 --> URI Class Initialized
INFO - 2017-04-08 00:55:55 --> Router Class Initialized
INFO - 2017-04-08 00:55:55 --> Output Class Initialized
INFO - 2017-04-08 00:55:55 --> Security Class Initialized
DEBUG - 2017-04-08 00:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:55:55 --> Input Class Initialized
INFO - 2017-04-08 00:55:55 --> Language Class Initialized
INFO - 2017-04-08 00:55:55 --> Loader Class Initialized
INFO - 2017-04-08 00:55:55 --> Helper loaded: url_helper
INFO - 2017-04-08 00:55:55 --> Helper loaded: language_helper
INFO - 2017-04-08 00:55:55 --> Helper loaded: html_helper
INFO - 2017-04-08 00:55:55 --> Helper loaded: form_helper
INFO - 2017-04-08 00:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:55:55 --> Controller Class Initialized
INFO - 2017-04-08 00:55:55 --> Database Driver Class Initialized
INFO - 2017-04-08 00:55:55 --> Model Class Initialized
INFO - 2017-04-08 00:55:55 --> Model Class Initialized
INFO - 2017-04-08 00:55:55 --> Email Class Initialized
INFO - 2017-04-08 00:55:55 --> Form Validation Class Initialized
INFO - 2017-04-08 00:55:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:55:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:55:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:55:55 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:55:55 --> Final output sent to browser
DEBUG - 2017-04-08 00:55:55 --> Total execution time: 0.1414
INFO - 2017-04-08 00:56:54 --> Config Class Initialized
INFO - 2017-04-08 00:56:54 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:56:54 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:56:54 --> Utf8 Class Initialized
INFO - 2017-04-08 00:56:54 --> URI Class Initialized
INFO - 2017-04-08 00:56:54 --> Router Class Initialized
INFO - 2017-04-08 00:56:54 --> Output Class Initialized
INFO - 2017-04-08 00:56:54 --> Security Class Initialized
DEBUG - 2017-04-08 00:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:56:54 --> Input Class Initialized
INFO - 2017-04-08 00:56:54 --> Language Class Initialized
INFO - 2017-04-08 00:56:54 --> Loader Class Initialized
INFO - 2017-04-08 00:56:54 --> Helper loaded: url_helper
INFO - 2017-04-08 00:56:54 --> Helper loaded: language_helper
INFO - 2017-04-08 00:56:54 --> Helper loaded: html_helper
INFO - 2017-04-08 00:56:54 --> Helper loaded: form_helper
INFO - 2017-04-08 00:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:56:54 --> Controller Class Initialized
INFO - 2017-04-08 00:56:54 --> Database Driver Class Initialized
INFO - 2017-04-08 00:56:54 --> Model Class Initialized
INFO - 2017-04-08 00:56:54 --> Model Class Initialized
INFO - 2017-04-08 00:56:54 --> Email Class Initialized
INFO - 2017-04-08 00:56:54 --> Form Validation Class Initialized
INFO - 2017-04-08 00:56:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:56:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:56:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:56:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:56:54 --> Final output sent to browser
DEBUG - 2017-04-08 00:56:54 --> Total execution time: 0.0969
INFO - 2017-04-08 00:57:47 --> Config Class Initialized
INFO - 2017-04-08 00:57:47 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:57:48 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:57:48 --> Utf8 Class Initialized
INFO - 2017-04-08 00:57:48 --> URI Class Initialized
INFO - 2017-04-08 00:57:48 --> Router Class Initialized
INFO - 2017-04-08 00:57:48 --> Output Class Initialized
INFO - 2017-04-08 00:57:48 --> Security Class Initialized
DEBUG - 2017-04-08 00:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:57:48 --> Input Class Initialized
INFO - 2017-04-08 00:57:48 --> Language Class Initialized
INFO - 2017-04-08 00:57:48 --> Loader Class Initialized
INFO - 2017-04-08 00:57:48 --> Helper loaded: url_helper
INFO - 2017-04-08 00:57:48 --> Helper loaded: language_helper
INFO - 2017-04-08 00:57:48 --> Helper loaded: html_helper
INFO - 2017-04-08 00:57:48 --> Helper loaded: form_helper
INFO - 2017-04-08 00:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:57:48 --> Controller Class Initialized
INFO - 2017-04-08 00:57:48 --> Database Driver Class Initialized
INFO - 2017-04-08 00:57:48 --> Model Class Initialized
INFO - 2017-04-08 00:57:48 --> Model Class Initialized
INFO - 2017-04-08 00:57:48 --> Email Class Initialized
INFO - 2017-04-08 00:57:48 --> Form Validation Class Initialized
INFO - 2017-04-08 00:57:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:57:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:57:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:57:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:57:48 --> Final output sent to browser
DEBUG - 2017-04-08 00:57:48 --> Total execution time: 0.0899
INFO - 2017-04-08 00:58:10 --> Config Class Initialized
INFO - 2017-04-08 00:58:10 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:58:10 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:58:10 --> Utf8 Class Initialized
INFO - 2017-04-08 00:58:10 --> URI Class Initialized
INFO - 2017-04-08 00:58:10 --> Router Class Initialized
INFO - 2017-04-08 00:58:10 --> Output Class Initialized
INFO - 2017-04-08 00:58:10 --> Security Class Initialized
DEBUG - 2017-04-08 00:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:58:10 --> Input Class Initialized
INFO - 2017-04-08 00:58:10 --> Language Class Initialized
INFO - 2017-04-08 00:58:10 --> Loader Class Initialized
INFO - 2017-04-08 00:58:10 --> Helper loaded: url_helper
INFO - 2017-04-08 00:58:10 --> Helper loaded: language_helper
INFO - 2017-04-08 00:58:10 --> Helper loaded: html_helper
INFO - 2017-04-08 00:58:10 --> Helper loaded: form_helper
INFO - 2017-04-08 00:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:58:10 --> Controller Class Initialized
INFO - 2017-04-08 00:58:10 --> Database Driver Class Initialized
INFO - 2017-04-08 00:58:10 --> Model Class Initialized
INFO - 2017-04-08 00:58:10 --> Model Class Initialized
INFO - 2017-04-08 00:58:10 --> Email Class Initialized
INFO - 2017-04-08 00:58:10 --> Form Validation Class Initialized
INFO - 2017-04-08 00:58:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:58:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:58:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:58:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:58:10 --> Final output sent to browser
DEBUG - 2017-04-08 00:58:10 --> Total execution time: 0.1095
INFO - 2017-04-08 00:58:53 --> Config Class Initialized
INFO - 2017-04-08 00:58:53 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:58:53 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:58:53 --> Utf8 Class Initialized
INFO - 2017-04-08 00:58:53 --> URI Class Initialized
INFO - 2017-04-08 00:58:53 --> Router Class Initialized
INFO - 2017-04-08 00:58:53 --> Output Class Initialized
INFO - 2017-04-08 00:58:53 --> Security Class Initialized
DEBUG - 2017-04-08 00:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:58:53 --> Input Class Initialized
INFO - 2017-04-08 00:58:53 --> Language Class Initialized
INFO - 2017-04-08 00:58:53 --> Loader Class Initialized
INFO - 2017-04-08 00:58:53 --> Helper loaded: url_helper
INFO - 2017-04-08 00:58:53 --> Helper loaded: language_helper
INFO - 2017-04-08 00:58:53 --> Helper loaded: html_helper
INFO - 2017-04-08 00:58:53 --> Helper loaded: form_helper
INFO - 2017-04-08 00:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:58:53 --> Controller Class Initialized
INFO - 2017-04-08 00:58:53 --> Database Driver Class Initialized
INFO - 2017-04-08 00:58:53 --> Model Class Initialized
INFO - 2017-04-08 00:58:53 --> Model Class Initialized
INFO - 2017-04-08 00:58:53 --> Email Class Initialized
INFO - 2017-04-08 00:58:53 --> Form Validation Class Initialized
INFO - 2017-04-08 00:58:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:58:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:58:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:58:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:58:53 --> Final output sent to browser
DEBUG - 2017-04-08 00:58:53 --> Total execution time: 0.0867
INFO - 2017-04-08 00:59:40 --> Config Class Initialized
INFO - 2017-04-08 00:59:40 --> Hooks Class Initialized
DEBUG - 2017-04-08 00:59:40 --> UTF-8 Support Enabled
INFO - 2017-04-08 00:59:40 --> Utf8 Class Initialized
INFO - 2017-04-08 00:59:40 --> URI Class Initialized
INFO - 2017-04-08 00:59:40 --> Router Class Initialized
INFO - 2017-04-08 00:59:40 --> Output Class Initialized
INFO - 2017-04-08 00:59:40 --> Security Class Initialized
DEBUG - 2017-04-08 00:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 00:59:40 --> Input Class Initialized
INFO - 2017-04-08 00:59:40 --> Language Class Initialized
INFO - 2017-04-08 00:59:40 --> Loader Class Initialized
INFO - 2017-04-08 00:59:40 --> Helper loaded: url_helper
INFO - 2017-04-08 00:59:40 --> Helper loaded: language_helper
INFO - 2017-04-08 00:59:40 --> Helper loaded: html_helper
INFO - 2017-04-08 00:59:40 --> Helper loaded: form_helper
INFO - 2017-04-08 00:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 00:59:40 --> Controller Class Initialized
INFO - 2017-04-08 00:59:40 --> Database Driver Class Initialized
INFO - 2017-04-08 00:59:40 --> Model Class Initialized
INFO - 2017-04-08 00:59:40 --> Model Class Initialized
INFO - 2017-04-08 00:59:40 --> Email Class Initialized
INFO - 2017-04-08 00:59:40 --> Form Validation Class Initialized
INFO - 2017-04-08 00:59:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 00:59:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 00:59:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 00:59:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 00:59:40 --> Final output sent to browser
DEBUG - 2017-04-08 00:59:40 --> Total execution time: 0.1110
INFO - 2017-04-08 01:00:01 --> Config Class Initialized
INFO - 2017-04-08 01:00:01 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:00:01 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:00:01 --> Utf8 Class Initialized
INFO - 2017-04-08 01:00:01 --> URI Class Initialized
INFO - 2017-04-08 01:00:01 --> Router Class Initialized
INFO - 2017-04-08 01:00:02 --> Output Class Initialized
INFO - 2017-04-08 01:00:02 --> Security Class Initialized
DEBUG - 2017-04-08 01:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:00:02 --> Input Class Initialized
INFO - 2017-04-08 01:00:02 --> Language Class Initialized
INFO - 2017-04-08 01:00:02 --> Loader Class Initialized
INFO - 2017-04-08 01:00:02 --> Helper loaded: url_helper
INFO - 2017-04-08 01:00:02 --> Helper loaded: language_helper
INFO - 2017-04-08 01:00:02 --> Helper loaded: html_helper
INFO - 2017-04-08 01:00:02 --> Helper loaded: form_helper
INFO - 2017-04-08 01:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:00:02 --> Controller Class Initialized
INFO - 2017-04-08 01:00:02 --> Database Driver Class Initialized
INFO - 2017-04-08 01:00:02 --> Model Class Initialized
INFO - 2017-04-08 01:00:02 --> Model Class Initialized
INFO - 2017-04-08 01:00:02 --> Email Class Initialized
INFO - 2017-04-08 01:00:02 --> Form Validation Class Initialized
INFO - 2017-04-08 01:00:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:00:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:00:02 --> Final output sent to browser
DEBUG - 2017-04-08 01:00:02 --> Total execution time: 0.1086
INFO - 2017-04-08 01:00:40 --> Config Class Initialized
INFO - 2017-04-08 01:00:40 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:00:40 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:00:40 --> Utf8 Class Initialized
INFO - 2017-04-08 01:00:40 --> URI Class Initialized
INFO - 2017-04-08 01:00:40 --> Router Class Initialized
INFO - 2017-04-08 01:00:40 --> Output Class Initialized
INFO - 2017-04-08 01:00:40 --> Security Class Initialized
DEBUG - 2017-04-08 01:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:00:40 --> Input Class Initialized
INFO - 2017-04-08 01:00:40 --> Language Class Initialized
INFO - 2017-04-08 01:00:40 --> Loader Class Initialized
INFO - 2017-04-08 01:00:40 --> Helper loaded: url_helper
INFO - 2017-04-08 01:00:40 --> Helper loaded: language_helper
INFO - 2017-04-08 01:00:40 --> Helper loaded: html_helper
INFO - 2017-04-08 01:00:40 --> Helper loaded: form_helper
INFO - 2017-04-08 01:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:00:40 --> Controller Class Initialized
INFO - 2017-04-08 01:00:40 --> Database Driver Class Initialized
INFO - 2017-04-08 01:00:40 --> Model Class Initialized
INFO - 2017-04-08 01:00:40 --> Model Class Initialized
INFO - 2017-04-08 01:00:40 --> Email Class Initialized
INFO - 2017-04-08 01:00:40 --> Form Validation Class Initialized
INFO - 2017-04-08 01:00:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:00:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:00:40 --> Final output sent to browser
DEBUG - 2017-04-08 01:00:40 --> Total execution time: 0.0915
INFO - 2017-04-08 01:01:57 --> Config Class Initialized
INFO - 2017-04-08 01:01:57 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:01:57 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:01:57 --> Utf8 Class Initialized
INFO - 2017-04-08 01:01:57 --> URI Class Initialized
INFO - 2017-04-08 01:01:57 --> Router Class Initialized
INFO - 2017-04-08 01:01:57 --> Output Class Initialized
INFO - 2017-04-08 01:01:57 --> Security Class Initialized
DEBUG - 2017-04-08 01:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:01:57 --> Input Class Initialized
INFO - 2017-04-08 01:01:57 --> Language Class Initialized
INFO - 2017-04-08 01:01:57 --> Loader Class Initialized
INFO - 2017-04-08 01:01:57 --> Helper loaded: url_helper
INFO - 2017-04-08 01:01:57 --> Helper loaded: language_helper
INFO - 2017-04-08 01:01:57 --> Helper loaded: html_helper
INFO - 2017-04-08 01:01:57 --> Helper loaded: form_helper
INFO - 2017-04-08 01:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:01:57 --> Controller Class Initialized
INFO - 2017-04-08 01:01:57 --> Database Driver Class Initialized
INFO - 2017-04-08 01:01:57 --> Model Class Initialized
INFO - 2017-04-08 01:01:57 --> Model Class Initialized
INFO - 2017-04-08 01:01:57 --> Email Class Initialized
INFO - 2017-04-08 01:01:57 --> Form Validation Class Initialized
INFO - 2017-04-08 01:01:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:01:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:01:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:01:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:01:57 --> Final output sent to browser
DEBUG - 2017-04-08 01:01:57 --> Total execution time: 0.1224
INFO - 2017-04-08 01:02:53 --> Config Class Initialized
INFO - 2017-04-08 01:02:53 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:02:53 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:02:53 --> Utf8 Class Initialized
INFO - 2017-04-08 01:02:53 --> URI Class Initialized
INFO - 2017-04-08 01:02:53 --> Router Class Initialized
INFO - 2017-04-08 01:02:53 --> Output Class Initialized
INFO - 2017-04-08 01:02:53 --> Security Class Initialized
DEBUG - 2017-04-08 01:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:02:53 --> Input Class Initialized
INFO - 2017-04-08 01:02:53 --> Language Class Initialized
INFO - 2017-04-08 01:02:53 --> Loader Class Initialized
INFO - 2017-04-08 01:02:53 --> Helper loaded: url_helper
INFO - 2017-04-08 01:02:53 --> Helper loaded: language_helper
INFO - 2017-04-08 01:02:53 --> Helper loaded: html_helper
INFO - 2017-04-08 01:02:53 --> Helper loaded: form_helper
INFO - 2017-04-08 01:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:02:53 --> Controller Class Initialized
INFO - 2017-04-08 01:02:53 --> Database Driver Class Initialized
INFO - 2017-04-08 01:02:53 --> Model Class Initialized
INFO - 2017-04-08 01:02:53 --> Model Class Initialized
INFO - 2017-04-08 01:02:53 --> Email Class Initialized
INFO - 2017-04-08 01:02:53 --> Form Validation Class Initialized
INFO - 2017-04-08 01:02:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:02:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:02:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:02:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:02:53 --> Final output sent to browser
DEBUG - 2017-04-08 01:02:53 --> Total execution time: 0.0994
INFO - 2017-04-08 01:03:30 --> Config Class Initialized
INFO - 2017-04-08 01:03:30 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:03:30 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:03:30 --> Utf8 Class Initialized
INFO - 2017-04-08 01:03:30 --> URI Class Initialized
INFO - 2017-04-08 01:03:30 --> Router Class Initialized
INFO - 2017-04-08 01:03:30 --> Output Class Initialized
INFO - 2017-04-08 01:03:30 --> Security Class Initialized
DEBUG - 2017-04-08 01:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:03:30 --> Input Class Initialized
INFO - 2017-04-08 01:03:30 --> Language Class Initialized
INFO - 2017-04-08 01:03:30 --> Loader Class Initialized
INFO - 2017-04-08 01:03:30 --> Helper loaded: url_helper
INFO - 2017-04-08 01:03:30 --> Helper loaded: language_helper
INFO - 2017-04-08 01:03:30 --> Helper loaded: html_helper
INFO - 2017-04-08 01:03:30 --> Helper loaded: form_helper
INFO - 2017-04-08 01:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:03:30 --> Controller Class Initialized
INFO - 2017-04-08 01:03:30 --> Database Driver Class Initialized
INFO - 2017-04-08 01:03:30 --> Model Class Initialized
INFO - 2017-04-08 01:03:30 --> Model Class Initialized
INFO - 2017-04-08 01:03:30 --> Email Class Initialized
INFO - 2017-04-08 01:03:30 --> Form Validation Class Initialized
INFO - 2017-04-08 01:03:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:03:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:03:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:03:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:03:30 --> Final output sent to browser
DEBUG - 2017-04-08 01:03:30 --> Total execution time: 0.0927
INFO - 2017-04-08 01:03:41 --> Config Class Initialized
INFO - 2017-04-08 01:03:41 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:03:41 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:03:41 --> Utf8 Class Initialized
INFO - 2017-04-08 01:03:41 --> URI Class Initialized
INFO - 2017-04-08 01:03:41 --> Router Class Initialized
INFO - 2017-04-08 01:03:41 --> Output Class Initialized
INFO - 2017-04-08 01:03:41 --> Security Class Initialized
DEBUG - 2017-04-08 01:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:03:41 --> Input Class Initialized
INFO - 2017-04-08 01:03:41 --> Language Class Initialized
INFO - 2017-04-08 01:03:41 --> Loader Class Initialized
INFO - 2017-04-08 01:03:41 --> Helper loaded: url_helper
INFO - 2017-04-08 01:03:41 --> Helper loaded: language_helper
INFO - 2017-04-08 01:03:41 --> Helper loaded: html_helper
INFO - 2017-04-08 01:03:41 --> Helper loaded: form_helper
INFO - 2017-04-08 01:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:03:41 --> Controller Class Initialized
INFO - 2017-04-08 01:03:41 --> Database Driver Class Initialized
INFO - 2017-04-08 01:03:41 --> Model Class Initialized
INFO - 2017-04-08 01:03:41 --> Model Class Initialized
INFO - 2017-04-08 01:03:41 --> Email Class Initialized
INFO - 2017-04-08 01:03:41 --> Form Validation Class Initialized
INFO - 2017-04-08 01:03:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:03:41 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:03:41 --> Final output sent to browser
DEBUG - 2017-04-08 01:03:41 --> Total execution time: 0.1447
INFO - 2017-04-08 01:05:11 --> Config Class Initialized
INFO - 2017-04-08 01:05:11 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:05:11 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:05:11 --> Utf8 Class Initialized
INFO - 2017-04-08 01:05:11 --> URI Class Initialized
INFO - 2017-04-08 01:05:11 --> Router Class Initialized
INFO - 2017-04-08 01:05:11 --> Output Class Initialized
INFO - 2017-04-08 01:05:11 --> Security Class Initialized
DEBUG - 2017-04-08 01:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:05:11 --> Input Class Initialized
INFO - 2017-04-08 01:05:11 --> Language Class Initialized
INFO - 2017-04-08 01:05:11 --> Loader Class Initialized
INFO - 2017-04-08 01:05:11 --> Helper loaded: url_helper
INFO - 2017-04-08 01:05:11 --> Helper loaded: language_helper
INFO - 2017-04-08 01:05:11 --> Helper loaded: html_helper
INFO - 2017-04-08 01:05:11 --> Helper loaded: form_helper
INFO - 2017-04-08 01:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:05:11 --> Controller Class Initialized
INFO - 2017-04-08 01:05:11 --> Database Driver Class Initialized
INFO - 2017-04-08 01:05:11 --> Model Class Initialized
INFO - 2017-04-08 01:05:11 --> Model Class Initialized
INFO - 2017-04-08 01:05:11 --> Email Class Initialized
INFO - 2017-04-08 01:05:11 --> Form Validation Class Initialized
INFO - 2017-04-08 01:05:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:05:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:05:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:05:11 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:05:11 --> Final output sent to browser
DEBUG - 2017-04-08 01:05:11 --> Total execution time: 0.0933
INFO - 2017-04-08 01:05:48 --> Config Class Initialized
INFO - 2017-04-08 01:05:48 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:05:48 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:05:48 --> Utf8 Class Initialized
INFO - 2017-04-08 01:05:48 --> URI Class Initialized
INFO - 2017-04-08 01:05:48 --> Router Class Initialized
INFO - 2017-04-08 01:05:48 --> Output Class Initialized
INFO - 2017-04-08 01:05:48 --> Security Class Initialized
DEBUG - 2017-04-08 01:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:05:48 --> Input Class Initialized
INFO - 2017-04-08 01:05:48 --> Language Class Initialized
INFO - 2017-04-08 01:05:48 --> Loader Class Initialized
INFO - 2017-04-08 01:05:48 --> Helper loaded: url_helper
INFO - 2017-04-08 01:05:48 --> Helper loaded: language_helper
INFO - 2017-04-08 01:05:48 --> Helper loaded: html_helper
INFO - 2017-04-08 01:05:48 --> Helper loaded: form_helper
INFO - 2017-04-08 01:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:05:48 --> Controller Class Initialized
INFO - 2017-04-08 01:05:48 --> Database Driver Class Initialized
INFO - 2017-04-08 01:05:48 --> Model Class Initialized
INFO - 2017-04-08 01:05:48 --> Model Class Initialized
INFO - 2017-04-08 01:05:48 --> Email Class Initialized
INFO - 2017-04-08 01:05:48 --> Form Validation Class Initialized
INFO - 2017-04-08 01:05:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:05:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:05:48 --> Final output sent to browser
DEBUG - 2017-04-08 01:05:48 --> Total execution time: 0.0978
INFO - 2017-04-08 01:06:53 --> Config Class Initialized
INFO - 2017-04-08 01:06:53 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:06:53 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:06:53 --> Utf8 Class Initialized
INFO - 2017-04-08 01:06:53 --> URI Class Initialized
INFO - 2017-04-08 01:06:53 --> Router Class Initialized
INFO - 2017-04-08 01:06:53 --> Output Class Initialized
INFO - 2017-04-08 01:06:53 --> Security Class Initialized
DEBUG - 2017-04-08 01:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:06:53 --> Input Class Initialized
INFO - 2017-04-08 01:06:53 --> Language Class Initialized
INFO - 2017-04-08 01:06:53 --> Loader Class Initialized
INFO - 2017-04-08 01:06:53 --> Helper loaded: url_helper
INFO - 2017-04-08 01:06:53 --> Helper loaded: language_helper
INFO - 2017-04-08 01:06:53 --> Helper loaded: html_helper
INFO - 2017-04-08 01:06:53 --> Helper loaded: form_helper
INFO - 2017-04-08 01:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:06:53 --> Controller Class Initialized
INFO - 2017-04-08 01:06:53 --> Database Driver Class Initialized
INFO - 2017-04-08 01:06:53 --> Model Class Initialized
INFO - 2017-04-08 01:06:53 --> Model Class Initialized
INFO - 2017-04-08 01:06:53 --> Email Class Initialized
INFO - 2017-04-08 01:06:53 --> Form Validation Class Initialized
INFO - 2017-04-08 01:06:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:06:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:06:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:06:53 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:06:53 --> Final output sent to browser
DEBUG - 2017-04-08 01:06:53 --> Total execution time: 0.0940
INFO - 2017-04-08 01:14:12 --> Config Class Initialized
INFO - 2017-04-08 01:14:12 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:14:12 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:14:12 --> Utf8 Class Initialized
INFO - 2017-04-08 01:14:12 --> URI Class Initialized
INFO - 2017-04-08 01:14:12 --> Router Class Initialized
INFO - 2017-04-08 01:14:12 --> Output Class Initialized
INFO - 2017-04-08 01:14:12 --> Security Class Initialized
DEBUG - 2017-04-08 01:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:14:12 --> Input Class Initialized
INFO - 2017-04-08 01:14:12 --> Language Class Initialized
INFO - 2017-04-08 01:14:12 --> Loader Class Initialized
INFO - 2017-04-08 01:14:12 --> Helper loaded: url_helper
INFO - 2017-04-08 01:14:12 --> Helper loaded: language_helper
INFO - 2017-04-08 01:14:12 --> Helper loaded: html_helper
INFO - 2017-04-08 01:14:12 --> Helper loaded: form_helper
INFO - 2017-04-08 01:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:14:12 --> Controller Class Initialized
INFO - 2017-04-08 01:14:12 --> Database Driver Class Initialized
INFO - 2017-04-08 01:14:12 --> Model Class Initialized
INFO - 2017-04-08 01:14:12 --> Model Class Initialized
INFO - 2017-04-08 01:14:12 --> Email Class Initialized
INFO - 2017-04-08 01:14:12 --> Form Validation Class Initialized
INFO - 2017-04-08 01:14:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:14:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:14:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:14:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:14:12 --> Final output sent to browser
DEBUG - 2017-04-08 01:14:12 --> Total execution time: 0.1374
INFO - 2017-04-08 01:14:28 --> Config Class Initialized
INFO - 2017-04-08 01:14:28 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:14:28 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:14:28 --> Utf8 Class Initialized
INFO - 2017-04-08 01:14:28 --> URI Class Initialized
INFO - 2017-04-08 01:14:28 --> Router Class Initialized
INFO - 2017-04-08 01:14:28 --> Output Class Initialized
INFO - 2017-04-08 01:14:28 --> Security Class Initialized
DEBUG - 2017-04-08 01:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:14:28 --> Input Class Initialized
INFO - 2017-04-08 01:14:28 --> Language Class Initialized
INFO - 2017-04-08 01:14:28 --> Loader Class Initialized
INFO - 2017-04-08 01:14:28 --> Helper loaded: url_helper
INFO - 2017-04-08 01:14:28 --> Helper loaded: language_helper
INFO - 2017-04-08 01:14:28 --> Helper loaded: html_helper
INFO - 2017-04-08 01:14:28 --> Helper loaded: form_helper
INFO - 2017-04-08 01:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:14:28 --> Controller Class Initialized
INFO - 2017-04-08 01:14:28 --> Database Driver Class Initialized
INFO - 2017-04-08 01:14:28 --> Model Class Initialized
INFO - 2017-04-08 01:14:28 --> Model Class Initialized
INFO - 2017-04-08 01:14:28 --> Email Class Initialized
INFO - 2017-04-08 01:14:28 --> Form Validation Class Initialized
INFO - 2017-04-08 01:14:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:14:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:14:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:14:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:14:28 --> Final output sent to browser
DEBUG - 2017-04-08 01:14:28 --> Total execution time: 0.1195
INFO - 2017-04-08 01:15:07 --> Config Class Initialized
INFO - 2017-04-08 01:15:07 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:15:07 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:15:07 --> Utf8 Class Initialized
INFO - 2017-04-08 01:15:07 --> URI Class Initialized
INFO - 2017-04-08 01:15:07 --> Router Class Initialized
INFO - 2017-04-08 01:15:07 --> Output Class Initialized
INFO - 2017-04-08 01:15:07 --> Security Class Initialized
DEBUG - 2017-04-08 01:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:15:07 --> Input Class Initialized
INFO - 2017-04-08 01:15:07 --> Language Class Initialized
INFO - 2017-04-08 01:15:07 --> Loader Class Initialized
INFO - 2017-04-08 01:15:07 --> Helper loaded: url_helper
INFO - 2017-04-08 01:15:07 --> Helper loaded: language_helper
INFO - 2017-04-08 01:15:07 --> Helper loaded: html_helper
INFO - 2017-04-08 01:15:07 --> Helper loaded: form_helper
INFO - 2017-04-08 01:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:15:07 --> Controller Class Initialized
INFO - 2017-04-08 01:15:07 --> Database Driver Class Initialized
INFO - 2017-04-08 01:15:07 --> Model Class Initialized
INFO - 2017-04-08 01:15:07 --> Model Class Initialized
INFO - 2017-04-08 01:15:07 --> Email Class Initialized
INFO - 2017-04-08 01:15:07 --> Form Validation Class Initialized
INFO - 2017-04-08 01:15:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:15:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:15:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:15:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:15:07 --> Final output sent to browser
DEBUG - 2017-04-08 01:15:07 --> Total execution time: 0.0908
INFO - 2017-04-08 01:17:37 --> Config Class Initialized
INFO - 2017-04-08 01:17:37 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:17:37 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:17:37 --> Utf8 Class Initialized
INFO - 2017-04-08 01:17:37 --> URI Class Initialized
INFO - 2017-04-08 01:17:37 --> Router Class Initialized
INFO - 2017-04-08 01:17:37 --> Output Class Initialized
INFO - 2017-04-08 01:17:37 --> Security Class Initialized
DEBUG - 2017-04-08 01:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:17:37 --> Input Class Initialized
INFO - 2017-04-08 01:17:37 --> Language Class Initialized
INFO - 2017-04-08 01:17:37 --> Loader Class Initialized
INFO - 2017-04-08 01:17:37 --> Helper loaded: url_helper
INFO - 2017-04-08 01:17:37 --> Helper loaded: language_helper
INFO - 2017-04-08 01:17:37 --> Helper loaded: html_helper
INFO - 2017-04-08 01:17:37 --> Helper loaded: form_helper
INFO - 2017-04-08 01:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:17:37 --> Controller Class Initialized
INFO - 2017-04-08 01:17:37 --> Database Driver Class Initialized
INFO - 2017-04-08 01:17:37 --> Model Class Initialized
INFO - 2017-04-08 01:17:37 --> Model Class Initialized
INFO - 2017-04-08 01:17:37 --> Email Class Initialized
INFO - 2017-04-08 01:17:37 --> Form Validation Class Initialized
INFO - 2017-04-08 01:17:37 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:17:37 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:17:37 --> Final output sent to browser
DEBUG - 2017-04-08 01:17:37 --> Total execution time: 0.0911
INFO - 2017-04-08 01:18:16 --> Config Class Initialized
INFO - 2017-04-08 01:18:16 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:18:16 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:18:16 --> Utf8 Class Initialized
INFO - 2017-04-08 01:18:16 --> URI Class Initialized
INFO - 2017-04-08 01:18:16 --> Router Class Initialized
INFO - 2017-04-08 01:18:16 --> Output Class Initialized
INFO - 2017-04-08 01:18:16 --> Security Class Initialized
DEBUG - 2017-04-08 01:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:18:16 --> Input Class Initialized
INFO - 2017-04-08 01:18:16 --> Language Class Initialized
INFO - 2017-04-08 01:18:16 --> Loader Class Initialized
INFO - 2017-04-08 01:18:16 --> Helper loaded: url_helper
INFO - 2017-04-08 01:18:16 --> Helper loaded: language_helper
INFO - 2017-04-08 01:18:16 --> Helper loaded: html_helper
INFO - 2017-04-08 01:18:16 --> Helper loaded: form_helper
INFO - 2017-04-08 01:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:18:16 --> Controller Class Initialized
INFO - 2017-04-08 01:18:16 --> Database Driver Class Initialized
INFO - 2017-04-08 01:18:16 --> Model Class Initialized
INFO - 2017-04-08 01:18:16 --> Model Class Initialized
INFO - 2017-04-08 01:18:16 --> Email Class Initialized
INFO - 2017-04-08 01:18:16 --> Form Validation Class Initialized
INFO - 2017-04-08 01:18:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:18:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:18:16 --> Final output sent to browser
DEBUG - 2017-04-08 01:18:16 --> Total execution time: 0.1002
INFO - 2017-04-08 01:18:43 --> Config Class Initialized
INFO - 2017-04-08 01:18:43 --> Hooks Class Initialized
DEBUG - 2017-04-08 01:18:43 --> UTF-8 Support Enabled
INFO - 2017-04-08 01:18:43 --> Utf8 Class Initialized
INFO - 2017-04-08 01:18:43 --> URI Class Initialized
INFO - 2017-04-08 01:18:43 --> Router Class Initialized
INFO - 2017-04-08 01:18:43 --> Output Class Initialized
INFO - 2017-04-08 01:18:43 --> Security Class Initialized
DEBUG - 2017-04-08 01:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 01:18:43 --> Input Class Initialized
INFO - 2017-04-08 01:18:43 --> Language Class Initialized
INFO - 2017-04-08 01:18:43 --> Loader Class Initialized
INFO - 2017-04-08 01:18:43 --> Helper loaded: url_helper
INFO - 2017-04-08 01:18:43 --> Helper loaded: language_helper
INFO - 2017-04-08 01:18:43 --> Helper loaded: html_helper
INFO - 2017-04-08 01:18:43 --> Helper loaded: form_helper
INFO - 2017-04-08 01:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 01:18:43 --> Controller Class Initialized
INFO - 2017-04-08 01:18:43 --> Database Driver Class Initialized
INFO - 2017-04-08 01:18:43 --> Model Class Initialized
INFO - 2017-04-08 01:18:43 --> Model Class Initialized
INFO - 2017-04-08 01:18:43 --> Email Class Initialized
INFO - 2017-04-08 01:18:43 --> Form Validation Class Initialized
INFO - 2017-04-08 01:18:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 01:18:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 01:18:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 01:18:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 01:18:43 --> Final output sent to browser
DEBUG - 2017-04-08 01:18:43 --> Total execution time: 0.1037
INFO - 2017-04-08 16:52:15 --> Config Class Initialized
INFO - 2017-04-08 16:52:15 --> Hooks Class Initialized
DEBUG - 2017-04-08 16:52:15 --> UTF-8 Support Enabled
INFO - 2017-04-08 16:52:15 --> Utf8 Class Initialized
INFO - 2017-04-08 16:52:15 --> URI Class Initialized
INFO - 2017-04-08 16:52:15 --> Router Class Initialized
INFO - 2017-04-08 16:52:15 --> Output Class Initialized
INFO - 2017-04-08 16:52:15 --> Security Class Initialized
DEBUG - 2017-04-08 16:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 16:52:15 --> Input Class Initialized
INFO - 2017-04-08 16:52:15 --> Language Class Initialized
INFO - 2017-04-08 16:52:15 --> Loader Class Initialized
INFO - 2017-04-08 16:52:15 --> Helper loaded: url_helper
INFO - 2017-04-08 16:52:15 --> Helper loaded: language_helper
INFO - 2017-04-08 16:52:15 --> Helper loaded: html_helper
INFO - 2017-04-08 16:52:15 --> Helper loaded: form_helper
INFO - 2017-04-08 16:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 16:52:15 --> Controller Class Initialized
INFO - 2017-04-08 16:52:15 --> Database Driver Class Initialized
INFO - 2017-04-08 16:52:15 --> Model Class Initialized
INFO - 2017-04-08 16:52:15 --> Model Class Initialized
INFO - 2017-04-08 16:52:15 --> Email Class Initialized
INFO - 2017-04-08 16:52:15 --> Form Validation Class Initialized
INFO - 2017-04-08 16:52:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 16:52:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 16:52:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 16:52:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 16:52:15 --> Final output sent to browser
DEBUG - 2017-04-08 16:52:15 --> Total execution time: 0.1357
INFO - 2017-04-08 16:53:25 --> Config Class Initialized
INFO - 2017-04-08 16:53:25 --> Hooks Class Initialized
DEBUG - 2017-04-08 16:53:25 --> UTF-8 Support Enabled
INFO - 2017-04-08 16:53:25 --> Utf8 Class Initialized
INFO - 2017-04-08 16:53:25 --> URI Class Initialized
INFO - 2017-04-08 16:53:25 --> Router Class Initialized
INFO - 2017-04-08 16:53:25 --> Output Class Initialized
INFO - 2017-04-08 16:53:25 --> Security Class Initialized
DEBUG - 2017-04-08 16:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 16:53:25 --> Input Class Initialized
INFO - 2017-04-08 16:53:25 --> Language Class Initialized
INFO - 2017-04-08 16:53:25 --> Loader Class Initialized
INFO - 2017-04-08 16:53:25 --> Helper loaded: url_helper
INFO - 2017-04-08 16:53:25 --> Helper loaded: language_helper
INFO - 2017-04-08 16:53:25 --> Helper loaded: html_helper
INFO - 2017-04-08 16:53:25 --> Helper loaded: form_helper
INFO - 2017-04-08 16:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 16:53:25 --> Controller Class Initialized
INFO - 2017-04-08 16:53:25 --> Database Driver Class Initialized
INFO - 2017-04-08 16:53:25 --> Model Class Initialized
INFO - 2017-04-08 16:53:25 --> Model Class Initialized
INFO - 2017-04-08 16:53:25 --> Email Class Initialized
INFO - 2017-04-08 16:53:25 --> Form Validation Class Initialized
INFO - 2017-04-08 16:53:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 16:53:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 16:53:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 16:53:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 16:53:25 --> Final output sent to browser
DEBUG - 2017-04-08 16:53:25 --> Total execution time: 0.1063
INFO - 2017-04-08 16:54:36 --> Config Class Initialized
INFO - 2017-04-08 16:54:36 --> Hooks Class Initialized
DEBUG - 2017-04-08 16:54:36 --> UTF-8 Support Enabled
INFO - 2017-04-08 16:54:36 --> Utf8 Class Initialized
INFO - 2017-04-08 16:54:36 --> URI Class Initialized
INFO - 2017-04-08 16:54:36 --> Router Class Initialized
INFO - 2017-04-08 16:54:36 --> Output Class Initialized
INFO - 2017-04-08 16:54:36 --> Security Class Initialized
DEBUG - 2017-04-08 16:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 16:54:36 --> Input Class Initialized
INFO - 2017-04-08 16:54:36 --> Language Class Initialized
INFO - 2017-04-08 16:54:36 --> Loader Class Initialized
INFO - 2017-04-08 16:54:36 --> Helper loaded: url_helper
INFO - 2017-04-08 16:54:36 --> Helper loaded: language_helper
INFO - 2017-04-08 16:54:36 --> Helper loaded: html_helper
INFO - 2017-04-08 16:54:36 --> Helper loaded: form_helper
INFO - 2017-04-08 16:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 16:54:36 --> Controller Class Initialized
INFO - 2017-04-08 16:54:36 --> Database Driver Class Initialized
INFO - 2017-04-08 16:54:36 --> Model Class Initialized
INFO - 2017-04-08 16:54:36 --> Model Class Initialized
INFO - 2017-04-08 16:54:36 --> Email Class Initialized
INFO - 2017-04-08 16:54:36 --> Form Validation Class Initialized
INFO - 2017-04-08 16:54:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 16:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 16:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 16:54:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 16:54:36 --> Final output sent to browser
DEBUG - 2017-04-08 16:54:36 --> Total execution time: 0.1153
INFO - 2017-04-08 16:55:24 --> Config Class Initialized
INFO - 2017-04-08 16:55:24 --> Hooks Class Initialized
DEBUG - 2017-04-08 16:55:24 --> UTF-8 Support Enabled
INFO - 2017-04-08 16:55:24 --> Utf8 Class Initialized
INFO - 2017-04-08 16:55:24 --> URI Class Initialized
INFO - 2017-04-08 16:55:24 --> Router Class Initialized
INFO - 2017-04-08 16:55:24 --> Output Class Initialized
INFO - 2017-04-08 16:55:24 --> Security Class Initialized
DEBUG - 2017-04-08 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 16:55:24 --> Input Class Initialized
INFO - 2017-04-08 16:55:24 --> Language Class Initialized
INFO - 2017-04-08 16:55:24 --> Loader Class Initialized
INFO - 2017-04-08 16:55:24 --> Helper loaded: url_helper
INFO - 2017-04-08 16:55:24 --> Helper loaded: language_helper
INFO - 2017-04-08 16:55:24 --> Helper loaded: html_helper
INFO - 2017-04-08 16:55:24 --> Helper loaded: form_helper
INFO - 2017-04-08 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 16:55:24 --> Controller Class Initialized
INFO - 2017-04-08 16:55:24 --> Database Driver Class Initialized
INFO - 2017-04-08 16:55:24 --> Model Class Initialized
INFO - 2017-04-08 16:55:24 --> Model Class Initialized
INFO - 2017-04-08 16:55:24 --> Email Class Initialized
INFO - 2017-04-08 16:55:24 --> Form Validation Class Initialized
INFO - 2017-04-08 16:55:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 16:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 16:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 16:55:24 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 16:55:24 --> Final output sent to browser
DEBUG - 2017-04-08 16:55:24 --> Total execution time: 0.0906
INFO - 2017-04-08 16:56:22 --> Config Class Initialized
INFO - 2017-04-08 16:56:22 --> Hooks Class Initialized
DEBUG - 2017-04-08 16:56:22 --> UTF-8 Support Enabled
INFO - 2017-04-08 16:56:22 --> Utf8 Class Initialized
INFO - 2017-04-08 16:56:22 --> URI Class Initialized
INFO - 2017-04-08 16:56:22 --> Router Class Initialized
INFO - 2017-04-08 16:56:22 --> Output Class Initialized
INFO - 2017-04-08 16:56:22 --> Security Class Initialized
DEBUG - 2017-04-08 16:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 16:56:22 --> Input Class Initialized
INFO - 2017-04-08 16:56:22 --> Language Class Initialized
INFO - 2017-04-08 16:56:22 --> Loader Class Initialized
INFO - 2017-04-08 16:56:22 --> Helper loaded: url_helper
INFO - 2017-04-08 16:56:22 --> Helper loaded: language_helper
INFO - 2017-04-08 16:56:22 --> Helper loaded: html_helper
INFO - 2017-04-08 16:56:22 --> Helper loaded: form_helper
INFO - 2017-04-08 16:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 16:56:22 --> Controller Class Initialized
INFO - 2017-04-08 16:56:22 --> Database Driver Class Initialized
INFO - 2017-04-08 16:56:22 --> Model Class Initialized
INFO - 2017-04-08 16:56:22 --> Model Class Initialized
INFO - 2017-04-08 16:56:22 --> Email Class Initialized
INFO - 2017-04-08 16:56:22 --> Form Validation Class Initialized
INFO - 2017-04-08 16:56:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 16:56:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 16:56:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 16:56:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 16:56:22 --> Final output sent to browser
DEBUG - 2017-04-08 16:56:22 --> Total execution time: 0.0933
INFO - 2017-04-08 16:57:00 --> Config Class Initialized
INFO - 2017-04-08 16:57:00 --> Hooks Class Initialized
DEBUG - 2017-04-08 16:57:00 --> UTF-8 Support Enabled
INFO - 2017-04-08 16:57:00 --> Utf8 Class Initialized
INFO - 2017-04-08 16:57:00 --> URI Class Initialized
INFO - 2017-04-08 16:57:00 --> Router Class Initialized
INFO - 2017-04-08 16:57:00 --> Output Class Initialized
INFO - 2017-04-08 16:57:00 --> Security Class Initialized
DEBUG - 2017-04-08 16:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 16:57:00 --> Input Class Initialized
INFO - 2017-04-08 16:57:00 --> Language Class Initialized
INFO - 2017-04-08 16:57:00 --> Loader Class Initialized
INFO - 2017-04-08 16:57:00 --> Helper loaded: url_helper
INFO - 2017-04-08 16:57:00 --> Helper loaded: language_helper
INFO - 2017-04-08 16:57:00 --> Helper loaded: html_helper
INFO - 2017-04-08 16:57:00 --> Helper loaded: form_helper
INFO - 2017-04-08 16:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 16:57:00 --> Controller Class Initialized
INFO - 2017-04-08 16:57:00 --> Database Driver Class Initialized
INFO - 2017-04-08 16:57:00 --> Model Class Initialized
INFO - 2017-04-08 16:57:00 --> Model Class Initialized
INFO - 2017-04-08 16:57:00 --> Email Class Initialized
INFO - 2017-04-08 16:57:00 --> Form Validation Class Initialized
INFO - 2017-04-08 16:57:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 16:57:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 16:57:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 16:57:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 16:57:00 --> Final output sent to browser
DEBUG - 2017-04-08 16:57:00 --> Total execution time: 0.1415
INFO - 2017-04-08 16:57:52 --> Config Class Initialized
INFO - 2017-04-08 16:57:52 --> Hooks Class Initialized
DEBUG - 2017-04-08 16:57:52 --> UTF-8 Support Enabled
INFO - 2017-04-08 16:57:52 --> Utf8 Class Initialized
INFO - 2017-04-08 16:57:52 --> URI Class Initialized
INFO - 2017-04-08 16:57:52 --> Router Class Initialized
INFO - 2017-04-08 16:57:52 --> Output Class Initialized
INFO - 2017-04-08 16:57:52 --> Security Class Initialized
DEBUG - 2017-04-08 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 16:57:52 --> Input Class Initialized
INFO - 2017-04-08 16:57:52 --> Language Class Initialized
INFO - 2017-04-08 16:57:52 --> Loader Class Initialized
INFO - 2017-04-08 16:57:52 --> Helper loaded: url_helper
INFO - 2017-04-08 16:57:52 --> Helper loaded: language_helper
INFO - 2017-04-08 16:57:52 --> Helper loaded: html_helper
INFO - 2017-04-08 16:57:52 --> Helper loaded: form_helper
INFO - 2017-04-08 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 16:57:52 --> Controller Class Initialized
INFO - 2017-04-08 16:57:52 --> Database Driver Class Initialized
INFO - 2017-04-08 16:57:52 --> Model Class Initialized
INFO - 2017-04-08 16:57:52 --> Model Class Initialized
INFO - 2017-04-08 16:57:52 --> Email Class Initialized
INFO - 2017-04-08 16:57:52 --> Form Validation Class Initialized
INFO - 2017-04-08 16:57:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 16:57:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 16:57:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 16:57:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 16:57:52 --> Final output sent to browser
DEBUG - 2017-04-08 16:57:52 --> Total execution time: 0.0929
INFO - 2017-04-08 17:01:40 --> Config Class Initialized
INFO - 2017-04-08 17:01:40 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:01:40 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:01:40 --> Utf8 Class Initialized
INFO - 2017-04-08 17:01:40 --> URI Class Initialized
INFO - 2017-04-08 17:01:40 --> Router Class Initialized
INFO - 2017-04-08 17:01:40 --> Output Class Initialized
INFO - 2017-04-08 17:01:40 --> Security Class Initialized
DEBUG - 2017-04-08 17:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:01:40 --> Input Class Initialized
INFO - 2017-04-08 17:01:40 --> Language Class Initialized
INFO - 2017-04-08 17:01:40 --> Loader Class Initialized
INFO - 2017-04-08 17:01:40 --> Helper loaded: url_helper
INFO - 2017-04-08 17:01:40 --> Helper loaded: language_helper
INFO - 2017-04-08 17:01:40 --> Helper loaded: html_helper
INFO - 2017-04-08 17:01:40 --> Helper loaded: form_helper
INFO - 2017-04-08 17:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:01:40 --> Controller Class Initialized
INFO - 2017-04-08 17:01:40 --> Database Driver Class Initialized
INFO - 2017-04-08 17:01:40 --> Model Class Initialized
INFO - 2017-04-08 17:01:40 --> Model Class Initialized
INFO - 2017-04-08 17:01:40 --> Email Class Initialized
INFO - 2017-04-08 17:01:40 --> Form Validation Class Initialized
INFO - 2017-04-08 17:01:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:01:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:01:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:01:40 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:01:40 --> Final output sent to browser
DEBUG - 2017-04-08 17:01:40 --> Total execution time: 0.1002
INFO - 2017-04-08 17:02:30 --> Config Class Initialized
INFO - 2017-04-08 17:02:30 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:02:30 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:02:30 --> Utf8 Class Initialized
INFO - 2017-04-08 17:02:30 --> URI Class Initialized
INFO - 2017-04-08 17:02:30 --> Router Class Initialized
INFO - 2017-04-08 17:02:30 --> Output Class Initialized
INFO - 2017-04-08 17:02:30 --> Security Class Initialized
DEBUG - 2017-04-08 17:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:02:30 --> Input Class Initialized
INFO - 2017-04-08 17:02:30 --> Language Class Initialized
INFO - 2017-04-08 17:02:30 --> Loader Class Initialized
INFO - 2017-04-08 17:02:30 --> Helper loaded: url_helper
INFO - 2017-04-08 17:02:30 --> Helper loaded: language_helper
INFO - 2017-04-08 17:02:30 --> Helper loaded: html_helper
INFO - 2017-04-08 17:02:30 --> Helper loaded: form_helper
INFO - 2017-04-08 17:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:02:30 --> Controller Class Initialized
INFO - 2017-04-08 17:02:30 --> Database Driver Class Initialized
INFO - 2017-04-08 17:02:30 --> Model Class Initialized
INFO - 2017-04-08 17:02:30 --> Model Class Initialized
INFO - 2017-04-08 17:02:30 --> Email Class Initialized
INFO - 2017-04-08 17:02:30 --> Form Validation Class Initialized
INFO - 2017-04-08 17:02:30 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:02:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:02:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:02:30 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:02:30 --> Final output sent to browser
DEBUG - 2017-04-08 17:02:30 --> Total execution time: 0.1304
INFO - 2017-04-08 17:03:07 --> Config Class Initialized
INFO - 2017-04-08 17:03:07 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:03:07 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:03:07 --> Utf8 Class Initialized
INFO - 2017-04-08 17:03:07 --> URI Class Initialized
INFO - 2017-04-08 17:03:07 --> Router Class Initialized
INFO - 2017-04-08 17:03:07 --> Output Class Initialized
INFO - 2017-04-08 17:03:07 --> Security Class Initialized
DEBUG - 2017-04-08 17:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:03:07 --> Input Class Initialized
INFO - 2017-04-08 17:03:07 --> Language Class Initialized
INFO - 2017-04-08 17:03:07 --> Loader Class Initialized
INFO - 2017-04-08 17:03:07 --> Helper loaded: url_helper
INFO - 2017-04-08 17:03:07 --> Helper loaded: language_helper
INFO - 2017-04-08 17:03:07 --> Helper loaded: html_helper
INFO - 2017-04-08 17:03:07 --> Helper loaded: form_helper
INFO - 2017-04-08 17:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:03:07 --> Controller Class Initialized
INFO - 2017-04-08 17:03:07 --> Database Driver Class Initialized
INFO - 2017-04-08 17:03:07 --> Model Class Initialized
INFO - 2017-04-08 17:03:07 --> Model Class Initialized
INFO - 2017-04-08 17:03:07 --> Email Class Initialized
INFO - 2017-04-08 17:03:07 --> Form Validation Class Initialized
INFO - 2017-04-08 17:03:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:03:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:03:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:03:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:03:08 --> Final output sent to browser
DEBUG - 2017-04-08 17:03:08 --> Total execution time: 0.1190
INFO - 2017-04-08 17:04:17 --> Config Class Initialized
INFO - 2017-04-08 17:04:17 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:04:17 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:04:17 --> Utf8 Class Initialized
INFO - 2017-04-08 17:04:17 --> URI Class Initialized
INFO - 2017-04-08 17:04:17 --> Router Class Initialized
INFO - 2017-04-08 17:04:17 --> Output Class Initialized
INFO - 2017-04-08 17:04:17 --> Security Class Initialized
DEBUG - 2017-04-08 17:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:04:17 --> Input Class Initialized
INFO - 2017-04-08 17:04:17 --> Language Class Initialized
INFO - 2017-04-08 17:04:17 --> Loader Class Initialized
INFO - 2017-04-08 17:04:17 --> Helper loaded: url_helper
INFO - 2017-04-08 17:04:17 --> Helper loaded: language_helper
INFO - 2017-04-08 17:04:17 --> Helper loaded: html_helper
INFO - 2017-04-08 17:04:17 --> Helper loaded: form_helper
INFO - 2017-04-08 17:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:04:17 --> Controller Class Initialized
INFO - 2017-04-08 17:04:17 --> Database Driver Class Initialized
INFO - 2017-04-08 17:04:17 --> Model Class Initialized
INFO - 2017-04-08 17:04:17 --> Model Class Initialized
INFO - 2017-04-08 17:04:17 --> Email Class Initialized
INFO - 2017-04-08 17:04:17 --> Form Validation Class Initialized
INFO - 2017-04-08 17:04:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:04:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:04:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:04:17 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:04:17 --> Final output sent to browser
DEBUG - 2017-04-08 17:04:17 --> Total execution time: 0.0982
INFO - 2017-04-08 17:04:54 --> Config Class Initialized
INFO - 2017-04-08 17:04:54 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:04:54 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:04:54 --> Utf8 Class Initialized
INFO - 2017-04-08 17:04:54 --> URI Class Initialized
INFO - 2017-04-08 17:04:54 --> Router Class Initialized
INFO - 2017-04-08 17:04:54 --> Output Class Initialized
INFO - 2017-04-08 17:04:54 --> Security Class Initialized
DEBUG - 2017-04-08 17:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:04:54 --> Input Class Initialized
INFO - 2017-04-08 17:04:54 --> Language Class Initialized
INFO - 2017-04-08 17:04:54 --> Loader Class Initialized
INFO - 2017-04-08 17:04:54 --> Helper loaded: url_helper
INFO - 2017-04-08 17:04:54 --> Helper loaded: language_helper
INFO - 2017-04-08 17:04:54 --> Helper loaded: html_helper
INFO - 2017-04-08 17:04:54 --> Helper loaded: form_helper
INFO - 2017-04-08 17:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:04:54 --> Controller Class Initialized
INFO - 2017-04-08 17:04:54 --> Database Driver Class Initialized
INFO - 2017-04-08 17:04:54 --> Model Class Initialized
INFO - 2017-04-08 17:04:54 --> Model Class Initialized
INFO - 2017-04-08 17:04:54 --> Email Class Initialized
INFO - 2017-04-08 17:04:54 --> Form Validation Class Initialized
INFO - 2017-04-08 17:04:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:04:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:04:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:04:54 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:04:54 --> Final output sent to browser
DEBUG - 2017-04-08 17:04:54 --> Total execution time: 0.0876
INFO - 2017-04-08 17:05:20 --> Config Class Initialized
INFO - 2017-04-08 17:05:20 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:05:20 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:05:20 --> Utf8 Class Initialized
INFO - 2017-04-08 17:05:20 --> URI Class Initialized
INFO - 2017-04-08 17:05:20 --> Router Class Initialized
INFO - 2017-04-08 17:05:20 --> Output Class Initialized
INFO - 2017-04-08 17:05:20 --> Security Class Initialized
DEBUG - 2017-04-08 17:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:05:20 --> Input Class Initialized
INFO - 2017-04-08 17:05:20 --> Language Class Initialized
INFO - 2017-04-08 17:05:20 --> Loader Class Initialized
INFO - 2017-04-08 17:05:20 --> Helper loaded: url_helper
INFO - 2017-04-08 17:05:20 --> Helper loaded: language_helper
INFO - 2017-04-08 17:05:20 --> Helper loaded: html_helper
INFO - 2017-04-08 17:05:20 --> Helper loaded: form_helper
INFO - 2017-04-08 17:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:05:20 --> Controller Class Initialized
INFO - 2017-04-08 17:05:20 --> Database Driver Class Initialized
INFO - 2017-04-08 17:05:20 --> Model Class Initialized
INFO - 2017-04-08 17:05:20 --> Model Class Initialized
INFO - 2017-04-08 17:05:20 --> Email Class Initialized
INFO - 2017-04-08 17:05:20 --> Form Validation Class Initialized
INFO - 2017-04-08 17:05:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:05:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:05:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:05:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:05:20 --> Final output sent to browser
DEBUG - 2017-04-08 17:05:20 --> Total execution time: 0.1182
INFO - 2017-04-08 17:05:31 --> Config Class Initialized
INFO - 2017-04-08 17:05:31 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:05:31 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:05:31 --> Utf8 Class Initialized
INFO - 2017-04-08 17:05:31 --> URI Class Initialized
INFO - 2017-04-08 17:05:31 --> Router Class Initialized
INFO - 2017-04-08 17:05:31 --> Output Class Initialized
INFO - 2017-04-08 17:05:31 --> Security Class Initialized
DEBUG - 2017-04-08 17:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:05:31 --> Input Class Initialized
INFO - 2017-04-08 17:05:31 --> Language Class Initialized
INFO - 2017-04-08 17:05:31 --> Loader Class Initialized
INFO - 2017-04-08 17:05:31 --> Helper loaded: url_helper
INFO - 2017-04-08 17:05:31 --> Helper loaded: language_helper
INFO - 2017-04-08 17:05:31 --> Helper loaded: html_helper
INFO - 2017-04-08 17:05:31 --> Helper loaded: form_helper
INFO - 2017-04-08 17:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:05:31 --> Controller Class Initialized
INFO - 2017-04-08 17:05:31 --> Database Driver Class Initialized
INFO - 2017-04-08 17:05:31 --> Model Class Initialized
INFO - 2017-04-08 17:05:31 --> Model Class Initialized
INFO - 2017-04-08 17:05:31 --> Email Class Initialized
INFO - 2017-04-08 17:05:31 --> Form Validation Class Initialized
INFO - 2017-04-08 17:05:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:05:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:05:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:05:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:05:31 --> Final output sent to browser
DEBUG - 2017-04-08 17:05:31 --> Total execution time: 0.1052
INFO - 2017-04-08 17:05:43 --> Config Class Initialized
INFO - 2017-04-08 17:05:43 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:05:43 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:05:43 --> Utf8 Class Initialized
INFO - 2017-04-08 17:05:43 --> URI Class Initialized
INFO - 2017-04-08 17:05:43 --> Router Class Initialized
INFO - 2017-04-08 17:05:43 --> Output Class Initialized
INFO - 2017-04-08 17:05:43 --> Security Class Initialized
DEBUG - 2017-04-08 17:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:05:43 --> Input Class Initialized
INFO - 2017-04-08 17:05:43 --> Language Class Initialized
INFO - 2017-04-08 17:05:43 --> Loader Class Initialized
INFO - 2017-04-08 17:05:43 --> Helper loaded: url_helper
INFO - 2017-04-08 17:05:43 --> Helper loaded: language_helper
INFO - 2017-04-08 17:05:43 --> Helper loaded: html_helper
INFO - 2017-04-08 17:05:43 --> Helper loaded: form_helper
INFO - 2017-04-08 17:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:05:43 --> Controller Class Initialized
INFO - 2017-04-08 17:05:43 --> Database Driver Class Initialized
INFO - 2017-04-08 17:05:43 --> Model Class Initialized
INFO - 2017-04-08 17:05:43 --> Model Class Initialized
INFO - 2017-04-08 17:05:43 --> Email Class Initialized
INFO - 2017-04-08 17:05:43 --> Form Validation Class Initialized
INFO - 2017-04-08 17:05:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:05:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:05:43 --> Final output sent to browser
DEBUG - 2017-04-08 17:05:43 --> Total execution time: 0.1233
INFO - 2017-04-08 17:15:43 --> Config Class Initialized
INFO - 2017-04-08 17:15:43 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:15:43 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:15:43 --> Utf8 Class Initialized
INFO - 2017-04-08 17:15:43 --> URI Class Initialized
INFO - 2017-04-08 17:15:43 --> Router Class Initialized
INFO - 2017-04-08 17:15:43 --> Output Class Initialized
INFO - 2017-04-08 17:15:43 --> Security Class Initialized
DEBUG - 2017-04-08 17:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:15:43 --> Input Class Initialized
INFO - 2017-04-08 17:15:43 --> Language Class Initialized
INFO - 2017-04-08 17:15:43 --> Loader Class Initialized
INFO - 2017-04-08 17:15:43 --> Helper loaded: url_helper
INFO - 2017-04-08 17:15:43 --> Helper loaded: language_helper
INFO - 2017-04-08 17:15:43 --> Helper loaded: html_helper
INFO - 2017-04-08 17:15:43 --> Helper loaded: form_helper
INFO - 2017-04-08 17:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:15:43 --> Controller Class Initialized
INFO - 2017-04-08 17:15:43 --> Database Driver Class Initialized
INFO - 2017-04-08 17:15:43 --> Model Class Initialized
INFO - 2017-04-08 17:15:43 --> Model Class Initialized
INFO - 2017-04-08 17:15:43 --> Email Class Initialized
INFO - 2017-04-08 17:15:43 --> Form Validation Class Initialized
INFO - 2017-04-08 17:15:43 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:15:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:15:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:15:43 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:15:43 --> Final output sent to browser
DEBUG - 2017-04-08 17:15:43 --> Total execution time: 0.1208
INFO - 2017-04-08 17:16:01 --> Config Class Initialized
INFO - 2017-04-08 17:16:01 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:16:01 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:16:01 --> Utf8 Class Initialized
INFO - 2017-04-08 17:16:01 --> URI Class Initialized
INFO - 2017-04-08 17:16:01 --> Router Class Initialized
INFO - 2017-04-08 17:16:01 --> Output Class Initialized
INFO - 2017-04-08 17:16:01 --> Security Class Initialized
DEBUG - 2017-04-08 17:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:16:01 --> Input Class Initialized
INFO - 2017-04-08 17:16:01 --> Language Class Initialized
INFO - 2017-04-08 17:16:01 --> Loader Class Initialized
INFO - 2017-04-08 17:16:01 --> Helper loaded: url_helper
INFO - 2017-04-08 17:16:01 --> Helper loaded: language_helper
INFO - 2017-04-08 17:16:01 --> Helper loaded: html_helper
INFO - 2017-04-08 17:16:01 --> Helper loaded: form_helper
INFO - 2017-04-08 17:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:16:01 --> Controller Class Initialized
INFO - 2017-04-08 17:16:01 --> Database Driver Class Initialized
INFO - 2017-04-08 17:16:01 --> Model Class Initialized
INFO - 2017-04-08 17:16:01 --> Model Class Initialized
INFO - 2017-04-08 17:16:01 --> Email Class Initialized
INFO - 2017-04-08 17:16:01 --> Form Validation Class Initialized
INFO - 2017-04-08 17:16:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:16:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:16:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:16:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:16:01 --> Final output sent to browser
DEBUG - 2017-04-08 17:16:01 --> Total execution time: 0.1055
INFO - 2017-04-08 17:16:38 --> Config Class Initialized
INFO - 2017-04-08 17:16:38 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:16:38 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:16:38 --> Utf8 Class Initialized
INFO - 2017-04-08 17:16:38 --> URI Class Initialized
INFO - 2017-04-08 17:16:38 --> Router Class Initialized
INFO - 2017-04-08 17:16:38 --> Output Class Initialized
INFO - 2017-04-08 17:16:38 --> Security Class Initialized
DEBUG - 2017-04-08 17:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:16:38 --> Input Class Initialized
INFO - 2017-04-08 17:16:38 --> Language Class Initialized
INFO - 2017-04-08 17:16:38 --> Loader Class Initialized
INFO - 2017-04-08 17:16:38 --> Helper loaded: url_helper
INFO - 2017-04-08 17:16:38 --> Helper loaded: language_helper
INFO - 2017-04-08 17:16:38 --> Helper loaded: html_helper
INFO - 2017-04-08 17:16:38 --> Helper loaded: form_helper
INFO - 2017-04-08 17:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:16:38 --> Controller Class Initialized
INFO - 2017-04-08 17:16:38 --> Database Driver Class Initialized
INFO - 2017-04-08 17:16:38 --> Model Class Initialized
INFO - 2017-04-08 17:16:38 --> Model Class Initialized
INFO - 2017-04-08 17:16:38 --> Email Class Initialized
INFO - 2017-04-08 17:16:38 --> Form Validation Class Initialized
INFO - 2017-04-08 17:16:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:16:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:16:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:16:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:16:38 --> Final output sent to browser
DEBUG - 2017-04-08 17:16:38 --> Total execution time: 0.0931
INFO - 2017-04-08 17:16:45 --> Config Class Initialized
INFO - 2017-04-08 17:16:45 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:16:46 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:16:46 --> Utf8 Class Initialized
INFO - 2017-04-08 17:16:46 --> URI Class Initialized
INFO - 2017-04-08 17:16:46 --> Router Class Initialized
INFO - 2017-04-08 17:16:46 --> Output Class Initialized
INFO - 2017-04-08 17:16:46 --> Security Class Initialized
DEBUG - 2017-04-08 17:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:16:46 --> Input Class Initialized
INFO - 2017-04-08 17:16:46 --> Language Class Initialized
INFO - 2017-04-08 17:16:46 --> Loader Class Initialized
INFO - 2017-04-08 17:16:46 --> Helper loaded: url_helper
INFO - 2017-04-08 17:16:46 --> Helper loaded: language_helper
INFO - 2017-04-08 17:16:46 --> Helper loaded: html_helper
INFO - 2017-04-08 17:16:46 --> Helper loaded: form_helper
INFO - 2017-04-08 17:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:16:46 --> Controller Class Initialized
INFO - 2017-04-08 17:16:46 --> Database Driver Class Initialized
INFO - 2017-04-08 17:16:46 --> Model Class Initialized
INFO - 2017-04-08 17:16:46 --> Model Class Initialized
INFO - 2017-04-08 17:16:46 --> Email Class Initialized
INFO - 2017-04-08 17:16:46 --> Form Validation Class Initialized
INFO - 2017-04-08 17:16:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:16:46 --> Final output sent to browser
DEBUG - 2017-04-08 17:16:46 --> Total execution time: 0.1110
INFO - 2017-04-08 17:17:00 --> Config Class Initialized
INFO - 2017-04-08 17:17:00 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:17:00 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:17:00 --> Utf8 Class Initialized
INFO - 2017-04-08 17:17:00 --> URI Class Initialized
INFO - 2017-04-08 17:17:00 --> Router Class Initialized
INFO - 2017-04-08 17:17:00 --> Output Class Initialized
INFO - 2017-04-08 17:17:00 --> Security Class Initialized
DEBUG - 2017-04-08 17:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:17:00 --> Input Class Initialized
INFO - 2017-04-08 17:17:00 --> Language Class Initialized
INFO - 2017-04-08 17:17:00 --> Loader Class Initialized
INFO - 2017-04-08 17:17:00 --> Helper loaded: url_helper
INFO - 2017-04-08 17:17:00 --> Helper loaded: language_helper
INFO - 2017-04-08 17:17:00 --> Helper loaded: html_helper
INFO - 2017-04-08 17:17:00 --> Helper loaded: form_helper
INFO - 2017-04-08 17:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:17:00 --> Controller Class Initialized
INFO - 2017-04-08 17:17:00 --> Database Driver Class Initialized
INFO - 2017-04-08 17:17:00 --> Model Class Initialized
INFO - 2017-04-08 17:17:00 --> Model Class Initialized
INFO - 2017-04-08 17:17:00 --> Email Class Initialized
INFO - 2017-04-08 17:17:00 --> Form Validation Class Initialized
INFO - 2017-04-08 17:17:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:17:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:17:00 --> Final output sent to browser
DEBUG - 2017-04-08 17:17:00 --> Total execution time: 0.1230
INFO - 2017-04-08 17:17:03 --> Config Class Initialized
INFO - 2017-04-08 17:17:03 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:17:03 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:17:03 --> Utf8 Class Initialized
INFO - 2017-04-08 17:17:03 --> URI Class Initialized
INFO - 2017-04-08 17:17:03 --> Router Class Initialized
INFO - 2017-04-08 17:17:03 --> Output Class Initialized
INFO - 2017-04-08 17:17:03 --> Security Class Initialized
DEBUG - 2017-04-08 17:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:17:03 --> Input Class Initialized
INFO - 2017-04-08 17:17:03 --> Language Class Initialized
INFO - 2017-04-08 17:17:04 --> Loader Class Initialized
INFO - 2017-04-08 17:17:04 --> Helper loaded: url_helper
INFO - 2017-04-08 17:17:04 --> Helper loaded: language_helper
INFO - 2017-04-08 17:17:04 --> Helper loaded: html_helper
INFO - 2017-04-08 17:17:04 --> Helper loaded: form_helper
INFO - 2017-04-08 17:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:17:04 --> Controller Class Initialized
INFO - 2017-04-08 17:17:04 --> Database Driver Class Initialized
INFO - 2017-04-08 17:17:04 --> Model Class Initialized
INFO - 2017-04-08 17:17:04 --> Model Class Initialized
INFO - 2017-04-08 17:17:04 --> Email Class Initialized
INFO - 2017-04-08 17:17:04 --> Form Validation Class Initialized
INFO - 2017-04-08 17:17:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:17:04 --> Final output sent to browser
DEBUG - 2017-04-08 17:17:04 --> Total execution time: 0.1090
INFO - 2017-04-08 17:17:20 --> Config Class Initialized
INFO - 2017-04-08 17:17:20 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:17:20 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:17:20 --> Utf8 Class Initialized
INFO - 2017-04-08 17:17:20 --> URI Class Initialized
INFO - 2017-04-08 17:17:20 --> Router Class Initialized
INFO - 2017-04-08 17:17:20 --> Output Class Initialized
INFO - 2017-04-08 17:17:20 --> Security Class Initialized
DEBUG - 2017-04-08 17:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:17:20 --> Input Class Initialized
INFO - 2017-04-08 17:17:20 --> Language Class Initialized
INFO - 2017-04-08 17:17:20 --> Loader Class Initialized
INFO - 2017-04-08 17:17:20 --> Helper loaded: url_helper
INFO - 2017-04-08 17:17:20 --> Helper loaded: language_helper
INFO - 2017-04-08 17:17:20 --> Helper loaded: html_helper
INFO - 2017-04-08 17:17:20 --> Helper loaded: form_helper
INFO - 2017-04-08 17:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:17:20 --> Controller Class Initialized
INFO - 2017-04-08 17:17:20 --> Database Driver Class Initialized
INFO - 2017-04-08 17:17:20 --> Model Class Initialized
INFO - 2017-04-08 17:17:20 --> Model Class Initialized
INFO - 2017-04-08 17:17:20 --> Email Class Initialized
INFO - 2017-04-08 17:17:20 --> Form Validation Class Initialized
INFO - 2017-04-08 17:17:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:17:20 --> Final output sent to browser
DEBUG - 2017-04-08 17:17:20 --> Total execution time: 0.1117
INFO - 2017-04-08 17:18:08 --> Config Class Initialized
INFO - 2017-04-08 17:18:08 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:18:08 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:18:08 --> Utf8 Class Initialized
INFO - 2017-04-08 17:18:08 --> URI Class Initialized
INFO - 2017-04-08 17:18:08 --> Router Class Initialized
INFO - 2017-04-08 17:18:08 --> Output Class Initialized
INFO - 2017-04-08 17:18:08 --> Security Class Initialized
DEBUG - 2017-04-08 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:18:08 --> Input Class Initialized
INFO - 2017-04-08 17:18:08 --> Language Class Initialized
INFO - 2017-04-08 17:18:08 --> Loader Class Initialized
INFO - 2017-04-08 17:18:08 --> Helper loaded: url_helper
INFO - 2017-04-08 17:18:08 --> Helper loaded: language_helper
INFO - 2017-04-08 17:18:08 --> Helper loaded: html_helper
INFO - 2017-04-08 17:18:08 --> Helper loaded: form_helper
INFO - 2017-04-08 17:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:18:08 --> Controller Class Initialized
INFO - 2017-04-08 17:18:08 --> Database Driver Class Initialized
INFO - 2017-04-08 17:18:08 --> Model Class Initialized
INFO - 2017-04-08 17:18:08 --> Model Class Initialized
INFO - 2017-04-08 17:18:08 --> Email Class Initialized
INFO - 2017-04-08 17:18:08 --> Form Validation Class Initialized
INFO - 2017-04-08 17:18:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:18:08 --> Final output sent to browser
DEBUG - 2017-04-08 17:18:08 --> Total execution time: 0.1162
INFO - 2017-04-08 17:19:28 --> Config Class Initialized
INFO - 2017-04-08 17:19:28 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:19:28 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:19:28 --> Utf8 Class Initialized
INFO - 2017-04-08 17:19:28 --> URI Class Initialized
INFO - 2017-04-08 17:19:28 --> Router Class Initialized
INFO - 2017-04-08 17:19:28 --> Output Class Initialized
INFO - 2017-04-08 17:19:28 --> Security Class Initialized
DEBUG - 2017-04-08 17:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:19:28 --> Input Class Initialized
INFO - 2017-04-08 17:19:28 --> Language Class Initialized
INFO - 2017-04-08 17:19:28 --> Loader Class Initialized
INFO - 2017-04-08 17:19:28 --> Helper loaded: url_helper
INFO - 2017-04-08 17:19:28 --> Helper loaded: language_helper
INFO - 2017-04-08 17:19:28 --> Helper loaded: html_helper
INFO - 2017-04-08 17:19:28 --> Helper loaded: form_helper
INFO - 2017-04-08 17:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:19:28 --> Controller Class Initialized
INFO - 2017-04-08 17:19:28 --> Database Driver Class Initialized
INFO - 2017-04-08 17:19:28 --> Model Class Initialized
INFO - 2017-04-08 17:19:28 --> Model Class Initialized
INFO - 2017-04-08 17:19:28 --> Email Class Initialized
INFO - 2017-04-08 17:19:28 --> Form Validation Class Initialized
INFO - 2017-04-08 17:19:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:19:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:19:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:19:28 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:19:28 --> Final output sent to browser
DEBUG - 2017-04-08 17:19:28 --> Total execution time: 0.0942
INFO - 2017-04-08 17:19:31 --> Config Class Initialized
INFO - 2017-04-08 17:19:31 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:19:31 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:19:31 --> Utf8 Class Initialized
INFO - 2017-04-08 17:19:31 --> URI Class Initialized
INFO - 2017-04-08 17:19:31 --> Router Class Initialized
INFO - 2017-04-08 17:19:31 --> Output Class Initialized
INFO - 2017-04-08 17:19:31 --> Security Class Initialized
DEBUG - 2017-04-08 17:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:19:31 --> Input Class Initialized
INFO - 2017-04-08 17:19:31 --> Language Class Initialized
INFO - 2017-04-08 17:19:32 --> Loader Class Initialized
INFO - 2017-04-08 17:19:32 --> Helper loaded: url_helper
INFO - 2017-04-08 17:19:32 --> Helper loaded: language_helper
INFO - 2017-04-08 17:19:32 --> Helper loaded: html_helper
INFO - 2017-04-08 17:19:32 --> Helper loaded: form_helper
INFO - 2017-04-08 17:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:19:32 --> Controller Class Initialized
INFO - 2017-04-08 17:19:32 --> Database Driver Class Initialized
INFO - 2017-04-08 17:19:32 --> Model Class Initialized
INFO - 2017-04-08 17:19:32 --> Model Class Initialized
INFO - 2017-04-08 17:19:32 --> Email Class Initialized
INFO - 2017-04-08 17:19:32 --> Form Validation Class Initialized
INFO - 2017-04-08 17:19:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:19:32 --> Final output sent to browser
DEBUG - 2017-04-08 17:19:32 --> Total execution time: 0.1258
INFO - 2017-04-08 17:19:52 --> Config Class Initialized
INFO - 2017-04-08 17:19:52 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:19:52 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:19:52 --> Utf8 Class Initialized
INFO - 2017-04-08 17:19:52 --> URI Class Initialized
INFO - 2017-04-08 17:19:52 --> Router Class Initialized
INFO - 2017-04-08 17:19:52 --> Output Class Initialized
INFO - 2017-04-08 17:19:52 --> Security Class Initialized
DEBUG - 2017-04-08 17:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:19:52 --> Input Class Initialized
INFO - 2017-04-08 17:19:52 --> Language Class Initialized
INFO - 2017-04-08 17:19:52 --> Loader Class Initialized
INFO - 2017-04-08 17:19:52 --> Helper loaded: url_helper
INFO - 2017-04-08 17:19:52 --> Helper loaded: language_helper
INFO - 2017-04-08 17:19:52 --> Helper loaded: html_helper
INFO - 2017-04-08 17:19:52 --> Helper loaded: form_helper
INFO - 2017-04-08 17:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:19:52 --> Controller Class Initialized
INFO - 2017-04-08 17:19:52 --> Database Driver Class Initialized
INFO - 2017-04-08 17:19:52 --> Model Class Initialized
INFO - 2017-04-08 17:19:52 --> Model Class Initialized
INFO - 2017-04-08 17:19:52 --> Email Class Initialized
INFO - 2017-04-08 17:19:52 --> Form Validation Class Initialized
INFO - 2017-04-08 17:19:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:19:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:19:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:19:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:19:52 --> Final output sent to browser
DEBUG - 2017-04-08 17:19:52 --> Total execution time: 0.1188
INFO - 2017-04-08 17:19:57 --> Config Class Initialized
INFO - 2017-04-08 17:19:57 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:19:57 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:19:57 --> Utf8 Class Initialized
INFO - 2017-04-08 17:19:57 --> URI Class Initialized
INFO - 2017-04-08 17:19:57 --> Router Class Initialized
INFO - 2017-04-08 17:19:57 --> Output Class Initialized
INFO - 2017-04-08 17:19:57 --> Security Class Initialized
DEBUG - 2017-04-08 17:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:19:57 --> Input Class Initialized
INFO - 2017-04-08 17:19:57 --> Language Class Initialized
INFO - 2017-04-08 17:19:57 --> Loader Class Initialized
INFO - 2017-04-08 17:19:57 --> Helper loaded: url_helper
INFO - 2017-04-08 17:19:57 --> Helper loaded: language_helper
INFO - 2017-04-08 17:19:57 --> Helper loaded: html_helper
INFO - 2017-04-08 17:19:57 --> Helper loaded: form_helper
INFO - 2017-04-08 17:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:19:57 --> Controller Class Initialized
INFO - 2017-04-08 17:19:57 --> Database Driver Class Initialized
INFO - 2017-04-08 17:19:57 --> Model Class Initialized
INFO - 2017-04-08 17:19:57 --> Model Class Initialized
INFO - 2017-04-08 17:19:57 --> Email Class Initialized
INFO - 2017-04-08 17:19:57 --> Form Validation Class Initialized
INFO - 2017-04-08 17:19:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:19:57 --> Final output sent to browser
DEBUG - 2017-04-08 17:19:57 --> Total execution time: 0.2081
INFO - 2017-04-08 17:20:47 --> Config Class Initialized
INFO - 2017-04-08 17:20:47 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:20:47 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:20:47 --> Utf8 Class Initialized
INFO - 2017-04-08 17:20:47 --> URI Class Initialized
INFO - 2017-04-08 17:20:47 --> Router Class Initialized
INFO - 2017-04-08 17:20:47 --> Output Class Initialized
INFO - 2017-04-08 17:20:47 --> Security Class Initialized
DEBUG - 2017-04-08 17:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:20:47 --> Input Class Initialized
INFO - 2017-04-08 17:20:47 --> Language Class Initialized
INFO - 2017-04-08 17:20:47 --> Loader Class Initialized
INFO - 2017-04-08 17:20:47 --> Helper loaded: url_helper
INFO - 2017-04-08 17:20:47 --> Helper loaded: language_helper
INFO - 2017-04-08 17:20:47 --> Helper loaded: html_helper
INFO - 2017-04-08 17:20:47 --> Helper loaded: form_helper
INFO - 2017-04-08 17:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:20:47 --> Controller Class Initialized
INFO - 2017-04-08 17:20:47 --> Database Driver Class Initialized
INFO - 2017-04-08 17:20:47 --> Model Class Initialized
INFO - 2017-04-08 17:20:47 --> Model Class Initialized
INFO - 2017-04-08 17:20:47 --> Email Class Initialized
INFO - 2017-04-08 17:20:47 --> Form Validation Class Initialized
INFO - 2017-04-08 17:20:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:20:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:20:47 --> Final output sent to browser
DEBUG - 2017-04-08 17:20:47 --> Total execution time: 0.1101
INFO - 2017-04-08 17:20:54 --> Config Class Initialized
INFO - 2017-04-08 17:20:54 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:20:54 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:20:54 --> Utf8 Class Initialized
INFO - 2017-04-08 17:20:54 --> URI Class Initialized
INFO - 2017-04-08 17:20:54 --> Router Class Initialized
INFO - 2017-04-08 17:20:54 --> Output Class Initialized
INFO - 2017-04-08 17:20:54 --> Security Class Initialized
DEBUG - 2017-04-08 17:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:20:54 --> Input Class Initialized
INFO - 2017-04-08 17:20:54 --> Language Class Initialized
INFO - 2017-04-08 17:20:54 --> Loader Class Initialized
INFO - 2017-04-08 17:20:54 --> Helper loaded: url_helper
INFO - 2017-04-08 17:20:54 --> Helper loaded: language_helper
INFO - 2017-04-08 17:20:54 --> Helper loaded: html_helper
INFO - 2017-04-08 17:20:54 --> Helper loaded: form_helper
INFO - 2017-04-08 17:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:20:54 --> Controller Class Initialized
INFO - 2017-04-08 17:20:54 --> Database Driver Class Initialized
INFO - 2017-04-08 17:20:54 --> Model Class Initialized
INFO - 2017-04-08 17:20:54 --> Model Class Initialized
INFO - 2017-04-08 17:20:54 --> Email Class Initialized
INFO - 2017-04-08 17:20:54 --> Form Validation Class Initialized
INFO - 2017-04-08 17:20:54 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:20:54 --> Final output sent to browser
DEBUG - 2017-04-08 17:20:54 --> Total execution time: 0.1192
INFO - 2017-04-08 17:22:23 --> Config Class Initialized
INFO - 2017-04-08 17:22:23 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:22:23 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:22:23 --> Utf8 Class Initialized
INFO - 2017-04-08 17:22:23 --> URI Class Initialized
INFO - 2017-04-08 17:22:23 --> Router Class Initialized
INFO - 2017-04-08 17:22:23 --> Output Class Initialized
INFO - 2017-04-08 17:22:23 --> Security Class Initialized
DEBUG - 2017-04-08 17:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:22:23 --> Input Class Initialized
INFO - 2017-04-08 17:22:23 --> Language Class Initialized
INFO - 2017-04-08 17:22:23 --> Loader Class Initialized
INFO - 2017-04-08 17:22:23 --> Helper loaded: url_helper
INFO - 2017-04-08 17:22:23 --> Helper loaded: language_helper
INFO - 2017-04-08 17:22:23 --> Helper loaded: html_helper
INFO - 2017-04-08 17:22:23 --> Helper loaded: form_helper
INFO - 2017-04-08 17:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:22:23 --> Controller Class Initialized
INFO - 2017-04-08 17:22:23 --> Database Driver Class Initialized
INFO - 2017-04-08 17:22:23 --> Model Class Initialized
INFO - 2017-04-08 17:22:23 --> Model Class Initialized
INFO - 2017-04-08 17:22:23 --> Email Class Initialized
INFO - 2017-04-08 17:22:23 --> Form Validation Class Initialized
INFO - 2017-04-08 17:22:23 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:22:23 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:22:23 --> Final output sent to browser
DEBUG - 2017-04-08 17:22:23 --> Total execution time: 0.1134
INFO - 2017-04-08 17:22:26 --> Config Class Initialized
INFO - 2017-04-08 17:22:26 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:22:26 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:22:26 --> Utf8 Class Initialized
INFO - 2017-04-08 17:22:26 --> URI Class Initialized
INFO - 2017-04-08 17:22:26 --> Router Class Initialized
INFO - 2017-04-08 17:22:26 --> Output Class Initialized
INFO - 2017-04-08 17:22:26 --> Security Class Initialized
DEBUG - 2017-04-08 17:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:22:26 --> Input Class Initialized
INFO - 2017-04-08 17:22:26 --> Language Class Initialized
INFO - 2017-04-08 17:22:26 --> Loader Class Initialized
INFO - 2017-04-08 17:22:26 --> Helper loaded: url_helper
INFO - 2017-04-08 17:22:26 --> Helper loaded: language_helper
INFO - 2017-04-08 17:22:26 --> Helper loaded: html_helper
INFO - 2017-04-08 17:22:26 --> Helper loaded: form_helper
INFO - 2017-04-08 17:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:22:26 --> Controller Class Initialized
INFO - 2017-04-08 17:22:26 --> Database Driver Class Initialized
INFO - 2017-04-08 17:22:26 --> Model Class Initialized
INFO - 2017-04-08 17:22:26 --> Model Class Initialized
INFO - 2017-04-08 17:22:26 --> Email Class Initialized
INFO - 2017-04-08 17:22:26 --> Form Validation Class Initialized
INFO - 2017-04-08 17:22:26 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:22:26 --> Final output sent to browser
DEBUG - 2017-04-08 17:22:26 --> Total execution time: 0.1100
INFO - 2017-04-08 17:24:06 --> Config Class Initialized
INFO - 2017-04-08 17:24:06 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:24:06 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:24:06 --> Utf8 Class Initialized
INFO - 2017-04-08 17:24:06 --> URI Class Initialized
INFO - 2017-04-08 17:24:06 --> Router Class Initialized
INFO - 2017-04-08 17:24:06 --> Output Class Initialized
INFO - 2017-04-08 17:24:06 --> Security Class Initialized
DEBUG - 2017-04-08 17:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:24:06 --> Input Class Initialized
INFO - 2017-04-08 17:24:06 --> Language Class Initialized
INFO - 2017-04-08 17:24:06 --> Loader Class Initialized
INFO - 2017-04-08 17:24:06 --> Helper loaded: url_helper
INFO - 2017-04-08 17:24:06 --> Helper loaded: language_helper
INFO - 2017-04-08 17:24:06 --> Helper loaded: html_helper
INFO - 2017-04-08 17:24:06 --> Helper loaded: form_helper
INFO - 2017-04-08 17:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:24:06 --> Controller Class Initialized
INFO - 2017-04-08 17:24:06 --> Database Driver Class Initialized
INFO - 2017-04-08 17:24:06 --> Model Class Initialized
INFO - 2017-04-08 17:24:06 --> Model Class Initialized
INFO - 2017-04-08 17:24:06 --> Email Class Initialized
INFO - 2017-04-08 17:24:06 --> Form Validation Class Initialized
INFO - 2017-04-08 17:24:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:24:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:24:06 --> Final output sent to browser
DEBUG - 2017-04-08 17:24:06 --> Total execution time: 0.1103
INFO - 2017-04-08 17:24:15 --> Config Class Initialized
INFO - 2017-04-08 17:24:15 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:24:15 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:24:15 --> Utf8 Class Initialized
INFO - 2017-04-08 17:24:15 --> URI Class Initialized
INFO - 2017-04-08 17:24:15 --> Router Class Initialized
INFO - 2017-04-08 17:24:15 --> Output Class Initialized
INFO - 2017-04-08 17:24:15 --> Security Class Initialized
DEBUG - 2017-04-08 17:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:24:15 --> Input Class Initialized
INFO - 2017-04-08 17:24:15 --> Language Class Initialized
INFO - 2017-04-08 17:24:15 --> Loader Class Initialized
INFO - 2017-04-08 17:24:15 --> Helper loaded: url_helper
INFO - 2017-04-08 17:24:15 --> Helper loaded: language_helper
INFO - 2017-04-08 17:24:15 --> Helper loaded: html_helper
INFO - 2017-04-08 17:24:15 --> Helper loaded: form_helper
INFO - 2017-04-08 17:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:24:15 --> Controller Class Initialized
INFO - 2017-04-08 17:24:15 --> Database Driver Class Initialized
INFO - 2017-04-08 17:24:15 --> Model Class Initialized
INFO - 2017-04-08 17:24:15 --> Model Class Initialized
INFO - 2017-04-08 17:24:15 --> Email Class Initialized
INFO - 2017-04-08 17:24:15 --> Form Validation Class Initialized
INFO - 2017-04-08 17:24:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:24:15 --> Final output sent to browser
DEBUG - 2017-04-08 17:24:15 --> Total execution time: 0.1100
INFO - 2017-04-08 17:24:46 --> Config Class Initialized
INFO - 2017-04-08 17:24:46 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:24:46 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:24:46 --> Utf8 Class Initialized
INFO - 2017-04-08 17:24:46 --> URI Class Initialized
INFO - 2017-04-08 17:24:46 --> Router Class Initialized
INFO - 2017-04-08 17:24:46 --> Output Class Initialized
INFO - 2017-04-08 17:24:46 --> Security Class Initialized
DEBUG - 2017-04-08 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:24:46 --> Input Class Initialized
INFO - 2017-04-08 17:24:46 --> Language Class Initialized
INFO - 2017-04-08 17:24:46 --> Loader Class Initialized
INFO - 2017-04-08 17:24:46 --> Helper loaded: url_helper
INFO - 2017-04-08 17:24:46 --> Helper loaded: language_helper
INFO - 2017-04-08 17:24:46 --> Helper loaded: html_helper
INFO - 2017-04-08 17:24:46 --> Helper loaded: form_helper
INFO - 2017-04-08 17:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:24:46 --> Controller Class Initialized
INFO - 2017-04-08 17:24:46 --> Database Driver Class Initialized
INFO - 2017-04-08 17:24:46 --> Model Class Initialized
INFO - 2017-04-08 17:24:46 --> Model Class Initialized
INFO - 2017-04-08 17:24:46 --> Email Class Initialized
INFO - 2017-04-08 17:24:46 --> Form Validation Class Initialized
INFO - 2017-04-08 17:24:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:24:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:24:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:24:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:24:46 --> Final output sent to browser
DEBUG - 2017-04-08 17:24:46 --> Total execution time: 0.1141
INFO - 2017-04-08 17:24:51 --> Config Class Initialized
INFO - 2017-04-08 17:24:51 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:24:51 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:24:51 --> Utf8 Class Initialized
INFO - 2017-04-08 17:24:51 --> URI Class Initialized
INFO - 2017-04-08 17:24:51 --> Router Class Initialized
INFO - 2017-04-08 17:24:51 --> Output Class Initialized
INFO - 2017-04-08 17:24:51 --> Security Class Initialized
DEBUG - 2017-04-08 17:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:24:51 --> Input Class Initialized
INFO - 2017-04-08 17:24:51 --> Language Class Initialized
INFO - 2017-04-08 17:24:51 --> Loader Class Initialized
INFO - 2017-04-08 17:24:51 --> Helper loaded: url_helper
INFO - 2017-04-08 17:24:51 --> Helper loaded: language_helper
INFO - 2017-04-08 17:24:51 --> Helper loaded: html_helper
INFO - 2017-04-08 17:24:51 --> Helper loaded: form_helper
INFO - 2017-04-08 17:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:24:51 --> Controller Class Initialized
INFO - 2017-04-08 17:24:51 --> Database Driver Class Initialized
INFO - 2017-04-08 17:24:51 --> Model Class Initialized
INFO - 2017-04-08 17:24:51 --> Model Class Initialized
INFO - 2017-04-08 17:24:51 --> Email Class Initialized
INFO - 2017-04-08 17:24:51 --> Form Validation Class Initialized
INFO - 2017-04-08 17:24:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:24:51 --> Final output sent to browser
DEBUG - 2017-04-08 17:24:51 --> Total execution time: 0.0864
INFO - 2017-04-08 17:25:20 --> Config Class Initialized
INFO - 2017-04-08 17:25:20 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:25:20 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:25:20 --> Utf8 Class Initialized
INFO - 2017-04-08 17:25:20 --> URI Class Initialized
INFO - 2017-04-08 17:25:20 --> Router Class Initialized
INFO - 2017-04-08 17:25:20 --> Output Class Initialized
INFO - 2017-04-08 17:25:20 --> Security Class Initialized
DEBUG - 2017-04-08 17:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:25:20 --> Input Class Initialized
INFO - 2017-04-08 17:25:20 --> Language Class Initialized
INFO - 2017-04-08 17:25:20 --> Loader Class Initialized
INFO - 2017-04-08 17:25:20 --> Helper loaded: url_helper
INFO - 2017-04-08 17:25:20 --> Helper loaded: language_helper
INFO - 2017-04-08 17:25:20 --> Helper loaded: html_helper
INFO - 2017-04-08 17:25:20 --> Helper loaded: form_helper
INFO - 2017-04-08 17:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:25:20 --> Controller Class Initialized
INFO - 2017-04-08 17:25:20 --> Database Driver Class Initialized
INFO - 2017-04-08 17:25:20 --> Model Class Initialized
INFO - 2017-04-08 17:25:20 --> Model Class Initialized
INFO - 2017-04-08 17:25:20 --> Email Class Initialized
INFO - 2017-04-08 17:25:20 --> Form Validation Class Initialized
INFO - 2017-04-08 17:25:20 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:25:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:25:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:25:20 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:25:20 --> Final output sent to browser
DEBUG - 2017-04-08 17:25:20 --> Total execution time: 0.0919
INFO - 2017-04-08 17:25:24 --> Config Class Initialized
INFO - 2017-04-08 17:25:24 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:25:24 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:25:24 --> Utf8 Class Initialized
INFO - 2017-04-08 17:25:24 --> URI Class Initialized
INFO - 2017-04-08 17:25:24 --> Router Class Initialized
INFO - 2017-04-08 17:25:24 --> Output Class Initialized
INFO - 2017-04-08 17:25:24 --> Security Class Initialized
DEBUG - 2017-04-08 17:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:25:24 --> Input Class Initialized
INFO - 2017-04-08 17:25:24 --> Language Class Initialized
INFO - 2017-04-08 17:25:24 --> Loader Class Initialized
INFO - 2017-04-08 17:25:24 --> Helper loaded: url_helper
INFO - 2017-04-08 17:25:24 --> Helper loaded: language_helper
INFO - 2017-04-08 17:25:24 --> Helper loaded: html_helper
INFO - 2017-04-08 17:25:24 --> Helper loaded: form_helper
INFO - 2017-04-08 17:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:25:24 --> Controller Class Initialized
INFO - 2017-04-08 17:25:24 --> Database Driver Class Initialized
INFO - 2017-04-08 17:25:24 --> Model Class Initialized
INFO - 2017-04-08 17:25:24 --> Model Class Initialized
INFO - 2017-04-08 17:25:24 --> Email Class Initialized
INFO - 2017-04-08 17:25:24 --> Form Validation Class Initialized
INFO - 2017-04-08 17:25:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:25:24 --> Final output sent to browser
DEBUG - 2017-04-08 17:25:24 --> Total execution time: 0.1225
INFO - 2017-04-08 17:26:18 --> Config Class Initialized
INFO - 2017-04-08 17:26:18 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:26:18 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:26:18 --> Utf8 Class Initialized
INFO - 2017-04-08 17:26:18 --> URI Class Initialized
INFO - 2017-04-08 17:26:18 --> Router Class Initialized
INFO - 2017-04-08 17:26:18 --> Output Class Initialized
INFO - 2017-04-08 17:26:18 --> Security Class Initialized
DEBUG - 2017-04-08 17:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:26:18 --> Input Class Initialized
INFO - 2017-04-08 17:26:18 --> Language Class Initialized
INFO - 2017-04-08 17:26:18 --> Loader Class Initialized
INFO - 2017-04-08 17:26:18 --> Helper loaded: url_helper
INFO - 2017-04-08 17:26:18 --> Helper loaded: language_helper
INFO - 2017-04-08 17:26:18 --> Helper loaded: html_helper
INFO - 2017-04-08 17:26:18 --> Helper loaded: form_helper
INFO - 2017-04-08 17:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:26:18 --> Controller Class Initialized
INFO - 2017-04-08 17:26:18 --> Database Driver Class Initialized
INFO - 2017-04-08 17:26:18 --> Model Class Initialized
INFO - 2017-04-08 17:26:18 --> Model Class Initialized
INFO - 2017-04-08 17:26:18 --> Email Class Initialized
INFO - 2017-04-08 17:26:18 --> Form Validation Class Initialized
INFO - 2017-04-08 17:26:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:26:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:26:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:26:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:26:18 --> Final output sent to browser
DEBUG - 2017-04-08 17:26:18 --> Total execution time: 0.0883
INFO - 2017-04-08 17:26:21 --> Config Class Initialized
INFO - 2017-04-08 17:26:21 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:26:21 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:26:21 --> Utf8 Class Initialized
INFO - 2017-04-08 17:26:21 --> URI Class Initialized
INFO - 2017-04-08 17:26:21 --> Router Class Initialized
INFO - 2017-04-08 17:26:21 --> Output Class Initialized
INFO - 2017-04-08 17:26:21 --> Security Class Initialized
DEBUG - 2017-04-08 17:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:26:21 --> Input Class Initialized
INFO - 2017-04-08 17:26:21 --> Language Class Initialized
INFO - 2017-04-08 17:26:21 --> Loader Class Initialized
INFO - 2017-04-08 17:26:21 --> Helper loaded: url_helper
INFO - 2017-04-08 17:26:21 --> Helper loaded: language_helper
INFO - 2017-04-08 17:26:21 --> Helper loaded: html_helper
INFO - 2017-04-08 17:26:21 --> Helper loaded: form_helper
INFO - 2017-04-08 17:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:26:21 --> Controller Class Initialized
INFO - 2017-04-08 17:26:21 --> Database Driver Class Initialized
INFO - 2017-04-08 17:26:21 --> Model Class Initialized
INFO - 2017-04-08 17:26:21 --> Model Class Initialized
INFO - 2017-04-08 17:26:21 --> Email Class Initialized
INFO - 2017-04-08 17:26:21 --> Form Validation Class Initialized
INFO - 2017-04-08 17:26:21 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:26:21 --> Final output sent to browser
DEBUG - 2017-04-08 17:26:21 --> Total execution time: 0.1173
INFO - 2017-04-08 17:27:10 --> Config Class Initialized
INFO - 2017-04-08 17:27:10 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:27:10 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:27:10 --> Utf8 Class Initialized
INFO - 2017-04-08 17:27:10 --> URI Class Initialized
INFO - 2017-04-08 17:27:10 --> Router Class Initialized
INFO - 2017-04-08 17:27:10 --> Output Class Initialized
INFO - 2017-04-08 17:27:10 --> Security Class Initialized
DEBUG - 2017-04-08 17:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:27:10 --> Input Class Initialized
INFO - 2017-04-08 17:27:10 --> Language Class Initialized
INFO - 2017-04-08 17:27:10 --> Loader Class Initialized
INFO - 2017-04-08 17:27:10 --> Helper loaded: url_helper
INFO - 2017-04-08 17:27:10 --> Helper loaded: language_helper
INFO - 2017-04-08 17:27:10 --> Helper loaded: html_helper
INFO - 2017-04-08 17:27:10 --> Helper loaded: form_helper
INFO - 2017-04-08 17:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:27:10 --> Controller Class Initialized
INFO - 2017-04-08 17:27:10 --> Database Driver Class Initialized
INFO - 2017-04-08 17:27:10 --> Model Class Initialized
INFO - 2017-04-08 17:27:10 --> Model Class Initialized
INFO - 2017-04-08 17:27:10 --> Email Class Initialized
INFO - 2017-04-08 17:27:10 --> Form Validation Class Initialized
INFO - 2017-04-08 17:27:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:27:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:27:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:27:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:27:10 --> Final output sent to browser
DEBUG - 2017-04-08 17:27:10 --> Total execution time: 0.0908
INFO - 2017-04-08 17:27:18 --> Config Class Initialized
INFO - 2017-04-08 17:27:18 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:27:18 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:27:18 --> Utf8 Class Initialized
INFO - 2017-04-08 17:27:18 --> URI Class Initialized
INFO - 2017-04-08 17:27:18 --> Router Class Initialized
INFO - 2017-04-08 17:27:18 --> Output Class Initialized
INFO - 2017-04-08 17:27:18 --> Security Class Initialized
DEBUG - 2017-04-08 17:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:27:18 --> Input Class Initialized
INFO - 2017-04-08 17:27:18 --> Language Class Initialized
INFO - 2017-04-08 17:27:18 --> Loader Class Initialized
INFO - 2017-04-08 17:27:18 --> Helper loaded: url_helper
INFO - 2017-04-08 17:27:18 --> Helper loaded: language_helper
INFO - 2017-04-08 17:27:18 --> Helper loaded: html_helper
INFO - 2017-04-08 17:27:18 --> Helper loaded: form_helper
INFO - 2017-04-08 17:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:27:18 --> Controller Class Initialized
INFO - 2017-04-08 17:27:18 --> Database Driver Class Initialized
INFO - 2017-04-08 17:27:18 --> Model Class Initialized
INFO - 2017-04-08 17:27:18 --> Model Class Initialized
INFO - 2017-04-08 17:27:18 --> Email Class Initialized
INFO - 2017-04-08 17:27:18 --> Form Validation Class Initialized
INFO - 2017-04-08 17:27:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:27:18 --> Final output sent to browser
DEBUG - 2017-04-08 17:27:18 --> Total execution time: 0.1268
INFO - 2017-04-08 17:27:52 --> Config Class Initialized
INFO - 2017-04-08 17:27:52 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:27:52 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:27:52 --> Utf8 Class Initialized
INFO - 2017-04-08 17:27:52 --> URI Class Initialized
INFO - 2017-04-08 17:27:52 --> Router Class Initialized
INFO - 2017-04-08 17:27:52 --> Output Class Initialized
INFO - 2017-04-08 17:27:52 --> Security Class Initialized
DEBUG - 2017-04-08 17:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:27:52 --> Input Class Initialized
INFO - 2017-04-08 17:27:52 --> Language Class Initialized
INFO - 2017-04-08 17:27:52 --> Loader Class Initialized
INFO - 2017-04-08 17:27:52 --> Helper loaded: url_helper
INFO - 2017-04-08 17:27:52 --> Helper loaded: language_helper
INFO - 2017-04-08 17:27:52 --> Helper loaded: html_helper
INFO - 2017-04-08 17:27:52 --> Helper loaded: form_helper
INFO - 2017-04-08 17:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:27:52 --> Controller Class Initialized
INFO - 2017-04-08 17:27:52 --> Database Driver Class Initialized
INFO - 2017-04-08 17:27:52 --> Model Class Initialized
INFO - 2017-04-08 17:27:52 --> Model Class Initialized
INFO - 2017-04-08 17:27:52 --> Email Class Initialized
INFO - 2017-04-08 17:27:52 --> Form Validation Class Initialized
INFO - 2017-04-08 17:27:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:27:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 17:27:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 17:27:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 17:27:52 --> Final output sent to browser
DEBUG - 2017-04-08 17:27:52 --> Total execution time: 0.1017
INFO - 2017-04-08 17:27:59 --> Config Class Initialized
INFO - 2017-04-08 17:27:59 --> Hooks Class Initialized
DEBUG - 2017-04-08 17:27:59 --> UTF-8 Support Enabled
INFO - 2017-04-08 17:27:59 --> Utf8 Class Initialized
INFO - 2017-04-08 17:27:59 --> URI Class Initialized
INFO - 2017-04-08 17:27:59 --> Router Class Initialized
INFO - 2017-04-08 17:27:59 --> Output Class Initialized
INFO - 2017-04-08 17:27:59 --> Security Class Initialized
DEBUG - 2017-04-08 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 17:27:59 --> Input Class Initialized
INFO - 2017-04-08 17:27:59 --> Language Class Initialized
INFO - 2017-04-08 17:27:59 --> Loader Class Initialized
INFO - 2017-04-08 17:27:59 --> Helper loaded: url_helper
INFO - 2017-04-08 17:27:59 --> Helper loaded: language_helper
INFO - 2017-04-08 17:27:59 --> Helper loaded: html_helper
INFO - 2017-04-08 17:27:59 --> Helper loaded: form_helper
INFO - 2017-04-08 17:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 17:27:59 --> Controller Class Initialized
INFO - 2017-04-08 17:27:59 --> Database Driver Class Initialized
INFO - 2017-04-08 17:27:59 --> Model Class Initialized
INFO - 2017-04-08 17:27:59 --> Model Class Initialized
INFO - 2017-04-08 17:27:59 --> Email Class Initialized
INFO - 2017-04-08 17:27:59 --> Form Validation Class Initialized
INFO - 2017-04-08 17:27:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 17:27:59 --> Final output sent to browser
DEBUG - 2017-04-08 17:27:59 --> Total execution time: 0.0926
INFO - 2017-04-08 18:00:45 --> Config Class Initialized
INFO - 2017-04-08 18:00:45 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:00:45 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:00:45 --> Utf8 Class Initialized
INFO - 2017-04-08 18:00:45 --> URI Class Initialized
INFO - 2017-04-08 18:00:45 --> Router Class Initialized
INFO - 2017-04-08 18:00:45 --> Output Class Initialized
INFO - 2017-04-08 18:00:45 --> Security Class Initialized
DEBUG - 2017-04-08 18:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:00:45 --> Input Class Initialized
INFO - 2017-04-08 18:00:45 --> Language Class Initialized
INFO - 2017-04-08 18:00:45 --> Loader Class Initialized
INFO - 2017-04-08 18:00:45 --> Helper loaded: url_helper
INFO - 2017-04-08 18:00:45 --> Helper loaded: language_helper
INFO - 2017-04-08 18:00:45 --> Helper loaded: html_helper
INFO - 2017-04-08 18:00:45 --> Helper loaded: form_helper
INFO - 2017-04-08 18:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:00:45 --> Controller Class Initialized
INFO - 2017-04-08 18:00:45 --> Database Driver Class Initialized
INFO - 2017-04-08 18:00:45 --> Model Class Initialized
INFO - 2017-04-08 18:00:45 --> Model Class Initialized
INFO - 2017-04-08 18:00:45 --> Email Class Initialized
INFO - 2017-04-08 18:00:45 --> Form Validation Class Initialized
INFO - 2017-04-08 18:00:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:00:45 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:00:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:00:46 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:00:46 --> Final output sent to browser
DEBUG - 2017-04-08 18:00:46 --> Total execution time: 0.1282
INFO - 2017-04-08 18:00:51 --> Config Class Initialized
INFO - 2017-04-08 18:00:51 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:00:51 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:00:51 --> Utf8 Class Initialized
INFO - 2017-04-08 18:00:51 --> URI Class Initialized
INFO - 2017-04-08 18:00:51 --> Router Class Initialized
INFO - 2017-04-08 18:00:51 --> Output Class Initialized
INFO - 2017-04-08 18:00:51 --> Security Class Initialized
DEBUG - 2017-04-08 18:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:00:51 --> Input Class Initialized
INFO - 2017-04-08 18:00:51 --> Language Class Initialized
INFO - 2017-04-08 18:00:51 --> Loader Class Initialized
INFO - 2017-04-08 18:00:51 --> Helper loaded: url_helper
INFO - 2017-04-08 18:00:51 --> Helper loaded: language_helper
INFO - 2017-04-08 18:00:51 --> Helper loaded: html_helper
INFO - 2017-04-08 18:00:51 --> Helper loaded: form_helper
INFO - 2017-04-08 18:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:00:51 --> Controller Class Initialized
INFO - 2017-04-08 18:00:51 --> Database Driver Class Initialized
INFO - 2017-04-08 18:00:51 --> Model Class Initialized
INFO - 2017-04-08 18:00:51 --> Model Class Initialized
INFO - 2017-04-08 18:00:51 --> Email Class Initialized
INFO - 2017-04-08 18:00:51 --> Form Validation Class Initialized
INFO - 2017-04-08 18:00:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:00:51 --> Final output sent to browser
DEBUG - 2017-04-08 18:00:51 --> Total execution time: 0.0992
INFO - 2017-04-08 18:01:25 --> Config Class Initialized
INFO - 2017-04-08 18:01:25 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:01:25 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:01:25 --> Utf8 Class Initialized
INFO - 2017-04-08 18:01:25 --> URI Class Initialized
INFO - 2017-04-08 18:01:25 --> Router Class Initialized
INFO - 2017-04-08 18:01:25 --> Output Class Initialized
INFO - 2017-04-08 18:01:25 --> Security Class Initialized
DEBUG - 2017-04-08 18:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:01:25 --> Input Class Initialized
INFO - 2017-04-08 18:01:25 --> Language Class Initialized
INFO - 2017-04-08 18:01:25 --> Loader Class Initialized
INFO - 2017-04-08 18:01:25 --> Helper loaded: url_helper
INFO - 2017-04-08 18:01:25 --> Helper loaded: language_helper
INFO - 2017-04-08 18:01:25 --> Helper loaded: html_helper
INFO - 2017-04-08 18:01:25 --> Helper loaded: form_helper
INFO - 2017-04-08 18:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:01:25 --> Controller Class Initialized
INFO - 2017-04-08 18:01:25 --> Database Driver Class Initialized
INFO - 2017-04-08 18:01:25 --> Model Class Initialized
INFO - 2017-04-08 18:01:25 --> Model Class Initialized
INFO - 2017-04-08 18:01:25 --> Email Class Initialized
INFO - 2017-04-08 18:01:25 --> Form Validation Class Initialized
INFO - 2017-04-08 18:01:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:01:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:01:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:01:25 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:01:25 --> Final output sent to browser
DEBUG - 2017-04-08 18:01:25 --> Total execution time: 0.0935
INFO - 2017-04-08 18:01:29 --> Config Class Initialized
INFO - 2017-04-08 18:01:29 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:01:29 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:01:29 --> Utf8 Class Initialized
INFO - 2017-04-08 18:01:29 --> URI Class Initialized
INFO - 2017-04-08 18:01:29 --> Router Class Initialized
INFO - 2017-04-08 18:01:29 --> Output Class Initialized
INFO - 2017-04-08 18:01:29 --> Security Class Initialized
DEBUG - 2017-04-08 18:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:01:29 --> Input Class Initialized
INFO - 2017-04-08 18:01:29 --> Language Class Initialized
INFO - 2017-04-08 18:01:29 --> Loader Class Initialized
INFO - 2017-04-08 18:01:29 --> Helper loaded: url_helper
INFO - 2017-04-08 18:01:29 --> Helper loaded: language_helper
INFO - 2017-04-08 18:01:29 --> Helper loaded: html_helper
INFO - 2017-04-08 18:01:29 --> Helper loaded: form_helper
INFO - 2017-04-08 18:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:01:29 --> Controller Class Initialized
INFO - 2017-04-08 18:01:29 --> Database Driver Class Initialized
INFO - 2017-04-08 18:01:29 --> Model Class Initialized
INFO - 2017-04-08 18:01:29 --> Model Class Initialized
INFO - 2017-04-08 18:01:29 --> Email Class Initialized
INFO - 2017-04-08 18:01:29 --> Form Validation Class Initialized
INFO - 2017-04-08 18:01:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:01:29 --> Final output sent to browser
DEBUG - 2017-04-08 18:01:29 --> Total execution time: 0.1188
INFO - 2017-04-08 18:01:49 --> Config Class Initialized
INFO - 2017-04-08 18:01:49 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:01:49 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:01:49 --> Utf8 Class Initialized
INFO - 2017-04-08 18:01:49 --> URI Class Initialized
INFO - 2017-04-08 18:01:49 --> Router Class Initialized
INFO - 2017-04-08 18:01:49 --> Output Class Initialized
INFO - 2017-04-08 18:01:49 --> Security Class Initialized
DEBUG - 2017-04-08 18:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:01:49 --> Input Class Initialized
INFO - 2017-04-08 18:01:49 --> Language Class Initialized
INFO - 2017-04-08 18:01:49 --> Loader Class Initialized
INFO - 2017-04-08 18:01:49 --> Helper loaded: url_helper
INFO - 2017-04-08 18:01:49 --> Helper loaded: language_helper
INFO - 2017-04-08 18:01:49 --> Helper loaded: html_helper
INFO - 2017-04-08 18:01:49 --> Helper loaded: form_helper
INFO - 2017-04-08 18:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:01:49 --> Controller Class Initialized
INFO - 2017-04-08 18:01:49 --> Database Driver Class Initialized
INFO - 2017-04-08 18:01:49 --> Model Class Initialized
INFO - 2017-04-08 18:01:49 --> Model Class Initialized
INFO - 2017-04-08 18:01:49 --> Email Class Initialized
INFO - 2017-04-08 18:01:49 --> Form Validation Class Initialized
INFO - 2017-04-08 18:01:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:01:49 --> Final output sent to browser
DEBUG - 2017-04-08 18:01:49 --> Total execution time: 0.0969
INFO - 2017-04-08 18:02:06 --> Config Class Initialized
INFO - 2017-04-08 18:02:06 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:02:06 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:02:06 --> Utf8 Class Initialized
INFO - 2017-04-08 18:02:06 --> URI Class Initialized
INFO - 2017-04-08 18:02:06 --> Router Class Initialized
INFO - 2017-04-08 18:02:06 --> Output Class Initialized
INFO - 2017-04-08 18:02:06 --> Security Class Initialized
DEBUG - 2017-04-08 18:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:02:06 --> Input Class Initialized
INFO - 2017-04-08 18:02:06 --> Language Class Initialized
INFO - 2017-04-08 18:02:06 --> Loader Class Initialized
INFO - 2017-04-08 18:02:06 --> Helper loaded: url_helper
INFO - 2017-04-08 18:02:06 --> Helper loaded: language_helper
INFO - 2017-04-08 18:02:06 --> Helper loaded: html_helper
INFO - 2017-04-08 18:02:06 --> Helper loaded: form_helper
INFO - 2017-04-08 18:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:02:06 --> Controller Class Initialized
INFO - 2017-04-08 18:02:06 --> Database Driver Class Initialized
INFO - 2017-04-08 18:02:06 --> Model Class Initialized
INFO - 2017-04-08 18:02:06 --> Model Class Initialized
INFO - 2017-04-08 18:02:06 --> Email Class Initialized
INFO - 2017-04-08 18:02:06 --> Form Validation Class Initialized
INFO - 2017-04-08 18:02:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:02:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:02:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:02:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:02:06 --> Final output sent to browser
DEBUG - 2017-04-08 18:02:06 --> Total execution time: 0.0992
INFO - 2017-04-08 18:02:10 --> Config Class Initialized
INFO - 2017-04-08 18:02:10 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:02:10 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:02:10 --> Utf8 Class Initialized
INFO - 2017-04-08 18:02:10 --> URI Class Initialized
INFO - 2017-04-08 18:02:10 --> Router Class Initialized
INFO - 2017-04-08 18:02:10 --> Output Class Initialized
INFO - 2017-04-08 18:02:10 --> Security Class Initialized
DEBUG - 2017-04-08 18:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:02:10 --> Input Class Initialized
INFO - 2017-04-08 18:02:10 --> Language Class Initialized
INFO - 2017-04-08 18:02:10 --> Loader Class Initialized
INFO - 2017-04-08 18:02:10 --> Helper loaded: url_helper
INFO - 2017-04-08 18:02:10 --> Helper loaded: language_helper
INFO - 2017-04-08 18:02:10 --> Helper loaded: html_helper
INFO - 2017-04-08 18:02:10 --> Helper loaded: form_helper
INFO - 2017-04-08 18:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:02:10 --> Controller Class Initialized
INFO - 2017-04-08 18:02:10 --> Database Driver Class Initialized
INFO - 2017-04-08 18:02:10 --> Model Class Initialized
INFO - 2017-04-08 18:02:10 --> Model Class Initialized
INFO - 2017-04-08 18:02:10 --> Email Class Initialized
INFO - 2017-04-08 18:02:10 --> Form Validation Class Initialized
INFO - 2017-04-08 18:02:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:02:10 --> Final output sent to browser
DEBUG - 2017-04-08 18:02:10 --> Total execution time: 0.0992
INFO - 2017-04-08 18:02:18 --> Config Class Initialized
INFO - 2017-04-08 18:02:18 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:02:18 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:02:18 --> Utf8 Class Initialized
INFO - 2017-04-08 18:02:18 --> URI Class Initialized
INFO - 2017-04-08 18:02:18 --> Router Class Initialized
INFO - 2017-04-08 18:02:18 --> Output Class Initialized
INFO - 2017-04-08 18:02:18 --> Security Class Initialized
DEBUG - 2017-04-08 18:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:02:18 --> Input Class Initialized
INFO - 2017-04-08 18:02:18 --> Language Class Initialized
INFO - 2017-04-08 18:02:18 --> Loader Class Initialized
INFO - 2017-04-08 18:02:18 --> Helper loaded: url_helper
INFO - 2017-04-08 18:02:18 --> Helper loaded: language_helper
INFO - 2017-04-08 18:02:18 --> Helper loaded: html_helper
INFO - 2017-04-08 18:02:18 --> Helper loaded: form_helper
INFO - 2017-04-08 18:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:02:18 --> Controller Class Initialized
INFO - 2017-04-08 18:02:18 --> Database Driver Class Initialized
INFO - 2017-04-08 18:02:18 --> Model Class Initialized
INFO - 2017-04-08 18:02:18 --> Model Class Initialized
INFO - 2017-04-08 18:02:18 --> Email Class Initialized
INFO - 2017-04-08 18:02:18 --> Form Validation Class Initialized
INFO - 2017-04-08 18:02:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:02:18 --> Final output sent to browser
DEBUG - 2017-04-08 18:02:18 --> Total execution time: 0.0954
INFO - 2017-04-08 18:02:29 --> Config Class Initialized
INFO - 2017-04-08 18:02:29 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:02:29 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:02:29 --> Utf8 Class Initialized
INFO - 2017-04-08 18:02:29 --> URI Class Initialized
INFO - 2017-04-08 18:02:29 --> Router Class Initialized
INFO - 2017-04-08 18:02:29 --> Output Class Initialized
INFO - 2017-04-08 18:02:29 --> Security Class Initialized
DEBUG - 2017-04-08 18:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:02:29 --> Input Class Initialized
INFO - 2017-04-08 18:02:29 --> Language Class Initialized
INFO - 2017-04-08 18:02:29 --> Loader Class Initialized
INFO - 2017-04-08 18:02:29 --> Helper loaded: url_helper
INFO - 2017-04-08 18:02:29 --> Helper loaded: language_helper
INFO - 2017-04-08 18:02:29 --> Helper loaded: html_helper
INFO - 2017-04-08 18:02:29 --> Helper loaded: form_helper
INFO - 2017-04-08 18:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:02:29 --> Controller Class Initialized
INFO - 2017-04-08 18:02:29 --> Database Driver Class Initialized
INFO - 2017-04-08 18:02:29 --> Model Class Initialized
INFO - 2017-04-08 18:02:29 --> Model Class Initialized
INFO - 2017-04-08 18:02:29 --> Email Class Initialized
INFO - 2017-04-08 18:02:29 --> Form Validation Class Initialized
INFO - 2017-04-08 18:02:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:02:29 --> Final output sent to browser
DEBUG - 2017-04-08 18:02:29 --> Total execution time: 0.0953
INFO - 2017-04-08 18:02:41 --> Config Class Initialized
INFO - 2017-04-08 18:02:41 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:02:41 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:02:41 --> Utf8 Class Initialized
INFO - 2017-04-08 18:02:41 --> URI Class Initialized
INFO - 2017-04-08 18:02:41 --> Router Class Initialized
INFO - 2017-04-08 18:02:41 --> Output Class Initialized
INFO - 2017-04-08 18:02:41 --> Security Class Initialized
DEBUG - 2017-04-08 18:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:02:41 --> Input Class Initialized
INFO - 2017-04-08 18:02:41 --> Language Class Initialized
INFO - 2017-04-08 18:02:41 --> Loader Class Initialized
INFO - 2017-04-08 18:02:41 --> Helper loaded: url_helper
INFO - 2017-04-08 18:02:41 --> Helper loaded: language_helper
INFO - 2017-04-08 18:02:41 --> Helper loaded: html_helper
INFO - 2017-04-08 18:02:41 --> Helper loaded: form_helper
INFO - 2017-04-08 18:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:02:41 --> Controller Class Initialized
INFO - 2017-04-08 18:02:41 --> Database Driver Class Initialized
INFO - 2017-04-08 18:02:41 --> Model Class Initialized
INFO - 2017-04-08 18:02:41 --> Model Class Initialized
INFO - 2017-04-08 18:02:41 --> Email Class Initialized
INFO - 2017-04-08 18:02:41 --> Form Validation Class Initialized
INFO - 2017-04-08 18:02:41 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:02:41 --> Final output sent to browser
DEBUG - 2017-04-08 18:02:41 --> Total execution time: 0.1002
INFO - 2017-04-08 18:02:56 --> Config Class Initialized
INFO - 2017-04-08 18:02:56 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:02:56 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:02:56 --> Utf8 Class Initialized
INFO - 2017-04-08 18:02:56 --> URI Class Initialized
INFO - 2017-04-08 18:02:56 --> Router Class Initialized
INFO - 2017-04-08 18:02:56 --> Output Class Initialized
INFO - 2017-04-08 18:02:56 --> Security Class Initialized
DEBUG - 2017-04-08 18:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:02:56 --> Input Class Initialized
INFO - 2017-04-08 18:02:56 --> Language Class Initialized
INFO - 2017-04-08 18:02:56 --> Loader Class Initialized
INFO - 2017-04-08 18:02:56 --> Helper loaded: url_helper
INFO - 2017-04-08 18:02:56 --> Helper loaded: language_helper
INFO - 2017-04-08 18:02:56 --> Helper loaded: html_helper
INFO - 2017-04-08 18:02:56 --> Helper loaded: form_helper
INFO - 2017-04-08 18:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:02:56 --> Controller Class Initialized
INFO - 2017-04-08 18:02:56 --> Database Driver Class Initialized
INFO - 2017-04-08 18:02:56 --> Model Class Initialized
INFO - 2017-04-08 18:02:56 --> Model Class Initialized
INFO - 2017-04-08 18:02:56 --> Email Class Initialized
INFO - 2017-04-08 18:02:56 --> Form Validation Class Initialized
INFO - 2017-04-08 18:02:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:02:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:02:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:02:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:02:56 --> Final output sent to browser
DEBUG - 2017-04-08 18:02:56 --> Total execution time: 0.0947
INFO - 2017-04-08 18:03:01 --> Config Class Initialized
INFO - 2017-04-08 18:03:01 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:03:01 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:03:01 --> Utf8 Class Initialized
INFO - 2017-04-08 18:03:01 --> URI Class Initialized
INFO - 2017-04-08 18:03:01 --> Router Class Initialized
INFO - 2017-04-08 18:03:01 --> Output Class Initialized
INFO - 2017-04-08 18:03:01 --> Security Class Initialized
DEBUG - 2017-04-08 18:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:03:01 --> Input Class Initialized
INFO - 2017-04-08 18:03:01 --> Language Class Initialized
INFO - 2017-04-08 18:03:01 --> Loader Class Initialized
INFO - 2017-04-08 18:03:01 --> Helper loaded: url_helper
INFO - 2017-04-08 18:03:01 --> Helper loaded: language_helper
INFO - 2017-04-08 18:03:01 --> Helper loaded: html_helper
INFO - 2017-04-08 18:03:01 --> Helper loaded: form_helper
INFO - 2017-04-08 18:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:03:01 --> Controller Class Initialized
INFO - 2017-04-08 18:03:01 --> Database Driver Class Initialized
INFO - 2017-04-08 18:03:01 --> Model Class Initialized
INFO - 2017-04-08 18:03:01 --> Model Class Initialized
INFO - 2017-04-08 18:03:01 --> Email Class Initialized
INFO - 2017-04-08 18:03:01 --> Form Validation Class Initialized
INFO - 2017-04-08 18:03:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:03:01 --> Final output sent to browser
DEBUG - 2017-04-08 18:03:01 --> Total execution time: 0.0937
INFO - 2017-04-08 18:03:14 --> Config Class Initialized
INFO - 2017-04-08 18:03:14 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:03:14 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:03:14 --> Utf8 Class Initialized
INFO - 2017-04-08 18:03:14 --> URI Class Initialized
INFO - 2017-04-08 18:03:14 --> Router Class Initialized
INFO - 2017-04-08 18:03:14 --> Output Class Initialized
INFO - 2017-04-08 18:03:14 --> Security Class Initialized
DEBUG - 2017-04-08 18:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:03:14 --> Input Class Initialized
INFO - 2017-04-08 18:03:14 --> Language Class Initialized
INFO - 2017-04-08 18:03:14 --> Loader Class Initialized
INFO - 2017-04-08 18:03:14 --> Helper loaded: url_helper
INFO - 2017-04-08 18:03:14 --> Helper loaded: language_helper
INFO - 2017-04-08 18:03:14 --> Helper loaded: html_helper
INFO - 2017-04-08 18:03:14 --> Helper loaded: form_helper
INFO - 2017-04-08 18:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:03:14 --> Controller Class Initialized
INFO - 2017-04-08 18:03:14 --> Database Driver Class Initialized
INFO - 2017-04-08 18:03:14 --> Model Class Initialized
INFO - 2017-04-08 18:03:14 --> Model Class Initialized
INFO - 2017-04-08 18:03:14 --> Email Class Initialized
INFO - 2017-04-08 18:03:14 --> Form Validation Class Initialized
INFO - 2017-04-08 18:03:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:03:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:03:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:03:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:03:14 --> Final output sent to browser
DEBUG - 2017-04-08 18:03:14 --> Total execution time: 0.0917
INFO - 2017-04-08 18:03:17 --> Config Class Initialized
INFO - 2017-04-08 18:03:17 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:03:17 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:03:17 --> Utf8 Class Initialized
INFO - 2017-04-08 18:03:17 --> URI Class Initialized
INFO - 2017-04-08 18:03:17 --> Router Class Initialized
INFO - 2017-04-08 18:03:17 --> Output Class Initialized
INFO - 2017-04-08 18:03:17 --> Security Class Initialized
DEBUG - 2017-04-08 18:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:03:17 --> Input Class Initialized
INFO - 2017-04-08 18:03:17 --> Language Class Initialized
INFO - 2017-04-08 18:03:17 --> Loader Class Initialized
INFO - 2017-04-08 18:03:17 --> Helper loaded: url_helper
INFO - 2017-04-08 18:03:17 --> Helper loaded: language_helper
INFO - 2017-04-08 18:03:17 --> Helper loaded: html_helper
INFO - 2017-04-08 18:03:17 --> Helper loaded: form_helper
INFO - 2017-04-08 18:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:03:17 --> Controller Class Initialized
INFO - 2017-04-08 18:03:17 --> Database Driver Class Initialized
INFO - 2017-04-08 18:03:17 --> Model Class Initialized
INFO - 2017-04-08 18:03:17 --> Model Class Initialized
INFO - 2017-04-08 18:03:17 --> Email Class Initialized
INFO - 2017-04-08 18:03:17 --> Form Validation Class Initialized
INFO - 2017-04-08 18:03:17 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:03:17 --> Final output sent to browser
DEBUG - 2017-04-08 18:03:17 --> Total execution time: 0.0943
INFO - 2017-04-08 18:03:24 --> Config Class Initialized
INFO - 2017-04-08 18:03:24 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:03:24 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:03:24 --> Utf8 Class Initialized
INFO - 2017-04-08 18:03:24 --> URI Class Initialized
INFO - 2017-04-08 18:03:24 --> Router Class Initialized
INFO - 2017-04-08 18:03:24 --> Output Class Initialized
INFO - 2017-04-08 18:03:24 --> Security Class Initialized
DEBUG - 2017-04-08 18:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:03:24 --> Input Class Initialized
INFO - 2017-04-08 18:03:24 --> Language Class Initialized
INFO - 2017-04-08 18:03:24 --> Loader Class Initialized
INFO - 2017-04-08 18:03:24 --> Helper loaded: url_helper
INFO - 2017-04-08 18:03:24 --> Helper loaded: language_helper
INFO - 2017-04-08 18:03:24 --> Helper loaded: html_helper
INFO - 2017-04-08 18:03:24 --> Helper loaded: form_helper
INFO - 2017-04-08 18:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:03:24 --> Controller Class Initialized
INFO - 2017-04-08 18:03:24 --> Database Driver Class Initialized
INFO - 2017-04-08 18:03:24 --> Model Class Initialized
INFO - 2017-04-08 18:03:24 --> Model Class Initialized
INFO - 2017-04-08 18:03:24 --> Email Class Initialized
INFO - 2017-04-08 18:03:24 --> Form Validation Class Initialized
INFO - 2017-04-08 18:03:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:03:24 --> Final output sent to browser
DEBUG - 2017-04-08 18:03:24 --> Total execution time: 0.0968
INFO - 2017-04-08 18:03:56 --> Config Class Initialized
INFO - 2017-04-08 18:03:56 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:03:56 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:03:56 --> Utf8 Class Initialized
INFO - 2017-04-08 18:03:56 --> URI Class Initialized
INFO - 2017-04-08 18:03:56 --> Router Class Initialized
INFO - 2017-04-08 18:03:56 --> Output Class Initialized
INFO - 2017-04-08 18:03:56 --> Security Class Initialized
DEBUG - 2017-04-08 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:03:56 --> Input Class Initialized
INFO - 2017-04-08 18:03:56 --> Language Class Initialized
INFO - 2017-04-08 18:03:56 --> Loader Class Initialized
INFO - 2017-04-08 18:03:56 --> Helper loaded: url_helper
INFO - 2017-04-08 18:03:56 --> Helper loaded: language_helper
INFO - 2017-04-08 18:03:56 --> Helper loaded: html_helper
INFO - 2017-04-08 18:03:56 --> Helper loaded: form_helper
INFO - 2017-04-08 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:03:56 --> Controller Class Initialized
INFO - 2017-04-08 18:03:56 --> Database Driver Class Initialized
INFO - 2017-04-08 18:03:56 --> Model Class Initialized
INFO - 2017-04-08 18:03:56 --> Model Class Initialized
INFO - 2017-04-08 18:03:56 --> Email Class Initialized
INFO - 2017-04-08 18:03:56 --> Form Validation Class Initialized
INFO - 2017-04-08 18:03:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:03:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:03:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:03:56 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:03:56 --> Final output sent to browser
DEBUG - 2017-04-08 18:03:56 --> Total execution time: 0.0926
INFO - 2017-04-08 18:04:00 --> Config Class Initialized
INFO - 2017-04-08 18:04:00 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:04:00 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:04:00 --> Utf8 Class Initialized
INFO - 2017-04-08 18:04:00 --> URI Class Initialized
INFO - 2017-04-08 18:04:00 --> Router Class Initialized
INFO - 2017-04-08 18:04:00 --> Output Class Initialized
INFO - 2017-04-08 18:04:00 --> Security Class Initialized
DEBUG - 2017-04-08 18:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:04:00 --> Input Class Initialized
INFO - 2017-04-08 18:04:00 --> Language Class Initialized
INFO - 2017-04-08 18:04:00 --> Loader Class Initialized
INFO - 2017-04-08 18:04:00 --> Helper loaded: url_helper
INFO - 2017-04-08 18:04:00 --> Helper loaded: language_helper
INFO - 2017-04-08 18:04:00 --> Helper loaded: html_helper
INFO - 2017-04-08 18:04:00 --> Helper loaded: form_helper
INFO - 2017-04-08 18:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:04:00 --> Controller Class Initialized
INFO - 2017-04-08 18:04:00 --> Database Driver Class Initialized
INFO - 2017-04-08 18:04:00 --> Model Class Initialized
INFO - 2017-04-08 18:04:00 --> Model Class Initialized
INFO - 2017-04-08 18:04:00 --> Email Class Initialized
INFO - 2017-04-08 18:04:00 --> Form Validation Class Initialized
INFO - 2017-04-08 18:04:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:04:00 --> Final output sent to browser
DEBUG - 2017-04-08 18:04:00 --> Total execution time: 0.0908
INFO - 2017-04-08 18:04:36 --> Config Class Initialized
INFO - 2017-04-08 18:04:36 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:04:36 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:04:36 --> Utf8 Class Initialized
INFO - 2017-04-08 18:04:36 --> URI Class Initialized
INFO - 2017-04-08 18:04:36 --> Router Class Initialized
INFO - 2017-04-08 18:04:36 --> Output Class Initialized
INFO - 2017-04-08 18:04:36 --> Security Class Initialized
DEBUG - 2017-04-08 18:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:04:36 --> Input Class Initialized
INFO - 2017-04-08 18:04:36 --> Language Class Initialized
INFO - 2017-04-08 18:04:36 --> Loader Class Initialized
INFO - 2017-04-08 18:04:36 --> Helper loaded: url_helper
INFO - 2017-04-08 18:04:36 --> Helper loaded: language_helper
INFO - 2017-04-08 18:04:36 --> Helper loaded: html_helper
INFO - 2017-04-08 18:04:36 --> Helper loaded: form_helper
INFO - 2017-04-08 18:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:04:36 --> Controller Class Initialized
INFO - 2017-04-08 18:04:36 --> Database Driver Class Initialized
INFO - 2017-04-08 18:04:36 --> Model Class Initialized
INFO - 2017-04-08 18:04:36 --> Model Class Initialized
INFO - 2017-04-08 18:04:36 --> Email Class Initialized
INFO - 2017-04-08 18:04:36 --> Form Validation Class Initialized
INFO - 2017-04-08 18:04:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:04:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:04:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:04:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:04:36 --> Final output sent to browser
DEBUG - 2017-04-08 18:04:36 --> Total execution time: 0.1304
INFO - 2017-04-08 18:04:39 --> Config Class Initialized
INFO - 2017-04-08 18:04:39 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:04:39 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:04:39 --> Utf8 Class Initialized
INFO - 2017-04-08 18:04:39 --> URI Class Initialized
INFO - 2017-04-08 18:04:39 --> Router Class Initialized
INFO - 2017-04-08 18:04:39 --> Output Class Initialized
INFO - 2017-04-08 18:04:39 --> Security Class Initialized
DEBUG - 2017-04-08 18:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:04:39 --> Input Class Initialized
INFO - 2017-04-08 18:04:39 --> Language Class Initialized
INFO - 2017-04-08 18:04:39 --> Loader Class Initialized
INFO - 2017-04-08 18:04:39 --> Helper loaded: url_helper
INFO - 2017-04-08 18:04:39 --> Helper loaded: language_helper
INFO - 2017-04-08 18:04:39 --> Helper loaded: html_helper
INFO - 2017-04-08 18:04:39 --> Helper loaded: form_helper
INFO - 2017-04-08 18:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:04:39 --> Controller Class Initialized
INFO - 2017-04-08 18:04:39 --> Database Driver Class Initialized
INFO - 2017-04-08 18:04:39 --> Model Class Initialized
INFO - 2017-04-08 18:04:39 --> Model Class Initialized
INFO - 2017-04-08 18:04:39 --> Email Class Initialized
INFO - 2017-04-08 18:04:39 --> Form Validation Class Initialized
INFO - 2017-04-08 18:04:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:04:39 --> Final output sent to browser
DEBUG - 2017-04-08 18:04:39 --> Total execution time: 0.0975
INFO - 2017-04-08 18:05:21 --> Config Class Initialized
INFO - 2017-04-08 18:05:21 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:05:21 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:05:21 --> Utf8 Class Initialized
INFO - 2017-04-08 18:05:21 --> URI Class Initialized
INFO - 2017-04-08 18:05:21 --> Router Class Initialized
INFO - 2017-04-08 18:05:21 --> Output Class Initialized
INFO - 2017-04-08 18:05:21 --> Security Class Initialized
DEBUG - 2017-04-08 18:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:05:21 --> Input Class Initialized
INFO - 2017-04-08 18:05:21 --> Language Class Initialized
INFO - 2017-04-08 18:05:21 --> Loader Class Initialized
INFO - 2017-04-08 18:05:21 --> Helper loaded: url_helper
INFO - 2017-04-08 18:05:21 --> Helper loaded: language_helper
INFO - 2017-04-08 18:05:21 --> Helper loaded: html_helper
INFO - 2017-04-08 18:05:21 --> Helper loaded: form_helper
INFO - 2017-04-08 18:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:05:21 --> Controller Class Initialized
INFO - 2017-04-08 18:05:22 --> Database Driver Class Initialized
INFO - 2017-04-08 18:05:22 --> Model Class Initialized
INFO - 2017-04-08 18:05:22 --> Model Class Initialized
INFO - 2017-04-08 18:05:22 --> Email Class Initialized
INFO - 2017-04-08 18:05:22 --> Form Validation Class Initialized
INFO - 2017-04-08 18:05:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:05:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:05:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:05:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:05:22 --> Final output sent to browser
DEBUG - 2017-04-08 18:05:22 --> Total execution time: 0.0930
INFO - 2017-04-08 18:05:25 --> Config Class Initialized
INFO - 2017-04-08 18:05:25 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:05:25 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:05:25 --> Utf8 Class Initialized
INFO - 2017-04-08 18:05:25 --> URI Class Initialized
INFO - 2017-04-08 18:05:25 --> Router Class Initialized
INFO - 2017-04-08 18:05:25 --> Output Class Initialized
INFO - 2017-04-08 18:05:25 --> Security Class Initialized
DEBUG - 2017-04-08 18:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:05:25 --> Input Class Initialized
INFO - 2017-04-08 18:05:25 --> Language Class Initialized
INFO - 2017-04-08 18:05:25 --> Loader Class Initialized
INFO - 2017-04-08 18:05:25 --> Helper loaded: url_helper
INFO - 2017-04-08 18:05:25 --> Helper loaded: language_helper
INFO - 2017-04-08 18:05:25 --> Helper loaded: html_helper
INFO - 2017-04-08 18:05:25 --> Helper loaded: form_helper
INFO - 2017-04-08 18:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:05:25 --> Controller Class Initialized
INFO - 2017-04-08 18:05:25 --> Database Driver Class Initialized
INFO - 2017-04-08 18:05:25 --> Model Class Initialized
INFO - 2017-04-08 18:05:25 --> Model Class Initialized
INFO - 2017-04-08 18:05:25 --> Email Class Initialized
INFO - 2017-04-08 18:05:25 --> Form Validation Class Initialized
INFO - 2017-04-08 18:05:25 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:05:25 --> Final output sent to browser
DEBUG - 2017-04-08 18:05:25 --> Total execution time: 0.1063
INFO - 2017-04-08 18:06:06 --> Config Class Initialized
INFO - 2017-04-08 18:06:06 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:06:06 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:06:06 --> Utf8 Class Initialized
INFO - 2017-04-08 18:06:06 --> URI Class Initialized
INFO - 2017-04-08 18:06:06 --> Router Class Initialized
INFO - 2017-04-08 18:06:06 --> Output Class Initialized
INFO - 2017-04-08 18:06:06 --> Security Class Initialized
DEBUG - 2017-04-08 18:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:06:06 --> Input Class Initialized
INFO - 2017-04-08 18:06:06 --> Language Class Initialized
INFO - 2017-04-08 18:06:06 --> Loader Class Initialized
INFO - 2017-04-08 18:06:06 --> Helper loaded: url_helper
INFO - 2017-04-08 18:06:06 --> Helper loaded: language_helper
INFO - 2017-04-08 18:06:06 --> Helper loaded: html_helper
INFO - 2017-04-08 18:06:06 --> Helper loaded: form_helper
INFO - 2017-04-08 18:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:06:06 --> Controller Class Initialized
INFO - 2017-04-08 18:06:06 --> Database Driver Class Initialized
INFO - 2017-04-08 18:06:06 --> Model Class Initialized
INFO - 2017-04-08 18:06:06 --> Model Class Initialized
INFO - 2017-04-08 18:06:06 --> Email Class Initialized
INFO - 2017-04-08 18:06:06 --> Form Validation Class Initialized
INFO - 2017-04-08 18:06:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 18:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 18:06:06 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 18:06:06 --> Final output sent to browser
DEBUG - 2017-04-08 18:06:06 --> Total execution time: 0.1109
INFO - 2017-04-08 18:06:09 --> Config Class Initialized
INFO - 2017-04-08 18:06:09 --> Hooks Class Initialized
DEBUG - 2017-04-08 18:06:09 --> UTF-8 Support Enabled
INFO - 2017-04-08 18:06:09 --> Utf8 Class Initialized
INFO - 2017-04-08 18:06:09 --> URI Class Initialized
INFO - 2017-04-08 18:06:09 --> Router Class Initialized
INFO - 2017-04-08 18:06:09 --> Output Class Initialized
INFO - 2017-04-08 18:06:09 --> Security Class Initialized
DEBUG - 2017-04-08 18:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 18:06:09 --> Input Class Initialized
INFO - 2017-04-08 18:06:09 --> Language Class Initialized
INFO - 2017-04-08 18:06:09 --> Loader Class Initialized
INFO - 2017-04-08 18:06:09 --> Helper loaded: url_helper
INFO - 2017-04-08 18:06:09 --> Helper loaded: language_helper
INFO - 2017-04-08 18:06:09 --> Helper loaded: html_helper
INFO - 2017-04-08 18:06:09 --> Helper loaded: form_helper
INFO - 2017-04-08 18:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 18:06:09 --> Controller Class Initialized
INFO - 2017-04-08 18:06:09 --> Database Driver Class Initialized
INFO - 2017-04-08 18:06:09 --> Model Class Initialized
INFO - 2017-04-08 18:06:09 --> Model Class Initialized
INFO - 2017-04-08 18:06:09 --> Email Class Initialized
INFO - 2017-04-08 18:06:09 --> Form Validation Class Initialized
INFO - 2017-04-08 18:06:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 18:06:09 --> Final output sent to browser
DEBUG - 2017-04-08 18:06:09 --> Total execution time: 0.1085
INFO - 2017-04-08 19:30:33 --> Config Class Initialized
INFO - 2017-04-08 19:30:33 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:30:33 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:30:33 --> Utf8 Class Initialized
INFO - 2017-04-08 19:30:33 --> URI Class Initialized
INFO - 2017-04-08 19:30:33 --> Router Class Initialized
INFO - 2017-04-08 19:30:33 --> Output Class Initialized
INFO - 2017-04-08 19:30:33 --> Security Class Initialized
DEBUG - 2017-04-08 19:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:30:33 --> Input Class Initialized
INFO - 2017-04-08 19:30:33 --> Language Class Initialized
INFO - 2017-04-08 19:30:33 --> Loader Class Initialized
INFO - 2017-04-08 19:30:33 --> Helper loaded: url_helper
INFO - 2017-04-08 19:30:33 --> Helper loaded: language_helper
INFO - 2017-04-08 19:30:33 --> Helper loaded: html_helper
INFO - 2017-04-08 19:30:33 --> Helper loaded: form_helper
INFO - 2017-04-08 19:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:30:33 --> Controller Class Initialized
INFO - 2017-04-08 19:30:33 --> Database Driver Class Initialized
INFO - 2017-04-08 19:30:33 --> Model Class Initialized
INFO - 2017-04-08 19:30:33 --> Model Class Initialized
INFO - 2017-04-08 19:30:33 --> Email Class Initialized
INFO - 2017-04-08 19:30:33 --> Form Validation Class Initialized
INFO - 2017-04-08 19:30:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:30:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:30:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:30:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:30:33 --> Final output sent to browser
DEBUG - 2017-04-08 19:30:33 --> Total execution time: 0.1049
INFO - 2017-04-08 19:30:38 --> Config Class Initialized
INFO - 2017-04-08 19:30:38 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:30:38 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:30:38 --> Utf8 Class Initialized
INFO - 2017-04-08 19:30:38 --> URI Class Initialized
INFO - 2017-04-08 19:30:39 --> Router Class Initialized
INFO - 2017-04-08 19:30:39 --> Output Class Initialized
INFO - 2017-04-08 19:30:39 --> Security Class Initialized
DEBUG - 2017-04-08 19:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:30:39 --> Input Class Initialized
INFO - 2017-04-08 19:30:39 --> Language Class Initialized
INFO - 2017-04-08 19:30:39 --> Loader Class Initialized
INFO - 2017-04-08 19:30:39 --> Helper loaded: url_helper
INFO - 2017-04-08 19:30:39 --> Helper loaded: language_helper
INFO - 2017-04-08 19:30:39 --> Helper loaded: html_helper
INFO - 2017-04-08 19:30:39 --> Helper loaded: form_helper
INFO - 2017-04-08 19:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:30:39 --> Controller Class Initialized
INFO - 2017-04-08 19:30:39 --> Database Driver Class Initialized
INFO - 2017-04-08 19:30:39 --> Model Class Initialized
INFO - 2017-04-08 19:30:39 --> Model Class Initialized
INFO - 2017-04-08 19:30:39 --> Email Class Initialized
INFO - 2017-04-08 19:30:39 --> Form Validation Class Initialized
INFO - 2017-04-08 19:30:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:30:39 --> Final output sent to browser
DEBUG - 2017-04-08 19:30:39 --> Total execution time: 0.0983
INFO - 2017-04-08 19:30:45 --> Config Class Initialized
INFO - 2017-04-08 19:30:45 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:30:45 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:30:45 --> Utf8 Class Initialized
INFO - 2017-04-08 19:30:45 --> URI Class Initialized
INFO - 2017-04-08 19:30:45 --> Router Class Initialized
INFO - 2017-04-08 19:30:45 --> Output Class Initialized
INFO - 2017-04-08 19:30:45 --> Security Class Initialized
DEBUG - 2017-04-08 19:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:30:45 --> Input Class Initialized
INFO - 2017-04-08 19:30:45 --> Language Class Initialized
INFO - 2017-04-08 19:30:45 --> Loader Class Initialized
INFO - 2017-04-08 19:30:45 --> Helper loaded: url_helper
INFO - 2017-04-08 19:30:45 --> Helper loaded: language_helper
INFO - 2017-04-08 19:30:45 --> Helper loaded: html_helper
INFO - 2017-04-08 19:30:45 --> Helper loaded: form_helper
INFO - 2017-04-08 19:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:30:45 --> Controller Class Initialized
INFO - 2017-04-08 19:30:45 --> Database Driver Class Initialized
INFO - 2017-04-08 19:30:45 --> Model Class Initialized
INFO - 2017-04-08 19:30:45 --> Model Class Initialized
INFO - 2017-04-08 19:30:45 --> Email Class Initialized
INFO - 2017-04-08 19:30:45 --> Form Validation Class Initialized
INFO - 2017-04-08 19:30:45 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:30:45 --> Final output sent to browser
DEBUG - 2017-04-08 19:30:45 --> Total execution time: 0.0904
INFO - 2017-04-08 19:31:07 --> Config Class Initialized
INFO - 2017-04-08 19:31:07 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:31:07 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:31:07 --> Utf8 Class Initialized
INFO - 2017-04-08 19:31:07 --> URI Class Initialized
INFO - 2017-04-08 19:31:07 --> Router Class Initialized
INFO - 2017-04-08 19:31:07 --> Output Class Initialized
INFO - 2017-04-08 19:31:07 --> Security Class Initialized
DEBUG - 2017-04-08 19:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:31:07 --> Input Class Initialized
INFO - 2017-04-08 19:31:07 --> Language Class Initialized
INFO - 2017-04-08 19:31:07 --> Loader Class Initialized
INFO - 2017-04-08 19:31:07 --> Helper loaded: url_helper
INFO - 2017-04-08 19:31:07 --> Helper loaded: language_helper
INFO - 2017-04-08 19:31:07 --> Helper loaded: html_helper
INFO - 2017-04-08 19:31:07 --> Helper loaded: form_helper
INFO - 2017-04-08 19:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:31:07 --> Controller Class Initialized
INFO - 2017-04-08 19:31:07 --> Database Driver Class Initialized
INFO - 2017-04-08 19:31:07 --> Model Class Initialized
INFO - 2017-04-08 19:31:07 --> Model Class Initialized
INFO - 2017-04-08 19:31:07 --> Email Class Initialized
INFO - 2017-04-08 19:31:07 --> Form Validation Class Initialized
INFO - 2017-04-08 19:31:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:31:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:31:07 --> Final output sent to browser
DEBUG - 2017-04-08 19:31:07 --> Total execution time: 0.1081
INFO - 2017-04-08 19:31:11 --> Config Class Initialized
INFO - 2017-04-08 19:31:11 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:31:11 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:31:11 --> Utf8 Class Initialized
INFO - 2017-04-08 19:31:11 --> URI Class Initialized
INFO - 2017-04-08 19:31:11 --> Router Class Initialized
INFO - 2017-04-08 19:31:11 --> Output Class Initialized
INFO - 2017-04-08 19:31:11 --> Security Class Initialized
DEBUG - 2017-04-08 19:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:31:11 --> Input Class Initialized
INFO - 2017-04-08 19:31:11 --> Language Class Initialized
INFO - 2017-04-08 19:31:11 --> Loader Class Initialized
INFO - 2017-04-08 19:31:11 --> Helper loaded: url_helper
INFO - 2017-04-08 19:31:11 --> Helper loaded: language_helper
INFO - 2017-04-08 19:31:11 --> Helper loaded: html_helper
INFO - 2017-04-08 19:31:11 --> Helper loaded: form_helper
INFO - 2017-04-08 19:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:31:11 --> Controller Class Initialized
INFO - 2017-04-08 19:31:11 --> Database Driver Class Initialized
INFO - 2017-04-08 19:31:11 --> Model Class Initialized
INFO - 2017-04-08 19:31:11 --> Model Class Initialized
INFO - 2017-04-08 19:31:11 --> Email Class Initialized
INFO - 2017-04-08 19:31:11 --> Form Validation Class Initialized
INFO - 2017-04-08 19:31:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:31:11 --> Final output sent to browser
DEBUG - 2017-04-08 19:31:11 --> Total execution time: 0.0935
INFO - 2017-04-08 19:32:09 --> Config Class Initialized
INFO - 2017-04-08 19:32:09 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:32:09 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:32:09 --> Utf8 Class Initialized
INFO - 2017-04-08 19:32:09 --> URI Class Initialized
INFO - 2017-04-08 19:32:09 --> Router Class Initialized
INFO - 2017-04-08 19:32:09 --> Output Class Initialized
INFO - 2017-04-08 19:32:09 --> Security Class Initialized
DEBUG - 2017-04-08 19:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:32:09 --> Input Class Initialized
INFO - 2017-04-08 19:32:09 --> Language Class Initialized
INFO - 2017-04-08 19:32:09 --> Loader Class Initialized
INFO - 2017-04-08 19:32:09 --> Helper loaded: url_helper
INFO - 2017-04-08 19:32:09 --> Helper loaded: language_helper
INFO - 2017-04-08 19:32:09 --> Helper loaded: html_helper
INFO - 2017-04-08 19:32:09 --> Helper loaded: form_helper
INFO - 2017-04-08 19:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:32:09 --> Controller Class Initialized
INFO - 2017-04-08 19:32:09 --> Database Driver Class Initialized
INFO - 2017-04-08 19:32:09 --> Model Class Initialized
INFO - 2017-04-08 19:32:09 --> Model Class Initialized
INFO - 2017-04-08 19:32:09 --> Email Class Initialized
INFO - 2017-04-08 19:32:09 --> Form Validation Class Initialized
INFO - 2017-04-08 19:32:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:32:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:32:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:32:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:32:09 --> Final output sent to browser
DEBUG - 2017-04-08 19:32:09 --> Total execution time: 0.0968
INFO - 2017-04-08 19:32:15 --> Config Class Initialized
INFO - 2017-04-08 19:32:15 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:32:15 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:32:15 --> Utf8 Class Initialized
INFO - 2017-04-08 19:32:15 --> URI Class Initialized
INFO - 2017-04-08 19:32:15 --> Router Class Initialized
INFO - 2017-04-08 19:32:15 --> Output Class Initialized
INFO - 2017-04-08 19:32:15 --> Security Class Initialized
DEBUG - 2017-04-08 19:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:32:15 --> Input Class Initialized
INFO - 2017-04-08 19:32:15 --> Language Class Initialized
INFO - 2017-04-08 19:32:15 --> Loader Class Initialized
INFO - 2017-04-08 19:32:15 --> Helper loaded: url_helper
INFO - 2017-04-08 19:32:15 --> Helper loaded: language_helper
INFO - 2017-04-08 19:32:15 --> Helper loaded: html_helper
INFO - 2017-04-08 19:32:15 --> Helper loaded: form_helper
INFO - 2017-04-08 19:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:32:15 --> Controller Class Initialized
INFO - 2017-04-08 19:32:15 --> Database Driver Class Initialized
INFO - 2017-04-08 19:32:15 --> Model Class Initialized
INFO - 2017-04-08 19:32:15 --> Model Class Initialized
INFO - 2017-04-08 19:32:15 --> Email Class Initialized
INFO - 2017-04-08 19:32:15 --> Form Validation Class Initialized
INFO - 2017-04-08 19:32:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:32:15 --> Final output sent to browser
DEBUG - 2017-04-08 19:32:15 --> Total execution time: 0.0961
INFO - 2017-04-08 19:33:27 --> Config Class Initialized
INFO - 2017-04-08 19:33:27 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:33:27 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:33:27 --> Utf8 Class Initialized
INFO - 2017-04-08 19:33:27 --> URI Class Initialized
INFO - 2017-04-08 19:33:27 --> Router Class Initialized
INFO - 2017-04-08 19:33:27 --> Output Class Initialized
INFO - 2017-04-08 19:33:27 --> Security Class Initialized
DEBUG - 2017-04-08 19:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:33:27 --> Input Class Initialized
INFO - 2017-04-08 19:33:27 --> Language Class Initialized
INFO - 2017-04-08 19:33:27 --> Loader Class Initialized
INFO - 2017-04-08 19:33:27 --> Helper loaded: url_helper
INFO - 2017-04-08 19:33:27 --> Helper loaded: language_helper
INFO - 2017-04-08 19:33:27 --> Helper loaded: html_helper
INFO - 2017-04-08 19:33:27 --> Helper loaded: form_helper
INFO - 2017-04-08 19:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:33:27 --> Controller Class Initialized
INFO - 2017-04-08 19:33:27 --> Database Driver Class Initialized
INFO - 2017-04-08 19:33:27 --> Model Class Initialized
INFO - 2017-04-08 19:33:27 --> Model Class Initialized
INFO - 2017-04-08 19:33:27 --> Email Class Initialized
INFO - 2017-04-08 19:33:27 --> Form Validation Class Initialized
INFO - 2017-04-08 19:33:27 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:33:27 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:33:27 --> Final output sent to browser
DEBUG - 2017-04-08 19:33:27 --> Total execution time: 0.0966
INFO - 2017-04-08 19:33:32 --> Config Class Initialized
INFO - 2017-04-08 19:33:32 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:33:32 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:33:32 --> Utf8 Class Initialized
INFO - 2017-04-08 19:33:32 --> URI Class Initialized
INFO - 2017-04-08 19:33:32 --> Router Class Initialized
INFO - 2017-04-08 19:33:32 --> Output Class Initialized
INFO - 2017-04-08 19:33:32 --> Security Class Initialized
DEBUG - 2017-04-08 19:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:33:32 --> Input Class Initialized
INFO - 2017-04-08 19:33:32 --> Language Class Initialized
INFO - 2017-04-08 19:33:32 --> Loader Class Initialized
INFO - 2017-04-08 19:33:32 --> Helper loaded: url_helper
INFO - 2017-04-08 19:33:32 --> Helper loaded: language_helper
INFO - 2017-04-08 19:33:32 --> Helper loaded: html_helper
INFO - 2017-04-08 19:33:32 --> Helper loaded: form_helper
INFO - 2017-04-08 19:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:33:32 --> Controller Class Initialized
INFO - 2017-04-08 19:33:32 --> Database Driver Class Initialized
INFO - 2017-04-08 19:33:32 --> Model Class Initialized
INFO - 2017-04-08 19:33:32 --> Model Class Initialized
INFO - 2017-04-08 19:33:32 --> Email Class Initialized
INFO - 2017-04-08 19:33:32 --> Form Validation Class Initialized
INFO - 2017-04-08 19:33:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:33:32 --> Final output sent to browser
DEBUG - 2017-04-08 19:33:32 --> Total execution time: 0.1349
INFO - 2017-04-08 19:33:36 --> Config Class Initialized
INFO - 2017-04-08 19:33:36 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:33:36 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:33:36 --> Utf8 Class Initialized
INFO - 2017-04-08 19:33:36 --> URI Class Initialized
INFO - 2017-04-08 19:33:36 --> Router Class Initialized
INFO - 2017-04-08 19:33:36 --> Output Class Initialized
INFO - 2017-04-08 19:33:36 --> Security Class Initialized
DEBUG - 2017-04-08 19:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:33:36 --> Input Class Initialized
INFO - 2017-04-08 19:33:36 --> Language Class Initialized
INFO - 2017-04-08 19:33:36 --> Loader Class Initialized
INFO - 2017-04-08 19:33:36 --> Helper loaded: url_helper
INFO - 2017-04-08 19:33:36 --> Helper loaded: language_helper
INFO - 2017-04-08 19:33:36 --> Helper loaded: html_helper
INFO - 2017-04-08 19:33:36 --> Helper loaded: form_helper
INFO - 2017-04-08 19:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:33:36 --> Controller Class Initialized
INFO - 2017-04-08 19:33:36 --> Database Driver Class Initialized
INFO - 2017-04-08 19:33:36 --> Model Class Initialized
INFO - 2017-04-08 19:33:36 --> Model Class Initialized
INFO - 2017-04-08 19:33:36 --> Email Class Initialized
INFO - 2017-04-08 19:33:36 --> Form Validation Class Initialized
INFO - 2017-04-08 19:33:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:33:36 --> Final output sent to browser
DEBUG - 2017-04-08 19:33:36 --> Total execution time: 0.1208
INFO - 2017-04-08 19:33:57 --> Config Class Initialized
INFO - 2017-04-08 19:33:57 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:33:57 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:33:57 --> Utf8 Class Initialized
INFO - 2017-04-08 19:33:57 --> URI Class Initialized
INFO - 2017-04-08 19:33:57 --> Router Class Initialized
INFO - 2017-04-08 19:33:57 --> Output Class Initialized
INFO - 2017-04-08 19:33:57 --> Security Class Initialized
DEBUG - 2017-04-08 19:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:33:57 --> Input Class Initialized
INFO - 2017-04-08 19:33:57 --> Language Class Initialized
INFO - 2017-04-08 19:33:57 --> Loader Class Initialized
INFO - 2017-04-08 19:33:57 --> Helper loaded: url_helper
INFO - 2017-04-08 19:33:57 --> Helper loaded: language_helper
INFO - 2017-04-08 19:33:57 --> Helper loaded: html_helper
INFO - 2017-04-08 19:33:57 --> Helper loaded: form_helper
INFO - 2017-04-08 19:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:33:57 --> Controller Class Initialized
INFO - 2017-04-08 19:33:57 --> Database Driver Class Initialized
INFO - 2017-04-08 19:33:57 --> Model Class Initialized
INFO - 2017-04-08 19:33:57 --> Model Class Initialized
INFO - 2017-04-08 19:33:57 --> Email Class Initialized
INFO - 2017-04-08 19:33:57 --> Form Validation Class Initialized
INFO - 2017-04-08 19:33:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:33:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:33:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:33:57 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:33:57 --> Final output sent to browser
DEBUG - 2017-04-08 19:33:57 --> Total execution time: 0.0922
INFO - 2017-04-08 19:34:00 --> Config Class Initialized
INFO - 2017-04-08 19:34:00 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:34:00 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:34:00 --> Utf8 Class Initialized
INFO - 2017-04-08 19:34:00 --> URI Class Initialized
INFO - 2017-04-08 19:34:00 --> Router Class Initialized
INFO - 2017-04-08 19:34:00 --> Output Class Initialized
INFO - 2017-04-08 19:34:00 --> Security Class Initialized
DEBUG - 2017-04-08 19:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:34:00 --> Input Class Initialized
INFO - 2017-04-08 19:34:00 --> Language Class Initialized
INFO - 2017-04-08 19:34:00 --> Loader Class Initialized
INFO - 2017-04-08 19:34:00 --> Helper loaded: url_helper
INFO - 2017-04-08 19:34:00 --> Helper loaded: language_helper
INFO - 2017-04-08 19:34:00 --> Helper loaded: html_helper
INFO - 2017-04-08 19:34:00 --> Helper loaded: form_helper
INFO - 2017-04-08 19:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:34:00 --> Controller Class Initialized
INFO - 2017-04-08 19:34:00 --> Database Driver Class Initialized
INFO - 2017-04-08 19:34:00 --> Model Class Initialized
INFO - 2017-04-08 19:34:00 --> Model Class Initialized
INFO - 2017-04-08 19:34:00 --> Email Class Initialized
INFO - 2017-04-08 19:34:00 --> Form Validation Class Initialized
INFO - 2017-04-08 19:34:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:34:00 --> Final output sent to browser
DEBUG - 2017-04-08 19:34:00 --> Total execution time: 0.1010
INFO - 2017-04-08 19:34:18 --> Config Class Initialized
INFO - 2017-04-08 19:34:18 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:34:18 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:34:18 --> Utf8 Class Initialized
INFO - 2017-04-08 19:34:18 --> URI Class Initialized
INFO - 2017-04-08 19:34:18 --> Router Class Initialized
INFO - 2017-04-08 19:34:18 --> Output Class Initialized
INFO - 2017-04-08 19:34:18 --> Security Class Initialized
DEBUG - 2017-04-08 19:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:34:18 --> Input Class Initialized
INFO - 2017-04-08 19:34:18 --> Language Class Initialized
INFO - 2017-04-08 19:34:18 --> Loader Class Initialized
INFO - 2017-04-08 19:34:18 --> Helper loaded: url_helper
INFO - 2017-04-08 19:34:18 --> Helper loaded: language_helper
INFO - 2017-04-08 19:34:18 --> Helper loaded: html_helper
INFO - 2017-04-08 19:34:18 --> Helper loaded: form_helper
INFO - 2017-04-08 19:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:34:18 --> Controller Class Initialized
INFO - 2017-04-08 19:34:18 --> Database Driver Class Initialized
INFO - 2017-04-08 19:34:18 --> Model Class Initialized
INFO - 2017-04-08 19:34:18 --> Model Class Initialized
INFO - 2017-04-08 19:34:18 --> Email Class Initialized
INFO - 2017-04-08 19:34:18 --> Form Validation Class Initialized
INFO - 2017-04-08 19:34:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:34:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:34:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:34:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:34:18 --> Final output sent to browser
DEBUG - 2017-04-08 19:34:18 --> Total execution time: 0.0927
INFO - 2017-04-08 19:36:48 --> Config Class Initialized
INFO - 2017-04-08 19:36:48 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:36:48 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:36:48 --> Utf8 Class Initialized
INFO - 2017-04-08 19:36:48 --> URI Class Initialized
INFO - 2017-04-08 19:36:48 --> Router Class Initialized
INFO - 2017-04-08 19:36:48 --> Output Class Initialized
INFO - 2017-04-08 19:36:48 --> Security Class Initialized
DEBUG - 2017-04-08 19:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:36:48 --> Input Class Initialized
INFO - 2017-04-08 19:36:48 --> Language Class Initialized
INFO - 2017-04-08 19:36:48 --> Loader Class Initialized
INFO - 2017-04-08 19:36:48 --> Helper loaded: url_helper
INFO - 2017-04-08 19:36:48 --> Helper loaded: language_helper
INFO - 2017-04-08 19:36:48 --> Helper loaded: html_helper
INFO - 2017-04-08 19:36:48 --> Helper loaded: form_helper
INFO - 2017-04-08 19:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:36:48 --> Controller Class Initialized
INFO - 2017-04-08 19:36:48 --> Database Driver Class Initialized
INFO - 2017-04-08 19:36:48 --> Model Class Initialized
INFO - 2017-04-08 19:36:48 --> Model Class Initialized
INFO - 2017-04-08 19:36:48 --> Email Class Initialized
INFO - 2017-04-08 19:36:48 --> Form Validation Class Initialized
INFO - 2017-04-08 19:36:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:36:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:36:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:36:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:36:48 --> Final output sent to browser
DEBUG - 2017-04-08 19:36:48 --> Total execution time: 0.1199
INFO - 2017-04-08 19:42:50 --> Config Class Initialized
INFO - 2017-04-08 19:42:50 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:42:50 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:42:50 --> Utf8 Class Initialized
INFO - 2017-04-08 19:42:50 --> URI Class Initialized
INFO - 2017-04-08 19:42:50 --> Router Class Initialized
INFO - 2017-04-08 19:42:50 --> Output Class Initialized
INFO - 2017-04-08 19:42:50 --> Security Class Initialized
DEBUG - 2017-04-08 19:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:42:50 --> Input Class Initialized
INFO - 2017-04-08 19:42:50 --> Language Class Initialized
INFO - 2017-04-08 19:42:50 --> Loader Class Initialized
INFO - 2017-04-08 19:42:51 --> Helper loaded: url_helper
INFO - 2017-04-08 19:42:51 --> Helper loaded: language_helper
INFO - 2017-04-08 19:42:51 --> Helper loaded: html_helper
INFO - 2017-04-08 19:42:51 --> Helper loaded: form_helper
INFO - 2017-04-08 19:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:42:51 --> Controller Class Initialized
INFO - 2017-04-08 19:42:51 --> Database Driver Class Initialized
INFO - 2017-04-08 19:42:51 --> Model Class Initialized
INFO - 2017-04-08 19:42:51 --> Model Class Initialized
INFO - 2017-04-08 19:42:51 --> Email Class Initialized
INFO - 2017-04-08 19:42:51 --> Form Validation Class Initialized
INFO - 2017-04-08 19:42:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:42:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:42:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:42:51 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:42:51 --> Final output sent to browser
DEBUG - 2017-04-08 19:42:51 --> Total execution time: 0.1283
INFO - 2017-04-08 19:43:22 --> Config Class Initialized
INFO - 2017-04-08 19:43:22 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:43:22 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:43:22 --> Utf8 Class Initialized
INFO - 2017-04-08 19:43:22 --> URI Class Initialized
INFO - 2017-04-08 19:43:22 --> Router Class Initialized
INFO - 2017-04-08 19:43:22 --> Output Class Initialized
INFO - 2017-04-08 19:43:22 --> Security Class Initialized
DEBUG - 2017-04-08 19:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:43:22 --> Input Class Initialized
INFO - 2017-04-08 19:43:22 --> Language Class Initialized
INFO - 2017-04-08 19:43:22 --> Loader Class Initialized
INFO - 2017-04-08 19:43:22 --> Helper loaded: url_helper
INFO - 2017-04-08 19:43:22 --> Helper loaded: language_helper
INFO - 2017-04-08 19:43:22 --> Helper loaded: html_helper
INFO - 2017-04-08 19:43:22 --> Helper loaded: form_helper
INFO - 2017-04-08 19:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:43:22 --> Controller Class Initialized
INFO - 2017-04-08 19:43:22 --> Database Driver Class Initialized
INFO - 2017-04-08 19:43:22 --> Model Class Initialized
INFO - 2017-04-08 19:43:22 --> Model Class Initialized
INFO - 2017-04-08 19:43:22 --> Email Class Initialized
INFO - 2017-04-08 19:43:22 --> Form Validation Class Initialized
INFO - 2017-04-08 19:43:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:43:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:43:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:43:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:43:22 --> Final output sent to browser
DEBUG - 2017-04-08 19:43:22 --> Total execution time: 0.1122
INFO - 2017-04-08 19:43:33 --> Config Class Initialized
INFO - 2017-04-08 19:43:33 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:43:33 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:43:33 --> Utf8 Class Initialized
INFO - 2017-04-08 19:43:33 --> URI Class Initialized
INFO - 2017-04-08 19:43:33 --> Router Class Initialized
INFO - 2017-04-08 19:43:33 --> Output Class Initialized
INFO - 2017-04-08 19:43:33 --> Security Class Initialized
DEBUG - 2017-04-08 19:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:43:33 --> Input Class Initialized
INFO - 2017-04-08 19:43:33 --> Language Class Initialized
INFO - 2017-04-08 19:43:33 --> Loader Class Initialized
INFO - 2017-04-08 19:43:33 --> Helper loaded: url_helper
INFO - 2017-04-08 19:43:33 --> Helper loaded: language_helper
INFO - 2017-04-08 19:43:33 --> Helper loaded: html_helper
INFO - 2017-04-08 19:43:33 --> Helper loaded: form_helper
INFO - 2017-04-08 19:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:43:33 --> Controller Class Initialized
INFO - 2017-04-08 19:43:33 --> Database Driver Class Initialized
INFO - 2017-04-08 19:43:33 --> Model Class Initialized
INFO - 2017-04-08 19:43:33 --> Model Class Initialized
INFO - 2017-04-08 19:43:33 --> Email Class Initialized
INFO - 2017-04-08 19:43:33 --> Form Validation Class Initialized
INFO - 2017-04-08 19:43:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:43:33 --> Final output sent to browser
DEBUG - 2017-04-08 19:43:33 --> Total execution time: 0.1099
INFO - 2017-04-08 19:43:56 --> Config Class Initialized
INFO - 2017-04-08 19:43:56 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:43:56 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:43:56 --> Utf8 Class Initialized
INFO - 2017-04-08 19:43:56 --> URI Class Initialized
INFO - 2017-04-08 19:43:56 --> Router Class Initialized
INFO - 2017-04-08 19:43:56 --> Output Class Initialized
INFO - 2017-04-08 19:43:56 --> Security Class Initialized
DEBUG - 2017-04-08 19:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:43:56 --> Input Class Initialized
INFO - 2017-04-08 19:43:56 --> Language Class Initialized
INFO - 2017-04-08 19:43:56 --> Loader Class Initialized
INFO - 2017-04-08 19:43:56 --> Helper loaded: url_helper
INFO - 2017-04-08 19:43:56 --> Helper loaded: language_helper
INFO - 2017-04-08 19:43:56 --> Helper loaded: html_helper
INFO - 2017-04-08 19:43:56 --> Helper loaded: form_helper
INFO - 2017-04-08 19:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:43:56 --> Controller Class Initialized
INFO - 2017-04-08 19:43:56 --> Database Driver Class Initialized
INFO - 2017-04-08 19:43:56 --> Model Class Initialized
INFO - 2017-04-08 19:43:56 --> Model Class Initialized
INFO - 2017-04-08 19:43:56 --> Email Class Initialized
INFO - 2017-04-08 19:43:56 --> Form Validation Class Initialized
INFO - 2017-04-08 19:43:56 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:43:56 --> Final output sent to browser
DEBUG - 2017-04-08 19:43:56 --> Total execution time: 0.0990
INFO - 2017-04-08 19:44:00 --> Config Class Initialized
INFO - 2017-04-08 19:44:00 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:44:00 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:44:00 --> Utf8 Class Initialized
INFO - 2017-04-08 19:44:00 --> URI Class Initialized
INFO - 2017-04-08 19:44:00 --> Router Class Initialized
INFO - 2017-04-08 19:44:00 --> Output Class Initialized
INFO - 2017-04-08 19:44:00 --> Security Class Initialized
DEBUG - 2017-04-08 19:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:44:00 --> Input Class Initialized
INFO - 2017-04-08 19:44:00 --> Language Class Initialized
INFO - 2017-04-08 19:44:00 --> Loader Class Initialized
INFO - 2017-04-08 19:44:00 --> Helper loaded: url_helper
INFO - 2017-04-08 19:44:00 --> Helper loaded: language_helper
INFO - 2017-04-08 19:44:00 --> Helper loaded: html_helper
INFO - 2017-04-08 19:44:00 --> Helper loaded: form_helper
INFO - 2017-04-08 19:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:44:00 --> Controller Class Initialized
INFO - 2017-04-08 19:44:00 --> Database Driver Class Initialized
INFO - 2017-04-08 19:44:00 --> Model Class Initialized
INFO - 2017-04-08 19:44:00 --> Model Class Initialized
INFO - 2017-04-08 19:44:00 --> Email Class Initialized
INFO - 2017-04-08 19:44:00 --> Form Validation Class Initialized
INFO - 2017-04-08 19:44:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:44:00 --> Final output sent to browser
DEBUG - 2017-04-08 19:44:00 --> Total execution time: 0.1096
INFO - 2017-04-08 19:44:07 --> Config Class Initialized
INFO - 2017-04-08 19:44:07 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:44:07 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:44:07 --> Utf8 Class Initialized
INFO - 2017-04-08 19:44:07 --> URI Class Initialized
INFO - 2017-04-08 19:44:07 --> Router Class Initialized
INFO - 2017-04-08 19:44:07 --> Output Class Initialized
INFO - 2017-04-08 19:44:07 --> Security Class Initialized
DEBUG - 2017-04-08 19:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:44:07 --> Input Class Initialized
INFO - 2017-04-08 19:44:07 --> Language Class Initialized
INFO - 2017-04-08 19:44:07 --> Loader Class Initialized
INFO - 2017-04-08 19:44:07 --> Helper loaded: url_helper
INFO - 2017-04-08 19:44:07 --> Helper loaded: language_helper
INFO - 2017-04-08 19:44:07 --> Helper loaded: html_helper
INFO - 2017-04-08 19:44:07 --> Helper loaded: form_helper
INFO - 2017-04-08 19:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:44:07 --> Controller Class Initialized
INFO - 2017-04-08 19:44:07 --> Database Driver Class Initialized
INFO - 2017-04-08 19:44:07 --> Model Class Initialized
INFO - 2017-04-08 19:44:07 --> Model Class Initialized
INFO - 2017-04-08 19:44:07 --> Email Class Initialized
INFO - 2017-04-08 19:44:07 --> Form Validation Class Initialized
INFO - 2017-04-08 19:44:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:44:07 --> Final output sent to browser
DEBUG - 2017-04-08 19:44:07 --> Total execution time: 0.1049
INFO - 2017-04-08 19:44:10 --> Config Class Initialized
INFO - 2017-04-08 19:44:10 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:44:10 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:44:10 --> Utf8 Class Initialized
INFO - 2017-04-08 19:44:10 --> URI Class Initialized
INFO - 2017-04-08 19:44:10 --> Router Class Initialized
INFO - 2017-04-08 19:44:10 --> Output Class Initialized
INFO - 2017-04-08 19:44:10 --> Security Class Initialized
DEBUG - 2017-04-08 19:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:44:10 --> Input Class Initialized
INFO - 2017-04-08 19:44:10 --> Language Class Initialized
INFO - 2017-04-08 19:44:10 --> Loader Class Initialized
INFO - 2017-04-08 19:44:10 --> Helper loaded: url_helper
INFO - 2017-04-08 19:44:10 --> Helper loaded: language_helper
INFO - 2017-04-08 19:44:10 --> Helper loaded: html_helper
INFO - 2017-04-08 19:44:10 --> Helper loaded: form_helper
INFO - 2017-04-08 19:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:44:10 --> Controller Class Initialized
INFO - 2017-04-08 19:44:11 --> Database Driver Class Initialized
INFO - 2017-04-08 19:44:11 --> Model Class Initialized
INFO - 2017-04-08 19:44:11 --> Model Class Initialized
INFO - 2017-04-08 19:44:11 --> Email Class Initialized
INFO - 2017-04-08 19:44:11 --> Form Validation Class Initialized
INFO - 2017-04-08 19:44:11 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:44:11 --> Final output sent to browser
DEBUG - 2017-04-08 19:44:11 --> Total execution time: 0.1036
INFO - 2017-04-08 19:44:51 --> Config Class Initialized
INFO - 2017-04-08 19:44:51 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:44:51 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:44:51 --> Utf8 Class Initialized
INFO - 2017-04-08 19:44:51 --> URI Class Initialized
INFO - 2017-04-08 19:44:51 --> Router Class Initialized
INFO - 2017-04-08 19:44:51 --> Output Class Initialized
INFO - 2017-04-08 19:44:51 --> Security Class Initialized
DEBUG - 2017-04-08 19:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:44:51 --> Input Class Initialized
INFO - 2017-04-08 19:44:51 --> Language Class Initialized
INFO - 2017-04-08 19:44:51 --> Loader Class Initialized
INFO - 2017-04-08 19:44:51 --> Helper loaded: url_helper
INFO - 2017-04-08 19:44:51 --> Helper loaded: language_helper
INFO - 2017-04-08 19:44:51 --> Helper loaded: html_helper
INFO - 2017-04-08 19:44:51 --> Helper loaded: form_helper
INFO - 2017-04-08 19:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:44:51 --> Controller Class Initialized
INFO - 2017-04-08 19:44:51 --> Database Driver Class Initialized
INFO - 2017-04-08 19:44:51 --> Model Class Initialized
INFO - 2017-04-08 19:44:51 --> Model Class Initialized
INFO - 2017-04-08 19:44:51 --> Email Class Initialized
INFO - 2017-04-08 19:44:51 --> Form Validation Class Initialized
INFO - 2017-04-08 19:44:51 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:44:51 --> Final output sent to browser
DEBUG - 2017-04-08 19:44:51 --> Total execution time: 0.1330
INFO - 2017-04-08 19:44:56 --> Config Class Initialized
INFO - 2017-04-08 19:44:56 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:44:57 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:44:57 --> Utf8 Class Initialized
INFO - 2017-04-08 19:44:57 --> URI Class Initialized
INFO - 2017-04-08 19:44:57 --> Router Class Initialized
INFO - 2017-04-08 19:44:57 --> Output Class Initialized
INFO - 2017-04-08 19:44:57 --> Security Class Initialized
DEBUG - 2017-04-08 19:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:44:57 --> Input Class Initialized
INFO - 2017-04-08 19:44:57 --> Language Class Initialized
INFO - 2017-04-08 19:44:57 --> Loader Class Initialized
INFO - 2017-04-08 19:44:57 --> Helper loaded: url_helper
INFO - 2017-04-08 19:44:57 --> Helper loaded: language_helper
INFO - 2017-04-08 19:44:57 --> Helper loaded: html_helper
INFO - 2017-04-08 19:44:57 --> Helper loaded: form_helper
INFO - 2017-04-08 19:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:44:57 --> Controller Class Initialized
INFO - 2017-04-08 19:44:57 --> Database Driver Class Initialized
INFO - 2017-04-08 19:44:57 --> Model Class Initialized
INFO - 2017-04-08 19:44:57 --> Model Class Initialized
INFO - 2017-04-08 19:44:57 --> Email Class Initialized
INFO - 2017-04-08 19:44:57 --> Form Validation Class Initialized
INFO - 2017-04-08 19:44:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:44:57 --> Final output sent to browser
DEBUG - 2017-04-08 19:44:57 --> Total execution time: 0.1064
INFO - 2017-04-08 19:44:59 --> Config Class Initialized
INFO - 2017-04-08 19:44:59 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:44:59 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:44:59 --> Utf8 Class Initialized
INFO - 2017-04-08 19:44:59 --> URI Class Initialized
INFO - 2017-04-08 19:44:59 --> Router Class Initialized
INFO - 2017-04-08 19:44:59 --> Output Class Initialized
INFO - 2017-04-08 19:44:59 --> Security Class Initialized
DEBUG - 2017-04-08 19:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:44:59 --> Input Class Initialized
INFO - 2017-04-08 19:44:59 --> Language Class Initialized
INFO - 2017-04-08 19:44:59 --> Loader Class Initialized
INFO - 2017-04-08 19:44:59 --> Helper loaded: url_helper
INFO - 2017-04-08 19:44:59 --> Helper loaded: language_helper
INFO - 2017-04-08 19:44:59 --> Helper loaded: html_helper
INFO - 2017-04-08 19:44:59 --> Helper loaded: form_helper
INFO - 2017-04-08 19:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:44:59 --> Controller Class Initialized
INFO - 2017-04-08 19:44:59 --> Database Driver Class Initialized
INFO - 2017-04-08 19:44:59 --> Model Class Initialized
INFO - 2017-04-08 19:44:59 --> Model Class Initialized
INFO - 2017-04-08 19:44:59 --> Email Class Initialized
INFO - 2017-04-08 19:44:59 --> Form Validation Class Initialized
INFO - 2017-04-08 19:44:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:44:59 --> Final output sent to browser
DEBUG - 2017-04-08 19:44:59 --> Total execution time: 0.1113
INFO - 2017-04-08 19:45:18 --> Config Class Initialized
INFO - 2017-04-08 19:45:18 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:45:18 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:45:18 --> Utf8 Class Initialized
INFO - 2017-04-08 19:45:18 --> URI Class Initialized
INFO - 2017-04-08 19:45:18 --> Router Class Initialized
INFO - 2017-04-08 19:45:18 --> Output Class Initialized
INFO - 2017-04-08 19:45:18 --> Security Class Initialized
DEBUG - 2017-04-08 19:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:45:18 --> Input Class Initialized
INFO - 2017-04-08 19:45:18 --> Language Class Initialized
INFO - 2017-04-08 19:45:18 --> Loader Class Initialized
INFO - 2017-04-08 19:45:18 --> Helper loaded: url_helper
INFO - 2017-04-08 19:45:18 --> Helper loaded: language_helper
INFO - 2017-04-08 19:45:18 --> Helper loaded: html_helper
INFO - 2017-04-08 19:45:18 --> Helper loaded: form_helper
INFO - 2017-04-08 19:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:45:18 --> Controller Class Initialized
INFO - 2017-04-08 19:45:18 --> Database Driver Class Initialized
INFO - 2017-04-08 19:45:18 --> Model Class Initialized
INFO - 2017-04-08 19:45:18 --> Model Class Initialized
INFO - 2017-04-08 19:45:18 --> Email Class Initialized
INFO - 2017-04-08 19:45:18 --> Form Validation Class Initialized
INFO - 2017-04-08 19:45:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:45:18 --> Final output sent to browser
DEBUG - 2017-04-08 19:45:18 --> Total execution time: 0.1546
INFO - 2017-04-08 19:45:28 --> Config Class Initialized
INFO - 2017-04-08 19:45:28 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:45:28 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:45:28 --> Utf8 Class Initialized
INFO - 2017-04-08 19:45:28 --> URI Class Initialized
INFO - 2017-04-08 19:45:28 --> Router Class Initialized
INFO - 2017-04-08 19:45:28 --> Output Class Initialized
INFO - 2017-04-08 19:45:28 --> Security Class Initialized
DEBUG - 2017-04-08 19:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:45:28 --> Input Class Initialized
INFO - 2017-04-08 19:45:28 --> Language Class Initialized
INFO - 2017-04-08 19:45:28 --> Loader Class Initialized
INFO - 2017-04-08 19:45:28 --> Helper loaded: url_helper
INFO - 2017-04-08 19:45:28 --> Helper loaded: language_helper
INFO - 2017-04-08 19:45:28 --> Helper loaded: html_helper
INFO - 2017-04-08 19:45:28 --> Helper loaded: form_helper
INFO - 2017-04-08 19:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:45:28 --> Controller Class Initialized
INFO - 2017-04-08 19:45:28 --> Database Driver Class Initialized
INFO - 2017-04-08 19:45:28 --> Model Class Initialized
INFO - 2017-04-08 19:45:28 --> Model Class Initialized
INFO - 2017-04-08 19:45:28 --> Email Class Initialized
INFO - 2017-04-08 19:45:28 --> Form Validation Class Initialized
INFO - 2017-04-08 19:45:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:45:28 --> Final output sent to browser
DEBUG - 2017-04-08 19:45:28 --> Total execution time: 0.1055
INFO - 2017-04-08 19:45:52 --> Config Class Initialized
INFO - 2017-04-08 19:45:52 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:45:52 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:45:52 --> Utf8 Class Initialized
INFO - 2017-04-08 19:45:52 --> URI Class Initialized
INFO - 2017-04-08 19:45:52 --> Router Class Initialized
INFO - 2017-04-08 19:45:52 --> Output Class Initialized
INFO - 2017-04-08 19:45:52 --> Security Class Initialized
DEBUG - 2017-04-08 19:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:45:52 --> Input Class Initialized
INFO - 2017-04-08 19:45:52 --> Language Class Initialized
INFO - 2017-04-08 19:45:52 --> Loader Class Initialized
INFO - 2017-04-08 19:45:52 --> Helper loaded: url_helper
INFO - 2017-04-08 19:45:52 --> Helper loaded: language_helper
INFO - 2017-04-08 19:45:52 --> Helper loaded: html_helper
INFO - 2017-04-08 19:45:52 --> Helper loaded: form_helper
INFO - 2017-04-08 19:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:45:52 --> Controller Class Initialized
INFO - 2017-04-08 19:45:52 --> Database Driver Class Initialized
INFO - 2017-04-08 19:45:52 --> Model Class Initialized
INFO - 2017-04-08 19:45:52 --> Model Class Initialized
INFO - 2017-04-08 19:45:52 --> Email Class Initialized
INFO - 2017-04-08 19:45:52 --> Form Validation Class Initialized
INFO - 2017-04-08 19:45:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:45:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:45:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:45:52 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:45:52 --> Final output sent to browser
DEBUG - 2017-04-08 19:45:52 --> Total execution time: 0.1288
INFO - 2017-04-08 19:46:00 --> Config Class Initialized
INFO - 2017-04-08 19:46:00 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:46:00 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:46:00 --> Utf8 Class Initialized
INFO - 2017-04-08 19:46:00 --> URI Class Initialized
INFO - 2017-04-08 19:46:00 --> Router Class Initialized
INFO - 2017-04-08 19:46:00 --> Output Class Initialized
INFO - 2017-04-08 19:46:00 --> Security Class Initialized
DEBUG - 2017-04-08 19:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:46:00 --> Input Class Initialized
INFO - 2017-04-08 19:46:00 --> Language Class Initialized
INFO - 2017-04-08 19:46:00 --> Loader Class Initialized
INFO - 2017-04-08 19:46:00 --> Helper loaded: url_helper
INFO - 2017-04-08 19:46:00 --> Helper loaded: language_helper
INFO - 2017-04-08 19:46:00 --> Helper loaded: html_helper
INFO - 2017-04-08 19:46:00 --> Helper loaded: form_helper
INFO - 2017-04-08 19:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:46:00 --> Controller Class Initialized
INFO - 2017-04-08 19:46:00 --> Database Driver Class Initialized
INFO - 2017-04-08 19:46:00 --> Model Class Initialized
INFO - 2017-04-08 19:46:00 --> Model Class Initialized
INFO - 2017-04-08 19:46:00 --> Email Class Initialized
INFO - 2017-04-08 19:46:00 --> Form Validation Class Initialized
INFO - 2017-04-08 19:46:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:46:00 --> Final output sent to browser
DEBUG - 2017-04-08 19:46:00 --> Total execution time: 0.1078
INFO - 2017-04-08 19:49:31 --> Config Class Initialized
INFO - 2017-04-08 19:49:31 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:49:31 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:49:31 --> Utf8 Class Initialized
INFO - 2017-04-08 19:49:31 --> URI Class Initialized
INFO - 2017-04-08 19:49:31 --> Router Class Initialized
INFO - 2017-04-08 19:49:31 --> Output Class Initialized
INFO - 2017-04-08 19:49:31 --> Security Class Initialized
DEBUG - 2017-04-08 19:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:49:31 --> Input Class Initialized
INFO - 2017-04-08 19:49:31 --> Language Class Initialized
INFO - 2017-04-08 19:49:31 --> Loader Class Initialized
INFO - 2017-04-08 19:49:31 --> Helper loaded: url_helper
INFO - 2017-04-08 19:49:31 --> Helper loaded: language_helper
INFO - 2017-04-08 19:49:31 --> Helper loaded: html_helper
INFO - 2017-04-08 19:49:31 --> Helper loaded: form_helper
INFO - 2017-04-08 19:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:49:31 --> Controller Class Initialized
INFO - 2017-04-08 19:49:31 --> Database Driver Class Initialized
INFO - 2017-04-08 19:49:31 --> Model Class Initialized
INFO - 2017-04-08 19:49:31 --> Model Class Initialized
INFO - 2017-04-08 19:49:31 --> Email Class Initialized
INFO - 2017-04-08 19:49:31 --> Form Validation Class Initialized
INFO - 2017-04-08 19:49:31 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:49:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:49:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:49:31 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:49:31 --> Final output sent to browser
DEBUG - 2017-04-08 19:49:31 --> Total execution time: 0.1184
INFO - 2017-04-08 19:49:39 --> Config Class Initialized
INFO - 2017-04-08 19:49:39 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:49:39 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:49:39 --> Utf8 Class Initialized
INFO - 2017-04-08 19:49:39 --> URI Class Initialized
INFO - 2017-04-08 19:49:39 --> Router Class Initialized
INFO - 2017-04-08 19:49:39 --> Output Class Initialized
INFO - 2017-04-08 19:49:39 --> Security Class Initialized
DEBUG - 2017-04-08 19:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:49:39 --> Input Class Initialized
INFO - 2017-04-08 19:49:39 --> Language Class Initialized
INFO - 2017-04-08 19:49:39 --> Loader Class Initialized
INFO - 2017-04-08 19:49:39 --> Helper loaded: url_helper
INFO - 2017-04-08 19:49:39 --> Helper loaded: language_helper
INFO - 2017-04-08 19:49:39 --> Helper loaded: html_helper
INFO - 2017-04-08 19:49:39 --> Helper loaded: form_helper
INFO - 2017-04-08 19:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:49:39 --> Controller Class Initialized
INFO - 2017-04-08 19:49:39 --> Database Driver Class Initialized
INFO - 2017-04-08 19:49:39 --> Model Class Initialized
INFO - 2017-04-08 19:49:39 --> Model Class Initialized
INFO - 2017-04-08 19:49:39 --> Email Class Initialized
INFO - 2017-04-08 19:49:39 --> Form Validation Class Initialized
INFO - 2017-04-08 19:49:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:49:39 --> Final output sent to browser
DEBUG - 2017-04-08 19:49:39 --> Total execution time: 0.1103
INFO - 2017-04-08 19:49:53 --> Config Class Initialized
INFO - 2017-04-08 19:49:53 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:49:53 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:49:53 --> Utf8 Class Initialized
INFO - 2017-04-08 19:49:53 --> URI Class Initialized
INFO - 2017-04-08 19:49:53 --> Router Class Initialized
INFO - 2017-04-08 19:49:53 --> Output Class Initialized
INFO - 2017-04-08 19:49:53 --> Security Class Initialized
DEBUG - 2017-04-08 19:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:49:53 --> Input Class Initialized
INFO - 2017-04-08 19:49:53 --> Language Class Initialized
INFO - 2017-04-08 19:49:53 --> Loader Class Initialized
INFO - 2017-04-08 19:49:53 --> Helper loaded: url_helper
INFO - 2017-04-08 19:49:53 --> Helper loaded: language_helper
INFO - 2017-04-08 19:49:53 --> Helper loaded: html_helper
INFO - 2017-04-08 19:49:53 --> Helper loaded: form_helper
INFO - 2017-04-08 19:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:49:53 --> Controller Class Initialized
INFO - 2017-04-08 19:49:53 --> Database Driver Class Initialized
INFO - 2017-04-08 19:49:53 --> Model Class Initialized
INFO - 2017-04-08 19:49:53 --> Model Class Initialized
INFO - 2017-04-08 19:49:53 --> Email Class Initialized
INFO - 2017-04-08 19:49:53 --> Form Validation Class Initialized
INFO - 2017-04-08 19:49:53 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:49:53 --> Final output sent to browser
DEBUG - 2017-04-08 19:49:53 --> Total execution time: 0.0964
INFO - 2017-04-08 19:51:01 --> Config Class Initialized
INFO - 2017-04-08 19:51:01 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:51:01 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:51:01 --> Utf8 Class Initialized
INFO - 2017-04-08 19:51:01 --> URI Class Initialized
INFO - 2017-04-08 19:51:01 --> Router Class Initialized
INFO - 2017-04-08 19:51:01 --> Output Class Initialized
INFO - 2017-04-08 19:51:01 --> Security Class Initialized
DEBUG - 2017-04-08 19:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:51:01 --> Input Class Initialized
INFO - 2017-04-08 19:51:01 --> Language Class Initialized
INFO - 2017-04-08 19:51:01 --> Loader Class Initialized
INFO - 2017-04-08 19:51:01 --> Helper loaded: url_helper
INFO - 2017-04-08 19:51:01 --> Helper loaded: language_helper
INFO - 2017-04-08 19:51:01 --> Helper loaded: html_helper
INFO - 2017-04-08 19:51:01 --> Helper loaded: form_helper
INFO - 2017-04-08 19:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:51:01 --> Controller Class Initialized
INFO - 2017-04-08 19:51:01 --> Database Driver Class Initialized
INFO - 2017-04-08 19:51:01 --> Model Class Initialized
INFO - 2017-04-08 19:51:01 --> Model Class Initialized
INFO - 2017-04-08 19:51:01 --> Email Class Initialized
INFO - 2017-04-08 19:51:01 --> Form Validation Class Initialized
INFO - 2017-04-08 19:51:01 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:51:01 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:51:01 --> Final output sent to browser
DEBUG - 2017-04-08 19:51:01 --> Total execution time: 0.1227
INFO - 2017-04-08 19:51:06 --> Config Class Initialized
INFO - 2017-04-08 19:51:06 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:51:06 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:51:06 --> Utf8 Class Initialized
INFO - 2017-04-08 19:51:06 --> URI Class Initialized
INFO - 2017-04-08 19:51:06 --> Router Class Initialized
INFO - 2017-04-08 19:51:06 --> Output Class Initialized
INFO - 2017-04-08 19:51:06 --> Security Class Initialized
DEBUG - 2017-04-08 19:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:51:06 --> Input Class Initialized
INFO - 2017-04-08 19:51:06 --> Language Class Initialized
INFO - 2017-04-08 19:51:06 --> Loader Class Initialized
INFO - 2017-04-08 19:51:06 --> Helper loaded: url_helper
INFO - 2017-04-08 19:51:06 --> Helper loaded: language_helper
INFO - 2017-04-08 19:51:06 --> Helper loaded: html_helper
INFO - 2017-04-08 19:51:06 --> Helper loaded: form_helper
INFO - 2017-04-08 19:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:51:06 --> Controller Class Initialized
INFO - 2017-04-08 19:51:06 --> Database Driver Class Initialized
INFO - 2017-04-08 19:51:06 --> Model Class Initialized
INFO - 2017-04-08 19:51:06 --> Model Class Initialized
INFO - 2017-04-08 19:51:06 --> Email Class Initialized
INFO - 2017-04-08 19:51:06 --> Form Validation Class Initialized
INFO - 2017-04-08 19:51:06 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:51:06 --> Final output sent to browser
DEBUG - 2017-04-08 19:51:06 --> Total execution time: 0.1117
INFO - 2017-04-08 19:52:49 --> Config Class Initialized
INFO - 2017-04-08 19:52:49 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:52:49 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:52:49 --> Utf8 Class Initialized
INFO - 2017-04-08 19:52:49 --> URI Class Initialized
INFO - 2017-04-08 19:52:49 --> Router Class Initialized
INFO - 2017-04-08 19:52:49 --> Output Class Initialized
INFO - 2017-04-08 19:52:49 --> Security Class Initialized
DEBUG - 2017-04-08 19:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:52:49 --> Input Class Initialized
INFO - 2017-04-08 19:52:49 --> Language Class Initialized
INFO - 2017-04-08 19:52:49 --> Loader Class Initialized
INFO - 2017-04-08 19:52:49 --> Helper loaded: url_helper
INFO - 2017-04-08 19:52:49 --> Helper loaded: language_helper
INFO - 2017-04-08 19:52:49 --> Helper loaded: html_helper
INFO - 2017-04-08 19:52:49 --> Helper loaded: form_helper
INFO - 2017-04-08 19:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:52:49 --> Controller Class Initialized
INFO - 2017-04-08 19:52:49 --> Database Driver Class Initialized
INFO - 2017-04-08 19:52:49 --> Model Class Initialized
INFO - 2017-04-08 19:52:49 --> Model Class Initialized
INFO - 2017-04-08 19:52:49 --> Email Class Initialized
INFO - 2017-04-08 19:52:49 --> Form Validation Class Initialized
INFO - 2017-04-08 19:52:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:52:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:52:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:52:49 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:52:49 --> Final output sent to browser
DEBUG - 2017-04-08 19:52:49 --> Total execution time: 0.1301
INFO - 2017-04-08 19:52:55 --> Config Class Initialized
INFO - 2017-04-08 19:52:55 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:52:55 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:52:55 --> Utf8 Class Initialized
INFO - 2017-04-08 19:52:55 --> URI Class Initialized
INFO - 2017-04-08 19:52:55 --> Router Class Initialized
INFO - 2017-04-08 19:52:55 --> Output Class Initialized
INFO - 2017-04-08 19:52:55 --> Security Class Initialized
DEBUG - 2017-04-08 19:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:52:55 --> Input Class Initialized
INFO - 2017-04-08 19:52:55 --> Language Class Initialized
INFO - 2017-04-08 19:52:55 --> Loader Class Initialized
INFO - 2017-04-08 19:52:55 --> Helper loaded: url_helper
INFO - 2017-04-08 19:52:55 --> Helper loaded: language_helper
INFO - 2017-04-08 19:52:55 --> Helper loaded: html_helper
INFO - 2017-04-08 19:52:55 --> Helper loaded: form_helper
INFO - 2017-04-08 19:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:52:55 --> Controller Class Initialized
INFO - 2017-04-08 19:52:55 --> Database Driver Class Initialized
INFO - 2017-04-08 19:52:55 --> Model Class Initialized
INFO - 2017-04-08 19:52:55 --> Model Class Initialized
INFO - 2017-04-08 19:52:55 --> Email Class Initialized
INFO - 2017-04-08 19:52:55 --> Form Validation Class Initialized
INFO - 2017-04-08 19:52:55 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:52:55 --> Final output sent to browser
DEBUG - 2017-04-08 19:52:55 --> Total execution time: 0.1157
INFO - 2017-04-08 19:53:41 --> Config Class Initialized
INFO - 2017-04-08 19:53:41 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:53:41 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:53:41 --> Utf8 Class Initialized
INFO - 2017-04-08 19:53:41 --> URI Class Initialized
INFO - 2017-04-08 19:53:41 --> Router Class Initialized
INFO - 2017-04-08 19:53:41 --> Output Class Initialized
INFO - 2017-04-08 19:53:41 --> Security Class Initialized
DEBUG - 2017-04-08 19:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:53:41 --> Input Class Initialized
INFO - 2017-04-08 19:53:41 --> Language Class Initialized
INFO - 2017-04-08 19:53:41 --> Loader Class Initialized
INFO - 2017-04-08 19:53:41 --> Helper loaded: url_helper
INFO - 2017-04-08 19:53:41 --> Helper loaded: language_helper
INFO - 2017-04-08 19:53:41 --> Helper loaded: html_helper
INFO - 2017-04-08 19:53:41 --> Helper loaded: form_helper
INFO - 2017-04-08 19:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:53:41 --> Controller Class Initialized
INFO - 2017-04-08 19:53:41 --> Database Driver Class Initialized
INFO - 2017-04-08 19:53:41 --> Model Class Initialized
INFO - 2017-04-08 19:53:42 --> Model Class Initialized
INFO - 2017-04-08 19:53:42 --> Email Class Initialized
INFO - 2017-04-08 19:53:42 --> Form Validation Class Initialized
INFO - 2017-04-08 19:53:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:53:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:53:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:53:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:53:42 --> Final output sent to browser
DEBUG - 2017-04-08 19:53:42 --> Total execution time: 0.1272
INFO - 2017-04-08 19:53:47 --> Config Class Initialized
INFO - 2017-04-08 19:53:47 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:53:47 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:53:47 --> Utf8 Class Initialized
INFO - 2017-04-08 19:53:47 --> URI Class Initialized
INFO - 2017-04-08 19:53:47 --> Router Class Initialized
INFO - 2017-04-08 19:53:47 --> Output Class Initialized
INFO - 2017-04-08 19:53:47 --> Security Class Initialized
DEBUG - 2017-04-08 19:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:53:47 --> Input Class Initialized
INFO - 2017-04-08 19:53:47 --> Language Class Initialized
INFO - 2017-04-08 19:53:47 --> Loader Class Initialized
INFO - 2017-04-08 19:53:47 --> Helper loaded: url_helper
INFO - 2017-04-08 19:53:47 --> Helper loaded: language_helper
INFO - 2017-04-08 19:53:47 --> Helper loaded: html_helper
INFO - 2017-04-08 19:53:47 --> Helper loaded: form_helper
INFO - 2017-04-08 19:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:53:47 --> Controller Class Initialized
INFO - 2017-04-08 19:53:47 --> Database Driver Class Initialized
INFO - 2017-04-08 19:53:47 --> Model Class Initialized
INFO - 2017-04-08 19:53:47 --> Model Class Initialized
INFO - 2017-04-08 19:53:47 --> Email Class Initialized
INFO - 2017-04-08 19:53:47 --> Form Validation Class Initialized
INFO - 2017-04-08 19:53:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:53:47 --> Final output sent to browser
DEBUG - 2017-04-08 19:53:47 --> Total execution time: 0.1119
INFO - 2017-04-08 19:53:52 --> Config Class Initialized
INFO - 2017-04-08 19:53:52 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:53:52 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:53:52 --> Utf8 Class Initialized
INFO - 2017-04-08 19:53:52 --> URI Class Initialized
INFO - 2017-04-08 19:53:52 --> Router Class Initialized
INFO - 2017-04-08 19:53:52 --> Output Class Initialized
INFO - 2017-04-08 19:53:52 --> Security Class Initialized
DEBUG - 2017-04-08 19:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:53:52 --> Input Class Initialized
INFO - 2017-04-08 19:53:52 --> Language Class Initialized
INFO - 2017-04-08 19:53:52 --> Loader Class Initialized
INFO - 2017-04-08 19:53:52 --> Helper loaded: url_helper
INFO - 2017-04-08 19:53:52 --> Helper loaded: language_helper
INFO - 2017-04-08 19:53:52 --> Helper loaded: html_helper
INFO - 2017-04-08 19:53:52 --> Helper loaded: form_helper
INFO - 2017-04-08 19:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:53:52 --> Controller Class Initialized
INFO - 2017-04-08 19:53:52 --> Database Driver Class Initialized
INFO - 2017-04-08 19:53:52 --> Model Class Initialized
INFO - 2017-04-08 19:53:52 --> Model Class Initialized
INFO - 2017-04-08 19:53:52 --> Email Class Initialized
INFO - 2017-04-08 19:53:52 --> Form Validation Class Initialized
INFO - 2017-04-08 19:53:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:53:52 --> Final output sent to browser
DEBUG - 2017-04-08 19:53:52 --> Total execution time: 0.1061
INFO - 2017-04-08 19:53:56 --> Config Class Initialized
INFO - 2017-04-08 19:53:56 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:53:57 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:53:57 --> Utf8 Class Initialized
INFO - 2017-04-08 19:53:57 --> URI Class Initialized
INFO - 2017-04-08 19:53:57 --> Router Class Initialized
INFO - 2017-04-08 19:53:57 --> Output Class Initialized
INFO - 2017-04-08 19:53:57 --> Security Class Initialized
DEBUG - 2017-04-08 19:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:53:57 --> Input Class Initialized
INFO - 2017-04-08 19:53:57 --> Language Class Initialized
INFO - 2017-04-08 19:53:57 --> Loader Class Initialized
INFO - 2017-04-08 19:53:57 --> Helper loaded: url_helper
INFO - 2017-04-08 19:53:57 --> Helper loaded: language_helper
INFO - 2017-04-08 19:53:57 --> Helper loaded: html_helper
INFO - 2017-04-08 19:53:57 --> Helper loaded: form_helper
INFO - 2017-04-08 19:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:53:57 --> Controller Class Initialized
INFO - 2017-04-08 19:53:57 --> Database Driver Class Initialized
INFO - 2017-04-08 19:53:57 --> Model Class Initialized
INFO - 2017-04-08 19:53:57 --> Model Class Initialized
INFO - 2017-04-08 19:53:57 --> Email Class Initialized
INFO - 2017-04-08 19:53:57 --> Form Validation Class Initialized
INFO - 2017-04-08 19:53:57 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:53:57 --> Final output sent to browser
DEBUG - 2017-04-08 19:53:57 --> Total execution time: 0.1085
INFO - 2017-04-08 19:54:22 --> Config Class Initialized
INFO - 2017-04-08 19:54:22 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:54:22 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:54:22 --> Utf8 Class Initialized
INFO - 2017-04-08 19:54:22 --> URI Class Initialized
INFO - 2017-04-08 19:54:22 --> Router Class Initialized
INFO - 2017-04-08 19:54:22 --> Output Class Initialized
INFO - 2017-04-08 19:54:22 --> Security Class Initialized
DEBUG - 2017-04-08 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:54:22 --> Input Class Initialized
INFO - 2017-04-08 19:54:22 --> Language Class Initialized
INFO - 2017-04-08 19:54:22 --> Loader Class Initialized
INFO - 2017-04-08 19:54:22 --> Helper loaded: url_helper
INFO - 2017-04-08 19:54:22 --> Helper loaded: language_helper
INFO - 2017-04-08 19:54:22 --> Helper loaded: html_helper
INFO - 2017-04-08 19:54:22 --> Helper loaded: form_helper
INFO - 2017-04-08 19:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:54:22 --> Controller Class Initialized
INFO - 2017-04-08 19:54:22 --> Database Driver Class Initialized
INFO - 2017-04-08 19:54:22 --> Model Class Initialized
INFO - 2017-04-08 19:54:22 --> Model Class Initialized
INFO - 2017-04-08 19:54:22 --> Email Class Initialized
INFO - 2017-04-08 19:54:22 --> Form Validation Class Initialized
INFO - 2017-04-08 19:54:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:54:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:54:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:54:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:54:22 --> Final output sent to browser
DEBUG - 2017-04-08 19:54:22 --> Total execution time: 0.1210
INFO - 2017-04-08 19:54:28 --> Config Class Initialized
INFO - 2017-04-08 19:54:28 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:54:28 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:54:28 --> Utf8 Class Initialized
INFO - 2017-04-08 19:54:28 --> URI Class Initialized
INFO - 2017-04-08 19:54:28 --> Router Class Initialized
INFO - 2017-04-08 19:54:28 --> Output Class Initialized
INFO - 2017-04-08 19:54:28 --> Security Class Initialized
DEBUG - 2017-04-08 19:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:54:28 --> Input Class Initialized
INFO - 2017-04-08 19:54:28 --> Language Class Initialized
INFO - 2017-04-08 19:54:28 --> Loader Class Initialized
INFO - 2017-04-08 19:54:28 --> Helper loaded: url_helper
INFO - 2017-04-08 19:54:28 --> Helper loaded: language_helper
INFO - 2017-04-08 19:54:28 --> Helper loaded: html_helper
INFO - 2017-04-08 19:54:28 --> Helper loaded: form_helper
INFO - 2017-04-08 19:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:54:28 --> Controller Class Initialized
INFO - 2017-04-08 19:54:28 --> Database Driver Class Initialized
INFO - 2017-04-08 19:54:28 --> Model Class Initialized
INFO - 2017-04-08 19:54:28 --> Model Class Initialized
INFO - 2017-04-08 19:54:28 --> Email Class Initialized
INFO - 2017-04-08 19:54:28 --> Form Validation Class Initialized
INFO - 2017-04-08 19:54:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:54:28 --> Final output sent to browser
DEBUG - 2017-04-08 19:54:28 --> Total execution time: 0.1179
INFO - 2017-04-08 19:54:32 --> Config Class Initialized
INFO - 2017-04-08 19:54:32 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:54:32 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:54:32 --> Utf8 Class Initialized
INFO - 2017-04-08 19:54:32 --> URI Class Initialized
INFO - 2017-04-08 19:54:32 --> Router Class Initialized
INFO - 2017-04-08 19:54:32 --> Output Class Initialized
INFO - 2017-04-08 19:54:32 --> Security Class Initialized
DEBUG - 2017-04-08 19:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:54:32 --> Input Class Initialized
INFO - 2017-04-08 19:54:32 --> Language Class Initialized
INFO - 2017-04-08 19:54:32 --> Loader Class Initialized
INFO - 2017-04-08 19:54:32 --> Helper loaded: url_helper
INFO - 2017-04-08 19:54:32 --> Helper loaded: language_helper
INFO - 2017-04-08 19:54:32 --> Helper loaded: html_helper
INFO - 2017-04-08 19:54:32 --> Helper loaded: form_helper
INFO - 2017-04-08 19:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:54:32 --> Controller Class Initialized
INFO - 2017-04-08 19:54:32 --> Database Driver Class Initialized
INFO - 2017-04-08 19:54:32 --> Model Class Initialized
INFO - 2017-04-08 19:54:32 --> Model Class Initialized
INFO - 2017-04-08 19:54:32 --> Email Class Initialized
INFO - 2017-04-08 19:54:32 --> Form Validation Class Initialized
INFO - 2017-04-08 19:54:32 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:54:32 --> Final output sent to browser
DEBUG - 2017-04-08 19:54:32 --> Total execution time: 0.1148
INFO - 2017-04-08 19:54:35 --> Config Class Initialized
INFO - 2017-04-08 19:54:35 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:54:35 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:54:35 --> Utf8 Class Initialized
INFO - 2017-04-08 19:54:35 --> URI Class Initialized
INFO - 2017-04-08 19:54:35 --> Router Class Initialized
INFO - 2017-04-08 19:54:35 --> Output Class Initialized
INFO - 2017-04-08 19:54:35 --> Security Class Initialized
DEBUG - 2017-04-08 19:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:54:35 --> Input Class Initialized
INFO - 2017-04-08 19:54:35 --> Language Class Initialized
INFO - 2017-04-08 19:54:35 --> Loader Class Initialized
INFO - 2017-04-08 19:54:35 --> Helper loaded: url_helper
INFO - 2017-04-08 19:54:35 --> Helper loaded: language_helper
INFO - 2017-04-08 19:54:35 --> Helper loaded: html_helper
INFO - 2017-04-08 19:54:35 --> Helper loaded: form_helper
INFO - 2017-04-08 19:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:54:35 --> Controller Class Initialized
INFO - 2017-04-08 19:54:35 --> Database Driver Class Initialized
INFO - 2017-04-08 19:54:35 --> Model Class Initialized
INFO - 2017-04-08 19:54:35 --> Model Class Initialized
INFO - 2017-04-08 19:54:35 --> Email Class Initialized
INFO - 2017-04-08 19:54:35 --> Form Validation Class Initialized
INFO - 2017-04-08 19:54:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:54:35 --> Final output sent to browser
DEBUG - 2017-04-08 19:54:35 --> Total execution time: 0.1128
INFO - 2017-04-08 19:54:38 --> Config Class Initialized
INFO - 2017-04-08 19:54:38 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:54:38 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:54:38 --> Utf8 Class Initialized
INFO - 2017-04-08 19:54:38 --> URI Class Initialized
INFO - 2017-04-08 19:54:38 --> Router Class Initialized
INFO - 2017-04-08 19:54:38 --> Output Class Initialized
INFO - 2017-04-08 19:54:38 --> Security Class Initialized
DEBUG - 2017-04-08 19:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:54:38 --> Input Class Initialized
INFO - 2017-04-08 19:54:38 --> Language Class Initialized
INFO - 2017-04-08 19:54:38 --> Loader Class Initialized
INFO - 2017-04-08 19:54:38 --> Helper loaded: url_helper
INFO - 2017-04-08 19:54:38 --> Helper loaded: language_helper
INFO - 2017-04-08 19:54:38 --> Helper loaded: html_helper
INFO - 2017-04-08 19:54:38 --> Helper loaded: form_helper
INFO - 2017-04-08 19:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:54:38 --> Controller Class Initialized
INFO - 2017-04-08 19:54:38 --> Database Driver Class Initialized
INFO - 2017-04-08 19:54:38 --> Model Class Initialized
INFO - 2017-04-08 19:54:38 --> Model Class Initialized
INFO - 2017-04-08 19:54:38 --> Email Class Initialized
INFO - 2017-04-08 19:54:38 --> Form Validation Class Initialized
INFO - 2017-04-08 19:54:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:54:38 --> Final output sent to browser
DEBUG - 2017-04-08 19:54:38 --> Total execution time: 0.1407
INFO - 2017-04-08 19:55:32 --> Config Class Initialized
INFO - 2017-04-08 19:55:32 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:55:32 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:55:32 --> Utf8 Class Initialized
INFO - 2017-04-08 19:55:32 --> URI Class Initialized
INFO - 2017-04-08 19:55:32 --> Router Class Initialized
INFO - 2017-04-08 19:55:32 --> Output Class Initialized
INFO - 2017-04-08 19:55:33 --> Security Class Initialized
DEBUG - 2017-04-08 19:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:55:33 --> Input Class Initialized
INFO - 2017-04-08 19:55:33 --> Language Class Initialized
INFO - 2017-04-08 19:55:33 --> Loader Class Initialized
INFO - 2017-04-08 19:55:33 --> Helper loaded: url_helper
INFO - 2017-04-08 19:55:33 --> Helper loaded: language_helper
INFO - 2017-04-08 19:55:33 --> Helper loaded: html_helper
INFO - 2017-04-08 19:55:33 --> Helper loaded: form_helper
INFO - 2017-04-08 19:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:55:33 --> Controller Class Initialized
INFO - 2017-04-08 19:55:33 --> Database Driver Class Initialized
INFO - 2017-04-08 19:55:33 --> Model Class Initialized
INFO - 2017-04-08 19:55:33 --> Model Class Initialized
INFO - 2017-04-08 19:55:33 --> Email Class Initialized
INFO - 2017-04-08 19:55:33 --> Form Validation Class Initialized
INFO - 2017-04-08 19:55:33 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:55:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:55:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:55:33 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:55:33 --> Final output sent to browser
DEBUG - 2017-04-08 19:55:33 --> Total execution time: 0.0884
INFO - 2017-04-08 19:55:40 --> Config Class Initialized
INFO - 2017-04-08 19:55:40 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:55:40 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:55:40 --> Utf8 Class Initialized
INFO - 2017-04-08 19:55:40 --> URI Class Initialized
INFO - 2017-04-08 19:55:40 --> Router Class Initialized
INFO - 2017-04-08 19:55:40 --> Output Class Initialized
INFO - 2017-04-08 19:55:40 --> Security Class Initialized
DEBUG - 2017-04-08 19:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:55:40 --> Input Class Initialized
INFO - 2017-04-08 19:55:40 --> Language Class Initialized
INFO - 2017-04-08 19:55:40 --> Loader Class Initialized
INFO - 2017-04-08 19:55:40 --> Helper loaded: url_helper
INFO - 2017-04-08 19:55:40 --> Helper loaded: language_helper
INFO - 2017-04-08 19:55:40 --> Helper loaded: html_helper
INFO - 2017-04-08 19:55:40 --> Helper loaded: form_helper
INFO - 2017-04-08 19:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:55:40 --> Controller Class Initialized
INFO - 2017-04-08 19:55:40 --> Database Driver Class Initialized
INFO - 2017-04-08 19:55:40 --> Model Class Initialized
INFO - 2017-04-08 19:55:40 --> Model Class Initialized
INFO - 2017-04-08 19:55:40 --> Email Class Initialized
INFO - 2017-04-08 19:55:40 --> Form Validation Class Initialized
INFO - 2017-04-08 19:55:40 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:55:40 --> Final output sent to browser
DEBUG - 2017-04-08 19:55:40 --> Total execution time: 0.1187
INFO - 2017-04-08 19:55:46 --> Config Class Initialized
INFO - 2017-04-08 19:55:46 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:55:46 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:55:46 --> Utf8 Class Initialized
INFO - 2017-04-08 19:55:46 --> URI Class Initialized
INFO - 2017-04-08 19:55:46 --> Router Class Initialized
INFO - 2017-04-08 19:55:46 --> Output Class Initialized
INFO - 2017-04-08 19:55:46 --> Security Class Initialized
DEBUG - 2017-04-08 19:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:55:46 --> Input Class Initialized
INFO - 2017-04-08 19:55:46 --> Language Class Initialized
INFO - 2017-04-08 19:55:46 --> Loader Class Initialized
INFO - 2017-04-08 19:55:46 --> Helper loaded: url_helper
INFO - 2017-04-08 19:55:46 --> Helper loaded: language_helper
INFO - 2017-04-08 19:55:46 --> Helper loaded: html_helper
INFO - 2017-04-08 19:55:46 --> Helper loaded: form_helper
INFO - 2017-04-08 19:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:55:46 --> Controller Class Initialized
INFO - 2017-04-08 19:55:46 --> Database Driver Class Initialized
INFO - 2017-04-08 19:55:46 --> Model Class Initialized
INFO - 2017-04-08 19:55:46 --> Model Class Initialized
INFO - 2017-04-08 19:55:46 --> Email Class Initialized
INFO - 2017-04-08 19:55:46 --> Form Validation Class Initialized
INFO - 2017-04-08 19:55:46 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:55:46 --> Final output sent to browser
DEBUG - 2017-04-08 19:55:46 --> Total execution time: 0.1013
INFO - 2017-04-08 19:55:52 --> Config Class Initialized
INFO - 2017-04-08 19:55:52 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:55:52 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:55:52 --> Utf8 Class Initialized
INFO - 2017-04-08 19:55:52 --> URI Class Initialized
INFO - 2017-04-08 19:55:52 --> Router Class Initialized
INFO - 2017-04-08 19:55:52 --> Output Class Initialized
INFO - 2017-04-08 19:55:52 --> Security Class Initialized
DEBUG - 2017-04-08 19:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:55:52 --> Input Class Initialized
INFO - 2017-04-08 19:55:52 --> Language Class Initialized
INFO - 2017-04-08 19:55:52 --> Loader Class Initialized
INFO - 2017-04-08 19:55:52 --> Helper loaded: url_helper
INFO - 2017-04-08 19:55:52 --> Helper loaded: language_helper
INFO - 2017-04-08 19:55:52 --> Helper loaded: html_helper
INFO - 2017-04-08 19:55:52 --> Helper loaded: form_helper
INFO - 2017-04-08 19:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:55:52 --> Controller Class Initialized
INFO - 2017-04-08 19:55:52 --> Database Driver Class Initialized
INFO - 2017-04-08 19:55:52 --> Model Class Initialized
INFO - 2017-04-08 19:55:52 --> Model Class Initialized
INFO - 2017-04-08 19:55:52 --> Email Class Initialized
INFO - 2017-04-08 19:55:52 --> Form Validation Class Initialized
INFO - 2017-04-08 19:55:52 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:55:52 --> Final output sent to browser
DEBUG - 2017-04-08 19:55:52 --> Total execution time: 0.1040
INFO - 2017-04-08 19:57:29 --> Config Class Initialized
INFO - 2017-04-08 19:57:29 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:57:29 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:57:29 --> Utf8 Class Initialized
INFO - 2017-04-08 19:57:29 --> URI Class Initialized
DEBUG - 2017-04-08 19:57:29 --> No URI present. Default controller set.
INFO - 2017-04-08 19:57:29 --> Router Class Initialized
INFO - 2017-04-08 19:57:29 --> Output Class Initialized
INFO - 2017-04-08 19:57:29 --> Security Class Initialized
DEBUG - 2017-04-08 19:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:57:29 --> Input Class Initialized
INFO - 2017-04-08 19:57:29 --> Language Class Initialized
INFO - 2017-04-08 19:57:29 --> Loader Class Initialized
INFO - 2017-04-08 19:57:29 --> Helper loaded: url_helper
INFO - 2017-04-08 19:57:29 --> Helper loaded: language_helper
INFO - 2017-04-08 19:57:29 --> Helper loaded: html_helper
INFO - 2017-04-08 19:57:29 --> Helper loaded: form_helper
INFO - 2017-04-08 19:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:57:29 --> Controller Class Initialized
INFO - 2017-04-08 19:57:29 --> Database Driver Class Initialized
INFO - 2017-04-08 19:57:29 --> Model Class Initialized
INFO - 2017-04-08 19:57:29 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:57:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-08 19:57:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-08 19:57:29 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-08 19:57:29 --> Final output sent to browser
DEBUG - 2017-04-08 19:57:29 --> Total execution time: 0.0911
INFO - 2017-04-08 19:57:34 --> Config Class Initialized
INFO - 2017-04-08 19:57:34 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:57:34 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:57:34 --> Utf8 Class Initialized
INFO - 2017-04-08 19:57:34 --> URI Class Initialized
INFO - 2017-04-08 19:57:34 --> Router Class Initialized
INFO - 2017-04-08 19:57:34 --> Output Class Initialized
INFO - 2017-04-08 19:57:34 --> Security Class Initialized
DEBUG - 2017-04-08 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:57:34 --> Input Class Initialized
INFO - 2017-04-08 19:57:34 --> Language Class Initialized
INFO - 2017-04-08 19:57:34 --> Loader Class Initialized
INFO - 2017-04-08 19:57:34 --> Helper loaded: url_helper
INFO - 2017-04-08 19:57:34 --> Helper loaded: language_helper
INFO - 2017-04-08 19:57:34 --> Helper loaded: html_helper
INFO - 2017-04-08 19:57:34 --> Helper loaded: form_helper
INFO - 2017-04-08 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:57:34 --> Controller Class Initialized
INFO - 2017-04-08 19:57:34 --> Database Driver Class Initialized
INFO - 2017-04-08 19:57:34 --> Model Class Initialized
INFO - 2017-04-08 19:57:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:57:34 --> Config Class Initialized
INFO - 2017-04-08 19:57:34 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:57:34 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:57:34 --> Utf8 Class Initialized
INFO - 2017-04-08 19:57:34 --> URI Class Initialized
INFO - 2017-04-08 19:57:34 --> Router Class Initialized
INFO - 2017-04-08 19:57:34 --> Output Class Initialized
INFO - 2017-04-08 19:57:34 --> Security Class Initialized
DEBUG - 2017-04-08 19:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:57:34 --> Input Class Initialized
INFO - 2017-04-08 19:57:34 --> Language Class Initialized
INFO - 2017-04-08 19:57:34 --> Loader Class Initialized
INFO - 2017-04-08 19:57:34 --> Helper loaded: url_helper
INFO - 2017-04-08 19:57:34 --> Helper loaded: language_helper
INFO - 2017-04-08 19:57:34 --> Helper loaded: html_helper
INFO - 2017-04-08 19:57:34 --> Helper loaded: form_helper
INFO - 2017-04-08 19:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:57:34 --> Controller Class Initialized
INFO - 2017-04-08 19:57:34 --> Database Driver Class Initialized
INFO - 2017-04-08 19:57:34 --> Model Class Initialized
INFO - 2017-04-08 19:57:34 --> Model Class Initialized
INFO - 2017-04-08 19:57:34 --> Model Class Initialized
INFO - 2017-04-08 19:57:34 --> Model Class Initialized
INFO - 2017-04-08 19:57:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:57:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:57:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-04-08 19:57:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:57:34 --> Final output sent to browser
DEBUG - 2017-04-08 19:57:34 --> Total execution time: 0.1010
INFO - 2017-04-08 19:58:48 --> Config Class Initialized
INFO - 2017-04-08 19:58:48 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:58:48 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:58:48 --> Utf8 Class Initialized
INFO - 2017-04-08 19:58:48 --> URI Class Initialized
INFO - 2017-04-08 19:58:48 --> Router Class Initialized
INFO - 2017-04-08 19:58:48 --> Output Class Initialized
INFO - 2017-04-08 19:58:48 --> Security Class Initialized
DEBUG - 2017-04-08 19:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:58:48 --> Input Class Initialized
INFO - 2017-04-08 19:58:48 --> Language Class Initialized
INFO - 2017-04-08 19:58:48 --> Loader Class Initialized
INFO - 2017-04-08 19:58:48 --> Helper loaded: url_helper
INFO - 2017-04-08 19:58:48 --> Helper loaded: language_helper
INFO - 2017-04-08 19:58:48 --> Helper loaded: html_helper
INFO - 2017-04-08 19:58:48 --> Helper loaded: form_helper
INFO - 2017-04-08 19:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:58:48 --> Controller Class Initialized
INFO - 2017-04-08 19:58:48 --> Database Driver Class Initialized
INFO - 2017-04-08 19:58:48 --> Model Class Initialized
INFO - 2017-04-08 19:58:48 --> Model Class Initialized
INFO - 2017-04-08 19:58:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:58:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-08 19:58:48 --> Could not find the language line "import_user"
INFO - 2017-04-08 19:58:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-04-08 19:58:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:58:48 --> Final output sent to browser
DEBUG - 2017-04-08 19:58:48 --> Total execution time: 0.0902
INFO - 2017-04-08 19:59:02 --> Config Class Initialized
INFO - 2017-04-08 19:59:02 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:59:02 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:59:02 --> Utf8 Class Initialized
INFO - 2017-04-08 19:59:02 --> URI Class Initialized
INFO - 2017-04-08 19:59:02 --> Router Class Initialized
INFO - 2017-04-08 19:59:02 --> Output Class Initialized
INFO - 2017-04-08 19:59:02 --> Security Class Initialized
DEBUG - 2017-04-08 19:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:59:02 --> Input Class Initialized
INFO - 2017-04-08 19:59:02 --> Language Class Initialized
INFO - 2017-04-08 19:59:02 --> Loader Class Initialized
INFO - 2017-04-08 19:59:02 --> Helper loaded: url_helper
INFO - 2017-04-08 19:59:02 --> Helper loaded: language_helper
INFO - 2017-04-08 19:59:02 --> Helper loaded: html_helper
INFO - 2017-04-08 19:59:02 --> Helper loaded: form_helper
INFO - 2017-04-08 19:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:59:02 --> Controller Class Initialized
INFO - 2017-04-08 19:59:02 --> Database Driver Class Initialized
INFO - 2017-04-08 19:59:02 --> Model Class Initialized
INFO - 2017-04-08 19:59:02 --> Model Class Initialized
INFO - 2017-04-08 19:59:02 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-08 19:59:02 --> Could not find the language line "import_user"
INFO - 2017-04-08 19:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-04-08 19:59:02 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:59:02 --> Final output sent to browser
DEBUG - 2017-04-08 19:59:02 --> Total execution time: 0.0952
INFO - 2017-04-08 19:59:08 --> Config Class Initialized
INFO - 2017-04-08 19:59:08 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:59:08 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:59:08 --> Utf8 Class Initialized
INFO - 2017-04-08 19:59:08 --> URI Class Initialized
INFO - 2017-04-08 19:59:08 --> Router Class Initialized
INFO - 2017-04-08 19:59:08 --> Output Class Initialized
INFO - 2017-04-08 19:59:08 --> Security Class Initialized
DEBUG - 2017-04-08 19:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:59:08 --> Input Class Initialized
INFO - 2017-04-08 19:59:08 --> Language Class Initialized
INFO - 2017-04-08 19:59:08 --> Loader Class Initialized
INFO - 2017-04-08 19:59:08 --> Helper loaded: url_helper
INFO - 2017-04-08 19:59:08 --> Helper loaded: language_helper
INFO - 2017-04-08 19:59:08 --> Helper loaded: html_helper
INFO - 2017-04-08 19:59:08 --> Helper loaded: form_helper
INFO - 2017-04-08 19:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:59:08 --> Controller Class Initialized
INFO - 2017-04-08 19:59:08 --> Database Driver Class Initialized
INFO - 2017-04-08 19:59:08 --> Model Class Initialized
INFO - 2017-04-08 19:59:08 --> Model Class Initialized
INFO - 2017-04-08 19:59:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:59:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-08 19:59:08 --> Could not find the language line "import_user"
INFO - 2017-04-08 19:59:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-04-08 19:59:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:59:08 --> Final output sent to browser
DEBUG - 2017-04-08 19:59:08 --> Total execution time: 0.0868
INFO - 2017-04-08 19:59:12 --> Config Class Initialized
INFO - 2017-04-08 19:59:12 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:59:12 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:59:12 --> Utf8 Class Initialized
INFO - 2017-04-08 19:59:12 --> URI Class Initialized
INFO - 2017-04-08 19:59:12 --> Router Class Initialized
INFO - 2017-04-08 19:59:12 --> Output Class Initialized
INFO - 2017-04-08 19:59:12 --> Security Class Initialized
DEBUG - 2017-04-08 19:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:59:12 --> Input Class Initialized
INFO - 2017-04-08 19:59:12 --> Language Class Initialized
INFO - 2017-04-08 19:59:12 --> Loader Class Initialized
INFO - 2017-04-08 19:59:12 --> Helper loaded: url_helper
INFO - 2017-04-08 19:59:12 --> Helper loaded: language_helper
INFO - 2017-04-08 19:59:12 --> Helper loaded: html_helper
INFO - 2017-04-08 19:59:12 --> Helper loaded: form_helper
INFO - 2017-04-08 19:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:59:12 --> Controller Class Initialized
INFO - 2017-04-08 19:59:12 --> Database Driver Class Initialized
INFO - 2017-04-08 19:59:12 --> Model Class Initialized
INFO - 2017-04-08 19:59:12 --> Model Class Initialized
INFO - 2017-04-08 19:59:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:59:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-08 19:59:13 --> Could not find the language line "import_user"
INFO - 2017-04-08 19:59:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-04-08 19:59:13 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:59:13 --> Final output sent to browser
DEBUG - 2017-04-08 19:59:13 --> Total execution time: 0.0932
INFO - 2017-04-08 19:59:21 --> Config Class Initialized
INFO - 2017-04-08 19:59:21 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:59:21 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:59:21 --> Utf8 Class Initialized
INFO - 2017-04-08 19:59:21 --> URI Class Initialized
INFO - 2017-04-08 19:59:21 --> Router Class Initialized
INFO - 2017-04-08 19:59:22 --> Output Class Initialized
INFO - 2017-04-08 19:59:22 --> Security Class Initialized
DEBUG - 2017-04-08 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:59:22 --> Input Class Initialized
INFO - 2017-04-08 19:59:22 --> Language Class Initialized
INFO - 2017-04-08 19:59:22 --> Loader Class Initialized
INFO - 2017-04-08 19:59:22 --> Helper loaded: url_helper
INFO - 2017-04-08 19:59:22 --> Helper loaded: language_helper
INFO - 2017-04-08 19:59:22 --> Helper loaded: html_helper
INFO - 2017-04-08 19:59:22 --> Helper loaded: form_helper
INFO - 2017-04-08 19:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:59:22 --> Controller Class Initialized
INFO - 2017-04-08 19:59:22 --> Database Driver Class Initialized
INFO - 2017-04-08 19:59:22 --> Model Class Initialized
INFO - 2017-04-08 19:59:22 --> Model Class Initialized
INFO - 2017-04-08 19:59:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:59:22 --> Config Class Initialized
INFO - 2017-04-08 19:59:22 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:59:22 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:59:22 --> Utf8 Class Initialized
INFO - 2017-04-08 19:59:22 --> URI Class Initialized
INFO - 2017-04-08 19:59:22 --> Router Class Initialized
INFO - 2017-04-08 19:59:22 --> Output Class Initialized
INFO - 2017-04-08 19:59:22 --> Security Class Initialized
DEBUG - 2017-04-08 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:59:22 --> Input Class Initialized
INFO - 2017-04-08 19:59:22 --> Language Class Initialized
INFO - 2017-04-08 19:59:22 --> Loader Class Initialized
INFO - 2017-04-08 19:59:22 --> Helper loaded: url_helper
INFO - 2017-04-08 19:59:22 --> Helper loaded: language_helper
INFO - 2017-04-08 19:59:22 --> Helper loaded: html_helper
INFO - 2017-04-08 19:59:22 --> Helper loaded: form_helper
INFO - 2017-04-08 19:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:59:22 --> Controller Class Initialized
INFO - 2017-04-08 19:59:22 --> Database Driver Class Initialized
INFO - 2017-04-08 19:59:22 --> Model Class Initialized
INFO - 2017-04-08 19:59:22 --> Model Class Initialized
INFO - 2017-04-08 19:59:22 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:59:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
ERROR - 2017-04-08 19:59:22 --> Could not find the language line "import_user"
INFO - 2017-04-08 19:59:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\user_list.php
INFO - 2017-04-08 19:59:22 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:59:22 --> Final output sent to browser
DEBUG - 2017-04-08 19:59:22 --> Total execution time: 0.0983
INFO - 2017-04-08 19:59:34 --> Config Class Initialized
INFO - 2017-04-08 19:59:34 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:59:34 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:59:34 --> Utf8 Class Initialized
INFO - 2017-04-08 19:59:34 --> URI Class Initialized
INFO - 2017-04-08 19:59:34 --> Router Class Initialized
INFO - 2017-04-08 19:59:34 --> Output Class Initialized
INFO - 2017-04-08 19:59:34 --> Security Class Initialized
DEBUG - 2017-04-08 19:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:59:34 --> Input Class Initialized
INFO - 2017-04-08 19:59:34 --> Language Class Initialized
INFO - 2017-04-08 19:59:34 --> Loader Class Initialized
INFO - 2017-04-08 19:59:34 --> Helper loaded: url_helper
INFO - 2017-04-08 19:59:34 --> Helper loaded: language_helper
INFO - 2017-04-08 19:59:34 --> Helper loaded: html_helper
INFO - 2017-04-08 19:59:34 --> Helper loaded: form_helper
INFO - 2017-04-08 19:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:59:34 --> Controller Class Initialized
INFO - 2017-04-08 19:59:35 --> Database Driver Class Initialized
INFO - 2017-04-08 19:59:35 --> Model Class Initialized
INFO - 2017-04-08 19:59:35 --> Model Class Initialized
INFO - 2017-04-08 19:59:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:59:35 --> Config Class Initialized
INFO - 2017-04-08 19:59:35 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:59:35 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:59:35 --> Utf8 Class Initialized
INFO - 2017-04-08 19:59:35 --> URI Class Initialized
INFO - 2017-04-08 19:59:35 --> Router Class Initialized
INFO - 2017-04-08 19:59:35 --> Output Class Initialized
INFO - 2017-04-08 19:59:35 --> Security Class Initialized
DEBUG - 2017-04-08 19:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:59:35 --> Input Class Initialized
INFO - 2017-04-08 19:59:35 --> Language Class Initialized
INFO - 2017-04-08 19:59:35 --> Loader Class Initialized
INFO - 2017-04-08 19:59:35 --> Helper loaded: url_helper
INFO - 2017-04-08 19:59:35 --> Helper loaded: language_helper
INFO - 2017-04-08 19:59:35 --> Helper loaded: html_helper
INFO - 2017-04-08 19:59:35 --> Helper loaded: form_helper
INFO - 2017-04-08 19:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:59:35 --> Controller Class Initialized
INFO - 2017-04-08 19:59:35 --> Database Driver Class Initialized
INFO - 2017-04-08 19:59:35 --> Model Class Initialized
INFO - 2017-04-08 19:59:35 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-08 19:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-08 19:59:35 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-08 19:59:35 --> Final output sent to browser
DEBUG - 2017-04-08 19:59:35 --> Total execution time: 0.0728
INFO - 2017-04-08 19:59:36 --> Config Class Initialized
INFO - 2017-04-08 19:59:36 --> Hooks Class Initialized
DEBUG - 2017-04-08 19:59:36 --> UTF-8 Support Enabled
INFO - 2017-04-08 19:59:36 --> Utf8 Class Initialized
INFO - 2017-04-08 19:59:36 --> URI Class Initialized
INFO - 2017-04-08 19:59:36 --> Router Class Initialized
INFO - 2017-04-08 19:59:36 --> Output Class Initialized
INFO - 2017-04-08 19:59:36 --> Security Class Initialized
DEBUG - 2017-04-08 19:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 19:59:36 --> Input Class Initialized
INFO - 2017-04-08 19:59:36 --> Language Class Initialized
INFO - 2017-04-08 19:59:36 --> Loader Class Initialized
INFO - 2017-04-08 19:59:36 --> Helper loaded: url_helper
INFO - 2017-04-08 19:59:36 --> Helper loaded: language_helper
INFO - 2017-04-08 19:59:36 --> Helper loaded: html_helper
INFO - 2017-04-08 19:59:36 --> Helper loaded: form_helper
INFO - 2017-04-08 19:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 19:59:36 --> Controller Class Initialized
INFO - 2017-04-08 19:59:36 --> Database Driver Class Initialized
INFO - 2017-04-08 19:59:36 --> Model Class Initialized
INFO - 2017-04-08 19:59:36 --> Model Class Initialized
INFO - 2017-04-08 19:59:36 --> Email Class Initialized
INFO - 2017-04-08 19:59:36 --> Form Validation Class Initialized
INFO - 2017-04-08 19:59:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 19:59:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 19:59:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 19:59:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 19:59:36 --> Final output sent to browser
DEBUG - 2017-04-08 19:59:36 --> Total execution time: 0.1116
INFO - 2017-04-08 20:00:13 --> Config Class Initialized
INFO - 2017-04-08 20:00:13 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:00:13 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:00:13 --> Utf8 Class Initialized
INFO - 2017-04-08 20:00:13 --> URI Class Initialized
INFO - 2017-04-08 20:00:13 --> Router Class Initialized
INFO - 2017-04-08 20:00:13 --> Output Class Initialized
INFO - 2017-04-08 20:00:13 --> Security Class Initialized
DEBUG - 2017-04-08 20:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:00:13 --> Input Class Initialized
INFO - 2017-04-08 20:00:13 --> Language Class Initialized
INFO - 2017-04-08 20:00:13 --> Loader Class Initialized
INFO - 2017-04-08 20:00:13 --> Helper loaded: url_helper
INFO - 2017-04-08 20:00:13 --> Helper loaded: language_helper
INFO - 2017-04-08 20:00:13 --> Helper loaded: html_helper
INFO - 2017-04-08 20:00:13 --> Helper loaded: form_helper
INFO - 2017-04-08 20:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:00:13 --> Controller Class Initialized
INFO - 2017-04-08 20:00:13 --> Database Driver Class Initialized
INFO - 2017-04-08 20:00:13 --> Model Class Initialized
INFO - 2017-04-08 20:00:13 --> Model Class Initialized
INFO - 2017-04-08 20:00:13 --> Email Class Initialized
INFO - 2017-04-08 20:00:13 --> Form Validation Class Initialized
INFO - 2017-04-08 20:00:13 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:00:13 --> Final output sent to browser
DEBUG - 2017-04-08 20:00:13 --> Total execution time: 0.0911
INFO - 2017-04-08 20:01:48 --> Config Class Initialized
INFO - 2017-04-08 20:01:48 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:01:48 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:01:48 --> Utf8 Class Initialized
INFO - 2017-04-08 20:01:48 --> URI Class Initialized
INFO - 2017-04-08 20:01:48 --> Router Class Initialized
INFO - 2017-04-08 20:01:48 --> Output Class Initialized
INFO - 2017-04-08 20:01:48 --> Security Class Initialized
DEBUG - 2017-04-08 20:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:01:48 --> Input Class Initialized
INFO - 2017-04-08 20:01:48 --> Language Class Initialized
INFO - 2017-04-08 20:01:48 --> Loader Class Initialized
INFO - 2017-04-08 20:01:48 --> Helper loaded: url_helper
INFO - 2017-04-08 20:01:48 --> Helper loaded: language_helper
INFO - 2017-04-08 20:01:48 --> Helper loaded: html_helper
INFO - 2017-04-08 20:01:48 --> Helper loaded: form_helper
INFO - 2017-04-08 20:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:01:48 --> Controller Class Initialized
INFO - 2017-04-08 20:01:48 --> Database Driver Class Initialized
INFO - 2017-04-08 20:01:48 --> Model Class Initialized
INFO - 2017-04-08 20:01:48 --> Model Class Initialized
INFO - 2017-04-08 20:01:48 --> Email Class Initialized
INFO - 2017-04-08 20:01:48 --> Form Validation Class Initialized
INFO - 2017-04-08 20:01:48 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:01:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 20:01:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 20:01:48 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 20:01:48 --> Final output sent to browser
DEBUG - 2017-04-08 20:01:48 --> Total execution time: 0.1013
INFO - 2017-04-08 20:01:58 --> Config Class Initialized
INFO - 2017-04-08 20:01:58 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:01:58 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:01:58 --> Utf8 Class Initialized
INFO - 2017-04-08 20:01:58 --> URI Class Initialized
INFO - 2017-04-08 20:01:58 --> Router Class Initialized
INFO - 2017-04-08 20:01:58 --> Output Class Initialized
INFO - 2017-04-08 20:01:58 --> Security Class Initialized
DEBUG - 2017-04-08 20:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:01:58 --> Input Class Initialized
INFO - 2017-04-08 20:01:58 --> Language Class Initialized
INFO - 2017-04-08 20:01:58 --> Loader Class Initialized
INFO - 2017-04-08 20:01:58 --> Helper loaded: url_helper
INFO - 2017-04-08 20:01:58 --> Helper loaded: language_helper
INFO - 2017-04-08 20:01:58 --> Helper loaded: html_helper
INFO - 2017-04-08 20:01:58 --> Helper loaded: form_helper
INFO - 2017-04-08 20:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:01:58 --> Controller Class Initialized
INFO - 2017-04-08 20:01:58 --> Database Driver Class Initialized
INFO - 2017-04-08 20:01:58 --> Model Class Initialized
INFO - 2017-04-08 20:01:58 --> Model Class Initialized
INFO - 2017-04-08 20:01:58 --> Email Class Initialized
INFO - 2017-04-08 20:01:58 --> Form Validation Class Initialized
INFO - 2017-04-08 20:01:58 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 20:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 20:01:58 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 20:01:58 --> Final output sent to browser
DEBUG - 2017-04-08 20:01:58 --> Total execution time: 0.1193
INFO - 2017-04-08 20:02:28 --> Config Class Initialized
INFO - 2017-04-08 20:02:28 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:02:28 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:02:28 --> Utf8 Class Initialized
INFO - 2017-04-08 20:02:28 --> URI Class Initialized
INFO - 2017-04-08 20:02:28 --> Router Class Initialized
INFO - 2017-04-08 20:02:28 --> Output Class Initialized
INFO - 2017-04-08 20:02:28 --> Security Class Initialized
DEBUG - 2017-04-08 20:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:02:28 --> Input Class Initialized
INFO - 2017-04-08 20:02:28 --> Language Class Initialized
INFO - 2017-04-08 20:02:28 --> Loader Class Initialized
INFO - 2017-04-08 20:02:28 --> Helper loaded: url_helper
INFO - 2017-04-08 20:02:28 --> Helper loaded: language_helper
INFO - 2017-04-08 20:02:28 --> Helper loaded: html_helper
INFO - 2017-04-08 20:02:28 --> Helper loaded: form_helper
INFO - 2017-04-08 20:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:02:28 --> Controller Class Initialized
INFO - 2017-04-08 20:02:28 --> Database Driver Class Initialized
INFO - 2017-04-08 20:02:28 --> Model Class Initialized
INFO - 2017-04-08 20:02:28 --> Model Class Initialized
INFO - 2017-04-08 20:02:28 --> Email Class Initialized
INFO - 2017-04-08 20:02:28 --> Form Validation Class Initialized
INFO - 2017-04-08 20:02:28 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:02:28 --> Final output sent to browser
DEBUG - 2017-04-08 20:02:28 --> Total execution time: 0.0857
INFO - 2017-04-08 20:03:24 --> Config Class Initialized
INFO - 2017-04-08 20:03:24 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:03:24 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:03:24 --> Utf8 Class Initialized
INFO - 2017-04-08 20:03:24 --> URI Class Initialized
INFO - 2017-04-08 20:03:24 --> Router Class Initialized
INFO - 2017-04-08 20:03:24 --> Output Class Initialized
INFO - 2017-04-08 20:03:24 --> Security Class Initialized
DEBUG - 2017-04-08 20:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:03:24 --> Input Class Initialized
INFO - 2017-04-08 20:03:24 --> Language Class Initialized
INFO - 2017-04-08 20:03:24 --> Loader Class Initialized
INFO - 2017-04-08 20:03:24 --> Helper loaded: url_helper
INFO - 2017-04-08 20:03:24 --> Helper loaded: language_helper
INFO - 2017-04-08 20:03:24 --> Helper loaded: html_helper
INFO - 2017-04-08 20:03:24 --> Helper loaded: form_helper
INFO - 2017-04-08 20:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:03:24 --> Controller Class Initialized
INFO - 2017-04-08 20:03:24 --> Database Driver Class Initialized
INFO - 2017-04-08 20:03:24 --> Model Class Initialized
INFO - 2017-04-08 20:03:24 --> Model Class Initialized
INFO - 2017-04-08 20:03:24 --> Email Class Initialized
INFO - 2017-04-08 20:03:24 --> Form Validation Class Initialized
INFO - 2017-04-08 20:03:24 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:03:24 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-04-08 20:03:24 --> Final output sent to browser
DEBUG - 2017-04-08 20:03:24 --> Total execution time: 0.1034
INFO - 2017-04-08 20:04:59 --> Config Class Initialized
INFO - 2017-04-08 20:04:59 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:04:59 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:04:59 --> Utf8 Class Initialized
INFO - 2017-04-08 20:04:59 --> URI Class Initialized
INFO - 2017-04-08 20:04:59 --> Router Class Initialized
INFO - 2017-04-08 20:04:59 --> Output Class Initialized
INFO - 2017-04-08 20:04:59 --> Security Class Initialized
DEBUG - 2017-04-08 20:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:04:59 --> Input Class Initialized
INFO - 2017-04-08 20:04:59 --> Language Class Initialized
INFO - 2017-04-08 20:04:59 --> Loader Class Initialized
INFO - 2017-04-08 20:04:59 --> Helper loaded: url_helper
INFO - 2017-04-08 20:04:59 --> Helper loaded: language_helper
INFO - 2017-04-08 20:04:59 --> Helper loaded: html_helper
INFO - 2017-04-08 20:04:59 --> Helper loaded: form_helper
INFO - 2017-04-08 20:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:04:59 --> Controller Class Initialized
INFO - 2017-04-08 20:04:59 --> Database Driver Class Initialized
INFO - 2017-04-08 20:04:59 --> Model Class Initialized
INFO - 2017-04-08 20:04:59 --> Model Class Initialized
INFO - 2017-04-08 20:04:59 --> Email Class Initialized
INFO - 2017-04-08 20:04:59 --> Form Validation Class Initialized
INFO - 2017-04-08 20:04:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:04:59 --> Language file loaded: language/indonesia/form_validation_lang.php
ERROR - 2017-04-08 20:05:00 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-04-08 20:05:00 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
ERROR - 2017-04-08 20:05:00 --> Severity: Warning --> fsockopen(): unable to connect to ssl://mail.kemdikbud.go.id:465 (Unknown error) C:\wamp64\www\savsoftquiz\system\libraries\Email.php 1990
INFO - 2017-04-08 20:05:00 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-04-08 20:05:12 --> Config Class Initialized
INFO - 2017-04-08 20:05:12 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:05:12 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:05:12 --> Utf8 Class Initialized
INFO - 2017-04-08 20:05:12 --> URI Class Initialized
INFO - 2017-04-08 20:05:12 --> Router Class Initialized
INFO - 2017-04-08 20:05:12 --> Output Class Initialized
INFO - 2017-04-08 20:05:12 --> Security Class Initialized
DEBUG - 2017-04-08 20:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:05:12 --> Input Class Initialized
INFO - 2017-04-08 20:05:12 --> Language Class Initialized
INFO - 2017-04-08 20:05:12 --> Loader Class Initialized
INFO - 2017-04-08 20:05:12 --> Helper loaded: url_helper
INFO - 2017-04-08 20:05:12 --> Helper loaded: language_helper
INFO - 2017-04-08 20:05:12 --> Helper loaded: html_helper
INFO - 2017-04-08 20:05:12 --> Helper loaded: form_helper
INFO - 2017-04-08 20:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:05:12 --> Controller Class Initialized
INFO - 2017-04-08 20:05:12 --> Database Driver Class Initialized
INFO - 2017-04-08 20:05:12 --> Model Class Initialized
INFO - 2017-04-08 20:05:12 --> Model Class Initialized
INFO - 2017-04-08 20:05:12 --> Email Class Initialized
INFO - 2017-04-08 20:05:12 --> Form Validation Class Initialized
INFO - 2017-04-08 20:05:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:05:12 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-04-08 20:05:12 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-04-08 20:05:13 --> Final output sent to browser
DEBUG - 2017-04-08 20:05:13 --> Total execution time: 1.3035
INFO - 2017-04-08 20:05:15 --> Config Class Initialized
INFO - 2017-04-08 20:05:15 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:05:15 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:05:15 --> Utf8 Class Initialized
INFO - 2017-04-08 20:05:15 --> URI Class Initialized
INFO - 2017-04-08 20:05:15 --> Router Class Initialized
INFO - 2017-04-08 20:05:15 --> Output Class Initialized
INFO - 2017-04-08 20:05:15 --> Security Class Initialized
DEBUG - 2017-04-08 20:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:05:15 --> Input Class Initialized
INFO - 2017-04-08 20:05:15 --> Language Class Initialized
INFO - 2017-04-08 20:05:15 --> Loader Class Initialized
INFO - 2017-04-08 20:05:15 --> Helper loaded: url_helper
INFO - 2017-04-08 20:05:15 --> Helper loaded: language_helper
INFO - 2017-04-08 20:05:15 --> Helper loaded: html_helper
INFO - 2017-04-08 20:05:15 --> Helper loaded: form_helper
INFO - 2017-04-08 20:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:05:15 --> Controller Class Initialized
INFO - 2017-04-08 20:05:15 --> Database Driver Class Initialized
INFO - 2017-04-08 20:05:15 --> Model Class Initialized
INFO - 2017-04-08 20:05:15 --> Model Class Initialized
INFO - 2017-04-08 20:05:15 --> Email Class Initialized
INFO - 2017-04-08 20:05:15 --> Form Validation Class Initialized
INFO - 2017-04-08 20:05:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:05:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 20:05:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-04-08 20:05:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 20:05:15 --> Final output sent to browser
DEBUG - 2017-04-08 20:05:15 --> Total execution time: 0.0902
INFO - 2017-04-08 20:05:16 --> Config Class Initialized
INFO - 2017-04-08 20:05:16 --> Hooks Class Initialized
DEBUG - 2017-04-08 20:05:16 --> UTF-8 Support Enabled
INFO - 2017-04-08 20:05:16 --> Utf8 Class Initialized
INFO - 2017-04-08 20:05:16 --> URI Class Initialized
DEBUG - 2017-04-08 20:05:16 --> No URI present. Default controller set.
INFO - 2017-04-08 20:05:16 --> Router Class Initialized
INFO - 2017-04-08 20:05:16 --> Output Class Initialized
INFO - 2017-04-08 20:05:16 --> Security Class Initialized
DEBUG - 2017-04-08 20:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 20:05:16 --> Input Class Initialized
INFO - 2017-04-08 20:05:16 --> Language Class Initialized
INFO - 2017-04-08 20:05:16 --> Loader Class Initialized
INFO - 2017-04-08 20:05:16 --> Helper loaded: url_helper
INFO - 2017-04-08 20:05:16 --> Helper loaded: language_helper
INFO - 2017-04-08 20:05:16 --> Helper loaded: html_helper
INFO - 2017-04-08 20:05:16 --> Helper loaded: form_helper
INFO - 2017-04-08 20:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 20:05:16 --> Controller Class Initialized
INFO - 2017-04-08 20:05:16 --> Database Driver Class Initialized
INFO - 2017-04-08 20:05:16 --> Model Class Initialized
INFO - 2017-04-08 20:05:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 20:05:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-08 20:05:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-08 20:05:16 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-08 20:05:16 --> Final output sent to browser
DEBUG - 2017-04-08 20:05:16 --> Total execution time: 0.0690
INFO - 2017-04-08 22:01:34 --> Config Class Initialized
INFO - 2017-04-08 22:01:34 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:01:34 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:01:34 --> Utf8 Class Initialized
INFO - 2017-04-08 22:01:34 --> URI Class Initialized
DEBUG - 2017-04-08 22:01:34 --> No URI present. Default controller set.
INFO - 2017-04-08 22:01:34 --> Router Class Initialized
INFO - 2017-04-08 22:01:34 --> Output Class Initialized
INFO - 2017-04-08 22:01:34 --> Security Class Initialized
DEBUG - 2017-04-08 22:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:01:34 --> Input Class Initialized
INFO - 2017-04-08 22:01:34 --> Language Class Initialized
INFO - 2017-04-08 22:01:34 --> Loader Class Initialized
INFO - 2017-04-08 22:01:34 --> Helper loaded: url_helper
INFO - 2017-04-08 22:01:34 --> Helper loaded: language_helper
INFO - 2017-04-08 22:01:34 --> Helper loaded: html_helper
INFO - 2017-04-08 22:01:34 --> Helper loaded: form_helper
INFO - 2017-04-08 22:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:01:34 --> Controller Class Initialized
INFO - 2017-04-08 22:01:34 --> Database Driver Class Initialized
INFO - 2017-04-08 22:01:34 --> Model Class Initialized
INFO - 2017-04-08 22:01:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:01:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-08 22:01:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-08 22:01:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-08 22:01:34 --> Final output sent to browser
DEBUG - 2017-04-08 22:01:34 --> Total execution time: 0.1091
INFO - 2017-04-08 22:01:38 --> Config Class Initialized
INFO - 2017-04-08 22:01:38 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:01:38 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:01:38 --> Utf8 Class Initialized
INFO - 2017-04-08 22:01:38 --> URI Class Initialized
INFO - 2017-04-08 22:01:38 --> Router Class Initialized
INFO - 2017-04-08 22:01:38 --> Output Class Initialized
INFO - 2017-04-08 22:01:38 --> Security Class Initialized
DEBUG - 2017-04-08 22:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:01:38 --> Input Class Initialized
INFO - 2017-04-08 22:01:38 --> Language Class Initialized
INFO - 2017-04-08 22:01:38 --> Loader Class Initialized
INFO - 2017-04-08 22:01:38 --> Helper loaded: url_helper
INFO - 2017-04-08 22:01:38 --> Helper loaded: language_helper
INFO - 2017-04-08 22:01:38 --> Helper loaded: html_helper
INFO - 2017-04-08 22:01:38 --> Helper loaded: form_helper
INFO - 2017-04-08 22:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:01:38 --> Controller Class Initialized
INFO - 2017-04-08 22:01:38 --> Database Driver Class Initialized
INFO - 2017-04-08 22:01:38 --> Model Class Initialized
INFO - 2017-04-08 22:01:38 --> Model Class Initialized
INFO - 2017-04-08 22:01:38 --> Email Class Initialized
INFO - 2017-04-08 22:01:38 --> Form Validation Class Initialized
INFO - 2017-04-08 22:01:38 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:01:38 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:01:38 --> Final output sent to browser
DEBUG - 2017-04-08 22:01:38 --> Total execution time: 0.1105
INFO - 2017-04-08 22:02:08 --> Config Class Initialized
INFO - 2017-04-08 22:02:08 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:02:08 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:02:08 --> Utf8 Class Initialized
INFO - 2017-04-08 22:02:08 --> URI Class Initialized
DEBUG - 2017-04-08 22:02:08 --> No URI present. Default controller set.
INFO - 2017-04-08 22:02:08 --> Router Class Initialized
INFO - 2017-04-08 22:02:08 --> Output Class Initialized
INFO - 2017-04-08 22:02:08 --> Security Class Initialized
DEBUG - 2017-04-08 22:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:02:08 --> Input Class Initialized
INFO - 2017-04-08 22:02:08 --> Language Class Initialized
INFO - 2017-04-08 22:02:08 --> Loader Class Initialized
INFO - 2017-04-08 22:02:08 --> Helper loaded: url_helper
INFO - 2017-04-08 22:02:08 --> Helper loaded: language_helper
INFO - 2017-04-08 22:02:08 --> Helper loaded: html_helper
INFO - 2017-04-08 22:02:08 --> Helper loaded: form_helper
INFO - 2017-04-08 22:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:02:08 --> Controller Class Initialized
INFO - 2017-04-08 22:02:08 --> Database Driver Class Initialized
INFO - 2017-04-08 22:02:08 --> Model Class Initialized
INFO - 2017-04-08 22:02:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:02:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-08 22:02:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-08 22:02:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-08 22:02:08 --> Final output sent to browser
DEBUG - 2017-04-08 22:02:08 --> Total execution time: 0.0783
INFO - 2017-04-08 22:04:18 --> Config Class Initialized
INFO - 2017-04-08 22:04:18 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:04:18 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:04:18 --> Utf8 Class Initialized
INFO - 2017-04-08 22:04:18 --> URI Class Initialized
INFO - 2017-04-08 22:04:18 --> Router Class Initialized
INFO - 2017-04-08 22:04:18 --> Output Class Initialized
INFO - 2017-04-08 22:04:18 --> Security Class Initialized
DEBUG - 2017-04-08 22:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:04:18 --> Input Class Initialized
INFO - 2017-04-08 22:04:18 --> Language Class Initialized
INFO - 2017-04-08 22:04:18 --> Loader Class Initialized
INFO - 2017-04-08 22:04:18 --> Helper loaded: url_helper
INFO - 2017-04-08 22:04:18 --> Helper loaded: language_helper
INFO - 2017-04-08 22:04:18 --> Helper loaded: html_helper
INFO - 2017-04-08 22:04:18 --> Helper loaded: form_helper
INFO - 2017-04-08 22:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:04:18 --> Controller Class Initialized
INFO - 2017-04-08 22:04:18 --> Database Driver Class Initialized
INFO - 2017-04-08 22:04:18 --> Model Class Initialized
INFO - 2017-04-08 22:04:18 --> Model Class Initialized
INFO - 2017-04-08 22:04:18 --> Email Class Initialized
INFO - 2017-04-08 22:04:18 --> Form Validation Class Initialized
INFO - 2017-04-08 22:04:18 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:04:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:04:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:04:18 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:04:18 --> Final output sent to browser
DEBUG - 2017-04-08 22:04:18 --> Total execution time: 0.0961
INFO - 2017-04-08 22:05:59 --> Config Class Initialized
INFO - 2017-04-08 22:05:59 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:05:59 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:05:59 --> Utf8 Class Initialized
INFO - 2017-04-08 22:05:59 --> URI Class Initialized
INFO - 2017-04-08 22:05:59 --> Router Class Initialized
INFO - 2017-04-08 22:05:59 --> Output Class Initialized
INFO - 2017-04-08 22:05:59 --> Security Class Initialized
DEBUG - 2017-04-08 22:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:05:59 --> Input Class Initialized
INFO - 2017-04-08 22:05:59 --> Language Class Initialized
INFO - 2017-04-08 22:05:59 --> Loader Class Initialized
INFO - 2017-04-08 22:05:59 --> Helper loaded: url_helper
INFO - 2017-04-08 22:05:59 --> Helper loaded: language_helper
INFO - 2017-04-08 22:05:59 --> Helper loaded: html_helper
INFO - 2017-04-08 22:05:59 --> Helper loaded: form_helper
INFO - 2017-04-08 22:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:05:59 --> Controller Class Initialized
INFO - 2017-04-08 22:05:59 --> Database Driver Class Initialized
INFO - 2017-04-08 22:05:59 --> Model Class Initialized
INFO - 2017-04-08 22:05:59 --> Model Class Initialized
INFO - 2017-04-08 22:05:59 --> Email Class Initialized
INFO - 2017-04-08 22:05:59 --> Form Validation Class Initialized
INFO - 2017-04-08 22:05:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:05:59 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:05:59 --> Final output sent to browser
DEBUG - 2017-04-08 22:05:59 --> Total execution time: 0.0901
INFO - 2017-04-08 22:07:09 --> Config Class Initialized
INFO - 2017-04-08 22:07:09 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:07:09 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:07:09 --> Utf8 Class Initialized
INFO - 2017-04-08 22:07:09 --> URI Class Initialized
INFO - 2017-04-08 22:07:09 --> Router Class Initialized
INFO - 2017-04-08 22:07:09 --> Output Class Initialized
INFO - 2017-04-08 22:07:09 --> Security Class Initialized
DEBUG - 2017-04-08 22:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:07:09 --> Input Class Initialized
INFO - 2017-04-08 22:07:09 --> Language Class Initialized
INFO - 2017-04-08 22:07:09 --> Loader Class Initialized
INFO - 2017-04-08 22:07:09 --> Helper loaded: url_helper
INFO - 2017-04-08 22:07:09 --> Helper loaded: language_helper
INFO - 2017-04-08 22:07:09 --> Helper loaded: html_helper
INFO - 2017-04-08 22:07:09 --> Helper loaded: form_helper
INFO - 2017-04-08 22:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:07:09 --> Controller Class Initialized
INFO - 2017-04-08 22:07:09 --> Database Driver Class Initialized
INFO - 2017-04-08 22:07:09 --> Model Class Initialized
INFO - 2017-04-08 22:07:09 --> Model Class Initialized
INFO - 2017-04-08 22:07:09 --> Email Class Initialized
INFO - 2017-04-08 22:07:09 --> Form Validation Class Initialized
INFO - 2017-04-08 22:07:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:07:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:07:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:07:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:07:09 --> Final output sent to browser
DEBUG - 2017-04-08 22:07:09 --> Total execution time: 0.1077
INFO - 2017-04-08 22:07:34 --> Config Class Initialized
INFO - 2017-04-08 22:07:34 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:07:34 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:07:34 --> Utf8 Class Initialized
INFO - 2017-04-08 22:07:34 --> URI Class Initialized
INFO - 2017-04-08 22:07:34 --> Router Class Initialized
INFO - 2017-04-08 22:07:34 --> Output Class Initialized
INFO - 2017-04-08 22:07:34 --> Security Class Initialized
DEBUG - 2017-04-08 22:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:07:34 --> Input Class Initialized
INFO - 2017-04-08 22:07:34 --> Language Class Initialized
INFO - 2017-04-08 22:07:34 --> Loader Class Initialized
INFO - 2017-04-08 22:07:34 --> Helper loaded: url_helper
INFO - 2017-04-08 22:07:34 --> Helper loaded: language_helper
INFO - 2017-04-08 22:07:34 --> Helper loaded: html_helper
INFO - 2017-04-08 22:07:34 --> Helper loaded: form_helper
INFO - 2017-04-08 22:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:07:34 --> Controller Class Initialized
INFO - 2017-04-08 22:07:34 --> Database Driver Class Initialized
INFO - 2017-04-08 22:07:34 --> Model Class Initialized
INFO - 2017-04-08 22:07:34 --> Model Class Initialized
INFO - 2017-04-08 22:07:34 --> Email Class Initialized
INFO - 2017-04-08 22:07:34 --> Form Validation Class Initialized
INFO - 2017-04-08 22:07:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:07:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:07:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:07:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:07:34 --> Final output sent to browser
DEBUG - 2017-04-08 22:07:34 --> Total execution time: 0.1513
INFO - 2017-04-08 22:08:08 --> Config Class Initialized
INFO - 2017-04-08 22:08:08 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:08:08 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:08:08 --> Utf8 Class Initialized
INFO - 2017-04-08 22:08:08 --> URI Class Initialized
INFO - 2017-04-08 22:08:08 --> Router Class Initialized
INFO - 2017-04-08 22:08:08 --> Output Class Initialized
INFO - 2017-04-08 22:08:08 --> Security Class Initialized
DEBUG - 2017-04-08 22:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:08:08 --> Input Class Initialized
INFO - 2017-04-08 22:08:08 --> Language Class Initialized
INFO - 2017-04-08 22:08:08 --> Loader Class Initialized
INFO - 2017-04-08 22:08:08 --> Helper loaded: url_helper
INFO - 2017-04-08 22:08:08 --> Helper loaded: language_helper
INFO - 2017-04-08 22:08:08 --> Helper loaded: html_helper
INFO - 2017-04-08 22:08:08 --> Helper loaded: form_helper
INFO - 2017-04-08 22:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:08:08 --> Controller Class Initialized
INFO - 2017-04-08 22:08:08 --> Database Driver Class Initialized
INFO - 2017-04-08 22:08:08 --> Model Class Initialized
INFO - 2017-04-08 22:08:08 --> Model Class Initialized
INFO - 2017-04-08 22:08:08 --> Email Class Initialized
INFO - 2017-04-08 22:08:08 --> Form Validation Class Initialized
INFO - 2017-04-08 22:08:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:08:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:08:08 --> Final output sent to browser
DEBUG - 2017-04-08 22:08:08 --> Total execution time: 0.0941
INFO - 2017-04-08 22:08:15 --> Config Class Initialized
INFO - 2017-04-08 22:08:15 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:08:15 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:08:15 --> Utf8 Class Initialized
INFO - 2017-04-08 22:08:15 --> URI Class Initialized
INFO - 2017-04-08 22:08:15 --> Router Class Initialized
INFO - 2017-04-08 22:08:15 --> Output Class Initialized
INFO - 2017-04-08 22:08:15 --> Security Class Initialized
DEBUG - 2017-04-08 22:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:08:15 --> Input Class Initialized
INFO - 2017-04-08 22:08:15 --> Language Class Initialized
INFO - 2017-04-08 22:08:15 --> Loader Class Initialized
INFO - 2017-04-08 22:08:15 --> Helper loaded: url_helper
INFO - 2017-04-08 22:08:15 --> Helper loaded: language_helper
INFO - 2017-04-08 22:08:15 --> Helper loaded: html_helper
INFO - 2017-04-08 22:08:15 --> Helper loaded: form_helper
INFO - 2017-04-08 22:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:08:15 --> Controller Class Initialized
INFO - 2017-04-08 22:08:15 --> Database Driver Class Initialized
INFO - 2017-04-08 22:08:15 --> Model Class Initialized
INFO - 2017-04-08 22:08:15 --> Model Class Initialized
INFO - 2017-04-08 22:08:15 --> Email Class Initialized
INFO - 2017-04-08 22:08:15 --> Form Validation Class Initialized
INFO - 2017-04-08 22:08:15 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:08:15 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:08:15 --> Final output sent to browser
DEBUG - 2017-04-08 22:08:15 --> Total execution time: 0.0871
INFO - 2017-04-08 22:09:10 --> Config Class Initialized
INFO - 2017-04-08 22:09:10 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:09:10 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:09:10 --> Utf8 Class Initialized
INFO - 2017-04-08 22:09:10 --> URI Class Initialized
INFO - 2017-04-08 22:09:10 --> Router Class Initialized
INFO - 2017-04-08 22:09:10 --> Output Class Initialized
INFO - 2017-04-08 22:09:10 --> Security Class Initialized
DEBUG - 2017-04-08 22:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:09:10 --> Input Class Initialized
INFO - 2017-04-08 22:09:10 --> Language Class Initialized
INFO - 2017-04-08 22:09:10 --> Loader Class Initialized
INFO - 2017-04-08 22:09:10 --> Helper loaded: url_helper
INFO - 2017-04-08 22:09:10 --> Helper loaded: language_helper
INFO - 2017-04-08 22:09:10 --> Helper loaded: html_helper
INFO - 2017-04-08 22:09:10 --> Helper loaded: form_helper
INFO - 2017-04-08 22:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:09:10 --> Controller Class Initialized
INFO - 2017-04-08 22:09:10 --> Database Driver Class Initialized
INFO - 2017-04-08 22:09:10 --> Model Class Initialized
INFO - 2017-04-08 22:09:10 --> Model Class Initialized
INFO - 2017-04-08 22:09:10 --> Email Class Initialized
INFO - 2017-04-08 22:09:10 --> Form Validation Class Initialized
INFO - 2017-04-08 22:09:10 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:09:10 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:09:10 --> Final output sent to browser
DEBUG - 2017-04-08 22:09:10 --> Total execution time: 0.0939
INFO - 2017-04-08 22:11:39 --> Config Class Initialized
INFO - 2017-04-08 22:11:39 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:11:39 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:11:39 --> Utf8 Class Initialized
INFO - 2017-04-08 22:11:39 --> URI Class Initialized
INFO - 2017-04-08 22:11:39 --> Router Class Initialized
INFO - 2017-04-08 22:11:39 --> Output Class Initialized
INFO - 2017-04-08 22:11:39 --> Security Class Initialized
DEBUG - 2017-04-08 22:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:11:39 --> Input Class Initialized
INFO - 2017-04-08 22:11:39 --> Language Class Initialized
INFO - 2017-04-08 22:11:39 --> Loader Class Initialized
INFO - 2017-04-08 22:11:39 --> Helper loaded: url_helper
INFO - 2017-04-08 22:11:39 --> Helper loaded: language_helper
INFO - 2017-04-08 22:11:39 --> Helper loaded: html_helper
INFO - 2017-04-08 22:11:39 --> Helper loaded: form_helper
INFO - 2017-04-08 22:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:11:39 --> Controller Class Initialized
INFO - 2017-04-08 22:11:39 --> Database Driver Class Initialized
INFO - 2017-04-08 22:11:39 --> Model Class Initialized
INFO - 2017-04-08 22:11:39 --> Model Class Initialized
INFO - 2017-04-08 22:11:39 --> Email Class Initialized
INFO - 2017-04-08 22:11:39 --> Form Validation Class Initialized
INFO - 2017-04-08 22:11:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:11:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:11:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:11:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:11:39 --> Final output sent to browser
DEBUG - 2017-04-08 22:11:39 --> Total execution time: 0.0879
INFO - 2017-04-08 22:13:12 --> Config Class Initialized
INFO - 2017-04-08 22:13:12 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:13:12 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:13:12 --> Utf8 Class Initialized
INFO - 2017-04-08 22:13:12 --> URI Class Initialized
INFO - 2017-04-08 22:13:12 --> Router Class Initialized
INFO - 2017-04-08 22:13:12 --> Output Class Initialized
INFO - 2017-04-08 22:13:12 --> Security Class Initialized
DEBUG - 2017-04-08 22:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:13:12 --> Input Class Initialized
INFO - 2017-04-08 22:13:12 --> Language Class Initialized
INFO - 2017-04-08 22:13:12 --> Loader Class Initialized
INFO - 2017-04-08 22:13:12 --> Helper loaded: url_helper
INFO - 2017-04-08 22:13:12 --> Helper loaded: language_helper
INFO - 2017-04-08 22:13:12 --> Helper loaded: html_helper
INFO - 2017-04-08 22:13:12 --> Helper loaded: form_helper
INFO - 2017-04-08 22:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:13:12 --> Controller Class Initialized
INFO - 2017-04-08 22:13:12 --> Database Driver Class Initialized
INFO - 2017-04-08 22:13:12 --> Model Class Initialized
INFO - 2017-04-08 22:13:12 --> Model Class Initialized
INFO - 2017-04-08 22:13:12 --> Email Class Initialized
INFO - 2017-04-08 22:13:12 --> Form Validation Class Initialized
INFO - 2017-04-08 22:13:12 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-08 22:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-08 22:13:12 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-08 22:13:12 --> Final output sent to browser
DEBUG - 2017-04-08 22:13:12 --> Total execution time: 0.0888
INFO - 2017-04-08 22:13:42 --> Config Class Initialized
INFO - 2017-04-08 22:13:42 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:13:42 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:13:42 --> Utf8 Class Initialized
INFO - 2017-04-08 22:13:42 --> URI Class Initialized
DEBUG - 2017-04-08 22:13:42 --> No URI present. Default controller set.
INFO - 2017-04-08 22:13:42 --> Router Class Initialized
INFO - 2017-04-08 22:13:42 --> Output Class Initialized
INFO - 2017-04-08 22:13:42 --> Security Class Initialized
DEBUG - 2017-04-08 22:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:13:42 --> Input Class Initialized
INFO - 2017-04-08 22:13:42 --> Language Class Initialized
INFO - 2017-04-08 22:13:42 --> Loader Class Initialized
INFO - 2017-04-08 22:13:42 --> Helper loaded: url_helper
INFO - 2017-04-08 22:13:42 --> Helper loaded: language_helper
INFO - 2017-04-08 22:13:42 --> Helper loaded: html_helper
INFO - 2017-04-08 22:13:42 --> Helper loaded: form_helper
INFO - 2017-04-08 22:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:13:42 --> Controller Class Initialized
INFO - 2017-04-08 22:13:42 --> Database Driver Class Initialized
INFO - 2017-04-08 22:13:42 --> Model Class Initialized
INFO - 2017-04-08 22:13:42 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:13:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-08 22:13:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-08 22:13:42 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-08 22:13:42 --> Final output sent to browser
DEBUG - 2017-04-08 22:13:42 --> Total execution time: 0.0736
INFO - 2017-04-08 22:13:44 --> Config Class Initialized
INFO - 2017-04-08 22:13:44 --> Hooks Class Initialized
DEBUG - 2017-04-08 22:13:44 --> UTF-8 Support Enabled
INFO - 2017-04-08 22:13:44 --> Utf8 Class Initialized
INFO - 2017-04-08 22:13:44 --> URI Class Initialized
DEBUG - 2017-04-08 22:13:44 --> No URI present. Default controller set.
INFO - 2017-04-08 22:13:44 --> Router Class Initialized
INFO - 2017-04-08 22:13:44 --> Output Class Initialized
INFO - 2017-04-08 22:13:44 --> Security Class Initialized
DEBUG - 2017-04-08 22:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-08 22:13:44 --> Input Class Initialized
INFO - 2017-04-08 22:13:44 --> Language Class Initialized
INFO - 2017-04-08 22:13:44 --> Loader Class Initialized
INFO - 2017-04-08 22:13:44 --> Helper loaded: url_helper
INFO - 2017-04-08 22:13:44 --> Helper loaded: language_helper
INFO - 2017-04-08 22:13:44 --> Helper loaded: html_helper
INFO - 2017-04-08 22:13:44 --> Helper loaded: form_helper
INFO - 2017-04-08 22:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-08 22:13:44 --> Controller Class Initialized
INFO - 2017-04-08 22:13:44 --> Database Driver Class Initialized
INFO - 2017-04-08 22:13:44 --> Model Class Initialized
INFO - 2017-04-08 22:13:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-08 22:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-08 22:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-08 22:13:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-08 22:13:44 --> Final output sent to browser
DEBUG - 2017-04-08 22:13:44 --> Total execution time: 0.0746
