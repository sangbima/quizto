<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-10 11:24:03 --> Config Class Initialized
INFO - 2017-04-10 11:24:03 --> Hooks Class Initialized
DEBUG - 2017-04-10 11:24:03 --> UTF-8 Support Enabled
INFO - 2017-04-10 11:24:03 --> Utf8 Class Initialized
INFO - 2017-04-10 11:24:03 --> URI Class Initialized
INFO - 2017-04-10 11:24:03 --> Router Class Initialized
INFO - 2017-04-10 11:24:03 --> Output Class Initialized
INFO - 2017-04-10 11:24:03 --> Security Class Initialized
DEBUG - 2017-04-10 11:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 11:24:03 --> Input Class Initialized
INFO - 2017-04-10 11:24:03 --> Language Class Initialized
INFO - 2017-04-10 11:24:03 --> Loader Class Initialized
INFO - 2017-04-10 11:24:03 --> Helper loaded: url_helper
INFO - 2017-04-10 11:24:03 --> Helper loaded: language_helper
INFO - 2017-04-10 11:24:03 --> Helper loaded: html_helper
INFO - 2017-04-10 11:24:03 --> Helper loaded: form_helper
INFO - 2017-04-10 11:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 11:24:03 --> Controller Class Initialized
INFO - 2017-04-10 11:24:03 --> Database Driver Class Initialized
INFO - 2017-04-10 11:24:03 --> Model Class Initialized
INFO - 2017-04-10 11:24:03 --> Model Class Initialized
INFO - 2017-04-10 11:24:03 --> Email Class Initialized
INFO - 2017-04-10 11:24:03 --> Form Validation Class Initialized
INFO - 2017-04-10 11:24:03 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 11:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-10 11:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-10 11:24:03 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-10 11:24:03 --> Final output sent to browser
DEBUG - 2017-04-10 11:24:03 --> Total execution time: 0.1219
INFO - 2017-04-10 11:25:15 --> Config Class Initialized
INFO - 2017-04-10 11:25:15 --> Hooks Class Initialized
DEBUG - 2017-04-10 11:25:15 --> UTF-8 Support Enabled
INFO - 2017-04-10 11:25:15 --> Utf8 Class Initialized
INFO - 2017-04-10 11:25:15 --> URI Class Initialized
INFO - 2017-04-10 11:25:15 --> Router Class Initialized
INFO - 2017-04-10 11:25:15 --> Output Class Initialized
INFO - 2017-04-10 11:25:15 --> Security Class Initialized
DEBUG - 2017-04-10 11:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 11:25:15 --> Input Class Initialized
INFO - 2017-04-10 11:25:15 --> Language Class Initialized
INFO - 2017-04-10 11:25:15 --> Loader Class Initialized
INFO - 2017-04-10 11:25:15 --> Helper loaded: url_helper
INFO - 2017-04-10 11:25:15 --> Helper loaded: language_helper
INFO - 2017-04-10 11:25:15 --> Helper loaded: html_helper
INFO - 2017-04-10 11:25:16 --> Helper loaded: form_helper
INFO - 2017-04-10 11:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 11:25:16 --> Controller Class Initialized
INFO - 2017-04-10 11:25:16 --> Database Driver Class Initialized
INFO - 2017-04-10 11:25:16 --> Model Class Initialized
INFO - 2017-04-10 11:25:16 --> Model Class Initialized
INFO - 2017-04-10 11:25:16 --> Email Class Initialized
INFO - 2017-04-10 11:25:16 --> Form Validation Class Initialized
INFO - 2017-04-10 11:25:16 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 11:25:16 --> Final output sent to browser
DEBUG - 2017-04-10 11:25:16 --> Total execution time: 0.0762
INFO - 2017-04-10 11:25:59 --> Config Class Initialized
INFO - 2017-04-10 11:25:59 --> Hooks Class Initialized
DEBUG - 2017-04-10 11:25:59 --> UTF-8 Support Enabled
INFO - 2017-04-10 11:25:59 --> Utf8 Class Initialized
INFO - 2017-04-10 11:25:59 --> URI Class Initialized
INFO - 2017-04-10 11:25:59 --> Router Class Initialized
INFO - 2017-04-10 11:25:59 --> Output Class Initialized
INFO - 2017-04-10 11:25:59 --> Security Class Initialized
DEBUG - 2017-04-10 11:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 11:25:59 --> Input Class Initialized
INFO - 2017-04-10 11:25:59 --> Language Class Initialized
INFO - 2017-04-10 11:25:59 --> Loader Class Initialized
INFO - 2017-04-10 11:25:59 --> Helper loaded: url_helper
INFO - 2017-04-10 11:25:59 --> Helper loaded: language_helper
INFO - 2017-04-10 11:25:59 --> Helper loaded: html_helper
INFO - 2017-04-10 11:25:59 --> Helper loaded: form_helper
INFO - 2017-04-10 11:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 11:25:59 --> Controller Class Initialized
INFO - 2017-04-10 11:25:59 --> Database Driver Class Initialized
INFO - 2017-04-10 11:25:59 --> Model Class Initialized
INFO - 2017-04-10 11:25:59 --> Model Class Initialized
INFO - 2017-04-10 11:25:59 --> Email Class Initialized
INFO - 2017-04-10 11:25:59 --> Form Validation Class Initialized
INFO - 2017-04-10 11:25:59 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 11:25:59 --> Language file loaded: language/indonesia/form_validation_lang.php
INFO - 2017-04-10 11:26:01 --> Language file loaded: language/indonesia/email_lang.php
INFO - 2017-04-10 11:26:02 --> Final output sent to browser
DEBUG - 2017-04-10 11:26:02 --> Total execution time: 3.1001
INFO - 2017-04-10 11:26:04 --> Config Class Initialized
INFO - 2017-04-10 11:26:04 --> Hooks Class Initialized
DEBUG - 2017-04-10 11:26:04 --> UTF-8 Support Enabled
INFO - 2017-04-10 11:26:04 --> Utf8 Class Initialized
INFO - 2017-04-10 11:26:04 --> URI Class Initialized
INFO - 2017-04-10 11:26:04 --> Router Class Initialized
INFO - 2017-04-10 11:26:04 --> Output Class Initialized
INFO - 2017-04-10 11:26:04 --> Security Class Initialized
DEBUG - 2017-04-10 11:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 11:26:04 --> Input Class Initialized
INFO - 2017-04-10 11:26:04 --> Language Class Initialized
INFO - 2017-04-10 11:26:04 --> Loader Class Initialized
INFO - 2017-04-10 11:26:04 --> Helper loaded: url_helper
INFO - 2017-04-10 11:26:04 --> Helper loaded: language_helper
INFO - 2017-04-10 11:26:04 --> Helper loaded: html_helper
INFO - 2017-04-10 11:26:04 --> Helper loaded: form_helper
INFO - 2017-04-10 11:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 11:26:04 --> Controller Class Initialized
INFO - 2017-04-10 11:26:04 --> Database Driver Class Initialized
INFO - 2017-04-10 11:26:04 --> Model Class Initialized
INFO - 2017-04-10 11:26:04 --> Model Class Initialized
INFO - 2017-04-10 11:26:04 --> Email Class Initialized
INFO - 2017-04-10 11:26:04 --> Form Validation Class Initialized
INFO - 2017-04-10 11:26:04 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 11:26:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-10 11:26:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_success.php
INFO - 2017-04-10 11:26:04 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-10 11:26:04 --> Final output sent to browser
DEBUG - 2017-04-10 11:26:04 --> Total execution time: 0.0938
INFO - 2017-04-10 11:26:08 --> Config Class Initialized
INFO - 2017-04-10 11:26:08 --> Hooks Class Initialized
DEBUG - 2017-04-10 11:26:08 --> UTF-8 Support Enabled
INFO - 2017-04-10 11:26:08 --> Utf8 Class Initialized
INFO - 2017-04-10 11:26:08 --> URI Class Initialized
DEBUG - 2017-04-10 11:26:08 --> No URI present. Default controller set.
INFO - 2017-04-10 11:26:08 --> Router Class Initialized
INFO - 2017-04-10 11:26:08 --> Output Class Initialized
INFO - 2017-04-10 11:26:08 --> Security Class Initialized
DEBUG - 2017-04-10 11:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 11:26:08 --> Input Class Initialized
INFO - 2017-04-10 11:26:08 --> Language Class Initialized
INFO - 2017-04-10 11:26:08 --> Loader Class Initialized
INFO - 2017-04-10 11:26:08 --> Helper loaded: url_helper
INFO - 2017-04-10 11:26:08 --> Helper loaded: language_helper
INFO - 2017-04-10 11:26:08 --> Helper loaded: html_helper
INFO - 2017-04-10 11:26:08 --> Helper loaded: form_helper
INFO - 2017-04-10 11:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 11:26:08 --> Controller Class Initialized
INFO - 2017-04-10 11:26:08 --> Database Driver Class Initialized
INFO - 2017-04-10 11:26:08 --> Model Class Initialized
INFO - 2017-04-10 11:26:08 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 11:26:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-10 11:26:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-10 11:26:08 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-10 11:26:08 --> Final output sent to browser
DEBUG - 2017-04-10 11:26:08 --> Total execution time: 0.0757
INFO - 2017-04-10 11:33:14 --> Config Class Initialized
INFO - 2017-04-10 11:33:14 --> Hooks Class Initialized
DEBUG - 2017-04-10 11:33:14 --> UTF-8 Support Enabled
INFO - 2017-04-10 11:33:14 --> Utf8 Class Initialized
INFO - 2017-04-10 11:33:14 --> URI Class Initialized
INFO - 2017-04-10 11:33:14 --> Router Class Initialized
INFO - 2017-04-10 11:33:14 --> Output Class Initialized
INFO - 2017-04-10 11:33:14 --> Security Class Initialized
DEBUG - 2017-04-10 11:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 11:33:14 --> Input Class Initialized
INFO - 2017-04-10 11:33:14 --> Language Class Initialized
INFO - 2017-04-10 11:33:14 --> Loader Class Initialized
INFO - 2017-04-10 11:33:14 --> Helper loaded: url_helper
INFO - 2017-04-10 11:33:14 --> Helper loaded: language_helper
INFO - 2017-04-10 11:33:14 --> Helper loaded: html_helper
INFO - 2017-04-10 11:33:14 --> Helper loaded: form_helper
INFO - 2017-04-10 11:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 11:33:14 --> Controller Class Initialized
INFO - 2017-04-10 11:33:14 --> Database Driver Class Initialized
INFO - 2017-04-10 11:33:14 --> Model Class Initialized
INFO - 2017-04-10 11:33:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 11:33:14 --> Config Class Initialized
INFO - 2017-04-10 11:33:14 --> Hooks Class Initialized
DEBUG - 2017-04-10 11:33:14 --> UTF-8 Support Enabled
INFO - 2017-04-10 11:33:14 --> Utf8 Class Initialized
INFO - 2017-04-10 11:33:14 --> URI Class Initialized
INFO - 2017-04-10 11:33:14 --> Router Class Initialized
INFO - 2017-04-10 11:33:14 --> Output Class Initialized
INFO - 2017-04-10 11:33:14 --> Security Class Initialized
DEBUG - 2017-04-10 11:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 11:33:14 --> Input Class Initialized
INFO - 2017-04-10 11:33:14 --> Language Class Initialized
INFO - 2017-04-10 11:33:14 --> Loader Class Initialized
INFO - 2017-04-10 11:33:14 --> Helper loaded: url_helper
INFO - 2017-04-10 11:33:14 --> Helper loaded: language_helper
INFO - 2017-04-10 11:33:14 --> Helper loaded: html_helper
INFO - 2017-04-10 11:33:14 --> Helper loaded: form_helper
INFO - 2017-04-10 11:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 11:33:14 --> Controller Class Initialized
INFO - 2017-04-10 11:33:14 --> Database Driver Class Initialized
INFO - 2017-04-10 11:33:14 --> Model Class Initialized
INFO - 2017-04-10 11:33:14 --> Model Class Initialized
INFO - 2017-04-10 11:33:14 --> Model Class Initialized
INFO - 2017-04-10 11:33:14 --> Model Class Initialized
INFO - 2017-04-10 11:33:14 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 11:33:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-10 11:33:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-04-10 11:33:14 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-10 11:33:14 --> Final output sent to browser
DEBUG - 2017-04-10 11:33:14 --> Total execution time: 0.1013
INFO - 2017-04-10 13:13:06 --> Config Class Initialized
INFO - 2017-04-10 13:13:06 --> Hooks Class Initialized
DEBUG - 2017-04-10 13:13:06 --> UTF-8 Support Enabled
INFO - 2017-04-10 13:13:06 --> Utf8 Class Initialized
INFO - 2017-04-10 13:13:06 --> URI Class Initialized
INFO - 2017-04-10 13:13:07 --> Router Class Initialized
INFO - 2017-04-10 13:13:07 --> Output Class Initialized
INFO - 2017-04-10 13:13:07 --> Security Class Initialized
DEBUG - 2017-04-10 13:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 13:13:07 --> Input Class Initialized
INFO - 2017-04-10 13:13:07 --> Language Class Initialized
INFO - 2017-04-10 13:13:07 --> Loader Class Initialized
INFO - 2017-04-10 13:13:07 --> Helper loaded: url_helper
INFO - 2017-04-10 13:13:07 --> Helper loaded: language_helper
INFO - 2017-04-10 13:13:07 --> Helper loaded: html_helper
INFO - 2017-04-10 13:13:07 --> Helper loaded: form_helper
INFO - 2017-04-10 13:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 13:13:07 --> Controller Class Initialized
INFO - 2017-04-10 13:13:07 --> Database Driver Class Initialized
INFO - 2017-04-10 13:13:07 --> Model Class Initialized
INFO - 2017-04-10 13:13:07 --> Model Class Initialized
INFO - 2017-04-10 13:13:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 13:13:07 --> Config Class Initialized
INFO - 2017-04-10 13:13:07 --> Hooks Class Initialized
DEBUG - 2017-04-10 13:13:07 --> UTF-8 Support Enabled
INFO - 2017-04-10 13:13:07 --> Utf8 Class Initialized
INFO - 2017-04-10 13:13:07 --> URI Class Initialized
INFO - 2017-04-10 13:13:07 --> Router Class Initialized
INFO - 2017-04-10 13:13:07 --> Output Class Initialized
INFO - 2017-04-10 13:13:07 --> Security Class Initialized
DEBUG - 2017-04-10 13:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 13:13:07 --> Input Class Initialized
INFO - 2017-04-10 13:13:07 --> Language Class Initialized
INFO - 2017-04-10 13:13:07 --> Loader Class Initialized
INFO - 2017-04-10 13:13:07 --> Helper loaded: url_helper
INFO - 2017-04-10 13:13:07 --> Helper loaded: language_helper
INFO - 2017-04-10 13:13:07 --> Helper loaded: html_helper
INFO - 2017-04-10 13:13:07 --> Helper loaded: form_helper
INFO - 2017-04-10 13:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 13:13:07 --> Controller Class Initialized
INFO - 2017-04-10 13:13:07 --> Database Driver Class Initialized
INFO - 2017-04-10 13:13:07 --> Model Class Initialized
INFO - 2017-04-10 13:13:07 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 13:13:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-10 13:13:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-10 13:13:07 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-10 13:13:07 --> Final output sent to browser
DEBUG - 2017-04-10 13:13:07 --> Total execution time: 0.0742
INFO - 2017-04-10 13:13:08 --> Config Class Initialized
INFO - 2017-04-10 13:13:08 --> Hooks Class Initialized
DEBUG - 2017-04-10 13:13:08 --> UTF-8 Support Enabled
INFO - 2017-04-10 13:13:08 --> Utf8 Class Initialized
INFO - 2017-04-10 13:13:08 --> URI Class Initialized
INFO - 2017-04-10 13:13:08 --> Router Class Initialized
INFO - 2017-04-10 13:13:08 --> Output Class Initialized
INFO - 2017-04-10 13:13:08 --> Security Class Initialized
DEBUG - 2017-04-10 13:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 13:13:08 --> Input Class Initialized
INFO - 2017-04-10 13:13:08 --> Language Class Initialized
INFO - 2017-04-10 13:13:08 --> Loader Class Initialized
INFO - 2017-04-10 13:13:08 --> Helper loaded: url_helper
INFO - 2017-04-10 13:13:08 --> Helper loaded: language_helper
INFO - 2017-04-10 13:13:08 --> Helper loaded: html_helper
INFO - 2017-04-10 13:13:08 --> Helper loaded: form_helper
INFO - 2017-04-10 13:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 13:13:08 --> Controller Class Initialized
INFO - 2017-04-10 13:13:09 --> Database Driver Class Initialized
INFO - 2017-04-10 13:13:09 --> Model Class Initialized
INFO - 2017-04-10 13:13:09 --> Model Class Initialized
INFO - 2017-04-10 13:13:09 --> Email Class Initialized
INFO - 2017-04-10 13:13:09 --> Form Validation Class Initialized
INFO - 2017-04-10 13:13:09 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 13:13:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-10 13:13:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-10 13:13:09 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-10 13:13:09 --> Final output sent to browser
DEBUG - 2017-04-10 13:13:09 --> Total execution time: 0.1426
INFO - 2017-04-10 15:47:34 --> Config Class Initialized
INFO - 2017-04-10 15:47:34 --> Hooks Class Initialized
DEBUG - 2017-04-10 15:47:34 --> UTF-8 Support Enabled
INFO - 2017-04-10 15:47:34 --> Utf8 Class Initialized
INFO - 2017-04-10 15:47:34 --> URI Class Initialized
DEBUG - 2017-04-10 15:47:34 --> No URI present. Default controller set.
INFO - 2017-04-10 15:47:34 --> Router Class Initialized
INFO - 2017-04-10 15:47:34 --> Output Class Initialized
INFO - 2017-04-10 15:47:34 --> Security Class Initialized
DEBUG - 2017-04-10 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 15:47:34 --> Input Class Initialized
INFO - 2017-04-10 15:47:34 --> Language Class Initialized
INFO - 2017-04-10 15:47:34 --> Loader Class Initialized
INFO - 2017-04-10 15:47:34 --> Helper loaded: url_helper
INFO - 2017-04-10 15:47:34 --> Helper loaded: language_helper
INFO - 2017-04-10 15:47:34 --> Helper loaded: html_helper
INFO - 2017-04-10 15:47:34 --> Helper loaded: form_helper
INFO - 2017-04-10 15:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 15:47:34 --> Controller Class Initialized
INFO - 2017-04-10 15:47:34 --> Database Driver Class Initialized
INFO - 2017-04-10 15:47:34 --> Model Class Initialized
INFO - 2017-04-10 15:47:34 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 15:47:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-10 15:47:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-10 15:47:34 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-10 15:47:34 --> Final output sent to browser
DEBUG - 2017-04-10 15:47:34 --> Total execution time: 0.1196
INFO - 2017-04-10 15:47:36 --> Config Class Initialized
INFO - 2017-04-10 15:47:36 --> Hooks Class Initialized
DEBUG - 2017-04-10 15:47:36 --> UTF-8 Support Enabled
INFO - 2017-04-10 15:47:36 --> Utf8 Class Initialized
INFO - 2017-04-10 15:47:36 --> URI Class Initialized
INFO - 2017-04-10 15:47:36 --> Router Class Initialized
INFO - 2017-04-10 15:47:36 --> Output Class Initialized
INFO - 2017-04-10 15:47:36 --> Security Class Initialized
DEBUG - 2017-04-10 15:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 15:47:36 --> Input Class Initialized
INFO - 2017-04-10 15:47:36 --> Language Class Initialized
INFO - 2017-04-10 15:47:36 --> Loader Class Initialized
INFO - 2017-04-10 15:47:36 --> Helper loaded: url_helper
INFO - 2017-04-10 15:47:36 --> Helper loaded: language_helper
INFO - 2017-04-10 15:47:36 --> Helper loaded: html_helper
INFO - 2017-04-10 15:47:36 --> Helper loaded: form_helper
INFO - 2017-04-10 15:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 15:47:36 --> Controller Class Initialized
INFO - 2017-04-10 15:47:36 --> Database Driver Class Initialized
INFO - 2017-04-10 15:47:36 --> Model Class Initialized
INFO - 2017-04-10 15:47:36 --> Model Class Initialized
INFO - 2017-04-10 15:47:36 --> Email Class Initialized
INFO - 2017-04-10 15:47:36 --> Form Validation Class Initialized
INFO - 2017-04-10 15:47:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 15:47:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-10 15:47:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-10 15:47:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-10 15:47:36 --> Final output sent to browser
DEBUG - 2017-04-10 15:47:36 --> Total execution time: 0.1326
INFO - 2017-04-10 16:06:36 --> Config Class Initialized
INFO - 2017-04-10 16:06:36 --> Hooks Class Initialized
DEBUG - 2017-04-10 16:06:36 --> UTF-8 Support Enabled
INFO - 2017-04-10 16:06:36 --> Utf8 Class Initialized
INFO - 2017-04-10 16:06:36 --> URI Class Initialized
INFO - 2017-04-10 16:06:36 --> Router Class Initialized
INFO - 2017-04-10 16:06:36 --> Output Class Initialized
INFO - 2017-04-10 16:06:36 --> Security Class Initialized
DEBUG - 2017-04-10 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-10 16:06:36 --> Input Class Initialized
INFO - 2017-04-10 16:06:36 --> Language Class Initialized
INFO - 2017-04-10 16:06:36 --> Loader Class Initialized
INFO - 2017-04-10 16:06:36 --> Helper loaded: url_helper
INFO - 2017-04-10 16:06:36 --> Helper loaded: language_helper
INFO - 2017-04-10 16:06:36 --> Helper loaded: html_helper
INFO - 2017-04-10 16:06:36 --> Helper loaded: form_helper
INFO - 2017-04-10 16:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-10 16:06:36 --> Controller Class Initialized
INFO - 2017-04-10 16:06:36 --> Database Driver Class Initialized
INFO - 2017-04-10 16:06:36 --> Model Class Initialized
INFO - 2017-04-10 16:06:36 --> Model Class Initialized
INFO - 2017-04-10 16:06:36 --> Email Class Initialized
INFO - 2017-04-10 16:06:36 --> Form Validation Class Initialized
INFO - 2017-04-10 16:06:36 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-10 16:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-10 16:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\register_new.php
INFO - 2017-04-10 16:06:36 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-10 16:06:36 --> Final output sent to browser
DEBUG - 2017-04-10 16:06:36 --> Total execution time: 0.1058
