<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-04-11 10:06:39 --> Config Class Initialized
INFO - 2017-04-11 10:06:39 --> Hooks Class Initialized
DEBUG - 2017-04-11 10:06:39 --> UTF-8 Support Enabled
INFO - 2017-04-11 10:06:39 --> Utf8 Class Initialized
INFO - 2017-04-11 10:06:39 --> URI Class Initialized
DEBUG - 2017-04-11 10:06:39 --> No URI present. Default controller set.
INFO - 2017-04-11 10:06:39 --> Router Class Initialized
INFO - 2017-04-11 10:06:39 --> Output Class Initialized
INFO - 2017-04-11 10:06:39 --> Security Class Initialized
DEBUG - 2017-04-11 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-11 10:06:39 --> Input Class Initialized
INFO - 2017-04-11 10:06:39 --> Language Class Initialized
INFO - 2017-04-11 10:06:39 --> Loader Class Initialized
INFO - 2017-04-11 10:06:39 --> Helper loaded: url_helper
INFO - 2017-04-11 10:06:39 --> Helper loaded: language_helper
INFO - 2017-04-11 10:06:39 --> Helper loaded: html_helper
INFO - 2017-04-11 10:06:39 --> Helper loaded: form_helper
INFO - 2017-04-11 10:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-11 10:06:39 --> Controller Class Initialized
INFO - 2017-04-11 10:06:39 --> Database Driver Class Initialized
INFO - 2017-04-11 10:06:39 --> Model Class Initialized
INFO - 2017-04-11 10:06:39 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-11 10:06:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-11 10:06:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-11 10:06:39 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-11 10:06:39 --> Final output sent to browser
DEBUG - 2017-04-11 10:06:39 --> Total execution time: 0.1229
INFO - 2017-04-11 10:06:44 --> Config Class Initialized
INFO - 2017-04-11 10:06:44 --> Hooks Class Initialized
DEBUG - 2017-04-11 10:06:44 --> UTF-8 Support Enabled
INFO - 2017-04-11 10:06:44 --> Utf8 Class Initialized
INFO - 2017-04-11 10:06:44 --> URI Class Initialized
INFO - 2017-04-11 10:06:44 --> Router Class Initialized
INFO - 2017-04-11 10:06:44 --> Output Class Initialized
INFO - 2017-04-11 10:06:44 --> Security Class Initialized
DEBUG - 2017-04-11 10:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-11 10:06:44 --> Input Class Initialized
INFO - 2017-04-11 10:06:44 --> Language Class Initialized
INFO - 2017-04-11 10:06:44 --> Loader Class Initialized
INFO - 2017-04-11 10:06:44 --> Helper loaded: url_helper
INFO - 2017-04-11 10:06:44 --> Helper loaded: language_helper
INFO - 2017-04-11 10:06:44 --> Helper loaded: html_helper
INFO - 2017-04-11 10:06:44 --> Helper loaded: form_helper
INFO - 2017-04-11 10:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-11 10:06:44 --> Controller Class Initialized
INFO - 2017-04-11 10:06:44 --> Database Driver Class Initialized
INFO - 2017-04-11 10:06:44 --> Model Class Initialized
INFO - 2017-04-11 10:06:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-11 10:06:44 --> Config Class Initialized
INFO - 2017-04-11 10:06:44 --> Hooks Class Initialized
DEBUG - 2017-04-11 10:06:44 --> UTF-8 Support Enabled
INFO - 2017-04-11 10:06:44 --> Utf8 Class Initialized
INFO - 2017-04-11 10:06:44 --> URI Class Initialized
INFO - 2017-04-11 10:06:44 --> Router Class Initialized
INFO - 2017-04-11 10:06:44 --> Output Class Initialized
INFO - 2017-04-11 10:06:44 --> Security Class Initialized
DEBUG - 2017-04-11 10:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-11 10:06:44 --> Input Class Initialized
INFO - 2017-04-11 10:06:44 --> Language Class Initialized
INFO - 2017-04-11 10:06:44 --> Loader Class Initialized
INFO - 2017-04-11 10:06:44 --> Helper loaded: url_helper
INFO - 2017-04-11 10:06:44 --> Helper loaded: language_helper
INFO - 2017-04-11 10:06:44 --> Helper loaded: html_helper
INFO - 2017-04-11 10:06:44 --> Helper loaded: form_helper
INFO - 2017-04-11 10:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-11 10:06:44 --> Controller Class Initialized
INFO - 2017-04-11 10:06:44 --> Database Driver Class Initialized
INFO - 2017-04-11 10:06:44 --> Model Class Initialized
INFO - 2017-04-11 10:06:44 --> Model Class Initialized
INFO - 2017-04-11 10:06:44 --> Model Class Initialized
INFO - 2017-04-11 10:06:44 --> Model Class Initialized
INFO - 2017-04-11 10:06:44 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-11 10:06:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-11 10:06:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\dashboard.php
INFO - 2017-04-11 10:06:44 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-11 10:06:44 --> Final output sent to browser
DEBUG - 2017-04-11 10:06:44 --> Total execution time: 0.1250
INFO - 2017-04-11 10:06:47 --> Config Class Initialized
INFO - 2017-04-11 10:06:47 --> Hooks Class Initialized
DEBUG - 2017-04-11 10:06:47 --> UTF-8 Support Enabled
INFO - 2017-04-11 10:06:47 --> Utf8 Class Initialized
INFO - 2017-04-11 10:06:47 --> URI Class Initialized
INFO - 2017-04-11 10:06:47 --> Router Class Initialized
INFO - 2017-04-11 10:06:47 --> Output Class Initialized
INFO - 2017-04-11 10:06:47 --> Security Class Initialized
DEBUG - 2017-04-11 10:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-11 10:06:47 --> Input Class Initialized
INFO - 2017-04-11 10:06:47 --> Language Class Initialized
INFO - 2017-04-11 10:06:47 --> Loader Class Initialized
INFO - 2017-04-11 10:06:47 --> Helper loaded: url_helper
INFO - 2017-04-11 10:06:47 --> Helper loaded: language_helper
INFO - 2017-04-11 10:06:47 --> Helper loaded: html_helper
INFO - 2017-04-11 10:06:47 --> Helper loaded: form_helper
INFO - 2017-04-11 10:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-11 10:06:47 --> Controller Class Initialized
INFO - 2017-04-11 10:06:47 --> Database Driver Class Initialized
INFO - 2017-04-11 10:06:47 --> Model Class Initialized
INFO - 2017-04-11 10:06:47 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-11 10:06:47 --> Zip Compression Class Initialized
INFO - 2017-04-11 10:06:47 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-04-11 10:06:47 --> Pagination Class Initialized
INFO - 2017-04-11 10:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header.php
INFO - 2017-04-11 10:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\calon_peserta.php
INFO - 2017-04-11 10:06:47 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer.php
INFO - 2017-04-11 10:06:47 --> Final output sent to browser
DEBUG - 2017-04-11 10:06:47 --> Total execution time: 0.0869
INFO - 2017-04-11 10:06:49 --> Config Class Initialized
INFO - 2017-04-11 10:06:49 --> Hooks Class Initialized
DEBUG - 2017-04-11 10:06:49 --> UTF-8 Support Enabled
INFO - 2017-04-11 10:06:49 --> Utf8 Class Initialized
INFO - 2017-04-11 10:06:49 --> URI Class Initialized
INFO - 2017-04-11 10:06:49 --> Router Class Initialized
INFO - 2017-04-11 10:06:49 --> Output Class Initialized
INFO - 2017-04-11 10:06:49 --> Security Class Initialized
DEBUG - 2017-04-11 10:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-11 10:06:49 --> Input Class Initialized
INFO - 2017-04-11 10:06:49 --> Language Class Initialized
INFO - 2017-04-11 10:06:49 --> Loader Class Initialized
INFO - 2017-04-11 10:06:49 --> Helper loaded: url_helper
INFO - 2017-04-11 10:06:49 --> Helper loaded: language_helper
INFO - 2017-04-11 10:06:49 --> Helper loaded: html_helper
INFO - 2017-04-11 10:06:49 --> Helper loaded: form_helper
INFO - 2017-04-11 10:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-11 10:06:49 --> Controller Class Initialized
INFO - 2017-04-11 10:06:49 --> Database Driver Class Initialized
INFO - 2017-04-11 10:06:49 --> Model Class Initialized
INFO - 2017-04-11 10:06:49 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-11 10:06:49 --> Zip Compression Class Initialized
INFO - 2017-04-11 10:06:49 --> Language file loaded: language/indonesia/pagination_lang.php
INFO - 2017-04-11 10:06:49 --> Pagination Class Initialized
INFO - 2017-04-11 10:07:00 --> Config Class Initialized
INFO - 2017-04-11 10:07:00 --> Hooks Class Initialized
DEBUG - 2017-04-11 10:07:00 --> UTF-8 Support Enabled
INFO - 2017-04-11 10:07:00 --> Utf8 Class Initialized
INFO - 2017-04-11 10:07:00 --> URI Class Initialized
INFO - 2017-04-11 10:07:00 --> Router Class Initialized
INFO - 2017-04-11 10:07:00 --> Output Class Initialized
INFO - 2017-04-11 10:07:00 --> Security Class Initialized
DEBUG - 2017-04-11 10:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-11 10:07:00 --> Input Class Initialized
INFO - 2017-04-11 10:07:00 --> Language Class Initialized
INFO - 2017-04-11 10:07:00 --> Loader Class Initialized
INFO - 2017-04-11 10:07:00 --> Helper loaded: url_helper
INFO - 2017-04-11 10:07:00 --> Helper loaded: language_helper
INFO - 2017-04-11 10:07:00 --> Helper loaded: html_helper
INFO - 2017-04-11 10:07:00 --> Helper loaded: form_helper
INFO - 2017-04-11 10:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-11 10:07:00 --> Controller Class Initialized
INFO - 2017-04-11 10:07:00 --> Database Driver Class Initialized
INFO - 2017-04-11 10:07:00 --> Model Class Initialized
INFO - 2017-04-11 10:07:00 --> Model Class Initialized
INFO - 2017-04-11 10:07:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-11 10:07:00 --> Config Class Initialized
INFO - 2017-04-11 10:07:00 --> Hooks Class Initialized
DEBUG - 2017-04-11 10:07:00 --> UTF-8 Support Enabled
INFO - 2017-04-11 10:07:00 --> Utf8 Class Initialized
INFO - 2017-04-11 10:07:00 --> URI Class Initialized
INFO - 2017-04-11 10:07:00 --> Router Class Initialized
INFO - 2017-04-11 10:07:00 --> Output Class Initialized
INFO - 2017-04-11 10:07:00 --> Security Class Initialized
DEBUG - 2017-04-11 10:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-04-11 10:07:00 --> Input Class Initialized
INFO - 2017-04-11 10:07:00 --> Language Class Initialized
INFO - 2017-04-11 10:07:00 --> Loader Class Initialized
INFO - 2017-04-11 10:07:00 --> Helper loaded: url_helper
INFO - 2017-04-11 10:07:00 --> Helper loaded: language_helper
INFO - 2017-04-11 10:07:00 --> Helper loaded: html_helper
INFO - 2017-04-11 10:07:00 --> Helper loaded: form_helper
INFO - 2017-04-11 10:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-04-11 10:07:00 --> Controller Class Initialized
INFO - 2017-04-11 10:07:00 --> Database Driver Class Initialized
INFO - 2017-04-11 10:07:00 --> Model Class Initialized
INFO - 2017-04-11 10:07:00 --> Language file loaded: language/indonesia/basic_lang.php
INFO - 2017-04-11 10:07:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\header_login.php
INFO - 2017-04-11 10:07:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\login.php
INFO - 2017-04-11 10:07:00 --> File loaded: C:\wamp64\www\savsoftquiz\application\views\footer_login.php
INFO - 2017-04-11 10:07:00 --> Final output sent to browser
DEBUG - 2017-04-11 10:07:00 --> Total execution time: 0.0829
